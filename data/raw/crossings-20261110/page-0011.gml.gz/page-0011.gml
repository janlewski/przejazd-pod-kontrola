<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:32" numberMatched="11728" numberReturned="728"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=10000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>487868.897000 189403.768623</gml:lowerCorner>
      		<gml:upperCorner>748403.698431 365689.573081</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494032.246000 289094.597000</gml:lowerCorner>
        		<gml:upperCorner>494032.246000 289094.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494032.246000 289094.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 041 312</ms:GML_ID>
        <ms:NAZWA>373 041 312</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373041312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493577.230000 289243.935000</gml:lowerCorner>
        		<gml:upperCorner>493577.230000 289243.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493577.230000 289243.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 041 806</ms:GML_ID>
        <ms:NAZWA>373 041 806</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373041806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495765.251000 289487.695000</gml:lowerCorner>
        		<gml:upperCorner>495765.251000 289487.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495765.251000 289487.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 039 341</ms:GML_ID>
        <ms:NAZWA>373 039 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373039341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499722.983000 289549.766000</gml:lowerCorner>
        		<gml:upperCorner>499722.983000 289549.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499722.983000 289549.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 034 999</ms:GML_ID>
        <ms:NAZWA>373 034 999</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373034999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512741.024000 218526.330000</gml:lowerCorner>
        		<gml:upperCorner>512741.024000 218526.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512741.024000 218526.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 081 323</ms:GML_ID>
        <ms:NAZWA>364 081 323</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364081323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505284.098606 218629.710840</gml:lowerCorner>
        		<gml:upperCorner>505284.098606 218629.710840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505284.098606 218629.710840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 456 994</ms:GML_ID>
        <ms:NAZWA>003 456 994</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003456994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513630.118000 218729.012000</gml:lowerCorner>
        		<gml:upperCorner>513630.118000 218729.012000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513630.118000 218729.012000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 080 410</ms:GML_ID>
        <ms:NAZWA>364 080 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364080410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500835.726000 218784.609000</gml:lowerCorner>
        		<gml:upperCorner>500835.726000 218784.609000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500835.726000 218784.609000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 216 627</ms:GML_ID>
        <ms:NAZWA>273 216 627</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273216627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514427.537563 218888.014166</gml:lowerCorner>
        		<gml:upperCorner>514427.537563 218888.014166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514427.537563 218888.014166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 079 596</ms:GML_ID>
        <ms:NAZWA>364 079 596</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364079596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516324.214000 219283.540000</gml:lowerCorner>
        		<gml:upperCorner>516324.214000 219283.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516324.214000 219283.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 077 719</ms:GML_ID>
        <ms:NAZWA>364 077 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364077719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516843.165000 219681.577000</gml:lowerCorner>
        		<gml:upperCorner>516843.165000 219681.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516843.165000 219681.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 077 022</ms:GML_ID>
        <ms:NAZWA>364 077 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364077022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517318.985000 220127.146000</gml:lowerCorner>
        		<gml:upperCorner>517318.985000 220127.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517318.985000 220127.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 076 351</ms:GML_ID>
        <ms:NAZWA>364 076 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364076351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517448.927455 220247.600447</gml:lowerCorner>
        		<gml:upperCorner>517448.927455 220247.600447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517448.927455 220247.600447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 076 174</ms:GML_ID>
        <ms:NAZWA>364 076 174</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364076174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517886.244000 220659.036000</gml:lowerCorner>
        		<gml:upperCorner>517886.244000 220659.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517886.244000 220659.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 075 574</ms:GML_ID>
        <ms:NAZWA>364 075 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364075574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498313.230412 220841.229249</gml:lowerCorner>
        		<gml:upperCorner>498313.230412 220841.229249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498313.230412 220841.229249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 213 370</ms:GML_ID>
        <ms:NAZWA>273 213 370</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273213370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518132.434000 221287.862000</gml:lowerCorner>
        		<gml:upperCorner>518132.434000 221287.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518132.434000 221287.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 074 852</ms:GML_ID>
        <ms:NAZWA>364 074 852</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364074852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503854.570636 221434.418198</gml:lowerCorner>
        		<gml:upperCorner>503854.570636 221434.418198</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503854.570636 221434.418198</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 453 844</ms:GML_ID>
        <ms:NAZWA>003 453 844</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003453844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503392.367754 222994.042019</gml:lowerCorner>
        		<gml:upperCorner>503392.367754 222994.042019</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503392.367754 222994.042019</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 452 188</ms:GML_ID>
        <ms:NAZWA>003 452 188</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003452188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518197.248000 223018.267000</gml:lowerCorner>
        		<gml:upperCorner>518197.248000 223018.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518197.248000 223018.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 073 098</ms:GML_ID>
        <ms:NAZWA>364 073 098</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364073098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496249.423037 223144.159897</gml:lowerCorner>
        		<gml:upperCorner>496249.423037 223144.159897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496249.423037 223144.159897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 210 271</ms:GML_ID>
        <ms:NAZWA>273 210 271</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273210271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495446.140143 223769.314317</gml:lowerCorner>
        		<gml:upperCorner>495446.140143 223769.314317</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495446.140143 223769.314317</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 209 252</ms:GML_ID>
        <ms:NAZWA>273 209 252</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273209252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503392.289365 224117.272843</gml:lowerCorner>
        		<gml:upperCorner>503392.289365 224117.272843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503392.289365 224117.272843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 451 081</ms:GML_ID>
        <ms:NAZWA>003 451 081</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003451081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518315.714000 224216.423000</gml:lowerCorner>
        		<gml:upperCorner>518315.714000 224216.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518315.714000 224216.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 071 885</ms:GML_ID>
        <ms:NAZWA>364 071 885</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364071885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518220.140000 224406.204000</gml:lowerCorner>
        		<gml:upperCorner>518220.140000 224406.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518220.140000 224406.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 071 675</ms:GML_ID>
        <ms:NAZWA>364 071 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364071675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493722.077449 225029.842868</gml:lowerCorner>
        		<gml:upperCorner>493722.077449 225029.842868</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493722.077449 225029.842868</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 207 119</ms:GML_ID>
        <ms:NAZWA>273 207 119</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273207119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493516.999635 225226.968666</gml:lowerCorner>
        		<gml:upperCorner>493516.999635 225226.968666</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493516.999635 225226.968666</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 206 835</ms:GML_ID>
        <ms:NAZWA>273 206 835</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273206835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517578.664000 227569.642000</gml:lowerCorner>
        		<gml:upperCorner>517578.664000 227569.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517578.664000 227569.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 068 411</ms:GML_ID>
        <ms:NAZWA>364 068 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364068411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489407.627000 227994.409000</gml:lowerCorner>
        		<gml:upperCorner>489407.627000 227994.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489407.627000 227994.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 201 777</ms:GML_ID>
        <ms:NAZWA>273 201 777</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273201777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516765.297190 228538.874183</gml:lowerCorner>
        		<gml:upperCorner>516765.297190 228538.874183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516765.297190 228538.874183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 067 066</ms:GML_ID>
        <ms:NAZWA>364 067 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364067066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516397.036000 228942.367000</gml:lowerCorner>
        		<gml:upperCorner>516397.036000 228942.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516397.036000 228942.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 066 497</ms:GML_ID>
        <ms:NAZWA>364 066 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364066497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516385.755000 230331.608000</gml:lowerCorner>
        		<gml:upperCorner>516385.755000 230331.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516385.755000 230331.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 065 099</ms:GML_ID>
        <ms:NAZWA>364 065 099</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364065099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501536.919879 231042.479486</gml:lowerCorner>
        		<gml:upperCorner>501536.919879 231042.479486</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501536.919879 231042.479486</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 443 830</ms:GML_ID>
        <ms:NAZWA>003 443 830</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003443830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516629.486000 231105.737000</gml:lowerCorner>
        		<gml:upperCorner>516629.486000 231105.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516629.486000 231105.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 064 288</ms:GML_ID>
        <ms:NAZWA>364 064 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364064288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500267.661020 232648.305818</gml:lowerCorner>
        		<gml:upperCorner>500267.661020 232648.305818</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500267.661020 232648.305818</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 441 687</ms:GML_ID>
        <ms:NAZWA>003 441 687</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003441687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499155.938000 328444.577000</gml:lowerCorner>
        		<gml:upperCorner>499155.938000 328444.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499155.938000 328444.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 337 487</ms:GML_ID>
        <ms:NAZWA>003 337 487</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003337487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500107.611086 330551.477387</gml:lowerCorner>
        		<gml:upperCorner>500107.611086 330551.477387</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500107.611086 330551.477387</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 335 171</ms:GML_ID>
        <ms:NAZWA>003 335 171</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003335171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500633.426290 331687.585305</gml:lowerCorner>
        		<gml:upperCorner>500633.426290 331687.585305</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500633.426290 331687.585305</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 333 922</ms:GML_ID>
        <ms:NAZWA>003 333 922</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003333922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500655.862000 334585.525000</gml:lowerCorner>
        		<gml:upperCorner>500655.862000 334585.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500655.862000 334585.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 331 006</ms:GML_ID>
        <ms:NAZWA>003 331 006</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003331006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500577.034000 336403.192000</gml:lowerCorner>
        		<gml:upperCorner>500577.034000 336403.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500577.034000 336403.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 329 186</ms:GML_ID>
        <ms:NAZWA>003 329 186</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003329186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488948.516000 336986.501000</gml:lowerCorner>
        		<gml:upperCorner>488948.516000 336986.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488948.516000 336986.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 087 482</ms:GML_ID>
        <ms:NAZWA>357 087 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357087482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500444.455000 339443.468000</gml:lowerCorner>
        		<gml:upperCorner>500444.455000 339443.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500444.455000 339443.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 326 144</ms:GML_ID>
        <ms:NAZWA>003 326 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003326144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490441.426000 339725.726000</gml:lowerCorner>
        		<gml:upperCorner>490441.426000 339725.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490441.426000 339725.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 090 643</ms:GML_ID>
        <ms:NAZWA>357 090 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357090643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501237.918000 342012.320000</gml:lowerCorner>
        		<gml:upperCorner>501237.918000 342012.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501237.918000 342012.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 323 388</ms:GML_ID>
        <ms:NAZWA>003 323 388</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003323388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492022.377000 342131.728000</gml:lowerCorner>
        		<gml:upperCorner>492022.377000 342131.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492022.377000 342131.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 093 535</ms:GML_ID>
        <ms:NAZWA>357 093 535</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357093535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501805.034000 343070.505000</gml:lowerCorner>
        		<gml:upperCorner>501805.034000 343070.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501805.034000 343070.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 322 183</ms:GML_ID>
        <ms:NAZWA>003 322 183</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003322183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492814.223423 343723.768232</gml:lowerCorner>
        		<gml:upperCorner>492814.223423 343723.768232</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492814.223423 343723.768232</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 095 332</ms:GML_ID>
        <ms:NAZWA>357 095 332</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357095332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502166.779000 343746.742000</gml:lowerCorner>
        		<gml:upperCorner>502166.779000 343746.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502166.779000 343746.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 321 420</ms:GML_ID>
        <ms:NAZWA>003 321 420</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003321420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493577.439000 344334.977000</gml:lowerCorner>
        		<gml:upperCorner>493577.439000 344334.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493577.439000 344334.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 096 319</ms:GML_ID>
        <ms:NAZWA>357 096 319</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357096319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493758.481000 345259.167000</gml:lowerCorner>
        		<gml:upperCorner>493758.481000 345259.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493758.481000 345259.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 097 266</ms:GML_ID>
        <ms:NAZWA>357 097 266</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357097266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503081.107000 345453.604000</gml:lowerCorner>
        		<gml:upperCorner>503081.107000 345453.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503081.107000 345453.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 319 486</ms:GML_ID>
        <ms:NAZWA>003 319 486</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003319486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503317.209000 346185.052000</gml:lowerCorner>
        		<gml:upperCorner>503317.209000 346185.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503317.209000 346185.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 318 706</ms:GML_ID>
        <ms:NAZWA>003 318 706</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003318706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494352.633000 346567.722000</gml:lowerCorner>
        		<gml:upperCorner>494352.633000 346567.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494352.633000 346567.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 098 703</ms:GML_ID>
        <ms:NAZWA>357 098 703</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357098703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488519.732245 353545.053961</gml:lowerCorner>
        		<gml:upperCorner>488519.732245 353545.053961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488519.732245 353545.053961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 146 361</ms:GML_ID>
        <ms:NAZWA>271 146 361</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271146361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488702.457452 353615.841916</gml:lowerCorner>
        		<gml:upperCorner>488702.457452 353615.841916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488702.457452 353615.841916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 146 551</ms:GML_ID>
        <ms:NAZWA>271 146 551</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271146551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489643.901000 353823.380000</gml:lowerCorner>
        		<gml:upperCorner>489643.901000 353823.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489643.901000 353823.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 147 522</ms:GML_ID>
        <ms:NAZWA>271 147 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271147522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491692.591290 354255.952078</gml:lowerCorner>
        		<gml:upperCorner>491692.591290 354255.952078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491692.591290 354255.952078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 149 617</ms:GML_ID>
        <ms:NAZWA>271 149 617</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271149617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494191.191349 354826.200703</gml:lowerCorner>
        		<gml:upperCorner>494191.191349 354826.200703</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494191.191349 354826.200703</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 152 183</ms:GML_ID>
        <ms:NAZWA>271 152 183</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271152183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494645.734000 347893.688000</gml:lowerCorner>
        		<gml:upperCorner>494645.734000 347893.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494645.734000 347893.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 100 055</ms:GML_ID>
        <ms:NAZWA>357 100 055</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357100055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496375.609206 355691.531638</gml:lowerCorner>
        		<gml:upperCorner>496375.609206 355691.531638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496375.609206 355691.531638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 154 532</ms:GML_ID>
        <ms:NAZWA>271 154 532</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271154532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496435.692000 349413.549000</gml:lowerCorner>
        		<gml:upperCorner>496435.692000 349413.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496435.692000 349413.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 102 549</ms:GML_ID>
        <ms:NAZWA>357 102 549</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357102549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496444.677000 364820.992000</gml:lowerCorner>
        		<gml:upperCorner>496444.677000 364820.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496444.677000 364820.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 187 962</ms:GML_ID>
        <ms:NAZWA>272 187 962</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272187962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496472.786000 354666.047000</gml:lowerCorner>
        		<gml:upperCorner>496472.786000 354666.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496472.786000 354666.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 108 145</ms:GML_ID>
        <ms:NAZWA>357 108 145</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357108145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496566.768000 353472.826000</gml:lowerCorner>
        		<gml:upperCorner>496566.768000 353472.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496566.768000 353472.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 106 913</ms:GML_ID>
        <ms:NAZWA>357 106 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357106913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496650.471000 349578.150000</gml:lowerCorner>
        		<gml:upperCorner>496650.471000 349578.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496650.471000 349578.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 102 823</ms:GML_ID>
        <ms:NAZWA>357 102 823</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357102823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496789.360000 355323.390000</gml:lowerCorner>
        		<gml:upperCorner>496789.360000 355323.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496789.360000 355323.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 108 875</ms:GML_ID>
        <ms:NAZWA>357 108 875</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357108875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496832.428000 349897.345000</gml:lowerCorner>
        		<gml:upperCorner>496832.428000 349897.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496832.428000 349897.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 103 193</ms:GML_ID>
        <ms:NAZWA>357 103 193</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357103193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497574.621000 363730.529000</gml:lowerCorner>
        		<gml:upperCorner>497574.621000 363730.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497574.621000 363730.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 189 534</ms:GML_ID>
        <ms:NAZWA>272 189 534</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272189534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498418.262000 356211.485000</gml:lowerCorner>
        		<gml:upperCorner>498418.262000 356211.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498418.262000 356211.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 156 642</ms:GML_ID>
        <ms:NAZWA>271 156 642</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271156642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498797.272822 362537.291958</gml:lowerCorner>
        		<gml:upperCorner>498797.272822 362537.291958</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498797.272822 362537.291958</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 191 244</ms:GML_ID>
        <ms:NAZWA>272 191 244</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272191244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499108.395537 356376.882374</gml:lowerCorner>
        		<gml:upperCorner>499108.395537 356376.882374</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499108.395537 356376.882374</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 157 352</ms:GML_ID>
        <ms:NAZWA>271 157 352</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271157352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499869.292000 361515.536000</gml:lowerCorner>
        		<gml:upperCorner>499869.292000 361515.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499869.292000 361515.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 192 725</ms:GML_ID>
        <ms:NAZWA>272 192 725</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272192725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500433.089000 360970.711000</gml:lowerCorner>
        		<gml:upperCorner>500433.089000 360970.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500433.089000 360970.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 193 509</ms:GML_ID>
        <ms:NAZWA>272 193 509</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272193509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500804.864000 360611.755000</gml:lowerCorner>
        		<gml:upperCorner>500804.864000 360611.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500804.864000 360611.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 194 026</ms:GML_ID>
        <ms:NAZWA>272 194 026</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272194026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502079.505818 359579.909346</gml:lowerCorner>
        		<gml:upperCorner>502079.505818 359579.909346</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502079.505818 359579.909346</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 195 084</ms:GML_ID>
        <ms:NAZWA>272 195 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272195084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502096.406786 359492.295762</gml:lowerCorner>
        		<gml:upperCorner>502096.406786 359492.295762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502096.406786 359492.295762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 194 984</ms:GML_ID>
        <ms:NAZWA>272 194 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272194984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502178.371646 359794.868583</gml:lowerCorner>
        		<gml:upperCorner>502178.371646 359794.868583</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502178.371646 359794.868583</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 195 309</ms:GML_ID>
        <ms:NAZWA>272 195 309</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272195309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502188.958084 359153.189991</gml:lowerCorner>
        		<gml:upperCorner>502188.958084 359153.189991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502188.958084 359153.189991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 196 047</ms:GML_ID>
        <ms:NAZWA>272 196 047</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272196047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502386.017337 359771.605510</gml:lowerCorner>
        		<gml:upperCorner>502386.017337 359771.605510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502386.017337 359771.605510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 195 514</ms:GML_ID>
        <ms:NAZWA>272 195 514</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272195514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502723.482000 357288.574000</gml:lowerCorner>
        		<gml:upperCorner>502723.482000 357288.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502723.482000 357288.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.802 000 849</ms:GML_ID>
        <ms:NAZWA>802 000 849</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>802000849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502732.440064 357245.123226</gml:lowerCorner>
        		<gml:upperCorner>502732.440064 357245.123226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502732.440064 357245.123226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 161 080</ms:GML_ID>
        <ms:NAZWA>271 161 080</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271161080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502959.674683 357744.576689</gml:lowerCorner>
        		<gml:upperCorner>502959.674683 357744.576689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502959.674683 357744.576689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 197 664</ms:GML_ID>
        <ms:NAZWA>272 197 664</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272197664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503307.139000 356768.977000</gml:lowerCorner>
        		<gml:upperCorner>503307.139000 356768.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503307.139000 356768.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.801 001 546</ms:GML_ID>
        <ms:NAZWA>801 001 546</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>801001546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503446.935000 356309.138000</gml:lowerCorner>
        		<gml:upperCorner>503446.935000 356309.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503446.935000 356309.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.801 002 060</ms:GML_ID>
        <ms:NAZWA>801 002 060</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>801002060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503654.069982 354487.904993</gml:lowerCorner>
        		<gml:upperCorner>503654.069982 354487.904993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503654.069982 354487.904993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 310 393</ms:GML_ID>
        <ms:NAZWA>003 310 393</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003310393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496286.842134 319733.849393</gml:lowerCorner>
        		<gml:upperCorner>496286.842134 319733.849393</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496286.842134 319733.849393</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 346 719</ms:GML_ID>
        <ms:NAZWA>003 346 719</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003346719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488832.500860 319856.672209</gml:lowerCorner>
        		<gml:upperCorner>488832.500860 319856.672209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488832.500860 319856.672209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 068 464</ms:GML_ID>
        <ms:NAZWA>357 068 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357068464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488136.138077 320102.009795</gml:lowerCorner>
        		<gml:upperCorner>488136.138077 320102.009795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488136.138077 320102.009795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 067 690</ms:GML_ID>
        <ms:NAZWA>357 067 690</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357067690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489403.975000 320222.499000</gml:lowerCorner>
        		<gml:upperCorner>489403.975000 320222.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489403.975000 320222.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 069 168</ms:GML_ID>
        <ms:NAZWA>357 069 168</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357069168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488009.036419 320413.600069</gml:lowerCorner>
        		<gml:upperCorner>488009.036419 320413.600069</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488009.036419 320413.600069</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 067 345</ms:GML_ID>
        <ms:NAZWA>357 067 345</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357067345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487956.856763 320688.637697</gml:lowerCorner>
        		<gml:upperCorner>487956.856763 320688.637697</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487956.856763 320688.637697</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 067 061</ms:GML_ID>
        <ms:NAZWA>357 067 061</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357067061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489436.342000 320692.657000</gml:lowerCorner>
        		<gml:upperCorner>489436.342000 320692.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489436.342000 320692.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 069 651</ms:GML_ID>
        <ms:NAZWA>357 069 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357069651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488722.435000 321824.846000</gml:lowerCorner>
        		<gml:upperCorner>488722.435000 321824.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488722.435000 321824.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 070 992</ms:GML_ID>
        <ms:NAZWA>357 070 992</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357070992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496738.620893 321890.247065</gml:lowerCorner>
        		<gml:upperCorner>496738.620893 321890.247065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496738.620893 321890.247065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 344 513</ms:GML_ID>
        <ms:NAZWA>003 344 513</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003344513</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488616.704000 322008.881000</gml:lowerCorner>
        		<gml:upperCorner>488616.704000 322008.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488616.704000 322008.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 071 205</ms:GML_ID>
        <ms:NAZWA>357 071 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357071205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497023.361757 323234.834478</gml:lowerCorner>
        		<gml:upperCorner>497023.361757 323234.834478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497023.361757 323234.834478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 343 136</ms:GML_ID>
        <ms:NAZWA>003 343 136</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003343136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488034.698000 323597.201000</gml:lowerCorner>
        		<gml:upperCorner>488034.698000 323597.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488034.698000 323597.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 072 897</ms:GML_ID>
        <ms:NAZWA>357 072 897</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357072897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497142.600522 323840.967920</gml:lowerCorner>
        		<gml:upperCorner>497142.600522 323840.967920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497142.600522 323840.967920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 342 522</ms:GML_ID>
        <ms:NAZWA>003 342 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003342522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497320.333046 324474.344375</gml:lowerCorner>
        		<gml:upperCorner>497320.333046 324474.344375</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497320.333046 324474.344375</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 341 862</ms:GML_ID>
        <ms:NAZWA>003 341 862</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003341862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487884.979000 325236.234000</gml:lowerCorner>
        		<gml:upperCorner>487884.979000 325236.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487884.979000 325236.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 074 547</ms:GML_ID>
        <ms:NAZWA>357 074 547</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357074547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487868.897000 325491.294000</gml:lowerCorner>
        		<gml:upperCorner>487868.897000 325491.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487868.897000 325491.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 074 801</ms:GML_ID>
        <ms:NAZWA>357 074 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357074801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498400.280905 326811.424770</gml:lowerCorner>
        		<gml:upperCorner>498400.280905 326811.424770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498400.280905 326811.424770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 339 290</ms:GML_ID>
        <ms:NAZWA>003 339 290</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003339290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498679.210387 327413.791605</gml:lowerCorner>
        		<gml:upperCorner>498679.210387 327413.791605</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498679.210387 327413.791605</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 338 624</ms:GML_ID>
        <ms:NAZWA>003 338 624</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003338624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706726.307000 275557.311000</gml:lowerCorner>
        		<gml:upperCorner>706726.307000 275557.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706726.307000 275557.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 043 528</ms:GML_ID>
        <ms:NAZWA>402 043 528</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402043528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707035.276000 275736.694000</gml:lowerCorner>
        		<gml:upperCorner>707035.276000 275736.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707035.276000 275736.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 043 170</ms:GML_ID>
        <ms:NAZWA>402 043 170</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402043170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707266.927000 275880.296000</gml:lowerCorner>
        		<gml:upperCorner>707266.927000 275880.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707266.927000 275880.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 042 893</ms:GML_ID>
        <ms:NAZWA>402 042 893</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402042893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707340.444728 275926.479435</gml:lowerCorner>
        		<gml:upperCorner>707340.444728 275926.479435</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707340.444728 275926.479435</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 042 814</ms:GML_ID>
        <ms:NAZWA>402 042 814</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402042814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707395.070000 275971.657000</gml:lowerCorner>
        		<gml:upperCorner>707395.070000 275971.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707395.070000 275971.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 042 734</ms:GML_ID>
        <ms:NAZWA>402 042 734</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402042734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707408.345746 275989.116219</gml:lowerCorner>
        		<gml:upperCorner>707408.345746 275989.116219</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707408.345746 275989.116219</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 042 712</ms:GML_ID>
        <ms:NAZWA>402 042 712</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402042712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707424.657000 276019.590000</gml:lowerCorner>
        		<gml:upperCorner>707424.657000 276019.590000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707424.657000 276019.590000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 042 692</ms:GML_ID>
        <ms:NAZWA>402 042 692</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402042692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706983.781516 277515.342827</gml:lowerCorner>
        		<gml:upperCorner>706983.781516 277515.342827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706983.781516 277515.342827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 098 066</ms:GML_ID>
        <ms:NAZWA>404 098 066</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404098066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707114.849000 277635.758000</gml:lowerCorner>
        		<gml:upperCorner>707114.849000 277635.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707114.849000 277635.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 040 995</ms:GML_ID>
        <ms:NAZWA>402 040 995</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402040995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706642.482000 278096.588000</gml:lowerCorner>
        		<gml:upperCorner>706642.482000 278096.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706642.482000 278096.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 097 400</ms:GML_ID>
        <ms:NAZWA>404 097 400</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404097400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707462.652000 278452.176000</gml:lowerCorner>
        		<gml:upperCorner>707462.652000 278452.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707462.652000 278452.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 040 108</ms:GML_ID>
        <ms:NAZWA>402 040 108</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402040108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707516.840000 280649.745000</gml:lowerCorner>
        		<gml:upperCorner>707516.840000 280649.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707516.840000 280649.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 037 867</ms:GML_ID>
        <ms:NAZWA>402 037 867</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402037867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704094.820136 281448.140624</gml:lowerCorner>
        		<gml:upperCorner>704094.820136 281448.140624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704094.820136 281448.140624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 093 163</ms:GML_ID>
        <ms:NAZWA>404 093 163</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404093163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703464.083000 283167.696000</gml:lowerCorner>
        		<gml:upperCorner>703464.083000 283167.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703464.083000 283167.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 091 330</ms:GML_ID>
        <ms:NAZWA>404 091 330</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404091330</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708466.097964 286037.629861</gml:lowerCorner>
        		<gml:upperCorner>708466.097964 286037.629861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708466.097964 286037.629861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 032 216</ms:GML_ID>
        <ms:NAZWA>402 032 216</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402032216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702235.779558 286544.577994</gml:lowerCorner>
        		<gml:upperCorner>702235.779558 286544.577994</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702235.779558 286544.577994</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 087 738</ms:GML_ID>
        <ms:NAZWA>404 087 738</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404087738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708682.434000 286780.457000</gml:lowerCorner>
        		<gml:upperCorner>708682.434000 286780.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708682.434000 286780.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 031 448</ms:GML_ID>
        <ms:NAZWA>402 031 448</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402031448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701951.682309 287331.093294</gml:lowerCorner>
        		<gml:upperCorner>701951.682309 287331.093294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701951.682309 287331.093294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 086 906</ms:GML_ID>
        <ms:NAZWA>404 086 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404086906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708821.207000 287377.019000</gml:lowerCorner>
        		<gml:upperCorner>708821.207000 287377.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708821.207000 287377.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 030 833</ms:GML_ID>
        <ms:NAZWA>402 030 833</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402030833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708912.151022 288146.484356</gml:lowerCorner>
        		<gml:upperCorner>708912.151022 288146.484356</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708912.151022 288146.484356</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 030 060</ms:GML_ID>
        <ms:NAZWA>402 030 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402030060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701588.436623 288331.595628</gml:lowerCorner>
        		<gml:upperCorner>701588.436623 288331.595628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701588.436623 288331.595628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 085 853</ms:GML_ID>
        <ms:NAZWA>404 085 853</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404085853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709107.888000 289833.630000</gml:lowerCorner>
        		<gml:upperCorner>709107.888000 289833.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709107.888000 289833.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 028 348</ms:GML_ID>
        <ms:NAZWA>402 028 348</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402028348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700876.771000 290292.962000</gml:lowerCorner>
        		<gml:upperCorner>700876.771000 290292.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700876.771000 290292.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 083 749</ms:GML_ID>
        <ms:NAZWA>404 083 749</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404083749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700399.045000 291607.788000</gml:lowerCorner>
        		<gml:upperCorner>700399.045000 291607.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700399.045000 291607.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 082 353</ms:GML_ID>
        <ms:NAZWA>404 082 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404082353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700066.484000 292440.828000</gml:lowerCorner>
        		<gml:upperCorner>700066.484000 292440.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700066.484000 292440.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 081 454</ms:GML_ID>
        <ms:NAZWA>404 081 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404081454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699221.392016 293301.336394</gml:lowerCorner>
        		<gml:upperCorner>699221.392016 293301.336394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699221.392016 293301.336394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 080 227</ms:GML_ID>
        <ms:NAZWA>404 080 227</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404080227</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709164.658000 293567.066000</gml:lowerCorner>
        		<gml:upperCorner>709164.658000 293567.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709164.658000 293567.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 024 611</ms:GML_ID>
        <ms:NAZWA>402 024 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402024611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693390.553000 360666.342000</gml:lowerCorner>
        		<gml:upperCorner>693390.553000 360666.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693390.553000 360666.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 127 844</ms:GML_ID>
        <ms:NAZWA>405 127 844</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405127844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697490.560000 360015.039000</gml:lowerCorner>
        		<gml:upperCorner>697490.560000 360015.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697490.560000 360015.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 132 035</ms:GML_ID>
        <ms:NAZWA>405 132 035</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405132035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702667.660230 362159.873022</gml:lowerCorner>
        		<gml:upperCorner>702667.660230 362159.873022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702667.660230 362159.873022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 137 993</ms:GML_ID>
        <ms:NAZWA>405 137 993</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405137993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704319.005000 362331.167000</gml:lowerCorner>
        		<gml:upperCorner>704319.005000 362331.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704319.005000 362331.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 139 670</ms:GML_ID>
        <ms:NAZWA>405 139 670</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405139670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705537.001000 362223.475000</gml:lowerCorner>
        		<gml:upperCorner>705537.001000 362223.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705537.001000 362223.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 140 934</ms:GML_ID>
        <ms:NAZWA>405 140 934</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405140934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705539.109000 362223.670000</gml:lowerCorner>
        		<gml:upperCorner>705539.109000 362223.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705539.109000 362223.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 140 937</ms:GML_ID>
        <ms:NAZWA>405 140 937</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405140937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717500.420000 362002.466000</gml:lowerCorner>
        		<gml:upperCorner>717500.420000 362002.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717500.420000 362002.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 071 195</ms:GML_ID>
        <ms:NAZWA>212 071 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212071195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717823.609000 361714.061000</gml:lowerCorner>
        		<gml:upperCorner>717823.609000 361714.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717823.609000 361714.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 153 661</ms:GML_ID>
        <ms:NAZWA>405 153 661</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405153661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718042.908000 361786.669000</gml:lowerCorner>
        		<gml:upperCorner>718042.908000 361786.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718042.908000 361786.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 153 890</ms:GML_ID>
        <ms:NAZWA>405 153 890</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405153890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722521.510000 338048.936000</gml:lowerCorner>
        		<gml:upperCorner>722521.510000 338048.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722521.510000 338048.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 169 086</ms:GML_ID>
        <ms:NAZWA>202 169 086</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202169086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722922.133442 340122.827502</gml:lowerCorner>
        		<gml:upperCorner>722922.133442 340122.827502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722922.133442 340122.827502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 166 966</ms:GML_ID>
        <ms:NAZWA>202 166 966</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202166966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723803.699000 346315.038000</gml:lowerCorner>
        		<gml:upperCorner>723803.699000 346315.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723803.699000 346315.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 160 643</ms:GML_ID>
        <ms:NAZWA>202 160 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202160643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724207.700827 346382.008516</gml:lowerCorner>
        		<gml:upperCorner>724207.700827 346382.008516</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724207.700827 346382.008516</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 017 999</ms:GML_ID>
        <ms:NAZWA>418 017 999</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418017999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724808.720000 350292.570000</gml:lowerCorner>
        		<gml:upperCorner>724808.720000 350292.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724808.720000 350292.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 156 254</ms:GML_ID>
        <ms:NAZWA>202 156 254</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202156254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725208.765000 350632.217000</gml:lowerCorner>
        		<gml:upperCorner>725208.765000 350632.217000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725208.765000 350632.217000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 155 729</ms:GML_ID>
        <ms:NAZWA>202 155 729</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202155729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725681.681000 351033.551000</gml:lowerCorner>
        		<gml:upperCorner>725681.681000 351033.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725681.681000 351033.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 155 108</ms:GML_ID>
        <ms:NAZWA>202 155 108</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202155108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725884.167000 343087.028000</gml:lowerCorner>
        		<gml:upperCorner>725884.167000 343087.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725884.167000 343087.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 021 697</ms:GML_ID>
        <ms:NAZWA>418 021 697</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418021697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>726812.711000 341368.827000</gml:lowerCorner>
        		<gml:upperCorner>726812.711000 341368.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>726812.711000 341368.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 023 653</ms:GML_ID>
        <ms:NAZWA>418 023 653</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418023653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>727001.037000 352153.328000</gml:lowerCorner>
        		<gml:upperCorner>727001.037000 352153.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>727001.037000 352153.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 153 377</ms:GML_ID>
        <ms:NAZWA>202 153 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202153377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>727799.658000 339900.918000</gml:lowerCorner>
        		<gml:upperCorner>727799.658000 339900.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>727799.658000 339900.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 025 425</ms:GML_ID>
        <ms:NAZWA>418 025 425</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418025425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728225.132000 339384.983000</gml:lowerCorner>
        		<gml:upperCorner>728225.132000 339384.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728225.132000 339384.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 026 097</ms:GML_ID>
        <ms:NAZWA>418 026 097</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418026097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728863.651220 355977.978827</gml:lowerCorner>
        		<gml:upperCorner>728863.651220 355977.978827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728863.651220 355977.978827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 149 038</ms:GML_ID>
        <ms:NAZWA>202 149 038</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202149038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728881.878000 337615.422000</gml:lowerCorner>
        		<gml:upperCorner>728881.878000 337615.422000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728881.878000 337615.422000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 028 005</ms:GML_ID>
        <ms:NAZWA>418 028 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418028005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730023.167000 360809.072000</gml:lowerCorner>
        		<gml:upperCorner>730023.167000 360809.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730023.167000 360809.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 144 055</ms:GML_ID>
        <ms:NAZWA>202 144 055</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202144055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730177.564000 361678.597000</gml:lowerCorner>
        		<gml:upperCorner>730177.564000 361678.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730177.564000 361678.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 143 174</ms:GML_ID>
        <ms:NAZWA>202 143 174</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202143174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>747398.029935 362284.243680</gml:lowerCorner>
        		<gml:upperCorner>747398.029935 362284.243680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>747398.029935 362284.243680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 191 252</ms:GML_ID>
        <ms:NAZWA>405 191 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405191252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748330.801455 361588.303859</gml:lowerCorner>
        		<gml:upperCorner>748330.801455 361588.303859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748330.801455 361588.303859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 192 453</ms:GML_ID>
        <ms:NAZWA>405 192 453</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405192453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748403.698431 360920.976574</gml:lowerCorner>
        		<gml:upperCorner>748403.698431 360920.976574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748403.698431 360920.976574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 193 160</ms:GML_ID>
        <ms:NAZWA>405 193 160</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405193160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690987.911901 296119.728508</gml:lowerCorner>
        		<gml:upperCorner>690987.911901 296119.728508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690987.911901 296119.728508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 071 336</ms:GML_ID>
        <ms:NAZWA>404 071 336</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404071336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691009.990000 303797.622000</gml:lowerCorner>
        		<gml:upperCorner>691009.990000 303797.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691009.990000 303797.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 218 230</ms:GML_ID>
        <ms:NAZWA>202 218 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202218230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692018.933000 304500.690000</gml:lowerCorner>
        		<gml:upperCorner>692018.933000 304500.690000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692018.933000 304500.690000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 217 002</ms:GML_ID>
        <ms:NAZWA>202 217 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202217002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692642.275000 295740.030000</gml:lowerCorner>
        		<gml:upperCorner>692642.275000 295740.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692642.275000 295740.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 073 060</ms:GML_ID>
        <ms:NAZWA>404 073 060</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404073060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693047.134000 305217.517000</gml:lowerCorner>
        		<gml:upperCorner>693047.134000 305217.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693047.134000 305217.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 215 748</ms:GML_ID>
        <ms:NAZWA>202 215 748</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202215748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694050.433000 305916.839000</gml:lowerCorner>
        		<gml:upperCorner>694050.433000 305916.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694050.433000 305916.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 214 524</ms:GML_ID>
        <ms:NAZWA>202 214 524</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202214524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694125.530000 295753.786000</gml:lowerCorner>
        		<gml:upperCorner>694125.530000 295753.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694125.530000 295753.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 074 542</ms:GML_ID>
        <ms:NAZWA>404 074 542</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404074542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694868.061000 295607.779000</gml:lowerCorner>
        		<gml:upperCorner>694868.061000 295607.779000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694868.061000 295607.779000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 075 301</ms:GML_ID>
        <ms:NAZWA>404 075 301</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404075301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696938.820000 294542.252000</gml:lowerCorner>
        		<gml:upperCorner>696938.820000 294542.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696938.820000 294542.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 077 633</ms:GML_ID>
        <ms:NAZWA>404 077 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404077633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708974.742949 298418.575359</gml:lowerCorner>
        		<gml:upperCorner>708974.742949 298418.575359</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708974.742949 298418.575359</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 019 676</ms:GML_ID>
        <ms:NAZWA>402 019 676</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402019676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709047.437000 299547.027000</gml:lowerCorner>
        		<gml:upperCorner>709047.437000 299547.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709047.437000 299547.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 018 539</ms:GML_ID>
        <ms:NAZWA>402 018 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402018539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709078.209827 300469.176057</gml:lowerCorner>
        		<gml:upperCorner>709078.209827 300469.176057</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709078.209827 300469.176057</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 017 617</ms:GML_ID>
        <ms:NAZWA>402 017 617</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402017617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709145.603000 294826.227000</gml:lowerCorner>
        		<gml:upperCorner>709145.603000 294826.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709145.603000 294826.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 023 350</ms:GML_ID>
        <ms:NAZWA>402 023 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402023350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709155.618000 294609.402000</gml:lowerCorner>
        		<gml:upperCorner>709155.618000 294609.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709155.618000 294609.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 023 578</ms:GML_ID>
        <ms:NAZWA>402 023 578</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402023578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709157.397508 301372.281713</gml:lowerCorner>
        		<gml:upperCorner>709157.397508 301372.281713</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709157.397508 301372.281713</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 016 708</ms:GML_ID>
        <ms:NAZWA>402 016 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402016708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709287.650000 302228.608000</gml:lowerCorner>
        		<gml:upperCorner>709287.650000 302228.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709287.650000 302228.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 015 842</ms:GML_ID>
        <ms:NAZWA>402 015 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402015842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709385.263000 303506.271000</gml:lowerCorner>
        		<gml:upperCorner>709385.263000 303506.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709385.263000 303506.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 014 560</ms:GML_ID>
        <ms:NAZWA>402 014 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402014560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709394.373000 303795.340000</gml:lowerCorner>
        		<gml:upperCorner>709394.373000 303795.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709394.373000 303795.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 014 272</ms:GML_ID>
        <ms:NAZWA>402 014 272</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402014272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710226.297000 306080.459000</gml:lowerCorner>
        		<gml:upperCorner>710226.297000 306080.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710226.297000 306080.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 011 665</ms:GML_ID>
        <ms:NAZWA>402 011 665</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402011665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680139.362000 250326.421000</gml:lowerCorner>
        		<gml:upperCorner>680139.362000 250326.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680139.362000 250326.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 084 372</ms:GML_ID>
        <ms:NAZWA>402 084 372</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402084372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682200.615000 251232.849000</gml:lowerCorner>
        		<gml:upperCorner>682200.615000 251232.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682200.615000 251232.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 082 077</ms:GML_ID>
        <ms:NAZWA>402 082 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402082077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683976.661000 252367.398000</gml:lowerCorner>
        		<gml:upperCorner>683976.661000 252367.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683976.661000 252367.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 079 986</ms:GML_ID>
        <ms:NAZWA>402 079 986</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402079986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684852.011000 252963.921000</gml:lowerCorner>
        		<gml:upperCorner>684852.011000 252963.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684852.011000 252963.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 078 892</ms:GML_ID>
        <ms:NAZWA>402 078 892</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402078892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685787.210000 254604.277000</gml:lowerCorner>
        		<gml:upperCorner>685787.210000 254604.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685787.210000 254604.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 076 961</ms:GML_ID>
        <ms:NAZWA>402 076 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402076961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686256.806000 255167.592000</gml:lowerCorner>
        		<gml:upperCorner>686256.806000 255167.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686256.806000 255167.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 076 228</ms:GML_ID>
        <ms:NAZWA>402 076 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402076228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686741.727000 255749.399000</gml:lowerCorner>
        		<gml:upperCorner>686741.727000 255749.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686741.727000 255749.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 075 471</ms:GML_ID>
        <ms:NAZWA>402 075 471</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402075471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690909.910000 256518.786000</gml:lowerCorner>
        		<gml:upperCorner>690909.910000 256518.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690909.910000 256518.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 070 728</ms:GML_ID>
        <ms:NAZWA>402 070 728</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402070728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695045.764785 256526.277485</gml:lowerCorner>
        		<gml:upperCorner>695045.764785 256526.277485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695045.764785 256526.277485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 066 517</ms:GML_ID>
        <ms:NAZWA>402 066 517</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402066517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695318.553000 256835.176000</gml:lowerCorner>
        		<gml:upperCorner>695318.553000 256835.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695318.553000 256835.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 066 093</ms:GML_ID>
        <ms:NAZWA>402 066 093</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402066093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698465.053000 261538.550000</gml:lowerCorner>
        		<gml:upperCorner>698465.053000 261538.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698465.053000 261538.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 060 317</ms:GML_ID>
        <ms:NAZWA>402 060 317</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402060317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699858.167000 264607.555000</gml:lowerCorner>
        		<gml:upperCorner>699858.167000 264607.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699858.167000 264607.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 056 874</ms:GML_ID>
        <ms:NAZWA>402 056 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402056874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702136.902000 267456.694000</gml:lowerCorner>
        		<gml:upperCorner>702136.902000 267456.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702136.902000 267456.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 053 150</ms:GML_ID>
        <ms:NAZWA>402 053 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402053150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702806.510930 270287.242903</gml:lowerCorner>
        		<gml:upperCorner>702806.510930 270287.242903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702806.510930 270287.242903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 050 241</ms:GML_ID>
        <ms:NAZWA>402 050 241</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402050241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703611.392000 272148.031000</gml:lowerCorner>
        		<gml:upperCorner>703611.392000 272148.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703611.392000 272148.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 048 208</ms:GML_ID>
        <ms:NAZWA>402 048 208</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402048208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703901.518000 272539.941000</gml:lowerCorner>
        		<gml:upperCorner>703901.518000 272539.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703901.518000 272539.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 047 721</ms:GML_ID>
        <ms:NAZWA>402 047 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402047721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704156.560000 272885.030000</gml:lowerCorner>
        		<gml:upperCorner>704156.560000 272885.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704156.560000 272885.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 047 292</ms:GML_ID>
        <ms:NAZWA>402 047 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402047292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705232.780000 274341.374000</gml:lowerCorner>
        		<gml:upperCorner>705232.780000 274341.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705232.780000 274341.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 045 478</ms:GML_ID>
        <ms:NAZWA>402 045 478</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402045478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705237.778000 274348.152000</gml:lowerCorner>
        		<gml:upperCorner>705237.778000 274348.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705237.778000 274348.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 045 472</ms:GML_ID>
        <ms:NAZWA>402 045 472</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402045472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705629.572000 274811.435000</gml:lowerCorner>
        		<gml:upperCorner>705629.572000 274811.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705629.572000 274811.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 044 860</ms:GML_ID>
        <ms:NAZWA>402 044 860</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402044860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706472.346000 275349.846000</gml:lowerCorner>
        		<gml:upperCorner>706472.346000 275349.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706472.346000 275349.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 043 856</ms:GML_ID>
        <ms:NAZWA>402 043 856</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402043856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677700.485000 302197.598000</gml:lowerCorner>
        		<gml:upperCorner>677700.485000 302197.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677700.485000 302197.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 232 065</ms:GML_ID>
        <ms:NAZWA>202 232 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202232065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678566.384000 302054.119000</gml:lowerCorner>
        		<gml:upperCorner>678566.384000 302054.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678566.384000 302054.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 231 187</ms:GML_ID>
        <ms:NAZWA>202 231 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202231187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679150.659722 301954.426856</gml:lowerCorner>
        		<gml:upperCorner>679150.659722 301954.426856</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679150.659722 301954.426856</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 230 595</ms:GML_ID>
        <ms:NAZWA>202 230 595</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202230595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681215.163000 301616.097000</gml:lowerCorner>
        		<gml:upperCorner>681215.163000 301616.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681215.163000 301616.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 228 501</ms:GML_ID>
        <ms:NAZWA>202 228 501</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202228501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681904.361000 301504.322000</gml:lowerCorner>
        		<gml:upperCorner>681904.361000 301504.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681904.361000 301504.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 227 803</ms:GML_ID>
        <ms:NAZWA>202 227 803</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202227803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682812.632000 301535.468000</gml:lowerCorner>
        		<gml:upperCorner>682812.632000 301535.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682812.632000 301535.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 226 891</ms:GML_ID>
        <ms:NAZWA>202 226 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202226891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682980.512000 305888.926000</gml:lowerCorner>
        		<gml:upperCorner>682980.512000 305888.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682980.512000 305888.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 057 728</ms:GML_ID>
        <ms:NAZWA>404 057 728</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404057728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684457.784000 304159.261000</gml:lowerCorner>
        		<gml:upperCorner>684457.784000 304159.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684457.784000 304159.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 060 008</ms:GML_ID>
        <ms:NAZWA>404 060 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404060008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685503.219546 303026.379080</gml:lowerCorner>
        		<gml:upperCorner>685503.219546 303026.379080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685503.219546 303026.379080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 061 550</ms:GML_ID>
        <ms:NAZWA>404 061 550</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404061550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686012.877000 301880.607000</gml:lowerCorner>
        		<gml:upperCorner>686012.877000 301880.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686012.877000 301880.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 223 670</ms:GML_ID>
        <ms:NAZWA>202 223 670</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202223670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686227.103780 302229.722722</gml:lowerCorner>
        		<gml:upperCorner>686227.103780 302229.722722</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686227.103780 302229.722722</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 062 626</ms:GML_ID>
        <ms:NAZWA>404 062 626</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404062626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687717.055295 302139.432484</gml:lowerCorner>
        		<gml:upperCorner>687717.055295 302139.432484</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687717.055295 302139.432484</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 221 944</ms:GML_ID>
        <ms:NAZWA>202 221 944</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202221944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687759.628260 302110.265945</gml:lowerCorner>
        		<gml:upperCorner>687759.628260 302110.265945</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687759.628260 302110.265945</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 221 941</ms:GML_ID>
        <ms:NAZWA>202 221 941</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202221941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688610.656000 302483.049000</gml:lowerCorner>
        		<gml:upperCorner>688610.656000 302483.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688610.656000 302483.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 220 985</ms:GML_ID>
        <ms:NAZWA>202 220 985</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202220985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688632.536000 300898.989000</gml:lowerCorner>
        		<gml:upperCorner>688632.536000 300898.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688632.536000 300898.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 065 781</ms:GML_ID>
        <ms:NAZWA>404 065 781</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404065781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689056.137000 302654.353000</gml:lowerCorner>
        		<gml:upperCorner>689056.137000 302654.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689056.137000 302654.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 220 508</ms:GML_ID>
        <ms:NAZWA>202 220 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202220508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689208.962000 299113.597000</gml:lowerCorner>
        		<gml:upperCorner>689208.962000 299113.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689208.962000 299113.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 067 657</ms:GML_ID>
        <ms:NAZWA>404 067 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404067657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689701.252000 297590.733000</gml:lowerCorner>
        		<gml:upperCorner>689701.252000 297590.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689701.252000 297590.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 069 257</ms:GML_ID>
        <ms:NAZWA>404 069 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404069257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689954.034000 303061.790000</gml:lowerCorner>
        		<gml:upperCorner>689954.034000 303061.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689954.034000 303061.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 219 520</ms:GML_ID>
        <ms:NAZWA>202 219 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202219520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677065.670000 315866.467000</gml:lowerCorner>
        		<gml:upperCorner>677065.670000 315866.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677065.670000 315866.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 045 603</ms:GML_ID>
        <ms:NAZWA>404 045 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404045603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678097.983509 312590.949715</gml:lowerCorner>
        		<gml:upperCorner>678097.983509 312590.949715</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678097.983509 312590.949715</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 049 038</ms:GML_ID>
        <ms:NAZWA>404 049 038</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404049038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694984.873000 306567.827000</gml:lowerCorner>
        		<gml:upperCorner>694984.873000 306567.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694984.873000 306567.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 213 384</ms:GML_ID>
        <ms:NAZWA>202 213 384</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202213384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696295.158700 307489.450184</gml:lowerCorner>
        		<gml:upperCorner>696295.158700 307489.450184</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696295.158700 307489.450184</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 211 782</ms:GML_ID>
        <ms:NAZWA>202 211 782</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202211782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699255.958000 310078.274000</gml:lowerCorner>
        		<gml:upperCorner>699255.958000 310078.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699255.958000 310078.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 207 795</ms:GML_ID>
        <ms:NAZWA>202 207 795</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202207795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700441.095000 311789.071000</gml:lowerCorner>
        		<gml:upperCorner>700441.095000 311789.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700441.095000 311789.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 205 718</ms:GML_ID>
        <ms:NAZWA>202 205 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202205718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700638.014000 312065.211000</gml:lowerCorner>
        		<gml:upperCorner>700638.014000 312065.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700638.014000 312065.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 205 379</ms:GML_ID>
        <ms:NAZWA>202 205 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202205379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702615.496000 313870.267000</gml:lowerCorner>
        		<gml:upperCorner>702615.496000 313870.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702615.496000 313870.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 202 698</ms:GML_ID>
        <ms:NAZWA>202 202 698</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202202698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705134.805000 315068.100000</gml:lowerCorner>
        		<gml:upperCorner>705134.805000 315068.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705134.805000 315068.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 199 843</ms:GML_ID>
        <ms:NAZWA>202 199 843</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202199843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705725.444178 314227.426799</gml:lowerCorner>
        		<gml:upperCorner>705725.444178 314227.426799</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705725.444178 314227.426799</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 001 681</ms:GML_ID>
        <ms:NAZWA>402 001 681</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402001681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706105.918296 315248.773212</gml:lowerCorner>
        		<gml:upperCorner>706105.918296 315248.773212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706105.918296 315248.773212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 000 555</ms:GML_ID>
        <ms:NAZWA>402 000 555</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402000555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706118.436000 313012.751000</gml:lowerCorner>
        		<gml:upperCorner>706118.436000 313012.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706118.436000 313012.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 003 043</ms:GML_ID>
        <ms:NAZWA>402 003 043</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402003043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707607.376000 315520.755000</gml:lowerCorner>
        		<gml:upperCorner>707607.376000 315520.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707607.376000 315520.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 197 319</ms:GML_ID>
        <ms:NAZWA>202 197 319</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202197319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708444.709000 311025.279000</gml:lowerCorner>
        		<gml:upperCorner>708444.709000 311025.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708444.709000 311025.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 006 311</ms:GML_ID>
        <ms:NAZWA>402 006 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402006311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709346.243000 309804.187000</gml:lowerCorner>
        		<gml:upperCorner>709346.243000 309804.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709346.243000 309804.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 007 827</ms:GML_ID>
        <ms:NAZWA>402 007 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402007827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709478.109163 309336.226727</gml:lowerCorner>
        		<gml:upperCorner>709478.109163 309336.226727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709478.109163 309336.226727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 008 319</ms:GML_ID>
        <ms:NAZWA>402 008 319</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402008319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710143.996000 306460.503000</gml:lowerCorner>
        		<gml:upperCorner>710143.996000 306460.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710143.996000 306460.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 011 295</ms:GML_ID>
        <ms:NAZWA>402 011 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402011295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>714998.038000 325912.710000</gml:lowerCorner>
        		<gml:upperCorner>714998.038000 325912.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>714998.038000 325912.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 183 956</ms:GML_ID>
        <ms:NAZWA>202 183 956</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202183956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716790.390000 327804.170000</gml:lowerCorner>
        		<gml:upperCorner>716790.390000 327804.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716790.390000 327804.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 181 264</ms:GML_ID>
        <ms:NAZWA>202 181 264</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202181264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718564.027773 329983.750891</gml:lowerCorner>
        		<gml:upperCorner>718564.027773 329983.750891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718564.027773 329983.750891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 178 378</ms:GML_ID>
        <ms:NAZWA>202 178 378</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202178378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720367.888000 331508.379000</gml:lowerCorner>
        		<gml:upperCorner>720367.888000 331508.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720367.888000 331508.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 176 014</ms:GML_ID>
        <ms:NAZWA>202 176 014</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202176014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729066.942000 336966.341000</gml:lowerCorner>
        		<gml:upperCorner>729066.942000 336966.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729066.942000 336966.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 028 678</ms:GML_ID>
        <ms:NAZWA>418 028 678</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418028678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729973.289000 333784.776000</gml:lowerCorner>
        		<gml:upperCorner>729973.289000 333784.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729973.289000 333784.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 031 983</ms:GML_ID>
        <ms:NAZWA>418 031 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418031983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730659.665000 332004.648000</gml:lowerCorner>
        		<gml:upperCorner>730659.665000 332004.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730659.665000 332004.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 033 919</ms:GML_ID>
        <ms:NAZWA>418 033 919</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418033919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730923.314000 331814.848000</gml:lowerCorner>
        		<gml:upperCorner>730923.314000 331814.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730923.314000 331814.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 034 244</ms:GML_ID>
        <ms:NAZWA>418 034 244</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418034244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731697.833224 331288.583079</gml:lowerCorner>
        		<gml:upperCorner>731697.833224 331288.583079</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731697.833224 331288.583079</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.418 035 110</ms:GML_ID>
        <ms:NAZWA>418 035 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>418035110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653023.877000 244520.287000</gml:lowerCorner>
        		<gml:upperCorner>653023.877000 244520.287000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653023.877000 244520.287000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 116 528</ms:GML_ID>
        <ms:NAZWA>402 116 528</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402116528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655591.315000 247363.941000</gml:lowerCorner>
        		<gml:upperCorner>655591.315000 247363.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655591.315000 247363.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 112 690</ms:GML_ID>
        <ms:NAZWA>402 112 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402112690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657092.226000 248779.739000</gml:lowerCorner>
        		<gml:upperCorner>657092.226000 248779.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657092.226000 248779.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 110 623</ms:GML_ID>
        <ms:NAZWA>402 110 623</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402110623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657915.402000 249203.048000</gml:lowerCorner>
        		<gml:upperCorner>657915.402000 249203.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657915.402000 249203.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 109 692</ms:GML_ID>
        <ms:NAZWA>402 109 692</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402109692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660115.052000 250283.925000</gml:lowerCorner>
        		<gml:upperCorner>660115.052000 250283.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660115.052000 250283.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 107 238</ms:GML_ID>
        <ms:NAZWA>402 107 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402107238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661104.020000 250641.300000</gml:lowerCorner>
        		<gml:upperCorner>661104.020000 250641.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661104.020000 250641.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 106 187</ms:GML_ID>
        <ms:NAZWA>402 106 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402106187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665939.592000 253625.082000</gml:lowerCorner>
        		<gml:upperCorner>665939.592000 253625.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665939.592000 253625.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 100 403</ms:GML_ID>
        <ms:NAZWA>402 100 403</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402100403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666368.303000 254040.563000</gml:lowerCorner>
        		<gml:upperCorner>666368.303000 254040.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666368.303000 254040.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 099 791</ms:GML_ID>
        <ms:NAZWA>402 099 791</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402099791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667236.040000 251070.175000</gml:lowerCorner>
        		<gml:upperCorner>667236.040000 251070.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667236.040000 251070.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 033 709</ms:GML_ID>
        <ms:NAZWA>420 033 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420033709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667303.655000 250660.655000</gml:lowerCorner>
        		<gml:upperCorner>667303.655000 250660.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667303.655000 250660.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 034 125</ms:GML_ID>
        <ms:NAZWA>420 034 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420034125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667372.064000 250246.121000</gml:lowerCorner>
        		<gml:upperCorner>667372.064000 250246.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667372.064000 250246.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 034 544</ms:GML_ID>
        <ms:NAZWA>420 034 544</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420034544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667526.205000 253352.291000</gml:lowerCorner>
        		<gml:upperCorner>667526.205000 253352.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667526.205000 253352.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 098 371</ms:GML_ID>
        <ms:NAZWA>402 098 371</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402098371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667762.851000 244324.866000</gml:lowerCorner>
        		<gml:upperCorner>667762.851000 244324.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667762.851000 244324.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 040 636</ms:GML_ID>
        <ms:NAZWA>420 040 636</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420040636</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667915.319000 245268.785000</gml:lowerCorner>
        		<gml:upperCorner>667915.319000 245268.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667915.319000 245268.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 039 666</ms:GML_ID>
        <ms:NAZWA>420 039 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420039666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668009.879000 247934.703000</gml:lowerCorner>
        		<gml:upperCorner>668009.879000 247934.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668009.879000 247934.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 036 944</ms:GML_ID>
        <ms:NAZWA>420 036 944</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420036944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668139.620000 247372.271000</gml:lowerCorner>
        		<gml:upperCorner>668139.620000 247372.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668139.620000 247372.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 037 522</ms:GML_ID>
        <ms:NAZWA>420 037 522</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420037522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670593.787000 251253.502000</gml:lowerCorner>
        		<gml:upperCorner>670593.787000 251253.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670593.787000 251253.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 094 657</ms:GML_ID>
        <ms:NAZWA>402 094 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402094657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672113.898000 250151.097000</gml:lowerCorner>
        		<gml:upperCorner>672113.898000 250151.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672113.898000 250151.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 092 779</ms:GML_ID>
        <ms:NAZWA>402 092 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402092779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673087.327000 249731.830000</gml:lowerCorner>
        		<gml:upperCorner>673087.327000 249731.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673087.327000 249731.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 091 693</ms:GML_ID>
        <ms:NAZWA>402 091 693</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402091693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675041.312000 249536.295000</gml:lowerCorner>
        		<gml:upperCorner>675041.312000 249536.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675041.312000 249536.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 089 726</ms:GML_ID>
        <ms:NAZWA>402 089 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402089726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677277.643000 249321.580000</gml:lowerCorner>
        		<gml:upperCorner>677277.643000 249321.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677277.643000 249321.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 087 481</ms:GML_ID>
        <ms:NAZWA>402 087 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402087481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678165.893000 249434.354000</gml:lowerCorner>
        		<gml:upperCorner>678165.893000 249434.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678165.893000 249434.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 086 585</ms:GML_ID>
        <ms:NAZWA>402 086 585</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402086585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678572.438058 249752.000318</gml:lowerCorner>
        		<gml:upperCorner>678572.438058 249752.000318</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678572.438058 249752.000318</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 086 058</ms:GML_ID>
        <ms:NAZWA>402 086 058</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402086058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679078.216650 250040.012176</gml:lowerCorner>
        		<gml:upperCorner>679078.216650 250040.012176</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679078.216650 250040.012176</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 085 473</ms:GML_ID>
        <ms:NAZWA>402 085 473</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402085473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679529.075000 250192.994000</gml:lowerCorner>
        		<gml:upperCorner>679529.075000 250192.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679529.075000 250192.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 084 996</ms:GML_ID>
        <ms:NAZWA>402 084 996</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402084996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647914.934000 278039.623000</gml:lowerCorner>
        		<gml:upperCorner>647914.934000 278039.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647914.934000 278039.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 275 100</ms:GML_ID>
        <ms:NAZWA>202 275 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202275100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650680.941000 279347.104000</gml:lowerCorner>
        		<gml:upperCorner>650680.941000 279347.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650680.941000 279347.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 271 966</ms:GML_ID>
        <ms:NAZWA>202 271 966</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202271966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652489.874083 277816.386351</gml:lowerCorner>
        		<gml:upperCorner>652489.874083 277816.386351</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652489.874083 277816.386351</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 269 541</ms:GML_ID>
        <ms:NAZWA>202 269 541</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202269541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656573.143000 280866.958000</gml:lowerCorner>
        		<gml:upperCorner>656573.143000 280866.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656573.143000 280866.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 264 019</ms:GML_ID>
        <ms:NAZWA>202 264 019</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202264019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658976.006000 284488.385000</gml:lowerCorner>
        		<gml:upperCorner>658976.006000 284488.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658976.006000 284488.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 259 633</ms:GML_ID>
        <ms:NAZWA>202 259 633</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202259633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659984.825000 285898.419000</gml:lowerCorner>
        		<gml:upperCorner>659984.825000 285898.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659984.825000 285898.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 257 896</ms:GML_ID>
        <ms:NAZWA>202 257 896</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202257896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661236.174000 286981.980000</gml:lowerCorner>
        		<gml:upperCorner>661236.174000 286981.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661236.174000 286981.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 256 195</ms:GML_ID>
        <ms:NAZWA>202 256 195</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202256195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661396.103000 292415.457000</gml:lowerCorner>
        		<gml:upperCorner>661396.103000 292415.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661396.103000 292415.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.421 018 421</ms:GML_ID>
        <ms:NAZWA>421 018 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>421018421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661797.734169 287231.528183</gml:lowerCorner>
        		<gml:upperCorner>661797.734169 287231.528183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661797.734169 287231.528183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 255 583</ms:GML_ID>
        <ms:NAZWA>202 255 583</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202255583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661801.148000 291757.819000</gml:lowerCorner>
        		<gml:upperCorner>661801.148000 291757.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661801.148000 291757.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.421 019 193</ms:GML_ID>
        <ms:NAZWA>421 019 193</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>421019193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661898.661000 291599.316000</gml:lowerCorner>
        		<gml:upperCorner>661898.661000 291599.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661898.661000 291599.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.421 019 379</ms:GML_ID>
        <ms:NAZWA>421 019 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>421019379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662507.882099 287549.698053</gml:lowerCorner>
        		<gml:upperCorner>662507.882099 287549.698053</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662507.882099 287549.698053</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 254 798</ms:GML_ID>
        <ms:NAZWA>202 254 798</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202254798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663053.601000 287939.701000</gml:lowerCorner>
        		<gml:upperCorner>663053.601000 287939.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663053.601000 287939.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.421 023 463</ms:GML_ID>
        <ms:NAZWA>421 023 463</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>421023463</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663525.413000 288039.817000</gml:lowerCorner>
        		<gml:upperCorner>663525.413000 288039.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663525.413000 288039.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 253 669</ms:GML_ID>
        <ms:NAZWA>202 253 669</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202253669</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665131.805000 289062.806000</gml:lowerCorner>
        		<gml:upperCorner>665131.805000 289062.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665131.805000 289062.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 251 731</ms:GML_ID>
        <ms:NAZWA>202 251 731</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202251731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665412.316000 289917.169000</gml:lowerCorner>
        		<gml:upperCorner>665412.316000 289917.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665412.316000 289917.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 250 826</ms:GML_ID>
        <ms:NAZWA>202 250 826</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202250826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665643.304000 290880.210000</gml:lowerCorner>
        		<gml:upperCorner>665643.304000 290880.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665643.304000 290880.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 249 836</ms:GML_ID>
        <ms:NAZWA>202 249 836</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202249836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667467.845000 294406.325000</gml:lowerCorner>
        		<gml:upperCorner>667467.845000 294406.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667467.845000 294406.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 245 852</ms:GML_ID>
        <ms:NAZWA>202 245 852</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202245852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671405.032475 299595.233838</gml:lowerCorner>
        		<gml:upperCorner>671405.032475 299595.233838</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671405.032475 299595.233838</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 239 254</ms:GML_ID>
        <ms:NAZWA>202 239 254</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202239254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646797.416473 224962.491599</gml:lowerCorner>
        		<gml:upperCorner>646797.416473 224962.491599</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646797.416473 224962.491599</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 029 084</ms:GML_ID>
        <ms:NAZWA>401 029 084</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401029084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647474.221000 239999.202000</gml:lowerCorner>
        		<gml:upperCorner>647474.221000 239999.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647474.221000 239999.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 123 948</ms:GML_ID>
        <ms:NAZWA>402 123 948</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402123948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647968.838000 240660.880000</gml:lowerCorner>
        		<gml:upperCorner>647968.838000 240660.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647968.838000 240660.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 123 122</ms:GML_ID>
        <ms:NAZWA>402 123 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402123122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651481.420036 243661.709589</gml:lowerCorner>
        		<gml:upperCorner>651481.420036 243661.709589</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651481.420036 243661.709589</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 118 449</ms:GML_ID>
        <ms:NAZWA>402 118 449</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402118449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651703.581243 244102.065863</gml:lowerCorner>
        		<gml:upperCorner>651703.581243 244102.065863</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651703.581243 244102.065863</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 117 955</ms:GML_ID>
        <ms:NAZWA>402 117 955</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402117955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651984.655000 244294.926000</gml:lowerCorner>
        		<gml:upperCorner>651984.655000 244294.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651984.655000 244294.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 117 597</ms:GML_ID>
        <ms:NAZWA>402 117 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402117597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653511.568000 226720.752000</gml:lowerCorner>
        		<gml:upperCorner>653511.568000 226720.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653511.568000 226720.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 036 029</ms:GML_ID>
        <ms:NAZWA>401 036 029</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401036029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655342.724000 227216.244000</gml:lowerCorner>
        		<gml:upperCorner>655342.724000 227216.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655342.724000 227216.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 037 923</ms:GML_ID>
        <ms:NAZWA>401 037 923</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401037923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663884.257527 226881.457081</gml:lowerCorner>
        		<gml:upperCorner>663884.257527 226881.457081</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663884.257527 226881.457081</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 046 523</ms:GML_ID>
        <ms:NAZWA>401 046 523</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401046523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668350.018000 242163.828000</gml:lowerCorner>
        		<gml:upperCorner>668350.018000 242163.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668350.018000 242163.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 042 913</ms:GML_ID>
        <ms:NAZWA>420 042 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420042913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669164.825000 240643.419000</gml:lowerCorner>
        		<gml:upperCorner>669164.825000 240643.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669164.825000 240643.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 044 682</ms:GML_ID>
        <ms:NAZWA>420 044 682</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420044682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669218.968000 240313.325000</gml:lowerCorner>
        		<gml:upperCorner>669218.968000 240313.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669218.968000 240313.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 045 016</ms:GML_ID>
        <ms:NAZWA>420 045 016</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420045016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669316.222000 239720.126000</gml:lowerCorner>
        		<gml:upperCorner>669316.222000 239720.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669316.222000 239720.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 045 616</ms:GML_ID>
        <ms:NAZWA>420 045 616</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420045616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669691.763000 237922.177000</gml:lowerCorner>
        		<gml:upperCorner>669691.763000 237922.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669691.763000 237922.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 047 762</ms:GML_ID>
        <ms:NAZWA>420 047 762</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420047762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669792.081000 229506.077000</gml:lowerCorner>
        		<gml:upperCorner>669792.081000 229506.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669792.081000 229506.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 056 025</ms:GML_ID>
        <ms:NAZWA>420 056 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420056025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669885.287000 230136.711000</gml:lowerCorner>
        		<gml:upperCorner>669885.287000 230136.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669885.287000 230136.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 055 394</ms:GML_ID>
        <ms:NAZWA>420 055 394</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420055394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670192.631000 232204.592000</gml:lowerCorner>
        		<gml:upperCorner>670192.631000 232204.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670192.631000 232204.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 053 304</ms:GML_ID>
        <ms:NAZWA>420 053 304</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420053304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670244.303000 235301.455000</gml:lowerCorner>
        		<gml:upperCorner>670244.303000 235301.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670244.303000 235301.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 050 145</ms:GML_ID>
        <ms:NAZWA>420 050 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420050145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670245.056414 225819.134180</gml:lowerCorner>
        		<gml:upperCorner>670245.056414 225819.134180</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670245.056414 225819.134180</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 053 056</ms:GML_ID>
        <ms:NAZWA>401 053 056</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401053056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670426.933000 234722.309000</gml:lowerCorner>
        		<gml:upperCorner>670426.933000 234722.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670426.933000 234722.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.420 050 753</ms:GML_ID>
        <ms:NAZWA>420 050 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>420050753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671809.998000 225817.074000</gml:lowerCorner>
        		<gml:upperCorner>671809.998000 225817.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671809.998000 225817.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 001 454</ms:GML_ID>
        <ms:NAZWA>407 001 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407001454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675071.743000 225798.752000</gml:lowerCorner>
        		<gml:upperCorner>675071.743000 225798.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675071.743000 225798.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 004 713</ms:GML_ID>
        <ms:NAZWA>407 004 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407004713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675636.408000 225795.417000</gml:lowerCorner>
        		<gml:upperCorner>675636.408000 225795.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675636.408000 225795.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 005 281</ms:GML_ID>
        <ms:NAZWA>407 005 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407005281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677541.747000 225784.544000</gml:lowerCorner>
        		<gml:upperCorner>677541.747000 225784.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677541.747000 225784.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 007 181</ms:GML_ID>
        <ms:NAZWA>407 007 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407007181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678412.728000 225779.983000</gml:lowerCorner>
        		<gml:upperCorner>678412.728000 225779.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678412.728000 225779.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 008 051</ms:GML_ID>
        <ms:NAZWA>407 008 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407008051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678942.302000 225769.512000</gml:lowerCorner>
        		<gml:upperCorner>678942.302000 225769.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678942.302000 225769.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 008 597</ms:GML_ID>
        <ms:NAZWA>407 008 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407008597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645583.529000 204698.782000</gml:lowerCorner>
        		<gml:upperCorner>645583.529000 204698.782000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645583.529000 204698.782000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 028 645</ms:GML_ID>
        <ms:NAZWA>406 028 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406028645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645978.554641 204314.341354</gml:lowerCorner>
        		<gml:upperCorner>645978.554641 204314.341354</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645978.554641 204314.341354</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 029 192</ms:GML_ID>
        <ms:NAZWA>406 029 192</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406029192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647089.997000 203717.078000</gml:lowerCorner>
        		<gml:upperCorner>647089.997000 203717.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647089.997000 203717.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 030 492</ms:GML_ID>
        <ms:NAZWA>406 030 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406030492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647693.200000 203332.572000</gml:lowerCorner>
        		<gml:upperCorner>647693.200000 203332.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647693.200000 203332.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 031 170</ms:GML_ID>
        <ms:NAZWA>406 031 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406031170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648161.891000 203034.887000</gml:lowerCorner>
        		<gml:upperCorner>648161.891000 203034.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648161.891000 203034.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 031 785</ms:GML_ID>
        <ms:NAZWA>406 031 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406031785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648391.754704 202899.592274</gml:lowerCorner>
        		<gml:upperCorner>648391.754704 202899.592274</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648391.754704 202899.592274</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 032 023</ms:GML_ID>
        <ms:NAZWA>406 032 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406032023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648892.609000 202826.918000</gml:lowerCorner>
        		<gml:upperCorner>648892.609000 202826.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648892.609000 202826.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 032 507</ms:GML_ID>
        <ms:NAZWA>406 032 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406032507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649495.148000 202932.865000</gml:lowerCorner>
        		<gml:upperCorner>649495.148000 202932.865000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649495.148000 202932.865000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 033 119</ms:GML_ID>
        <ms:NAZWA>406 033 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406033119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652280.508000 203433.355000</gml:lowerCorner>
        		<gml:upperCorner>652280.508000 203433.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652280.508000 203433.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 035 989</ms:GML_ID>
        <ms:NAZWA>406 035 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406035989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652670.723374 202517.910610</gml:lowerCorner>
        		<gml:upperCorner>652670.723374 202517.910610</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652670.723374 202517.910610</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 037 006</ms:GML_ID>
        <ms:NAZWA>406 037 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406037006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672900.452000 218397.642000</gml:lowerCorner>
        		<gml:upperCorner>672900.452000 218397.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672900.452000 218397.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 061 537</ms:GML_ID>
        <ms:NAZWA>401 061 537</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401061537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673142.485000 217094.525000</gml:lowerCorner>
        		<gml:upperCorner>673142.485000 217094.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673142.485000 217094.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 062 861</ms:GML_ID>
        <ms:NAZWA>401 062 861</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401062861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677970.772000 209124.421000</gml:lowerCorner>
        		<gml:upperCorner>677970.772000 209124.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677970.772000 209124.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 073 608</ms:GML_ID>
        <ms:NAZWA>401 073 608</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401073608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680476.704000 208805.023000</gml:lowerCorner>
        		<gml:upperCorner>680476.704000 208805.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680476.704000 208805.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 076 260</ms:GML_ID>
        <ms:NAZWA>401 076 260</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401076260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680768.653165 191475.293203</gml:lowerCorner>
        		<gml:upperCorner>680768.653165 191475.293203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680768.653165 191475.293203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 096 773</ms:GML_ID>
        <ms:NAZWA>401 096 773</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401096773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680959.947645 190363.863901</gml:lowerCorner>
        		<gml:upperCorner>680959.947645 190363.863901</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680959.947645 190363.863901</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 097 918</ms:GML_ID>
        <ms:NAZWA>401 097 918</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401097918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681182.723000 224788.618000</gml:lowerCorner>
        		<gml:upperCorner>681182.723000 224788.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681182.723000 224788.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 011 030</ms:GML_ID>
        <ms:NAZWA>407 011 030</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407011030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681222.888138 190019.937361</gml:lowerCorner>
        		<gml:upperCorner>681222.888138 190019.937361</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681222.888138 190019.937361</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 098 362</ms:GML_ID>
        <ms:NAZWA>401 098 362</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401098362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681446.732805 189877.925797</gml:lowerCorner>
        		<gml:upperCorner>681446.732805 189877.925797</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681446.732805 189877.925797</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 098 623</ms:GML_ID>
        <ms:NAZWA>401 098 623</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401098623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681650.471217 189403.768623</gml:lowerCorner>
        		<gml:upperCorner>681650.471217 189403.768623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681650.471217 189403.768623</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 099 169</ms:GML_ID>
        <ms:NAZWA>401 099 169</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401099169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682044.246000 224397.153000</gml:lowerCorner>
        		<gml:upperCorner>682044.246000 224397.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682044.246000 224397.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 011 977</ms:GML_ID>
        <ms:NAZWA>407 011 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407011977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682047.612741 199239.169477</gml:lowerCorner>
        		<gml:upperCorner>682047.612741 199239.169477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682047.612741 199239.169477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 088 508</ms:GML_ID>
        <ms:NAZWA>401 088 508</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401088508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683000.740576 207173.522111</gml:lowerCorner>
        		<gml:upperCorner>683000.740576 207173.522111</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683000.740576 207173.522111</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 079 473</ms:GML_ID>
        <ms:NAZWA>401 079 473</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401079473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684961.324247 223040.695256</gml:lowerCorner>
        		<gml:upperCorner>684961.324247 223040.695256</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684961.324247 223040.695256</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 015 196</ms:GML_ID>
        <ms:NAZWA>407 015 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407015196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685602.038000 222769.975000</gml:lowerCorner>
        		<gml:upperCorner>685602.038000 222769.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685602.038000 222769.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 015 892</ms:GML_ID>
        <ms:NAZWA>407 015 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407015892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686152.372247 222787.208459</gml:lowerCorner>
        		<gml:upperCorner>686152.372247 222787.208459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686152.372247 222787.208459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.407 016 494</ms:GML_ID>
        <ms:NAZWA>407 016 494</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>407016494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642376.027000 351176.710000</gml:lowerCorner>
        		<gml:upperCorner>642376.027000 351176.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642376.027000 351176.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 061 744</ms:GML_ID>
        <ms:NAZWA>405 061 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405061744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644931.808159 349498.677423</gml:lowerCorner>
        		<gml:upperCorner>644931.808159 349498.677423</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644931.808159 349498.677423</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 064 806</ms:GML_ID>
        <ms:NAZWA>405 064 806</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405064806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647420.371414 345413.165694</gml:lowerCorner>
        		<gml:upperCorner>647420.371414 345413.165694</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647420.371414 345413.165694</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 065 290</ms:GML_ID>
        <ms:NAZWA>210 065 290</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210065290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648792.932000 360495.316000</gml:lowerCorner>
        		<gml:upperCorner>648792.932000 360495.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648792.932000 360495.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 048 632</ms:GML_ID>
        <ms:NAZWA>210 048 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210048632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650085.788000 355461.065000</gml:lowerCorner>
        		<gml:upperCorner>650085.788000 355461.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650085.788000 355461.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 053 834</ms:GML_ID>
        <ms:NAZWA>210 053 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210053834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650654.640000 352605.603000</gml:lowerCorner>
        		<gml:upperCorner>650654.640000 352605.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650654.640000 352605.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 056 751</ms:GML_ID>
        <ms:NAZWA>210 056 751</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210056751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650902.882000 350661.030000</gml:lowerCorner>
        		<gml:upperCorner>650902.882000 350661.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650902.882000 350661.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 058 712</ms:GML_ID>
        <ms:NAZWA>210 058 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210058712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651026.775000 349523.557000</gml:lowerCorner>
        		<gml:upperCorner>651026.775000 349523.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651026.775000 349523.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 072 100</ms:GML_ID>
        <ms:NAZWA>405 072 100</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405072100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651084.513845 349402.445924</gml:lowerCorner>
        		<gml:upperCorner>651084.513845 349402.445924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651084.513845 349402.445924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 001 361</ms:GML_ID>
        <ms:NAZWA>404 001 361</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404001361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651790.743000 351052.600000</gml:lowerCorner>
        		<gml:upperCorner>651790.743000 351052.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651790.743000 351052.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 073 857</ms:GML_ID>
        <ms:NAZWA>405 073 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405073857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652854.940000 354207.043000</gml:lowerCorner>
        		<gml:upperCorner>652854.940000 354207.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652854.940000 354207.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 077 276</ms:GML_ID>
        <ms:NAZWA>405 077 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405077276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653294.521000 355362.381000</gml:lowerCorner>
        		<gml:upperCorner>653294.521000 355362.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653294.521000 355362.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 078 536</ms:GML_ID>
        <ms:NAZWA>405 078 536</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405078536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653976.247000 356537.693000</gml:lowerCorner>
        		<gml:upperCorner>653976.247000 356537.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653976.247000 356537.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 079 894</ms:GML_ID>
        <ms:NAZWA>405 079 894</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405079894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654787.159000 345242.614000</gml:lowerCorner>
        		<gml:upperCorner>654787.159000 345242.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654787.159000 345242.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 007 268</ms:GML_ID>
        <ms:NAZWA>404 007 268</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404007268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655175.457000 357882.119000</gml:lowerCorner>
        		<gml:upperCorner>655175.457000 357882.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655175.457000 357882.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 081 718</ms:GML_ID>
        <ms:NAZWA>405 081 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405081718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655525.625000 344196.175000</gml:lowerCorner>
        		<gml:upperCorner>655525.625000 344196.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655525.625000 344196.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 008 549</ms:GML_ID>
        <ms:NAZWA>404 008 549</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404008549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659852.696000 358974.691000</gml:lowerCorner>
        		<gml:upperCorner>659852.696000 358974.691000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659852.696000 358974.691000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 086 535</ms:GML_ID>
        <ms:NAZWA>405 086 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405086535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662842.289000 359617.412000</gml:lowerCorner>
        		<gml:upperCorner>662842.289000 359617.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662842.289000 359617.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 089 596</ms:GML_ID>
        <ms:NAZWA>405 089 596</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405089596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667362.401000 360060.123000</gml:lowerCorner>
        		<gml:upperCorner>667362.401000 360060.123000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667362.401000 360060.123000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 094 231</ms:GML_ID>
        <ms:NAZWA>405 094 231</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405094231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671014.999452 359054.831878</gml:lowerCorner>
        		<gml:upperCorner>671014.999452 359054.831878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671014.999452 359054.831878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 098 067</ms:GML_ID>
        <ms:NAZWA>405 098 067</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405098067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672066.847000 359327.252000</gml:lowerCorner>
        		<gml:upperCorner>672066.847000 359327.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672066.847000 359327.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 099 169</ms:GML_ID>
        <ms:NAZWA>405 099 169</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405099169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673858.151000 363130.964000</gml:lowerCorner>
        		<gml:upperCorner>673858.151000 363130.964000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673858.151000 363130.964000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 103 385</ms:GML_ID>
        <ms:NAZWA>405 103 385</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405103385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641968.729534 331194.127399</gml:lowerCorner>
        		<gml:upperCorner>641968.729534 331194.127399</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641968.729534 331194.127399</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 081 557</ms:GML_ID>
        <ms:NAZWA>210 081 557</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210081557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642848.167000 332015.934000</gml:lowerCorner>
        		<gml:upperCorner>642848.167000 332015.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642848.167000 332015.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 080 283</ms:GML_ID>
        <ms:NAZWA>210 080 283</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210080283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643347.926000 333321.580000</gml:lowerCorner>
        		<gml:upperCorner>643347.926000 333321.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643347.926000 333321.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 078 880</ms:GML_ID>
        <ms:NAZWA>210 078 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210078880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643878.758000 334000.696000</gml:lowerCorner>
        		<gml:upperCorner>643878.758000 334000.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643878.758000 334000.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 078 017</ms:GML_ID>
        <ms:NAZWA>210 078 017</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210078017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644907.763000 335700.803000</gml:lowerCorner>
        		<gml:upperCorner>644907.763000 335700.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644907.763000 335700.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 076 021</ms:GML_ID>
        <ms:NAZWA>210 076 021</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210076021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646095.707000 341957.061000</gml:lowerCorner>
        		<gml:upperCorner>646095.707000 341957.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646095.707000 341957.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 069 005</ms:GML_ID>
        <ms:NAZWA>210 069 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210069005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646238.118000 339887.276000</gml:lowerCorner>
        		<gml:upperCorner>646238.118000 339887.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646238.118000 339887.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 071 159</ms:GML_ID>
        <ms:NAZWA>210 071 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210071159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646245.949000 342443.549000</gml:lowerCorner>
        		<gml:upperCorner>646245.949000 342443.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646245.949000 342443.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 068 496</ms:GML_ID>
        <ms:NAZWA>210 068 496</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210068496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646479.509000 343201.462000</gml:lowerCorner>
        		<gml:upperCorner>646479.509000 343201.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646479.509000 343201.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 067 702</ms:GML_ID>
        <ms:NAZWA>210 067 702</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210067702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655840.100000 343566.975000</gml:lowerCorner>
        		<gml:upperCorner>655840.100000 343566.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655840.100000 343566.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 009 253</ms:GML_ID>
        <ms:NAZWA>404 009 253</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404009253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656182.050000 342731.251000</gml:lowerCorner>
        		<gml:upperCorner>656182.050000 342731.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656182.050000 342731.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 010 156</ms:GML_ID>
        <ms:NAZWA>404 010 156</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404010156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659961.017000 337201.713000</gml:lowerCorner>
        		<gml:upperCorner>659961.017000 337201.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659961.017000 337201.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 017 052</ms:GML_ID>
        <ms:NAZWA>404 017 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404017052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661693.637643 336466.157555</gml:lowerCorner>
        		<gml:upperCorner>661693.637643 336466.157555</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661693.637643 336466.157555</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 018 938</ms:GML_ID>
        <ms:NAZWA>404 018 938</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404018938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664749.057000 334040.528000</gml:lowerCorner>
        		<gml:upperCorner>664749.057000 334040.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664749.057000 334040.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 022 880</ms:GML_ID>
        <ms:NAZWA>404 022 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404022880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665969.961000 331498.619000</gml:lowerCorner>
        		<gml:upperCorner>665969.961000 331498.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665969.961000 331498.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 025 729</ms:GML_ID>
        <ms:NAZWA>404 025 729</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404025729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666456.579677 329677.060848</gml:lowerCorner>
        		<gml:upperCorner>666456.579677 329677.060848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666456.579677 329677.060848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 027 666</ms:GML_ID>
        <ms:NAZWA>404 027 666</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404027666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667781.735000 327946.383000</gml:lowerCorner>
        		<gml:upperCorner>667781.735000 327946.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667781.735000 327946.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 029 856</ms:GML_ID>
        <ms:NAZWA>404 029 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404029856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669027.250000 326468.550000</gml:lowerCorner>
        		<gml:upperCorner>669027.250000 326468.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669027.250000 326468.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 031 789</ms:GML_ID>
        <ms:NAZWA>404 031 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404031789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670709.903000 324517.564000</gml:lowerCorner>
        		<gml:upperCorner>670709.903000 324517.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670709.903000 324517.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 034 364</ms:GML_ID>
        <ms:NAZWA>404 034 364</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404034364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672686.732000 322983.541000</gml:lowerCorner>
        		<gml:upperCorner>672686.732000 322983.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672686.732000 322983.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 036 870</ms:GML_ID>
        <ms:NAZWA>404 036 870</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404036870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676076.275000 319559.540000</gml:lowerCorner>
        		<gml:upperCorner>676076.275000 319559.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676076.275000 319559.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 041 713</ms:GML_ID>
        <ms:NAZWA>404 041 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404041713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676464.291000 318974.271000</gml:lowerCorner>
        		<gml:upperCorner>676464.291000 318974.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676464.291000 318974.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.404 042 425</ms:GML_ID>
        <ms:NAZWA>404 042 425</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>404042425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633054.394000 287605.322000</gml:lowerCorner>
        		<gml:upperCorner>633054.394000 287605.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633054.394000 287605.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 129 020</ms:GML_ID>
        <ms:NAZWA>210 129 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210129020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633151.114000 297942.418000</gml:lowerCorner>
        		<gml:upperCorner>633151.114000 297942.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633151.114000 297942.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 118 370</ms:GML_ID>
        <ms:NAZWA>210 118 370</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210118370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633215.476000 288531.800000</gml:lowerCorner>
        		<gml:upperCorner>633215.476000 288531.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633215.476000 288531.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 128 078</ms:GML_ID>
        <ms:NAZWA>210 128 078</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210128078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633296.202000 289019.305000</gml:lowerCorner>
        		<gml:upperCorner>633296.202000 289019.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633296.202000 289019.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 127 583</ms:GML_ID>
        <ms:NAZWA>210 127 583</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210127583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633445.587000 289865.471000</gml:lowerCorner>
        		<gml:upperCorner>633445.587000 289865.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633445.587000 289865.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 126 726</ms:GML_ID>
        <ms:NAZWA>210 126 726</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210126726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633501.961524 302013.356840</gml:lowerCorner>
        		<gml:upperCorner>633501.961524 302013.356840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633501.961524 302013.356840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 114 228</ms:GML_ID>
        <ms:NAZWA>210 114 228</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210114228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633665.638056 301079.987326</gml:lowerCorner>
        		<gml:upperCorner>633665.638056 301079.987326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633665.638056 301079.987326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 115 188</ms:GML_ID>
        <ms:NAZWA>210 115 188</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210115188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633729.023000 301111.719000</gml:lowerCorner>
        		<gml:upperCorner>633729.023000 301111.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633729.023000 301111.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 063 965</ms:GML_ID>
        <ms:NAZWA>410 063 965</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410063965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634294.176486 277995.414949</gml:lowerCorner>
        		<gml:upperCorner>634294.176486 277995.414949</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634294.176486 277995.414949</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 139 122</ms:GML_ID>
        <ms:NAZWA>210 139 122</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210139122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634408.938000 300869.755000</gml:lowerCorner>
        		<gml:upperCorner>634408.938000 300869.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634408.938000 300869.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 063 179</ms:GML_ID>
        <ms:NAZWA>410 063 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410063179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634926.058000 301196.380000</gml:lowerCorner>
        		<gml:upperCorner>634926.058000 301196.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634926.058000 301196.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 062 565</ms:GML_ID>
        <ms:NAZWA>410 062 565</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410062565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635104.771000 301484.497000</gml:lowerCorner>
        		<gml:upperCorner>635104.771000 301484.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635104.771000 301484.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 062 222</ms:GML_ID>
        <ms:NAZWA>410 062 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410062222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635166.127000 275728.470000</gml:lowerCorner>
        		<gml:upperCorner>635166.127000 275728.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635166.127000 275728.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 141 670</ms:GML_ID>
        <ms:NAZWA>210 141 670</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210141670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635351.803000 302034.519000</gml:lowerCorner>
        		<gml:upperCorner>635351.803000 302034.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635351.803000 302034.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 061 620</ms:GML_ID>
        <ms:NAZWA>410 061 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410061620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645490.160000 276079.094000</gml:lowerCorner>
        		<gml:upperCorner>645490.160000 276079.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645490.160000 276079.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 278 244</ms:GML_ID>
        <ms:NAZWA>202 278 244</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202278244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646369.827618 276924.254030</gml:lowerCorner>
        		<gml:upperCorner>646369.827618 276924.254030</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646369.827618 276924.254030</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 277 011</ms:GML_ID>
        <ms:NAZWA>202 277 011</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202277011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646799.410730 277335.154279</gml:lowerCorner>
        		<gml:upperCorner>646799.410730 277335.154279</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646799.410730 277335.154279</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 276 421</ms:GML_ID>
        <ms:NAZWA>202 276 421</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202276421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647450.741000 277769.271000</gml:lowerCorner>
        		<gml:upperCorner>647450.741000 277769.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647450.741000 277769.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 275 635</ms:GML_ID>
        <ms:NAZWA>202 275 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202275635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627476.661000 195417.998000</gml:lowerCorner>
        		<gml:upperCorner>627476.661000 195417.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627476.661000 195417.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.429 002 389</ms:GML_ID>
        <ms:NAZWA>429 002 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>429002389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628138.785000 195491.856000</gml:lowerCorner>
        		<gml:upperCorner>628138.785000 195491.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628138.785000 195491.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.429 003 060</ms:GML_ID>
        <ms:NAZWA>429 003 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>429003060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627094.914000 195555.878000</gml:lowerCorner>
        		<gml:upperCorner>627094.914000 195555.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627094.914000 195555.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.429 001 984</ms:GML_ID>
        <ms:NAZWA>429 001 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>429001984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626540.623000 195791.148000</gml:lowerCorner>
        		<gml:upperCorner>626540.623000 195791.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626540.623000 195791.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.429 001 380</ms:GML_ID>
        <ms:NAZWA>429 001 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>429001380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626114.238000 195937.333000</gml:lowerCorner>
        		<gml:upperCorner>626114.238000 195937.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626114.238000 195937.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.408 009 880</ms:GML_ID>
        <ms:NAZWA>408 009 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>408009880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626237.538000 195998.714000</gml:lowerCorner>
        		<gml:upperCorner>626237.538000 195998.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626237.538000 195998.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.429 001 010</ms:GML_ID>
        <ms:NAZWA>429 001 010</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>429001010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625722.471654 196744.041613</gml:lowerCorner>
        		<gml:upperCorner>625722.471654 196744.041613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625722.471654 196744.041613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.408 008 980</ms:GML_ID>
        <ms:NAZWA>408 008 980</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>408008980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628162.213000 202746.519000</gml:lowerCorner>
        		<gml:upperCorner>628162.213000 202746.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628162.213000 202746.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 004 495</ms:GML_ID>
        <ms:NAZWA>406 004 495</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406004495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629167.289392 202764.376154</gml:lowerCorner>
        		<gml:upperCorner>629167.289392 202764.376154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629167.289392 202764.376154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 005 520</ms:GML_ID>
        <ms:NAZWA>406 005 520</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406005520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627059.961000 202890.638000</gml:lowerCorner>
        		<gml:upperCorner>627059.961000 202890.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627059.961000 202890.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.432 003 926</ms:GML_ID>
        <ms:NAZWA>432 003 926</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>432003926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627021.697000 202923.674000</gml:lowerCorner>
        		<gml:upperCorner>627021.697000 202923.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627021.697000 202923.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 003 223</ms:GML_ID>
        <ms:NAZWA>406 003 223</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406003223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645280.819274 205096.284836</gml:lowerCorner>
        		<gml:upperCorner>645280.819274 205096.284836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645280.819274 205096.284836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 028 125</ms:GML_ID>
        <ms:NAZWA>406 028 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406028125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626153.004465 205665.377255</gml:lowerCorner>
        		<gml:upperCorner>626153.004465 205665.377255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626153.004465 205665.377255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.995 000 668</ms:GML_ID>
        <ms:NAZWA>995 000 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>995000668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626142.402771 205677.419511</gml:lowerCorner>
        		<gml:upperCorner>626142.402771 205677.419511</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626142.402771 205677.419511</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.995 000 650</ms:GML_ID>
        <ms:NAZWA>995 000 650</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>995000650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626073.722710 206045.867878</gml:lowerCorner>
        		<gml:upperCorner>626073.722710 206045.867878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626073.722710 206045.867878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.995 000 260</ms:GML_ID>
        <ms:NAZWA>995 000 260</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>995000260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626136.463544 206151.711326</gml:lowerCorner>
        		<gml:upperCorner>626136.463544 206151.711326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626136.463544 206151.711326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.995 000 206</ms:GML_ID>
        <ms:NAZWA>995 000 206</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>995000206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640955.677011 206348.849403</gml:lowerCorner>
        		<gml:upperCorner>640955.677011 206348.849403</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640955.677011 206348.849403</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 023 578</ms:GML_ID>
        <ms:NAZWA>406 023 578</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406023578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624953.034094 206821.923026</gml:lowerCorner>
        		<gml:upperCorner>624953.034094 206821.923026</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624953.034094 206821.923026</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 731</ms:GML_ID>
        <ms:NAZWA>994 000 731</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625011.191979 206841.544728</gml:lowerCorner>
        		<gml:upperCorner>625011.191979 206841.544728</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625011.191979 206841.544728</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 788</ms:GML_ID>
        <ms:NAZWA>994 000 788</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624919.287739 206862.299711</gml:lowerCorner>
        		<gml:upperCorner>624919.287739 206862.299711</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624919.287739 206862.299711</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 732</ms:GML_ID>
        <ms:NAZWA>994 000 732</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624988.836586 206867.684449</gml:lowerCorner>
        		<gml:upperCorner>624988.836586 206867.684449</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624988.836586 206867.684449</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 787</ms:GML_ID>
        <ms:NAZWA>994 000 787</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624948.617294 206912.881991</gml:lowerCorner>
        		<gml:upperCorner>624948.617294 206912.881991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624948.617294 206912.881991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 790</ms:GML_ID>
        <ms:NAZWA>994 000 790</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625221.326722 207182.457789</gml:lowerCorner>
        		<gml:upperCorner>625221.326722 207182.457789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625221.326722 207182.457789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 001 184</ms:GML_ID>
        <ms:NAZWA>994 001 184</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994001184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631233.787535 207308.367062</gml:lowerCorner>
        		<gml:upperCorner>631233.787535 207308.367062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631233.787535 207308.367062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 011 647</ms:GML_ID>
        <ms:NAZWA>406 011 647</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406011647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638558.798000 207855.483000</gml:lowerCorner>
        		<gml:upperCorner>638558.798000 207855.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638558.798000 207855.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 020 611</ms:GML_ID>
        <ms:NAZWA>406 020 611</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406020611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632685.855367 208541.017021</gml:lowerCorner>
        		<gml:upperCorner>632685.855367 208541.017021</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632685.855367 208541.017021</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 013 733</ms:GML_ID>
        <ms:NAZWA>406 013 733</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406013733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638119.454000 208543.552000</gml:lowerCorner>
        		<gml:upperCorner>638119.454000 208543.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638119.454000 208543.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 019 752</ms:GML_ID>
        <ms:NAZWA>406 019 752</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406019752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633324.770000 208950.085000</gml:lowerCorner>
        		<gml:upperCorner>633324.770000 208950.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633324.770000 208950.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 014 495</ms:GML_ID>
        <ms:NAZWA>406 014 495</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406014495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637570.644398 208990.368831</gml:lowerCorner>
        		<gml:upperCorner>637570.644398 208990.368831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637570.644398 208990.368831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 019 038</ms:GML_ID>
        <ms:NAZWA>406 019 038</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406019038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635590.666000 209297.238000</gml:lowerCorner>
        		<gml:upperCorner>635590.666000 209297.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635590.666000 209297.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 016 838</ms:GML_ID>
        <ms:NAZWA>406 016 838</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406016838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637092.852559 209386.909414</gml:lowerCorner>
        		<gml:upperCorner>637092.852559 209386.909414</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637092.852559 209386.909414</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.406 018 372</ms:GML_ID>
        <ms:NAZWA>406 018 372</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>406018372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625095.365000 215687.355000</gml:lowerCorner>
        		<gml:upperCorner>625095.365000 215687.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625095.365000 215687.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 004 424</ms:GML_ID>
        <ms:NAZWA>401 004 424</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401004424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626371.431180 217035.705167</gml:lowerCorner>
        		<gml:upperCorner>626371.431180 217035.705167</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626371.431180 217035.705167</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 006 271</ms:GML_ID>
        <ms:NAZWA>401 006 271</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401006271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630130.187000 220271.100000</gml:lowerCorner>
        		<gml:upperCorner>630130.187000 220271.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630130.187000 220271.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 011 326</ms:GML_ID>
        <ms:NAZWA>401 011 326</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401011326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621304.902347 210548.089851</gml:lowerCorner>
        		<gml:upperCorner>621304.902347 210548.089851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621304.902347 210548.089851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.417 033 474</ms:GML_ID>
        <ms:NAZWA>417 033 474</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>417033474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621332.098000 209165.027000</gml:lowerCorner>
        		<gml:upperCorner>621332.098000 209165.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621332.098000 209165.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 201 957</ms:GML_ID>
        <ms:NAZWA>351 201 957</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351201957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621461.853000 218492.816000</gml:lowerCorner>
        		<gml:upperCorner>621461.853000 218492.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621461.853000 218492.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 192 056</ms:GML_ID>
        <ms:NAZWA>351 192 056</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351192056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622388.511000 198733.209000</gml:lowerCorner>
        		<gml:upperCorner>622388.511000 198733.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622388.511000 198733.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.409 002 837</ms:GML_ID>
        <ms:NAZWA>409 002 837</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>409002837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622627.060591 211647.815789</gml:lowerCorner>
        		<gml:upperCorner>622627.060591 211647.815789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622627.060591 211647.815789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 199 090</ms:GML_ID>
        <ms:NAZWA>351 199 090</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351199090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622770.311426 212506.845869</gml:lowerCorner>
        		<gml:upperCorner>622770.311426 212506.845869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622770.311426 212506.845869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 198 232</ms:GML_ID>
        <ms:NAZWA>351 198 232</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351198232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622813.379000 213016.957000</gml:lowerCorner>
        		<gml:upperCorner>622813.379000 213016.957000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622813.379000 213016.957000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 000 774</ms:GML_ID>
        <ms:NAZWA>401 000 774</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401000774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623148.735521 198988.424970</gml:lowerCorner>
        		<gml:upperCorner>623148.735521 198988.424970</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623148.735521 198988.424970</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.409 002 034</ms:GML_ID>
        <ms:NAZWA>409 002 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>409002034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623323.770000 213572.433000</gml:lowerCorner>
        		<gml:upperCorner>623323.770000 213572.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623323.770000 213572.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.857 001 716</ms:GML_ID>
        <ms:NAZWA>857 001 716</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>857001716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623329.770000 213503.494000</gml:lowerCorner>
        		<gml:upperCorner>623329.770000 213503.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623329.770000 213503.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 001 510</ms:GML_ID>
        <ms:NAZWA>401 001 510</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401001510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623829.403559 199559.054611</gml:lowerCorner>
        		<gml:upperCorner>623829.403559 199559.054611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623829.403559 199559.054611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.409 001 138</ms:GML_ID>
        <ms:NAZWA>409 001 138</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>409001138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624192.250813 200551.201304</gml:lowerCorner>
        		<gml:upperCorner>624192.250813 200551.201304</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624192.250813 200551.201304</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.408 004 825</ms:GML_ID>
        <ms:NAZWA>408 004 825</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>408004825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624381.241322 206639.938381</gml:lowerCorner>
        		<gml:upperCorner>624381.241322 206639.938381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624381.241322 206639.938381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 379</ms:GML_ID>
        <ms:NAZWA>994 000 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624677.547773 202140.985799</gml:lowerCorner>
        		<gml:upperCorner>624677.547773 202140.985799</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624677.547773 202140.985799</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.432 001 305</ms:GML_ID>
        <ms:NAZWA>432 001 305</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>432001305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624700.451000 198793.200000</gml:lowerCorner>
        		<gml:upperCorner>624700.451000 198793.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624700.451000 198793.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.408 006 673</ms:GML_ID>
        <ms:NAZWA>408 006 673</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>408006673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624901.327000 215303.253000</gml:lowerCorner>
        		<gml:upperCorner>624901.327000 215303.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624901.327000 215303.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 003 983</ms:GML_ID>
        <ms:NAZWA>401 003 983</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401003983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624904.675114 206964.240808</gml:lowerCorner>
        		<gml:upperCorner>624904.675114 206964.240808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624904.675114 206964.240808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 789</ms:GML_ID>
        <ms:NAZWA>994 000 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624912.251082 206915.338528</gml:lowerCorner>
        		<gml:upperCorner>624912.251082 206915.338528</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624912.251082 206915.338528</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.994 000 757</ms:GML_ID>
        <ms:NAZWA>994 000 757</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>994000757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621278.565043 250190.075285</gml:lowerCorner>
        		<gml:upperCorner>621278.565043 250190.075285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621278.565043 250190.075285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 316 365</ms:GML_ID>
        <ms:NAZWA>202 316 365</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202316365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622664.410000 251495.974000</gml:lowerCorner>
        		<gml:upperCorner>622664.410000 251495.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622664.410000 251495.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 314 460</ms:GML_ID>
        <ms:NAZWA>202 314 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202314460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624940.342000 254188.154000</gml:lowerCorner>
        		<gml:upperCorner>624940.342000 254188.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624940.342000 254188.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 310 881</ms:GML_ID>
        <ms:NAZWA>202 310 881</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202310881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625924.636000 254634.997000</gml:lowerCorner>
        		<gml:upperCorner>625924.636000 254634.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625924.636000 254634.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 309 802</ms:GML_ID>
        <ms:NAZWA>202 309 802</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202309802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627703.922000 255832.582000</gml:lowerCorner>
        		<gml:upperCorner>627703.922000 255832.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627703.922000 255832.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 307 656</ms:GML_ID>
        <ms:NAZWA>202 307 656</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202307656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628709.967000 256535.108000</gml:lowerCorner>
        		<gml:upperCorner>628709.967000 256535.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628709.967000 256535.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 306 427</ms:GML_ID>
        <ms:NAZWA>202 306 427</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202306427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628919.273000 256719.120000</gml:lowerCorner>
        		<gml:upperCorner>628919.273000 256719.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628919.273000 256719.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 306 150</ms:GML_ID>
        <ms:NAZWA>202 306 150</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202306150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632308.678000 259914.716000</gml:lowerCorner>
        		<gml:upperCorner>632308.678000 259914.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632308.678000 259914.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 301 485</ms:GML_ID>
        <ms:NAZWA>202 301 485</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202301485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633363.132000 264556.127000</gml:lowerCorner>
        		<gml:upperCorner>633363.132000 264556.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633363.132000 264556.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 296 126</ms:GML_ID>
        <ms:NAZWA>202 296 126</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202296126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633740.232000 261559.234000</gml:lowerCorner>
        		<gml:upperCorner>633740.232000 261559.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633740.232000 261559.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 299 215</ms:GML_ID>
        <ms:NAZWA>202 299 215</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202299215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633851.320000 265396.197000</gml:lowerCorner>
        		<gml:upperCorner>633851.320000 265396.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633851.320000 265396.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 295 154</ms:GML_ID>
        <ms:NAZWA>202 295 154</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202295154</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634149.880000 265906.464000</gml:lowerCorner>
        		<gml:upperCorner>634149.880000 265906.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634149.880000 265906.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 294 561</ms:GML_ID>
        <ms:NAZWA>202 294 561</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202294561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635314.696000 267578.955000</gml:lowerCorner>
        		<gml:upperCorner>635314.696000 267578.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635314.696000 267578.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 292 519</ms:GML_ID>
        <ms:NAZWA>202 292 519</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202292519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635884.841000 274657.703000</gml:lowerCorner>
        		<gml:upperCorner>635884.841000 274657.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635884.841000 274657.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 142 954</ms:GML_ID>
        <ms:NAZWA>210 142 954</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210142954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636192.393000 273865.510000</gml:lowerCorner>
        		<gml:upperCorner>636192.393000 273865.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636192.393000 273865.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 143 824</ms:GML_ID>
        <ms:NAZWA>210 143 824</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210143824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636465.246000 272115.204000</gml:lowerCorner>
        		<gml:upperCorner>636465.246000 272115.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636465.246000 272115.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 145 596</ms:GML_ID>
        <ms:NAZWA>210 145 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210145596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637538.934688 270053.125330</gml:lowerCorner>
        		<gml:upperCorner>637538.934688 270053.125330</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637538.934688 270053.125330</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 289 140</ms:GML_ID>
        <ms:NAZWA>202 289 140</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202289140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639726.210000 271258.977000</gml:lowerCorner>
        		<gml:upperCorner>639726.210000 271258.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639726.210000 271258.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 286 680</ms:GML_ID>
        <ms:NAZWA>202 286 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202286680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641076.274000 273024.636000</gml:lowerCorner>
        		<gml:upperCorner>641076.274000 273024.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641076.274000 273024.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 284 355</ms:GML_ID>
        <ms:NAZWA>202 284 355</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202284355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633231.211000 306427.302000</gml:lowerCorner>
        		<gml:upperCorner>633231.211000 306427.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633231.211000 306427.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 109 777</ms:GML_ID>
        <ms:NAZWA>210 109 777</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210109777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624954.416000 306642.960000</gml:lowerCorner>
        		<gml:upperCorner>624954.416000 306642.960000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624954.416000 306642.960000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 075 095</ms:GML_ID>
        <ms:NAZWA>410 075 095</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410075095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624098.693000 307051.365000</gml:lowerCorner>
        		<gml:upperCorner>624098.693000 307051.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624098.693000 307051.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 076 039</ms:GML_ID>
        <ms:NAZWA>410 076 039</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410076039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622498.883000 307367.218000</gml:lowerCorner>
        		<gml:upperCorner>622498.883000 307367.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622498.883000 307367.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 077 688</ms:GML_ID>
        <ms:NAZWA>410 077 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410077688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633111.323580 307583.520570</gml:lowerCorner>
        		<gml:upperCorner>633111.323580 307583.520570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633111.323580 307583.520570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 108 611</ms:GML_ID>
        <ms:NAZWA>210 108 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210108611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617190.805000 307873.456000</gml:lowerCorner>
        		<gml:upperCorner>617190.805000 307873.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617190.805000 307873.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 083 023</ms:GML_ID>
        <ms:NAZWA>410 083 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410083023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632707.091179 310562.374369</gml:lowerCorner>
        		<gml:upperCorner>632707.091179 310562.374369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632707.091179 310562.374369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 105 593</ms:GML_ID>
        <ms:NAZWA>210 105 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210105593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632558.662000 311201.461000</gml:lowerCorner>
        		<gml:upperCorner>632558.662000 311201.461000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632558.662000 311201.461000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 104 945</ms:GML_ID>
        <ms:NAZWA>210 104 945</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210104945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632161.146000 312882.517000</gml:lowerCorner>
        		<gml:upperCorner>632161.146000 312882.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632161.146000 312882.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 103 210</ms:GML_ID>
        <ms:NAZWA>210 103 210</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210103210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632172.677000 315057.545000</gml:lowerCorner>
        		<gml:upperCorner>632172.677000 315057.545000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632172.677000 315057.545000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 100 894</ms:GML_ID>
        <ms:NAZWA>210 100 894</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210100894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633634.274000 316574.064000</gml:lowerCorner>
        		<gml:upperCorner>633634.274000 316574.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633634.274000 316574.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 098 791</ms:GML_ID>
        <ms:NAZWA>210 098 791</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210098791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633999.154873 317565.762371</gml:lowerCorner>
        		<gml:upperCorner>633999.154873 317565.762371</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633999.154873 317565.762371</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 097 733</ms:GML_ID>
        <ms:NAZWA>210 097 733</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210097733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634232.252000 318174.206000</gml:lowerCorner>
        		<gml:upperCorner>634232.252000 318174.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634232.252000 318174.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 097 084</ms:GML_ID>
        <ms:NAZWA>210 097 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210097084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634317.871000 318405.958000</gml:lowerCorner>
        		<gml:upperCorner>634317.871000 318405.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634317.871000 318405.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 096 834</ms:GML_ID>
        <ms:NAZWA>210 096 834</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210096834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635331.399000 321111.665000</gml:lowerCorner>
        		<gml:upperCorner>635331.399000 321111.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635331.399000 321111.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 093 946</ms:GML_ID>
        <ms:NAZWA>210 093 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210093946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635869.598000 322541.930000</gml:lowerCorner>
        		<gml:upperCorner>635869.598000 322541.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635869.598000 322541.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 092 417</ms:GML_ID>
        <ms:NAZWA>210 092 417</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210092417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636171.876000 323345.023000</gml:lowerCorner>
        		<gml:upperCorner>636171.876000 323345.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636171.876000 323345.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 091 559</ms:GML_ID>
        <ms:NAZWA>210 091 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210091559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637362.616000 325469.389000</gml:lowerCorner>
        		<gml:upperCorner>637362.616000 325469.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637362.616000 325469.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 089 108</ms:GML_ID>
        <ms:NAZWA>210 089 108</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210089108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638766.057925 327474.521118</gml:lowerCorner>
        		<gml:upperCorner>638766.057925 327474.521118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638766.057925 327474.521118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 086 660</ms:GML_ID>
        <ms:NAZWA>210 086 660</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210086660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606224.397585 271215.632063</gml:lowerCorner>
        		<gml:upperCorner>606224.397585 271215.632063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606224.397585 271215.632063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 090 934</ms:GML_ID>
        <ms:NAZWA>403 090 934</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403090934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607450.542000 269274.946000</gml:lowerCorner>
        		<gml:upperCorner>607450.542000 269274.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607450.542000 269274.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 093 709</ms:GML_ID>
        <ms:NAZWA>403 093 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403093709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607473.139000 273849.707000</gml:lowerCorner>
        		<gml:upperCorner>607473.139000 273849.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607473.139000 273849.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 087 982</ms:GML_ID>
        <ms:NAZWA>403 087 982</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403087982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608784.716000 267294.408000</gml:lowerCorner>
        		<gml:upperCorner>608784.716000 267294.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608784.716000 267294.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 096 126</ms:GML_ID>
        <ms:NAZWA>403 096 126</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403096126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609110.291000 267008.211000</gml:lowerCorner>
        		<gml:upperCorner>609110.291000 267008.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609110.291000 267008.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 096 559</ms:GML_ID>
        <ms:NAZWA>403 096 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403096559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610560.842000 258716.171000</gml:lowerCorner>
        		<gml:upperCorner>610560.842000 258716.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610560.842000 258716.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 106 365</ms:GML_ID>
        <ms:NAZWA>403 106 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403106365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610670.047000 259809.163000</gml:lowerCorner>
        		<gml:upperCorner>610670.047000 259809.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610670.047000 259809.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 105 263</ms:GML_ID>
        <ms:NAZWA>403 105 263</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403105263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610705.408745 258088.285397</gml:lowerCorner>
        		<gml:upperCorner>610705.408745 258088.285397</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610705.408745 258088.285397</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 107 010</ms:GML_ID>
        <ms:NAZWA>403 107 010</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403107010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611437.589000 265233.929000</gml:lowerCorner>
        		<gml:upperCorner>611437.589000 265233.929000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611437.589000 265233.929000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 099 642</ms:GML_ID>
        <ms:NAZWA>403 099 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403099642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611510.449000 263686.383000</gml:lowerCorner>
        		<gml:upperCorner>611510.449000 263686.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611510.449000 263686.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 101 220</ms:GML_ID>
        <ms:NAZWA>403 101 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403101220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612234.918800 254567.808112</gml:lowerCorner>
        		<gml:upperCorner>612234.918800 254567.808112</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612234.918800 254567.808112</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 110 874</ms:GML_ID>
        <ms:NAZWA>403 110 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403110874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613436.628000 251167.002000</gml:lowerCorner>
        		<gml:upperCorner>613436.628000 251167.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613436.628000 251167.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 114 480</ms:GML_ID>
        <ms:NAZWA>403 114 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403114480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614236.666000 248178.524000</gml:lowerCorner>
        		<gml:upperCorner>614236.666000 248178.524000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614236.666000 248178.524000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 117 580</ms:GML_ID>
        <ms:NAZWA>403 117 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403117580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614350.016000 247702.775000</gml:lowerCorner>
        		<gml:upperCorner>614350.016000 247702.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614350.016000 247702.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 118 065</ms:GML_ID>
        <ms:NAZWA>403 118 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403118065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614606.817000 246624.161000</gml:lowerCorner>
        		<gml:upperCorner>614606.817000 246624.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614606.817000 246624.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 119 176</ms:GML_ID>
        <ms:NAZWA>403 119 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403119176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615290.833000 245359.822000</gml:lowerCorner>
        		<gml:upperCorner>615290.833000 245359.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615290.833000 245359.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 120 616</ms:GML_ID>
        <ms:NAZWA>403 120 616</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403120616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618760.950000 245817.744000</gml:lowerCorner>
        		<gml:upperCorner>618760.950000 245817.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618760.950000 245817.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 321 443</ms:GML_ID>
        <ms:NAZWA>202 321 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202321443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619620.711000 247494.146000</gml:lowerCorner>
        		<gml:upperCorner>619620.711000 247494.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619620.711000 247494.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 319 559</ms:GML_ID>
        <ms:NAZWA>202 319 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202319559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604570.317000 230533.877000</gml:lowerCorner>
        		<gml:upperCorner>604570.317000 230533.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604570.317000 230533.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 012 880</ms:GML_ID>
        <ms:NAZWA>411 012 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411012880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604768.068145 241482.752404</gml:lowerCorner>
        		<gml:upperCorner>604768.068145 241482.752404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604768.068145 241482.752404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 160 914</ms:GML_ID>
        <ms:NAZWA>351 160 914</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351160914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605916.411000 231075.090000</gml:lowerCorner>
        		<gml:upperCorner>605916.411000 231075.090000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605916.411000 231075.090000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 011 406</ms:GML_ID>
        <ms:NAZWA>411 011 406</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411011406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606162.209000 231264.978000</gml:lowerCorner>
        		<gml:upperCorner>606162.209000 231264.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606162.209000 231264.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 011 096</ms:GML_ID>
        <ms:NAZWA>411 011 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411011096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606702.198000 240579.120000</gml:lowerCorner>
        		<gml:upperCorner>606702.198000 240579.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606702.198000 240579.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 163 049</ms:GML_ID>
        <ms:NAZWA>351 163 049</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351163049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606768.210000 231742.310000</gml:lowerCorner>
        		<gml:upperCorner>606768.210000 231742.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606768.210000 231742.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 010 325</ms:GML_ID>
        <ms:NAZWA>411 010 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411010325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608698.298000 239386.574000</gml:lowerCorner>
        		<gml:upperCorner>608698.298000 239386.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608698.298000 239386.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 165 441</ms:GML_ID>
        <ms:NAZWA>351 165 441</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351165441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609324.174520 238687.151719</gml:lowerCorner>
        		<gml:upperCorner>609324.174520 238687.151719</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609324.174520 238687.151719</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 166 372</ms:GML_ID>
        <ms:NAZWA>351 166 372</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351166372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610926.219000 237859.689000</gml:lowerCorner>
        		<gml:upperCorner>610926.219000 237859.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610926.219000 237859.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 168 200</ms:GML_ID>
        <ms:NAZWA>351 168 200</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351168200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611265.751270 234048.990641</gml:lowerCorner>
        		<gml:upperCorner>611265.751270 234048.990641</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611265.751270 234048.990641</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 005 245</ms:GML_ID>
        <ms:NAZWA>411 005 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411005245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611788.390983 234635.688871</gml:lowerCorner>
        		<gml:upperCorner>611788.390983 234635.688871</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611788.390983 234635.688871</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 004 456</ms:GML_ID>
        <ms:NAZWA>411 004 456</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411004456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613348.701000 235824.490000</gml:lowerCorner>
        		<gml:upperCorner>613348.701000 235824.490000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613348.701000 235824.490000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 002 445</ms:GML_ID>
        <ms:NAZWA>411 002 445</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411002445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613903.812000 237287.359000</gml:lowerCorner>
        		<gml:upperCorner>613903.812000 237287.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613903.812000 237287.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 331 295</ms:GML_ID>
        <ms:NAZWA>202 331 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202331295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614820.829000 239193.668000</gml:lowerCorner>
        		<gml:upperCorner>614820.829000 239193.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614820.829000 239193.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 329 148</ms:GML_ID>
        <ms:NAZWA>202 329 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202329148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616407.759284 241856.952530</gml:lowerCorner>
        		<gml:upperCorner>616407.759284 241856.952530</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616407.759284 241856.952530</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 326 050</ms:GML_ID>
        <ms:NAZWA>202 326 050</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202326050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616719.817000 242650.961000</gml:lowerCorner>
        		<gml:upperCorner>616719.817000 242650.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616719.817000 242650.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 123 696</ms:GML_ID>
        <ms:NAZWA>403 123 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403123696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616883.141000 242658.332000</gml:lowerCorner>
        		<gml:upperCorner>616883.141000 242658.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616883.141000 242658.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 325 113</ms:GML_ID>
        <ms:NAZWA>202 325 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202325113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617377.918043 243490.577057</gml:lowerCorner>
        		<gml:upperCorner>617377.918043 243490.577057</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617377.918043 243490.577057</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 324 151</ms:GML_ID>
        <ms:NAZWA>202 324 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202324151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617914.026000 232101.678000</gml:lowerCorner>
        		<gml:upperCorner>617914.026000 232101.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617914.026000 232101.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 177 994</ms:GML_ID>
        <ms:NAZWA>351 177 994</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351177994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618811.683000 228951.633000</gml:lowerCorner>
        		<gml:upperCorner>618811.683000 228951.633000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618811.683000 228951.633000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 181 267</ms:GML_ID>
        <ms:NAZWA>351 181 267</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351181267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619971.156280 224654.890000</gml:lowerCorner>
        		<gml:upperCorner>619971.156280 224654.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619971.156280 224654.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 185 718</ms:GML_ID>
        <ms:NAZWA>351 185 718</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351185718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639811.352000 224040.369000</gml:lowerCorner>
        		<gml:upperCorner>639811.352000 224040.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639811.352000 224040.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 021 847</ms:GML_ID>
        <ms:NAZWA>401 021 847</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401021847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640961.108074 225759.472039</gml:lowerCorner>
        		<gml:upperCorner>640961.108074 225759.472039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640961.108074 225759.472039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 140 320</ms:GML_ID>
        <ms:NAZWA>402 140 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402140320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640981.858229 224637.588376</gml:lowerCorner>
        		<gml:upperCorner>640981.858229 224637.588376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640981.858229 224637.588376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 023 193</ms:GML_ID>
        <ms:NAZWA>401 023 193</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401023193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641059.365000 229168.775000</gml:lowerCorner>
        		<gml:upperCorner>641059.365000 229168.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641059.365000 229168.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 136 719</ms:GML_ID>
        <ms:NAZWA>402 136 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402136719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641300.287007 224759.680038</gml:lowerCorner>
        		<gml:upperCorner>641300.287007 224759.680038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641300.287007 224759.680038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 141 495</ms:GML_ID>
        <ms:NAZWA>402 141 495</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402141495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642009.291767 231299.959101</gml:lowerCorner>
        		<gml:upperCorner>642009.291767 231299.959101</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642009.291767 231299.959101</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 134 324</ms:GML_ID>
        <ms:NAZWA>402 134 324</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402134324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642240.124000 224931.739000</gml:lowerCorner>
        		<gml:upperCorner>642240.124000 224931.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642240.124000 224931.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.401 024 483</ms:GML_ID>
        <ms:NAZWA>401 024 483</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>401024483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643895.028000 233346.563000</gml:lowerCorner>
        		<gml:upperCorner>643895.028000 233346.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643895.028000 233346.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 131 528</ms:GML_ID>
        <ms:NAZWA>402 131 528</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402131528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645203.341685 235489.109376</gml:lowerCorner>
        		<gml:upperCorner>645203.341685 235489.109376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645203.341685 235489.109376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 129 006</ms:GML_ID>
        <ms:NAZWA>402 129 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402129006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645558.236850 236206.582383</gml:lowerCorner>
        		<gml:upperCorner>645558.236850 236206.582383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645558.236850 236206.582383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.402 128 206</ms:GML_ID>
        <ms:NAZWA>402 128 206</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>402128206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638977.857000 327813.067000</gml:lowerCorner>
        		<gml:upperCorner>638977.857000 327813.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638977.857000 327813.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 086 260</ms:GML_ID>
        <ms:NAZWA>210 086 260</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210086260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604149.427337 329980.402203</gml:lowerCorner>
        		<gml:upperCorner>604149.427337 329980.402203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604149.427337 329980.402203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 025 862</ms:GML_ID>
        <ms:NAZWA>403 025 862</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403025862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604391.979000 330802.219000</gml:lowerCorner>
        		<gml:upperCorner>604391.979000 330802.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604391.979000 330802.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 025 009</ms:GML_ID>
        <ms:NAZWA>403 025 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403025009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604434.022000 330946.561000</gml:lowerCorner>
        		<gml:upperCorner>604434.022000 330946.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604434.022000 330946.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 024 850</ms:GML_ID>
        <ms:NAZWA>403 024 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403024850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604612.759000 331562.759000</gml:lowerCorner>
        		<gml:upperCorner>604612.759000 331562.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604612.759000 331562.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 024 209</ms:GML_ID>
        <ms:NAZWA>403 024 209</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403024209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604600.390000 332003.402000</gml:lowerCorner>
        		<gml:upperCorner>604600.390000 332003.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604600.390000 332003.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 023 754</ms:GML_ID>
        <ms:NAZWA>403 023 754</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403023754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604228.005374 332268.196035</gml:lowerCorner>
        		<gml:upperCorner>604228.005374 332268.196035</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604228.005374 332268.196035</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 023 279</ms:GML_ID>
        <ms:NAZWA>403 023 279</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403023279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605341.688911 349985.508327</gml:lowerCorner>
        		<gml:upperCorner>605341.688911 349985.508327</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605341.688911 349985.508327</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 021 429</ms:GML_ID>
        <ms:NAZWA>405 021 429</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405021429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607504.916905 350761.713909</gml:lowerCorner>
        		<gml:upperCorner>607504.916905 350761.713909</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607504.916905 350761.713909</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 023 729</ms:GML_ID>
        <ms:NAZWA>405 023 729</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405023729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611092.410000 351940.811000</gml:lowerCorner>
        		<gml:upperCorner>611092.410000 351940.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611092.410000 351940.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 027 508</ms:GML_ID>
        <ms:NAZWA>405 027 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405027508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639945.034000 352872.355000</gml:lowerCorner>
        		<gml:upperCorner>639945.034000 352872.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639945.034000 352872.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 058 775</ms:GML_ID>
        <ms:NAZWA>405 058 775</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405058775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616034.964587 353004.489791</gml:lowerCorner>
        		<gml:upperCorner>616034.964587 353004.489791</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616034.964587 353004.489791</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 032 576</ms:GML_ID>
        <ms:NAZWA>405 032 576</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405032576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617636.838273 353345.953527</gml:lowerCorner>
        		<gml:upperCorner>617636.838273 353345.953527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617636.838273 353345.953527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 034 223</ms:GML_ID>
        <ms:NAZWA>405 034 223</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405034223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638653.816000 353625.954000</gml:lowerCorner>
        		<gml:upperCorner>638653.816000 353625.954000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638653.816000 353625.954000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 057 281</ms:GML_ID>
        <ms:NAZWA>405 057 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405057281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619845.594000 354569.087000</gml:lowerCorner>
        		<gml:upperCorner>619845.594000 354569.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619845.594000 354569.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 036 759</ms:GML_ID>
        <ms:NAZWA>405 036 759</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405036759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623875.692000 355359.507000</gml:lowerCorner>
        		<gml:upperCorner>623875.692000 355359.507000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623875.692000 355359.507000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 040 999</ms:GML_ID>
        <ms:NAZWA>405 040 999</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405040999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635237.202000 355533.429000</gml:lowerCorner>
        		<gml:upperCorner>635237.202000 355533.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635237.202000 355533.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 053 360</ms:GML_ID>
        <ms:NAZWA>405 053 360</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405053360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626570.046026 355649.608961</gml:lowerCorner>
        		<gml:upperCorner>626570.046026 355649.608961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626570.046026 355649.608961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 043 712</ms:GML_ID>
        <ms:NAZWA>405 043 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405043712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630119.534809 356030.369686</gml:lowerCorner>
        		<gml:upperCorner>630119.534809 356030.369686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630119.534809 356030.369686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 047 620</ms:GML_ID>
        <ms:NAZWA>405 047 620</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405047620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603889.469000 295248.258000</gml:lowerCorner>
        		<gml:upperCorner>603889.469000 295248.258000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603889.469000 295248.258000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 063 750</ms:GML_ID>
        <ms:NAZWA>403 063 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403063750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604155.722000 289497.529000</gml:lowerCorner>
        		<gml:upperCorner>604155.722000 289497.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604155.722000 289497.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 109 359</ms:GML_ID>
        <ms:NAZWA>410 109 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410109359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604886.377671 290016.253940</gml:lowerCorner>
        		<gml:upperCorner>604886.377671 290016.253940</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604886.377671 290016.253940</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 108 443</ms:GML_ID>
        <ms:NAZWA>410 108 443</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410108443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605633.591126 292611.739133</gml:lowerCorner>
        		<gml:upperCorner>605633.591126 292611.739133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605633.591126 292611.739133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 066 981</ms:GML_ID>
        <ms:NAZWA>403 066 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403066981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605736.890000 290808.967000</gml:lowerCorner>
        		<gml:upperCorner>605736.890000 290808.967000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605736.890000 290808.967000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 069 011</ms:GML_ID>
        <ms:NAZWA>403 069 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403069011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605742.288000 292641.763000</gml:lowerCorner>
        		<gml:upperCorner>605742.288000 292641.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605742.288000 292641.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 105 236</ms:GML_ID>
        <ms:NAZWA>410 105 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410105236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605742.470000 290236.471000</gml:lowerCorner>
        		<gml:upperCorner>605742.470000 290236.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605742.470000 290236.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 069 617</ms:GML_ID>
        <ms:NAZWA>403 069 617</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403069617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606014.800081 291933.898123</gml:lowerCorner>
        		<gml:upperCorner>606014.800081 291933.898123</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606014.800081 291933.898123</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 067 761</ms:GML_ID>
        <ms:NAZWA>403 067 761</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403067761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606928.705000 295686.979000</gml:lowerCorner>
        		<gml:upperCorner>606928.705000 295686.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606928.705000 295686.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 101 062</ms:GML_ID>
        <ms:NAZWA>410 101 062</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410101062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606933.976000 296331.710000</gml:lowerCorner>
        		<gml:upperCorner>606933.976000 296331.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606933.976000 296331.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 100 418</ms:GML_ID>
        <ms:NAZWA>410 100 418</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410100418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607193.235223 299099.624215</gml:lowerCorner>
        		<gml:upperCorner>607193.235223 299099.624215</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607193.235223 299099.624215</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 097 633</ms:GML_ID>
        <ms:NAZWA>410 097 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410097633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607201.733250 293503.234344</gml:lowerCorner>
        		<gml:upperCorner>607201.733250 293503.234344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607201.733250 293503.234344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 103 284</ms:GML_ID>
        <ms:NAZWA>410 103 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410103284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607662.773000 279084.384000</gml:lowerCorner>
        		<gml:upperCorner>607662.773000 279084.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607662.773000 279084.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 082 581</ms:GML_ID>
        <ms:NAZWA>403 082 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403082581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607837.463000 275510.351000</gml:lowerCorner>
        		<gml:upperCorner>607837.463000 275510.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607837.463000 275510.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 086 255</ms:GML_ID>
        <ms:NAZWA>403 086 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403086255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608084.590000 287553.952000</gml:lowerCorner>
        		<gml:upperCorner>608084.590000 287553.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608084.590000 287553.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 073 354</ms:GML_ID>
        <ms:NAZWA>403 073 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403073354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608708.939000 286674.611000</gml:lowerCorner>
        		<gml:upperCorner>608708.939000 286674.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608708.939000 286674.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 074 434</ms:GML_ID>
        <ms:NAZWA>403 074 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403074434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608756.104760 302740.066882</gml:lowerCorner>
        		<gml:upperCorner>608756.104760 302740.066882</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608756.104760 302740.066882</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 093 606</ms:GML_ID>
        <ms:NAZWA>410 093 606</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410093606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609114.091000 285669.862000</gml:lowerCorner>
        		<gml:upperCorner>609114.091000 285669.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609114.091000 285669.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 075 524</ms:GML_ID>
        <ms:NAZWA>403 075 524</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403075524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611544.821000 304798.766000</gml:lowerCorner>
        		<gml:upperCorner>611544.821000 304798.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611544.821000 304798.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 090 119</ms:GML_ID>
        <ms:NAZWA>410 090 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410090119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612419.679000 305799.314000</gml:lowerCorner>
        		<gml:upperCorner>612419.679000 305799.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612419.679000 305799.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 088 749</ms:GML_ID>
        <ms:NAZWA>410 088 749</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410088749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613017.012000 305996.232000</gml:lowerCorner>
        		<gml:upperCorner>613017.012000 305996.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613017.012000 305996.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 088 119</ms:GML_ID>
        <ms:NAZWA>410 088 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410088119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613298.849000 306154.189000</gml:lowerCorner>
        		<gml:upperCorner>613298.849000 306154.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613298.849000 306154.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 087 791</ms:GML_ID>
        <ms:NAZWA>410 087 791</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410087791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627104.305000 305618.509000</gml:lowerCorner>
        		<gml:upperCorner>627104.305000 305618.509000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627104.305000 305618.509000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 072 704</ms:GML_ID>
        <ms:NAZWA>410 072 704</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410072704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632529.297000 294153.923000</gml:lowerCorner>
        		<gml:upperCorner>632529.297000 294153.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632529.297000 294153.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 122 209</ms:GML_ID>
        <ms:NAZWA>210 122 209</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210122209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632534.067000 284615.142000</gml:lowerCorner>
        		<gml:upperCorner>632534.067000 284615.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632534.067000 284615.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 132 054</ms:GML_ID>
        <ms:NAZWA>210 132 054</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210132054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632740.552000 303420.098000</gml:lowerCorner>
        		<gml:upperCorner>632740.552000 303420.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632740.552000 303420.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 066 591</ms:GML_ID>
        <ms:NAZWA>410 066 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410066591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632752.538000 293102.600000</gml:lowerCorner>
        		<gml:upperCorner>632752.538000 293102.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632752.538000 293102.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 123 342</ms:GML_ID>
        <ms:NAZWA>210 123 342</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210123342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632829.346000 295984.468000</gml:lowerCorner>
        		<gml:upperCorner>632829.346000 295984.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632829.346000 295984.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 120 355</ms:GML_ID>
        <ms:NAZWA>210 120 355</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210120355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632833.480616 286310.371426</gml:lowerCorner>
        		<gml:upperCorner>632833.480616 286310.371426</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632833.480616 286310.371426</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 130 334</ms:GML_ID>
        <ms:NAZWA>210 130 334</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210130334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632951.801000 287015.155000</gml:lowerCorner>
        		<gml:upperCorner>632951.801000 287015.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632951.801000 287015.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 129 619</ms:GML_ID>
        <ms:NAZWA>210 129 619</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210129619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632957.267000 296763.266000</gml:lowerCorner>
        		<gml:upperCorner>632957.267000 296763.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632957.267000 296763.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 119 565</ms:GML_ID>
        <ms:NAZWA>210 119 565</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210119565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595231.582000 225479.325000</gml:lowerCorner>
        		<gml:upperCorner>595231.582000 225479.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595231.582000 225479.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 024 381</ms:GML_ID>
        <ms:NAZWA>411 024 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411024381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596651.765000 226698.388000</gml:lowerCorner>
        		<gml:upperCorner>596651.765000 226698.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596651.765000 226698.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 022 507</ms:GML_ID>
        <ms:NAZWA>411 022 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411022507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596882.382588 195985.623321</gml:lowerCorner>
        		<gml:upperCorner>596882.382588 195985.623321</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596882.382588 195985.623321</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 321 986</ms:GML_ID>
        <ms:NAZWA>273 321 986</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273321986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598369.833000 196994.891000</gml:lowerCorner>
        		<gml:upperCorner>598369.833000 196994.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598369.833000 196994.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 323 851</ms:GML_ID>
        <ms:NAZWA>273 323 851</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273323851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603401.716080 198332.847256</gml:lowerCorner>
        		<gml:upperCorner>603401.716080 198332.847256</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603401.716080 198332.847256</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 329 300</ms:GML_ID>
        <ms:NAZWA>273 329 300</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273329300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604706.820701 198924.768641</gml:lowerCorner>
        		<gml:upperCorner>604706.820701 198924.768641</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604706.820701 198924.768641</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 330 735</ms:GML_ID>
        <ms:NAZWA>273 330 735</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273330735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607825.021021 199467.181208</gml:lowerCorner>
        		<gml:upperCorner>607825.021021 199467.181208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607825.021021 199467.181208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 333 937</ms:GML_ID>
        <ms:NAZWA>273 333 937</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273333937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611693.740062 201069.504753</gml:lowerCorner>
        		<gml:upperCorner>611693.740062 201069.504753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611693.740062 201069.504753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 338 263</ms:GML_ID>
        <ms:NAZWA>273 338 263</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273338263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613379.720000 202037.368000</gml:lowerCorner>
        		<gml:upperCorner>613379.720000 202037.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613379.720000 202037.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 340 207</ms:GML_ID>
        <ms:NAZWA>273 340 207</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273340207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614394.246000 202334.129000</gml:lowerCorner>
        		<gml:upperCorner>614394.246000 202334.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614394.246000 202334.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 341 280</ms:GML_ID>
        <ms:NAZWA>273 341 280</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273341280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615292.641000 202599.884000</gml:lowerCorner>
        		<gml:upperCorner>615292.641000 202599.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615292.641000 202599.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 342 231</ms:GML_ID>
        <ms:NAZWA>273 342 231</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273342231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617959.700665 204370.997523</gml:lowerCorner>
        		<gml:upperCorner>617959.700665 204370.997523</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617959.700665 204370.997523</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 345 485</ms:GML_ID>
        <ms:NAZWA>273 345 485</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273345485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618302.794636 196520.302990</gml:lowerCorner>
        		<gml:upperCorner>618302.794636 196520.302990</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618302.794636 196520.302990</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.409 007 585</ms:GML_ID>
        <ms:NAZWA>409 007 585</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>409007585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618539.305000 205146.452000</gml:lowerCorner>
        		<gml:upperCorner>618539.305000 205146.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618539.305000 205146.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 346 454</ms:GML_ID>
        <ms:NAZWA>273 346 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273346454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618891.477177 205635.626909</gml:lowerCorner>
        		<gml:upperCorner>618891.477177 205635.626909</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618891.477177 205635.626909</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 347 057</ms:GML_ID>
        <ms:NAZWA>273 347 057</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273347057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620269.248759 206760.113699</gml:lowerCorner>
        		<gml:upperCorner>620269.248759 206760.113699</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620269.248759 206760.113699</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.428 006 227</ms:GML_ID>
        <ms:NAZWA>428 006 227</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>428006227</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620522.378494 207004.359948</gml:lowerCorner>
        		<gml:upperCorner>620522.378494 207004.359948</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620522.378494 207004.359948</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.428 005 874</ms:GML_ID>
        <ms:NAZWA>428 005 874</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>428005874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620660.283000 207115.373000</gml:lowerCorner>
        		<gml:upperCorner>620660.283000 207115.373000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620660.283000 207115.373000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.428 005 698</ms:GML_ID>
        <ms:NAZWA>428 005 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>428005698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620777.948000 211489.376000</gml:lowerCorner>
        		<gml:upperCorner>620777.948000 211489.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620777.948000 211489.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.417 032 356</ms:GML_ID>
        <ms:NAZWA>417 032 356</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>417032356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621053.329042 210786.842514</gml:lowerCorner>
        		<gml:upperCorner>621053.329042 210786.842514</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621053.329042 210786.842514</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.417 033 110</ms:GML_ID>
        <ms:NAZWA>417 033 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>417033110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592003.334000 339550.678000</gml:lowerCorner>
        		<gml:upperCorner>592003.334000 339550.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592003.334000 339550.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 008 435</ms:GML_ID>
        <ms:NAZWA>403 008 435</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403008435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592299.914834 339225.376973</gml:lowerCorner>
        		<gml:upperCorner>592299.914834 339225.376973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592299.914834 339225.376973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 008 881</ms:GML_ID>
        <ms:NAZWA>403 008 881</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403008881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594439.324000 337291.928000</gml:lowerCorner>
        		<gml:upperCorner>594439.324000 337291.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594439.324000 337291.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 011 798</ms:GML_ID>
        <ms:NAZWA>403 011 798</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403011798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595762.499000 335765.319000</gml:lowerCorner>
        		<gml:upperCorner>595762.499000 335765.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595762.499000 335765.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 013 821</ms:GML_ID>
        <ms:NAZWA>403 013 821</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403013821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598220.236000 334909.019000</gml:lowerCorner>
        		<gml:upperCorner>598220.236000 334909.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598220.236000 334909.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 016 544</ms:GML_ID>
        <ms:NAZWA>403 016 544</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403016544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598339.465096 346782.923262</gml:lowerCorner>
        		<gml:upperCorner>598339.465096 346782.923262</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598339.465096 346782.923262</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 013 657</ms:GML_ID>
        <ms:NAZWA>405 013 657</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405013657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598524.767000 334843.256000</gml:lowerCorner>
        		<gml:upperCorner>598524.767000 334843.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598524.767000 334843.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 016 856</ms:GML_ID>
        <ms:NAZWA>403 016 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403016856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598569.068467 311269.981773</gml:lowerCorner>
        		<gml:upperCorner>598569.068467 311269.981773</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598569.068467 311269.981773</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 046 429</ms:GML_ID>
        <ms:NAZWA>403 046 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403046429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598659.465000 310260.173000</gml:lowerCorner>
        		<gml:upperCorner>598659.465000 310260.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598659.465000 310260.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 047 451</ms:GML_ID>
        <ms:NAZWA>403 047 451</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403047451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598761.444000 309802.546000</gml:lowerCorner>
        		<gml:upperCorner>598761.444000 309802.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598761.444000 309802.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 047 921</ms:GML_ID>
        <ms:NAZWA>403 047 921</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403047921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598816.694000 312708.820000</gml:lowerCorner>
        		<gml:upperCorner>598816.694000 312708.820000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598816.694000 312708.820000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 044 955</ms:GML_ID>
        <ms:NAZWA>403 044 955</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403044955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598997.639000 313093.039000</gml:lowerCorner>
        		<gml:upperCorner>598997.639000 313093.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598997.639000 313093.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 044 531</ms:GML_ID>
        <ms:NAZWA>403 044 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403044531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599189.860000 320692.593000</gml:lowerCorner>
        		<gml:upperCorner>599189.860000 320692.593000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599189.860000 320692.593000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 036 721</ms:GML_ID>
        <ms:NAZWA>403 036 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403036721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599219.846000 307749.146000</gml:lowerCorner>
        		<gml:upperCorner>599219.846000 307749.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599219.846000 307749.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 050 043</ms:GML_ID>
        <ms:NAZWA>403 050 043</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403050043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599251.669000 314382.052000</gml:lowerCorner>
        		<gml:upperCorner>599251.669000 314382.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599251.669000 314382.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 043 186</ms:GML_ID>
        <ms:NAZWA>403 043 186</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403043186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599408.442000 318947.607000</gml:lowerCorner>
        		<gml:upperCorner>599408.442000 318947.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599408.442000 318947.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 038 473</ms:GML_ID>
        <ms:NAZWA>403 038 473</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403038473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599564.829000 318197.614000</gml:lowerCorner>
        		<gml:upperCorner>599564.829000 318197.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599564.829000 318197.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 039 250</ms:GML_ID>
        <ms:NAZWA>403 039 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403039250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599741.441000 317351.682000</gml:lowerCorner>
        		<gml:upperCorner>599741.441000 317351.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599741.441000 317351.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 040 115</ms:GML_ID>
        <ms:NAZWA>403 040 115</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403040115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600656.926000 323815.774000</gml:lowerCorner>
        		<gml:upperCorner>600656.926000 323815.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600656.926000 323815.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 033 036</ms:GML_ID>
        <ms:NAZWA>403 033 036</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403033036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600997.531000 324156.085000</gml:lowerCorner>
        		<gml:upperCorner>600997.531000 324156.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600997.531000 324156.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 032 554</ms:GML_ID>
        <ms:NAZWA>403 032 554</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403032554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602064.211000 333242.748000</gml:lowerCorner>
        		<gml:upperCorner>602064.211000 333242.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602064.211000 333242.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 020 797</ms:GML_ID>
        <ms:NAZWA>403 020 797</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403020797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602571.355000 332787.857000</gml:lowerCorner>
        		<gml:upperCorner>602571.355000 332787.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602571.355000 332787.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 021 479</ms:GML_ID>
        <ms:NAZWA>403 021 479</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403021479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603208.940000 332409.430000</gml:lowerCorner>
        		<gml:upperCorner>603208.940000 332409.430000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603208.940000 332409.430000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 022 249</ms:GML_ID>
        <ms:NAZWA>403 022 249</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403022249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603618.940435 332384.405365</gml:lowerCorner>
        		<gml:upperCorner>603618.940435 332384.405365</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603618.940435 332384.405365</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 022 650</ms:GML_ID>
        <ms:NAZWA>403 022 650</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403022650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603644.692000 328352.407000</gml:lowerCorner>
        		<gml:upperCorner>603644.692000 328352.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603644.692000 328352.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 027 562</ms:GML_ID>
        <ms:NAZWA>403 027 562</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403027562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603837.058000 328952.369000</gml:lowerCorner>
        		<gml:upperCorner>603837.058000 328952.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603837.058000 328952.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 026 933</ms:GML_ID>
        <ms:NAZWA>403 026 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403026933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603909.784000 329178.091000</gml:lowerCorner>
        		<gml:upperCorner>603909.784000 329178.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603909.784000 329178.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 026 697</ms:GML_ID>
        <ms:NAZWA>403 026 697</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403026697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583835.614393 349197.370126</gml:lowerCorner>
        		<gml:upperCorner>583835.614393 349197.370126</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583835.614393 349197.370126</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 037 615</ms:GML_ID>
        <ms:NAZWA>374 037 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374037615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584330.495000 358234.824000</gml:lowerCorner>
        		<gml:upperCorner>584330.495000 358234.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584330.495000 358234.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 236 841</ms:GML_ID>
        <ms:NAZWA>018 236 841</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018236841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584863.452590 357157.741590</gml:lowerCorner>
        		<gml:upperCorner>584863.452590 357157.741590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584863.452590 357157.741590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 238 049</ms:GML_ID>
        <ms:NAZWA>018 238 049</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018238049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585210.998889 349592.257513</gml:lowerCorner>
        		<gml:upperCorner>585210.998889 349592.257513</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585210.998889 349592.257513</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 039 051</ms:GML_ID>
        <ms:NAZWA>374 039 051</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374039051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586595.023757 352278.279653</gml:lowerCorner>
        		<gml:upperCorner>586595.023757 352278.279653</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586595.023757 352278.279653</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 088 558</ms:GML_ID>
        <ms:NAZWA>354 088 558</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>354088558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587504.361000 349899.344000</gml:lowerCorner>
        		<gml:upperCorner>587504.361000 349899.344000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587504.361000 349899.344000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 041 368</ms:GML_ID>
        <ms:NAZWA>374 041 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374041368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587520.564000 352836.715000</gml:lowerCorner>
        		<gml:upperCorner>587520.564000 352836.715000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587520.564000 352836.715000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 243 252</ms:GML_ID>
        <ms:NAZWA>018 243 252</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018243252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588175.926282 349847.663694</gml:lowerCorner>
        		<gml:upperCorner>588175.926282 349847.663694</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588175.926282 349847.663694</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 042 049</ms:GML_ID>
        <ms:NAZWA>374 042 049</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374042049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588373.748000 347967.896000</gml:lowerCorner>
        		<gml:upperCorner>588373.748000 347967.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588373.748000 347967.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 001 285</ms:GML_ID>
        <ms:NAZWA>405 001 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405001285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588420.587000 350616.199000</gml:lowerCorner>
        		<gml:upperCorner>588420.587000 350616.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588420.587000 350616.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 245 668</ms:GML_ID>
        <ms:NAZWA>018 245 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018245668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588538.425000 350226.651000</gml:lowerCorner>
        		<gml:upperCorner>588538.425000 350226.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588538.425000 350226.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 246 077</ms:GML_ID>
        <ms:NAZWA>018 246 077</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018246077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588835.499339 348935.931435</gml:lowerCorner>
        		<gml:upperCorner>588835.499339 348935.931435</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588835.499339 348935.931435</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 179 774</ms:GML_ID>
        <ms:NAZWA>203 179 774</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203179774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588860.509459 349830.427845</gml:lowerCorner>
        		<gml:upperCorner>588860.509459 349830.427845</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588860.509459 349830.427845</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 178 862</ms:GML_ID>
        <ms:NAZWA>203 178 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203178862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588877.463832 349935.987285</gml:lowerCorner>
        		<gml:upperCorner>588877.463832 349935.987285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588877.463832 349935.987285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 178 756</ms:GML_ID>
        <ms:NAZWA>203 178 756</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203178756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589371.144347 350603.292878</gml:lowerCorner>
        		<gml:upperCorner>589371.144347 350603.292878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589371.144347 350603.292878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 177 879</ms:GML_ID>
        <ms:NAZWA>203 177 879</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203177879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589715.526035 350786.533178</gml:lowerCorner>
        		<gml:upperCorner>589715.526035 350786.533178</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589715.526035 350786.533178</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 177 487</ms:GML_ID>
        <ms:NAZWA>203 177 487</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203177487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591028.531119 351481.285085</gml:lowerCorner>
        		<gml:upperCorner>591028.531119 351481.285085</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591028.531119 351481.285085</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 175 995</ms:GML_ID>
        <ms:NAZWA>203 175 995</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203175995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591498.103000 351762.127000</gml:lowerCorner>
        		<gml:upperCorner>591498.103000 351762.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591498.103000 351762.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 175 454</ms:GML_ID>
        <ms:NAZWA>203 175 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203175454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596331.717000 357127.499000</gml:lowerCorner>
        		<gml:upperCorner>596331.717000 357127.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596331.717000 357127.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 168 220</ms:GML_ID>
        <ms:NAZWA>203 168 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203168220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597160.144000 358089.374000</gml:lowerCorner>
        		<gml:upperCorner>597160.144000 358089.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597160.144000 358089.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 166 951</ms:GML_ID>
        <ms:NAZWA>203 166 951</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203166951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597766.159000 358709.667000</gml:lowerCorner>
        		<gml:upperCorner>597766.159000 358709.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597766.159000 358709.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 166 083</ms:GML_ID>
        <ms:NAZWA>203 166 083</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203166083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600099.883000 361095.703000</gml:lowerCorner>
        		<gml:upperCorner>600099.883000 361095.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600099.883000 361095.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 162 744</ms:GML_ID>
        <ms:NAZWA>203 162 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203162744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600639.354000 347953.329000</gml:lowerCorner>
        		<gml:upperCorner>600639.354000 347953.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600639.354000 347953.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 016 300</ms:GML_ID>
        <ms:NAZWA>405 016 300</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405016300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602086.650000 363345.802000</gml:lowerCorner>
        		<gml:upperCorner>602086.650000 363345.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602086.650000 363345.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 159 732</ms:GML_ID>
        <ms:NAZWA>203 159 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203159732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602812.281000 364224.354000</gml:lowerCorner>
        		<gml:upperCorner>602812.281000 364224.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602812.281000 364224.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 158 593</ms:GML_ID>
        <ms:NAZWA>203 158 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203158593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603102.377000 364560.202000</gml:lowerCorner>
        		<gml:upperCorner>603102.377000 364560.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603102.377000 364560.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 158 148</ms:GML_ID>
        <ms:NAZWA>203 158 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203158148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604093.816064 365689.573081</gml:lowerCorner>
        		<gml:upperCorner>604093.816064 365689.573081</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604093.816064 365689.573081</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 156 646</ms:GML_ID>
        <ms:NAZWA>203 156 646</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203156646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575235.675791 194369.616087</gml:lowerCorner>
        		<gml:upperCorner>575235.675791 194369.616087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575235.675791 194369.616087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 299 718</ms:GML_ID>
        <ms:NAZWA>273 299 718</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273299718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575955.193042 194262.515275</gml:lowerCorner>
        		<gml:upperCorner>575955.193042 194262.515275</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575955.193042 194262.515275</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 300 436</ms:GML_ID>
        <ms:NAZWA>273 300 436</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273300436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580071.827000 227385.496000</gml:lowerCorner>
        		<gml:upperCorner>580071.827000 227385.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580071.827000 227385.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 015 965</ms:GML_ID>
        <ms:NAZWA>422 015 965</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422015965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580617.096000 227002.425000</gml:lowerCorner>
        		<gml:upperCorner>580617.096000 227002.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580617.096000 227002.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 015 305</ms:GML_ID>
        <ms:NAZWA>422 015 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422015305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583774.333000 226114.070000</gml:lowerCorner>
        		<gml:upperCorner>583774.333000 226114.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583774.333000 226114.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 012 016</ms:GML_ID>
        <ms:NAZWA>422 012 016</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422012016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584108.977000 225974.092000</gml:lowerCorner>
        		<gml:upperCorner>584108.977000 225974.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584108.977000 225974.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 011 653</ms:GML_ID>
        <ms:NAZWA>422 011 653</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422011653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584629.331000 195493.477000</gml:lowerCorner>
        		<gml:upperCorner>584629.331000 195493.477000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584629.331000 195493.477000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 309 495</ms:GML_ID>
        <ms:NAZWA>273 309 495</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273309495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585184.217000 225835.644000</gml:lowerCorner>
        		<gml:upperCorner>585184.217000 225835.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585184.217000 225835.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 010 561</ms:GML_ID>
        <ms:NAZWA>422 010 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422010561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586154.715000 225381.926000</gml:lowerCorner>
        		<gml:upperCorner>586154.715000 225381.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586154.715000 225381.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 009 470</ms:GML_ID>
        <ms:NAZWA>422 009 470</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422009470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586821.202000 224963.268000</gml:lowerCorner>
        		<gml:upperCorner>586821.202000 224963.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586821.202000 224963.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 008 683</ms:GML_ID>
        <ms:NAZWA>422 008 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422008683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587388.887000 195980.688000</gml:lowerCorner>
        		<gml:upperCorner>587388.887000 195980.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587388.887000 195980.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 312 313</ms:GML_ID>
        <ms:NAZWA>273 312 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273312313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589055.357000 224412.392000</gml:lowerCorner>
        		<gml:upperCorner>589055.357000 224412.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589055.357000 224412.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 006 375</ms:GML_ID>
        <ms:NAZWA>422 006 375</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422006375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590237.820000 224179.934000</gml:lowerCorner>
        		<gml:upperCorner>590237.820000 224179.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590237.820000 224179.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 005 160</ms:GML_ID>
        <ms:NAZWA>422 005 160</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422005160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590250.340548 195649.537834</gml:lowerCorner>
        		<gml:upperCorner>590250.340548 195649.537834</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590250.340548 195649.537834</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 315 195</ms:GML_ID>
        <ms:NAZWA>273 315 195</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273315195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590990.784000 224093.074000</gml:lowerCorner>
        		<gml:upperCorner>590990.784000 224093.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590990.784000 224093.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 004 413</ms:GML_ID>
        <ms:NAZWA>422 004 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422004413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591126.666071 195380.812367</gml:lowerCorner>
        		<gml:upperCorner>591126.666071 195380.812367</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591126.666071 195380.812367</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 316 110</ms:GML_ID>
        <ms:NAZWA>273 316 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273316110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593194.539000 223838.914000</gml:lowerCorner>
        		<gml:upperCorner>593194.539000 223838.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593194.539000 223838.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 002 195</ms:GML_ID>
        <ms:NAZWA>422 002 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422002195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594160.797000 224062.278000</gml:lowerCorner>
        		<gml:upperCorner>594160.797000 224062.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594160.797000 224062.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 001 177</ms:GML_ID>
        <ms:NAZWA>422 001 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422001177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594961.038000 225094.168000</gml:lowerCorner>
        		<gml:upperCorner>594961.038000 225094.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594961.038000 225094.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 024 852</ms:GML_ID>
        <ms:NAZWA>411 024 852</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411024852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595108.450000 225305.104000</gml:lowerCorner>
        		<gml:upperCorner>595108.450000 225305.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595108.450000 225305.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 024 593</ms:GML_ID>
        <ms:NAZWA>411 024 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411024593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562890.113000 295756.557000</gml:lowerCorner>
        		<gml:upperCorner>562890.113000 295756.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562890.113000 295756.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 089 099</ms:GML_ID>
        <ms:NAZWA>351 089 099</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351089099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563309.570000 305465.726000</gml:lowerCorner>
        		<gml:upperCorner>563309.570000 305465.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563309.570000 305465.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 231 497</ms:GML_ID>
        <ms:NAZWA>203 231 497</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203231497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563399.840444 294934.619645</gml:lowerCorner>
        		<gml:upperCorner>563399.840444 294934.619645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563399.840444 294934.619645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 090 071</ms:GML_ID>
        <ms:NAZWA>351 090 071</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351090071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568073.814963 290075.046833</gml:lowerCorner>
        		<gml:upperCorner>568073.814963 290075.046833</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568073.814963 290075.046833</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 097 231</ms:GML_ID>
        <ms:NAZWA>351 097 231</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351097231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569774.148711 286922.108271</gml:lowerCorner>
        		<gml:upperCorner>569774.148711 286922.108271</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569774.148711 286922.108271</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 100 813</ms:GML_ID>
        <ms:NAZWA>351 100 813</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351100813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571804.126000 281841.592000</gml:lowerCorner>
        		<gml:upperCorner>571804.126000 281841.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571804.126000 281841.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 106 411</ms:GML_ID>
        <ms:NAZWA>351 106 411</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351106411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572299.391517 281204.656937</gml:lowerCorner>
        		<gml:upperCorner>572299.391517 281204.656937</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572299.391517 281204.656937</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 107 213</ms:GML_ID>
        <ms:NAZWA>351 107 213</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351107213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596836.557875 277824.917255</gml:lowerCorner>
        		<gml:upperCorner>596836.557875 277824.917255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596836.557875 277824.917255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 123 928</ms:GML_ID>
        <ms:NAZWA>410 123 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410123928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597100.698000 278541.828000</gml:lowerCorner>
        		<gml:upperCorner>597100.698000 278541.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597100.698000 278541.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 123 164</ms:GML_ID>
        <ms:NAZWA>410 123 164</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410123164</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597531.131000 279487.153000</gml:lowerCorner>
        		<gml:upperCorner>597531.131000 279487.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597531.131000 279487.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 122 120</ms:GML_ID>
        <ms:NAZWA>410 122 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410122120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598027.674000 282981.910000</gml:lowerCorner>
        		<gml:upperCorner>598027.674000 282981.910000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598027.674000 282981.910000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 118 468</ms:GML_ID>
        <ms:NAZWA>410 118 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410118468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598093.897000 280818.188000</gml:lowerCorner>
        		<gml:upperCorner>598093.897000 280818.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598093.897000 280818.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 120 671</ms:GML_ID>
        <ms:NAZWA>410 120 671</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410120671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599198.494259 284371.420714</gml:lowerCorner>
        		<gml:upperCorner>599198.494259 284371.420714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599198.494259 284371.420714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 116 621</ms:GML_ID>
        <ms:NAZWA>410 116 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410116621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599493.142665 307027.616189</gml:lowerCorner>
        		<gml:upperCorner>599493.142665 307027.616189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599493.142665 307027.616189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 050 813</ms:GML_ID>
        <ms:NAZWA>403 050 813</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403050813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599791.908000 303827.218000</gml:lowerCorner>
        		<gml:upperCorner>599791.908000 303827.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599791.908000 303827.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 054 054</ms:GML_ID>
        <ms:NAZWA>403 054 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403054054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600593.082044 286157.733572</gml:lowerCorner>
        		<gml:upperCorner>600593.082044 286157.733572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600593.082044 286157.733572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 114 352</ms:GML_ID>
        <ms:NAZWA>410 114 352</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410114352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601379.473000 286898.753000</gml:lowerCorner>
        		<gml:upperCorner>601379.473000 286898.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601379.473000 286898.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 113 250</ms:GML_ID>
        <ms:NAZWA>410 113 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410113250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602252.481000 287742.890000</gml:lowerCorner>
        		<gml:upperCorner>602252.481000 287742.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602252.481000 287742.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 112 014</ms:GML_ID>
        <ms:NAZWA>410 112 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410112014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603314.775849 297067.329858</gml:lowerCorner>
        		<gml:upperCorner>603314.775849 297067.329858</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603314.775849 297067.329858</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 061 843</ms:GML_ID>
        <ms:NAZWA>403 061 843</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403061843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603553.212000 296311.868000</gml:lowerCorner>
        		<gml:upperCorner>603553.212000 296311.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603553.212000 296311.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 062 634</ms:GML_ID>
        <ms:NAZWA>403 062 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403062634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598121.071000 227911.581000</gml:lowerCorner>
        		<gml:upperCorner>598121.071000 227911.581000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598121.071000 227911.581000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 020 597</ms:GML_ID>
        <ms:NAZWA>411 020 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411020597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578892.044000 228219.087000</gml:lowerCorner>
        		<gml:upperCorner>578892.044000 228219.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578892.044000 228219.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 017 410</ms:GML_ID>
        <ms:NAZWA>422 017 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422017410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598691.955000 228446.915000</gml:lowerCorner>
        		<gml:upperCorner>598691.955000 228446.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598691.955000 228446.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 019 813</ms:GML_ID>
        <ms:NAZWA>411 019 813</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411019813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578061.522000 228813.718000</gml:lowerCorner>
        		<gml:upperCorner>578061.522000 228813.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578061.522000 228813.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 018 431</ms:GML_ID>
        <ms:NAZWA>422 018 431</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422018431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574102.426000 228820.628000</gml:lowerCorner>
        		<gml:upperCorner>574102.426000 228820.628000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574102.426000 228820.628000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 022 636</ms:GML_ID>
        <ms:NAZWA>422 022 636</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422022636</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574684.954000 229027.658000</gml:lowerCorner>
        		<gml:upperCorner>574684.954000 229027.658000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574684.954000 229027.658000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 022 017</ms:GML_ID>
        <ms:NAZWA>422 022 017</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422022017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577551.416000 229074.306000</gml:lowerCorner>
        		<gml:upperCorner>577551.416000 229074.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577551.416000 229074.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 019 005</ms:GML_ID>
        <ms:NAZWA>422 019 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422019005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575096.430000 229158.324000</gml:lowerCorner>
        		<gml:upperCorner>575096.430000 229158.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575096.430000 229158.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 021 584</ms:GML_ID>
        <ms:NAZWA>422 021 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422021584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599601.085000 229299.029000</gml:lowerCorner>
        		<gml:upperCorner>599601.085000 229299.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599601.085000 229299.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 018 566</ms:GML_ID>
        <ms:NAZWA>411 018 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411018566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575618.245000 229323.539000</gml:lowerCorner>
        		<gml:upperCorner>575618.245000 229323.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575618.245000 229323.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 021 058</ms:GML_ID>
        <ms:NAZWA>422 021 058</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422021058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576819.767000 229426.097000</gml:lowerCorner>
        		<gml:upperCorner>576819.767000 229426.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576819.767000 229426.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.422 019 825</ms:GML_ID>
        <ms:NAZWA>422 019 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>422019825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601794.398000 229907.384000</gml:lowerCorner>
        		<gml:upperCorner>601794.398000 229907.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601794.398000 229907.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 015 863</ms:GML_ID>
        <ms:NAZWA>411 015 863</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411015863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602938.818000 229944.755000</gml:lowerCorner>
        		<gml:upperCorner>602938.818000 229944.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602938.818000 229944.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.411 014 638</ms:GML_ID>
        <ms:NAZWA>411 014 638</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>411014638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601721.320000 243417.724000</gml:lowerCorner>
        		<gml:upperCorner>601721.320000 243417.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601721.320000 243417.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 157 283</ms:GML_ID>
        <ms:NAZWA>351 157 283</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351157283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599408.632478 246820.284613</gml:lowerCorner>
        		<gml:upperCorner>599408.632478 246820.284613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599408.632478 246820.284613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 153 082</ms:GML_ID>
        <ms:NAZWA>351 153 082</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351153082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595475.678409 252919.636437</gml:lowerCorner>
        		<gml:upperCorner>595475.678409 252919.636437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595475.678409 252919.636437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 145 719</ms:GML_ID>
        <ms:NAZWA>351 145 719</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351145719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594966.971000 255847.789000</gml:lowerCorner>
        		<gml:upperCorner>594966.971000 255847.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594966.971000 255847.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 142 684</ms:GML_ID>
        <ms:NAZWA>351 142 684</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351142684</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593821.592688 260401.628920</gml:lowerCorner>
        		<gml:upperCorner>593821.592688 260401.628920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593821.592688 260401.628920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 137 397</ms:GML_ID>
        <ms:NAZWA>351 137 397</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351137397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593232.580000 260846.081000</gml:lowerCorner>
        		<gml:upperCorner>593232.580000 260846.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593232.580000 260846.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 141 593</ms:GML_ID>
        <ms:NAZWA>410 141 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410141593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593231.291000 262023.408000</gml:lowerCorner>
        		<gml:upperCorner>593231.291000 262023.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593231.291000 262023.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 140 286</ms:GML_ID>
        <ms:NAZWA>410 140 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410140286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591052.794000 262939.412000</gml:lowerCorner>
        		<gml:upperCorner>591052.794000 262939.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591052.794000 262939.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 133 629</ms:GML_ID>
        <ms:NAZWA>351 133 629</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351133629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593218.660000 263450.874000</gml:lowerCorner>
        		<gml:upperCorner>593218.660000 263450.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593218.660000 263450.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 138 949</ms:GML_ID>
        <ms:NAZWA>410 138 949</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410138949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553454.308161 263623.161975</gml:lowerCorner>
        		<gml:upperCorner>553454.308161 263623.161975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553454.308161 263623.161975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 275 990</ms:GML_ID>
        <ms:NAZWA>203 275 990</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203275990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593273.768000 264091.026000</gml:lowerCorner>
        		<gml:upperCorner>593273.768000 264091.026000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593273.768000 264091.026000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 138 302</ms:GML_ID>
        <ms:NAZWA>410 138 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410138302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553781.979000 264195.253000</gml:lowerCorner>
        		<gml:upperCorner>553781.979000 264195.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553781.979000 264195.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 275 333</ms:GML_ID>
        <ms:NAZWA>203 275 333</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203275333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

