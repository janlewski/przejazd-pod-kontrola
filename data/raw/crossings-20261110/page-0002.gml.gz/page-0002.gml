<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:18" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=1000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=3000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>158043.371000 531384.500000</gml:lowerCorner>
      		<gml:upperCorner>535314.525691 776436.914910</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209537.214881 673536.976189</gml:lowerCorner>
        		<gml:upperCorner>209537.214881 673536.976189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209537.214881 673536.976189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 040 311</ms:GML_ID>
        <ms:NAZWA>108 040 311</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108040311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209136.139364 674230.805572</gml:lowerCorner>
        		<gml:upperCorner>209136.139364 674230.805572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209136.139364 674230.805572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 041 112</ms:GML_ID>
        <ms:NAZWA>108 041 112</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108041112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208743.039000 675060.295000</gml:lowerCorner>
        		<gml:upperCorner>208743.039000 675060.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208743.039000 675060.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 042 046</ms:GML_ID>
        <ms:NAZWA>108 042 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108042046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208865.439000 675644.151000</gml:lowerCorner>
        		<gml:upperCorner>208865.439000 675644.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208865.439000 675644.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 042 658</ms:GML_ID>
        <ms:NAZWA>108 042 658</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108042658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209109.873000 676007.600000</gml:lowerCorner>
        		<gml:upperCorner>209109.873000 676007.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209109.873000 676007.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 043 097</ms:GML_ID>
        <ms:NAZWA>108 043 097</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108043097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209357.005000 676456.459000</gml:lowerCorner>
        		<gml:upperCorner>209357.005000 676456.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209357.005000 676456.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 043 612</ms:GML_ID>
        <ms:NAZWA>108 043 612</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108043612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209445.591000 676682.296000</gml:lowerCorner>
        		<gml:upperCorner>209445.591000 676682.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209445.591000 676682.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 043 855</ms:GML_ID>
        <ms:NAZWA>108 043 855</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108043855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209904.561000 677498.309000</gml:lowerCorner>
        		<gml:upperCorner>209904.561000 677498.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209904.561000 677498.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 044 805</ms:GML_ID>
        <ms:NAZWA>108 044 805</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108044805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210189.950000 677555.969000</gml:lowerCorner>
        		<gml:upperCorner>210189.950000 677555.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210189.950000 677555.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 045 099</ms:GML_ID>
        <ms:NAZWA>108 045 099</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108045099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210522.632517 677692.474122</gml:lowerCorner>
        		<gml:upperCorner>210522.632517 677692.474122</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210522.632517 677692.474122</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 045 472</ms:GML_ID>
        <ms:NAZWA>108 045 472</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108045472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207934.025438 694965.656578</gml:lowerCorner>
        		<gml:upperCorner>207934.025438 694965.656578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207934.025438 694965.656578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 064 853</ms:GML_ID>
        <ms:NAZWA>108 064 853</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108064853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208178.992000 694378.399000</gml:lowerCorner>
        		<gml:upperCorner>208178.992000 694378.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208178.992000 694378.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 064 217</ms:GML_ID>
        <ms:NAZWA>108 064 217</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108064217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208349.581402 693654.533477</gml:lowerCorner>
        		<gml:upperCorner>208349.581402 693654.533477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208349.581402 693654.533477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 063 471</ms:GML_ID>
        <ms:NAZWA>108 063 471</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108063471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209012.706163 690982.265400</gml:lowerCorner>
        		<gml:upperCorner>209012.706163 690982.265400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209012.706163 690982.265400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 060 714</ms:GML_ID>
        <ms:NAZWA>108 060 714</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108060714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209327.419000 689900.402000</gml:lowerCorner>
        		<gml:upperCorner>209327.419000 689900.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209327.419000 689900.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 059 510</ms:GML_ID>
        <ms:NAZWA>108 059 510</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108059510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209369.614395 690286.964293</gml:lowerCorner>
        		<gml:upperCorner>209369.614395 690286.964293</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209369.614395 690286.964293</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 059 931</ms:GML_ID>
        <ms:NAZWA>108 059 931</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108059931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213622.260000 689806.416000</gml:lowerCorner>
        		<gml:upperCorner>213622.260000 689806.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213622.260000 689806.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 057 442</ms:GML_ID>
        <ms:NAZWA>106 057 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106057442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214021.313000 690306.394000</gml:lowerCorner>
        		<gml:upperCorner>214021.313000 690306.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214021.313000 690306.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 056 803</ms:GML_ID>
        <ms:NAZWA>106 056 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106056803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214657.094000 690910.978000</gml:lowerCorner>
        		<gml:upperCorner>214657.094000 690910.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214657.094000 690910.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 055 924</ms:GML_ID>
        <ms:NAZWA>106 055 924</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106055924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215028.216000 691256.863000</gml:lowerCorner>
        		<gml:upperCorner>215028.216000 691256.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215028.216000 691256.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 055 417</ms:GML_ID>
        <ms:NAZWA>106 055 417</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106055417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215420.123000 691388.108000</gml:lowerCorner>
        		<gml:upperCorner>215420.123000 691388.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215420.123000 691388.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 054 995</ms:GML_ID>
        <ms:NAZWA>106 054 995</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106054995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217288.556000 691003.142000</gml:lowerCorner>
        		<gml:upperCorner>217288.556000 691003.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217288.556000 691003.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 052 871</ms:GML_ID>
        <ms:NAZWA>106 052 871</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106052871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218371.896000 690045.712000</gml:lowerCorner>
        		<gml:upperCorner>218371.896000 690045.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218371.896000 690045.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 051 418</ms:GML_ID>
        <ms:NAZWA>106 051 418</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106051418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219240.471000 689634.339000</gml:lowerCorner>
        		<gml:upperCorner>219240.471000 689634.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219240.471000 689634.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 050 446</ms:GML_ID>
        <ms:NAZWA>106 050 446</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106050446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224865.629000 689286.310000</gml:lowerCorner>
        		<gml:upperCorner>224865.629000 689286.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224865.629000 689286.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 043 551</ms:GML_ID>
        <ms:NAZWA>106 043 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106043551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225099.284000 689852.415000</gml:lowerCorner>
        		<gml:upperCorner>225099.284000 689852.415000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225099.284000 689852.415000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 042 936</ms:GML_ID>
        <ms:NAZWA>106 042 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106042936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225247.087000 690153.333000</gml:lowerCorner>
        		<gml:upperCorner>225247.087000 690153.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225247.087000 690153.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 042 602</ms:GML_ID>
        <ms:NAZWA>106 042 602</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106042602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225586.731000 690734.550000</gml:lowerCorner>
        		<gml:upperCorner>225586.731000 690734.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225586.731000 690734.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 041 929</ms:GML_ID>
        <ms:NAZWA>106 041 929</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106041929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225750.771000 691186.434000</gml:lowerCorner>
        		<gml:upperCorner>225750.771000 691186.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225750.771000 691186.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 041 444</ms:GML_ID>
        <ms:NAZWA>106 041 444</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106041444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225830.763000 692121.246000</gml:lowerCorner>
        		<gml:upperCorner>225830.763000 692121.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225830.763000 692121.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.106 040 505</ms:GML_ID>
        <ms:NAZWA>106 040 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>106040505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206345.894000 639767.670000</gml:lowerCorner>
        		<gml:upperCorner>206345.894000 639767.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206345.894000 639767.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 049 123</ms:GML_ID>
        <ms:NAZWA>096 049 123</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096049123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210701.572000 639914.096000</gml:lowerCorner>
        		<gml:upperCorner>210701.572000 639914.096000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210701.572000 639914.096000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 043 202</ms:GML_ID>
        <ms:NAZWA>096 043 202</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096043202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211539.626000 640470.653000</gml:lowerCorner>
        		<gml:upperCorner>211539.626000 640470.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211539.626000 640470.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 042 118</ms:GML_ID>
        <ms:NAZWA>096 042 118</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096042118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206844.237845 640792.314972</gml:lowerCorner>
        		<gml:upperCorner>206844.237845 640792.314972</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206844.237845 640792.314972</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 047 925</ms:GML_ID>
        <ms:NAZWA>096 047 925</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096047925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213941.352000 640812.594000</gml:lowerCorner>
        		<gml:upperCorner>213941.352000 640812.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213941.352000 640812.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 039 282</ms:GML_ID>
        <ms:NAZWA>096 039 282</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096039282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214397.244000 640851.858000</gml:lowerCorner>
        		<gml:upperCorner>214397.244000 640851.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214397.244000 640851.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 038 815</ms:GML_ID>
        <ms:NAZWA>096 038 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096038815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212411.817000 640891.038000</gml:lowerCorner>
        		<gml:upperCorner>212411.817000 640891.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212411.817000 640891.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 041 053</ms:GML_ID>
        <ms:NAZWA>096 041 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096041053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209741.204277 640964.565209</gml:lowerCorner>
        		<gml:upperCorner>209741.204277 640964.565209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209741.204277 640964.565209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 044 779</ms:GML_ID>
        <ms:NAZWA>096 044 779</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096044779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214898.014000 640974.449000</gml:lowerCorner>
        		<gml:upperCorner>214898.014000 640974.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214898.014000 640974.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 038 300</ms:GML_ID>
        <ms:NAZWA>096 038 300</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096038300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207542.641000 641210.763000</gml:lowerCorner>
        		<gml:upperCorner>207542.641000 641210.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207542.641000 641210.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 047 110</ms:GML_ID>
        <ms:NAZWA>096 047 110</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096047110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209262.495000 641235.814000</gml:lowerCorner>
        		<gml:upperCorner>209262.495000 641235.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209262.495000 641235.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 045 335</ms:GML_ID>
        <ms:NAZWA>096 045 335</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096045335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208793.702000 641335.117000</gml:lowerCorner>
        		<gml:upperCorner>208793.702000 641335.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208793.702000 641335.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 045 815</ms:GML_ID>
        <ms:NAZWA>096 045 815</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096045815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208024.008338 641372.629228</gml:lowerCorner>
        		<gml:upperCorner>208024.008338 641372.629228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208024.008338 641372.629228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 046 599</ms:GML_ID>
        <ms:NAZWA>096 046 599</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096046599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205566.629000 654324.942000</gml:lowerCorner>
        		<gml:upperCorner>205566.629000 654324.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205566.629000 654324.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 016 105</ms:GML_ID>
        <ms:NAZWA>108 016 105</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108016105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205583.531000 655258.370000</gml:lowerCorner>
        		<gml:upperCorner>205583.531000 655258.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205583.531000 655258.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 017 081</ms:GML_ID>
        <ms:NAZWA>108 017 081</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108017081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205820.798000 658894.647000</gml:lowerCorner>
        		<gml:upperCorner>205820.798000 658894.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205820.798000 658894.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 021 086</ms:GML_ID>
        <ms:NAZWA>108 021 086</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108021086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206262.549000 659400.541000</gml:lowerCorner>
        		<gml:upperCorner>206262.549000 659400.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206262.549000 659400.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 021 757</ms:GML_ID>
        <ms:NAZWA>108 021 757</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108021757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206789.028761 660358.071501</gml:lowerCorner>
        		<gml:upperCorner>206789.028761 660358.071501</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206789.028761 660358.071501</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 022 891</ms:GML_ID>
        <ms:NAZWA>108 022 891</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108022891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206911.135504 660883.172761</gml:lowerCorner>
        		<gml:upperCorner>206911.135504 660883.172761</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206911.135504 660883.172761</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 023 438</ms:GML_ID>
        <ms:NAZWA>108 023 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108023438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207777.251382 661526.307778</gml:lowerCorner>
        		<gml:upperCorner>207777.251382 661526.307778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207777.251382 661526.307778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 024 668</ms:GML_ID>
        <ms:NAZWA>108 024 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108024668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208511.591000 661547.193000</gml:lowerCorner>
        		<gml:upperCorner>208511.591000 661547.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208511.591000 661547.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 025 404</ms:GML_ID>
        <ms:NAZWA>108 025 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108025404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209428.870656 662499.821503</gml:lowerCorner>
        		<gml:upperCorner>209428.870656 662499.821503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209428.870656 662499.821503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 026 884</ms:GML_ID>
        <ms:NAZWA>108 026 884</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108026884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209997.768833 663472.731084</gml:lowerCorner>
        		<gml:upperCorner>209997.768833 663472.731084</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209997.768833 663472.731084</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 028 020</ms:GML_ID>
        <ms:NAZWA>108 028 020</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108028020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210328.982612 663960.376548</gml:lowerCorner>
        		<gml:upperCorner>210328.982612 663960.376548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210328.982612 663960.376548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 028 610</ms:GML_ID>
        <ms:NAZWA>108 028 610</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108028610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210669.754954 664192.983888</gml:lowerCorner>
        		<gml:upperCorner>210669.754954 664192.983888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210669.754954 664192.983888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 029 028</ms:GML_ID>
        <ms:NAZWA>108 029 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108029028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204132.898000 638791.560000</gml:lowerCorner>
        		<gml:upperCorner>204132.898000 638791.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204132.898000 638791.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 051 675</ms:GML_ID>
        <ms:NAZWA>096 051 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096051675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203405.696000 638852.321000</gml:lowerCorner>
        		<gml:upperCorner>203405.696000 638852.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203405.696000 638852.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 052 423</ms:GML_ID>
        <ms:NAZWA>096 052 423</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096052423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203008.259217 639401.094168</gml:lowerCorner>
        		<gml:upperCorner>203008.259217 639401.094168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203008.259217 639401.094168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 053 103</ms:GML_ID>
        <ms:NAZWA>096 053 103</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096053103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204976.305000 639447.938000</gml:lowerCorner>
        		<gml:upperCorner>204976.305000 639447.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204976.305000 639447.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 050 580</ms:GML_ID>
        <ms:NAZWA>096 050 580</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096050580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202741.015000 643750.986000</gml:lowerCorner>
        		<gml:upperCorner>202741.015000 643750.986000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202741.015000 643750.986000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 003 489</ms:GML_ID>
        <ms:NAZWA>108 003 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108003489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203035.365419 644760.488960</gml:lowerCorner>
        		<gml:upperCorner>203035.365419 644760.488960</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203035.365419 644760.488960</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 004 552</ms:GML_ID>
        <ms:NAZWA>108 004 552</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108004552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203277.811260 645755.757965</gml:lowerCorner>
        		<gml:upperCorner>203277.811260 645755.757965</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203277.811260 645755.757965</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 005 665</ms:GML_ID>
        <ms:NAZWA>108 005 665</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108005665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203187.570422 646105.749720</gml:lowerCorner>
        		<gml:upperCorner>203187.570422 646105.749720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203187.570422 646105.749720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 006 046</ms:GML_ID>
        <ms:NAZWA>108 006 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108006046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203074.588000 646754.335000</gml:lowerCorner>
        		<gml:upperCorner>203074.588000 646754.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203074.588000 646754.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 006 821</ms:GML_ID>
        <ms:NAZWA>108 006 821</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108006821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203705.785732 646879.768288</gml:lowerCorner>
        		<gml:upperCorner>203705.785732 646879.768288</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203705.785732 646879.768288</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 007 531</ms:GML_ID>
        <ms:NAZWA>108 007 531</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108007531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203883.948062 646906.540869</gml:lowerCorner>
        		<gml:upperCorner>203883.948062 646906.540869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203883.948062 646906.540869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 007 720</ms:GML_ID>
        <ms:NAZWA>108 007 720</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108007720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204020.075768 646972.422394</gml:lowerCorner>
        		<gml:upperCorner>204020.075768 646972.422394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204020.075768 646972.422394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 007 863</ms:GML_ID>
        <ms:NAZWA>108 007 863</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108007863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204424.742000 646993.001000</gml:lowerCorner>
        		<gml:upperCorner>204424.742000 646993.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204424.742000 646993.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 008 276</ms:GML_ID>
        <ms:NAZWA>108 008 276</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108008276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204983.320000 647714.576000</gml:lowerCorner>
        		<gml:upperCorner>204983.320000 647714.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204983.320000 647714.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 009 201</ms:GML_ID>
        <ms:NAZWA>108 009 201</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108009201</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204992.443876 648769.368707</gml:lowerCorner>
        		<gml:upperCorner>204992.443876 648769.368707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204992.443876 648769.368707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 010 270</ms:GML_ID>
        <ms:NAZWA>108 010 270</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108010270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205045.712000 648984.486000</gml:lowerCorner>
        		<gml:upperCorner>205045.712000 648984.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205045.712000 648984.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 010 495</ms:GML_ID>
        <ms:NAZWA>108 010 495</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108010495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205376.569620 649648.926638</gml:lowerCorner>
        		<gml:upperCorner>205376.569620 649648.926638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205376.569620 649648.926638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 011 263</ms:GML_ID>
        <ms:NAZWA>108 011 263</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108011263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205332.047000 651226.585000</gml:lowerCorner>
        		<gml:upperCorner>205332.047000 651226.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205332.047000 651226.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 012 845</ms:GML_ID>
        <ms:NAZWA>108 012 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108012845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205460.021000 652987.349000</gml:lowerCorner>
        		<gml:upperCorner>205460.021000 652987.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205460.021000 652987.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 014 678</ms:GML_ID>
        <ms:NAZWA>108 014 678</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108014678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205491.576000 656140.578000</gml:lowerCorner>
        		<gml:upperCorner>205491.576000 656140.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205491.576000 656140.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 017 970</ms:GML_ID>
        <ms:NAZWA>108 017 970</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108017970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205481.891761 656460.983921</gml:lowerCorner>
        		<gml:upperCorner>205481.891761 656460.983921</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205481.891761 656460.983921</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 018 291</ms:GML_ID>
        <ms:NAZWA>108 018 291</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108018291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202729.454492 656702.693877</gml:lowerCorner>
        		<gml:upperCorner>202729.454492 656702.693877</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202729.454492 656702.693877</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.110 003 047</ms:GML_ID>
        <ms:NAZWA>110 003 047</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>110003047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203790.761307 657489.010504</gml:lowerCorner>
        		<gml:upperCorner>203790.761307 657489.010504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203790.761307 657489.010504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.110 001 692</ms:GML_ID>
        <ms:NAZWA>110 001 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>110001692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204213.734000 657617.070000</gml:lowerCorner>
        		<gml:upperCorner>204213.734000 657617.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204213.734000 657617.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.110 001 249</ms:GML_ID>
        <ms:NAZWA>110 001 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>110001249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205052.576000 657786.082000</gml:lowerCorner>
        		<gml:upperCorner>205052.576000 657786.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205052.576000 657786.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 019 693</ms:GML_ID>
        <ms:NAZWA>108 019 693</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108019693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205053.756875 658043.827931</gml:lowerCorner>
        		<gml:upperCorner>205053.756875 658043.827931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205053.756875 658043.827931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 019 933</ms:GML_ID>
        <ms:NAZWA>108 019 933</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108019933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207800.170388 695278.413356</gml:lowerCorner>
        		<gml:upperCorner>207800.170388 695278.413356</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207800.170388 695278.413356</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 065 193</ms:GML_ID>
        <ms:NAZWA>108 065 193</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108065193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207620.471000 695698.725000</gml:lowerCorner>
        		<gml:upperCorner>207620.471000 695698.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207620.471000 695698.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 065 651</ms:GML_ID>
        <ms:NAZWA>108 065 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108065651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207421.851517 696162.087006</gml:lowerCorner>
        		<gml:upperCorner>207421.851517 696162.087006</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207421.851517 696162.087006</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 066 155</ms:GML_ID>
        <ms:NAZWA>108 066 155</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108066155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207032.134000 697072.289000</gml:lowerCorner>
        		<gml:upperCorner>207032.134000 697072.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207032.134000 697072.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 067 145</ms:GML_ID>
        <ms:NAZWA>108 067 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108067145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206785.345018 697648.927733</gml:lowerCorner>
        		<gml:upperCorner>206785.345018 697648.927733</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206785.345018 697648.927733</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 067 772</ms:GML_ID>
        <ms:NAZWA>108 067 772</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108067772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206375.431000 698559.037000</gml:lowerCorner>
        		<gml:upperCorner>206375.431000 698559.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206375.431000 698559.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 068 772</ms:GML_ID>
        <ms:NAZWA>108 068 772</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108068772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206105.469000 698932.160000</gml:lowerCorner>
        		<gml:upperCorner>206105.469000 698932.160000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206105.469000 698932.160000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 069 242</ms:GML_ID>
        <ms:NAZWA>108 069 242</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108069242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205843.021000 699091.701000</gml:lowerCorner>
        		<gml:upperCorner>205843.021000 699091.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205843.021000 699091.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 069 552</ms:GML_ID>
        <ms:NAZWA>108 069 552</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108069552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205521.533000 699718.044000</gml:lowerCorner>
        		<gml:upperCorner>205521.533000 699718.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205521.533000 699718.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 070 260</ms:GML_ID>
        <ms:NAZWA>108 070 260</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108070260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205427.433000 699880.475000</gml:lowerCorner>
        		<gml:upperCorner>205427.433000 699880.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205427.433000 699880.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 070 445</ms:GML_ID>
        <ms:NAZWA>108 070 445</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108070445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205245.880201 700143.733835</gml:lowerCorner>
        		<gml:upperCorner>205245.880201 700143.733835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205245.880201 700143.733835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 070 768</ms:GML_ID>
        <ms:NAZWA>108 070 768</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108070768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203226.322000 702004.163000</gml:lowerCorner>
        		<gml:upperCorner>203226.322000 702004.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203226.322000 702004.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 073 572</ms:GML_ID>
        <ms:NAZWA>108 073 572</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108073572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203043.754000 702232.632000</gml:lowerCorner>
        		<gml:upperCorner>203043.754000 702232.632000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203043.754000 702232.632000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 073 864</ms:GML_ID>
        <ms:NAZWA>108 073 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108073864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201989.122000 703474.374000</gml:lowerCorner>
        		<gml:upperCorner>201989.122000 703474.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201989.122000 703474.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 075 496</ms:GML_ID>
        <ms:NAZWA>108 075 496</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108075496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201408.175704 704064.932490</gml:lowerCorner>
        		<gml:upperCorner>201408.175704 704064.932490</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201408.175704 704064.932490</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 076 323</ms:GML_ID>
        <ms:NAZWA>108 076 323</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108076323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199939.485000 705551.102000</gml:lowerCorner>
        		<gml:upperCorner>199939.485000 705551.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199939.485000 705551.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 078 413</ms:GML_ID>
        <ms:NAZWA>108 078 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108078413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198856.231200 706720.182427</gml:lowerCorner>
        		<gml:upperCorner>198856.231200 706720.182427</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198856.231200 706720.182427</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 080 011</ms:GML_ID>
        <ms:NAZWA>108 080 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108080011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198630.055000 707097.337000</gml:lowerCorner>
        		<gml:upperCorner>198630.055000 707097.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198630.055000 707097.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 080 451</ms:GML_ID>
        <ms:NAZWA>108 080 451</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108080451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198314.708000 707404.259000</gml:lowerCorner>
        		<gml:upperCorner>198314.708000 707404.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198314.708000 707404.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 080 902</ms:GML_ID>
        <ms:NAZWA>108 080 902</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108080902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197725.167165 708476.086728</gml:lowerCorner>
        		<gml:upperCorner>197725.167165 708476.086728</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197725.167165 708476.086728</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 082 148</ms:GML_ID>
        <ms:NAZWA>108 082 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108082148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197530.161723 708766.065541</gml:lowerCorner>
        		<gml:upperCorner>197530.161723 708766.065541</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197530.161723 708766.065541</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 082 505</ms:GML_ID>
        <ms:NAZWA>108 082 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108082505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194218.115000 721095.472000</gml:lowerCorner>
        		<gml:upperCorner>194218.115000 721095.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194218.115000 721095.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 095 537</ms:GML_ID>
        <ms:NAZWA>108 095 537</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108095537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194572.038000 720228.625000</gml:lowerCorner>
        		<gml:upperCorner>194572.038000 720228.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194572.038000 720228.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 094 552</ms:GML_ID>
        <ms:NAZWA>108 094 552</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108094552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194613.745000 719969.246000</gml:lowerCorner>
        		<gml:upperCorner>194613.745000 719969.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194613.745000 719969.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 094 290</ms:GML_ID>
        <ms:NAZWA>108 094 290</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108094290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194704.914739 719505.904973</gml:lowerCorner>
        		<gml:upperCorner>194704.914739 719505.904973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194704.914739 719505.904973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 093 816</ms:GML_ID>
        <ms:NAZWA>108 093 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108093816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194863.956000 719007.154000</gml:lowerCorner>
        		<gml:upperCorner>194863.956000 719007.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194863.956000 719007.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 093 292</ms:GML_ID>
        <ms:NAZWA>108 093 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108093292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195182.194919 718014.781926</gml:lowerCorner>
        		<gml:upperCorner>195182.194919 718014.781926</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195182.194919 718014.781926</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 092 251</ms:GML_ID>
        <ms:NAZWA>108 092 251</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108092251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195273.331000 717647.673000</gml:lowerCorner>
        		<gml:upperCorner>195273.331000 717647.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195273.331000 717647.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 091 870</ms:GML_ID>
        <ms:NAZWA>108 091 870</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108091870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195276.382000 717487.333000</gml:lowerCorner>
        		<gml:upperCorner>195276.382000 717487.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195276.382000 717487.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 091 710</ms:GML_ID>
        <ms:NAZWA>108 091 710</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108091710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195292.144323 716517.352934</gml:lowerCorner>
        		<gml:upperCorner>195292.144323 716517.352934</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195292.144323 716517.352934</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 090 739</ms:GML_ID>
        <ms:NAZWA>108 090 739</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108090739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195302.893911 715855.159179</gml:lowerCorner>
        		<gml:upperCorner>195302.893911 715855.159179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195302.893911 715855.159179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 090 079</ms:GML_ID>
        <ms:NAZWA>108 090 079</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108090079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195326.751860 714385.356757</gml:lowerCorner>
        		<gml:upperCorner>195326.751860 714385.356757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195326.751860 714385.356757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 088 608</ms:GML_ID>
        <ms:NAZWA>108 088 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108088608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195522.020000 713781.126000</gml:lowerCorner>
        		<gml:upperCorner>195522.020000 713781.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195522.020000 713781.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 087 957</ms:GML_ID>
        <ms:NAZWA>108 087 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108087957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195680.815000 713533.438000</gml:lowerCorner>
        		<gml:upperCorner>195680.815000 713533.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195680.815000 713533.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 087 662</ms:GML_ID>
        <ms:NAZWA>108 087 662</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108087662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195776.086215 713384.044955</gml:lowerCorner>
        		<gml:upperCorner>195776.086215 713384.044955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195776.086215 713384.044955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 087 486</ms:GML_ID>
        <ms:NAZWA>108 087 486</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108087486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195968.797847 713062.888437</gml:lowerCorner>
        		<gml:upperCorner>195968.797847 713062.888437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195968.797847 713062.888437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 087 110</ms:GML_ID>
        <ms:NAZWA>108 087 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108087110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196229.024928 712158.649394</gml:lowerCorner>
        		<gml:upperCorner>196229.024928 712158.649394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196229.024928 712158.649394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 086 169</ms:GML_ID>
        <ms:NAZWA>108 086 169</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108086169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196429.243696 711438.862999</gml:lowerCorner>
        		<gml:upperCorner>196429.243696 711438.862999</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196429.243696 711438.862999</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 085 421</ms:GML_ID>
        <ms:NAZWA>108 085 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108085421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196596.022000 710839.817000</gml:lowerCorner>
        		<gml:upperCorner>196596.022000 710839.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196596.022000 710839.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 084 800</ms:GML_ID>
        <ms:NAZWA>108 084 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108084800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196768.163084 710389.594604</gml:lowerCorner>
        		<gml:upperCorner>196768.163084 710389.594604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196768.163084 710389.594604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 084 315</ms:GML_ID>
        <ms:NAZWA>108 084 315</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108084315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197226.353000 709566.673000</gml:lowerCorner>
        		<gml:upperCorner>197226.353000 709566.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197226.353000 709566.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 083 373</ms:GML_ID>
        <ms:NAZWA>108 083 373</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108083373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189457.398000 738558.044000</gml:lowerCorner>
        		<gml:upperCorner>189457.398000 738558.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189457.398000 738558.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 116 474</ms:GML_ID>
        <ms:NAZWA>108 116 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108116474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189919.561550 739347.378145</gml:lowerCorner>
        		<gml:upperCorner>189919.561550 739347.378145</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189919.561550 739347.378145</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 117 433</ms:GML_ID>
        <ms:NAZWA>108 117 433</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108117433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190155.353126 735174.725417</gml:lowerCorner>
        		<gml:upperCorner>190155.353126 735174.725417</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190155.353126 735174.725417</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 111 705</ms:GML_ID>
        <ms:NAZWA>108 111 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108111705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191247.373000 733349.671000</gml:lowerCorner>
        		<gml:upperCorner>191247.373000 733349.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191247.373000 733349.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 109 489</ms:GML_ID>
        <ms:NAZWA>108 109 489</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108109489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191845.318642 732669.891682</gml:lowerCorner>
        		<gml:upperCorner>191845.318642 732669.891682</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191845.318642 732669.891682</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 108 582</ms:GML_ID>
        <ms:NAZWA>108 108 582</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108108582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192333.096000 731600.642000</gml:lowerCorner>
        		<gml:upperCorner>192333.096000 731600.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192333.096000 731600.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 107 308</ms:GML_ID>
        <ms:NAZWA>108 107 308</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108107308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192396.171000 731778.413000</gml:lowerCorner>
        		<gml:upperCorner>192396.171000 731778.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192396.171000 731778.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 107 497</ms:GML_ID>
        <ms:NAZWA>108 107 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108107497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192411.980000 731844.249000</gml:lowerCorner>
        		<gml:upperCorner>192411.980000 731844.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192411.980000 731844.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 107 564</ms:GML_ID>
        <ms:NAZWA>108 107 564</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108107564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192589.513000 731172.013000</gml:lowerCorner>
        		<gml:upperCorner>192589.513000 731172.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192589.513000 731172.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 106 787</ms:GML_ID>
        <ms:NAZWA>108 106 787</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108106787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192855.051000 730767.271000</gml:lowerCorner>
        		<gml:upperCorner>192855.051000 730767.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192855.051000 730767.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 106 303</ms:GML_ID>
        <ms:NAZWA>108 106 303</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108106303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193128.041383 730336.217263</gml:lowerCorner>
        		<gml:upperCorner>193128.041383 730336.217263</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193128.041383 730336.217263</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 105 793</ms:GML_ID>
        <ms:NAZWA>108 105 793</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108105793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193472.502000 726873.854000</gml:lowerCorner>
        		<gml:upperCorner>193472.502000 726873.854000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193472.502000 726873.854000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 102 091</ms:GML_ID>
        <ms:NAZWA>108 102 091</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108102091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193530.880000 729478.630000</gml:lowerCorner>
        		<gml:upperCorner>193530.880000 729478.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193530.880000 729478.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 104 842</ms:GML_ID>
        <ms:NAZWA>108 104 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108104842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193645.969000 729261.848000</gml:lowerCorner>
        		<gml:upperCorner>193645.969000 729261.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193645.969000 729261.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 104 595</ms:GML_ID>
        <ms:NAZWA>108 104 595</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108104595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193748.915000 727620.235000</gml:lowerCorner>
        		<gml:upperCorner>193748.915000 727620.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193748.915000 727620.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 102 888</ms:GML_ID>
        <ms:NAZWA>108 102 888</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108102888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193800.968000 728931.069000</gml:lowerCorner>
        		<gml:upperCorner>193800.968000 728931.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193800.968000 728931.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 104 229</ms:GML_ID>
        <ms:NAZWA>108 104 229</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108104229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193859.701000 728285.265000</gml:lowerCorner>
        		<gml:upperCorner>193859.701000 728285.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193859.701000 728285.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 103 565</ms:GML_ID>
        <ms:NAZWA>108 103 565</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108103565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193893.786608 728643.054676</gml:lowerCorner>
        		<gml:upperCorner>193893.786608 728643.054676</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193893.786608 728643.054676</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 103 924</ms:GML_ID>
        <ms:NAZWA>108 103 924</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108103924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185184.040663 743141.097849</gml:lowerCorner>
        		<gml:upperCorner>185184.040663 743141.097849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185184.040663 743141.097849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 124 821</ms:GML_ID>
        <ms:NAZWA>108 124 821</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108124821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185353.749303 742797.154977</gml:lowerCorner>
        		<gml:upperCorner>185353.749303 742797.154977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185353.749303 742797.154977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 124 425</ms:GML_ID>
        <ms:NAZWA>108 124 425</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108124425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185402.620607 766144.628051</gml:lowerCorner>
        		<gml:upperCorner>185402.620607 766144.628051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185402.620607 766144.628051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 159 037</ms:GML_ID>
        <ms:NAZWA>108 159 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108159037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185460.367703 765991.855515</gml:lowerCorner>
        		<gml:upperCorner>185460.367703 765991.855515</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185460.367703 765991.855515</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 158 873</ms:GML_ID>
        <ms:NAZWA>108 158 873</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108158873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185553.517845 766937.123547</gml:lowerCorner>
        		<gml:upperCorner>185553.517845 766937.123547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185553.517845 766937.123547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 159 856</ms:GML_ID>
        <ms:NAZWA>108 159 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108159856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185891.108562 767409.774549</gml:lowerCorner>
        		<gml:upperCorner>185891.108562 767409.774549</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185891.108562 767409.774549</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 160 450</ms:GML_ID>
        <ms:NAZWA>108 160 450</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108160450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186149.330731 742114.784640</gml:lowerCorner>
        		<gml:upperCorner>186149.330731 742114.784640</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186149.330731 742114.784640</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 123 310</ms:GML_ID>
        <ms:NAZWA>108 123 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108123310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186461.543280 741937.129992</gml:lowerCorner>
        		<gml:upperCorner>186461.543280 741937.129992</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186461.543280 741937.129992</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 122 917</ms:GML_ID>
        <ms:NAZWA>108 122 917</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108122917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186962.142011 741457.319347</gml:lowerCorner>
        		<gml:upperCorner>186962.142011 741457.319347</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186962.142011 741457.319347</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 122 139</ms:GML_ID>
        <ms:NAZWA>108 122 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108122139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188430.907791 741560.682780</gml:lowerCorner>
        		<gml:upperCorner>188430.907791 741560.682780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188430.907791 741560.682780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 120 584</ms:GML_ID>
        <ms:NAZWA>108 120 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108120584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189410.449898 741238.615059</gml:lowerCorner>
        		<gml:upperCorner>189410.449898 741238.615059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189410.449898 741238.615059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 119 526</ms:GML_ID>
        <ms:NAZWA>108 119 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108119526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189657.506272 740512.363153</gml:lowerCorner>
        		<gml:upperCorner>189657.506272 740512.363153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189657.506272 740512.363153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 118 666</ms:GML_ID>
        <ms:NAZWA>108 118 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108118666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210729.382072 775906.819510</gml:lowerCorner>
        		<gml:upperCorner>210729.382072 775906.819510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210729.382072 775906.819510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 011 510</ms:GML_ID>
        <ms:NAZWA>102 011 510</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102011510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212111.566796 776436.914910</gml:lowerCorner>
        		<gml:upperCorner>212111.566796 776436.914910</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212111.566796 776436.914910</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 010 004</ms:GML_ID>
        <ms:NAZWA>102 010 004</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102010004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212871.432630 776008.584644</gml:lowerCorner>
        		<gml:upperCorner>212871.432630 776008.584644</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212871.432630 776008.584644</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 009 129</ms:GML_ID>
        <ms:NAZWA>102 009 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102009129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213187.756954 775821.616161</gml:lowerCorner>
        		<gml:upperCorner>213187.756954 775821.616161</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213187.756954 775821.616161</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 008 763</ms:GML_ID>
        <ms:NAZWA>102 008 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102008763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215329.960847 774381.260772</gml:lowerCorner>
        		<gml:upperCorner>215329.960847 774381.260772</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215329.960847 774381.260772</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 006 167</ms:GML_ID>
        <ms:NAZWA>102 006 167</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102006167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216341.595000 774445.450000</gml:lowerCorner>
        		<gml:upperCorner>216341.595000 774445.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216341.595000 774445.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 005 047</ms:GML_ID>
        <ms:NAZWA>102 005 047</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102005047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216704.384627 774494.226546</gml:lowerCorner>
        		<gml:upperCorner>216704.384627 774494.226546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216704.384627 774494.226546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.102 004 675</ms:GML_ID>
        <ms:NAZWA>102 004 675</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>102004675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184898.232000 743475.944000</gml:lowerCorner>
        		<gml:upperCorner>184898.232000 743475.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184898.232000 743475.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 125 274</ms:GML_ID>
        <ms:NAZWA>108 125 274</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108125274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184770.070754 743894.253005</gml:lowerCorner>
        		<gml:upperCorner>184770.070754 743894.253005</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184770.070754 743894.253005</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 125 718</ms:GML_ID>
        <ms:NAZWA>108 125 718</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108125718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184453.224534 744317.993569</gml:lowerCorner>
        		<gml:upperCorner>184453.224534 744317.993569</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184453.224534 744317.993569</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 126 261</ms:GML_ID>
        <ms:NAZWA>108 126 261</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108126261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182876.702500 746091.600255</gml:lowerCorner>
        		<gml:upperCorner>182876.702500 746091.600255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182876.702500 746091.600255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 129 996</ms:GML_ID>
        <ms:NAZWA>108 129 996</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108129996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182971.088154 746159.444345</gml:lowerCorner>
        		<gml:upperCorner>182971.088154 746159.444345</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182971.088154 746159.444345</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 130 113</ms:GML_ID>
        <ms:NAZWA>108 130 113</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108130113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183837.447000 746994.457000</gml:lowerCorner>
        		<gml:upperCorner>183837.447000 746994.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183837.447000 746994.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 131 372</ms:GML_ID>
        <ms:NAZWA>108 131 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108131372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184607.763341 749002.432854</gml:lowerCorner>
        		<gml:upperCorner>184607.763341 749002.432854</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184607.763341 749002.432854</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 133 771</ms:GML_ID>
        <ms:NAZWA>108 133 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108133771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184589.088283 749847.751212</gml:lowerCorner>
        		<gml:upperCorner>184589.088283 749847.751212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184589.088283 749847.751212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 134 741</ms:GML_ID>
        <ms:NAZWA>108 134 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108134741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183553.753000 751187.810000</gml:lowerCorner>
        		<gml:upperCorner>183553.753000 751187.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183553.753000 751187.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 136 452</ms:GML_ID>
        <ms:NAZWA>108 136 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108136452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182615.888000 751944.805000</gml:lowerCorner>
        		<gml:upperCorner>182615.888000 751944.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182615.888000 751944.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 137 683</ms:GML_ID>
        <ms:NAZWA>108 137 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108137683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181233.944000 752709.450000</gml:lowerCorner>
        		<gml:upperCorner>181233.944000 752709.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181233.944000 752709.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 139 606</ms:GML_ID>
        <ms:NAZWA>108 139 606</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108139606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180937.275842 753467.555134</gml:lowerCorner>
        		<gml:upperCorner>180937.275842 753467.555134</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180937.275842 753467.555134</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 140 461</ms:GML_ID>
        <ms:NAZWA>108 140 461</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108140461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180391.815629 753721.436774</gml:lowerCorner>
        		<gml:upperCorner>180391.815629 753721.436774</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180391.815629 753721.436774</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 141 118</ms:GML_ID>
        <ms:NAZWA>108 141 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108141118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179855.287516 755703.167596</gml:lowerCorner>
        		<gml:upperCorner>179855.287516 755703.167596</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179855.287516 755703.167596</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 143 346</ms:GML_ID>
        <ms:NAZWA>108 143 346</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108143346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179588.243000 755917.486000</gml:lowerCorner>
        		<gml:upperCorner>179588.243000 755917.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179588.243000 755917.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 143 702</ms:GML_ID>
        <ms:NAZWA>108 143 702</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108143702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179211.213000 756453.603000</gml:lowerCorner>
        		<gml:upperCorner>179211.213000 756453.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179211.213000 756453.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 144 484</ms:GML_ID>
        <ms:NAZWA>108 144 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108144484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179090.301000 756720.519000</gml:lowerCorner>
        		<gml:upperCorner>179090.301000 756720.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179090.301000 756720.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 144 781</ms:GML_ID>
        <ms:NAZWA>108 144 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108144781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>178917.022000 757172.907000</gml:lowerCorner>
        		<gml:upperCorner>178917.022000 757172.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>178917.022000 757172.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 145 269</ms:GML_ID>
        <ms:NAZWA>108 145 269</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108145269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>178798.425000 757707.610000</gml:lowerCorner>
        		<gml:upperCorner>178798.425000 757707.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>178798.425000 757707.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 145 818</ms:GML_ID>
        <ms:NAZWA>108 145 818</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108145818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>178481.295000 759079.084000</gml:lowerCorner>
        		<gml:upperCorner>178481.295000 759079.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>178481.295000 759079.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 147 240</ms:GML_ID>
        <ms:NAZWA>108 147 240</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108147240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179337.711000 759407.835000</gml:lowerCorner>
        		<gml:upperCorner>179337.711000 759407.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179337.711000 759407.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 148 290</ms:GML_ID>
        <ms:NAZWA>108 148 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108148290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180733.643247 761264.829195</gml:lowerCorner>
        		<gml:upperCorner>180733.643247 761264.829195</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180733.643247 761264.829195</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 151 112</ms:GML_ID>
        <ms:NAZWA>108 151 112</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108151112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181389.790000 761954.564000</gml:lowerCorner>
        		<gml:upperCorner>181389.790000 761954.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181389.790000 761954.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 152 108</ms:GML_ID>
        <ms:NAZWA>108 152 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108152108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181773.564000 763012.951000</gml:lowerCorner>
        		<gml:upperCorner>181773.564000 763012.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181773.564000 763012.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 153 325</ms:GML_ID>
        <ms:NAZWA>108 153 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108153325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184835.487000 765014.091000</gml:lowerCorner>
        		<gml:upperCorner>184835.487000 765014.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184835.487000 765014.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 157 477</ms:GML_ID>
        <ms:NAZWA>108 157 477</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108157477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>173879.386204 727089.961547</gml:lowerCorner>
        		<gml:upperCorner>173879.386204 727089.961547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>173879.386204 727089.961547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 027 078</ms:GML_ID>
        <ms:NAZWA>107 027 078</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107027078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>174204.382000 727371.141000</gml:lowerCorner>
        		<gml:upperCorner>174204.382000 727371.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>174204.382000 727371.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 026 646</ms:GML_ID>
        <ms:NAZWA>107 026 646</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107026646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>175539.875000 728100.631000</gml:lowerCorner>
        		<gml:upperCorner>175539.875000 728100.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>175539.875000 728100.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 024 956</ms:GML_ID>
        <ms:NAZWA>107 024 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107024956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>176365.907330 727456.579675</gml:lowerCorner>
        		<gml:upperCorner>176365.907330 727456.579675</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>176365.907330 727456.579675</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 023 897</ms:GML_ID>
        <ms:NAZWA>107 023 897</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107023897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>177954.694000 727450.120000</gml:lowerCorner>
        		<gml:upperCorner>177954.694000 727450.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>177954.694000 727450.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 021 821</ms:GML_ID>
        <ms:NAZWA>107 021 821</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107021821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179122.048000 728450.697000</gml:lowerCorner>
        		<gml:upperCorner>179122.048000 728450.697000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179122.048000 728450.697000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 020 245</ms:GML_ID>
        <ms:NAZWA>107 020 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107020245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179656.744000 729316.051000</gml:lowerCorner>
        		<gml:upperCorner>179656.744000 729316.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179656.744000 729316.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 018 430</ms:GML_ID>
        <ms:NAZWA>107 018 430</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107018430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181066.151000 729377.242000</gml:lowerCorner>
        		<gml:upperCorner>181066.151000 729377.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181066.151000 729377.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 016 849</ms:GML_ID>
        <ms:NAZWA>107 016 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107016849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181343.906000 732350.118000</gml:lowerCorner>
        		<gml:upperCorner>181343.906000 732350.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181343.906000 732350.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 010 360</ms:GML_ID>
        <ms:NAZWA>107 010 360</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107010360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181567.315967 733015.292383</gml:lowerCorner>
        		<gml:upperCorner>181567.315967 733015.292383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181567.315967 733015.292383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 009 495</ms:GML_ID>
        <ms:NAZWA>107 009 495</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107009495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181696.746270 729713.015130</gml:lowerCorner>
        		<gml:upperCorner>181696.746270 729713.015130</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181696.746270 729713.015130</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 016 106</ms:GML_ID>
        <ms:NAZWA>107 016 106</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107016106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181841.689000 729851.395000</gml:lowerCorner>
        		<gml:upperCorner>181841.689000 729851.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181841.689000 729851.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 015 905</ms:GML_ID>
        <ms:NAZWA>107 015 905</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107015905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181848.400021 733266.885653</gml:lowerCorner>
        		<gml:upperCorner>181848.400021 733266.885653</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181848.400021 733266.885653</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 009 108</ms:GML_ID>
        <ms:NAZWA>107 009 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107009108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182070.318000 730741.460000</gml:lowerCorner>
        		<gml:upperCorner>182070.318000 730741.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182070.318000 730741.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 014 946</ms:GML_ID>
        <ms:NAZWA>107 014 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107014946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182086.807000 730506.368000</gml:lowerCorner>
        		<gml:upperCorner>182086.807000 730506.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182086.807000 730506.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 015 182</ms:GML_ID>
        <ms:NAZWA>107 015 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107015182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182245.381725 732857.190479</gml:lowerCorner>
        		<gml:upperCorner>182245.381725 732857.190479</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182245.381725 732857.190479</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 011 484</ms:GML_ID>
        <ms:NAZWA>107 011 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107011484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182665.682000 734175.660000</gml:lowerCorner>
        		<gml:upperCorner>182665.682000 734175.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182665.682000 734175.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 007 890</ms:GML_ID>
        <ms:NAZWA>107 007 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107007890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182690.012393 732996.683010</gml:lowerCorner>
        		<gml:upperCorner>182690.012393 732996.683010</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182690.012393 732996.683010</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 011 968</ms:GML_ID>
        <ms:NAZWA>107 011 968</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107011968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182966.734000 732449.872000</gml:lowerCorner>
        		<gml:upperCorner>182966.734000 732449.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182966.734000 732449.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 012 706</ms:GML_ID>
        <ms:NAZWA>107 012 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107012706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183038.681096 734958.052415</gml:lowerCorner>
        		<gml:upperCorner>183038.681096 734958.052415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183038.681096 734958.052415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 006 983</ms:GML_ID>
        <ms:NAZWA>107 006 983</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107006983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183191.830000 735095.142000</gml:lowerCorner>
        		<gml:upperCorner>183191.830000 735095.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183191.830000 735095.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 006 776</ms:GML_ID>
        <ms:NAZWA>107 006 776</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107006776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184044.824767 735955.491503</gml:lowerCorner>
        		<gml:upperCorner>184044.824767 735955.491503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184044.824767 735955.491503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 005 273</ms:GML_ID>
        <ms:NAZWA>107 005 273</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107005273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184324.479000 736060.278000</gml:lowerCorner>
        		<gml:upperCorner>184324.479000 736060.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184324.479000 736060.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 004 962</ms:GML_ID>
        <ms:NAZWA>107 004 962</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107004962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185610.276461 736116.997691</gml:lowerCorner>
        		<gml:upperCorner>185610.276461 736116.997691</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185610.276461 736116.997691</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 003 676</ms:GML_ID>
        <ms:NAZWA>107 003 676</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107003676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185881.516000 736129.994000</gml:lowerCorner>
        		<gml:upperCorner>185881.516000 736129.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185881.516000 736129.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 003 404</ms:GML_ID>
        <ms:NAZWA>107 003 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107003404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186480.601000 736304.789000</gml:lowerCorner>
        		<gml:upperCorner>186480.601000 736304.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186480.601000 736304.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 002 774</ms:GML_ID>
        <ms:NAZWA>107 002 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107002774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186759.024249 736248.488977</gml:lowerCorner>
        		<gml:upperCorner>186759.024249 736248.488977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186759.024249 736248.488977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 002 484</ms:GML_ID>
        <ms:NAZWA>107 002 484</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107002484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187483.170508 735990.197162</gml:lowerCorner>
        		<gml:upperCorner>187483.170508 735990.197162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187483.170508 735990.197162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 001 717</ms:GML_ID>
        <ms:NAZWA>107 001 717</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107001717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188598.700000 736186.555000</gml:lowerCorner>
        		<gml:upperCorner>188598.700000 736186.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188598.700000 736186.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 113 733</ms:GML_ID>
        <ms:NAZWA>108 113 733</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108113733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188901.983000 737060.872000</gml:lowerCorner>
        		<gml:upperCorner>188901.983000 737060.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188901.983000 737060.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 114 743</ms:GML_ID>
        <ms:NAZWA>108 114 743</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108114743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>158043.371000 722164.768000</gml:lowerCorner>
        		<gml:upperCorner>158043.371000 722164.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>158043.371000 722164.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 049 461</ms:GML_ID>
        <ms:NAZWA>107 049 461</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107049461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>159058.789000 724538.277000</gml:lowerCorner>
        		<gml:upperCorner>159058.789000 724538.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>159058.789000 724538.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 045 772</ms:GML_ID>
        <ms:NAZWA>107 045 772</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107045772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167406.203000 722714.852000</gml:lowerCorner>
        		<gml:upperCorner>167406.203000 722714.852000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167406.203000 722714.852000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 035 993</ms:GML_ID>
        <ms:NAZWA>107 035 993</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107035993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>170535.042000 725201.802000</gml:lowerCorner>
        		<gml:upperCorner>170535.042000 725201.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>170535.042000 725201.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 031 704</ms:GML_ID>
        <ms:NAZWA>107 031 704</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107031704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>171750.123000 725803.580000</gml:lowerCorner>
        		<gml:upperCorner>171750.123000 725803.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>171750.123000 725803.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 030 054</ms:GML_ID>
        <ms:NAZWA>107 030 054</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107030054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>172112.714398 725913.411116</gml:lowerCorner>
        		<gml:upperCorner>172112.714398 725913.411116</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>172112.714398 725913.411116</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.107 029 672</ms:GML_ID>
        <ms:NAZWA>107 029 672</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>107029672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192568.845708 724873.017530</gml:lowerCorner>
        		<gml:upperCorner>192568.845708 724873.017530</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192568.845708 724873.017530</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 099 843</ms:GML_ID>
        <ms:NAZWA>108 099 843</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108099843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192575.542000 724184.307000</gml:lowerCorner>
        		<gml:upperCorner>192575.542000 724184.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192575.542000 724184.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 099 132</ms:GML_ID>
        <ms:NAZWA>108 099 132</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108099132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192639.480246 723949.589998</gml:lowerCorner>
        		<gml:upperCorner>192639.480246 723949.589998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192639.480246 723949.589998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 098 882</ms:GML_ID>
        <ms:NAZWA>108 098 882</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108098882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192728.835000 723695.083000</gml:lowerCorner>
        		<gml:upperCorner>192728.835000 723695.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192728.835000 723695.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 098 609</ms:GML_ID>
        <ms:NAZWA>108 098 609</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108098609</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192775.238627 723430.307259</gml:lowerCorner>
        		<gml:upperCorner>192775.238627 723430.307259</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192775.238627 723430.307259</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 098 340</ms:GML_ID>
        <ms:NAZWA>108 098 340</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108098340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192997.005058 722905.226121</gml:lowerCorner>
        		<gml:upperCorner>192997.005058 722905.226121</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192997.005058 722905.226121</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 097 765</ms:GML_ID>
        <ms:NAZWA>108 097 765</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108097765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193095.106000 725524.617000</gml:lowerCorner>
        		<gml:upperCorner>193095.106000 725524.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193095.106000 725524.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 100 683</ms:GML_ID>
        <ms:NAZWA>108 100 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108100683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193233.826000 726189.621000</gml:lowerCorner>
        		<gml:upperCorner>193233.826000 726189.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193233.826000 726189.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 101 367</ms:GML_ID>
        <ms:NAZWA>108 101 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108101367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193264.682000 722487.061000</gml:lowerCorner>
        		<gml:upperCorner>193264.682000 722487.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193264.682000 722487.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 097 269</ms:GML_ID>
        <ms:NAZWA>108 097 269</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108097269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193376.544000 722312.257000</gml:lowerCorner>
        		<gml:upperCorner>193376.544000 722312.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193376.544000 722312.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 097 061</ms:GML_ID>
        <ms:NAZWA>108 097 061</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108097061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193536.853000 722154.029000</gml:lowerCorner>
        		<gml:upperCorner>193536.853000 722154.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193536.853000 722154.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 096 834</ms:GML_ID>
        <ms:NAZWA>108 096 834</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108096834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193824.783000 721693.368000</gml:lowerCorner>
        		<gml:upperCorner>193824.783000 721693.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193824.783000 721693.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 096 276</ms:GML_ID>
        <ms:NAZWA>108 096 276</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108096276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193934.269000 721487.192000</gml:lowerCorner>
        		<gml:upperCorner>193934.269000 721487.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193934.269000 721487.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 096 040</ms:GML_ID>
        <ms:NAZWA>108 096 040</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108096040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196962.981535 640203.574046</gml:lowerCorner>
        		<gml:upperCorner>196962.981535 640203.574046</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196962.981535 640203.574046</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 062 445</ms:GML_ID>
        <ms:NAZWA>096 062 445</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096062445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198285.474000 642215.182000</gml:lowerCorner>
        		<gml:upperCorner>198285.474000 642215.182000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198285.474000 642215.182000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 059 736</ms:GML_ID>
        <ms:NAZWA>096 059 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096059736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198484.930985 642360.676077</gml:lowerCorner>
        		<gml:upperCorner>198484.930985 642360.676077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198484.930985 642360.676077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 059 485</ms:GML_ID>
        <ms:NAZWA>096 059 485</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096059485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198671.457000 642529.879000</gml:lowerCorner>
        		<gml:upperCorner>198671.457000 642529.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198671.457000 642529.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 059 234</ms:GML_ID>
        <ms:NAZWA>096 059 234</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096059234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198971.627450 642689.217447</gml:lowerCorner>
        		<gml:upperCorner>198971.627450 642689.217447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198971.627450 642689.217447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 058 891</ms:GML_ID>
        <ms:NAZWA>096 058 891</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096058891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199387.137000 642685.634000</gml:lowerCorner>
        		<gml:upperCorner>199387.137000 642685.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199387.137000 642685.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 058 457</ms:GML_ID>
        <ms:NAZWA>096 058 457</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096058457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199991.896000 642752.095000</gml:lowerCorner>
        		<gml:upperCorner>199991.896000 642752.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199991.896000 642752.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 057 846</ms:GML_ID>
        <ms:NAZWA>096 057 846</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096057846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201198.397584 642062.980738</gml:lowerCorner>
        		<gml:upperCorner>201198.397584 642062.980738</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201198.397584 642062.980738</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 056 436</ms:GML_ID>
        <ms:NAZWA>096 056 436</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096056436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201202.274000 642105.080000</gml:lowerCorner>
        		<gml:upperCorner>201202.274000 642105.080000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201202.274000 642105.080000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 000 960</ms:GML_ID>
        <ms:NAZWA>108 000 960</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108000960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201507.134765 641964.317433</gml:lowerCorner>
        		<gml:upperCorner>201507.134765 641964.317433</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201507.134765 641964.317433</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.619 000 506</ms:GML_ID>
        <ms:NAZWA>619 000 506</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>619000506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201740.541317 642427.472722</gml:lowerCorner>
        		<gml:upperCorner>201740.541317 642427.472722</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201740.541317 642427.472722</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 001 682</ms:GML_ID>
        <ms:NAZWA>108 001 682</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108001682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201862.617865 642764.139309</gml:lowerCorner>
        		<gml:upperCorner>201862.617865 642764.139309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201862.617865 642764.139309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 002 001</ms:GML_ID>
        <ms:NAZWA>108 002 001</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108002001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201874.669000 641474.073000</gml:lowerCorner>
        		<gml:upperCorner>201874.669000 641474.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201874.669000 641474.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 055 536</ms:GML_ID>
        <ms:NAZWA>096 055 536</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096055536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202322.601118 643040.104260</gml:lowerCorner>
        		<gml:upperCorner>202322.601118 643040.104260</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202322.601118 643040.104260</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 002 561</ms:GML_ID>
        <ms:NAZWA>108 002 561</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108002561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202676.327000 640500.342000</gml:lowerCorner>
        		<gml:upperCorner>202676.327000 640500.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202676.327000 640500.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 054 253</ms:GML_ID>
        <ms:NAZWA>096 054 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096054253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202703.771000 643455.003000</gml:lowerCorner>
        		<gml:upperCorner>202703.771000 643455.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202703.771000 643455.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 003 189</ms:GML_ID>
        <ms:NAZWA>108 003 189</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108003189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202882.925068 644202.812320</gml:lowerCorner>
        		<gml:upperCorner>202882.925068 644202.812320</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202882.925068 644202.812320</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 003 964</ms:GML_ID>
        <ms:NAZWA>108 003 964</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108003964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202993.313000 644534.477000</gml:lowerCorner>
        		<gml:upperCorner>202993.313000 644534.477000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202993.313000 644534.477000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 004 317</ms:GML_ID>
        <ms:NAZWA>108 004 317</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108004317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203293.216000 645211.410000</gml:lowerCorner>
        		<gml:upperCorner>203293.216000 645211.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203293.216000 645211.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.108 005 101</ms:GML_ID>
        <ms:NAZWA>108 005 101</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>108005101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229691.180000 642222.762000</gml:lowerCorner>
        		<gml:upperCorner>229691.180000 642222.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229691.180000 642222.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 014 076</ms:GML_ID>
        <ms:NAZWA>096 014 076</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096014076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229878.809611 642647.407346</gml:lowerCorner>
        		<gml:upperCorner>229878.809611 642647.407346</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229878.809611 642647.407346</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 014 547</ms:GML_ID>
        <ms:NAZWA>096 014 547</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096014547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230047.342000 640726.724000</gml:lowerCorner>
        		<gml:upperCorner>230047.342000 640726.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230047.342000 640726.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 011 936</ms:GML_ID>
        <ms:NAZWA>096 011 936</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096011936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230405.864000 639916.907000</gml:lowerCorner>
        		<gml:upperCorner>230405.864000 639916.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230405.864000 639916.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 011 002</ms:GML_ID>
        <ms:NAZWA>096 011 002</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096011002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231789.399117 639692.784506</gml:lowerCorner>
        		<gml:upperCorner>231789.399117 639692.784506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231789.399117 639692.784506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 009 572</ms:GML_ID>
        <ms:NAZWA>096 009 572</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096009572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232313.101000 639451.672000</gml:lowerCorner>
        		<gml:upperCorner>232313.101000 639451.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232313.101000 639451.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 008 971</ms:GML_ID>
        <ms:NAZWA>096 008 971</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096008971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232463.627426 639433.279953</gml:lowerCorner>
        		<gml:upperCorner>232463.627426 639433.279953</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232463.627426 639433.279953</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 008 818</ms:GML_ID>
        <ms:NAZWA>096 008 818</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096008818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233585.507483 640344.943984</gml:lowerCorner>
        		<gml:upperCorner>233585.507483 640344.943984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233585.507483 640344.943984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 007 351</ms:GML_ID>
        <ms:NAZWA>096 007 351</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096007351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234250.925432 640667.948788</gml:lowerCorner>
        		<gml:upperCorner>234250.925432 640667.948788</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234250.925432 640667.948788</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 006 612</ms:GML_ID>
        <ms:NAZWA>096 006 612</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096006612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235065.270587 641071.286494</gml:lowerCorner>
        		<gml:upperCorner>235065.270587 641071.286494</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235065.270587 641071.286494</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 005 702</ms:GML_ID>
        <ms:NAZWA>096 005 702</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096005702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235823.539000 641236.200000</gml:lowerCorner>
        		<gml:upperCorner>235823.539000 641236.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235823.539000 641236.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 004 905</ms:GML_ID>
        <ms:NAZWA>096 004 905</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096004905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236221.204000 641217.603000</gml:lowerCorner>
        		<gml:upperCorner>236221.204000 641217.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236221.204000 641217.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 004 507</ms:GML_ID>
        <ms:NAZWA>096 004 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096004507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237081.865760 641176.525912</gml:lowerCorner>
        		<gml:upperCorner>237081.865760 641176.525912</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237081.865760 641176.525912</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 003 645</ms:GML_ID>
        <ms:NAZWA>096 003 645</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096003645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239304.846724 642417.289341</gml:lowerCorner>
        		<gml:upperCorner>239304.846724 642417.289341</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239304.846724 642417.289341</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.609 000 179</ms:GML_ID>
        <ms:NAZWA>609 000 179</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>609000179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239617.014000 640296.831000</gml:lowerCorner>
        		<gml:upperCorner>239617.014000 640296.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239617.014000 640296.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 001 207</ms:GML_ID>
        <ms:NAZWA>115 001 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115001207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240420.082754 640344.198122</gml:lowerCorner>
        		<gml:upperCorner>240420.082754 640344.198122</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240420.082754 640344.198122</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 002 017</ms:GML_ID>
        <ms:NAZWA>115 002 017</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115002017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241401.002301 640450.525012</gml:lowerCorner>
        		<gml:upperCorner>241401.002301 640450.525012</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241401.002301 640450.525012</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 003 005</ms:GML_ID>
        <ms:NAZWA>115 003 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115003005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241693.361917 645969.738752</gml:lowerCorner>
        		<gml:upperCorner>241693.361917 645969.738752</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241693.361917 645969.738752</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 082 720</ms:GML_ID>
        <ms:NAZWA>091 082 720</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091082720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242148.232909 640772.047029</gml:lowerCorner>
        		<gml:upperCorner>242148.232909 640772.047029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242148.232909 640772.047029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 003 822</ms:GML_ID>
        <ms:NAZWA>115 003 822</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115003822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243014.542000 640953.864000</gml:lowerCorner>
        		<gml:upperCorner>243014.542000 640953.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243014.542000 640953.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 004 728</ms:GML_ID>
        <ms:NAZWA>115 004 728</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115004728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>163602.610778 638259.352191</gml:lowerCorner>
        		<gml:upperCorner>163602.610778 638259.352191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>163602.610778 638259.352191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 142 433</ms:GML_ID>
        <ms:NAZWA>096 142 433</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096142433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>164049.676025 638541.998212</gml:lowerCorner>
        		<gml:upperCorner>164049.676025 638541.998212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>164049.676025 638541.998212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 141 786</ms:GML_ID>
        <ms:NAZWA>096 141 786</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096141786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>164283.296021 638751.333741</gml:lowerCorner>
        		<gml:upperCorner>164283.296021 638751.333741</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>164283.296021 638751.333741</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 141 448</ms:GML_ID>
        <ms:NAZWA>096 141 448</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096141448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>164738.613216 638438.639350</gml:lowerCorner>
        		<gml:upperCorner>164738.613216 638438.639350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>164738.613216 638438.639350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 140 870</ms:GML_ID>
        <ms:NAZWA>096 140 870</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096140870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167512.668849 638807.083198</gml:lowerCorner>
        		<gml:upperCorner>167512.668849 638807.083198</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167512.668849 638807.083198</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 002 796</ms:GML_ID>
        <ms:NAZWA>105 002 796</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105002796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167737.943000 639088.986000</gml:lowerCorner>
        		<gml:upperCorner>167737.943000 639088.986000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167737.943000 639088.986000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 003 159</ms:GML_ID>
        <ms:NAZWA>105 003 159</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105003159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168047.361552 639822.809000</gml:lowerCorner>
        		<gml:upperCorner>168047.361552 639822.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168047.361552 639822.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 003 972</ms:GML_ID>
        <ms:NAZWA>105 003 972</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105003972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168812.309000 641187.933000</gml:lowerCorner>
        		<gml:upperCorner>168812.309000 641187.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168812.309000 641187.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 005 562</ms:GML_ID>
        <ms:NAZWA>105 005 562</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105005562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168836.501000 641434.923000</gml:lowerCorner>
        		<gml:upperCorner>168836.501000 641434.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168836.501000 641434.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 005 814</ms:GML_ID>
        <ms:NAZWA>105 005 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105005814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>169120.327000 641560.896000</gml:lowerCorner>
        		<gml:upperCorner>169120.327000 641560.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>169120.327000 641560.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 006 151</ms:GML_ID>
        <ms:NAZWA>105 006 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105006151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>169538.794196 641561.590239</gml:lowerCorner>
        		<gml:upperCorner>169538.794196 641561.590239</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>169538.794196 641561.590239</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 006 570</ms:GML_ID>
        <ms:NAZWA>105 006 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105006570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>169977.009651 641711.939260</gml:lowerCorner>
        		<gml:upperCorner>169977.009651 641711.939260</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>169977.009651 641711.939260</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 007 040</ms:GML_ID>
        <ms:NAZWA>105 007 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105007040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>171694.796919 642268.115158</gml:lowerCorner>
        		<gml:upperCorner>171694.796919 642268.115158</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>171694.796919 642268.115158</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 008 906</ms:GML_ID>
        <ms:NAZWA>105 008 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105008906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>171824.933000 642257.383000</gml:lowerCorner>
        		<gml:upperCorner>171824.933000 642257.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>171824.933000 642257.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 009 037</ms:GML_ID>
        <ms:NAZWA>105 009 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105009037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195859.619649 639504.463480</gml:lowerCorner>
        		<gml:upperCorner>195859.619649 639504.463480</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195859.619649 639504.463480</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 067 243</ms:GML_ID>
        <ms:NAZWA>096 067 243</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096067243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196146.510128 639426.481843</gml:lowerCorner>
        		<gml:upperCorner>196146.510128 639426.481843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196146.510128 639426.481843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 066 923</ms:GML_ID>
        <ms:NAZWA>096 066 923</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096066923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196368.775000 638737.640000</gml:lowerCorner>
        		<gml:upperCorner>196368.775000 638737.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196368.775000 638737.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 066 176</ms:GML_ID>
        <ms:NAZWA>096 066 176</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096066176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196886.778434 638940.827403</gml:lowerCorner>
        		<gml:upperCorner>196886.778434 638940.827403</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196886.778434 638940.827403</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 063 735</ms:GML_ID>
        <ms:NAZWA>096 063 735</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096063735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196911.874000 639885.726000</gml:lowerCorner>
        		<gml:upperCorner>196911.874000 639885.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196911.874000 639885.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 062 767</ms:GML_ID>
        <ms:NAZWA>096 062 767</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096062767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248408.774311 638615.082392</gml:lowerCorner>
        		<gml:upperCorner>248408.774311 638615.082392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248408.774311 638615.082392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 010 706</ms:GML_ID>
        <ms:NAZWA>115 010 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115010706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248820.382010 638287.998296</gml:lowerCorner>
        		<gml:upperCorner>248820.382010 638287.998296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248820.382010 638287.998296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 011 232</ms:GML_ID>
        <ms:NAZWA>115 011 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115011232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249042.715588 638111.285131</gml:lowerCorner>
        		<gml:upperCorner>249042.715588 638111.285131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249042.715588 638111.285131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 011 516</ms:GML_ID>
        <ms:NAZWA>115 011 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115011516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249131.910841 638040.432921</gml:lowerCorner>
        		<gml:upperCorner>249131.910841 638040.432921</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249131.910841 638040.432921</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 011 630</ms:GML_ID>
        <ms:NAZWA>115 011 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115011630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249457.566375 637852.963162</gml:lowerCorner>
        		<gml:upperCorner>249457.566375 637852.963162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249457.566375 637852.963162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 012 008</ms:GML_ID>
        <ms:NAZWA>115 012 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115012008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249721.287527 637793.382816</gml:lowerCorner>
        		<gml:upperCorner>249721.287527 637793.382816</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249721.287527 637793.382816</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 012 280</ms:GML_ID>
        <ms:NAZWA>115 012 280</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115012280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254061.501408 637686.657642</gml:lowerCorner>
        		<gml:upperCorner>254061.501408 637686.657642</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254061.501408 637686.657642</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 018 770</ms:GML_ID>
        <ms:NAZWA>115 018 770</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115018770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254109.866429 637928.675817</gml:lowerCorner>
        		<gml:upperCorner>254109.866429 637928.675817</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254109.866429 637928.675817</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 019 018</ms:GML_ID>
        <ms:NAZWA>115 019 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115019018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254197.864000 638143.410000</gml:lowerCorner>
        		<gml:upperCorner>254197.864000 638143.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254197.864000 638143.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 019 251</ms:GML_ID>
        <ms:NAZWA>115 019 251</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115019251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254281.581074 638258.324698</gml:lowerCorner>
        		<gml:upperCorner>254281.581074 638258.324698</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254281.581074 638258.324698</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 019 393</ms:GML_ID>
        <ms:NAZWA>115 019 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115019393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254733.878537 638635.659105</gml:lowerCorner>
        		<gml:upperCorner>254733.878537 638635.659105</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254733.878537 638635.659105</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 019 988</ms:GML_ID>
        <ms:NAZWA>115 019 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115019988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254873.155000 638770.152000</gml:lowerCorner>
        		<gml:upperCorner>254873.155000 638770.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254873.155000 638770.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 020 176</ms:GML_ID>
        <ms:NAZWA>115 020 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115020176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254978.806835 638970.222179</gml:lowerCorner>
        		<gml:upperCorner>254978.806835 638970.222179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254978.806835 638970.222179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 020 407</ms:GML_ID>
        <ms:NAZWA>115 020 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115020407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259683.301000 639030.986000</gml:lowerCorner>
        		<gml:upperCorner>259683.301000 639030.986000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259683.301000 639030.986000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 027 746</ms:GML_ID>
        <ms:NAZWA>115 027 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115027746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259923.297000 638857.949000</gml:lowerCorner>
        		<gml:upperCorner>259923.297000 638857.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259923.297000 638857.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 028 041</ms:GML_ID>
        <ms:NAZWA>115 028 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115028041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260154.020000 638692.819000</gml:lowerCorner>
        		<gml:upperCorner>260154.020000 638692.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260154.020000 638692.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 028 325</ms:GML_ID>
        <ms:NAZWA>115 028 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115028325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260329.064000 638566.300000</gml:lowerCorner>
        		<gml:upperCorner>260329.064000 638566.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260329.064000 638566.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 028 547</ms:GML_ID>
        <ms:NAZWA>115 028 547</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115028547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261246.923000 637907.585000</gml:lowerCorner>
        		<gml:upperCorner>261246.923000 637907.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261246.923000 637907.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 029 675</ms:GML_ID>
        <ms:NAZWA>115 029 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115029675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262584.855000 637717.275000</gml:lowerCorner>
        		<gml:upperCorner>262584.855000 637717.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262584.855000 637717.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 031 135</ms:GML_ID>
        <ms:NAZWA>115 031 135</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115031135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263323.826857 637892.061546</gml:lowerCorner>
        		<gml:upperCorner>263323.826857 637892.061546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263323.826857 637892.061546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 031 894</ms:GML_ID>
        <ms:NAZWA>115 031 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115031894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264192.964000 638100.024000</gml:lowerCorner>
        		<gml:upperCorner>264192.964000 638100.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264192.964000 638100.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 032 788</ms:GML_ID>
        <ms:NAZWA>115 032 788</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115032788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264484.303000 638169.382000</gml:lowerCorner>
        		<gml:upperCorner>264484.303000 638169.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264484.303000 638169.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 033 088</ms:GML_ID>
        <ms:NAZWA>115 033 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115033088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264692.872000 638229.881000</gml:lowerCorner>
        		<gml:upperCorner>264692.872000 638229.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264692.872000 638229.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 033 306</ms:GML_ID>
        <ms:NAZWA>115 033 306</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115033306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265328.971202 638561.172231</gml:lowerCorner>
        		<gml:upperCorner>265328.971202 638561.172231</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265328.971202 638561.172231</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 034 023</ms:GML_ID>
        <ms:NAZWA>115 034 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115034023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265616.184000 638712.112000</gml:lowerCorner>
        		<gml:upperCorner>265616.184000 638712.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265616.184000 638712.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 034 347</ms:GML_ID>
        <ms:NAZWA>115 034 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115034347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268035.611000 639093.465000</gml:lowerCorner>
        		<gml:upperCorner>268035.611000 639093.465000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268035.611000 639093.465000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 036 862</ms:GML_ID>
        <ms:NAZWA>115 036 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115036862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268499.221000 639084.879000</gml:lowerCorner>
        		<gml:upperCorner>268499.221000 639084.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268499.221000 639084.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 037 328</ms:GML_ID>
        <ms:NAZWA>115 037 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115037328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268834.617000 639078.236000</gml:lowerCorner>
        		<gml:upperCorner>268834.617000 639078.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268834.617000 639078.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 037 663</ms:GML_ID>
        <ms:NAZWA>115 037 663</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115037663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269316.641534 639069.162381</gml:lowerCorner>
        		<gml:upperCorner>269316.641534 639069.162381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269316.641534 639069.162381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 038 144</ms:GML_ID>
        <ms:NAZWA>115 038 144</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115038144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269593.814000 639065.734000</gml:lowerCorner>
        		<gml:upperCorner>269593.814000 639065.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269593.814000 639065.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 038 423</ms:GML_ID>
        <ms:NAZWA>115 038 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115038423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193287.295000 624816.416000</gml:lowerCorner>
        		<gml:upperCorner>193287.295000 624816.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193287.295000 624816.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 085 435</ms:GML_ID>
        <ms:NAZWA>096 085 435</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096085435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192480.287000 626047.679000</gml:lowerCorner>
        		<gml:upperCorner>192480.287000 626047.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192480.287000 626047.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 083 919</ms:GML_ID>
        <ms:NAZWA>096 083 919</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096083919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191919.620000 626301.096000</gml:lowerCorner>
        		<gml:upperCorner>191919.620000 626301.096000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191919.620000 626301.096000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 083 289</ms:GML_ID>
        <ms:NAZWA>096 083 289</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096083289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192254.158356 630159.026684</gml:lowerCorner>
        		<gml:upperCorner>192254.158356 630159.026684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192254.158356 630159.026684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 078 918</ms:GML_ID>
        <ms:NAZWA>096 078 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096078918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192501.544000 630741.577000</gml:lowerCorner>
        		<gml:upperCorner>192501.544000 630741.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192501.544000 630741.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 078 278</ms:GML_ID>
        <ms:NAZWA>096 078 278</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096078278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192702.891524 631100.806117</gml:lowerCorner>
        		<gml:upperCorner>192702.891524 631100.806117</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192702.891524 631100.806117</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 077 862</ms:GML_ID>
        <ms:NAZWA>096 077 862</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096077862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193346.447000 632227.595000</gml:lowerCorner>
        		<gml:upperCorner>193346.447000 632227.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193346.447000 632227.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 076 541</ms:GML_ID>
        <ms:NAZWA>096 076 541</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096076541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193216.822820 632677.705233</gml:lowerCorner>
        		<gml:upperCorner>193216.822820 632677.705233</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193216.822820 632677.705233</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 076 059</ms:GML_ID>
        <ms:NAZWA>096 076 059</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096076059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193694.949000 633151.114000</gml:lowerCorner>
        		<gml:upperCorner>193694.949000 633151.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193694.949000 633151.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 075 373</ms:GML_ID>
        <ms:NAZWA>096 075 373</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096075373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193997.224801 633369.780412</gml:lowerCorner>
        		<gml:upperCorner>193997.224801 633369.780412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193997.224801 633369.780412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 074 989</ms:GML_ID>
        <ms:NAZWA>096 074 989</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096074989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194200.803827 633722.149974</gml:lowerCorner>
        		<gml:upperCorner>194200.803827 633722.149974</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194200.803827 633722.149974</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 074 571</ms:GML_ID>
        <ms:NAZWA>096 074 571</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096074571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194984.423000 634951.086000</gml:lowerCorner>
        		<gml:upperCorner>194984.423000 634951.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194984.423000 634951.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 073 005</ms:GML_ID>
        <ms:NAZWA>096 073 005</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096073005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194429.346000 636328.808000</gml:lowerCorner>
        		<gml:upperCorner>194429.346000 636328.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194429.346000 636328.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 071 313</ms:GML_ID>
        <ms:NAZWA>096 071 313</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096071313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194517.824000 636499.641000</gml:lowerCorner>
        		<gml:upperCorner>194517.824000 636499.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194517.824000 636499.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 071 121</ms:GML_ID>
        <ms:NAZWA>096 071 121</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096071121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194707.115074 636804.252305</gml:lowerCorner>
        		<gml:upperCorner>194707.115074 636804.252305</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194707.115074 636804.252305</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 070 757</ms:GML_ID>
        <ms:NAZWA>096 070 757</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096070757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195030.993680 637162.544985</gml:lowerCorner>
        		<gml:upperCorner>195030.993680 637162.544985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195030.993680 637162.544985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 070 266</ms:GML_ID>
        <ms:NAZWA>096 070 266</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096070266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195038.374000 637562.871000</gml:lowerCorner>
        		<gml:upperCorner>195038.374000 637562.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195038.374000 637562.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 069 859</ms:GML_ID>
        <ms:NAZWA>096 069 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096069859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196599.152483 637948.124430</gml:lowerCorner>
        		<gml:upperCorner>196599.152483 637948.124430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196599.152483 637948.124430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 065 314</ms:GML_ID>
        <ms:NAZWA>096 065 314</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096065314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194852.878230 638096.343770</gml:lowerCorner>
        		<gml:upperCorner>194852.878230 638096.343770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194852.878230 638096.343770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 069 291</ms:GML_ID>
        <ms:NAZWA>096 069 291</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096069291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196588.377026 638233.184501</gml:lowerCorner>
        		<gml:upperCorner>196588.377026 638233.184501</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196588.377026 638233.184501</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 065 603</ms:GML_ID>
        <ms:NAZWA>096 065 603</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096065603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196430.376286 638495.956179</gml:lowerCorner>
        		<gml:upperCorner>196430.376286 638495.956179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196430.376286 638495.956179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 065 918</ms:GML_ID>
        <ms:NAZWA>096 065 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096065918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179711.208613 622310.301835</gml:lowerCorner>
        		<gml:upperCorner>179711.208613 622310.301835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179711.208613 622310.301835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 106 583</ms:GML_ID>
        <ms:NAZWA>096 106 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096106583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179303.709000 622838.423000</gml:lowerCorner>
        		<gml:upperCorner>179303.709000 622838.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179303.709000 622838.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 107 251</ms:GML_ID>
        <ms:NAZWA>096 107 251</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096107251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>178923.046895 622946.739242</gml:lowerCorner>
        		<gml:upperCorner>178923.046895 622946.739242</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>178923.046895 622946.739242</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 107 678</ms:GML_ID>
        <ms:NAZWA>096 107 678</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096107678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>177283.060000 623222.128000</gml:lowerCorner>
        		<gml:upperCorner>177283.060000 623222.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>177283.060000 623222.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 109 512</ms:GML_ID>
        <ms:NAZWA>096 109 512</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096109512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>176790.831000 623958.561000</gml:lowerCorner>
        		<gml:upperCorner>176790.831000 623958.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>176790.831000 623958.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 110 400</ms:GML_ID>
        <ms:NAZWA>096 110 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096110400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>175196.119000 624145.789000</gml:lowerCorner>
        		<gml:upperCorner>175196.119000 624145.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>175196.119000 624145.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 113 069</ms:GML_ID>
        <ms:NAZWA>096 113 069</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096113069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>176205.308000 624466.949000</gml:lowerCorner>
        		<gml:upperCorner>176205.308000 624466.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>176205.308000 624466.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 111 179</ms:GML_ID>
        <ms:NAZWA>096 111 179</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096111179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>174063.350000 625023.359000</gml:lowerCorner>
        		<gml:upperCorner>174063.350000 625023.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>174063.350000 625023.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 114 829</ms:GML_ID>
        <ms:NAZWA>096 114 829</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096114829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>170527.501000 627079.348000</gml:lowerCorner>
        		<gml:upperCorner>170527.501000 627079.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>170527.501000 627079.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 120 916</ms:GML_ID>
        <ms:NAZWA>096 120 916</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096120916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>172052.332000 627289.049000</gml:lowerCorner>
        		<gml:upperCorner>172052.332000 627289.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>172052.332000 627289.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 118 855</ms:GML_ID>
        <ms:NAZWA>096 118 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096118855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>171321.393000 627307.593000</gml:lowerCorner>
        		<gml:upperCorner>171321.393000 627307.593000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>171321.393000 627307.593000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 119 816</ms:GML_ID>
        <ms:NAZWA>096 119 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096119816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168003.171727 629442.338649</gml:lowerCorner>
        		<gml:upperCorner>168003.171727 629442.338649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168003.171727 629442.338649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 126 385</ms:GML_ID>
        <ms:NAZWA>096 126 385</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096126385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168474.341521 629764.052439</gml:lowerCorner>
        		<gml:upperCorner>168474.341521 629764.052439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168474.341521 629764.052439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 125 814</ms:GML_ID>
        <ms:NAZWA>096 125 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096125814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167718.849000 630109.408000</gml:lowerCorner>
        		<gml:upperCorner>167718.849000 630109.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167718.849000 630109.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 127 465</ms:GML_ID>
        <ms:NAZWA>096 127 465</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096127465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165521.054000 632102.917000</gml:lowerCorner>
        		<gml:upperCorner>165521.054000 632102.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165521.054000 632102.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 130 985</ms:GML_ID>
        <ms:NAZWA>096 130 985</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096130985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165995.820943 634438.493059</gml:lowerCorner>
        		<gml:upperCorner>165995.820943 634438.493059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165995.820943 634438.493059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 134 200</ms:GML_ID>
        <ms:NAZWA>096 134 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096134200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165714.006000 636142.594000</gml:lowerCorner>
        		<gml:upperCorner>165714.006000 636142.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165714.006000 636142.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 136 146</ms:GML_ID>
        <ms:NAZWA>096 136 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096136146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165953.439000 636451.899000</gml:lowerCorner>
        		<gml:upperCorner>165953.439000 636451.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165953.439000 636451.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 136 546</ms:GML_ID>
        <ms:NAZWA>096 136 546</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096136546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165314.220000 637382.141000</gml:lowerCorner>
        		<gml:upperCorner>165314.220000 637382.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165314.220000 637382.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 139 679</ms:GML_ID>
        <ms:NAZWA>096 139 679</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096139679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>166867.586185 637416.908079</gml:lowerCorner>
        		<gml:upperCorner>166867.586185 637416.908079</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>166867.586185 637416.908079</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 000 993</ms:GML_ID>
        <ms:NAZWA>105 000 993</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105000993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>166754.692237 637459.562756</gml:lowerCorner>
        		<gml:upperCorner>166754.692237 637459.562756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>166754.692237 637459.562756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 137 954</ms:GML_ID>
        <ms:NAZWA>096 137 954</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096137954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>166685.848695 637606.553918</gml:lowerCorner>
        		<gml:upperCorner>166685.848695 637606.553918</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>166685.848695 637606.553918</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 138 085</ms:GML_ID>
        <ms:NAZWA>096 138 085</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096138085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167300.974000 637612.667000</gml:lowerCorner>
        		<gml:upperCorner>167300.974000 637612.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167300.974000 637612.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 001 505</ms:GML_ID>
        <ms:NAZWA>105 001 505</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105001505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>164993.065885 637928.335448</gml:lowerCorner>
        		<gml:upperCorner>164993.065885 637928.335448</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>164993.065885 637928.335448</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 140 299</ms:GML_ID>
        <ms:NAZWA>096 140 299</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096140299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167566.509000 638132.211000</gml:lowerCorner>
        		<gml:upperCorner>167566.509000 638132.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167566.509000 638132.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.105 002 101</ms:GML_ID>
        <ms:NAZWA>105 002 101</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>105002101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>163878.797974 638244.192269</gml:lowerCorner>
        		<gml:upperCorner>163878.797974 638244.192269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>163878.797974 638244.192269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 142 140</ms:GML_ID>
        <ms:NAZWA>096 142 140</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096142140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181484.622856 621701.344353</gml:lowerCorner>
        		<gml:upperCorner>181484.622856 621701.344353</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181484.622856 621701.344353</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 104 521</ms:GML_ID>
        <ms:NAZWA>096 104 521</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096104521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181573.250000 621713.308000</gml:lowerCorner>
        		<gml:upperCorner>181573.250000 621713.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181573.250000 621713.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 104 429</ms:GML_ID>
        <ms:NAZWA>096 104 429</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096104429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182055.060000 621643.917000</gml:lowerCorner>
        		<gml:upperCorner>182055.060000 621643.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182055.060000 621643.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 103 927</ms:GML_ID>
        <ms:NAZWA>096 103 927</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096103927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182544.954000 621020.570000</gml:lowerCorner>
        		<gml:upperCorner>182544.954000 621020.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182544.954000 621020.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 103 095</ms:GML_ID>
        <ms:NAZWA>096 103 095</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096103095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182769.475545 620232.939054</gml:lowerCorner>
        		<gml:upperCorner>182769.475545 620232.939054</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182769.475545 620232.939054</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 102 275</ms:GML_ID>
        <ms:NAZWA>096 102 275</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096102275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182896.198000 620003.470000</gml:lowerCorner>
        		<gml:upperCorner>182896.198000 620003.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182896.198000 620003.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 102 013</ms:GML_ID>
        <ms:NAZWA>096 102 013</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096102013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183312.388000 619641.288000</gml:lowerCorner>
        		<gml:upperCorner>183312.388000 619641.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183312.388000 619641.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 101 452</ms:GML_ID>
        <ms:NAZWA>096 101 452</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096101452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183821.757600 619495.452951</gml:lowerCorner>
        		<gml:upperCorner>183821.757600 619495.452951</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183821.757600 619495.452951</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 100 925</ms:GML_ID>
        <ms:NAZWA>096 100 925</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096100925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>184609.161000 619492.744000</gml:lowerCorner>
        		<gml:upperCorner>184609.161000 619492.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>184609.161000 619492.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 100 127</ms:GML_ID>
        <ms:NAZWA>096 100 127</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096100127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185078.621000 619395.151000</gml:lowerCorner>
        		<gml:upperCorner>185078.621000 619395.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185078.621000 619395.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 099 645</ms:GML_ID>
        <ms:NAZWA>096 099 645</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096099645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185351.574000 619334.391000</gml:lowerCorner>
        		<gml:upperCorner>185351.574000 619334.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185351.574000 619334.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 099 366</ms:GML_ID>
        <ms:NAZWA>096 099 366</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096099366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185794.403000 619236.092000</gml:lowerCorner>
        		<gml:upperCorner>185794.403000 619236.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185794.403000 619236.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 098 913</ms:GML_ID>
        <ms:NAZWA>096 098 913</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096098913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186081.221067 619171.994545</gml:lowerCorner>
        		<gml:upperCorner>186081.221067 619171.994545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186081.221067 619171.994545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 098 617</ms:GML_ID>
        <ms:NAZWA>096 098 617</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096098617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186651.931000 619071.248000</gml:lowerCorner>
        		<gml:upperCorner>186651.931000 619071.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186651.931000 619071.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 098 038</ms:GML_ID>
        <ms:NAZWA>096 098 038</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096098038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186997.711945 619051.562234</gml:lowerCorner>
        		<gml:upperCorner>186997.711945 619051.562234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186997.711945 619051.562234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 097 692</ms:GML_ID>
        <ms:NAZWA>096 097 692</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096097692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187334.664000 619031.912000</gml:lowerCorner>
        		<gml:upperCorner>187334.664000 619031.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187334.664000 619031.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 097 352</ms:GML_ID>
        <ms:NAZWA>096 097 352</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096097352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188721.099000 618871.103000</gml:lowerCorner>
        		<gml:upperCorner>188721.099000 618871.103000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188721.099000 618871.103000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 095 956</ms:GML_ID>
        <ms:NAZWA>096 095 956</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096095956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189595.125810 618776.255223</gml:lowerCorner>
        		<gml:upperCorner>189595.125810 618776.255223</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189595.125810 618776.255223</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 095 077</ms:GML_ID>
        <ms:NAZWA>096 095 077</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096095077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191398.570159 628099.515156</gml:lowerCorner>
        		<gml:upperCorner>191398.570159 628099.515156</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191398.570159 628099.515156</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 081 293</ms:GML_ID>
        <ms:NAZWA>096 081 293</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096081293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191408.650000 627927.570000</gml:lowerCorner>
        		<gml:upperCorner>191408.650000 627927.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191408.650000 627927.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 081 469</ms:GML_ID>
        <ms:NAZWA>096 081 469</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096081469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191488.277735 628435.205498</gml:lowerCorner>
        		<gml:upperCorner>191488.277735 628435.205498</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191488.277735 628435.205498</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 080 948</ms:GML_ID>
        <ms:NAZWA>096 080 948</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096080948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191511.824000 626836.734000</gml:lowerCorner>
        		<gml:upperCorner>191511.824000 626836.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191511.824000 626836.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 082 587</ms:GML_ID>
        <ms:NAZWA>096 082 587</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096082587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191623.323000 619577.669000</gml:lowerCorner>
        		<gml:upperCorner>191623.323000 619577.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191623.323000 619577.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 092 813</ms:GML_ID>
        <ms:NAZWA>096 092 813</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096092813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191674.253000 626507.625000</gml:lowerCorner>
        		<gml:upperCorner>191674.253000 626507.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191674.253000 626507.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 082 958</ms:GML_ID>
        <ms:NAZWA>096 082 958</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096082958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191692.506398 628989.044658</gml:lowerCorner>
        		<gml:upperCorner>191692.506398 628989.044658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191692.506398 628989.044658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 080 356</ms:GML_ID>
        <ms:NAZWA>096 080 356</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096080356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206763.381815 601720.091125</gml:lowerCorner>
        		<gml:upperCorner>206763.381815 601720.091125</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206763.381815 601720.091125</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 045 878</ms:GML_ID>
        <ms:NAZWA>104 045 878</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104045878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206579.602019 601946.149486</gml:lowerCorner>
        		<gml:upperCorner>206579.602019 601946.149486</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206579.602019 601946.149486</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 046 171</ms:GML_ID>
        <ms:NAZWA>104 046 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104046171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206311.896000 602272.942000</gml:lowerCorner>
        		<gml:upperCorner>206311.896000 602272.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206311.896000 602272.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 046 595</ms:GML_ID>
        <ms:NAZWA>104 046 595</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104046595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206187.306000 602387.100000</gml:lowerCorner>
        		<gml:upperCorner>206187.306000 602387.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206187.306000 602387.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 046 763</ms:GML_ID>
        <ms:NAZWA>104 046 763</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104046763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205746.638531 602676.281686</gml:lowerCorner>
        		<gml:upperCorner>205746.638531 602676.281686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205746.638531 602676.281686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 047 292</ms:GML_ID>
        <ms:NAZWA>104 047 292</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104047292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205525.661000 602938.858000</gml:lowerCorner>
        		<gml:upperCorner>205525.661000 602938.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205525.661000 602938.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 047 640</ms:GML_ID>
        <ms:NAZWA>104 047 640</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104047640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205041.629211 603702.531372</gml:lowerCorner>
        		<gml:upperCorner>205041.629211 603702.531372</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205041.629211 603702.531372</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 048 606</ms:GML_ID>
        <ms:NAZWA>104 048 606</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104048606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204826.946497 604282.803350</gml:lowerCorner>
        		<gml:upperCorner>204826.946497 604282.803350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204826.946497 604282.803350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 049 245</ms:GML_ID>
        <ms:NAZWA>104 049 245</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104049245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204764.972000 604484.948000</gml:lowerCorner>
        		<gml:upperCorner>204764.972000 604484.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204764.972000 604484.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 049 464</ms:GML_ID>
        <ms:NAZWA>104 049 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104049464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235620.123883 605242.493078</gml:lowerCorner>
        		<gml:upperCorner>235620.123883 605242.493078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235620.123883 605242.493078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 040 658</ms:GML_ID>
        <ms:NAZWA>091 040 658</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091040658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235846.260000 606243.331000</gml:lowerCorner>
        		<gml:upperCorner>235846.260000 606243.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235846.260000 606243.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 041 685</ms:GML_ID>
        <ms:NAZWA>091 041 685</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091041685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201610.527257 618832.632603</gml:lowerCorner>
        		<gml:upperCorner>201610.527257 618832.632603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201610.527257 618832.632603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 063 676</ms:GML_ID>
        <ms:NAZWA>104 063 676</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104063676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192544.657370 620169.750228</gml:lowerCorner>
        		<gml:upperCorner>192544.657370 620169.750228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192544.657370 620169.750228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 091 713</ms:GML_ID>
        <ms:NAZWA>096 091 713</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096091713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198744.362948 620780.187896</gml:lowerCorner>
        		<gml:upperCorner>198744.362948 620780.187896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198744.362948 620780.187896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 068 601</ms:GML_ID>
        <ms:NAZWA>104 068 601</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104068601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200932.443046 620910.735081</gml:lowerCorner>
        		<gml:upperCorner>200932.443046 620910.735081</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200932.443046 620910.735081</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 066 325</ms:GML_ID>
        <ms:NAZWA>104 066 325</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104066325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194063.843000 621980.478000</gml:lowerCorner>
        		<gml:upperCorner>194063.843000 621980.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194063.843000 621980.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 089 340</ms:GML_ID>
        <ms:NAZWA>096 089 340</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096089340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196306.250000 622005.385000</gml:lowerCorner>
        		<gml:upperCorner>196306.250000 622005.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196306.250000 622005.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 071 572</ms:GML_ID>
        <ms:NAZWA>104 071 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104071572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195927.977000 622203.005000</gml:lowerCorner>
        		<gml:upperCorner>195927.977000 622203.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195927.977000 622203.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 071 999</ms:GML_ID>
        <ms:NAZWA>104 071 999</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104071999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194530.204067 623982.347062</gml:lowerCorner>
        		<gml:upperCorner>194530.204067 623982.347062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194530.204067 623982.347062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.096 086 958</ms:GML_ID>
        <ms:NAZWA>096 086 958</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>096086958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208509.780548 593629.579244</gml:lowerCorner>
        		<gml:upperCorner>208509.780548 593629.579244</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208509.780548 593629.579244</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 035 638</ms:GML_ID>
        <ms:NAZWA>104 035 638</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104035638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208404.940834 594153.783684</gml:lowerCorner>
        		<gml:upperCorner>208404.940834 594153.783684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208404.940834 594153.783684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 036 174</ms:GML_ID>
        <ms:NAZWA>104 036 174</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104036174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208367.183054 594357.921137</gml:lowerCorner>
        		<gml:upperCorner>208367.183054 594357.921137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208367.183054 594357.921137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 036 381</ms:GML_ID>
        <ms:NAZWA>104 036 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104036381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208438.262875 595255.169013</gml:lowerCorner>
        		<gml:upperCorner>208438.262875 595255.169013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208438.262875 595255.169013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 037 356</ms:GML_ID>
        <ms:NAZWA>104 037 356</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104037356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208831.859288 595723.584988</gml:lowerCorner>
        		<gml:upperCorner>208831.859288 595723.584988</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208831.859288 595723.584988</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 037 990</ms:GML_ID>
        <ms:NAZWA>104 037 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104037990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208971.926279 596089.903896</gml:lowerCorner>
        		<gml:upperCorner>208971.926279 596089.903896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208971.926279 596089.903896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 038 390</ms:GML_ID>
        <ms:NAZWA>104 038 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104038390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209698.430252 597040.327162</gml:lowerCorner>
        		<gml:upperCorner>209698.430252 597040.327162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209698.430252 597040.327162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 039 631</ms:GML_ID>
        <ms:NAZWA>104 039 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104039631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209852.195000 597456.073000</gml:lowerCorner>
        		<gml:upperCorner>209852.195000 597456.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209852.195000 597456.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 040 075</ms:GML_ID>
        <ms:NAZWA>104 040 075</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104040075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209972.814898 597832.823141</gml:lowerCorner>
        		<gml:upperCorner>209972.814898 597832.823141</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209972.814898 597832.823141</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 040 473</ms:GML_ID>
        <ms:NAZWA>104 040 473</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104040473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209703.092000 598512.587000</gml:lowerCorner>
        		<gml:upperCorner>209703.092000 598512.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209703.092000 598512.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 041 245</ms:GML_ID>
        <ms:NAZWA>104 041 245</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104041245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209330.417000 598582.276000</gml:lowerCorner>
        		<gml:upperCorner>209330.417000 598582.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209330.417000 598582.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 041 626</ms:GML_ID>
        <ms:NAZWA>104 041 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104041626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209086.585128 598704.599300</gml:lowerCorner>
        		<gml:upperCorner>209086.585128 598704.599300</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209086.585128 598704.599300</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 041 904</ms:GML_ID>
        <ms:NAZWA>104 041 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104041904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208958.083000 598975.588000</gml:lowerCorner>
        		<gml:upperCorner>208958.083000 598975.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208958.083000 598975.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 042 207</ms:GML_ID>
        <ms:NAZWA>104 042 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104042207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208698.573242 599872.965210</gml:lowerCorner>
        		<gml:upperCorner>208698.573242 599872.965210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208698.573242 599872.965210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 043 125</ms:GML_ID>
        <ms:NAZWA>104 043 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104043125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208563.900064 600095.195598</gml:lowerCorner>
        		<gml:upperCorner>208563.900064 600095.195598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208563.900064 600095.195598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 043 405</ms:GML_ID>
        <ms:NAZWA>104 043 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104043405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207618.794739 600816.512634</gml:lowerCorner>
        		<gml:upperCorner>207618.794739 600816.512634</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207618.794739 600816.512634</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 044 616</ms:GML_ID>
        <ms:NAZWA>104 044 616</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104044616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207413.993000 601000.772000</gml:lowerCorner>
        		<gml:upperCorner>207413.993000 601000.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207413.993000 601000.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 044 904</ms:GML_ID>
        <ms:NAZWA>104 044 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104044904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207022.810791 601419.806519</gml:lowerCorner>
        		<gml:upperCorner>207022.810791 601419.806519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207022.810791 601419.806519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 045 482</ms:GML_ID>
        <ms:NAZWA>104 045 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104045482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201917.460772 578449.614713</gml:lowerCorner>
        		<gml:upperCorner>201917.460772 578449.614713</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201917.460772 578449.614713</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 016 277</ms:GML_ID>
        <ms:NAZWA>104 016 277</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104016277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202162.009560 578976.757449</gml:lowerCorner>
        		<gml:upperCorner>202162.009560 578976.757449</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202162.009560 578976.757449</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 016 890</ms:GML_ID>
        <ms:NAZWA>104 016 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104016890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202814.679699 580057.555819</gml:lowerCorner>
        		<gml:upperCorner>202814.679699 580057.555819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202814.679699 580057.555819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 018 182</ms:GML_ID>
        <ms:NAZWA>104 018 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104018182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203114.635000 580311.075000</gml:lowerCorner>
        		<gml:upperCorner>203114.635000 580311.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203114.635000 580311.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 018 605</ms:GML_ID>
        <ms:NAZWA>104 018 605</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104018605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203670.681058 580682.301651</gml:lowerCorner>
        		<gml:upperCorner>203670.681058 580682.301651</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203670.681058 580682.301651</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 019 277</ms:GML_ID>
        <ms:NAZWA>104 019 277</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104019277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203821.797871 580846.147220</gml:lowerCorner>
        		<gml:upperCorner>203821.797871 580846.147220</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203821.797871 580846.147220</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 019 501</ms:GML_ID>
        <ms:NAZWA>104 019 501</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104019501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204064.971429 581236.832048</gml:lowerCorner>
        		<gml:upperCorner>204064.971429 581236.832048</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204064.971429 581236.832048</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 019 971</ms:GML_ID>
        <ms:NAZWA>104 019 971</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104019971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204735.456000 581579.915000</gml:lowerCorner>
        		<gml:upperCorner>204735.456000 581579.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204735.456000 581579.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 020 818</ms:GML_ID>
        <ms:NAZWA>104 020 818</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104020818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204826.838968 581745.745607</gml:lowerCorner>
        		<gml:upperCorner>204826.838968 581745.745607</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204826.838968 581745.745607</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 021 015</ms:GML_ID>
        <ms:NAZWA>104 021 015</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104021015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204848.168000 582211.012000</gml:lowerCorner>
        		<gml:upperCorner>204848.168000 582211.012000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204848.168000 582211.012000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 021 496</ms:GML_ID>
        <ms:NAZWA>104 021 496</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104021496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205010.608000 582511.305000</gml:lowerCorner>
        		<gml:upperCorner>205010.608000 582511.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205010.608000 582511.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 021 868</ms:GML_ID>
        <ms:NAZWA>104 021 868</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104021868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205482.773000 582570.177000</gml:lowerCorner>
        		<gml:upperCorner>205482.773000 582570.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205482.773000 582570.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 022 349</ms:GML_ID>
        <ms:NAZWA>104 022 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104022349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205851.560885 582676.070946</gml:lowerCorner>
        		<gml:upperCorner>205851.560885 582676.070946</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205851.560885 582676.070946</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 022 736</ms:GML_ID>
        <ms:NAZWA>104 022 736</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104022736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206278.235492 582859.875793</gml:lowerCorner>
        		<gml:upperCorner>206278.235492 582859.875793</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206278.235492 582859.875793</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 023 200</ms:GML_ID>
        <ms:NAZWA>104 023 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104023200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206843.901000 583465.288000</gml:lowerCorner>
        		<gml:upperCorner>206843.901000 583465.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206843.901000 583465.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 024 046</ms:GML_ID>
        <ms:NAZWA>104 024 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104024046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206938.954000 583786.308000</gml:lowerCorner>
        		<gml:upperCorner>206938.954000 583786.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206938.954000 583786.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 024 383</ms:GML_ID>
        <ms:NAZWA>104 024 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104024383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207333.832000 585275.526000</gml:lowerCorner>
        		<gml:upperCorner>207333.832000 585275.526000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207333.832000 585275.526000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 025 941</ms:GML_ID>
        <ms:NAZWA>104 025 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104025941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207324.844000 585556.515000</gml:lowerCorner>
        		<gml:upperCorner>207324.844000 585556.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207324.844000 585556.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 026 224</ms:GML_ID>
        <ms:NAZWA>104 026 224</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104026224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207076.592000 586072.903000</gml:lowerCorner>
        		<gml:upperCorner>207076.592000 586072.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207076.592000 586072.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 026 832</ms:GML_ID>
        <ms:NAZWA>104 026 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104026832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207057.262000 586285.323000</gml:lowerCorner>
        		<gml:upperCorner>207057.262000 586285.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207057.262000 586285.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 027 051</ms:GML_ID>
        <ms:NAZWA>104 027 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104027051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206960.281977 586861.237729</gml:lowerCorner>
        		<gml:upperCorner>206960.281977 586861.237729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206960.281977 586861.237729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 027 645</ms:GML_ID>
        <ms:NAZWA>104 027 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104027645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207107.432000 587363.598000</gml:lowerCorner>
        		<gml:upperCorner>207107.432000 587363.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207107.432000 587363.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 028 296</ms:GML_ID>
        <ms:NAZWA>104 028 296</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104028296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207342.758000 587769.790000</gml:lowerCorner>
        		<gml:upperCorner>207342.758000 587769.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207342.758000 587769.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 028 768</ms:GML_ID>
        <ms:NAZWA>104 028 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104028768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207427.912650 587992.864935</gml:lowerCorner>
        		<gml:upperCorner>207427.912650 587992.864935</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207427.912650 587992.864935</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 029 007</ms:GML_ID>
        <ms:NAZWA>104 029 007</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104029007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207380.040612 588614.418048</gml:lowerCorner>
        		<gml:upperCorner>207380.040612 588614.418048</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207380.040612 588614.418048</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 029 654</ms:GML_ID>
        <ms:NAZWA>104 029 654</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104029654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207217.954000 588943.409000</gml:lowerCorner>
        		<gml:upperCorner>207217.954000 588943.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207217.954000 588943.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 030 032</ms:GML_ID>
        <ms:NAZWA>104 030 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104030032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207022.668838 589510.384875</gml:lowerCorner>
        		<gml:upperCorner>207022.668838 589510.384875</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207022.668838 589510.384875</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 030 637</ms:GML_ID>
        <ms:NAZWA>104 030 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104030637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206963.980912 589980.647179</gml:lowerCorner>
        		<gml:upperCorner>206963.980912 589980.647179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206963.980912 589980.647179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 031 118</ms:GML_ID>
        <ms:NAZWA>104 031 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104031118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207116.941692 590714.517317</gml:lowerCorner>
        		<gml:upperCorner>207116.941692 590714.517317</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207116.941692 590714.517317</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 031 930</ms:GML_ID>
        <ms:NAZWA>104 031 930</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104031930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207402.122000 591262.095000</gml:lowerCorner>
        		<gml:upperCorner>207402.122000 591262.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207402.122000 591262.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 032 554</ms:GML_ID>
        <ms:NAZWA>104 032 554</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104032554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207544.524000 591377.602000</gml:lowerCorner>
        		<gml:upperCorner>207544.524000 591377.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207544.524000 591377.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 032 738</ms:GML_ID>
        <ms:NAZWA>104 032 738</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104032738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207683.654000 591459.556000</gml:lowerCorner>
        		<gml:upperCorner>207683.654000 591459.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207683.654000 591459.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 032 902</ms:GML_ID>
        <ms:NAZWA>104 032 902</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104032902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208105.408000 591856.428000</gml:lowerCorner>
        		<gml:upperCorner>208105.408000 591856.428000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208105.408000 591856.428000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 033 693</ms:GML_ID>
        <ms:NAZWA>104 033 693</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104033693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208309.367000 592597.652000</gml:lowerCorner>
        		<gml:upperCorner>208309.367000 592597.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208309.367000 592597.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 034 507</ms:GML_ID>
        <ms:NAZWA>104 034 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104034507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265773.720354 575669.796746</gml:lowerCorner>
        		<gml:upperCorner>265773.720354 575669.796746</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265773.720354 575669.796746</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 289 857</ms:GML_ID>
        <ms:NAZWA>008 289 857</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008289857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263056.556425 577115.555151</gml:lowerCorner>
        		<gml:upperCorner>263056.556425 577115.555151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263056.556425 577115.555151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 293 036</ms:GML_ID>
        <ms:NAZWA>008 293 036</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008293036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252026.483672 577296.817263</gml:lowerCorner>
        		<gml:upperCorner>252026.483672 577296.817263</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252026.483672 577296.817263</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 306 380</ms:GML_ID>
        <ms:NAZWA>008 306 380</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008306380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260956.687222 577304.052087</gml:lowerCorner>
        		<gml:upperCorner>260956.687222 577304.052087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260956.687222 577304.052087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 295 210</ms:GML_ID>
        <ms:NAZWA>008 295 210</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008295210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247556.642605 581203.568293</gml:lowerCorner>
        		<gml:upperCorner>247556.642605 581203.568293</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247556.642605 581203.568293</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 021 546</ms:GML_ID>
        <ms:NAZWA>095 021 546</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095021546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247962.345435 582096.370194</gml:lowerCorner>
        		<gml:upperCorner>247962.345435 582096.370194</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247962.345435 582096.370194</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 022 530</ms:GML_ID>
        <ms:NAZWA>095 022 530</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095022530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239829.709994 583031.538616</gml:lowerCorner>
        		<gml:upperCorner>239829.709994 583031.538616</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239829.709994 583031.538616</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 017 734</ms:GML_ID>
        <ms:NAZWA>091 017 734</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091017734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243397.528507 583272.848158</gml:lowerCorner>
        		<gml:upperCorner>243397.528507 583272.848158</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243397.528507 583272.848158</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 028 481</ms:GML_ID>
        <ms:NAZWA>095 028 481</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095028481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247722.961052 583590.291283</gml:lowerCorner>
        		<gml:upperCorner>247722.961052 583590.291283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247722.961052 583590.291283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 024 744</ms:GML_ID>
        <ms:NAZWA>095 024 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095024744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237640.917419 594514.566611</gml:lowerCorner>
        		<gml:upperCorner>237640.917419 594514.566611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237640.917419 594514.566611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 029 519</ms:GML_ID>
        <ms:NAZWA>091 029 519</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091029519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236373.904000 608577.454000</gml:lowerCorner>
        		<gml:upperCorner>236373.904000 608577.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236373.904000 608577.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 044 079</ms:GML_ID>
        <ms:NAZWA>091 044 079</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091044079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236685.678000 611656.793000</gml:lowerCorner>
        		<gml:upperCorner>236685.678000 611656.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236685.678000 611656.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 047 188</ms:GML_ID>
        <ms:NAZWA>091 047 188</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091047188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236675.947910 615597.753909</gml:lowerCorner>
        		<gml:upperCorner>236675.947910 615597.753909</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236675.947910 615597.753909</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 051 139</ms:GML_ID>
        <ms:NAZWA>091 051 139</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091051139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237690.920000 620408.398000</gml:lowerCorner>
        		<gml:upperCorner>237690.920000 620408.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237690.920000 620408.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 056 102</ms:GML_ID>
        <ms:NAZWA>091 056 102</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091056102</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238875.897650 624940.946623</gml:lowerCorner>
        		<gml:upperCorner>238875.897650 624940.946623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238875.897650 624940.946623</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 060 898</ms:GML_ID>
        <ms:NAZWA>091 060 898</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091060898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238956.469208 626026.954029</gml:lowerCorner>
        		<gml:upperCorner>238956.469208 626026.954029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238956.469208 626026.954029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 061 988</ms:GML_ID>
        <ms:NAZWA>091 061 988</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091061988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253452.812000 635721.291000</gml:lowerCorner>
        		<gml:upperCorner>253452.812000 635721.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253452.812000 635721.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 016 663</ms:GML_ID>
        <ms:NAZWA>115 016 663</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115016663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252622.382000 635949.786000</gml:lowerCorner>
        		<gml:upperCorner>252622.382000 635949.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252622.382000 635949.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 015 737</ms:GML_ID>
        <ms:NAZWA>115 015 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115015737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253619.283711 635970.710721</gml:lowerCorner>
        		<gml:upperCorner>253619.283711 635970.710721</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253619.283711 635970.710721</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 016 967</ms:GML_ID>
        <ms:NAZWA>115 016 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115016967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252388.087000 636092.431000</gml:lowerCorner>
        		<gml:upperCorner>252388.087000 636092.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252388.087000 636092.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 015 462</ms:GML_ID>
        <ms:NAZWA>115 015 462</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115015462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253723.788000 636196.966000</gml:lowerCorner>
        		<gml:upperCorner>253723.788000 636196.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253723.788000 636196.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 017 216</ms:GML_ID>
        <ms:NAZWA>115 017 216</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115017216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251973.042613 636345.568437</gml:lowerCorner>
        		<gml:upperCorner>251973.042613 636345.568437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251973.042613 636345.568437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 014 975</ms:GML_ID>
        <ms:NAZWA>115 014 975</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115014975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253806.246000 636374.063000</gml:lowerCorner>
        		<gml:upperCorner>253806.246000 636374.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253806.246000 636374.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 017 411</ms:GML_ID>
        <ms:NAZWA>115 017 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115017411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253983.038000 636828.132000</gml:lowerCorner>
        		<gml:upperCorner>253983.038000 636828.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253983.038000 636828.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 017 901</ms:GML_ID>
        <ms:NAZWA>115 017 901</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115017901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250875.897062 637118.015085</gml:lowerCorner>
        		<gml:upperCorner>250875.897062 637118.015085</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250875.897062 637118.015085</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 013 633</ms:GML_ID>
        <ms:NAZWA>115 013 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115013633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254064.425217 637171.811400</gml:lowerCorner>
        		<gml:upperCorner>254064.425217 637171.811400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254064.425217 637171.811400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 018 254</ms:GML_ID>
        <ms:NAZWA>115 018 254</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115018254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254077.496390 637344.212155</gml:lowerCorner>
        		<gml:upperCorner>254077.496390 637344.212155</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254077.496390 637344.212155</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 018 427</ms:GML_ID>
        <ms:NAZWA>115 018 427</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115018427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250442.858222 637426.520410</gml:lowerCorner>
        		<gml:upperCorner>250442.858222 637426.520410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250442.858222 637426.520410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 013 100</ms:GML_ID>
        <ms:NAZWA>115 013 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115013100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261998.855000 637575.713000</gml:lowerCorner>
        		<gml:upperCorner>261998.855000 637575.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261998.855000 637575.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 030 530</ms:GML_ID>
        <ms:NAZWA>115 030 530</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115030530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>160905.183000 570904.869000</gml:lowerCorner>
        		<gml:upperCorner>160905.183000 570904.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>160905.183000 570904.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 041 751</ms:GML_ID>
        <ms:NAZWA>099 041 751</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099041751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>162342.555681 571954.889241</gml:lowerCorner>
        		<gml:upperCorner>162342.555681 571954.889241</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>162342.555681 571954.889241</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 039 965</ms:GML_ID>
        <ms:NAZWA>099 039 965</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099039965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>162971.734000 572418.636000</gml:lowerCorner>
        		<gml:upperCorner>162971.734000 572418.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>162971.734000 572418.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 039 163</ms:GML_ID>
        <ms:NAZWA>099 039 163</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099039163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>165494.027000 572860.117000</gml:lowerCorner>
        		<gml:upperCorner>165494.027000 572860.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>165494.027000 572860.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 036 467</ms:GML_ID>
        <ms:NAZWA>099 036 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099036467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>166443.972000 572720.052000</gml:lowerCorner>
        		<gml:upperCorner>166443.972000 572720.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>166443.972000 572720.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 035 513</ms:GML_ID>
        <ms:NAZWA>099 035 513</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099035513</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>167322.974000 572787.707000</gml:lowerCorner>
        		<gml:upperCorner>167322.974000 572787.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>167322.974000 572787.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 034 615</ms:GML_ID>
        <ms:NAZWA>099 034 615</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099034615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168385.473000 573244.031000</gml:lowerCorner>
        		<gml:upperCorner>168385.473000 573244.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168385.473000 573244.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 033 450</ms:GML_ID>
        <ms:NAZWA>099 033 450</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099033450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>168924.675000 573390.219000</gml:lowerCorner>
        		<gml:upperCorner>168924.675000 573390.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>168924.675000 573390.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 032 888</ms:GML_ID>
        <ms:NAZWA>099 032 888</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099032888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>170583.894218 573710.442311</gml:lowerCorner>
        		<gml:upperCorner>170583.894218 573710.442311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>170583.894218 573710.442311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 031 161</ms:GML_ID>
        <ms:NAZWA>099 031 161</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099031161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>172291.782000 573810.844000</gml:lowerCorner>
        		<gml:upperCorner>172291.782000 573810.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>172291.782000 573810.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 029 449</ms:GML_ID>
        <ms:NAZWA>099 029 449</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099029449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>172663.504136 573834.937050</gml:lowerCorner>
        		<gml:upperCorner>172663.504136 573834.937050</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>172663.504136 573834.937050</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 029 077</ms:GML_ID>
        <ms:NAZWA>099 029 077</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099029077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>173028.304197 573858.388598</gml:lowerCorner>
        		<gml:upperCorner>173028.304197 573858.388598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>173028.304197 573858.388598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 028 712</ms:GML_ID>
        <ms:NAZWA>099 028 712</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099028712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>173486.207065 573887.780848</gml:lowerCorner>
        		<gml:upperCorner>173486.207065 573887.780848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>173486.207065 573887.780848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 028 255</ms:GML_ID>
        <ms:NAZWA>099 028 255</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099028255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>173900.303000 573942.796000</gml:lowerCorner>
        		<gml:upperCorner>173900.303000 573942.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>173900.303000 573942.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 027 832</ms:GML_ID>
        <ms:NAZWA>099 027 832</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099027832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>175026.552000 573779.937000</gml:lowerCorner>
        		<gml:upperCorner>175026.552000 573779.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>175026.552000 573779.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 026 667</ms:GML_ID>
        <ms:NAZWA>099 026 667</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099026667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>175921.419000 573584.337000</gml:lowerCorner>
        		<gml:upperCorner>175921.419000 573584.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>175921.419000 573584.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 025 749</ms:GML_ID>
        <ms:NAZWA>099 025 749</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099025749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>178342.155000 573828.827000</gml:lowerCorner>
        		<gml:upperCorner>178342.155000 573828.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>178342.155000 573828.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 023 265</ms:GML_ID>
        <ms:NAZWA>099 023 265</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099023265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>179174.735000 573391.000000</gml:lowerCorner>
        		<gml:upperCorner>179174.735000 573391.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>179174.735000 573391.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 022 320</ms:GML_ID>
        <ms:NAZWA>099 022 320</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099022320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180261.864000 572096.971000</gml:lowerCorner>
        		<gml:upperCorner>180261.864000 572096.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180261.864000 572096.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 020 170</ms:GML_ID>
        <ms:NAZWA>099 020 170</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099020170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195912.379282 572806.600328</gml:lowerCorner>
        		<gml:upperCorner>195912.379282 572806.600328</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195912.379282 572806.600328</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 006 977</ms:GML_ID>
        <ms:NAZWA>104 006 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104006977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196004.856000 571858.547000</gml:lowerCorner>
        		<gml:upperCorner>196004.856000 571858.547000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196004.856000 571858.547000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 005 943</ms:GML_ID>
        <ms:NAZWA>104 005 943</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104005943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196077.730582 573045.716506</gml:lowerCorner>
        		<gml:upperCorner>196077.730582 573045.716506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196077.730582 573045.716506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 007 272</ms:GML_ID>
        <ms:NAZWA>104 007 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104007272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196285.945000 573214.605000</gml:lowerCorner>
        		<gml:upperCorner>196285.945000 573214.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196285.945000 573214.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 007 539</ms:GML_ID>
        <ms:NAZWA>104 007 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104007539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196505.703955 573365.058222</gml:lowerCorner>
        		<gml:upperCorner>196505.703955 573365.058222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196505.703955 573365.058222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 007 808</ms:GML_ID>
        <ms:NAZWA>104 007 808</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104007808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196868.417358 573933.148254</gml:lowerCorner>
        		<gml:upperCorner>196868.417358 573933.148254</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196868.417358 573933.148254</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 008 520</ms:GML_ID>
        <ms:NAZWA>104 008 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104008520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197381.171963 574520.548955</gml:lowerCorner>
        		<gml:upperCorner>197381.171963 574520.548955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197381.171963 574520.548955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 009 311</ms:GML_ID>
        <ms:NAZWA>104 009 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104009311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198402.942034 575458.544216</gml:lowerCorner>
        		<gml:upperCorner>198402.942034 575458.544216</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198402.942034 575458.544216</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 010 713</ms:GML_ID>
        <ms:NAZWA>104 010 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104010713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198790.997000 575689.608000</gml:lowerCorner>
        		<gml:upperCorner>198790.997000 575689.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198790.997000 575689.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 011 167</ms:GML_ID>
        <ms:NAZWA>104 011 167</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104011167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199265.388110 576057.699330</gml:lowerCorner>
        		<gml:upperCorner>199265.388110 576057.699330</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199265.388110 576057.699330</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 011 773</ms:GML_ID>
        <ms:NAZWA>104 011 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104011773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199577.136511 576472.346986</gml:lowerCorner>
        		<gml:upperCorner>199577.136511 576472.346986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199577.136511 576472.346986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 012 291</ms:GML_ID>
        <ms:NAZWA>104 012 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104012291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199851.519000 576659.763000</gml:lowerCorner>
        		<gml:upperCorner>199851.519000 576659.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199851.519000 576659.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 012 627</ms:GML_ID>
        <ms:NAZWA>104 012 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104012627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200162.916000 576716.201000</gml:lowerCorner>
        		<gml:upperCorner>200162.916000 576716.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200162.916000 576716.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 012 948</ms:GML_ID>
        <ms:NAZWA>104 012 948</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104012948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201147.801561 577875.189644</gml:lowerCorner>
        		<gml:upperCorner>201147.801561 577875.189644</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201147.801561 577875.189644</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 015 264</ms:GML_ID>
        <ms:NAZWA>104 015 264</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104015264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201283.509365 577313.441159</gml:lowerCorner>
        		<gml:upperCorner>201283.509365 577313.441159</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201283.509365 577313.441159</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 014 685</ms:GML_ID>
        <ms:NAZWA>104 014 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104014685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182149.270000 570621.262000</gml:lowerCorner>
        		<gml:upperCorner>182149.270000 570621.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182149.270000 570621.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 017 622</ms:GML_ID>
        <ms:NAZWA>099 017 622</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099017622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182312.752000 570459.726000</gml:lowerCorner>
        		<gml:upperCorner>182312.752000 570459.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182312.752000 570459.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 017 383</ms:GML_ID>
        <ms:NAZWA>099 017 383</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099017383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182639.036000 570401.177000</gml:lowerCorner>
        		<gml:upperCorner>182639.036000 570401.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182639.036000 570401.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 017 048</ms:GML_ID>
        <ms:NAZWA>099 017 048</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099017048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183017.226000 570367.963000</gml:lowerCorner>
        		<gml:upperCorner>183017.226000 570367.963000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183017.226000 570367.963000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 016 653</ms:GML_ID>
        <ms:NAZWA>099 016 653</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099016653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183298.091935 570213.620284</gml:lowerCorner>
        		<gml:upperCorner>183298.091935 570213.620284</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183298.091935 570213.620284</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 016 315</ms:GML_ID>
        <ms:NAZWA>099 016 315</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099016315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183607.387117 570003.254525</gml:lowerCorner>
        		<gml:upperCorner>183607.387117 570003.254525</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183607.387117 570003.254525</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 015 911</ms:GML_ID>
        <ms:NAZWA>099 015 911</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099015911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185002.789000 569323.545000</gml:lowerCorner>
        		<gml:upperCorner>185002.789000 569323.545000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185002.789000 569323.545000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 014 178</ms:GML_ID>
        <ms:NAZWA>099 014 178</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099014178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185231.958000 569082.086000</gml:lowerCorner>
        		<gml:upperCorner>185231.958000 569082.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185231.958000 569082.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 013 838</ms:GML_ID>
        <ms:NAZWA>099 013 838</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099013838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185499.627000 569009.645000</gml:lowerCorner>
        		<gml:upperCorner>185499.627000 569009.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185499.627000 569009.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 013 559</ms:GML_ID>
        <ms:NAZWA>099 013 559</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099013559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185631.267000 568813.591000</gml:lowerCorner>
        		<gml:upperCorner>185631.267000 568813.591000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185631.267000 568813.591000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 013 317</ms:GML_ID>
        <ms:NAZWA>099 013 317</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099013317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185837.684000 568668.276000</gml:lowerCorner>
        		<gml:upperCorner>185837.684000 568668.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185837.684000 568668.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 013 053</ms:GML_ID>
        <ms:NAZWA>099 013 053</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099013053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186032.692000 568554.922000</gml:lowerCorner>
        		<gml:upperCorner>186032.692000 568554.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186032.692000 568554.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 012 819</ms:GML_ID>
        <ms:NAZWA>099 012 819</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099012819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186103.662972 568231.566715</gml:lowerCorner>
        		<gml:upperCorner>186103.662972 568231.566715</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186103.662972 568231.566715</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 012 484</ms:GML_ID>
        <ms:NAZWA>099 012 484</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099012484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186109.479000 567998.712000</gml:lowerCorner>
        		<gml:upperCorner>186109.479000 567998.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186109.479000 567998.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 012 251</ms:GML_ID>
        <ms:NAZWA>099 012 251</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099012251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186113.063000 567870.927000</gml:lowerCorner>
        		<gml:upperCorner>186113.063000 567870.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186113.063000 567870.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 012 122</ms:GML_ID>
        <ms:NAZWA>099 012 122</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099012122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186244.549821 567152.593837</gml:lowerCorner>
        		<gml:upperCorner>186244.549821 567152.593837</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186244.549821 567152.593837</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 011 369</ms:GML_ID>
        <ms:NAZWA>099 011 369</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099011369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186244.902107 566417.861631</gml:lowerCorner>
        		<gml:upperCorner>186244.902107 566417.861631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186244.902107 566417.861631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 010 601</ms:GML_ID>
        <ms:NAZWA>099 010 601</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099010601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186246.160000 565396.076000</gml:lowerCorner>
        		<gml:upperCorner>186246.160000 565396.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186246.160000 565396.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 009 547</ms:GML_ID>
        <ms:NAZWA>099 009 547</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099009547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186269.334000 565259.179000</gml:lowerCorner>
        		<gml:upperCorner>186269.334000 565259.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186269.334000 565259.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 009 409</ms:GML_ID>
        <ms:NAZWA>099 009 409</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099009409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186324.807502 565924.754493</gml:lowerCorner>
        		<gml:upperCorner>186324.807502 565924.754493</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186324.807502 565924.754493</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 010 088</ms:GML_ID>
        <ms:NAZWA>099 010 088</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099010088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187345.872000 563984.577000</gml:lowerCorner>
        		<gml:upperCorner>187345.872000 563984.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187345.872000 563984.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 007 526</ms:GML_ID>
        <ms:NAZWA>099 007 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099007526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187847.493000 563759.908000</gml:lowerCorner>
        		<gml:upperCorner>187847.493000 563759.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187847.493000 563759.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 006 935</ms:GML_ID>
        <ms:NAZWA>099 006 935</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099006935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188033.949000 563692.548000</gml:lowerCorner>
        		<gml:upperCorner>188033.949000 563692.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188033.949000 563692.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 006 743</ms:GML_ID>
        <ms:NAZWA>099 006 743</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099006743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188861.198788 563615.821642</gml:lowerCorner>
        		<gml:upperCorner>188861.198788 563615.821642</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188861.198788 563615.821642</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 005 867</ms:GML_ID>
        <ms:NAZWA>099 005 867</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099005867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189207.581000 563938.492000</gml:lowerCorner>
        		<gml:upperCorner>189207.581000 563938.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189207.581000 563938.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 005 384</ms:GML_ID>
        <ms:NAZWA>099 005 384</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099005384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189493.352000 564244.308000</gml:lowerCorner>
        		<gml:upperCorner>189493.352000 564244.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189493.352000 564244.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 004 963</ms:GML_ID>
        <ms:NAZWA>099 004 963</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099004963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189716.960000 564752.646000</gml:lowerCorner>
        		<gml:upperCorner>189716.960000 564752.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189716.960000 564752.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 004 403</ms:GML_ID>
        <ms:NAZWA>099 004 403</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099004403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189763.959000 564877.358000</gml:lowerCorner>
        		<gml:upperCorner>189763.959000 564877.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189763.959000 564877.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 004 270</ms:GML_ID>
        <ms:NAZWA>099 004 270</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099004270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189913.261000 565084.511000</gml:lowerCorner>
        		<gml:upperCorner>189913.261000 565084.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189913.261000 565084.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 004 006</ms:GML_ID>
        <ms:NAZWA>099 004 006</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099004006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246189.882584 560689.483644</gml:lowerCorner>
        		<gml:upperCorner>246189.882584 560689.483644</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246189.882584 560689.483644</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 008 342</ms:GML_ID>
        <ms:NAZWA>118 008 342</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118008342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246227.201008 561055.722831</gml:lowerCorner>
        		<gml:upperCorner>246227.201008 561055.722831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246227.201008 561055.722831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 007 964</ms:GML_ID>
        <ms:NAZWA>118 007 964</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118007964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235435.331000 561617.546000</gml:lowerCorner>
        		<gml:upperCorner>235435.331000 561617.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235435.331000 561617.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 012 630</ms:GML_ID>
        <ms:NAZWA>094 012 630</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094012630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235714.019000 562579.464000</gml:lowerCorner>
        		<gml:upperCorner>235714.019000 562579.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235714.019000 562579.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 011 605</ms:GML_ID>
        <ms:NAZWA>094 011 605</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094011605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235761.665752 562954.148548</gml:lowerCorner>
        		<gml:upperCorner>235761.665752 562954.148548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235761.665752 562954.148548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 011 228</ms:GML_ID>
        <ms:NAZWA>094 011 228</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094011228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236126.509084 564476.400624</gml:lowerCorner>
        		<gml:upperCorner>236126.509084 564476.400624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236126.509084 564476.400624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 009 633</ms:GML_ID>
        <ms:NAZWA>094 009 633</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094009633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247825.441000 565473.026000</gml:lowerCorner>
        		<gml:upperCorner>247825.441000 565473.026000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247825.441000 565473.026000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 004 536</ms:GML_ID>
        <ms:NAZWA>095 004 536</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095004536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246510.264214 565915.579528</gml:lowerCorner>
        		<gml:upperCorner>246510.264214 565915.579528</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246510.264214 565915.579528</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 004 530</ms:GML_ID>
        <ms:NAZWA>100 004 530</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100004530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237161.432766 566171.115291</gml:lowerCorner>
        		<gml:upperCorner>237161.432766 566171.115291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237161.432766 566171.115291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 007 504</ms:GML_ID>
        <ms:NAZWA>094 007 504</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094007504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239843.763000 566865.679000</gml:lowerCorner>
        		<gml:upperCorner>239843.763000 566865.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239843.763000 566865.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 004 410</ms:GML_ID>
        <ms:NAZWA>094 004 410</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094004410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240447.179622 567384.623347</gml:lowerCorner>
        		<gml:upperCorner>240447.179622 567384.623347</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240447.179622 567384.623347</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 003 538</ms:GML_ID>
        <ms:NAZWA>094 003 538</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094003538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246016.871841 567612.534742</gml:lowerCorner>
        		<gml:upperCorner>246016.871841 567612.534742</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246016.871841 567612.534742</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 318 359</ms:GML_ID>
        <ms:NAZWA>008 318 359</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008318359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244539.527000 570197.556000</gml:lowerCorner>
        		<gml:upperCorner>244539.527000 570197.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244539.527000 570197.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.947 001 405</ms:GML_ID>
        <ms:NAZWA>947 001 405</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>947001405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244254.594000 570757.190000</gml:lowerCorner>
        		<gml:upperCorner>244254.594000 570757.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244254.594000 570757.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.947 002 037</ms:GML_ID>
        <ms:NAZWA>947 002 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>947002037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240557.538161 571776.171189</gml:lowerCorner>
        		<gml:upperCorner>240557.538161 571776.171189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240557.538161 571776.171189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 015 239</ms:GML_ID>
        <ms:NAZWA>100 015 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100015239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240711.756188 571869.555615</gml:lowerCorner>
        		<gml:upperCorner>240711.756188 571869.555615</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240711.756188 571869.555615</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 015 130</ms:GML_ID>
        <ms:NAZWA>100 015 130</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100015130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240540.240000 571874.455000</gml:lowerCorner>
        		<gml:upperCorner>240540.240000 571874.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240540.240000 571874.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.603 002 502</ms:GML_ID>
        <ms:NAZWA>603 002 502</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>603002502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247554.843659 576727.633580</gml:lowerCorner>
        		<gml:upperCorner>247554.843659 576727.633580</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247554.843659 576727.633580</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.095 016 994</ms:GML_ID>
        <ms:NAZWA>095 016 994</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>095016994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190176.668000 565289.538000</gml:lowerCorner>
        		<gml:upperCorner>190176.668000 565289.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190176.668000 565289.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 003 675</ms:GML_ID>
        <ms:NAZWA>099 003 675</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099003675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190420.686000 565412.733000</gml:lowerCorner>
        		<gml:upperCorner>190420.686000 565412.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190420.686000 565412.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 003 397</ms:GML_ID>
        <ms:NAZWA>099 003 397</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099003397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190701.457290 565691.213959</gml:lowerCorner>
        		<gml:upperCorner>190701.457290 565691.213959</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190701.457290 565691.213959</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 002 993</ms:GML_ID>
        <ms:NAZWA>099 002 993</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099002993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190840.742000 565877.617000</gml:lowerCorner>
        		<gml:upperCorner>190840.742000 565877.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190840.742000 565877.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 002 760</ms:GML_ID>
        <ms:NAZWA>099 002 760</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099002760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191636.615000 566449.122000</gml:lowerCorner>
        		<gml:upperCorner>191636.615000 566449.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191636.615000 566449.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 001 761</ms:GML_ID>
        <ms:NAZWA>099 001 761</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099001761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192209.759148 566645.953737</gml:lowerCorner>
        		<gml:upperCorner>192209.759148 566645.953737</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192209.759148 566645.953737</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 001 129</ms:GML_ID>
        <ms:NAZWA>099 001 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099001129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192543.746366 567111.784351</gml:lowerCorner>
        		<gml:upperCorner>192543.746366 567111.784351</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192543.746366 567111.784351</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.099 000 548</ms:GML_ID>
        <ms:NAZWA>099 000 548</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>099000548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192740.007000 566102.495000</gml:lowerCorner>
        		<gml:upperCorner>192740.007000 566102.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192740.007000 566102.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 032 974</ms:GML_ID>
        <ms:NAZWA>098 032 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098032974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193480.863832 565562.441809</gml:lowerCorner>
        		<gml:upperCorner>193480.863832 565562.441809</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193480.863832 565562.441809</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 032 037</ms:GML_ID>
        <ms:NAZWA>098 032 037</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098032037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194078.603561 568770.801923</gml:lowerCorner>
        		<gml:upperCorner>194078.603561 568770.801923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194078.603561 568770.801923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 001 980</ms:GML_ID>
        <ms:NAZWA>104 001 980</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104001980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194454.560000 564966.070000</gml:lowerCorner>
        		<gml:upperCorner>194454.560000 564966.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194454.560000 564966.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 030 806</ms:GML_ID>
        <ms:NAZWA>098 030 806</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098030806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194477.818000 568923.336000</gml:lowerCorner>
        		<gml:upperCorner>194477.818000 568923.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194477.818000 568923.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.104 002 409</ms:GML_ID>
        <ms:NAZWA>104 002 409</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>104002409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195361.815000 564201.041000</gml:lowerCorner>
        		<gml:upperCorner>195361.815000 564201.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195361.815000 564201.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 029 483</ms:GML_ID>
        <ms:NAZWA>098 029 483</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098029483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196185.215079 563754.574714</gml:lowerCorner>
        		<gml:upperCorner>196185.215079 563754.574714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196185.215079 563754.574714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 028 528</ms:GML_ID>
        <ms:NAZWA>098 028 528</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098028528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196852.816016 559908.505849</gml:lowerCorner>
        		<gml:upperCorner>196852.816016 559908.505849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196852.816016 559908.505849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 024 089</ms:GML_ID>
        <ms:NAZWA>098 024 089</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098024089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196940.959000 562107.756000</gml:lowerCorner>
        		<gml:upperCorner>196940.959000 562107.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196940.959000 562107.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 026 559</ms:GML_ID>
        <ms:NAZWA>098 026 559</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098026559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197062.673791 560932.061250</gml:lowerCorner>
        		<gml:upperCorner>197062.673791 560932.061250</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197062.673791 560932.061250</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 025 250</ms:GML_ID>
        <ms:NAZWA>098 025 250</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098025250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197102.767000 561442.784000</gml:lowerCorner>
        		<gml:upperCorner>197102.767000 561442.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197102.767000 561442.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 025 790</ms:GML_ID>
        <ms:NAZWA>098 025 790</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098025790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197552.138122 558816.077472</gml:lowerCorner>
        		<gml:upperCorner>197552.138122 558816.077472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197552.138122 558816.077472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 022 619</ms:GML_ID>
        <ms:NAZWA>098 022 619</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098022619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197778.196000 557963.996000</gml:lowerCorner>
        		<gml:upperCorner>197778.196000 557963.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197778.196000 557963.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 021 686</ms:GML_ID>
        <ms:NAZWA>098 021 686</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098021686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199256.085000 556838.997000</gml:lowerCorner>
        		<gml:upperCorner>199256.085000 556838.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199256.085000 556838.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 019 728</ms:GML_ID>
        <ms:NAZWA>098 019 728</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098019728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199461.466000 556743.652000</gml:lowerCorner>
        		<gml:upperCorner>199461.466000 556743.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199461.466000 556743.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 019 507</ms:GML_ID>
        <ms:NAZWA>098 019 507</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098019507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199781.742000 555956.404000</gml:lowerCorner>
        		<gml:upperCorner>199781.742000 555956.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199781.742000 555956.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 018 511</ms:GML_ID>
        <ms:NAZWA>098 018 511</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098018511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199952.621000 555746.002000</gml:lowerCorner>
        		<gml:upperCorner>199952.621000 555746.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199952.621000 555746.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 018 225</ms:GML_ID>
        <ms:NAZWA>098 018 225</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098018225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200405.659597 555520.846410</gml:lowerCorner>
        		<gml:upperCorner>200405.659597 555520.846410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200405.659597 555520.846410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 017 661</ms:GML_ID>
        <ms:NAZWA>098 017 661</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098017661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200524.398000 555348.219000</gml:lowerCorner>
        		<gml:upperCorner>200524.398000 555348.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200524.398000 555348.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 017 450</ms:GML_ID>
        <ms:NAZWA>098 017 450</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098017450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200693.121000 555249.099000</gml:lowerCorner>
        		<gml:upperCorner>200693.121000 555249.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200693.121000 555249.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 017 255</ms:GML_ID>
        <ms:NAZWA>098 017 255</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098017255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201027.747067 554756.213875</gml:lowerCorner>
        		<gml:upperCorner>201027.747067 554756.213875</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201027.747067 554756.213875</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 016 647</ms:GML_ID>
        <ms:NAZWA>098 016 647</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098016647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201248.768518 554399.191049</gml:lowerCorner>
        		<gml:upperCorner>201248.768518 554399.191049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201248.768518 554399.191049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 016 209</ms:GML_ID>
        <ms:NAZWA>098 016 209</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098016209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201891.038213 553754.990468</gml:lowerCorner>
        		<gml:upperCorner>201891.038213 553754.990468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201891.038213 553754.990468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 015 294</ms:GML_ID>
        <ms:NAZWA>098 015 294</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098015294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225058.462000 553571.008000</gml:lowerCorner>
        		<gml:upperCorner>225058.462000 553571.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225058.462000 553571.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 013 495</ms:GML_ID>
        <ms:NAZWA>097 013 495</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097013495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225132.612000 552683.077000</gml:lowerCorner>
        		<gml:upperCorner>225132.612000 552683.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225132.612000 552683.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 014 424</ms:GML_ID>
        <ms:NAZWA>097 014 424</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097014424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225339.776794 552085.165014</gml:lowerCorner>
        		<gml:upperCorner>225339.776794 552085.165014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225339.776794 552085.165014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 015 057</ms:GML_ID>
        <ms:NAZWA>097 015 057</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097015057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225394.669000 553716.213000</gml:lowerCorner>
        		<gml:upperCorner>225394.669000 553716.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225394.669000 553716.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 013 124</ms:GML_ID>
        <ms:NAZWA>097 013 124</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097013124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225478.131000 551761.199000</gml:lowerCorner>
        		<gml:upperCorner>225478.131000 551761.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225478.131000 551761.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 015 408</ms:GML_ID>
        <ms:NAZWA>097 015 408</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097015408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225800.396163 551123.495569</gml:lowerCorner>
        		<gml:upperCorner>225800.396163 551123.495569</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225800.396163 551123.495569</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 016 129</ms:GML_ID>
        <ms:NAZWA>097 016 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097016129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226205.823000 554484.013000</gml:lowerCorner>
        		<gml:upperCorner>226205.823000 554484.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226205.823000 554484.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 011 966</ms:GML_ID>
        <ms:NAZWA>097 011 966</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097011966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226307.533000 549865.223000</gml:lowerCorner>
        		<gml:upperCorner>226307.533000 549865.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226307.533000 549865.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 017 534</ms:GML_ID>
        <ms:NAZWA>097 017 534</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097017534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226355.172270 554712.826768</gml:lowerCorner>
        		<gml:upperCorner>226355.172270 554712.826768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226355.172270 554712.826768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 011 693</ms:GML_ID>
        <ms:NAZWA>097 011 693</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097011693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226446.974000 555089.061000</gml:lowerCorner>
        		<gml:upperCorner>226446.974000 555089.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226446.974000 555089.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 011 292</ms:GML_ID>
        <ms:NAZWA>097 011 292</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097011292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226519.496000 555398.894000</gml:lowerCorner>
        		<gml:upperCorner>226519.496000 555398.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226519.496000 555398.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 010 960</ms:GML_ID>
        <ms:NAZWA>097 010 960</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097010960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226756.920000 555673.149000</gml:lowerCorner>
        		<gml:upperCorner>226756.920000 555673.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226756.920000 555673.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 010 597</ms:GML_ID>
        <ms:NAZWA>097 010 597</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097010597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226929.908468 555883.233925</gml:lowerCorner>
        		<gml:upperCorner>226929.908468 555883.233925</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226929.908468 555883.233925</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 010 325</ms:GML_ID>
        <ms:NAZWA>097 010 325</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097010325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227012.810000 556048.858000</gml:lowerCorner>
        		<gml:upperCorner>227012.810000 556048.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227012.810000 556048.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 010 139</ms:GML_ID>
        <ms:NAZWA>097 010 139</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097010139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227300.630555 556918.296881</gml:lowerCorner>
        		<gml:upperCorner>227300.630555 556918.296881</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227300.630555 556918.296881</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 009 218</ms:GML_ID>
        <ms:NAZWA>097 009 218</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097009218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227379.750195 557356.301086</gml:lowerCorner>
        		<gml:upperCorner>227379.750195 557356.301086</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227379.750195 557356.301086</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 008 765</ms:GML_ID>
        <ms:NAZWA>097 008 765</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097008765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227854.462000 558035.226000</gml:lowerCorner>
        		<gml:upperCorner>227854.462000 558035.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227854.462000 558035.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 007 564</ms:GML_ID>
        <ms:NAZWA>097 007 564</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097007564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228940.275000 558061.358000</gml:lowerCorner>
        		<gml:upperCorner>228940.275000 558061.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228940.275000 558061.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 006 470</ms:GML_ID>
        <ms:NAZWA>097 006 470</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097006470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229438.280570 558105.585323</gml:lowerCorner>
        		<gml:upperCorner>229438.280570 558105.585323</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229438.280570 558105.585323</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 005 971</ms:GML_ID>
        <ms:NAZWA>097 005 971</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097005971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229890.538000 558090.295000</gml:lowerCorner>
        		<gml:upperCorner>229890.538000 558090.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229890.538000 558090.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 005 507</ms:GML_ID>
        <ms:NAZWA>097 005 507</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097005507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230391.840000 557819.513000</gml:lowerCorner>
        		<gml:upperCorner>230391.840000 557819.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230391.840000 557819.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 004 934</ms:GML_ID>
        <ms:NAZWA>097 004 934</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097004934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230728.303799 557698.447833</gml:lowerCorner>
        		<gml:upperCorner>230728.303799 557698.447833</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230728.303799 557698.447833</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 004 575</ms:GML_ID>
        <ms:NAZWA>097 004 575</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097004575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231144.310018 557695.332716</gml:lowerCorner>
        		<gml:upperCorner>231144.310018 557695.332716</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231144.310018 557695.332716</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 004 158</ms:GML_ID>
        <ms:NAZWA>097 004 158</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097004158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232867.734457 549812.736795</gml:lowerCorner>
        		<gml:upperCorner>232867.734457 549812.736795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232867.734457 549812.736795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 025 142</ms:GML_ID>
        <ms:NAZWA>094 025 142</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094025142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232711.288474 550274.800003</gml:lowerCorner>
        		<gml:upperCorner>232711.288474 550274.800003</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232711.288474 550274.800003</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 024 652</ms:GML_ID>
        <ms:NAZWA>094 024 652</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094024652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232745.162000 551654.319000</gml:lowerCorner>
        		<gml:upperCorner>232745.162000 551654.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232745.162000 551654.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 023 257</ms:GML_ID>
        <ms:NAZWA>094 023 257</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094023257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232726.375000 552245.231000</gml:lowerCorner>
        		<gml:upperCorner>232726.375000 552245.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232726.375000 552245.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 022 668</ms:GML_ID>
        <ms:NAZWA>094 022 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094022668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232930.266000 553591.278000</gml:lowerCorner>
        		<gml:upperCorner>232930.266000 553591.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232930.266000 553591.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 021 298</ms:GML_ID>
        <ms:NAZWA>094 021 298</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094021298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233302.846070 554798.039143</gml:lowerCorner>
        		<gml:upperCorner>233302.846070 554798.039143</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233302.846070 554798.039143</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 020 027</ms:GML_ID>
        <ms:NAZWA>094 020 027</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094020027</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233777.901116 556085.853680</gml:lowerCorner>
        		<gml:upperCorner>233777.901116 556085.853680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233777.901116 556085.853680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 018 654</ms:GML_ID>
        <ms:NAZWA>094 018 654</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094018654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234307.368000 557592.005000</gml:lowerCorner>
        		<gml:upperCorner>234307.368000 557592.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234307.368000 557592.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 016 917</ms:GML_ID>
        <ms:NAZWA>094 016 917</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094016917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245223.752782 557599.029599</gml:lowerCorner>
        		<gml:upperCorner>245223.752782 557599.029599</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245223.752782 557599.029599</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 011 667</ms:GML_ID>
        <ms:NAZWA>118 011 667</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118011667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232730.687000 557610.937000</gml:lowerCorner>
        		<gml:upperCorner>232730.687000 557610.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232730.687000 557610.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 002 558</ms:GML_ID>
        <ms:NAZWA>097 002 558</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097002558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232177.947572 557700.701520</gml:lowerCorner>
        		<gml:upperCorner>232177.947572 557700.701520</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232177.947572 557700.701520</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 003 124</ms:GML_ID>
        <ms:NAZWA>097 003 124</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097003124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233089.585000 557731.163000</gml:lowerCorner>
        		<gml:upperCorner>233089.585000 557731.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233089.585000 557731.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 002 178</ms:GML_ID>
        <ms:NAZWA>097 002 178</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097002178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234345.308000 557984.234000</gml:lowerCorner>
        		<gml:upperCorner>234345.308000 557984.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234345.308000 557984.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 016 522</ms:GML_ID>
        <ms:NAZWA>094 016 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094016522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234355.426000 558242.798000</gml:lowerCorner>
        		<gml:upperCorner>234355.426000 558242.798000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234355.426000 558242.798000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 000 811</ms:GML_ID>
        <ms:NAZWA>097 000 811</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097000811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234652.072000 558544.851000</gml:lowerCorner>
        		<gml:upperCorner>234652.072000 558544.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234652.072000 558544.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 015 852</ms:GML_ID>
        <ms:NAZWA>094 015 852</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094015852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245835.983697 559125.747640</gml:lowerCorner>
        		<gml:upperCorner>245835.983697 559125.747640</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245835.983697 559125.747640</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 010 001</ms:GML_ID>
        <ms:NAZWA>118 010 001</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118010001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245902.392581 559687.189285</gml:lowerCorner>
        		<gml:upperCorner>245902.392581 559687.189285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245902.392581 559687.189285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 009 428</ms:GML_ID>
        <ms:NAZWA>118 009 428</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118009428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217790.174433 544358.464457</gml:lowerCorner>
        		<gml:upperCorner>217790.174433 544358.464457</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217790.174433 544358.464457</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 033 502</ms:GML_ID>
        <ms:NAZWA>097 033 502</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097033502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207518.988000 545174.864000</gml:lowerCorner>
        		<gml:upperCorner>207518.988000 545174.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207518.988000 545174.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 003 790</ms:GML_ID>
        <ms:NAZWA>098 003 790</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098003790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218126.164000 545377.959000</gml:lowerCorner>
        		<gml:upperCorner>218126.164000 545377.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218126.164000 545377.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 032 299</ms:GML_ID>
        <ms:NAZWA>097 032 299</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097032299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217924.897924 545726.390587</gml:lowerCorner>
        		<gml:upperCorner>217924.897924 545726.390587</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217924.897924 545726.390587</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 031 885</ms:GML_ID>
        <ms:NAZWA>097 031 885</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097031885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207397.868549 546124.544582</gml:lowerCorner>
        		<gml:upperCorner>207397.868549 546124.544582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207397.868549 546124.544582</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 004 751</ms:GML_ID>
        <ms:NAZWA>098 004 751</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098004751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217962.870000 546160.673000</gml:lowerCorner>
        		<gml:upperCorner>217962.870000 546160.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217962.870000 546160.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 031 443</ms:GML_ID>
        <ms:NAZWA>097 031 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097031443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217978.711710 546558.294077</gml:lowerCorner>
        		<gml:upperCorner>217978.711710 546558.294077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217978.711710 546558.294077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 031 032</ms:GML_ID>
        <ms:NAZWA>097 031 032</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097031032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217914.825000 546741.931000</gml:lowerCorner>
        		<gml:upperCorner>217914.825000 546741.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217914.825000 546741.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 030 838</ms:GML_ID>
        <ms:NAZWA>097 030 838</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097030838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218147.789004 547072.649998</gml:lowerCorner>
        		<gml:upperCorner>218147.789004 547072.649998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218147.789004 547072.649998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 030 395</ms:GML_ID>
        <ms:NAZWA>097 030 395</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097030395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218259.869000 547444.543000</gml:lowerCorner>
        		<gml:upperCorner>218259.869000 547444.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218259.869000 547444.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 029 982</ms:GML_ID>
        <ms:NAZWA>097 029 982</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097029982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218686.768793 547921.464681</gml:lowerCorner>
        		<gml:upperCorner>218686.768793 547921.464681</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218686.768793 547921.464681</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 029 248</ms:GML_ID>
        <ms:NAZWA>097 029 248</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097029248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206968.093000 548194.189000</gml:lowerCorner>
        		<gml:upperCorner>206968.093000 548194.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206968.093000 548194.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 006 900</ms:GML_ID>
        <ms:NAZWA>098 006 900</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098006900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206777.544000 549035.877000</gml:lowerCorner>
        		<gml:upperCorner>206777.544000 549035.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206777.544000 549035.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 007 765</ms:GML_ID>
        <ms:NAZWA>098 007 765</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098007765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205985.926090 549487.213013</gml:lowerCorner>
        		<gml:upperCorner>205985.926090 549487.213013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205985.926090 549487.213013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 008 867</ms:GML_ID>
        <ms:NAZWA>098 008 867</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098008867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204978.232000 549610.424000</gml:lowerCorner>
        		<gml:upperCorner>204978.232000 549610.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204978.232000 549610.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 009 895</ms:GML_ID>
        <ms:NAZWA>098 009 895</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098009895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204708.797000 549805.022000</gml:lowerCorner>
        		<gml:upperCorner>204708.797000 549805.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204708.797000 549805.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 010 226</ms:GML_ID>
        <ms:NAZWA>098 010 226</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098010226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204271.165000 550138.265000</gml:lowerCorner>
        		<gml:upperCorner>204271.165000 550138.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204271.165000 550138.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 010 778</ms:GML_ID>
        <ms:NAZWA>098 010 778</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098010778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203519.219000 550828.142000</gml:lowerCorner>
        		<gml:upperCorner>203519.219000 550828.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203519.219000 550828.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 011 822</ms:GML_ID>
        <ms:NAZWA>098 011 822</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098011822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203263.993296 551327.501066</gml:lowerCorner>
        		<gml:upperCorner>203263.993296 551327.501066</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203263.993296 551327.501066</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 012 382</ms:GML_ID>
        <ms:NAZWA>098 012 382</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098012382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202719.563981 552165.685089</gml:lowerCorner>
        		<gml:upperCorner>202719.563981 552165.685089</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202719.563981 552165.685089</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 013 430</ms:GML_ID>
        <ms:NAZWA>098 013 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098013430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222141.434852 541895.735402</gml:lowerCorner>
        		<gml:upperCorner>222141.434852 541895.735402</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222141.434852 541895.735402</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 009 939</ms:GML_ID>
        <ms:NAZWA>117 009 939</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117009939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223096.715000 542299.057000</gml:lowerCorner>
        		<gml:upperCorner>223096.715000 542299.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223096.715000 542299.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 008 654</ms:GML_ID>
        <ms:NAZWA>117 008 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117008654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222506.139311 543390.342792</gml:lowerCorner>
        		<gml:upperCorner>222506.139311 543390.342792</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222506.139311 543390.342792</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 007 323</ms:GML_ID>
        <ms:NAZWA>117 007 323</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117007323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222297.951523 543569.610953</gml:lowerCorner>
        		<gml:upperCorner>222297.951523 543569.610953</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222297.951523 543569.610953</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 007 044</ms:GML_ID>
        <ms:NAZWA>117 007 044</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117007044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222059.132579 544117.153578</gml:lowerCorner>
        		<gml:upperCorner>222059.132579 544117.153578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222059.132579 544117.153578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 006 452</ms:GML_ID>
        <ms:NAZWA>117 006 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117006452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217794.148000 544168.152000</gml:lowerCorner>
        		<gml:upperCorner>217794.148000 544168.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217794.148000 544168.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 033 691</ms:GML_ID>
        <ms:NAZWA>097 033 691</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097033691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222129.539000 544635.303000</gml:lowerCorner>
        		<gml:upperCorner>222129.539000 544635.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222129.539000 544635.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 005 904</ms:GML_ID>
        <ms:NAZWA>117 005 904</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117005904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222218.702000 544746.766000</gml:lowerCorner>
        		<gml:upperCorner>222218.702000 544746.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222218.702000 544746.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 005 761</ms:GML_ID>
        <ms:NAZWA>117 005 761</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117005761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222498.698000 545188.187000</gml:lowerCorner>
        		<gml:upperCorner>222498.698000 545188.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222498.698000 545188.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 005 228</ms:GML_ID>
        <ms:NAZWA>117 005 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117005228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222802.904000 545887.431000</gml:lowerCorner>
        		<gml:upperCorner>222802.904000 545887.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222802.904000 545887.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 004 466</ms:GML_ID>
        <ms:NAZWA>117 004 466</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117004466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217979.467888 545979.652805</gml:lowerCorner>
        		<gml:upperCorner>217979.467888 545979.652805</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217979.467888 545979.652805</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 031 625</ms:GML_ID>
        <ms:NAZWA>097 031 625</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097031625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223043.483000 547988.984000</gml:lowerCorner>
        		<gml:upperCorner>223043.483000 547988.984000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223043.483000 547988.984000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 001 967</ms:GML_ID>
        <ms:NAZWA>117 001 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117001967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223046.684526 548248.451189</gml:lowerCorner>
        		<gml:upperCorner>223046.684526 548248.451189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223046.684526 548248.451189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 001 684</ms:GML_ID>
        <ms:NAZWA>117 001 684</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117001684</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220025.171000 548326.082000</gml:lowerCorner>
        		<gml:upperCorner>220025.171000 548326.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220025.171000 548326.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 026 339</ms:GML_ID>
        <ms:NAZWA>097 026 339</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097026339</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220590.597372 548400.839982</gml:lowerCorner>
        		<gml:upperCorner>220590.597372 548400.839982</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220590.597372 548400.839982</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 025 617</ms:GML_ID>
        <ms:NAZWA>097 025 617</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097025617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219033.545000 548754.506000</gml:lowerCorner>
        		<gml:upperCorner>219033.545000 548754.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219033.545000 548754.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 028 255</ms:GML_ID>
        <ms:NAZWA>097 028 255</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097028255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219802.364249 548867.012384</gml:lowerCorner>
        		<gml:upperCorner>219802.364249 548867.012384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219802.364249 548867.012384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 026 954</ms:GML_ID>
        <ms:NAZWA>097 026 954</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097026954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221380.126000 549028.214000</gml:lowerCorner>
        		<gml:upperCorner>221380.126000 549028.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221380.126000 549028.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 024 485</ms:GML_ID>
        <ms:NAZWA>097 024 485</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097024485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219440.211000 549192.190000</gml:lowerCorner>
        		<gml:upperCorner>219440.211000 549192.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219440.211000 549192.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 027 620</ms:GML_ID>
        <ms:NAZWA>097 027 620</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097027620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221403.767000 549274.371000</gml:lowerCorner>
        		<gml:upperCorner>221403.767000 549274.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221403.767000 549274.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 024 236</ms:GML_ID>
        <ms:NAZWA>097 024 236</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097024236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207075.236609 537276.208244</gml:lowerCorner>
        		<gml:upperCorner>207075.236609 537276.208244</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207075.236609 537276.208244</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 051 190</ms:GML_ID>
        <ms:NAZWA>097 051 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097051190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207548.288000 537914.079000</gml:lowerCorner>
        		<gml:upperCorner>207548.288000 537914.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207548.288000 537914.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 050 383</ms:GML_ID>
        <ms:NAZWA>097 050 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097050383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207813.803000 538411.106000</gml:lowerCorner>
        		<gml:upperCorner>207813.803000 538411.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207813.803000 538411.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 049 809</ms:GML_ID>
        <ms:NAZWA>097 049 809</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097049809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207966.539000 538742.770000</gml:lowerCorner>
        		<gml:upperCorner>207966.539000 538742.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207966.539000 538742.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 049 442</ms:GML_ID>
        <ms:NAZWA>097 049 442</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097049442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207818.542675 539571.323399</gml:lowerCorner>
        		<gml:upperCorner>207818.542675 539571.323399</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207818.542675 539571.323399</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 048 588</ms:GML_ID>
        <ms:NAZWA>097 048 588</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097048588</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207777.859000 540295.194000</gml:lowerCorner>
        		<gml:upperCorner>207777.859000 540295.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207777.859000 540295.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 047 861</ms:GML_ID>
        <ms:NAZWA>097 047 861</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097047861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207933.307224 540970.527207</gml:lowerCorner>
        		<gml:upperCorner>207933.307224 540970.527207</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207933.307224 540970.527207</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 047 158</ms:GML_ID>
        <ms:NAZWA>097 047 158</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097047158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208049.436411 541242.313737</gml:lowerCorner>
        		<gml:upperCorner>208049.436411 541242.313737</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208049.436411 541242.313737</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 046 862</ms:GML_ID>
        <ms:NAZWA>097 046 862</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097046862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208475.652000 542235.905000</gml:lowerCorner>
        		<gml:upperCorner>208475.652000 542235.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208475.652000 542235.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 045 780</ms:GML_ID>
        <ms:NAZWA>097 045 780</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097045780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212477.725523 542438.173812</gml:lowerCorner>
        		<gml:upperCorner>212477.725523 542438.173812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212477.725523 542438.173812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 040 457</ms:GML_ID>
        <ms:NAZWA>097 040 457</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097040457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208591.219000 542828.605000</gml:lowerCorner>
        		<gml:upperCorner>208591.219000 542828.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208591.219000 542828.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 045 169</ms:GML_ID>
        <ms:NAZWA>097 045 169</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097045169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216462.255670 543137.798384</gml:lowerCorner>
        		<gml:upperCorner>216462.255670 543137.798384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216462.255670 543137.798384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 035 730</ms:GML_ID>
        <ms:NAZWA>097 035 730</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097035730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208589.279000 543285.385000</gml:lowerCorner>
        		<gml:upperCorner>208589.279000 543285.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208589.279000 543285.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 001 525</ms:GML_ID>
        <ms:NAZWA>098 001 525</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098001525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208662.237176 543307.873844</gml:lowerCorner>
        		<gml:upperCorner>208662.237176 543307.873844</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208662.237176 543307.873844</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 044 675</ms:GML_ID>
        <ms:NAZWA>097 044 675</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097044675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210084.594377 543311.259405</gml:lowerCorner>
        		<gml:upperCorner>210084.594377 543311.259405</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210084.594377 543311.259405</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 043 064</ms:GML_ID>
        <ms:NAZWA>097 043 064</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097043064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217476.766000 543324.515000</gml:lowerCorner>
        		<gml:upperCorner>217476.766000 543324.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217476.766000 543324.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 034 659</ms:GML_ID>
        <ms:NAZWA>097 034 659</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097034659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209225.719050 543501.213779</gml:lowerCorner>
        		<gml:upperCorner>209225.719050 543501.213779</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209225.719050 543501.213779</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 044 063</ms:GML_ID>
        <ms:NAZWA>097 044 063</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097044063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217773.219435 543700.588708</gml:lowerCorner>
        		<gml:upperCorner>217773.219435 543700.588708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217773.219435 543700.588708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 034 169</ms:GML_ID>
        <ms:NAZWA>097 034 169</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097034169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208130.224264 543704.338616</gml:lowerCorner>
        		<gml:upperCorner>208130.224264 543704.338616</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208130.224264 543704.338616</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 002 169</ms:GML_ID>
        <ms:NAZWA>098 002 169</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098002169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207774.634000 544304.519000</gml:lowerCorner>
        		<gml:upperCorner>207774.634000 544304.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207774.634000 544304.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.098 002 875</ms:GML_ID>
        <ms:NAZWA>098 002 875</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>098002875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217774.895148 544948.054809</gml:lowerCorner>
        		<gml:upperCorner>217774.895148 544948.054809</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217774.895148 544948.054809</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 032 908</ms:GML_ID>
        <ms:NAZWA>097 032 908</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097032908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222620.022000 545466.563000</gml:lowerCorner>
        		<gml:upperCorner>222620.022000 545466.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222620.022000 545466.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 004 925</ms:GML_ID>
        <ms:NAZWA>117 004 925</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117004925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222641.274041 539127.749383</gml:lowerCorner>
        		<gml:upperCorner>222641.274041 539127.749383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222641.274041 539127.749383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 013 068</ms:GML_ID>
        <ms:NAZWA>117 013 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117013068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222888.669951 546056.846896</gml:lowerCorner>
        		<gml:upperCorner>222888.669951 546056.846896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222888.669951 546056.846896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 004 275</ms:GML_ID>
        <ms:NAZWA>117 004 275</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117004275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223009.674480 542877.766014</gml:lowerCorner>
        		<gml:upperCorner>223009.674480 542877.766014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223009.674480 542877.766014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 008 056</ms:GML_ID>
        <ms:NAZWA>117 008 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117008056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223028.804363 538876.474013</gml:lowerCorner>
        		<gml:upperCorner>223028.804363 538876.474013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223028.804363 538876.474013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 013 540</ms:GML_ID>
        <ms:NAZWA>117 013 540</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117013540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223107.773000 546233.128000</gml:lowerCorner>
        		<gml:upperCorner>223107.773000 546233.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223107.773000 546233.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 003 991</ms:GML_ID>
        <ms:NAZWA>117 003 991</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117003991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223225.996000 547135.159000</gml:lowerCorner>
        		<gml:upperCorner>223225.996000 547135.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223225.996000 547135.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 002 994</ms:GML_ID>
        <ms:NAZWA>117 002 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117002994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223230.312000 546474.231000</gml:lowerCorner>
        		<gml:upperCorner>223230.312000 546474.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223230.312000 546474.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 003 705</ms:GML_ID>
        <ms:NAZWA>117 003 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117003705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223317.219387 549172.752003</gml:lowerCorner>
        		<gml:upperCorner>223317.219387 549172.752003</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223317.219387 549172.752003</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 021 719</ms:GML_ID>
        <ms:NAZWA>097 021 719</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097021719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223351.147296 547695.199404</gml:lowerCorner>
        		<gml:upperCorner>223351.147296 547695.199404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223351.147296 547695.199404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 002 415</ms:GML_ID>
        <ms:NAZWA>117 002 415</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117002415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223380.882000 537316.151000</gml:lowerCorner>
        		<gml:upperCorner>223380.882000 537316.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223380.882000 537316.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 015 810</ms:GML_ID>
        <ms:NAZWA>117 015 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117015810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223495.408617 548898.607807</gml:lowerCorner>
        		<gml:upperCorner>223495.408617 548898.607807</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223495.408617 548898.607807</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 021 378</ms:GML_ID>
        <ms:NAZWA>097 021 378</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097021378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223608.112000 536516.128000</gml:lowerCorner>
        		<gml:upperCorner>223608.112000 536516.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223608.112000 536516.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 016 649</ms:GML_ID>
        <ms:NAZWA>117 016 649</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117016649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223646.609000 538308.436000</gml:lowerCorner>
        		<gml:upperCorner>223646.609000 538308.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223646.609000 538308.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 014 412</ms:GML_ID>
        <ms:NAZWA>117 014 412</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117014412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223901.635907 548484.002762</gml:lowerCorner>
        		<gml:upperCorner>223901.635907 548484.002762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223901.635907 548484.002762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 020 740</ms:GML_ID>
        <ms:NAZWA>097 020 740</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097020740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224693.376248 535811.935165</gml:lowerCorner>
        		<gml:upperCorner>224693.376248 535811.935165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224693.376248 535811.935165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 017 943</ms:GML_ID>
        <ms:NAZWA>117 017 943</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117017943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224694.784000 534838.143000</gml:lowerCorner>
        		<gml:upperCorner>224694.784000 534838.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224694.784000 534838.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 019 022</ms:GML_ID>
        <ms:NAZWA>117 019 022</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117019022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224919.947009 548363.556744</gml:lowerCorner>
        		<gml:upperCorner>224919.947009 548363.556744</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224919.947009 548363.556744</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 019 705</ms:GML_ID>
        <ms:NAZWA>097 019 705</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097019705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225478.655035 548548.503870</gml:lowerCorner>
        		<gml:upperCorner>225478.655035 548548.503870</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225478.655035 548548.503870</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 019 108</ms:GML_ID>
        <ms:NAZWA>097 019 108</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097019108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225650.617867 535379.757218</gml:lowerCorner>
        		<gml:upperCorner>225650.617867 535379.757218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225650.617867 535379.757218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 036 200</ms:GML_ID>
        <ms:NAZWA>103 036 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103036200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225685.028000 548803.099000</gml:lowerCorner>
        		<gml:upperCorner>225685.028000 548803.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225685.028000 548803.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 018 777</ms:GML_ID>
        <ms:NAZWA>097 018 777</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097018777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226506.110000 535098.930000</gml:lowerCorner>
        		<gml:upperCorner>226506.110000 535098.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226506.110000 535098.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 035 293</ms:GML_ID>
        <ms:NAZWA>103 035 293</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103035293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227290.465000 534872.276000</gml:lowerCorner>
        		<gml:upperCorner>227290.465000 534872.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227290.465000 534872.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 034 477</ms:GML_ID>
        <ms:NAZWA>103 034 477</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103034477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227751.942000 534760.270000</gml:lowerCorner>
        		<gml:upperCorner>227751.942000 534760.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227751.942000 534760.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 033 999</ms:GML_ID>
        <ms:NAZWA>103 033 999</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103033999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228539.423000 534762.561000</gml:lowerCorner>
        		<gml:upperCorner>228539.423000 534762.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228539.423000 534762.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 033 210</ms:GML_ID>
        <ms:NAZWA>103 033 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103033210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232914.960000 549255.866000</gml:lowerCorner>
        		<gml:upperCorner>232914.960000 549255.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232914.960000 549255.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 025 701</ms:GML_ID>
        <ms:NAZWA>094 025 701</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094025701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232929.343000 548719.362000</gml:lowerCorner>
        		<gml:upperCorner>232929.343000 548719.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232929.343000 548719.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 026 239</ms:GML_ID>
        <ms:NAZWA>094 026 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094026239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232940.624000 548305.245000</gml:lowerCorner>
        		<gml:upperCorner>232940.624000 548305.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232940.624000 548305.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 026 653</ms:GML_ID>
        <ms:NAZWA>094 026 653</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094026653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232970.675000 547271.799000</gml:lowerCorner>
        		<gml:upperCorner>232970.675000 547271.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232970.675000 547271.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 027 687</ms:GML_ID>
        <ms:NAZWA>094 027 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094027687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233099.994000 546559.448000</gml:lowerCorner>
        		<gml:upperCorner>233099.994000 546559.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233099.994000 546559.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 028 414</ms:GML_ID>
        <ms:NAZWA>094 028 414</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094028414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233335.570000 545839.576000</gml:lowerCorner>
        		<gml:upperCorner>233335.570000 545839.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233335.570000 545839.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 029 172</ms:GML_ID>
        <ms:NAZWA>094 029 172</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094029172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233398.881010 545647.453337</gml:lowerCorner>
        		<gml:upperCorner>233398.881010 545647.453337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233398.881010 545647.453337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 029 373</ms:GML_ID>
        <ms:NAZWA>094 029 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094029373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233469.430764 545356.521426</gml:lowerCorner>
        		<gml:upperCorner>233469.430764 545356.521426</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233469.430764 545356.521426</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 029 674</ms:GML_ID>
        <ms:NAZWA>094 029 674</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094029674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233656.471000 544423.001000</gml:lowerCorner>
        		<gml:upperCorner>233656.471000 544423.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233656.471000 544423.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 030 627</ms:GML_ID>
        <ms:NAZWA>094 030 627</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094030627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233864.522000 543382.425000</gml:lowerCorner>
        		<gml:upperCorner>233864.522000 543382.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233864.522000 543382.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 031 689</ms:GML_ID>
        <ms:NAZWA>094 031 689</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094031689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234525.424919 541230.464538</gml:lowerCorner>
        		<gml:upperCorner>234525.424919 541230.464538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234525.424919 541230.464538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 033 965</ms:GML_ID>
        <ms:NAZWA>094 033 965</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094033965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235017.917075 540363.130926</gml:lowerCorner>
        		<gml:upperCorner>235017.917075 540363.130926</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235017.917075 540363.130926</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 034 963</ms:GML_ID>
        <ms:NAZWA>094 034 963</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094034963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235164.893228 540104.609183</gml:lowerCorner>
        		<gml:upperCorner>235164.893228 540104.609183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235164.893228 540104.609183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 035 259</ms:GML_ID>
        <ms:NAZWA>094 035 259</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094035259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235380.648000 539724.364000</gml:lowerCorner>
        		<gml:upperCorner>235380.648000 539724.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235380.648000 539724.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 035 697</ms:GML_ID>
        <ms:NAZWA>094 035 697</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094035697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235804.964000 538977.389000</gml:lowerCorner>
        		<gml:upperCorner>235804.964000 538977.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235804.964000 538977.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 036 556</ms:GML_ID>
        <ms:NAZWA>094 036 556</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094036556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236946.874000 535176.229000</gml:lowerCorner>
        		<gml:upperCorner>236946.874000 535176.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236946.874000 535176.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 022 311</ms:GML_ID>
        <ms:NAZWA>103 022 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103022311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237036.273000 537388.872000</gml:lowerCorner>
        		<gml:upperCorner>237036.273000 537388.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237036.273000 537388.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 038 613</ms:GML_ID>
        <ms:NAZWA>094 038 613</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094038613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237190.254000 536653.354000</gml:lowerCorner>
        		<gml:upperCorner>237190.254000 536653.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237190.254000 536653.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 039 467</ms:GML_ID>
        <ms:NAZWA>094 039 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094039467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237497.817000 535425.794000</gml:lowerCorner>
        		<gml:upperCorner>237497.817000 535425.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237497.817000 535425.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 021 699</ms:GML_ID>
        <ms:NAZWA>103 021 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103021699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256527.792000 531384.500000</gml:lowerCorner>
        		<gml:upperCorner>256527.792000 531384.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256527.792000 531384.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 004 128</ms:GML_ID>
        <ms:NAZWA>114 004 128</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114004128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266453.672000 531651.432000</gml:lowerCorner>
        		<gml:upperCorner>266453.672000 531651.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266453.672000 531651.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.156 001 098</ms:GML_ID>
        <ms:NAZWA>156 001 098</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>156001098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266618.612000 531737.736000</gml:lowerCorner>
        		<gml:upperCorner>266618.612000 531737.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266618.612000 531737.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 054 575</ms:GML_ID>
        <ms:NAZWA>062 054 575</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062054575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267907.415000 537883.195000</gml:lowerCorner>
        		<gml:upperCorner>267907.415000 537883.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267907.415000 537883.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 048 100</ms:GML_ID>
        <ms:NAZWA>062 048 100</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062048100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267481.775437 541252.762192</gml:lowerCorner>
        		<gml:upperCorner>267481.775437 541252.762192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267481.775437 541252.762192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 044 645</ms:GML_ID>
        <ms:NAZWA>062 044 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062044645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251637.434983 541350.351670</gml:lowerCorner>
        		<gml:upperCorner>251637.434983 541350.351670</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251637.434983 541350.351670</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 041 213</ms:GML_ID>
        <ms:NAZWA>133 041 213</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>133041213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271370.384780 542968.863842</gml:lowerCorner>
        		<gml:upperCorner>271370.384780 542968.863842</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271370.384780 542968.863842</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 039 695</ms:GML_ID>
        <ms:NAZWA>062 039 695</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062039695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275522.059893 544699.837748</gml:lowerCorner>
        		<gml:upperCorner>275522.059893 544699.837748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275522.059893 544699.837748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 034 936</ms:GML_ID>
        <ms:NAZWA>062 034 936</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062034936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275564.459000 548804.442000</gml:lowerCorner>
        		<gml:upperCorner>275564.459000 548804.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275564.459000 548804.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 030 284</ms:GML_ID>
        <ms:NAZWA>062 030 284</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062030284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277528.375000 549621.505000</gml:lowerCorner>
        		<gml:upperCorner>277528.375000 549621.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277528.375000 549621.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 028 134</ms:GML_ID>
        <ms:NAZWA>062 028 134</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062028134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278302.641000 551396.377000</gml:lowerCorner>
        		<gml:upperCorner>278302.641000 551396.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278302.641000 551396.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 026 190</ms:GML_ID>
        <ms:NAZWA>062 026 190</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062026190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250676.097000 552455.389000</gml:lowerCorner>
        		<gml:upperCorner>250676.097000 552455.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250676.097000 552455.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 052 709</ms:GML_ID>
        <ms:NAZWA>133 052 709</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>133052709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279467.344000 553918.674000</gml:lowerCorner>
        		<gml:upperCorner>279467.344000 553918.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279467.344000 553918.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 023 384</ms:GML_ID>
        <ms:NAZWA>062 023 384</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062023384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279266.214000 554544.227000</gml:lowerCorner>
        		<gml:upperCorner>279266.214000 554544.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279266.214000 554544.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 022 717</ms:GML_ID>
        <ms:NAZWA>062 022 717</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062022717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246265.067880 561125.302818</gml:lowerCorner>
        		<gml:upperCorner>246265.067880 561125.302818</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246265.067880 561125.302818</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.118 007 888</ms:GML_ID>
        <ms:NAZWA>118 007 888</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>118007888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281174.371000 562551.369000</gml:lowerCorner>
        		<gml:upperCorner>281174.371000 562551.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281174.371000 562551.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 012 370</ms:GML_ID>
        <ms:NAZWA>062 012 370</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062012370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281034.848000 563378.431000</gml:lowerCorner>
        		<gml:upperCorner>281034.848000 563378.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281034.848000 563378.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 011 515</ms:GML_ID>
        <ms:NAZWA>062 011 515</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062011515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280846.860000 564815.078000</gml:lowerCorner>
        		<gml:upperCorner>280846.860000 564815.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280846.860000 564815.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 010 073</ms:GML_ID>
        <ms:NAZWA>062 010 073</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062010073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246531.039000 566226.341000</gml:lowerCorner>
        		<gml:upperCorner>246531.039000 566226.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246531.039000 566226.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 004 842</ms:GML_ID>
        <ms:NAZWA>100 004 842</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100004842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479327.915443 651362.125009</gml:lowerCorner>
        		<gml:upperCorner>479327.915443 651362.125009</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479327.915443 651362.125009</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 020 942</ms:GML_ID>
        <ms:NAZWA>007 020 942</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007020942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478557.478994 651873.971402</gml:lowerCorner>
        		<gml:upperCorner>478557.478994 651873.971402</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478557.478994 651873.971402</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 021 879</ms:GML_ID>
        <ms:NAZWA>007 021 879</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007021879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478331.810720 652018.358095</gml:lowerCorner>
        		<gml:upperCorner>478331.810720 652018.358095</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478331.810720 652018.358095</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 022 132</ms:GML_ID>
        <ms:NAZWA>007 022 132</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007022132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478305.201661 652035.715773</gml:lowerCorner>
        		<gml:upperCorner>478305.201661 652035.715773</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478305.201661 652035.715773</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 022 162</ms:GML_ID>
        <ms:NAZWA>007 022 162</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007022162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477180.694140 652776.336980</gml:lowerCorner>
        		<gml:upperCorner>477180.694140 652776.336980</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477180.694140 652776.336980</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 023 511</ms:GML_ID>
        <ms:NAZWA>007 023 511</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007023511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476962.368000 652915.455000</gml:lowerCorner>
        		<gml:upperCorner>476962.368000 652915.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476962.368000 652915.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 023 770</ms:GML_ID>
        <ms:NAZWA>007 023 770</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007023770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475302.304807 654001.682084</gml:lowerCorner>
        		<gml:upperCorner>475302.304807 654001.682084</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475302.304807 654001.682084</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 025 755</ms:GML_ID>
        <ms:NAZWA>007 025 755</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007025755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461463.328000 656580.263000</gml:lowerCorner>
        		<gml:upperCorner>461463.328000 656580.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461463.328000 656580.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 079 806</ms:GML_ID>
        <ms:NAZWA>012 079 806</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012079806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473044.782230 657096.085977</gml:lowerCorner>
        		<gml:upperCorner>473044.782230 657096.085977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473044.782230 657096.085977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 029 941</ms:GML_ID>
        <ms:NAZWA>007 029 941</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007029941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461162.154000 658467.283000</gml:lowerCorner>
        		<gml:upperCorner>461162.154000 658467.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461162.154000 658467.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 081 719</ms:GML_ID>
        <ms:NAZWA>012 081 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012081719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487396.273612 659190.959942</gml:lowerCorner>
        		<gml:upperCorner>487396.273612 659190.959942</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487396.273612 659190.959942</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 024 224</ms:GML_ID>
        <ms:NAZWA>002 024 224</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002024224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459737.155451 665152.353226</gml:lowerCorner>
        		<gml:upperCorner>459737.155451 665152.353226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459737.155451 665152.353226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 088 582</ms:GML_ID>
        <ms:NAZWA>012 088 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012088582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459141.884946 666637.702475</gml:lowerCorner>
        		<gml:upperCorner>459141.884946 666637.702475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459141.884946 666637.702475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 090 181</ms:GML_ID>
        <ms:NAZWA>012 090 181</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012090181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482838.863000 668905.423000</gml:lowerCorner>
        		<gml:upperCorner>482838.863000 668905.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482838.863000 668905.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 034 999</ms:GML_ID>
        <ms:NAZWA>002 034 999</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002034999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458811.296161 669469.984969</gml:lowerCorner>
        		<gml:upperCorner>458811.296161 669469.984969</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458811.296161 669469.984969</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 093 121</ms:GML_ID>
        <ms:NAZWA>012 093 121</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012093121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482714.715000 669668.916000</gml:lowerCorner>
        		<gml:upperCorner>482714.715000 669668.916000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482714.715000 669668.916000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 035 763</ms:GML_ID>
        <ms:NAZWA>002 035 763</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002035763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459470.757384 671806.272590</gml:lowerCorner>
        		<gml:upperCorner>459470.757384 671806.272590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459470.757384 671806.272590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 095 549</ms:GML_ID>
        <ms:NAZWA>012 095 549</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012095549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468522.960000 671901.886000</gml:lowerCorner>
        		<gml:upperCorner>468522.960000 671901.886000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468522.960000 671901.886000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 045 542</ms:GML_ID>
        <ms:NAZWA>013 045 542</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013045542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469504.249000 672026.454000</gml:lowerCorner>
        		<gml:upperCorner>469504.249000 672026.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469504.249000 672026.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 044 552</ms:GML_ID>
        <ms:NAZWA>013 044 552</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013044552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471530.135000 672601.606000</gml:lowerCorner>
        		<gml:upperCorner>471530.135000 672601.606000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471530.135000 672601.606000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 042 442</ms:GML_ID>
        <ms:NAZWA>013 042 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013042442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474256.606000 673284.063000</gml:lowerCorner>
        		<gml:upperCorner>474256.606000 673284.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474256.606000 673284.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 039 640</ms:GML_ID>
        <ms:NAZWA>013 039 640</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013039640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479083.087000 673424.432000</gml:lowerCorner>
        		<gml:upperCorner>479083.087000 673424.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479083.087000 673424.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 034 743</ms:GML_ID>
        <ms:NAZWA>013 034 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013034743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458543.086026 673496.700927</gml:lowerCorner>
        		<gml:upperCorner>458543.086026 673496.700927</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458543.086026 673496.700927</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 052 938</ms:GML_ID>
        <ms:NAZWA>007 052 938</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007052938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459256.154661 673530.234169</gml:lowerCorner>
        		<gml:upperCorner>459256.154661 673530.234169</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459256.154661 673530.234169</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 097 548</ms:GML_ID>
        <ms:NAZWA>012 097 548</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012097548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476323.842000 673560.412000</gml:lowerCorner>
        		<gml:upperCorner>476323.842000 673560.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476323.842000 673560.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 037 533</ms:GML_ID>
        <ms:NAZWA>013 037 533</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013037533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478175.351000 673590.288000</gml:lowerCorner>
        		<gml:upperCorner>478175.351000 673590.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478175.351000 673590.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 035 667</ms:GML_ID>
        <ms:NAZWA>013 035 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013035667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477198.778000 673676.227000</gml:lowerCorner>
        		<gml:upperCorner>477198.778000 673676.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477198.778000 673676.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 036 649</ms:GML_ID>
        <ms:NAZWA>013 036 649</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013036649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457781.115878 673868.075187</gml:lowerCorner>
        		<gml:upperCorner>457781.115878 673868.075187</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457781.115878 673868.075187</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 053 789</ms:GML_ID>
        <ms:NAZWA>007 053 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007053789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481640.038000 675616.087000</gml:lowerCorner>
        		<gml:upperCorner>481640.038000 675616.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481640.038000 675616.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 041 825</ms:GML_ID>
        <ms:NAZWA>002 041 825</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002041825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481115.174977 676765.626987</gml:lowerCorner>
        		<gml:upperCorner>481115.174977 676765.626987</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481115.174977 676765.626987</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 043 087</ms:GML_ID>
        <ms:NAZWA>002 043 087</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002043087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479996.492000 679597.823000</gml:lowerCorner>
        		<gml:upperCorner>479996.492000 679597.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479996.492000 679597.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 046 143</ms:GML_ID>
        <ms:NAZWA>002 046 143</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002046143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479389.318000 682387.727000</gml:lowerCorner>
        		<gml:upperCorner>479389.318000 682387.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479389.318000 682387.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 049 002</ms:GML_ID>
        <ms:NAZWA>002 049 002</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002049002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457650.318505 682890.707804</gml:lowerCorner>
        		<gml:upperCorner>457650.318505 682890.707804</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457650.318505 682890.707804</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 109 318</ms:GML_ID>
        <ms:NAZWA>012 109 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012109318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479315.524000 683785.852000</gml:lowerCorner>
        		<gml:upperCorner>479315.524000 683785.852000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479315.524000 683785.852000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 050 404</ms:GML_ID>
        <ms:NAZWA>002 050 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002050404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491938.710000 641541.254000</gml:lowerCorner>
        		<gml:upperCorner>491938.710000 641541.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491938.710000 641541.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 003 504</ms:GML_ID>
        <ms:NAZWA>021 003 504</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021003504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492358.301000 648031.427000</gml:lowerCorner>
        		<gml:upperCorner>492358.301000 648031.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492358.301000 648031.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.449 017 180</ms:GML_ID>
        <ms:NAZWA>449 017 180</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>449017180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493192.002659 643117.756412</gml:lowerCorner>
        		<gml:upperCorner>493192.002659 643117.756412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493192.002659 643117.756412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 005 525</ms:GML_ID>
        <ms:NAZWA>021 005 525</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021005525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493855.165842 643994.804162</gml:lowerCorner>
        		<gml:upperCorner>493855.165842 643994.804162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493855.165842 643994.804162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 006 610</ms:GML_ID>
        <ms:NAZWA>021 006 610</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021006610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493902.954020 646860.834032</gml:lowerCorner>
        		<gml:upperCorner>493902.954020 646860.834032</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493902.954020 646860.834032</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.449 019 130</ms:GML_ID>
        <ms:NAZWA>449 019 130</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>449019130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494795.287000 645237.125000</gml:lowerCorner>
        		<gml:upperCorner>494795.287000 645237.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494795.287000 645237.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 008 171</ms:GML_ID>
        <ms:NAZWA>021 008 171</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021008171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495115.131000 645660.250000</gml:lowerCorner>
        		<gml:upperCorner>495115.131000 645660.250000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495115.131000 645660.250000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 008 716</ms:GML_ID>
        <ms:NAZWA>021 008 716</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021008716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502323.402075 655225.882185</gml:lowerCorner>
        		<gml:upperCorner>502323.402075 655225.882185</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502323.402075 655225.882185</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 025 008</ms:GML_ID>
        <ms:NAZWA>006 025 008</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006025008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503948.768000 657391.455000</gml:lowerCorner>
        		<gml:upperCorner>503948.768000 657391.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503948.768000 657391.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 027 716</ms:GML_ID>
        <ms:NAZWA>006 027 716</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006027716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508474.728000 641608.241000</gml:lowerCorner>
        		<gml:upperCorner>508474.728000 641608.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508474.728000 641608.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 012 083</ms:GML_ID>
        <ms:NAZWA>010 012 083</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010012083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508508.823000 642627.368000</gml:lowerCorner>
        		<gml:upperCorner>508508.823000 642627.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508508.823000 642627.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 013 103</ms:GML_ID>
        <ms:NAZWA>010 013 103</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010013103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508572.651000 644544.499000</gml:lowerCorner>
        		<gml:upperCorner>508572.651000 644544.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508572.651000 644544.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 015 018</ms:GML_ID>
        <ms:NAZWA>010 015 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010015018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508664.321000 647275.127000</gml:lowerCorner>
        		<gml:upperCorner>508664.321000 647275.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508664.321000 647275.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 017 753</ms:GML_ID>
        <ms:NAZWA>010 017 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010017753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508686.226000 647698.102000</gml:lowerCorner>
        		<gml:upperCorner>508686.226000 647698.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508686.226000 647698.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 018 177</ms:GML_ID>
        <ms:NAZWA>010 018 177</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010018177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508796.009000 648990.993000</gml:lowerCorner>
        		<gml:upperCorner>508796.009000 648990.993000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508796.009000 648990.993000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 019 474</ms:GML_ID>
        <ms:NAZWA>010 019 474</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010019474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509030.676000 649731.737000</gml:lowerCorner>
        		<gml:upperCorner>509030.676000 649731.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509030.676000 649731.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 020 261</ms:GML_ID>
        <ms:NAZWA>010 020 261</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010020261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509311.723000 656933.686000</gml:lowerCorner>
        		<gml:upperCorner>509311.723000 656933.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509311.723000 656933.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 027 669</ms:GML_ID>
        <ms:NAZWA>010 027 669</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010027669</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509374.191697 650491.930504</gml:lowerCorner>
        		<gml:upperCorner>509374.191697 650491.930504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509374.191697 650491.930504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 021 095</ms:GML_ID>
        <ms:NAZWA>010 021 095</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010021095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509614.758000 655064.706000</gml:lowerCorner>
        		<gml:upperCorner>509614.758000 655064.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509614.758000 655064.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 025 760</ms:GML_ID>
        <ms:NAZWA>010 025 760</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010025760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509783.656000 652235.544000</gml:lowerCorner>
        		<gml:upperCorner>509783.656000 652235.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509783.656000 652235.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 022 918</ms:GML_ID>
        <ms:NAZWA>010 022 918</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010022918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460949.594407 641384.442091</gml:lowerCorner>
        		<gml:upperCorner>460949.594407 641384.442091</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460949.594407 641384.442091</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 032 161</ms:GML_ID>
        <ms:NAZWA>008 032 161</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008032161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486288.792045 646836.931422</gml:lowerCorner>
        		<gml:upperCorner>486288.792045 646836.931422</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486288.792045 646836.931422</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 012 635</ms:GML_ID>
        <ms:NAZWA>007 012 635</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007012635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485290.250031 647452.080228</gml:lowerCorner>
        		<gml:upperCorner>485290.250031 647452.080228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485290.250031 647452.080228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 013 809</ms:GML_ID>
        <ms:NAZWA>007 013 809</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007013809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485094.013034 647580.304133</gml:lowerCorner>
        		<gml:upperCorner>485094.013034 647580.304133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485094.013034 647580.304133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 014 046</ms:GML_ID>
        <ms:NAZWA>007 014 046</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007014046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484087.005337 648239.726538</gml:lowerCorner>
        		<gml:upperCorner>484087.005337 648239.726538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484087.005337 648239.726538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 015 235</ms:GML_ID>
        <ms:NAZWA>007 015 235</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007015235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484062.168928 648268.671019</gml:lowerCorner>
        		<gml:upperCorner>484062.168928 648268.671019</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484062.168928 648268.671019</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 015 274</ms:GML_ID>
        <ms:NAZWA>007 015 274</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007015274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482875.022000 649042.325000</gml:lowerCorner>
        		<gml:upperCorner>482875.022000 649042.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482875.022000 649042.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 016 699</ms:GML_ID>
        <ms:NAZWA>007 016 699</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007016699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482631.749643 649201.991965</gml:lowerCorner>
        		<gml:upperCorner>482631.749643 649201.991965</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482631.749643 649201.991965</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 016 984</ms:GML_ID>
        <ms:NAZWA>007 016 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007016984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482321.010592 649398.513659</gml:lowerCorner>
        		<gml:upperCorner>482321.010592 649398.513659</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482321.010592 649398.513659</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 017 354</ms:GML_ID>
        <ms:NAZWA>007 017 354</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007017354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460110.288471 649629.573408</gml:lowerCorner>
        		<gml:upperCorner>460110.288471 649629.573408</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460110.288471 649629.573408</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 072 509</ms:GML_ID>
        <ms:NAZWA>012 072 509</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012072509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481862.739978 649706.478754</gml:lowerCorner>
        		<gml:upperCorner>481862.739978 649706.478754</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481862.739978 649706.478754</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 017 910</ms:GML_ID>
        <ms:NAZWA>007 017 910</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007017910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481671.071541 649831.970899</gml:lowerCorner>
        		<gml:upperCorner>481671.071541 649831.970899</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481671.071541 649831.970899</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 018 144</ms:GML_ID>
        <ms:NAZWA>007 018 144</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007018144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480626.132838 650512.187179</gml:lowerCorner>
        		<gml:upperCorner>480626.132838 650512.187179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480626.132838 650512.187179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 019 386</ms:GML_ID>
        <ms:NAZWA>007 019 386</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007019386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479815.018809 651044.275555</gml:lowerCorner>
        		<gml:upperCorner>479815.018809 651044.275555</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479815.018809 651044.275555</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 020 368</ms:GML_ID>
        <ms:NAZWA>007 020 368</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007020368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489406.770707 640380.036068</gml:lowerCorner>
        		<gml:upperCorner>489406.770707 640380.036068</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489406.770707 640380.036068</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 004 625</ms:GML_ID>
        <ms:NAZWA>002 004 625</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002004625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490009.370000 640898.235000</gml:lowerCorner>
        		<gml:upperCorner>490009.370000 640898.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490009.370000 640898.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 005 426</ms:GML_ID>
        <ms:NAZWA>009 005 426</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009005426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490780.934440 640966.918971</gml:lowerCorner>
        		<gml:upperCorner>490780.934440 640966.918971</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490780.934440 640966.918971</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.503 005 173</ms:GML_ID>
        <ms:NAZWA>503 005 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>503005173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490306.723985 641284.001703</gml:lowerCorner>
        		<gml:upperCorner>490306.723985 641284.001703</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490306.723985 641284.001703</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.503 005 766</ms:GML_ID>
        <ms:NAZWA>503 005 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>503005766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489800.846815 642103.467338</gml:lowerCorner>
        		<gml:upperCorner>489800.846815 642103.467338</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489800.846815 642103.467338</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 006 485</ms:GML_ID>
        <ms:NAZWA>007 006 485</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007006485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489716.478677 642325.570778</gml:lowerCorner>
        		<gml:upperCorner>489716.478677 642325.570778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489716.478677 642325.570778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 006 722</ms:GML_ID>
        <ms:NAZWA>007 006 722</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007006722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489221.839347 643638.744106</gml:lowerCorner>
        		<gml:upperCorner>489221.839347 643638.744106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489221.839347 643638.744106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 008 205</ms:GML_ID>
        <ms:NAZWA>007 008 205</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007008205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489137.091820 643852.196107</gml:lowerCorner>
        		<gml:upperCorner>489137.091820 643852.196107</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489137.091820 643852.196107</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 008 435</ms:GML_ID>
        <ms:NAZWA>007 008 435</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007008435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489130.329000 643868.831000</gml:lowerCorner>
        		<gml:upperCorner>489130.329000 643868.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489130.329000 643868.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 008 452</ms:GML_ID>
        <ms:NAZWA>007 008 452</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007008452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489895.522947 644264.340426</gml:lowerCorner>
        		<gml:upperCorner>489895.522947 644264.340426</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489895.522947 644264.340426</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.506 008 067</ms:GML_ID>
        <ms:NAZWA>506 008 067</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>506008067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488773.256285 644469.814628</gml:lowerCorner>
        		<gml:upperCorner>488773.256285 644469.814628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488773.256285 644469.814628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 009 155</ms:GML_ID>
        <ms:NAZWA>007 009 155</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007009155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488853.419829 644636.382687</gml:lowerCorner>
        		<gml:upperCorner>488853.419829 644636.382687</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488853.419829 644636.382687</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.506 009 214</ms:GML_ID>
        <ms:NAZWA>506 009 214</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>506009214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490086.497000 647141.633000</gml:lowerCorner>
        		<gml:upperCorner>490086.497000 647141.633000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490086.497000 647141.633000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 011 621</ms:GML_ID>
        <ms:NAZWA>002 011 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002011621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490078.653000 648707.204000</gml:lowerCorner>
        		<gml:upperCorner>490078.653000 648707.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490078.653000 648707.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.449 013 189</ms:GML_ID>
        <ms:NAZWA>449 013 189</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>449013189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491578.924000 648730.979000</gml:lowerCorner>
        		<gml:upperCorner>491578.924000 648730.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491578.924000 648730.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.449 016 127</ms:GML_ID>
        <ms:NAZWA>449 016 127</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>449016127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489899.928294 651526.141289</gml:lowerCorner>
        		<gml:upperCorner>489899.928294 651526.141289</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489899.928294 651526.141289</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 016 009</ms:GML_ID>
        <ms:NAZWA>002 016 009</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002016009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489877.641217 652019.122984</gml:lowerCorner>
        		<gml:upperCorner>489877.641217 652019.122984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489877.641217 652019.122984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 016 503</ms:GML_ID>
        <ms:NAZWA>002 016 503</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002016503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489824.726988 653161.291369</gml:lowerCorner>
        		<gml:upperCorner>489824.726988 653161.291369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489824.726988 653161.291369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 017 651</ms:GML_ID>
        <ms:NAZWA>002 017 651</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002017651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489805.083000 653594.552000</gml:lowerCorner>
        		<gml:upperCorner>489805.083000 653594.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489805.083000 653594.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 018 080</ms:GML_ID>
        <ms:NAZWA>002 018 080</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002018080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483887.001787 623637.575163</gml:lowerCorner>
        		<gml:upperCorner>483887.001787 623637.575163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483887.001787 623637.575163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 014 428</ms:GML_ID>
        <ms:NAZWA>003 014 428</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003014428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483139.759449 626509.311785</gml:lowerCorner>
        		<gml:upperCorner>483139.759449 626509.311785</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483139.759449 626509.311785</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.019 003 777</ms:GML_ID>
        <ms:NAZWA>019 003 777</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>019003777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483606.270489 626558.879263</gml:lowerCorner>
        		<gml:upperCorner>483606.270489 626558.879263</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483606.270489 626558.879263</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.019 003 300</ms:GML_ID>
        <ms:NAZWA>019 003 300</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>019003300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482277.126000 626831.877000</gml:lowerCorner>
        		<gml:upperCorner>482277.126000 626831.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482277.126000 626831.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.019 004 702</ms:GML_ID>
        <ms:NAZWA>019 004 702</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>019004702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482272.533000 626833.980000</gml:lowerCorner>
        		<gml:upperCorner>482272.533000 626833.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482272.533000 626833.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.019 004 706</ms:GML_ID>
        <ms:NAZWA>019 004 706</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>019004706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483402.471000 629933.253000</gml:lowerCorner>
        		<gml:upperCorner>483402.471000 629933.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483402.471000 629933.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.447 008 048</ms:GML_ID>
        <ms:NAZWA>447 008 048</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>447008048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483689.967000 630325.234000</gml:lowerCorner>
        		<gml:upperCorner>483689.967000 630325.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483689.967000 630325.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 007 545</ms:GML_ID>
        <ms:NAZWA>001 007 545</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001007545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484908.030590 631163.112386</gml:lowerCorner>
        		<gml:upperCorner>484908.030590 631163.112386</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484908.030590 631163.112386</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.020 001 662</ms:GML_ID>
        <ms:NAZWA>020 001 662</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>020001662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484579.695000 631215.365000</gml:lowerCorner>
        		<gml:upperCorner>484579.695000 631215.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484579.695000 631215.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.510 001 826</ms:GML_ID>
        <ms:NAZWA>510 001 826</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>510001826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486852.499280 631261.557237</gml:lowerCorner>
        		<gml:upperCorner>486852.499280 631261.557237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486852.499280 631261.557237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.509 003 466</ms:GML_ID>
        <ms:NAZWA>509 003 466</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>509003466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485116.525828 631994.764340</gml:lowerCorner>
        		<gml:upperCorner>485116.525828 631994.764340</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485116.525828 631994.764340</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.020 002 588</ms:GML_ID>
        <ms:NAZWA>020 002 588</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>020002588</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484478.556000 632134.775000</gml:lowerCorner>
        		<gml:upperCorner>484478.556000 632134.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484478.556000 632134.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.510 002 867</ms:GML_ID>
        <ms:NAZWA>510 002 867</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>510002867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485494.071000 632953.402500</gml:lowerCorner>
        		<gml:upperCorner>485494.071000 632953.402500</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485494.071000 632953.402500</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.020 003 431</ms:GML_ID>
        <ms:NAZWA>020 003 431</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>020003431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484975.220000 633032.392000</gml:lowerCorner>
        		<gml:upperCorner>484975.220000 633032.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484975.220000 633032.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.447 004 508</ms:GML_ID>
        <ms:NAZWA>447 004 508</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>447004508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485942.970332 633915.057802</gml:lowerCorner>
        		<gml:upperCorner>485942.970332 633915.057802</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485942.970332 633915.057802</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.020 004 754</ms:GML_ID>
        <ms:NAZWA>020 004 754</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>020004754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485886.590102 634469.601339</gml:lowerCorner>
        		<gml:upperCorner>485886.590102 634469.601339</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485886.590102 634469.601339</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.918 002 750</ms:GML_ID>
        <ms:NAZWA>918 002 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>918002750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475357.433631 636261.018271</gml:lowerCorner>
        		<gml:upperCorner>475357.433631 636261.018271</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475357.433631 636261.018271</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 016 631</ms:GML_ID>
        <ms:NAZWA>008 016 631</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008016631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489276.064855 634010.503386</gml:lowerCorner>
        		<gml:upperCorner>489276.064855 634010.503386</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489276.064855 634010.503386</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.020 008 262</ms:GML_ID>
        <ms:NAZWA>020 008 262</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>020008262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489792.965152 639237.835998</gml:lowerCorner>
        		<gml:upperCorner>489792.965152 639237.835998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489792.965152 639237.835998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 000 322</ms:GML_ID>
        <ms:NAZWA>021 000 322</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021000322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490243.835000 639790.495000</gml:lowerCorner>
        		<gml:upperCorner>490243.835000 639790.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490243.835000 639790.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 001 031</ms:GML_ID>
        <ms:NAZWA>021 001 031</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021001031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490647.675000 640283.583000</gml:lowerCorner>
        		<gml:upperCorner>490647.675000 640283.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490647.675000 640283.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.021 001 656</ms:GML_ID>
        <ms:NAZWA>021 001 656</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>021001656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492033.629027 637875.556906</gml:lowerCorner>
        		<gml:upperCorner>492033.629027 637875.556906</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492033.629027 637875.556906</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.834 010 111</ms:GML_ID>
        <ms:NAZWA>834 010 111</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>834010111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506340.767990 631416.612231</gml:lowerCorner>
        		<gml:upperCorner>506340.767990 631416.612231</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506340.767990 631416.612231</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 025 993</ms:GML_ID>
        <ms:NAZWA>009 025 993</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009025993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506478.994000 631441.713000</gml:lowerCorner>
        		<gml:upperCorner>506478.994000 631441.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506478.994000 631441.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.511 000 415</ms:GML_ID>
        <ms:NAZWA>511 000 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>511000415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506613.074000 631821.314000</gml:lowerCorner>
        		<gml:upperCorner>506613.074000 631821.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506613.074000 631821.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 000 922</ms:GML_ID>
        <ms:NAZWA>010 000 922</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010000922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506648.185000 631794.295000</gml:lowerCorner>
        		<gml:upperCorner>506648.185000 631794.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506648.185000 631794.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.511 000 807</ms:GML_ID>
        <ms:NAZWA>511 000 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>511000807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506833.766972 631989.580223</gml:lowerCorner>
        		<gml:upperCorner>506833.766972 631989.580223</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506833.766972 631989.580223</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 001 268</ms:GML_ID>
        <ms:NAZWA>010 001 268</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010001268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506873.239836 632023.196626</gml:lowerCorner>
        		<gml:upperCorner>506873.239836 632023.196626</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506873.239836 632023.196626</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 001 322</ms:GML_ID>
        <ms:NAZWA>010 001 322</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010001322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507043.680000 632168.229000</gml:lowerCorner>
        		<gml:upperCorner>507043.680000 632168.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507043.680000 632168.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 001 545</ms:GML_ID>
        <ms:NAZWA>010 001 545</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010001545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508023.020000 633327.135000</gml:lowerCorner>
        		<gml:upperCorner>508023.020000 633327.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508023.020000 633327.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 003 063</ms:GML_ID>
        <ms:NAZWA>010 003 063</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010003063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508829.040890 634306.730208</gml:lowerCorner>
        		<gml:upperCorner>508829.040890 634306.730208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508829.040890 634306.730208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.028 000 257</ms:GML_ID>
        <ms:NAZWA>028 000 257</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>028000257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508944.641000 634465.550000</gml:lowerCorner>
        		<gml:upperCorner>508944.641000 634465.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508944.641000 634465.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 004 532</ms:GML_ID>
        <ms:NAZWA>010 004 532</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010004532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510624.446877 635786.044805</gml:lowerCorner>
        		<gml:upperCorner>510624.446877 635786.044805</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510624.446877 635786.044805</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.028 002 133</ms:GML_ID>
        <ms:NAZWA>028 002 133</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>028002133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512981.930963 617786.647229</gml:lowerCorner>
        		<gml:upperCorner>512981.930963 617786.647229</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512981.930963 617786.647229</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 047 786</ms:GML_ID>
        <ms:NAZWA>009 047 786</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009047786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513484.049471 618479.052201</gml:lowerCorner>
        		<gml:upperCorner>513484.049471 618479.052201</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513484.049471 618479.052201</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 048 646</ms:GML_ID>
        <ms:NAZWA>009 048 646</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009048646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514638.763809 618472.215208</gml:lowerCorner>
        		<gml:upperCorner>514638.763809 618472.215208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514638.763809 618472.215208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 049 840</ms:GML_ID>
        <ms:NAZWA>009 049 840</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009049840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523493.182495 619487.675920</gml:lowerCorner>
        		<gml:upperCorner>523493.182495 619487.675920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523493.182495 619487.675920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 058 938</ms:GML_ID>
        <ms:NAZWA>009 058 938</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009058938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525286.935000 617698.943000</gml:lowerCorner>
        		<gml:upperCorner>525286.935000 617698.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525286.935000 617698.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 003 243</ms:GML_ID>
        <ms:NAZWA>027 003 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027003243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525747.196438 618968.139039</gml:lowerCorner>
        		<gml:upperCorner>525747.196438 618968.139039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525747.196438 618968.139039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 001 890</ms:GML_ID>
        <ms:NAZWA>027 001 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027001890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526884.371290 619739.164722</gml:lowerCorner>
        		<gml:upperCorner>526884.371290 619739.164722</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526884.371290 619739.164722</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 062 517</ms:GML_ID>
        <ms:NAZWA>009 062 517</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009062517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535314.525691 619163.705654</gml:lowerCorner>
        		<gml:upperCorner>535314.525691 619163.705654</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535314.525691 619163.705654</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 071 459</ms:GML_ID>
        <ms:NAZWA>009 071 459</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009071459</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456412.709000 613702.290000</gml:lowerCorner>
        		<gml:upperCorner>456412.709000 613702.290000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456412.709000 613702.290000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 035 599</ms:GML_ID>
        <ms:NAZWA>012 035 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012035599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456583.498000 615951.288000</gml:lowerCorner>
        		<gml:upperCorner>456583.498000 615951.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456583.498000 615951.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 037 820</ms:GML_ID>
        <ms:NAZWA>012 037 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012037820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456601.902000 616761.911000</gml:lowerCorner>
        		<gml:upperCorner>456601.902000 616761.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456601.902000 616761.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 038 641</ms:GML_ID>
        <ms:NAZWA>012 038 641</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012038641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456638.043167 617760.545432</gml:lowerCorner>
        		<gml:upperCorner>456638.043167 617760.545432</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456638.043167 617760.545432</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 039 642</ms:GML_ID>
        <ms:NAZWA>012 039 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012039642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456922.874000 618622.059000</gml:lowerCorner>
        		<gml:upperCorner>456922.874000 618622.059000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456922.874000 618622.059000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 040 541</ms:GML_ID>
        <ms:NAZWA>012 040 541</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012040541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457290.310000 619670.796000</gml:lowerCorner>
        		<gml:upperCorner>457290.310000 619670.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457290.310000 619670.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 041 652</ms:GML_ID>
        <ms:NAZWA>012 041 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012041652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457445.120000 620112.634000</gml:lowerCorner>
        		<gml:upperCorner>457445.120000 620112.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457445.120000 620112.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 042 121</ms:GML_ID>
        <ms:NAZWA>012 042 121</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012042121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457587.149505 621985.566965</gml:lowerCorner>
        		<gml:upperCorner>457587.149505 621985.566965</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457587.149505 621985.566965</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 044 080</ms:GML_ID>
        <ms:NAZWA>012 044 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012044080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457699.073798 627313.832288</gml:lowerCorner>
        		<gml:upperCorner>457699.073798 627313.832288</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457699.073798 627313.832288</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 049 699</ms:GML_ID>
        <ms:NAZWA>012 049 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012049699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457392.972000 629243.052000</gml:lowerCorner>
        		<gml:upperCorner>457392.972000 629243.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457392.972000 629243.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 051 622</ms:GML_ID>
        <ms:NAZWA>012 051 622</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012051622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457230.432000 630265.580000</gml:lowerCorner>
        		<gml:upperCorner>457230.432000 630265.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457230.432000 630265.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 052 650</ms:GML_ID>
        <ms:NAZWA>012 052 650</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012052650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456959.577000 631971.190000</gml:lowerCorner>
        		<gml:upperCorner>456959.577000 631971.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456959.577000 631971.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 054 389</ms:GML_ID>
        <ms:NAZWA>012 054 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012054389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457120.057000 635911.645000</gml:lowerCorner>
        		<gml:upperCorner>457120.057000 635911.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457120.057000 635911.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 058 342</ms:GML_ID>
        <ms:NAZWA>012 058 342</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012058342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471219.929625 636671.321536</gml:lowerCorner>
        		<gml:upperCorner>471219.929625 636671.321536</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471219.929625 636671.321536</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 020 789</ms:GML_ID>
        <ms:NAZWA>008 020 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008020789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470398.696847 637059.490998</gml:lowerCorner>
        		<gml:upperCorner>470398.696847 637059.490998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470398.696847 637059.490998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 021 701</ms:GML_ID>
        <ms:NAZWA>008 021 701</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008021701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469421.147081 637681.441058</gml:lowerCorner>
        		<gml:upperCorner>469421.147081 637681.441058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469421.147081 637681.441058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 022 862</ms:GML_ID>
        <ms:NAZWA>008 022 862</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008022862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466593.083035 639164.520670</gml:lowerCorner>
        		<gml:upperCorner>466593.083035 639164.520670</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466593.083035 639164.520670</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 026 087</ms:GML_ID>
        <ms:NAZWA>008 026 087</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008026087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464347.344068 639985.285999</gml:lowerCorner>
        		<gml:upperCorner>464347.344068 639985.285999</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464347.344068 639985.285999</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 028 486</ms:GML_ID>
        <ms:NAZWA>008 028 486</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008028486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461468.290000 641171.020000</gml:lowerCorner>
        		<gml:upperCorner>461468.290000 641171.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461468.290000 641171.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 031 601</ms:GML_ID>
        <ms:NAZWA>008 031 601</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008031601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481759.532148 602861.478311</gml:lowerCorner>
        		<gml:upperCorner>481759.532148 602861.478311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481759.532148 602861.478311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 035 797</ms:GML_ID>
        <ms:NAZWA>003 035 797</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003035797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481124.727359 606943.280135</gml:lowerCorner>
        		<gml:upperCorner>481124.727359 606943.280135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481124.727359 606943.280135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 031 664</ms:GML_ID>
        <ms:NAZWA>003 031 664</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003031664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481328.307792 611044.901915</gml:lowerCorner>
        		<gml:upperCorner>481328.307792 611044.901915</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481328.307792 611044.901915</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 027 556</ms:GML_ID>
        <ms:NAZWA>003 027 556</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003027556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481656.211671 612188.085213</gml:lowerCorner>
        		<gml:upperCorner>481656.211671 612188.085213</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481656.211671 612188.085213</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 026 340</ms:GML_ID>
        <ms:NAZWA>003 026 340</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003026340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482843.715376 615947.101966</gml:lowerCorner>
        		<gml:upperCorner>482843.715376 615947.101966</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482843.715376 615947.101966</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 022 266</ms:GML_ID>
        <ms:NAZWA>003 022 266</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003022266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483709.374000 619213.551000</gml:lowerCorner>
        		<gml:upperCorner>483709.374000 619213.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483709.374000 619213.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 018 880</ms:GML_ID>
        <ms:NAZWA>003 018 880</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003018880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483873.533000 619911.097000</gml:lowerCorner>
        		<gml:upperCorner>483873.533000 619911.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483873.533000 619911.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 018 169</ms:GML_ID>
        <ms:NAZWA>003 018 169</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003018169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478258.429229 620704.499956</gml:lowerCorner>
        		<gml:upperCorner>478258.429229 620704.499956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478258.429229 620704.499956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 018 478</ms:GML_ID>
        <ms:NAZWA>001 018 478</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001018478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483933.033000 620856.730000</gml:lowerCorner>
        		<gml:upperCorner>483933.033000 620856.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483933.033000 620856.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 017 211</ms:GML_ID>
        <ms:NAZWA>003 017 211</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003017211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483901.177593 622440.450577</gml:lowerCorner>
        		<gml:upperCorner>483901.177593 622440.450577</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483901.177593 622440.450577</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 015 625</ms:GML_ID>
        <ms:NAZWA>003 015 625</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003015625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528519.595486 592699.466165</gml:lowerCorner>
        		<gml:upperCorner>528519.595486 592699.466165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528519.595486 592699.466165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 029 314</ms:GML_ID>
        <ms:NAZWA>027 029 314</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027029314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528059.669000 593381.913000</gml:lowerCorner>
        		<gml:upperCorner>528059.669000 593381.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528059.669000 593381.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 028 492</ms:GML_ID>
        <ms:NAZWA>027 028 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027028492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527679.426000 594907.270000</gml:lowerCorner>
        		<gml:upperCorner>527679.426000 594907.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527679.426000 594907.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 026 820</ms:GML_ID>
        <ms:NAZWA>027 026 820</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027026820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527499.286467 596634.761040</gml:lowerCorner>
        		<gml:upperCorner>527499.286467 596634.761040</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527499.286467 596634.761040</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 025 024</ms:GML_ID>
        <ms:NAZWA>027 025 024</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027025024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527139.061710 597044.663793</gml:lowerCorner>
        		<gml:upperCorner>527139.061710 597044.663793</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527139.061710 597044.663793</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 024 473</ms:GML_ID>
        <ms:NAZWA>027 024 473</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027024473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526583.757818 598175.173301</gml:lowerCorner>
        		<gml:upperCorner>526583.757818 598175.173301</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526583.757818 598175.173301</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 023 159</ms:GML_ID>
        <ms:NAZWA>027 023 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027023159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526247.033000 600055.238000</gml:lowerCorner>
        		<gml:upperCorner>526247.033000 600055.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526247.033000 600055.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 021 249</ms:GML_ID>
        <ms:NAZWA>027 021 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027021249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526153.555000 600829.779000</gml:lowerCorner>
        		<gml:upperCorner>526153.555000 600829.779000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526153.555000 600829.779000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 020 465</ms:GML_ID>
        <ms:NAZWA>027 020 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027020465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525957.669000 603157.776000</gml:lowerCorner>
        		<gml:upperCorner>525957.669000 603157.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525957.669000 603157.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 018 125</ms:GML_ID>
        <ms:NAZWA>027 018 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027018125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525685.840000 605085.476000</gml:lowerCorner>
        		<gml:upperCorner>525685.840000 605085.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525685.840000 605085.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 016 178</ms:GML_ID>
        <ms:NAZWA>027 016 178</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027016178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525470.486000 606615.760000</gml:lowerCorner>
        		<gml:upperCorner>525470.486000 606615.760000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525470.486000 606615.760000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 014 632</ms:GML_ID>
        <ms:NAZWA>027 014 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027014632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525371.397000 607018.973000</gml:lowerCorner>
        		<gml:upperCorner>525371.397000 607018.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525371.397000 607018.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 014 215</ms:GML_ID>
        <ms:NAZWA>027 014 215</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027014215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525218.658000 607418.244000</gml:lowerCorner>
        		<gml:upperCorner>525218.658000 607418.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525218.658000 607418.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 013 788</ms:GML_ID>
        <ms:NAZWA>027 013 788</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027013788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524941.780000 608476.354000</gml:lowerCorner>
        		<gml:upperCorner>524941.780000 608476.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524941.780000 608476.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 012 679</ms:GML_ID>
        <ms:NAZWA>027 012 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027012679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524970.246474 609010.204314</gml:lowerCorner>
        		<gml:upperCorner>524970.246474 609010.204314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524970.246474 609010.204314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 012 144</ms:GML_ID>
        <ms:NAZWA>027 012 144</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027012144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524838.945000 609768.481000</gml:lowerCorner>
        		<gml:upperCorner>524838.945000 609768.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524838.945000 609768.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 011 362</ms:GML_ID>
        <ms:NAZWA>027 011 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027011362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524843.239000 613031.699000</gml:lowerCorner>
        		<gml:upperCorner>524843.239000 613031.699000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524843.239000 613031.699000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 008 055</ms:GML_ID>
        <ms:NAZWA>027 008 055</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027008055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524675.122592 614127.672058</gml:lowerCorner>
        		<gml:upperCorner>524675.122592 614127.672058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524675.122592 614127.672058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 006 931</ms:GML_ID>
        <ms:NAZWA>027 006 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027006931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509633.392254 615380.492890</gml:lowerCorner>
        		<gml:upperCorner>509633.392254 615380.492890</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509633.392254 615380.492890</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 043 622</ms:GML_ID>
        <ms:NAZWA>009 043 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009043622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524740.386000 616237.802000</gml:lowerCorner>
        		<gml:upperCorner>524740.386000 616237.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524740.386000 616237.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 004 817</ms:GML_ID>
        <ms:NAZWA>027 004 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027004817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510594.976925 616336.381447</gml:lowerCorner>
        		<gml:upperCorner>510594.976925 616336.381447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510594.976925 616336.381447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 044 984</ms:GML_ID>
        <ms:NAZWA>009 044 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009044984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508085.862607 616429.314499</gml:lowerCorner>
        		<gml:upperCorner>508085.862607 616429.314499</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508085.862607 616429.314499</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 041 258</ms:GML_ID>
        <ms:NAZWA>009 041 258</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>009041258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455981.240000 610716.656000</gml:lowerCorner>
        		<gml:upperCorner>455981.240000 610716.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455981.240000 610716.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 032 540</ms:GML_ID>
        <ms:NAZWA>012 032 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012032540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455983.559426 609689.948975</gml:lowerCorner>
        		<gml:upperCorner>455983.559426 609689.948975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455983.559426 609689.948975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 031 515</ms:GML_ID>
        <ms:NAZWA>012 031 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012031515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456078.618000 607795.896000</gml:lowerCorner>
        		<gml:upperCorner>456078.618000 607795.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456078.618000 607795.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 029 611</ms:GML_ID>
        <ms:NAZWA>012 029 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012029611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456277.048000 606692.146000</gml:lowerCorner>
        		<gml:upperCorner>456277.048000 606692.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456277.048000 606692.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 028 492</ms:GML_ID>
        <ms:NAZWA>012 028 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012028492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456874.857427 584130.017726</gml:lowerCorner>
        		<gml:upperCorner>456874.857427 584130.017726</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456874.857427 584130.017726</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 005 489</ms:GML_ID>
        <ms:NAZWA>012 005 489</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012005489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456906.481369 583203.204205</gml:lowerCorner>
        		<gml:upperCorner>456906.481369 583203.204205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456906.481369 583203.204205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 004 550</ms:GML_ID>
        <ms:NAZWA>012 004 550</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012004550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457154.496581 601834.948769</gml:lowerCorner>
        		<gml:upperCorner>457154.496581 601834.948769</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457154.496581 601834.948769</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.575 001 820</ms:GML_ID>
        <ms:NAZWA>575 001 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>575001820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457171.575143 601928.382539</gml:lowerCorner>
        		<gml:upperCorner>457171.575143 601928.382539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457171.575143 601928.382539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 023 605</ms:GML_ID>
        <ms:NAZWA>012 023 605</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012023605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457371.170000 593418.038000</gml:lowerCorner>
        		<gml:upperCorner>457371.170000 593418.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457371.170000 593418.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 014 917</ms:GML_ID>
        <ms:NAZWA>012 014 917</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012014917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457406.828723 594457.191468</gml:lowerCorner>
        		<gml:upperCorner>457406.828723 594457.191468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457406.828723 594457.191468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 015 963</ms:GML_ID>
        <ms:NAZWA>012 015 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012015963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457491.918504 590392.800857</gml:lowerCorner>
        		<gml:upperCorner>457491.918504 590392.800857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457491.918504 590392.800857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 011 882</ms:GML_ID>
        <ms:NAZWA>012 011 882</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012011882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457522.438366 583856.513365</gml:lowerCorner>
        		<gml:upperCorner>457522.438366 583856.513365</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457522.438366 583856.513365</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 060 778</ms:GML_ID>
        <ms:NAZWA>001 060 778</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001060778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457560.422347 600363.043034</gml:lowerCorner>
        		<gml:upperCorner>457560.422347 600363.043034</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457560.422347 600363.043034</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 021 984</ms:GML_ID>
        <ms:NAZWA>012 021 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012021984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457591.887227 588582.003271</gml:lowerCorner>
        		<gml:upperCorner>457591.887227 588582.003271</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457591.887227 588582.003271</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 010 071</ms:GML_ID>
        <ms:NAZWA>012 010 071</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012010071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457734.108089 595781.976179</gml:lowerCorner>
        		<gml:upperCorner>457734.108089 595781.976179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457734.108089 595781.976179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 017 325</ms:GML_ID>
        <ms:NAZWA>012 017 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012017325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457896.629000 598250.271000</gml:lowerCorner>
        		<gml:upperCorner>457896.629000 598250.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457896.629000 598250.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 019 841</ms:GML_ID>
        <ms:NAZWA>012 019 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012019841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458100.504000 584899.799000</gml:lowerCorner>
        		<gml:upperCorner>458100.504000 584899.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458100.504000 584899.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 059 584</ms:GML_ID>
        <ms:NAZWA>001 059 584</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001059584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459777.087255 587922.138929</gml:lowerCorner>
        		<gml:upperCorner>459777.087255 587922.138929</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459777.087255 587922.138929</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 056 125</ms:GML_ID>
        <ms:NAZWA>001 056 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001056125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480360.989679 582441.904133</gml:lowerCorner>
        		<gml:upperCorner>480360.989679 582441.904133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480360.989679 582441.904133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 058 712</ms:GML_ID>
        <ms:NAZWA>003 058 712</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003058712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482088.678000 583235.405000</gml:lowerCorner>
        		<gml:upperCorner>482088.678000 583235.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482088.678000 583235.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 056 808</ms:GML_ID>
        <ms:NAZWA>003 056 808</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003056808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482821.006211 583450.583579</gml:lowerCorner>
        		<gml:upperCorner>482821.006211 583450.583579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482821.006211 583450.583579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 056 041</ms:GML_ID>
        <ms:NAZWA>003 056 041</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003056041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483632.529201 584184.966295</gml:lowerCorner>
        		<gml:upperCorner>483632.529201 584184.966295</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483632.529201 584184.966295</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 054 920</ms:GML_ID>
        <ms:NAZWA>003 054 920</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003054920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484295.085838 585823.157016</gml:lowerCorner>
        		<gml:upperCorner>484295.085838 585823.157016</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484295.085838 585823.157016</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 053 048</ms:GML_ID>
        <ms:NAZWA>003 053 048</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003053048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483970.329000 587510.699000</gml:lowerCorner>
        		<gml:upperCorner>483970.329000 587510.699000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483970.329000 587510.699000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 051 333</ms:GML_ID>
        <ms:NAZWA>003 051 333</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003051333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460129.306257 588552.976676</gml:lowerCorner>
        		<gml:upperCorner>460129.306257 588552.976676</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460129.306257 588552.976676</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 055 405</ms:GML_ID>
        <ms:NAZWA>001 055 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001055405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483672.803363 589516.693453</gml:lowerCorner>
        		<gml:upperCorner>483672.803363 589516.693453</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483672.803363 589516.693453</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 049 295</ms:GML_ID>
        <ms:NAZWA>003 049 295</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003049295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461259.946176 590594.065071</gml:lowerCorner>
        		<gml:upperCorner>461259.946176 590594.065071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461259.946176 590594.065071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 053 068</ms:GML_ID>
        <ms:NAZWA>001 053 068</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001053068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483515.939327 591820.681724</gml:lowerCorner>
        		<gml:upperCorner>483515.939327 591820.681724</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483515.939327 591820.681724</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 046 986</ms:GML_ID>
        <ms:NAZWA>003 046 986</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003046986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462212.179060 592313.493976</gml:lowerCorner>
        		<gml:upperCorner>462212.179060 592313.493976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462212.179060 592313.493976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 051 103</ms:GML_ID>
        <ms:NAZWA>001 051 103</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001051103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483070.630775 594645.830650</gml:lowerCorner>
        		<gml:upperCorner>483070.630775 594645.830650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483070.630775 594645.830650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 044 127</ms:GML_ID>
        <ms:NAZWA>003 044 127</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003044127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465633.486727 598438.776600</gml:lowerCorner>
        		<gml:upperCorner>465633.486727 598438.776600</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465633.486727 598438.776600</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 044 084</ms:GML_ID>
        <ms:NAZWA>001 044 084</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001044084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482314.618129 599380.902754</gml:lowerCorner>
        		<gml:upperCorner>482314.618129 599380.902754</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482314.618129 599380.902754</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 039 327</ms:GML_ID>
        <ms:NAZWA>003 039 327</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003039327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482170.378000 600289.951000</gml:lowerCorner>
        		<gml:upperCorner>482170.378000 600289.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482170.378000 600289.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 038 406</ms:GML_ID>
        <ms:NAZWA>003 038 406</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003038406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467419.242415 601592.704849</gml:lowerCorner>
        		<gml:upperCorner>467419.242415 601592.704849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467419.242415 601592.704849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 040 468</ms:GML_ID>
        <ms:NAZWA>001 040 468</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001040468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481910.339765 601916.079673</gml:lowerCorner>
        		<gml:upperCorner>481910.339765 601916.079673</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481910.339765 601916.079673</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 036 758</ms:GML_ID>
        <ms:NAZWA>003 036 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003036758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468386.540312 603299.607729</gml:lowerCorner>
        		<gml:upperCorner>468386.540312 603299.607729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468386.540312 603299.607729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 038 495</ms:GML_ID>
        <ms:NAZWA>001 038 495</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001038495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481523.013000 604346.693000</gml:lowerCorner>
        		<gml:upperCorner>481523.013000 604346.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481523.013000 604346.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 034 296</ms:GML_ID>
        <ms:NAZWA>003 034 296</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003034296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481153.108696 607589.733297</gml:lowerCorner>
        		<gml:upperCorner>481153.108696 607589.733297</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481153.108696 607589.733297</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 031 020</ms:GML_ID>
        <ms:NAZWA>003 031 020</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003031020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481273.134304 610152.813591</gml:lowerCorner>
        		<gml:upperCorner>481273.134304 610152.813591</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481273.134304 610152.813591</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 028 451</ms:GML_ID>
        <ms:NAZWA>003 028 451</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003028451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456283.777000 612808.816000</gml:lowerCorner>
        		<gml:upperCorner>456283.777000 612808.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456283.777000 612808.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 034 656</ms:GML_ID>
        <ms:NAZWA>012 034 656</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012034656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466309.759934 569252.759681</gml:lowerCorner>
        		<gml:upperCorner>466309.759934 569252.759681</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466309.759934 569252.759681</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 015 176</ms:GML_ID>
        <ms:NAZWA>011 015 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011015176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451031.657000 569402.348000</gml:lowerCorner>
        		<gml:upperCorner>451031.657000 569402.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451031.657000 569402.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 079 416</ms:GML_ID>
        <ms:NAZWA>001 079 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001079416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451799.676000 569791.765000</gml:lowerCorner>
        		<gml:upperCorner>451799.676000 569791.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451799.676000 569791.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 078 535</ms:GML_ID>
        <ms:NAZWA>001 078 535</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001078535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463882.965000 570354.801000</gml:lowerCorner>
        		<gml:upperCorner>463882.965000 570354.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463882.965000 570354.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 012 511</ms:GML_ID>
        <ms:NAZWA>011 012 511</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011012511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453541.934000 570949.973000</gml:lowerCorner>
        		<gml:upperCorner>453541.934000 570949.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453541.934000 570949.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 076 294</ms:GML_ID>
        <ms:NAZWA>001 076 294</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001076294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462336.061610 571063.739840</gml:lowerCorner>
        		<gml:upperCorner>462336.061610 571063.739840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462336.061610 571063.739840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 010 808</ms:GML_ID>
        <ms:NAZWA>011 010 808</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011010808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461735.285008 571330.537078</gml:lowerCorner>
        		<gml:upperCorner>461735.285008 571330.537078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461735.285008 571330.537078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 010 151</ms:GML_ID>
        <ms:NAZWA>011 010 151</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011010151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453405.048000 571853.210000</gml:lowerCorner>
        		<gml:upperCorner>453405.048000 571853.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453405.048000 571853.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 075 372</ms:GML_ID>
        <ms:NAZWA>001 075 372</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001075372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459695.178116 572862.870918</gml:lowerCorner>
        		<gml:upperCorner>459695.178116 572862.870918</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459695.178116 572862.870918</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 007 550</ms:GML_ID>
        <ms:NAZWA>011 007 550</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011007550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453067.094000 573218.810000</gml:lowerCorner>
        		<gml:upperCorner>453067.094000 573218.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453067.094000 573218.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 073 974</ms:GML_ID>
        <ms:NAZWA>001 073 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001073974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458895.334308 573831.817886</gml:lowerCorner>
        		<gml:upperCorner>458895.334308 573831.817886</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458895.334308 573831.817886</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 006 292</ms:GML_ID>
        <ms:NAZWA>011 006 292</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011006292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452835.940251 574154.402226</gml:lowerCorner>
        		<gml:upperCorner>452835.940251 574154.402226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452835.940251 574154.402226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 073 009</ms:GML_ID>
        <ms:NAZWA>001 073 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001073009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458251.225000 574612.289000</gml:lowerCorner>
        		<gml:upperCorner>458251.225000 574612.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458251.225000 574612.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 005 281</ms:GML_ID>
        <ms:NAZWA>011 005 281</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011005281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

