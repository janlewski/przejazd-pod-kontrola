<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:20" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=2000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=4000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>198292.331000 508313.939180</gml:lowerCorner>
      		<gml:upperCorner>564026.641000 695063.356000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457522.009964 575495.937875</gml:lowerCorner>
        		<gml:upperCorner>457522.009964 575495.937875</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457522.009964 575495.937875</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 004 135</ms:GML_ID>
        <ms:NAZWA>011 004 135</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011004135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452483.644000 575880.287000</gml:lowerCorner>
        		<gml:upperCorner>452483.644000 575880.287000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452483.644000 575880.287000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 071 236</ms:GML_ID>
        <ms:NAZWA>001 071 236</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001071236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456082.660216 577244.681677</gml:lowerCorner>
        		<gml:upperCorner>456082.660216 577244.681677</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456082.660216 577244.681677</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 001 864</ms:GML_ID>
        <ms:NAZWA>011 001 864</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011001864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454602.381000 577639.004000</gml:lowerCorner>
        		<gml:upperCorner>454602.381000 577639.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454602.381000 577639.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 068 236</ms:GML_ID>
        <ms:NAZWA>001 068 236</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001068236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455693.249000 577758.916000</gml:lowerCorner>
        		<gml:upperCorner>455693.249000 577758.916000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455693.249000 577758.916000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.530 000 592</ms:GML_ID>
        <ms:NAZWA>530 000 592</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>530000592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455621.288000 577944.993000</gml:lowerCorner>
        		<gml:upperCorner>455621.288000 577944.993000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455621.288000 577944.993000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 067 163</ms:GML_ID>
        <ms:NAZWA>001 067 163</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001067163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455865.267976 577980.252766</gml:lowerCorner>
        		<gml:upperCorner>455865.267976 577980.252766</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455865.267976 577980.252766</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 001 082</ms:GML_ID>
        <ms:NAZWA>011 001 082</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011001082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461799.995987 591569.494739</gml:lowerCorner>
        		<gml:upperCorner>461799.995987 591569.494739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461799.995987 591569.494739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 051 959</ms:GML_ID>
        <ms:NAZWA>001 051 959</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001051959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462727.952000 593245.876000</gml:lowerCorner>
        		<gml:upperCorner>462727.952000 593245.876000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462727.952000 593245.876000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 050 038</ms:GML_ID>
        <ms:NAZWA>001 050 038</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001050038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469937.376837 566783.655381</gml:lowerCorner>
        		<gml:upperCorner>469937.376837 566783.655381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469937.376837 566783.655381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 078 509</ms:GML_ID>
        <ms:NAZWA>003 078 509</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003078509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469967.955000 568376.285000</gml:lowerCorner>
        		<gml:upperCorner>469967.955000 568376.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469967.955000 568376.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 076 847</ms:GML_ID>
        <ms:NAZWA>003 076 847</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003076847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469974.713000 565632.250000</gml:lowerCorner>
        		<gml:upperCorner>469974.713000 565632.250000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469974.713000 565632.250000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 007 987</ms:GML_ID>
        <ms:NAZWA>015 007 987</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015007987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470072.383000 569599.857000</gml:lowerCorner>
        		<gml:upperCorner>470072.383000 569599.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470072.383000 569599.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 075 617</ms:GML_ID>
        <ms:NAZWA>003 075 617</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003075617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470104.590666 565057.304599</gml:lowerCorner>
        		<gml:upperCorner>470104.590666 565057.304599</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470104.590666 565057.304599</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 008 621</ms:GML_ID>
        <ms:NAZWA>015 008 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015008621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470382.169863 570307.530337</gml:lowerCorner>
        		<gml:upperCorner>470382.169863 570307.530337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470382.169863 570307.530337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 074 845</ms:GML_ID>
        <ms:NAZWA>003 074 845</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003074845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470598.872495 566021.233022</gml:lowerCorner>
        		<gml:upperCorner>470598.872495 566021.233022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470598.872495 566021.233022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.531 000 454</ms:GML_ID>
        <ms:NAZWA>531 000 454</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>531000454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470932.418318 565734.233380</gml:lowerCorner>
        		<gml:upperCorner>470932.418318 565734.233380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470932.418318 565734.233380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.532 000 344</ms:GML_ID>
        <ms:NAZWA>532 000 344</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>532000344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471029.639268 571708.487711</gml:lowerCorner>
        		<gml:upperCorner>471029.639268 571708.487711</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471029.639268 571708.487711</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 073 300</ms:GML_ID>
        <ms:NAZWA>003 073 300</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003073300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471448.435995 572616.696833</gml:lowerCorner>
        		<gml:upperCorner>471448.435995 572616.696833</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471448.435995 572616.696833</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 072 300</ms:GML_ID>
        <ms:NAZWA>003 072 300</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003072300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472307.729833 574485.367574</gml:lowerCorner>
        		<gml:upperCorner>472307.729833 574485.367574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472307.729833 574485.367574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 070 242</ms:GML_ID>
        <ms:NAZWA>003 070 242</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003070242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472319.852733 564914.207570</gml:lowerCorner>
        		<gml:upperCorner>472319.852733 564914.207570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472319.852733 564914.207570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 081 570</ms:GML_ID>
        <ms:NAZWA>003 081 570</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003081570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472756.333000 575238.095000</gml:lowerCorner>
        		<gml:upperCorner>472756.333000 575238.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472756.333000 575238.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 069 360</ms:GML_ID>
        <ms:NAZWA>003 069 360</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003069360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473046.497000 564304.322000</gml:lowerCorner>
        		<gml:upperCorner>473046.497000 564304.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473046.497000 564304.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 082 540</ms:GML_ID>
        <ms:NAZWA>003 082 540</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003082540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473355.735287 563818.331645</gml:lowerCorner>
        		<gml:upperCorner>473355.735287 563818.331645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473355.735287 563818.331645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 083 116</ms:GML_ID>
        <ms:NAZWA>003 083 116</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003083116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473763.040886 576900.911234</gml:lowerCorner>
        		<gml:upperCorner>473763.040886 576900.911234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473763.040886 576900.911234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 067 420</ms:GML_ID>
        <ms:NAZWA>003 067 420</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003067420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474397.744800 562184.035658</gml:lowerCorner>
        		<gml:upperCorner>474397.744800 562184.035658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474397.744800 562184.035658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 085 055</ms:GML_ID>
        <ms:NAZWA>003 085 055</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003085055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474758.681430 561617.380425</gml:lowerCorner>
        		<gml:upperCorner>474758.681430 561617.380425</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474758.681430 561617.380425</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 085 729</ms:GML_ID>
        <ms:NAZWA>003 085 729</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003085729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475277.949618 560495.388575</gml:lowerCorner>
        		<gml:upperCorner>475277.949618 560495.388575</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475277.949618 560495.388575</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 086 975</ms:GML_ID>
        <ms:NAZWA>003 086 975</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003086975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475302.101872 578540.165048</gml:lowerCorner>
        		<gml:upperCorner>475302.101872 578540.165048</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475302.101872 578540.165048</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 065 176</ms:GML_ID>
        <ms:NAZWA>003 065 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003065176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475761.042353 558483.009409</gml:lowerCorner>
        		<gml:upperCorner>475761.042353 558483.009409</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475761.042353 558483.009409</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 089 034</ms:GML_ID>
        <ms:NAZWA>003 089 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003089034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476242.844000 556712.519000</gml:lowerCorner>
        		<gml:upperCorner>476242.844000 556712.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476242.844000 556712.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 090 872</ms:GML_ID>
        <ms:NAZWA>003 090 872</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003090872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456791.201000 549025.274000</gml:lowerCorner>
        		<gml:upperCorner>456791.201000 549025.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456791.201000 549025.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 030 516</ms:GML_ID>
        <ms:NAZWA>015 030 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015030516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457178.119000 549490.383000</gml:lowerCorner>
        		<gml:upperCorner>457178.119000 549490.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457178.119000 549490.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 029 909</ms:GML_ID>
        <ms:NAZWA>015 029 909</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015029909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458097.823000 551466.289000</gml:lowerCorner>
        		<gml:upperCorner>458097.823000 551466.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458097.823000 551466.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 027 725</ms:GML_ID>
        <ms:NAZWA>015 027 725</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015027725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458814.873385 552135.189061</gml:lowerCorner>
        		<gml:upperCorner>458814.873385 552135.189061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458814.873385 552135.189061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 026 744</ms:GML_ID>
        <ms:NAZWA>015 026 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015026744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459493.036000 552741.220000</gml:lowerCorner>
        		<gml:upperCorner>459493.036000 552741.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459493.036000 552741.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 025 835</ms:GML_ID>
        <ms:NAZWA>015 025 835</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015025835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460107.571245 553347.503381</gml:lowerCorner>
        		<gml:upperCorner>460107.571245 553347.503381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460107.571245 553347.503381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 024 986</ms:GML_ID>
        <ms:NAZWA>015 024 986</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015024986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460663.094000 554008.915000</gml:lowerCorner>
        		<gml:upperCorner>460663.094000 554008.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460663.094000 554008.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 024 105</ms:GML_ID>
        <ms:NAZWA>015 024 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015024105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460990.990000 554401.918000</gml:lowerCorner>
        		<gml:upperCorner>460990.990000 554401.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460990.990000 554401.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 023 592</ms:GML_ID>
        <ms:NAZWA>015 023 592</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015023592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461564.885663 555713.787022</gml:lowerCorner>
        		<gml:upperCorner>461564.885663 555713.787022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461564.885663 555713.787022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 022 142</ms:GML_ID>
        <ms:NAZWA>015 022 142</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015022142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462536.946000 557386.907000</gml:lowerCorner>
        		<gml:upperCorner>462536.946000 557386.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462536.946000 557386.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 020 206</ms:GML_ID>
        <ms:NAZWA>015 020 206</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015020206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463499.872589 559576.910098</gml:lowerCorner>
        		<gml:upperCorner>463499.872589 559576.910098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463499.872589 559576.910098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 017 770</ms:GML_ID>
        <ms:NAZWA>015 017 770</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015017770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463946.190062 560395.597944</gml:lowerCorner>
        		<gml:upperCorner>463946.190062 560395.597944</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463946.190062 560395.597944</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 016 838</ms:GML_ID>
        <ms:NAZWA>015 016 838</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015016838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464260.047000 560973.643000</gml:lowerCorner>
        		<gml:upperCorner>464260.047000 560973.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464260.047000 560973.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 016 180</ms:GML_ID>
        <ms:NAZWA>015 016 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015016180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464784.990041 561640.400770</gml:lowerCorner>
        		<gml:upperCorner>464784.990041 561640.400770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464784.990041 561640.400770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 015 318</ms:GML_ID>
        <ms:NAZWA>015 015 318</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015015318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465479.930000 562021.267000</gml:lowerCorner>
        		<gml:upperCorner>465479.930000 562021.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465479.930000 562021.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 014 525</ms:GML_ID>
        <ms:NAZWA>015 014 525</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015014525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466125.097000 562372.599000</gml:lowerCorner>
        		<gml:upperCorner>466125.097000 562372.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466125.097000 562372.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 013 789</ms:GML_ID>
        <ms:NAZWA>015 013 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015013789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468837.096610 563370.005049</gml:lowerCorner>
        		<gml:upperCorner>468837.096610 563370.005049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468837.096610 563370.005049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 010 880</ms:GML_ID>
        <ms:NAZWA>015 010 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015010880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469639.242183 563820.968544</gml:lowerCorner>
        		<gml:upperCorner>469639.242183 563820.968544</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469639.242183 563820.968544</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 009 957</ms:GML_ID>
        <ms:NAZWA>015 009 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015009957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469440.402104 566169.513861</gml:lowerCorner>
        		<gml:upperCorner>469440.402104 566169.513861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469440.402104 566169.513861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 007 229</ms:GML_ID>
        <ms:NAZWA>015 007 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015007229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469216.805000 567403.299000</gml:lowerCorner>
        		<gml:upperCorner>469216.805000 567403.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469216.805000 567403.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.011 018 658</ms:GML_ID>
        <ms:NAZWA>011 018 658</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>011018658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469709.970008 567421.459490</gml:lowerCorner>
        		<gml:upperCorner>469709.970008 567421.459490</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469709.970008 567421.459490</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 005 777</ms:GML_ID>
        <ms:NAZWA>015 005 777</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015005777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469654.466000 567451.687000</gml:lowerCorner>
        		<gml:upperCorner>469654.466000 567451.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469654.466000 567451.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.533 000 921</ms:GML_ID>
        <ms:NAZWA>533 000 921</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>533000921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476585.231000 555754.701000</gml:lowerCorner>
        		<gml:upperCorner>476585.231000 555754.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476585.231000 555754.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 091 890</ms:GML_ID>
        <ms:NAZWA>003 091 890</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003091890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476831.046368 555067.598839</gml:lowerCorner>
        		<gml:upperCorner>476831.046368 555067.598839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476831.046368 555067.598839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 092 620</ms:GML_ID>
        <ms:NAZWA>003 092 620</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003092620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477181.923037 579498.857252</gml:lowerCorner>
        		<gml:upperCorner>477181.923037 579498.857252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477181.923037 579498.857252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 063 049</ms:GML_ID>
        <ms:NAZWA>003 063 049</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003063049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477260.123703 553822.668515</gml:lowerCorner>
        		<gml:upperCorner>477260.123703 553822.668515</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477260.123703 553822.668515</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 093 939</ms:GML_ID>
        <ms:NAZWA>003 093 939</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003093939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478000.317697 580243.615168</gml:lowerCorner>
        		<gml:upperCorner>478000.317697 580243.615168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478000.317697 580243.615168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 061 941</ms:GML_ID>
        <ms:NAZWA>003 061 941</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003061941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478339.810000 552029.904000</gml:lowerCorner>
        		<gml:upperCorner>478339.810000 552029.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478339.810000 552029.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 096 057</ms:GML_ID>
        <ms:NAZWA>003 096 057</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003096057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478470.722000 580684.656000</gml:lowerCorner>
        		<gml:upperCorner>478470.722000 580684.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478470.722000 580684.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 061 297</ms:GML_ID>
        <ms:NAZWA>003 061 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003061297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478930.584000 581114.622000</gml:lowerCorner>
        		<gml:upperCorner>478930.584000 581114.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478930.584000 581114.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 060 667</ms:GML_ID>
        <ms:NAZWA>003 060 667</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003060667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479604.186000 550107.816000</gml:lowerCorner>
        		<gml:upperCorner>479604.186000 550107.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479604.186000 550107.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 098 371</ms:GML_ID>
        <ms:NAZWA>003 098 371</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003098371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480204.898000 548949.153000</gml:lowerCorner>
        		<gml:upperCorner>480204.898000 548949.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480204.898000 548949.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 099 673</ms:GML_ID>
        <ms:NAZWA>003 099 673</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003099673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519039.778000 548446.380000</gml:lowerCorner>
        		<gml:upperCorner>519039.778000 548446.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519039.778000 548446.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 049 456</ms:GML_ID>
        <ms:NAZWA>033 049 456</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033049456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519332.011000 548822.282000</gml:lowerCorner>
        		<gml:upperCorner>519332.011000 548822.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519332.011000 548822.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 049 956</ms:GML_ID>
        <ms:NAZWA>033 049 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033049956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519492.508000 549028.752000</gml:lowerCorner>
        		<gml:upperCorner>519492.508000 549028.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519492.508000 549028.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 050 198</ms:GML_ID>
        <ms:NAZWA>033 050 198</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033050198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520598.822931 548803.536486</gml:lowerCorner>
        		<gml:upperCorner>520598.822931 548803.536486</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520598.822931 548803.536486</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 051 611</ms:GML_ID>
        <ms:NAZWA>033 051 611</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033051611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522953.714507 549049.820523</gml:lowerCorner>
        		<gml:upperCorner>522953.714507 549049.820523</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522953.714507 549049.820523</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 055 033</ms:GML_ID>
        <ms:NAZWA>033 055 033</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033055033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526601.093000 549647.612000</gml:lowerCorner>
        		<gml:upperCorner>526601.093000 549647.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526601.093000 549647.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 059 024</ms:GML_ID>
        <ms:NAZWA>033 059 024</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033059024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527012.119000 549612.823000</gml:lowerCorner>
        		<gml:upperCorner>527012.119000 549612.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527012.119000 549612.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 059 434</ms:GML_ID>
        <ms:NAZWA>033 059 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033059434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528025.309000 549525.198000</gml:lowerCorner>
        		<gml:upperCorner>528025.309000 549525.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528025.309000 549525.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 060 454</ms:GML_ID>
        <ms:NAZWA>033 060 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033060454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528429.894000 549489.135000</gml:lowerCorner>
        		<gml:upperCorner>528429.894000 549489.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528429.894000 549489.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 060 860</ms:GML_ID>
        <ms:NAZWA>033 060 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033060860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529378.485399 591948.928019</gml:lowerCorner>
        		<gml:upperCorner>529378.485399 591948.928019</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529378.485399 591948.928019</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 030 497</ms:GML_ID>
        <ms:NAZWA>027 030 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027030497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529514.384917 549201.302224</gml:lowerCorner>
        		<gml:upperCorner>529514.384917 549201.302224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529514.384917 549201.302224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 061 982</ms:GML_ID>
        <ms:NAZWA>033 061 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033061982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530228.553540 591849.707092</gml:lowerCorner>
        		<gml:upperCorner>530228.553540 591849.707092</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530228.553540 591849.707092</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 031 354</ms:GML_ID>
        <ms:NAZWA>027 031 354</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027031354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533043.891823 548255.912851</gml:lowerCorner>
        		<gml:upperCorner>533043.891823 548255.912851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533043.891823 548255.912851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 065 643</ms:GML_ID>
        <ms:NAZWA>033 065 643</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033065643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531562.646000 548643.802000</gml:lowerCorner>
        		<gml:upperCorner>531562.646000 548643.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531562.646000 548643.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 064 105</ms:GML_ID>
        <ms:NAZWA>033 064 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033064105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530453.603366 548945.441582</gml:lowerCorner>
        		<gml:upperCorner>530453.603366 548945.441582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530453.603366 548945.441582</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 062 956</ms:GML_ID>
        <ms:NAZWA>033 062 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033062956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543763.978000 577028.917000</gml:lowerCorner>
        		<gml:upperCorner>543763.978000 577028.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543763.978000 577028.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 051 994</ms:GML_ID>
        <ms:NAZWA>027 051 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027051994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542106.657000 577861.644000</gml:lowerCorner>
        		<gml:upperCorner>542106.657000 577861.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542106.657000 577861.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 050 131</ms:GML_ID>
        <ms:NAZWA>027 050 131</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027050131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541491.251252 578349.315318</gml:lowerCorner>
        		<gml:upperCorner>541491.251252 578349.315318</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541491.251252 578349.315318</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 049 337</ms:GML_ID>
        <ms:NAZWA>027 049 337</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027049337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540657.204755 579380.181228</gml:lowerCorner>
        		<gml:upperCorner>540657.204755 579380.181228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540657.204755 579380.181228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 048 011</ms:GML_ID>
        <ms:NAZWA>027 048 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027048011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540183.589000 579965.416000</gml:lowerCorner>
        		<gml:upperCorner>540183.589000 579965.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540183.589000 579965.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 047 256</ms:GML_ID>
        <ms:NAZWA>027 047 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027047256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539635.396000 580530.900000</gml:lowerCorner>
        		<gml:upperCorner>539635.396000 580530.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539635.396000 580530.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 046 469</ms:GML_ID>
        <ms:NAZWA>027 046 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027046469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539310.216000 580987.394000</gml:lowerCorner>
        		<gml:upperCorner>539310.216000 580987.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539310.216000 580987.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 045 910</ms:GML_ID>
        <ms:NAZWA>027 045 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027045910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538357.467000 582349.568000</gml:lowerCorner>
        		<gml:upperCorner>538357.467000 582349.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538357.467000 582349.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 044 245</ms:GML_ID>
        <ms:NAZWA>027 044 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027044245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537986.044000 582717.723000</gml:lowerCorner>
        		<gml:upperCorner>537986.044000 582717.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537986.044000 582717.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 043 722</ms:GML_ID>
        <ms:NAZWA>027 043 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027043722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536896.513000 583804.972000</gml:lowerCorner>
        		<gml:upperCorner>536896.513000 583804.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536896.513000 583804.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 042 181</ms:GML_ID>
        <ms:NAZWA>027 042 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027042181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535917.825000 585333.821000</gml:lowerCorner>
        		<gml:upperCorner>535917.825000 585333.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535917.825000 585333.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 040 365</ms:GML_ID>
        <ms:NAZWA>027 040 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027040365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535566.105000 585886.199000</gml:lowerCorner>
        		<gml:upperCorner>535566.105000 585886.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535566.105000 585886.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 039 710</ms:GML_ID>
        <ms:NAZWA>027 039 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027039710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534915.236000 586904.048000</gml:lowerCorner>
        		<gml:upperCorner>534915.236000 586904.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534915.236000 586904.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 038 497</ms:GML_ID>
        <ms:NAZWA>027 038 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027038497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533956.138000 588410.988000</gml:lowerCorner>
        		<gml:upperCorner>533956.138000 588410.988000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533956.138000 588410.988000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 036 714</ms:GML_ID>
        <ms:NAZWA>027 036 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027036714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533475.472000 589166.125000</gml:lowerCorner>
        		<gml:upperCorner>533475.472000 589166.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533475.472000 589166.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 035 818</ms:GML_ID>
        <ms:NAZWA>027 035 818</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027035818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533177.893147 589632.788087</gml:lowerCorner>
        		<gml:upperCorner>533177.893147 589632.788087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533177.893147 589632.788087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 035 265</ms:GML_ID>
        <ms:NAZWA>027 035 265</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027035265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532534.033000 590810.495000</gml:lowerCorner>
        		<gml:upperCorner>532534.033000 590810.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532534.033000 590810.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 033 912</ms:GML_ID>
        <ms:NAZWA>027 033 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027033912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531015.360000 591616.493000</gml:lowerCorner>
        		<gml:upperCorner>531015.360000 591616.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531015.360000 591616.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 032 179</ms:GML_ID>
        <ms:NAZWA>027 032 179</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027032179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564026.641000 537521.138000</gml:lowerCorner>
        		<gml:upperCorner>564026.641000 537521.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564026.641000 537521.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 099 680</ms:GML_ID>
        <ms:NAZWA>033 099 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033099680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562687.210635 538189.921139</gml:lowerCorner>
        		<gml:upperCorner>562687.210635 538189.921139</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562687.210635 538189.921139</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 098 183</ms:GML_ID>
        <ms:NAZWA>033 098 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033098183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555453.563523 540311.579572</gml:lowerCorner>
        		<gml:upperCorner>555453.563523 540311.579572</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555453.563523 540311.579572</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 091 948</ms:GML_ID>
        <ms:NAZWA>027 091 948</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027091948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555344.811606 541127.265933</gml:lowerCorner>
        		<gml:upperCorner>555344.811606 541127.265933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555344.811606 541127.265933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 091 126</ms:GML_ID>
        <ms:NAZWA>027 091 126</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027091126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555222.335084 541785.427478</gml:lowerCorner>
        		<gml:upperCorner>555222.335084 541785.427478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555222.335084 541785.427478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 090 454</ms:GML_ID>
        <ms:NAZWA>027 090 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027090454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555058.454000 542143.409000</gml:lowerCorner>
        		<gml:upperCorner>555058.454000 542143.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555058.454000 542143.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 090 058</ms:GML_ID>
        <ms:NAZWA>027 090 058</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027090058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554675.379951 542735.629536</gml:lowerCorner>
        		<gml:upperCorner>554675.379951 542735.629536</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554675.379951 542735.629536</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 089 351</ms:GML_ID>
        <ms:NAZWA>027 089 351</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027089351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553614.005204 544289.822089</gml:lowerCorner>
        		<gml:upperCorner>553614.005204 544289.822089</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553614.005204 544289.822089</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 087 467</ms:GML_ID>
        <ms:NAZWA>027 087 467</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027087467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553004.427000 544736.470000</gml:lowerCorner>
        		<gml:upperCorner>553004.427000 544736.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553004.427000 544736.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 086 020</ms:GML_ID>
        <ms:NAZWA>033 086 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033086020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551507.827503 544855.461004</gml:lowerCorner>
        		<gml:upperCorner>551507.827503 544855.461004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551507.827503 544855.461004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 084 497</ms:GML_ID>
        <ms:NAZWA>033 084 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033084497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550150.141965 545204.543020</gml:lowerCorner>
        		<gml:upperCorner>550150.141965 545204.543020</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550150.141965 545204.543020</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 083 099</ms:GML_ID>
        <ms:NAZWA>033 083 099</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033083099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549679.011094 545325.844780</gml:lowerCorner>
        		<gml:upperCorner>549679.011094 545325.844780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549679.011094 545325.844780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 082 611</ms:GML_ID>
        <ms:NAZWA>033 082 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033082611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552662.674693 545342.431727</gml:lowerCorner>
        		<gml:upperCorner>552662.674693 545342.431727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552662.674693 545342.431727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 085 980</ms:GML_ID>
        <ms:NAZWA>027 085 980</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027085980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549135.893000 545465.126000</gml:lowerCorner>
        		<gml:upperCorner>549135.893000 545465.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549135.893000 545465.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 082 052</ms:GML_ID>
        <ms:NAZWA>033 082 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033082052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548443.173000 545642.698000</gml:lowerCorner>
        		<gml:upperCorner>548443.173000 545642.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548443.173000 545642.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 081 335</ms:GML_ID>
        <ms:NAZWA>033 081 335</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033081335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547103.184000 545987.552000</gml:lowerCorner>
        		<gml:upperCorner>547103.184000 545987.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547103.184000 545987.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 079 955</ms:GML_ID>
        <ms:NAZWA>033 079 955</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033079955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546047.722795 546259.332508</gml:lowerCorner>
        		<gml:upperCorner>546047.722795 546259.332508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546047.722795 546259.332508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 078 860</ms:GML_ID>
        <ms:NAZWA>033 078 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033078860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545214.563000 546423.269000</gml:lowerCorner>
        		<gml:upperCorner>545214.563000 546423.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545214.563000 546423.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 078 011</ms:GML_ID>
        <ms:NAZWA>033 078 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033078011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544748.103335 546509.197836</gml:lowerCorner>
        		<gml:upperCorner>544748.103335 546509.197836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544748.103335 546509.197836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 077 538</ms:GML_ID>
        <ms:NAZWA>033 077 538</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033077538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544262.127000 546584.148000</gml:lowerCorner>
        		<gml:upperCorner>544262.127000 546584.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544262.127000 546584.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 077 045</ms:GML_ID>
        <ms:NAZWA>033 077 045</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033077045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552379.591956 546745.362396</gml:lowerCorner>
        		<gml:upperCorner>552379.591956 546745.362396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552379.591956 546745.362396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 084 531</ms:GML_ID>
        <ms:NAZWA>027 084 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027084531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552323.590000 548119.277000</gml:lowerCorner>
        		<gml:upperCorner>552323.590000 548119.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552323.590000 548119.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 083 127</ms:GML_ID>
        <ms:NAZWA>027 083 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027083127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552560.403000 550919.554000</gml:lowerCorner>
        		<gml:upperCorner>552560.403000 550919.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552560.403000 550919.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 080 302</ms:GML_ID>
        <ms:NAZWA>027 080 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027080302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552386.693000 551953.599000</gml:lowerCorner>
        		<gml:upperCorner>552386.693000 551953.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552386.693000 551953.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 079 250</ms:GML_ID>
        <ms:NAZWA>027 079 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027079250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552236.330000 552841.725000</gml:lowerCorner>
        		<gml:upperCorner>552236.330000 552841.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552236.330000 552841.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 078 350</ms:GML_ID>
        <ms:NAZWA>027 078 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027078350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552044.148000 553984.393000</gml:lowerCorner>
        		<gml:upperCorner>552044.148000 553984.393000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552044.148000 553984.393000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 077 192</ms:GML_ID>
        <ms:NAZWA>027 077 192</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027077192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552019.485000 554997.587000</gml:lowerCorner>
        		<gml:upperCorner>552019.485000 554997.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552019.485000 554997.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 076 168</ms:GML_ID>
        <ms:NAZWA>027 076 168</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027076168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552071.946000 555603.896000</gml:lowerCorner>
        		<gml:upperCorner>552071.946000 555603.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552071.946000 555603.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 075 561</ms:GML_ID>
        <ms:NAZWA>027 075 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027075561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551798.811000 557256.769000</gml:lowerCorner>
        		<gml:upperCorner>551798.811000 557256.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551798.811000 557256.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 073 883</ms:GML_ID>
        <ms:NAZWA>027 073 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027073883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551612.159784 558269.944838</gml:lowerCorner>
        		<gml:upperCorner>551612.159784 558269.944838</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551612.159784 558269.944838</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 072 852</ms:GML_ID>
        <ms:NAZWA>027 072 852</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027072852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476400.963342 518621.566750</gml:lowerCorner>
        		<gml:upperCorner>476400.963342 518621.566750</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476400.963342 518621.566750</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 060 081</ms:GML_ID>
        <ms:NAZWA>016 060 081</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016060081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477584.611000 519508.262000</gml:lowerCorner>
        		<gml:upperCorner>477584.611000 519508.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477584.611000 519508.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 061 561</ms:GML_ID>
        <ms:NAZWA>016 061 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016061561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479442.160000 520905.245000</gml:lowerCorner>
        		<gml:upperCorner>479442.160000 520905.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479442.160000 520905.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 063 887</ms:GML_ID>
        <ms:NAZWA>016 063 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016063887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487187.420000 521254.567000</gml:lowerCorner>
        		<gml:upperCorner>487187.420000 521254.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487187.420000 521254.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 004 753</ms:GML_ID>
        <ms:NAZWA>033 004 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033004753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480003.995000 521393.891000</gml:lowerCorner>
        		<gml:upperCorner>480003.995000 521393.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480003.995000 521393.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 064 632</ms:GML_ID>
        <ms:NAZWA>016 064 632</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016064632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480810.185000 522157.459000</gml:lowerCorner>
        		<gml:upperCorner>480810.185000 522157.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480810.185000 522157.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 065 743</ms:GML_ID>
        <ms:NAZWA>016 065 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016065743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488876.069000 522268.169000</gml:lowerCorner>
        		<gml:upperCorner>488876.069000 522268.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488876.069000 522268.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 006 737</ms:GML_ID>
        <ms:NAZWA>033 006 737</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033006737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485303.165410 522347.577613</gml:lowerCorner>
        		<gml:upperCorner>485303.165410 522347.577613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485303.165410 522347.577613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 127 490</ms:GML_ID>
        <ms:NAZWA>003 127 490</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003127490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481271.291000 522547.133000</gml:lowerCorner>
        		<gml:upperCorner>481271.291000 522547.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481271.291000 522547.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 066 351</ms:GML_ID>
        <ms:NAZWA>016 066 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016066351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484994.359647 522844.401793</gml:lowerCorner>
        		<gml:upperCorner>484994.359647 522844.401793</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484994.359647 522844.401793</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 126 903</ms:GML_ID>
        <ms:NAZWA>003 126 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003126903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481949.477000 523072.098000</gml:lowerCorner>
        		<gml:upperCorner>481949.477000 523072.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481949.477000 523072.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 067 212</ms:GML_ID>
        <ms:NAZWA>016 067 212</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016067212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490386.574021 523305.582852</gml:lowerCorner>
        		<gml:upperCorner>490386.574021 523305.582852</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490386.574021 523305.582852</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 008 718</ms:GML_ID>
        <ms:NAZWA>033 008 718</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033008718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491977.761000 523644.275000</gml:lowerCorner>
        		<gml:upperCorner>491977.761000 523644.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491977.761000 523644.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 010 391</ms:GML_ID>
        <ms:NAZWA>033 010 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033010391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484245.284062 524349.412509</gml:lowerCorner>
        		<gml:upperCorner>484245.284062 524349.412509</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484245.284062 524349.412509</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 070 238</ms:GML_ID>
        <ms:NAZWA>016 070 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016070238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483873.796000 524592.749000</gml:lowerCorner>
        		<gml:upperCorner>483873.796000 524592.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483873.796000 524592.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 069 759</ms:GML_ID>
        <ms:NAZWA>016 069 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016069759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484452.284000 527700.280000</gml:lowerCorner>
        		<gml:upperCorner>484452.284000 527700.280000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484452.284000 527700.280000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 121 858</ms:GML_ID>
        <ms:NAZWA>003 121 858</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003121858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485057.015530 530760.488250</gml:lowerCorner>
        		<gml:upperCorner>485057.015530 530760.488250</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485057.015530 530760.488250</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 118 736</ms:GML_ID>
        <ms:NAZWA>003 118 736</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003118736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484779.545678 532189.694534</gml:lowerCorner>
        		<gml:upperCorner>484779.545678 532189.694534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484779.545678 532189.694534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 117 275</ms:GML_ID>
        <ms:NAZWA>003 117 275</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003117275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484449.467000 533603.190000</gml:lowerCorner>
        		<gml:upperCorner>484449.467000 533603.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484449.467000 533603.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 115 823</ms:GML_ID>
        <ms:NAZWA>003 115 823</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003115823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484089.563984 535142.139007</gml:lowerCorner>
        		<gml:upperCorner>484089.563984 535142.139007</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484089.563984 535142.139007</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 114 239</ms:GML_ID>
        <ms:NAZWA>003 114 239</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003114239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483728.932265 536687.179082</gml:lowerCorner>
        		<gml:upperCorner>483728.932265 536687.179082</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483728.932265 536687.179082</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 112 654</ms:GML_ID>
        <ms:NAZWA>003 112 654</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003112654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483480.480308 538999.797478</gml:lowerCorner>
        		<gml:upperCorner>483480.480308 538999.797478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483480.480308 538999.797478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 110 312</ms:GML_ID>
        <ms:NAZWA>003 110 312</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003110312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483461.438000 540261.031000</gml:lowerCorner>
        		<gml:upperCorner>483461.438000 540261.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483461.438000 540261.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 109 052</ms:GML_ID>
        <ms:NAZWA>003 109 052</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003109052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483261.636814 541969.452114</gml:lowerCorner>
        		<gml:upperCorner>483261.636814 541969.452114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483261.636814 541969.452114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 107 323</ms:GML_ID>
        <ms:NAZWA>003 107 323</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003107323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452029.243680 543571.686770</gml:lowerCorner>
        		<gml:upperCorner>452029.243680 543571.686770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452029.243680 543571.686770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 038 295</ms:GML_ID>
        <ms:NAZWA>015 038 295</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015038295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452206.324507 544032.592074</gml:lowerCorner>
        		<gml:upperCorner>452206.324507 544032.592074</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452206.324507 544032.592074</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 037 803</ms:GML_ID>
        <ms:NAZWA>015 037 803</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015037803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452484.557585 544521.182117</gml:lowerCorner>
        		<gml:upperCorner>452484.557585 544521.182117</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452484.557585 544521.182117</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 037 249</ms:GML_ID>
        <ms:NAZWA>015 037 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015037249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452725.046421 544943.372808</gml:lowerCorner>
        		<gml:upperCorner>452725.046421 544943.372808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452725.046421 544943.372808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 036 753</ms:GML_ID>
        <ms:NAZWA>015 036 753</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015036753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453325.093000 545660.506000</gml:lowerCorner>
        		<gml:upperCorner>453325.093000 545660.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453325.093000 545660.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 035 807</ms:GML_ID>
        <ms:NAZWA>015 035 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015035807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454009.206000 546194.888000</gml:lowerCorner>
        		<gml:upperCorner>454009.206000 546194.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454009.206000 546194.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 034 934</ms:GML_ID>
        <ms:NAZWA>015 034 934</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015034934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481472.773594 546502.555202</gml:lowerCorner>
        		<gml:upperCorner>481472.773594 546502.555202</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481472.773594 546502.555202</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 102 433</ms:GML_ID>
        <ms:NAZWA>003 102 433</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003102433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480967.408448 547478.394678</gml:lowerCorner>
        		<gml:upperCorner>480967.408448 547478.394678</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480967.408448 547478.394678</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 101 336</ms:GML_ID>
        <ms:NAZWA>003 101 336</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003101336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454966.919000 548224.494000</gml:lowerCorner>
        		<gml:upperCorner>454966.919000 548224.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454966.919000 548224.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 032 592</ms:GML_ID>
        <ms:NAZWA>015 032 592</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015032592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488350.585000 517897.685000</gml:lowerCorner>
        		<gml:upperCorner>488350.585000 517897.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488350.585000 517897.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 007 141</ms:GML_ID>
        <ms:NAZWA>018 007 141</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018007141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487711.769403 518395.061064</gml:lowerCorner>
        		<gml:upperCorner>487711.769403 518395.061064</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487711.769403 518395.061064</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 006 331</ms:GML_ID>
        <ms:NAZWA>018 006 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018006331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486580.328625 519385.327832</gml:lowerCorner>
        		<gml:upperCorner>486580.328625 519385.327832</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486580.328625 519385.327832</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 004 815</ms:GML_ID>
        <ms:NAZWA>018 004 815</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018004815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486679.812465 520795.413106</gml:lowerCorner>
        		<gml:upperCorner>486679.812465 520795.413106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486679.812465 520795.413106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 004 066</ms:GML_ID>
        <ms:NAZWA>033 004 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033004066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492852.395738 524092.648344</gml:lowerCorner>
        		<gml:upperCorner>492852.395738 524092.648344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492852.395738 524092.648344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 011 374</ms:GML_ID>
        <ms:NAZWA>033 011 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033011374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493488.004870 524418.940478</gml:lowerCorner>
        		<gml:upperCorner>493488.004870 524418.940478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493488.004870 524418.940478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 012 089</ms:GML_ID>
        <ms:NAZWA>033 012 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033012089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494599.501113 524888.704014</gml:lowerCorner>
        		<gml:upperCorner>494599.501113 524888.704014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494599.501113 524888.704014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 013 300</ms:GML_ID>
        <ms:NAZWA>033 013 300</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033013300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495801.738052 525324.354222</gml:lowerCorner>
        		<gml:upperCorner>495801.738052 525324.354222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495801.738052 525324.354222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 014 580</ms:GML_ID>
        <ms:NAZWA>033 014 580</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033014580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497823.783000 526859.919000</gml:lowerCorner>
        		<gml:upperCorner>497823.783000 526859.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497823.783000 526859.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 017 120</ms:GML_ID>
        <ms:NAZWA>033 017 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033017120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499649.705159 528248.790605</gml:lowerCorner>
        		<gml:upperCorner>499649.705159 528248.790605</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499649.705159 528248.790605</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 019 416</ms:GML_ID>
        <ms:NAZWA>033 019 416</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033019416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500972.712841 528757.797729</gml:lowerCorner>
        		<gml:upperCorner>500972.712841 528757.797729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500972.712841 528757.797729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 020 836</ms:GML_ID>
        <ms:NAZWA>033 020 836</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033020836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502599.850394 529666.723138</gml:lowerCorner>
        		<gml:upperCorner>502599.850394 529666.723138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502599.850394 529666.723138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 022 705</ms:GML_ID>
        <ms:NAZWA>033 022 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033022705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504980.430000 531141.296000</gml:lowerCorner>
        		<gml:upperCorner>504980.430000 531141.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504980.430000 531141.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 025 558</ms:GML_ID>
        <ms:NAZWA>033 025 558</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033025558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505327.635554 531369.633506</gml:lowerCorner>
        		<gml:upperCorner>505327.635554 531369.633506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505327.635554 531369.633506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 025 963</ms:GML_ID>
        <ms:NAZWA>033 025 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033025963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506662.693000 532015.300000</gml:lowerCorner>
        		<gml:upperCorner>506662.693000 532015.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506662.693000 532015.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 027 454</ms:GML_ID>
        <ms:NAZWA>033 027 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033027454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507166.126762 532203.919979</gml:lowerCorner>
        		<gml:upperCorner>507166.126762 532203.919979</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507166.126762 532203.919979</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 027 992</ms:GML_ID>
        <ms:NAZWA>033 027 992</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033027992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508323.958420 532632.457592</gml:lowerCorner>
        		<gml:upperCorner>508323.958420 532632.457592</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508323.958420 532632.457592</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 029 228</ms:GML_ID>
        <ms:NAZWA>033 029 228</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033029228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508883.780000 532999.657000</gml:lowerCorner>
        		<gml:upperCorner>508883.780000 532999.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508883.780000 532999.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 029 898</ms:GML_ID>
        <ms:NAZWA>033 029 898</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033029898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509457.746950 533499.512318</gml:lowerCorner>
        		<gml:upperCorner>509457.746950 533499.512318</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509457.746950 533499.512318</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 030 667</ms:GML_ID>
        <ms:NAZWA>033 030 667</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033030667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509983.786132 534702.359174</gml:lowerCorner>
        		<gml:upperCorner>509983.786132 534702.359174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509983.786132 534702.359174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 031 981</ms:GML_ID>
        <ms:NAZWA>033 031 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033031981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510595.096359 536524.887463</gml:lowerCorner>
        		<gml:upperCorner>510595.096359 536524.887463</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510595.096359 536524.887463</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 033 927</ms:GML_ID>
        <ms:NAZWA>033 033 927</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033033927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511423.920000 537539.643000</gml:lowerCorner>
        		<gml:upperCorner>511423.920000 537539.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511423.920000 537539.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 035 238</ms:GML_ID>
        <ms:NAZWA>033 035 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033035238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512104.942292 538414.492272</gml:lowerCorner>
        		<gml:upperCorner>512104.942292 538414.492272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512104.942292 538414.492272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 036 347</ms:GML_ID>
        <ms:NAZWA>033 036 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033036347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513109.896842 539765.419495</gml:lowerCorner>
        		<gml:upperCorner>513109.896842 539765.419495</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513109.896842 539765.419495</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 038 032</ms:GML_ID>
        <ms:NAZWA>033 038 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033038032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516136.507937 544135.783010</gml:lowerCorner>
        		<gml:upperCorner>516136.507937 544135.783010</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516136.507937 544135.783010</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 043 439</ms:GML_ID>
        <ms:NAZWA>033 043 439</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033043439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516905.953286 545004.410254</gml:lowerCorner>
        		<gml:upperCorner>516905.953286 545004.410254</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516905.953286 545004.410254</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 044 625</ms:GML_ID>
        <ms:NAZWA>033 044 625</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033044625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288035.407000 677738.497000</gml:lowerCorner>
        		<gml:upperCorner>288035.407000 677738.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288035.407000 677738.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 275 062</ms:GML_ID>
        <ms:NAZWA>025 275 062</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025275062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288288.016846 694760.401721</gml:lowerCorner>
        		<gml:upperCorner>288288.016846 694760.401721</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288288.016846 694760.401721</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 012 624</ms:GML_ID>
        <ms:NAZWA>071 012 624</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071012624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288768.747891 681335.475539</gml:lowerCorner>
        		<gml:upperCorner>288768.747891 681335.475539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288768.747891 681335.475539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.079 003 284</ms:GML_ID>
        <ms:NAZWA>079 003 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>079003284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288932.272000 678488.996000</gml:lowerCorner>
        		<gml:upperCorner>288932.272000 678488.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288932.272000 678488.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 273 893</ms:GML_ID>
        <ms:NAZWA>025 273 893</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025273893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289352.463407 679568.870443</gml:lowerCorner>
        		<gml:upperCorner>289352.463407 679568.870443</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289352.463407 679568.870443</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.079 001 641</ms:GML_ID>
        <ms:NAZWA>079 001 641</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>079001641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289901.575000 679300.038000</gml:lowerCorner>
        		<gml:upperCorner>289901.575000 679300.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289901.575000 679300.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 272 629</ms:GML_ID>
        <ms:NAZWA>025 272 629</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025272629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290288.046000 679623.053000</gml:lowerCorner>
        		<gml:upperCorner>290288.046000 679623.053000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290288.046000 679623.053000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 272 124</ms:GML_ID>
        <ms:NAZWA>025 272 124</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025272124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290809.498000 694112.656000</gml:lowerCorner>
        		<gml:upperCorner>290809.498000 694112.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290809.498000 694112.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 009 934</ms:GML_ID>
        <ms:NAZWA>071 009 934</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071009934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290950.481000 680177.259000</gml:lowerCorner>
        		<gml:upperCorner>290950.481000 680177.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290950.481000 680177.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 271 259</ms:GML_ID>
        <ms:NAZWA>025 271 259</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025271259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291747.954000 680843.972000</gml:lowerCorner>
        		<gml:upperCorner>291747.954000 680843.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291747.954000 680843.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 270 219</ms:GML_ID>
        <ms:NAZWA>025 270 219</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025270219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292056.485263 693394.395147</gml:lowerCorner>
        		<gml:upperCorner>292056.485263 693394.395147</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292056.485263 693394.395147</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 008 478</ms:GML_ID>
        <ms:NAZWA>071 008 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071008478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292563.055000 681525.719000</gml:lowerCorner>
        		<gml:upperCorner>292563.055000 681525.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292563.055000 681525.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 269 156</ms:GML_ID>
        <ms:NAZWA>025 269 156</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025269156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293150.516000 684083.479000</gml:lowerCorner>
        		<gml:upperCorner>293150.516000 684083.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293150.516000 684083.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 266 440</ms:GML_ID>
        <ms:NAZWA>025 266 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025266440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297024.713203 686848.747657</gml:lowerCorner>
        		<gml:upperCorner>297024.713203 686848.747657</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297024.713203 686848.747657</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 085 432</ms:GML_ID>
        <ms:NAZWA>070 085 432</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070085432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298662.237000 677699.856000</gml:lowerCorner>
        		<gml:upperCorner>298662.237000 677699.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298662.237000 677699.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 075 285</ms:GML_ID>
        <ms:NAZWA>070 075 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070075285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298745.121000 679204.055000</gml:lowerCorner>
        		<gml:upperCorner>298745.121000 679204.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298745.121000 679204.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 076 794</ms:GML_ID>
        <ms:NAZWA>070 076 794</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070076794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298765.093000 673529.988000</gml:lowerCorner>
        		<gml:upperCorner>298765.093000 673529.988000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298765.093000 673529.988000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 071 107</ms:GML_ID>
        <ms:NAZWA>070 071 107</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070071107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298859.922000 683309.962000</gml:lowerCorner>
        		<gml:upperCorner>298859.922000 683309.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298859.922000 683309.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 081 290</ms:GML_ID>
        <ms:NAZWA>070 081 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070081290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299015.176000 680151.165000</gml:lowerCorner>
        		<gml:upperCorner>299015.176000 680151.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299015.176000 680151.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 077 791</ms:GML_ID>
        <ms:NAZWA>070 077 791</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070077791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299193.813000 682702.812000</gml:lowerCorner>
        		<gml:upperCorner>299193.813000 682702.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299193.813000 682702.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 080 595</ms:GML_ID>
        <ms:NAZWA>070 080 595</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070080595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299229.585000 680533.385000</gml:lowerCorner>
        		<gml:upperCorner>299229.585000 680533.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299229.585000 680533.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 078 230</ms:GML_ID>
        <ms:NAZWA>070 078 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070078230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299640.392000 681629.845000</gml:lowerCorner>
        		<gml:upperCorner>299640.392000 681629.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299640.392000 681629.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 079 420</ms:GML_ID>
        <ms:NAZWA>070 079 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070079420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307093.018000 694110.183000</gml:lowerCorner>
        		<gml:upperCorner>307093.018000 694110.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307093.018000 694110.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 000 445</ms:GML_ID>
        <ms:NAZWA>074 000 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074000445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307463.405236 695034.520556</gml:lowerCorner>
        		<gml:upperCorner>307463.405236 695034.520556</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307463.405236 695034.520556</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 001 508</ms:GML_ID>
        <ms:NAZWA>074 001 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074001508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255945.136000 678302.816459</gml:lowerCorner>
        		<gml:upperCorner>255945.136000 678302.816459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255945.136000 678302.816459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 310 737</ms:GML_ID>
        <ms:NAZWA>025 310 737</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025310737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265485.812000 678401.462000</gml:lowerCorner>
        		<gml:upperCorner>265485.812000 678401.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265485.812000 678401.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 300 963</ms:GML_ID>
        <ms:NAZWA>025 300 963</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025300963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266569.672361 677906.996815</gml:lowerCorner>
        		<gml:upperCorner>266569.672361 677906.996815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266569.672361 677906.996815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 299 770</ms:GML_ID>
        <ms:NAZWA>025 299 770</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025299770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270590.559588 674694.370646</gml:lowerCorner>
        		<gml:upperCorner>270590.559588 674694.370646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270590.559588 674694.370646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 294 449</ms:GML_ID>
        <ms:NAZWA>025 294 449</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025294449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270976.378547 674158.202878</gml:lowerCorner>
        		<gml:upperCorner>270976.378547 674158.202878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270976.378547 674158.202878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 293 789</ms:GML_ID>
        <ms:NAZWA>025 293 789</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025293789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272085.009548 673052.036723</gml:lowerCorner>
        		<gml:upperCorner>272085.009548 673052.036723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272085.009548 673052.036723</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 292 170</ms:GML_ID>
        <ms:NAZWA>025 292 170</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025292170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273465.417307 672976.490626</gml:lowerCorner>
        		<gml:upperCorner>273465.417307 672976.490626</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273465.417307 672976.490626</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 290 770</ms:GML_ID>
        <ms:NAZWA>025 290 770</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025290770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274984.159781 673298.826442</gml:lowerCorner>
        		<gml:upperCorner>274984.159781 673298.826442</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274984.159781 673298.826442</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 289 217</ms:GML_ID>
        <ms:NAZWA>025 289 217</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025289217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275732.609680 673506.337404</gml:lowerCorner>
        		<gml:upperCorner>275732.609680 673506.337404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275732.609680 673506.337404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 288 436</ms:GML_ID>
        <ms:NAZWA>025 288 436</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025288436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278081.424358 674502.735144</gml:lowerCorner>
        		<gml:upperCorner>278081.424358 674502.735144</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278081.424358 674502.735144</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 285 881</ms:GML_ID>
        <ms:NAZWA>025 285 881</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025285881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279128.683000 674634.132000</gml:lowerCorner>
        		<gml:upperCorner>279128.683000 674634.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279128.683000 674634.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 284 823</ms:GML_ID>
        <ms:NAZWA>025 284 823</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025284823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280994.006000 674710.156000</gml:lowerCorner>
        		<gml:upperCorner>280994.006000 674710.156000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280994.006000 674710.156000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 282 940</ms:GML_ID>
        <ms:NAZWA>025 282 940</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025282940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281270.989747 674777.000416</gml:lowerCorner>
        		<gml:upperCorner>281270.989747 674777.000416</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281270.989747 674777.000416</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 282 648</ms:GML_ID>
        <ms:NAZWA>025 282 648</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025282648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284259.400000 675319.023000</gml:lowerCorner>
        		<gml:upperCorner>284259.400000 675319.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284259.400000 675319.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 279 581</ms:GML_ID>
        <ms:NAZWA>025 279 581</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025279581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285292.490316 675821.908827</gml:lowerCorner>
        		<gml:upperCorner>285292.490316 675821.908827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285292.490316 675821.908827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 278 432</ms:GML_ID>
        <ms:NAZWA>025 278 432</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025278432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286143.562000 694772.515000</gml:lowerCorner>
        		<gml:upperCorner>286143.562000 694772.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286143.562000 694772.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 014 818</ms:GML_ID>
        <ms:NAZWA>071 014 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071014818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286347.342000 676341.116000</gml:lowerCorner>
        		<gml:upperCorner>286347.342000 676341.116000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286347.342000 676341.116000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 277 256</ms:GML_ID>
        <ms:NAZWA>025 277 256</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025277256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286641.078704 694597.138903</gml:lowerCorner>
        		<gml:upperCorner>286641.078704 694597.138903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286641.078704 694597.138903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 014 278</ms:GML_ID>
        <ms:NAZWA>071 014 278</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071014278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286774.852820 676683.885432</gml:lowerCorner>
        		<gml:upperCorner>286774.852820 676683.885432</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286774.852820 676683.885432</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 276 708</ms:GML_ID>
        <ms:NAZWA>025 276 708</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025276708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287411.388000 677217.348000</gml:lowerCorner>
        		<gml:upperCorner>287411.388000 677217.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287411.388000 677217.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 275 887</ms:GML_ID>
        <ms:NAZWA>025 275 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>025275887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395737.692000 652808.265000</gml:lowerCorner>
        		<gml:upperCorner>395737.692000 652808.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395737.692000 652808.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 114 579</ms:GML_ID>
        <ms:NAZWA>026 114 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026114579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395996.254000 654319.874000</gml:lowerCorner>
        		<gml:upperCorner>395996.254000 654319.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395996.254000 654319.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 113 044</ms:GML_ID>
        <ms:NAZWA>026 113 044</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026113044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396621.214000 656551.137000</gml:lowerCorner>
        		<gml:upperCorner>396621.214000 656551.137000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396621.214000 656551.137000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 110 705</ms:GML_ID>
        <ms:NAZWA>026 110 705</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026110705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397883.256000 658478.778000</gml:lowerCorner>
        		<gml:upperCorner>397883.256000 658478.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397883.256000 658478.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 108 405</ms:GML_ID>
        <ms:NAZWA>026 108 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026108405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398335.095000 660708.829000</gml:lowerCorner>
        		<gml:upperCorner>398335.095000 660708.829000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398335.095000 660708.829000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 106 064</ms:GML_ID>
        <ms:NAZWA>026 106 064</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026106064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398357.653999 661370.763019</gml:lowerCorner>
        		<gml:upperCorner>398357.653999 661370.763019</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398357.653999 661370.763019</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 105 397</ms:GML_ID>
        <ms:NAZWA>026 105 397</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026105397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398405.439000 659861.311000</gml:lowerCorner>
        		<gml:upperCorner>398405.439000 659861.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398405.439000 659861.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 106 915</ms:GML_ID>
        <ms:NAZWA>026 106 915</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026106915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398594.609109 662276.340999</gml:lowerCorner>
        		<gml:upperCorner>398594.609109 662276.340999</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398594.609109 662276.340999</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 104 460</ms:GML_ID>
        <ms:NAZWA>026 104 460</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026104460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399116.734592 651800.085784</gml:lowerCorner>
        		<gml:upperCorner>399116.734592 651800.085784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399116.734592 651800.085784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 096 583</ms:GML_ID>
        <ms:NAZWA>008 096 583</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008096583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400498.117834 651826.549212</gml:lowerCorner>
        		<gml:upperCorner>400498.117834 651826.549212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400498.117834 651826.549212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 095 202</ms:GML_ID>
        <ms:NAZWA>008 095 202</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008095202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400728.864000 666191.375000</gml:lowerCorner>
        		<gml:upperCorner>400728.864000 666191.375000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400728.864000 666191.375000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 099 997</ms:GML_ID>
        <ms:NAZWA>026 099 997</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026099997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401559.208000 667326.791000</gml:lowerCorner>
        		<gml:upperCorner>401559.208000 667326.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401559.208000 667326.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 098 582</ms:GML_ID>
        <ms:NAZWA>026 098 582</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026098582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402385.405000 668289.819000</gml:lowerCorner>
        		<gml:upperCorner>402385.405000 668289.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402385.405000 668289.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 097 314</ms:GML_ID>
        <ms:NAZWA>026 097 314</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026097314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402920.005000 668910.494000</gml:lowerCorner>
        		<gml:upperCorner>402920.005000 668910.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402920.005000 668910.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 096 494</ms:GML_ID>
        <ms:NAZWA>026 096 494</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026096494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403301.394000 695063.356000</gml:lowerCorner>
        		<gml:upperCorner>403301.394000 695063.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403301.394000 695063.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 010 187</ms:GML_ID>
        <ms:NAZWA>082 010 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082010187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403319.382000 694636.010000</gml:lowerCorner>
        		<gml:upperCorner>403319.382000 694636.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403319.382000 694636.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 009 759</ms:GML_ID>
        <ms:NAZWA>082 009 759</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082009759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403427.156000 692767.626000</gml:lowerCorner>
        		<gml:upperCorner>403427.156000 692767.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403427.156000 692767.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 007 884</ms:GML_ID>
        <ms:NAZWA>082 007 884</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082007884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403802.755270 652269.285896</gml:lowerCorner>
        		<gml:upperCorner>403802.755270 652269.285896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403802.755270 652269.285896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 091 796</ms:GML_ID>
        <ms:NAZWA>008 091 796</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008091796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403963.242000 691854.613000</gml:lowerCorner>
        		<gml:upperCorner>403963.242000 691854.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403963.242000 691854.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 006 801</ms:GML_ID>
        <ms:NAZWA>082 006 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082006801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404030.598195 652214.753017</gml:lowerCorner>
        		<gml:upperCorner>404030.598195 652214.753017</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404030.598195 652214.753017</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 091 560</ms:GML_ID>
        <ms:NAZWA>008 091 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008091560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404219.278103 670497.952665</gml:lowerCorner>
        		<gml:upperCorner>404219.278103 670497.952665</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404219.278103 670497.952665</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 094 436</ms:GML_ID>
        <ms:NAZWA>026 094 436</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026094436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404616.148240 691354.633605</gml:lowerCorner>
        		<gml:upperCorner>404616.148240 691354.633605</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404616.148240 691354.633605</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 005 977</ms:GML_ID>
        <ms:NAZWA>082 005 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082005977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404719.452000 673635.854000</gml:lowerCorner>
        		<gml:upperCorner>404719.452000 673635.854000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404719.452000 673635.854000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 091 248</ms:GML_ID>
        <ms:NAZWA>026 091 248</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026091248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404764.873928 652023.961222</gml:lowerCorner>
        		<gml:upperCorner>404764.873928 652023.961222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404764.873928 652023.961222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 090 803</ms:GML_ID>
        <ms:NAZWA>008 090 803</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008090803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405066.805000 678109.264000</gml:lowerCorner>
        		<gml:upperCorner>405066.805000 678109.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405066.805000 678109.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 086 654</ms:GML_ID>
        <ms:NAZWA>026 086 654</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026086654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405157.599337 651921.461367</gml:lowerCorner>
        		<gml:upperCorner>405157.599337 651921.461367</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405157.599337 651921.461367</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 090 397</ms:GML_ID>
        <ms:NAZWA>008 090 397</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008090397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405336.606000 679375.384000</gml:lowerCorner>
        		<gml:upperCorner>405336.606000 679375.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405336.606000 679375.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 085 361</ms:GML_ID>
        <ms:NAZWA>026 085 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026085361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405343.596000 690904.129000</gml:lowerCorner>
        		<gml:upperCorner>405343.596000 690904.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405343.596000 690904.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 005 116</ms:GML_ID>
        <ms:NAZWA>082 005 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082005116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405659.281000 680891.196000</gml:lowerCorner>
        		<gml:upperCorner>405659.281000 680891.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405659.281000 680891.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 083 808</ms:GML_ID>
        <ms:NAZWA>026 083 808</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026083808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406149.834000 682174.400000</gml:lowerCorner>
        		<gml:upperCorner>406149.834000 682174.400000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406149.834000 682174.400000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 082 416</ms:GML_ID>
        <ms:NAZWA>026 082 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026082416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406446.489000 690719.208000</gml:lowerCorner>
        		<gml:upperCorner>406446.489000 690719.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406446.489000 690719.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 003 996</ms:GML_ID>
        <ms:NAZWA>082 003 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082003996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406774.410813 682964.580042</gml:lowerCorner>
        		<gml:upperCorner>406774.410813 682964.580042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406774.410813 682964.580042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 081 408</ms:GML_ID>
        <ms:NAZWA>026 081 408</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026081408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407213.560000 690268.206000</gml:lowerCorner>
        		<gml:upperCorner>407213.560000 690268.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407213.560000 690268.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 003 088</ms:GML_ID>
        <ms:NAZWA>082 003 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082003088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407729.288000 689498.726000</gml:lowerCorner>
        		<gml:upperCorner>407729.288000 689498.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407729.288000 689498.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 002 155</ms:GML_ID>
        <ms:NAZWA>082 002 155</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082002155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407954.345000 689222.525000</gml:lowerCorner>
        		<gml:upperCorner>407954.345000 689222.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407954.345000 689222.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 001 800</ms:GML_ID>
        <ms:NAZWA>082 001 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082001800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408395.637693 651127.607976</gml:lowerCorner>
        		<gml:upperCorner>408395.637693 651127.607976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408395.637693 651127.607976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 086 965</ms:GML_ID>
        <ms:NAZWA>008 086 965</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008086965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408667.253919 688345.148097</gml:lowerCorner>
        		<gml:upperCorner>408667.253919 688345.148097</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408667.253919 688345.148097</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.578 001 053</ms:GML_ID>
        <ms:NAZWA>578 001 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>578001053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408734.317000 688434.336000</gml:lowerCorner>
        		<gml:upperCorner>408734.317000 688434.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408734.317000 688434.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 000 662</ms:GML_ID>
        <ms:NAZWA>082 000 662</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082000662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408845.157000 688275.002000</gml:lowerCorner>
        		<gml:upperCorner>408845.157000 688275.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408845.157000 688275.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 075 648</ms:GML_ID>
        <ms:NAZWA>026 075 648</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026075648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408965.158000 688191.177000</gml:lowerCorner>
        		<gml:upperCorner>408965.158000 688191.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408965.158000 688191.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.076 000 751</ms:GML_ID>
        <ms:NAZWA>076 000 751</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>076000751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409871.948000 690334.305000</gml:lowerCorner>
        		<gml:upperCorner>409871.948000 690334.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409871.948000 690334.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 073 346</ms:GML_ID>
        <ms:NAZWA>026 073 346</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026073346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410763.476890 650934.207546</gml:lowerCorner>
        		<gml:upperCorner>410763.476890 650934.207546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410763.476890 650934.207546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 084 581</ms:GML_ID>
        <ms:NAZWA>008 084 581</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008084581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>411061.219000 684286.574000</gml:lowerCorner>
        		<gml:upperCorner>411061.219000 684286.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>411061.219000 684286.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.076 005 238</ms:GML_ID>
        <ms:NAZWA>076 005 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>076005238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412290.997000 682408.740000</gml:lowerCorner>
        		<gml:upperCorner>412290.997000 682408.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412290.997000 682408.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.076 007 493</ms:GML_ID>
        <ms:NAZWA>076 007 493</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>076007493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412829.555822 650931.277755</gml:lowerCorner>
        		<gml:upperCorner>412829.555822 650931.277755</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412829.555822 650931.277755</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 082 514</ms:GML_ID>
        <ms:NAZWA>008 082 514</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008082514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413177.534000 681322.766000</gml:lowerCorner>
        		<gml:upperCorner>413177.534000 681322.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413177.534000 681322.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.076 008 895</ms:GML_ID>
        <ms:NAZWA>076 008 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>076008895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414013.091000 680265.000000</gml:lowerCorner>
        		<gml:upperCorner>414013.091000 680265.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414013.091000 680265.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.076 010 245</ms:GML_ID>
        <ms:NAZWA>076 010 245</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>076010245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414348.699000 678162.999000</gml:lowerCorner>
        		<gml:upperCorner>414348.699000 678162.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414348.699000 678162.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 001 119</ms:GML_ID>
        <ms:NAZWA>077 001 119</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077001119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414578.270000 677237.216000</gml:lowerCorner>
        		<gml:upperCorner>414578.270000 677237.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414578.270000 677237.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 002 080</ms:GML_ID>
        <ms:NAZWA>077 002 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077002080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414720.730035 650928.543664</gml:lowerCorner>
        		<gml:upperCorner>414720.730035 650928.543664</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414720.730035 650928.543664</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 080 622</ms:GML_ID>
        <ms:NAZWA>008 080 622</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008080622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415113.647603 676212.370049</gml:lowerCorner>
        		<gml:upperCorner>415113.647603 676212.370049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415113.647603 676212.370049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 003 238</ms:GML_ID>
        <ms:NAZWA>077 003 238</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077003238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415572.704000 675334.635000</gml:lowerCorner>
        		<gml:upperCorner>415572.704000 675334.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415572.704000 675334.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 004 226</ms:GML_ID>
        <ms:NAZWA>077 004 226</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077004226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274198.670926 647692.956680</gml:lowerCorner>
        		<gml:upperCorner>274198.670926 647692.956680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274198.670926 647692.956680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 048 593</ms:GML_ID>
        <ms:NAZWA>115 048 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115048593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297668.712000 650107.419000</gml:lowerCorner>
        		<gml:upperCorner>297668.712000 650107.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297668.712000 650107.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 045 150</ms:GML_ID>
        <ms:NAZWA>070 045 150</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070045150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298414.870000 650967.420000</gml:lowerCorner>
        		<gml:upperCorner>298414.870000 650967.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298414.870000 650967.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 046 404</ms:GML_ID>
        <ms:NAZWA>070 046 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070046404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300245.909000 656295.703000</gml:lowerCorner>
        		<gml:upperCorner>300245.909000 656295.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300245.909000 656295.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 001 501</ms:GML_ID>
        <ms:NAZWA>075 001 501</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075001501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298988.785000 656567.076000</gml:lowerCorner>
        		<gml:upperCorner>298988.785000 656567.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298988.785000 656567.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 002 841</ms:GML_ID>
        <ms:NAZWA>075 002 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075002841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298119.070000 656633.330000</gml:lowerCorner>
        		<gml:upperCorner>298119.070000 656633.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298119.070000 656633.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 003 726</ms:GML_ID>
        <ms:NAZWA>075 003 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075003726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297712.164000 656776.580000</gml:lowerCorner>
        		<gml:upperCorner>297712.164000 656776.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297712.164000 656776.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 004 158</ms:GML_ID>
        <ms:NAZWA>075 004 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075004158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297217.273000 656951.327000</gml:lowerCorner>
        		<gml:upperCorner>297217.273000 656951.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297217.273000 656951.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 004 683</ms:GML_ID>
        <ms:NAZWA>075 004 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075004683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299948.973000 657390.819000</gml:lowerCorner>
        		<gml:upperCorner>299948.973000 657390.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299948.973000 657390.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 054 215</ms:GML_ID>
        <ms:NAZWA>070 054 215</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070054215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295222.547000 657843.246000</gml:lowerCorner>
        		<gml:upperCorner>295222.547000 657843.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295222.547000 657843.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 006 890</ms:GML_ID>
        <ms:NAZWA>075 006 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075006890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294988.637000 658144.141000</gml:lowerCorner>
        		<gml:upperCorner>294988.637000 658144.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294988.637000 658144.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 007 271</ms:GML_ID>
        <ms:NAZWA>075 007 271</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075007271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294708.000000 658531.108000</gml:lowerCorner>
        		<gml:upperCorner>294708.000000 658531.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294708.000000 658531.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 007 750</ms:GML_ID>
        <ms:NAZWA>075 007 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075007750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299180.237000 659402.751000</gml:lowerCorner>
        		<gml:upperCorner>299180.237000 659402.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299180.237000 659402.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 056 375</ms:GML_ID>
        <ms:NAZWA>070 056 375</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070056375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294017.722000 659483.958000</gml:lowerCorner>
        		<gml:upperCorner>294017.722000 659483.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294017.722000 659483.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 008 927</ms:GML_ID>
        <ms:NAZWA>075 008 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075008927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293535.278000 660127.147000</gml:lowerCorner>
        		<gml:upperCorner>293535.278000 660127.147000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293535.278000 660127.147000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 009 732</ms:GML_ID>
        <ms:NAZWA>075 009 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075009732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292398.135000 660956.198000</gml:lowerCorner>
        		<gml:upperCorner>292398.135000 660956.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292398.135000 660956.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 011 142</ms:GML_ID>
        <ms:NAZWA>075 011 142</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075011142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298979.466000 660979.434000</gml:lowerCorner>
        		<gml:upperCorner>298979.466000 660979.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298979.466000 660979.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 057 983</ms:GML_ID>
        <ms:NAZWA>070 057 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070057983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292100.126000 661163.570000</gml:lowerCorner>
        		<gml:upperCorner>292100.126000 661163.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292100.126000 661163.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 011 505</ms:GML_ID>
        <ms:NAZWA>075 011 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075011505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291398.765000 661589.009000</gml:lowerCorner>
        		<gml:upperCorner>291398.765000 661589.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291398.765000 661589.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 012 328</ms:GML_ID>
        <ms:NAZWA>075 012 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075012328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290725.219000 661851.467000</gml:lowerCorner>
        		<gml:upperCorner>290725.219000 661851.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290725.219000 661851.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 013 051</ms:GML_ID>
        <ms:NAZWA>075 013 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075013051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298945.941000 662134.213000</gml:lowerCorner>
        		<gml:upperCorner>298945.941000 662134.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298945.941000 662134.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 059 138</ms:GML_ID>
        <ms:NAZWA>070 059 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070059138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289447.290000 662399.779000</gml:lowerCorner>
        		<gml:upperCorner>289447.290000 662399.779000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289447.290000 662399.779000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 014 446</ms:GML_ID>
        <ms:NAZWA>075 014 446</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075014446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288812.869730 662898.053760</gml:lowerCorner>
        		<gml:upperCorner>288812.869730 662898.053760</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288812.869730 662898.053760</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 015 253</ms:GML_ID>
        <ms:NAZWA>075 015 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075015253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288538.347293 663190.337573</gml:lowerCorner>
        		<gml:upperCorner>288538.347293 663190.337573</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288538.347293 663190.337573</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 015 659</ms:GML_ID>
        <ms:NAZWA>075 015 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075015659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298525.134000 663593.337000</gml:lowerCorner>
        		<gml:upperCorner>298525.134000 663593.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298525.134000 663593.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 060 666</ms:GML_ID>
        <ms:NAZWA>070 060 666</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070060666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288064.758850 664575.353642</gml:lowerCorner>
        		<gml:upperCorner>288064.758850 664575.353642</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288064.758850 664575.353642</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 017 120</ms:GML_ID>
        <ms:NAZWA>075 017 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075017120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298103.832000 665097.048000</gml:lowerCorner>
        		<gml:upperCorner>298103.832000 665097.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298103.832000 665097.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 062 256</ms:GML_ID>
        <ms:NAZWA>070 062 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070062256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297531.051000 668375.382000</gml:lowerCorner>
        		<gml:upperCorner>297531.051000 668375.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297531.051000 668375.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 065 681</ms:GML_ID>
        <ms:NAZWA>070 065 681</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070065681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298794.777000 672938.063000</gml:lowerCorner>
        		<gml:upperCorner>298794.777000 672938.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298794.777000 672938.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 070 515</ms:GML_ID>
        <ms:NAZWA>070 070 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070070515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416409.098504 650904.659827</gml:lowerCorner>
        		<gml:upperCorner>416409.098504 650904.659827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416409.098504 650904.659827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 078 930</ms:GML_ID>
        <ms:NAZWA>008 078 930</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008078930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418667.541237 672254.697357</gml:lowerCorner>
        		<gml:upperCorner>418667.541237 672254.697357</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418667.541237 672254.697357</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 008 700</ms:GML_ID>
        <ms:NAZWA>077 008 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077008700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418681.631618 650741.573690</gml:lowerCorner>
        		<gml:upperCorner>418681.631618 650741.573690</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418681.631618 650741.573690</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 076 653</ms:GML_ID>
        <ms:NAZWA>008 076 653</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008076653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419930.711681 693563.465478</gml:lowerCorner>
        		<gml:upperCorner>419930.711681 693563.465478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419930.711681 693563.465478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 097 957</ms:GML_ID>
        <ms:NAZWA>007 097 957</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007097957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420099.395044 650633.984041</gml:lowerCorner>
        		<gml:upperCorner>420099.395044 650633.984041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420099.395044 650633.984041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 075 232</ms:GML_ID>
        <ms:NAZWA>008 075 232</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008075232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420540.383000 671293.989000</gml:lowerCorner>
        		<gml:upperCorner>420540.383000 671293.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420540.383000 671293.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 010 815</ms:GML_ID>
        <ms:NAZWA>077 010 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077010815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421318.924528 692651.240227</gml:lowerCorner>
        		<gml:upperCorner>421318.924528 692651.240227</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421318.924528 692651.240227</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 096 238</ms:GML_ID>
        <ms:NAZWA>007 096 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007096238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421826.455555 650413.108072</gml:lowerCorner>
        		<gml:upperCorner>421826.455555 650413.108072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421826.455555 650413.108072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 073 488</ms:GML_ID>
        <ms:NAZWA>008 073 488</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008073488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422865.816374 669713.037486</gml:lowerCorner>
        		<gml:upperCorner>422865.816374 669713.037486</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422865.816374 669713.037486</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.077 013 627</ms:GML_ID>
        <ms:NAZWA>077 013 627</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>077013627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426558.571832 689907.647863</gml:lowerCorner>
        		<gml:upperCorner>426558.571832 689907.647863</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426558.571832 689907.647863</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 090 028</ms:GML_ID>
        <ms:NAZWA>007 090 028</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007090028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426888.722773 650132.401619</gml:lowerCorner>
        		<gml:upperCorner>426888.722773 650132.401619</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426888.722773 650132.401619</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 068 375</ms:GML_ID>
        <ms:NAZWA>008 068 375</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008068375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428941.026155 650146.920888</gml:lowerCorner>
        		<gml:upperCorner>428941.026155 650146.920888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428941.026155 650146.920888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 066 319</ms:GML_ID>
        <ms:NAZWA>008 066 319</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008066319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430798.214152 686830.986971</gml:lowerCorner>
        		<gml:upperCorner>430798.214152 686830.986971</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430798.214152 686830.986971</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 084 701</ms:GML_ID>
        <ms:NAZWA>007 084 701</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007084701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431190.777564 686331.312531</gml:lowerCorner>
        		<gml:upperCorner>431190.777564 686331.312531</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431190.777564 686331.312531</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 084 064</ms:GML_ID>
        <ms:NAZWA>007 084 064</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007084064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431417.915906 650436.149867</gml:lowerCorner>
        		<gml:upperCorner>431417.915906 650436.149867</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431417.915906 650436.149867</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 063 825</ms:GML_ID>
        <ms:NAZWA>008 063 825</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008063825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431885.952437 650490.811222</gml:lowerCorner>
        		<gml:upperCorner>431885.952437 650490.811222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431885.952437 650490.811222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 063 352</ms:GML_ID>
        <ms:NAZWA>008 063 352</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008063352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435564.095898 682602.709013</gml:lowerCorner>
        		<gml:upperCorner>435564.095898 682602.709013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435564.095898 682602.709013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 078 187</ms:GML_ID>
        <ms:NAZWA>007 078 187</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007078187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435832.387855 650704.540842</gml:lowerCorner>
        		<gml:upperCorner>435832.387855 650704.540842</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435832.387855 650704.540842</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 059 358</ms:GML_ID>
        <ms:NAZWA>008 059 358</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008059358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436791.100000 681527.328000</gml:lowerCorner>
        		<gml:upperCorner>436791.100000 681527.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436791.100000 681527.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 076 553</ms:GML_ID>
        <ms:NAZWA>007 076 553</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007076553</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438662.107253 680349.039116</gml:lowerCorner>
        		<gml:upperCorner>438662.107253 680349.039116</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438662.107253 680349.039116</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 074 325</ms:GML_ID>
        <ms:NAZWA>007 074 325</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007074325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439621.969000 648653.307000</gml:lowerCorner>
        		<gml:upperCorner>439621.969000 648653.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439621.969000 648653.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 054 959</ms:GML_ID>
        <ms:NAZWA>008 054 959</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008054959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439951.111720 679839.597071</gml:lowerCorner>
        		<gml:upperCorner>439951.111720 679839.597071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439951.111720 679839.597071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 072 936</ms:GML_ID>
        <ms:NAZWA>007 072 936</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007072936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441051.609911 647444.877420</gml:lowerCorner>
        		<gml:upperCorner>441051.609911 647444.877420</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441051.609911 647444.877420</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 053 087</ms:GML_ID>
        <ms:NAZWA>008 053 087</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008053087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442727.915231 679193.183482</gml:lowerCorner>
        		<gml:upperCorner>442727.915231 679193.183482</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442727.915231 679193.183482</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 070 086</ms:GML_ID>
        <ms:NAZWA>007 070 086</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007070086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444237.785000 678834.851000</gml:lowerCorner>
        		<gml:upperCorner>444237.785000 678834.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444237.785000 678834.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 068 533</ms:GML_ID>
        <ms:NAZWA>007 068 533</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007068533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446116.953000 678302.298000</gml:lowerCorner>
        		<gml:upperCorner>446116.953000 678302.298000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446116.953000 678302.298000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 066 572</ms:GML_ID>
        <ms:NAZWA>007 066 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007066572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446981.023027 677693.674543</gml:lowerCorner>
        		<gml:upperCorner>446981.023027 677693.674543</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446981.023027 677693.674543</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 065 512</ms:GML_ID>
        <ms:NAZWA>007 065 512</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007065512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450000.468158 676731.533006</gml:lowerCorner>
        		<gml:upperCorner>450000.468158 676731.533006</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450000.468158 676731.533006</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 062 289</ms:GML_ID>
        <ms:NAZWA>007 062 289</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007062289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452967.138000 675287.149000</gml:lowerCorner>
        		<gml:upperCorner>452967.138000 675287.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452967.138000 675287.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 058 886</ms:GML_ID>
        <ms:NAZWA>007 058 886</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007058886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456331.530000 678522.748000</gml:lowerCorner>
        		<gml:upperCorner>456331.530000 678522.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456331.530000 678522.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 104 689</ms:GML_ID>
        <ms:NAZWA>012 104 689</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012104689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456415.177000 679756.897000</gml:lowerCorner>
        		<gml:upperCorner>456415.177000 679756.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456415.177000 679756.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 105 927</ms:GML_ID>
        <ms:NAZWA>012 105 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012105927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456692.549000 680883.413000</gml:lowerCorner>
        		<gml:upperCorner>456692.549000 680883.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456692.549000 680883.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 107 095</ms:GML_ID>
        <ms:NAZWA>012 107 095</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012107095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457098.201000 681732.846000</gml:lowerCorner>
        		<gml:upperCorner>457098.201000 681732.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457098.201000 681732.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 108 035</ms:GML_ID>
        <ms:NAZWA>012 108 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012108035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350689.715000 658037.582000</gml:lowerCorner>
        		<gml:upperCorner>350689.715000 658037.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350689.715000 658037.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 177 191</ms:GML_ID>
        <ms:NAZWA>025 177 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025177191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351408.004000 657126.755000</gml:lowerCorner>
        		<gml:upperCorner>351408.004000 657126.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351408.004000 657126.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 176 030</ms:GML_ID>
        <ms:NAZWA>025 176 030</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025176030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351648.410000 649901.657000</gml:lowerCorner>
        		<gml:upperCorner>351648.410000 649901.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351648.410000 649901.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 167 922</ms:GML_ID>
        <ms:NAZWA>025 167 922</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025167922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351935.626000 647737.010000</gml:lowerCorner>
        		<gml:upperCorner>351935.626000 647737.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351935.626000 647737.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 165 710</ms:GML_ID>
        <ms:NAZWA>025 165 710</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025165710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352261.174000 652949.385000</gml:lowerCorner>
        		<gml:upperCorner>352261.174000 652949.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352261.174000 652949.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 171 177</ms:GML_ID>
        <ms:NAZWA>025 171 177</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025171177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352841.662367 654381.013032</gml:lowerCorner>
        		<gml:upperCorner>352841.662367 654381.013032</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352841.662367 654381.013032</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 172 761</ms:GML_ID>
        <ms:NAZWA>025 172 761</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025172761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354418.230000 646053.846000</gml:lowerCorner>
        		<gml:upperCorner>354418.230000 646053.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354418.230000 646053.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 162 231</ms:GML_ID>
        <ms:NAZWA>025 162 231</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025162231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355327.226066 645049.679096</gml:lowerCorner>
        		<gml:upperCorner>355327.226066 645049.679096</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355327.226066 645049.679096</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 160 854</ms:GML_ID>
        <ms:NAZWA>025 160 854</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025160854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355730.105000 644389.600000</gml:lowerCorner>
        		<gml:upperCorner>355730.105000 644389.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355730.105000 644389.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 160 084</ms:GML_ID>
        <ms:NAZWA>025 160 084</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025160084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388326.555000 643867.192000</gml:lowerCorner>
        		<gml:upperCorner>388326.555000 643867.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388326.555000 643867.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 112 364</ms:GML_ID>
        <ms:NAZWA>008 112 364</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008112364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388691.873000 643778.734000</gml:lowerCorner>
        		<gml:upperCorner>388691.873000 643778.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388691.873000 643778.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 080 099</ms:GML_ID>
        <ms:NAZWA>022 080 099</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022080099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388740.606000 645180.860000</gml:lowerCorner>
        		<gml:upperCorner>388740.606000 645180.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388740.606000 645180.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 110 985</ms:GML_ID>
        <ms:NAZWA>008 110 985</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008110985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389078.477000 646272.544000</gml:lowerCorner>
        		<gml:upperCorner>389078.477000 646272.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389078.477000 646272.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 109 842</ms:GML_ID>
        <ms:NAZWA>008 109 842</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008109842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389221.438751 645507.811785</gml:lowerCorner>
        		<gml:upperCorner>389221.438751 645507.811785</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389221.438751 645507.811785</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 081 907</ms:GML_ID>
        <ms:NAZWA>022 081 907</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022081907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389255.825000 647161.608000</gml:lowerCorner>
        		<gml:upperCorner>389255.825000 647161.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389255.825000 647161.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 108 931</ms:GML_ID>
        <ms:NAZWA>008 108 931</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008108931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389743.113000 648228.420000</gml:lowerCorner>
        		<gml:upperCorner>389743.113000 648228.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389743.113000 648228.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 107 758</ms:GML_ID>
        <ms:NAZWA>008 107 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008107758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390139.303000 648286.345000</gml:lowerCorner>
        		<gml:upperCorner>390139.303000 648286.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390139.303000 648286.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 084 838</ms:GML_ID>
        <ms:NAZWA>022 084 838</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022084838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392274.799000 648681.882000</gml:lowerCorner>
        		<gml:upperCorner>392274.799000 648681.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392274.799000 648681.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 104 988</ms:GML_ID>
        <ms:NAZWA>008 104 988</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008104988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255727.962078 640078.764233</gml:lowerCorner>
        		<gml:upperCorner>255727.962078 640078.764233</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255727.962078 640078.764233</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 021 798</ms:GML_ID>
        <ms:NAZWA>115 021 798</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115021798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255892.971000 640291.089000</gml:lowerCorner>
        		<gml:upperCorner>255892.971000 640291.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255892.971000 640291.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 022 069</ms:GML_ID>
        <ms:NAZWA>115 022 069</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115022069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256085.483821 640488.900547</gml:lowerCorner>
        		<gml:upperCorner>256085.483821 640488.900547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256085.483821 640488.900547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 022 346</ms:GML_ID>
        <ms:NAZWA>115 022 346</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115022346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256415.543000 640827.747000</gml:lowerCorner>
        		<gml:upperCorner>256415.543000 640827.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256415.543000 640827.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 022 819</ms:GML_ID>
        <ms:NAZWA>115 022 819</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115022819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256559.504000 640975.838000</gml:lowerCorner>
        		<gml:upperCorner>256559.504000 640975.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256559.504000 640975.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 023 025</ms:GML_ID>
        <ms:NAZWA>115 023 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115023025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256719.842000 641141.041000</gml:lowerCorner>
        		<gml:upperCorner>256719.842000 641141.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256719.842000 641141.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 023 255</ms:GML_ID>
        <ms:NAZWA>115 023 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115023255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256983.740148 641412.132786</gml:lowerCorner>
        		<gml:upperCorner>256983.740148 641412.132786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256983.740148 641412.132786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 023 635</ms:GML_ID>
        <ms:NAZWA>115 023 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115023635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257171.564000 641551.943000</gml:lowerCorner>
        		<gml:upperCorner>257171.564000 641551.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257171.564000 641551.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 023 870</ms:GML_ID>
        <ms:NAZWA>115 023 870</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115023870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257453.807044 641532.844510</gml:lowerCorner>
        		<gml:upperCorner>257453.807044 641532.844510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257453.807044 641532.844510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 024 158</ms:GML_ID>
        <ms:NAZWA>115 024 158</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115024158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257715.895266 640657.623508</gml:lowerCorner>
        		<gml:upperCorner>257715.895266 640657.623508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257715.895266 640657.623508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 025 149</ms:GML_ID>
        <ms:NAZWA>115 025 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115025149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258109.991714 640162.929527</gml:lowerCorner>
        		<gml:upperCorner>258109.991714 640162.929527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258109.991714 640162.929527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 025 807</ms:GML_ID>
        <ms:NAZWA>115 025 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115025807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258751.977000 639701.398000</gml:lowerCorner>
        		<gml:upperCorner>258751.977000 639701.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258751.977000 639701.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 026 599</ms:GML_ID>
        <ms:NAZWA>115 026 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115026599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259063.794000 639477.000000</gml:lowerCorner>
        		<gml:upperCorner>259063.794000 639477.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259063.794000 639477.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 026 983</ms:GML_ID>
        <ms:NAZWA>115 026 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115026983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267337.462000 639106.317000</gml:lowerCorner>
        		<gml:upperCorner>267337.462000 639106.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267337.462000 639106.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 036 166</ms:GML_ID>
        <ms:NAZWA>115 036 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115036166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269985.994000 639211.990000</gml:lowerCorner>
        		<gml:upperCorner>269985.994000 639211.990000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269985.994000 639211.990000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 038 848</ms:GML_ID>
        <ms:NAZWA>115 038 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115038848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270143.012000 639381.048000</gml:lowerCorner>
        		<gml:upperCorner>270143.012000 639381.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270143.012000 639381.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 039 080</ms:GML_ID>
        <ms:NAZWA>115 039 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115039080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270253.964000 639639.399000</gml:lowerCorner>
        		<gml:upperCorner>270253.964000 639639.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270253.964000 639639.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 039 362</ms:GML_ID>
        <ms:NAZWA>115 039 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115039362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270382.928000 640016.247000</gml:lowerCorner>
        		<gml:upperCorner>270382.928000 640016.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270382.928000 640016.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 039 760</ms:GML_ID>
        <ms:NAZWA>115 039 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115039760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270455.018000 640224.283000</gml:lowerCorner>
        		<gml:upperCorner>270455.018000 640224.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270455.018000 640224.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 039 981</ms:GML_ID>
        <ms:NAZWA>115 039 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115039981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270563.585000 640541.075000</gml:lowerCorner>
        		<gml:upperCorner>270563.585000 640541.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270563.585000 640541.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 040 316</ms:GML_ID>
        <ms:NAZWA>115 040 316</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115040316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270692.004000 640916.315000</gml:lowerCorner>
        		<gml:upperCorner>270692.004000 640916.315000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270692.004000 640916.315000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 040 712</ms:GML_ID>
        <ms:NAZWA>115 040 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115040712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270772.798000 641151.822000</gml:lowerCorner>
        		<gml:upperCorner>270772.798000 641151.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270772.798000 641151.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 040 962</ms:GML_ID>
        <ms:NAZWA>115 040 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115040962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270838.710000 641344.266000</gml:lowerCorner>
        		<gml:upperCorner>270838.710000 641344.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270838.710000 641344.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 041 164</ms:GML_ID>
        <ms:NAZWA>115 041 164</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115041164</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270904.157030 641536.719704</gml:lowerCorner>
        		<gml:upperCorner>270904.157030 641536.719704</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270904.157030 641536.719704</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 041 368</ms:GML_ID>
        <ms:NAZWA>115 041 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115041368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271544.232000 643401.052000</gml:lowerCorner>
        		<gml:upperCorner>271544.232000 643401.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271544.232000 643401.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 043 340</ms:GML_ID>
        <ms:NAZWA>115 043 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115043340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271632.872000 643655.657000</gml:lowerCorner>
        		<gml:upperCorner>271632.872000 643655.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271632.872000 643655.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 043 610</ms:GML_ID>
        <ms:NAZWA>115 043 610</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115043610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271754.916000 644015.110000</gml:lowerCorner>
        		<gml:upperCorner>271754.916000 644015.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271754.916000 644015.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 043 989</ms:GML_ID>
        <ms:NAZWA>115 043 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115043989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271812.876000 644183.481000</gml:lowerCorner>
        		<gml:upperCorner>271812.876000 644183.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271812.876000 644183.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 044 168</ms:GML_ID>
        <ms:NAZWA>115 044 168</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115044168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271902.121000 644442.521000</gml:lowerCorner>
        		<gml:upperCorner>271902.121000 644442.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271902.121000 644442.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 044 441</ms:GML_ID>
        <ms:NAZWA>115 044 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115044441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457143.001000 637777.156000</gml:lowerCorner>
        		<gml:upperCorner>457143.001000 637777.156000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457143.001000 637777.156000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 060 209</ms:GML_ID>
        <ms:NAZWA>012 060 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012060209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457154.635000 638719.687000</gml:lowerCorner>
        		<gml:upperCorner>457154.635000 638719.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457154.635000 638719.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 061 153</ms:GML_ID>
        <ms:NAZWA>012 061 153</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012061153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457170.276000 639960.842000</gml:lowerCorner>
        		<gml:upperCorner>457170.276000 639960.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457170.276000 639960.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 062 394</ms:GML_ID>
        <ms:NAZWA>012 062 394</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012062394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457528.387000 641255.381000</gml:lowerCorner>
        		<gml:upperCorner>457528.387000 641255.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457528.387000 641255.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 063 742</ms:GML_ID>
        <ms:NAZWA>012 063 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012063742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460338.977000 641636.440000</gml:lowerCorner>
        		<gml:upperCorner>460338.977000 641636.440000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460338.977000 641636.440000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 032 823</ms:GML_ID>
        <ms:NAZWA>008 032 823</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008032823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457749.575000 641943.932000</gml:lowerCorner>
        		<gml:upperCorner>457749.575000 641943.932000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457749.575000 641943.932000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 064 466</ms:GML_ID>
        <ms:NAZWA>012 064 466</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012064466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459232.629640 642092.124053</gml:lowerCorner>
        		<gml:upperCorner>459232.629640 642092.124053</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459232.629640 642092.124053</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 034 019</ms:GML_ID>
        <ms:NAZWA>008 034 019</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008034019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457758.772000 642464.143000</gml:lowerCorner>
        		<gml:upperCorner>457758.772000 642464.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457758.772000 642464.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.528 000 464</ms:GML_ID>
        <ms:NAZWA>528 000 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>528000464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457958.303464 642671.061485</gml:lowerCorner>
        		<gml:upperCorner>457958.303464 642671.061485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457958.303464 642671.061485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 065 217</ms:GML_ID>
        <ms:NAZWA>012 065 217</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012065217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456015.095000 643150.112000</gml:lowerCorner>
        		<gml:upperCorner>456015.095000 643150.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456015.095000 643150.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 037 416</ms:GML_ID>
        <ms:NAZWA>008 037 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>008037416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454629.497779 643488.114888</gml:lowerCorner>
        		<gml:upperCorner>454629.497779 643488.114888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454629.497779 643488.114888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 038 844</ms:GML_ID>
        <ms:NAZWA>008 038 844</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008038844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453254.433052 643822.344879</gml:lowerCorner>
        		<gml:upperCorner>453254.433052 643822.344879</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453254.433052 643822.344879</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 040 260</ms:GML_ID>
        <ms:NAZWA>008 040 260</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008040260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450934.322179 644384.867034</gml:lowerCorner>
        		<gml:upperCorner>450934.322179 644384.867034</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450934.322179 644384.867034</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 042 647</ms:GML_ID>
        <ms:NAZWA>008 042 647</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008042647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449919.728436 644631.626831</gml:lowerCorner>
        		<gml:upperCorner>449919.728436 644631.626831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449919.728436 644631.626831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 043 692</ms:GML_ID>
        <ms:NAZWA>008 043 692</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008043692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448737.890087 644920.418995</gml:lowerCorner>
        		<gml:upperCorner>448737.890087 644920.418995</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448737.890087 644920.418995</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 044 909</ms:GML_ID>
        <ms:NAZWA>008 044 909</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008044909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446830.748907 645383.309963</gml:lowerCorner>
        		<gml:upperCorner>446830.748907 645383.309963</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446830.748907 645383.309963</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 046 873</ms:GML_ID>
        <ms:NAZWA>008 046 873</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008046873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445875.567477 645615.605084</gml:lowerCorner>
        		<gml:upperCorner>445875.567477 645615.605084</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445875.567477 645615.605084</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 047 855</ms:GML_ID>
        <ms:NAZWA>008 047 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008047855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443783.919544 646122.853401</gml:lowerCorner>
        		<gml:upperCorner>443783.919544 646122.853401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443783.919544 646122.853401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 050 010</ms:GML_ID>
        <ms:NAZWA>008 050 010</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008050010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442916.477050 646333.744384</gml:lowerCorner>
        		<gml:upperCorner>442916.477050 646333.744384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442916.477050 646333.744384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 050 901</ms:GML_ID>
        <ms:NAZWA>008 050 901</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008050901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272042.562000 644852.178000</gml:lowerCorner>
        		<gml:upperCorner>272042.562000 644852.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272042.562000 644852.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 044 875</ms:GML_ID>
        <ms:NAZWA>115 044 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115044875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272202.744000 645317.548000</gml:lowerCorner>
        		<gml:upperCorner>272202.744000 645317.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272202.744000 645317.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 045 368</ms:GML_ID>
        <ms:NAZWA>115 045 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115045368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272288.484000 645567.004000</gml:lowerCorner>
        		<gml:upperCorner>272288.484000 645567.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272288.484000 645567.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 045 631</ms:GML_ID>
        <ms:NAZWA>115 045 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115045631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272470.306000 646004.784000</gml:lowerCorner>
        		<gml:upperCorner>272470.306000 646004.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272470.306000 646004.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 046 105</ms:GML_ID>
        <ms:NAZWA>115 046 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115046105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272785.842000 646386.485000</gml:lowerCorner>
        		<gml:upperCorner>272785.842000 646386.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272785.842000 646386.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 046 602</ms:GML_ID>
        <ms:NAZWA>115 046 602</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115046602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272882.370000 646498.055000</gml:lowerCorner>
        		<gml:upperCorner>272882.370000 646498.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272882.370000 646498.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 046 750</ms:GML_ID>
        <ms:NAZWA>115 046 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115046750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273143.763000 646803.394000</gml:lowerCorner>
        		<gml:upperCorner>273143.763000 646803.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273143.763000 646803.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 047 153</ms:GML_ID>
        <ms:NAZWA>115 047 153</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115047153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273323.953000 647013.084000</gml:lowerCorner>
        		<gml:upperCorner>273323.953000 647013.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273323.953000 647013.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 047 432</ms:GML_ID>
        <ms:NAZWA>115 047 432</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115047432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273549.313000 647275.320000</gml:lowerCorner>
        		<gml:upperCorner>273549.313000 647275.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273549.313000 647275.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 047 776</ms:GML_ID>
        <ms:NAZWA>115 047 776</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115047776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273802.450000 647570.487000</gml:lowerCorner>
        		<gml:upperCorner>273802.450000 647570.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273802.450000 647570.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.115 048 163</ms:GML_ID>
        <ms:NAZWA>115 048 163</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>115048163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293186.089000 660407.875000</gml:lowerCorner>
        		<gml:upperCorner>293186.089000 660407.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293186.089000 660407.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.075 010 181</ms:GML_ID>
        <ms:NAZWA>075 010 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>075010181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297203.701000 646764.627000</gml:lowerCorner>
        		<gml:upperCorner>297203.701000 646764.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297203.701000 646764.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 041 428</ms:GML_ID>
        <ms:NAZWA>070 041 428</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070041428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297723.479000 639651.292000</gml:lowerCorner>
        		<gml:upperCorner>297723.479000 639651.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297723.479000 639651.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 033 854</ms:GML_ID>
        <ms:NAZWA>070 033 854</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070033854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297947.727000 641199.183000</gml:lowerCorner>
        		<gml:upperCorner>297947.727000 641199.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297947.727000 641199.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 035 512</ms:GML_ID>
        <ms:NAZWA>070 035 512</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070035512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298177.442000 643514.293000</gml:lowerCorner>
        		<gml:upperCorner>298177.442000 643514.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298177.442000 643514.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 037 918</ms:GML_ID>
        <ms:NAZWA>070 037 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070037918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298196.734000 638704.640000</gml:lowerCorner>
        		<gml:upperCorner>298196.734000 638704.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298196.734000 638704.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 032 786</ms:GML_ID>
        <ms:NAZWA>070 032 786</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070032786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298272.975000 642851.961000</gml:lowerCorner>
        		<gml:upperCorner>298272.975000 642851.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298272.975000 642851.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 037 251</ms:GML_ID>
        <ms:NAZWA>070 037 251</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070037251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298337.883000 642397.482000</gml:lowerCorner>
        		<gml:upperCorner>298337.883000 642397.482000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298337.883000 642397.482000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 036 793</ms:GML_ID>
        <ms:NAZWA>070 036 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070036793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299073.878000 636743.024000</gml:lowerCorner>
        		<gml:upperCorner>299073.878000 636743.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299073.878000 636743.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 030 460</ms:GML_ID>
        <ms:NAZWA>070 030 460</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070030460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299917.429000 636128.703000</gml:lowerCorner>
        		<gml:upperCorner>299917.429000 636128.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299917.429000 636128.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 029 387</ms:GML_ID>
        <ms:NAZWA>070 029 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070029387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300739.251000 635529.952000</gml:lowerCorner>
        		<gml:upperCorner>300739.251000 635529.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300739.251000 635529.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 028 365</ms:GML_ID>
        <ms:NAZWA>070 028 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070028365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301448.188000 634618.154000</gml:lowerCorner>
        		<gml:upperCorner>301448.188000 634618.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301448.188000 634618.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 027 185</ms:GML_ID>
        <ms:NAZWA>070 027 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070027185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302062.802000 633700.475000</gml:lowerCorner>
        		<gml:upperCorner>302062.802000 633700.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302062.802000 633700.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 026 085</ms:GML_ID>
        <ms:NAZWA>070 026 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070026085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302559.346000 632936.522000</gml:lowerCorner>
        		<gml:upperCorner>302559.346000 632936.522000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302559.346000 632936.522000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 025 184</ms:GML_ID>
        <ms:NAZWA>070 025 184</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070025184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303181.894000 631974.391000</gml:lowerCorner>
        		<gml:upperCorner>303181.894000 631974.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303181.894000 631974.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 024 029</ms:GML_ID>
        <ms:NAZWA>070 024 029</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070024029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303950.639000 629285.793000</gml:lowerCorner>
        		<gml:upperCorner>303950.639000 629285.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303950.639000 629285.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 021 039</ms:GML_ID>
        <ms:NAZWA>070 021 039</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070021039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304013.168000 630691.366000</gml:lowerCorner>
        		<gml:upperCorner>304013.168000 630691.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304013.168000 630691.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 022 500</ms:GML_ID>
        <ms:NAZWA>070 022 500</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070022500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304249.742000 628516.100000</gml:lowerCorner>
        		<gml:upperCorner>304249.742000 628516.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304249.742000 628516.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 020 191</ms:GML_ID>
        <ms:NAZWA>070 020 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070020191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304825.736000 627683.076000</gml:lowerCorner>
        		<gml:upperCorner>304825.736000 627683.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304825.736000 627683.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 019 176</ms:GML_ID>
        <ms:NAZWA>070 019 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070019176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348455.735762 625551.674165</gml:lowerCorner>
        		<gml:upperCorner>348455.735762 625551.674165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348455.735762 625551.674165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 160 968</ms:GML_ID>
        <ms:NAZWA>008 160 968</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008160968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360652.032000 625559.283000</gml:lowerCorner>
        		<gml:upperCorner>360652.032000 625559.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360652.032000 625559.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 136 765</ms:GML_ID>
        <ms:NAZWA>025 136 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025136765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360453.288000 626354.271000</gml:lowerCorner>
        		<gml:upperCorner>360453.288000 626354.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360453.288000 626354.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 137 587</ms:GML_ID>
        <ms:NAZWA>025 137 587</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025137587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349091.186000 627631.289000</gml:lowerCorner>
        		<gml:upperCorner>349091.186000 627631.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349091.186000 627631.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 158 728</ms:GML_ID>
        <ms:NAZWA>008 158 728</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008158728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360849.375000 628064.114000</gml:lowerCorner>
        		<gml:upperCorner>360849.375000 628064.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360849.375000 628064.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 139 350</ms:GML_ID>
        <ms:NAZWA>025 139 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025139350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352437.924000 628786.148000</gml:lowerCorner>
        		<gml:upperCorner>352437.924000 628786.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352437.924000 628786.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 155 043</ms:GML_ID>
        <ms:NAZWA>008 155 043</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008155043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361530.699000 628909.872000</gml:lowerCorner>
        		<gml:upperCorner>361530.699000 628909.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361530.699000 628909.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 140 464</ms:GML_ID>
        <ms:NAZWA>025 140 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025140464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361705.779000 629286.481000</gml:lowerCorner>
        		<gml:upperCorner>361705.779000 629286.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361705.779000 629286.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 140 882</ms:GML_ID>
        <ms:NAZWA>025 140 882</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025140882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357159.536000 629534.891000</gml:lowerCorner>
        		<gml:upperCorner>357159.536000 629534.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357159.536000 629534.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 149 957</ms:GML_ID>
        <ms:NAZWA>008 149 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008149957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355127.856087 629582.626965</gml:lowerCorner>
        		<gml:upperCorner>355127.856087 629582.626965</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355127.856087 629582.626965</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 152 082</ms:GML_ID>
        <ms:NAZWA>008 152 082</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008152082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361805.057000 629596.109000</gml:lowerCorner>
        		<gml:upperCorner>361805.057000 629596.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361805.057000 629596.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 141 222</ms:GML_ID>
        <ms:NAZWA>025 141 222</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025141222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360402.565000 629810.162000</gml:lowerCorner>
        		<gml:upperCorner>360402.565000 629810.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360402.565000 629810.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 146 464</ms:GML_ID>
        <ms:NAZWA>008 146 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008146464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359647.501000 629924.938000</gml:lowerCorner>
        		<gml:upperCorner>359647.501000 629924.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359647.501000 629924.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 147 270</ms:GML_ID>
        <ms:NAZWA>008 147 270</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008147270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361941.649000 630101.165000</gml:lowerCorner>
        		<gml:upperCorner>361941.649000 630101.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361941.649000 630101.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 141 732</ms:GML_ID>
        <ms:NAZWA>025 141 732</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025141732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363964.943000 632962.864000</gml:lowerCorner>
        		<gml:upperCorner>363964.943000 632962.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363964.943000 632962.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.566 001 380</ms:GML_ID>
        <ms:NAZWA>566 001 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>566001380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363431.727000 633404.940000</gml:lowerCorner>
        		<gml:upperCorner>363431.727000 633404.940000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363431.727000 633404.940000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.566 002 087</ms:GML_ID>
        <ms:NAZWA>566 002 087</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>566002087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363412.074778 633813.852000</gml:lowerCorner>
        		<gml:upperCorner>363412.074778 633813.852000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363412.074778 633813.852000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 145 854</ms:GML_ID>
        <ms:NAZWA>025 145 854</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025145854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363510.880000 634609.774000</gml:lowerCorner>
        		<gml:upperCorner>363510.880000 634609.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363510.880000 634609.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 146 648</ms:GML_ID>
        <ms:NAZWA>025 146 648</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025146648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363216.908000 636307.857000</gml:lowerCorner>
        		<gml:upperCorner>363216.908000 636307.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363216.908000 636307.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 148 429</ms:GML_ID>
        <ms:NAZWA>025 148 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025148429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360367.756000 638607.185000</gml:lowerCorner>
        		<gml:upperCorner>360367.756000 638607.185000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360367.756000 638607.185000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 152 406</ms:GML_ID>
        <ms:NAZWA>025 152 406</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025152406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359391.887000 640664.337000</gml:lowerCorner>
        		<gml:upperCorner>359391.887000 640664.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359391.887000 640664.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 154 725</ms:GML_ID>
        <ms:NAZWA>025 154 725</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025154725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358802.251281 641318.514972</gml:lowerCorner>
        		<gml:upperCorner>358802.251281 641318.514972</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358802.251281 641318.514972</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 155 609</ms:GML_ID>
        <ms:NAZWA>025 155 609</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025155609</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358072.997000 642183.010000</gml:lowerCorner>
        		<gml:upperCorner>358072.997000 642183.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358072.997000 642183.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 156 737</ms:GML_ID>
        <ms:NAZWA>025 156 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025156737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357003.926000 643131.161000</gml:lowerCorner>
        		<gml:upperCorner>357003.926000 643131.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357003.926000 643131.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 158 196</ms:GML_ID>
        <ms:NAZWA>025 158 196</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025158196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366252.862275 632803.793296</gml:lowerCorner>
        		<gml:upperCorner>366252.862275 632803.793296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366252.862275 632803.793296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 139 540</ms:GML_ID>
        <ms:NAZWA>008 139 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008139540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366435.114227 632783.437128</gml:lowerCorner>
        		<gml:upperCorner>366435.114227 632783.437128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366435.114227 632783.437128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 139 354</ms:GML_ID>
        <ms:NAZWA>008 139 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008139354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366993.992000 632888.049000</gml:lowerCorner>
        		<gml:upperCorner>366993.992000 632888.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366993.992000 632888.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 138 787</ms:GML_ID>
        <ms:NAZWA>008 138 787</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008138787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367554.057000 632967.648000</gml:lowerCorner>
        		<gml:upperCorner>367554.057000 632967.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367554.057000 632967.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 138 226</ms:GML_ID>
        <ms:NAZWA>008 138 226</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008138226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370941.374801 633433.134751</gml:lowerCorner>
        		<gml:upperCorner>370941.374801 633433.134751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370941.374801 633433.134751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 134 800</ms:GML_ID>
        <ms:NAZWA>008 134 800</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008134800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372691.544313 634295.145443</gml:lowerCorner>
        		<gml:upperCorner>372691.544313 634295.145443</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372691.544313 634295.145443</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 132 795</ms:GML_ID>
        <ms:NAZWA>008 132 795</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008132795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373560.308461 634326.386000</gml:lowerCorner>
        		<gml:upperCorner>373560.308461 634326.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373560.308461 634326.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 131 925</ms:GML_ID>
        <ms:NAZWA>008 131 925</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008131925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375631.288000 635940.938000</gml:lowerCorner>
        		<gml:upperCorner>375631.288000 635940.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375631.288000 635940.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 128 752</ms:GML_ID>
        <ms:NAZWA>008 128 752</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008128752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376701.889000 636614.398000</gml:lowerCorner>
        		<gml:upperCorner>376701.889000 636614.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376701.889000 636614.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 127 178</ms:GML_ID>
        <ms:NAZWA>008 127 178</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008127178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376830.644000 637261.603000</gml:lowerCorner>
        		<gml:upperCorner>376830.644000 637261.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376830.644000 637261.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 126 513</ms:GML_ID>
        <ms:NAZWA>008 126 513</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008126513</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377336.566000 638006.120000</gml:lowerCorner>
        		<gml:upperCorner>377336.566000 638006.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377336.566000 638006.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 125 607</ms:GML_ID>
        <ms:NAZWA>008 125 607</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008125607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378735.571000 639943.953000</gml:lowerCorner>
        		<gml:upperCorner>378735.571000 639943.953000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378735.571000 639943.953000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 123 217</ms:GML_ID>
        <ms:NAZWA>008 123 217</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008123217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379507.050000 640454.973000</gml:lowerCorner>
        		<gml:upperCorner>379507.050000 640454.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379507.050000 640454.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 122 286</ms:GML_ID>
        <ms:NAZWA>008 122 286</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008122286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380267.056000 640923.456000</gml:lowerCorner>
        		<gml:upperCorner>380267.056000 640923.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380267.056000 640923.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 121 396</ms:GML_ID>
        <ms:NAZWA>008 121 396</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008121396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382523.979000 642185.311000</gml:lowerCorner>
        		<gml:upperCorner>382523.979000 642185.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382523.979000 642185.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 118 797</ms:GML_ID>
        <ms:NAZWA>008 118 797</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008118797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384623.766000 642559.125000</gml:lowerCorner>
        		<gml:upperCorner>384623.766000 642559.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384623.766000 642559.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 116 658</ms:GML_ID>
        <ms:NAZWA>008 116 658</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008116658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385303.261000 642672.099000</gml:lowerCorner>
        		<gml:upperCorner>385303.261000 642672.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385303.261000 642672.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 115 968</ms:GML_ID>
        <ms:NAZWA>008 115 968</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008115968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386934.092000 642655.443000</gml:lowerCorner>
        		<gml:upperCorner>386934.092000 642655.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386934.092000 642655.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 114 322</ms:GML_ID>
        <ms:NAZWA>008 114 322</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008114322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388011.351581 643295.618375</gml:lowerCorner>
        		<gml:upperCorner>388011.351581 643295.618375</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388011.351581 643295.618375</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 113 018</ms:GML_ID>
        <ms:NAZWA>008 113 018</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008113018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388205.851293 643080.151008</gml:lowerCorner>
        		<gml:upperCorner>388205.851293 643080.151008</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388205.851293 643080.151008</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.576 003 443</ms:GML_ID>
        <ms:NAZWA>576 003 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>576003443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388638.745000 642748.460000</gml:lowerCorner>
        		<gml:upperCorner>388638.745000 642748.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388638.745000 642748.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.576 002 864</ms:GML_ID>
        <ms:NAZWA>576 002 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>576002864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389080.463000 641100.155000</gml:lowerCorner>
        		<gml:upperCorner>389080.463000 641100.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389080.463000 641100.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 077 371</ms:GML_ID>
        <ms:NAZWA>022 077 371</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022077371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389393.131000 638268.806000</gml:lowerCorner>
        		<gml:upperCorner>389393.131000 638268.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389393.131000 638268.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 074 521</ms:GML_ID>
        <ms:NAZWA>022 074 521</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022074521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389556.622000 636349.466000</gml:lowerCorner>
        		<gml:upperCorner>389556.622000 636349.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389556.622000 636349.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 072 594</ms:GML_ID>
        <ms:NAZWA>022 072 594</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022072594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389717.554000 634198.711000</gml:lowerCorner>
        		<gml:upperCorner>389717.554000 634198.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389717.554000 634198.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 070 436</ms:GML_ID>
        <ms:NAZWA>022 070 436</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022070436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389784.769000 633153.955000</gml:lowerCorner>
        		<gml:upperCorner>389784.769000 633153.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389784.769000 633153.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 069 388</ms:GML_ID>
        <ms:NAZWA>022 069 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022069388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389836.462000 629673.421000</gml:lowerCorner>
        		<gml:upperCorner>389836.462000 629673.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389836.462000 629673.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 065 905</ms:GML_ID>
        <ms:NAZWA>022 065 905</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022065905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389863.126000 630428.411000</gml:lowerCorner>
        		<gml:upperCorner>389863.126000 630428.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389863.126000 630428.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 066 656</ms:GML_ID>
        <ms:NAZWA>022 066 656</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022066656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389969.923000 626519.172000</gml:lowerCorner>
        		<gml:upperCorner>389969.923000 626519.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389969.923000 626519.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 062 743</ms:GML_ID>
        <ms:NAZWA>022 062 743</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022062743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389992.408000 622254.584000</gml:lowerCorner>
        		<gml:upperCorner>389992.408000 622254.584000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389992.408000 622254.584000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 058 473</ms:GML_ID>
        <ms:NAZWA>022 058 473</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022058473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390005.535000 625693.863000</gml:lowerCorner>
        		<gml:upperCorner>390005.535000 625693.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390005.535000 625693.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 061 916</ms:GML_ID>
        <ms:NAZWA>022 061 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022061916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390037.464000 624957.157000</gml:lowerCorner>
        		<gml:upperCorner>390037.464000 624957.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390037.464000 624957.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 061 189</ms:GML_ID>
        <ms:NAZWA>022 061 189</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022061189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390072.342672 623923.248890</gml:lowerCorner>
        		<gml:upperCorner>390072.342672 623923.248890</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390072.342672 623923.248890</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 060 150</ms:GML_ID>
        <ms:NAZWA>022 060 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022060150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333434.585000 611726.216000</gml:lowerCorner>
        		<gml:upperCorner>333434.585000 611726.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333434.585000 611726.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 190 778</ms:GML_ID>
        <ms:NAZWA>008 190 778</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008190778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345861.061000 612480.672000</gml:lowerCorner>
        		<gml:upperCorner>345861.061000 612480.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345861.061000 612480.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 175 945</ms:GML_ID>
        <ms:NAZWA>008 175 945</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008175945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345087.642000 612658.748000</gml:lowerCorner>
        		<gml:upperCorner>345087.642000 612658.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345087.642000 612658.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 176 755</ms:GML_ID>
        <ms:NAZWA>008 176 755</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008176755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338337.590727 614669.898629</gml:lowerCorner>
        		<gml:upperCorner>338337.590727 614669.898629</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338337.590727 614669.898629</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 184 595</ms:GML_ID>
        <ms:NAZWA>008 184 595</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008184595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346838.048000 614906.644000</gml:lowerCorner>
        		<gml:upperCorner>346838.048000 614906.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346838.048000 614906.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 173 163</ms:GML_ID>
        <ms:NAZWA>008 173 163</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008173163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346894.431000 615455.791000</gml:lowerCorner>
        		<gml:upperCorner>346894.431000 615455.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346894.431000 615455.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 172 594</ms:GML_ID>
        <ms:NAZWA>008 172 594</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008172594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346696.344000 616285.695000</gml:lowerCorner>
        		<gml:upperCorner>346696.344000 616285.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346696.344000 616285.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 171 722</ms:GML_ID>
        <ms:NAZWA>008 171 722</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008171722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346345.187041 617514.966708</gml:lowerCorner>
        		<gml:upperCorner>346345.187041 617514.966708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346345.187041 617514.966708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 170 440</ms:GML_ID>
        <ms:NAZWA>008 170 440</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008170440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346070.024157 617904.625037</gml:lowerCorner>
        		<gml:upperCorner>346070.024157 617904.625037</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346070.024157 617904.625037</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 169 957</ms:GML_ID>
        <ms:NAZWA>008 169 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008169957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345947.403437 618325.346330</gml:lowerCorner>
        		<gml:upperCorner>345947.403437 618325.346330</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345947.403437 618325.346330</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 169 520</ms:GML_ID>
        <ms:NAZWA>008 169 520</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008169520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364224.746000 618931.014000</gml:lowerCorner>
        		<gml:upperCorner>364224.746000 618931.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364224.746000 618931.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 129 159</ms:GML_ID>
        <ms:NAZWA>025 129 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025129159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363885.284961 619352.572971</gml:lowerCorner>
        		<gml:upperCorner>363885.284961 619352.572971</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363885.284961 619352.572971</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 129 703</ms:GML_ID>
        <ms:NAZWA>025 129 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025129703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345774.803656 619735.569813</gml:lowerCorner>
        		<gml:upperCorner>345774.803656 619735.569813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345774.803656 619735.569813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 168 043</ms:GML_ID>
        <ms:NAZWA>008 168 043</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008168043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363492.036882 619748.067039</gml:lowerCorner>
        		<gml:upperCorner>363492.036882 619748.067039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363492.036882 619748.067039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 130 262</ms:GML_ID>
        <ms:NAZWA>025 130 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025130262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362820.621000 621069.228000</gml:lowerCorner>
        		<gml:upperCorner>362820.621000 621069.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362820.621000 621069.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 131 745</ms:GML_ID>
        <ms:NAZWA>025 131 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025131745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362573.888000 621564.549000</gml:lowerCorner>
        		<gml:upperCorner>362573.888000 621564.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362573.888000 621564.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 132 305</ms:GML_ID>
        <ms:NAZWA>025 132 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025132305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362248.254000 622218.646000</gml:lowerCorner>
        		<gml:upperCorner>362248.254000 622218.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362248.254000 622218.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 133 028</ms:GML_ID>
        <ms:NAZWA>025 133 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025133028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361817.195627 623096.067098</gml:lowerCorner>
        		<gml:upperCorner>361817.195627 623096.067098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361817.195627 623096.067098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 134 006</ms:GML_ID>
        <ms:NAZWA>025 134 006</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025134006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361666.229000 623387.822000</gml:lowerCorner>
        		<gml:upperCorner>361666.229000 623387.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361666.229000 623387.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 134 335</ms:GML_ID>
        <ms:NAZWA>025 134 335</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025134335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361290.378000 623998.900000</gml:lowerCorner>
        		<gml:upperCorner>361290.378000 623998.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361290.378000 623998.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 135 057</ms:GML_ID>
        <ms:NAZWA>025 135 057</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025135057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346641.787000 624251.166000</gml:lowerCorner>
        		<gml:upperCorner>346641.787000 624251.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346641.787000 624251.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 163 318</ms:GML_ID>
        <ms:NAZWA>008 163 318</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008163318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360871.850163 624750.632582</gml:lowerCorner>
        		<gml:upperCorner>360871.850163 624750.632582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360871.850163 624750.632582</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 135 928</ms:GML_ID>
        <ms:NAZWA>025 135 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025135928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290106.613026 618354.787786</gml:lowerCorner>
        		<gml:upperCorner>290106.613026 618354.787786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290106.613026 618354.787786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 042 711</ms:GML_ID>
        <ms:NAZWA>073 042 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073042711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290286.100000 617825.071000</gml:lowerCorner>
        		<gml:upperCorner>290286.100000 617825.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290286.100000 617825.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 042 148</ms:GML_ID>
        <ms:NAZWA>073 042 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073042148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291348.602000 616583.969000</gml:lowerCorner>
        		<gml:upperCorner>291348.602000 616583.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291348.602000 616583.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 040 389</ms:GML_ID>
        <ms:NAZWA>073 040 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073040389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293250.475000 616413.375000</gml:lowerCorner>
        		<gml:upperCorner>293250.475000 616413.375000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293250.475000 616413.375000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 038 478</ms:GML_ID>
        <ms:NAZWA>073 038 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073038478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294217.154000 616176.978000</gml:lowerCorner>
        		<gml:upperCorner>294217.154000 616176.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294217.154000 616176.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 037 479</ms:GML_ID>
        <ms:NAZWA>073 037 479</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073037479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295760.194000 615715.470000</gml:lowerCorner>
        		<gml:upperCorner>295760.194000 615715.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295760.194000 615715.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 035 867</ms:GML_ID>
        <ms:NAZWA>073 035 867</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073035867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296262.729000 615532.059000</gml:lowerCorner>
        		<gml:upperCorner>296262.729000 615532.059000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296262.729000 615532.059000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 035 331</ms:GML_ID>
        <ms:NAZWA>073 035 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073035331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296693.986000 615298.966000</gml:lowerCorner>
        		<gml:upperCorner>296693.986000 615298.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296693.986000 615298.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 034 840</ms:GML_ID>
        <ms:NAZWA>073 034 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073034840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299335.788000 613871.127000</gml:lowerCorner>
        		<gml:upperCorner>299335.788000 613871.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299335.788000 613871.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 031 834</ms:GML_ID>
        <ms:NAZWA>073 031 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073031834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300339.180000 613328.376000</gml:lowerCorner>
        		<gml:upperCorner>300339.180000 613328.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300339.180000 613328.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 030 694</ms:GML_ID>
        <ms:NAZWA>073 030 694</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073030694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302672.438280 612597.566189</gml:lowerCorner>
        		<gml:upperCorner>302672.438280 612597.566189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302672.438280 612597.566189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 028 177</ms:GML_ID>
        <ms:NAZWA>073 028 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073028177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304013.718000 612635.017000</gml:lowerCorner>
        		<gml:upperCorner>304013.718000 612635.017000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304013.718000 612635.017000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 026 834</ms:GML_ID>
        <ms:NAZWA>073 026 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073026834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305482.266000 626606.784000</gml:lowerCorner>
        		<gml:upperCorner>305482.266000 626606.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305482.266000 626606.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 017 909</ms:GML_ID>
        <ms:NAZWA>070 017 909</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070017909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305490.314000 624088.417000</gml:lowerCorner>
        		<gml:upperCorner>305490.314000 624088.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305490.314000 624088.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 015 316</ms:GML_ID>
        <ms:NAZWA>070 015 316</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070015316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305504.826003 625881.314658</gml:lowerCorner>
        		<gml:upperCorner>305504.826003 625881.314658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305504.826003 625881.314658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 017 164</ms:GML_ID>
        <ms:NAZWA>070 017 164</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070017164</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305661.042000 611648.549000</gml:lowerCorner>
        		<gml:upperCorner>305661.042000 611648.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305661.042000 611648.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 024 845</ms:GML_ID>
        <ms:NAZWA>073 024 845</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073024845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305976.294000 623047.782000</gml:lowerCorner>
        		<gml:upperCorner>305976.294000 623047.782000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305976.294000 623047.782000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 014 130</ms:GML_ID>
        <ms:NAZWA>070 014 130</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070014130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306676.473000 617220.159000</gml:lowerCorner>
        		<gml:upperCorner>306676.473000 617220.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306676.473000 617220.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 008 202</ms:GML_ID>
        <ms:NAZWA>070 008 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070008202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306852.491000 616368.170000</gml:lowerCorner>
        		<gml:upperCorner>306852.491000 616368.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306852.491000 616368.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 007 326</ms:GML_ID>
        <ms:NAZWA>070 007 326</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070007326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307354.710000 614868.001000</gml:lowerCorner>
        		<gml:upperCorner>307354.710000 614868.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307354.710000 614868.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 005 744</ms:GML_ID>
        <ms:NAZWA>070 005 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070005744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307585.419000 614176.355000</gml:lowerCorner>
        		<gml:upperCorner>307585.419000 614176.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307585.419000 614176.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 005 015</ms:GML_ID>
        <ms:NAZWA>070 005 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070005015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307735.413000 613727.727000</gml:lowerCorner>
        		<gml:upperCorner>307735.413000 613727.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307735.413000 613727.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 004 545</ms:GML_ID>
        <ms:NAZWA>070 004 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070004545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307942.425000 613108.242000</gml:lowerCorner>
        		<gml:upperCorner>307942.425000 613108.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307942.425000 613108.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 003 890</ms:GML_ID>
        <ms:NAZWA>070 003 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070003890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307975.145000 611203.720000</gml:lowerCorner>
        		<gml:upperCorner>307975.145000 611203.720000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307975.145000 611203.720000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 022 423</ms:GML_ID>
        <ms:NAZWA>073 022 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073022423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308262.865000 612148.682000</gml:lowerCorner>
        		<gml:upperCorner>308262.865000 612148.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308262.865000 612148.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 002 876</ms:GML_ID>
        <ms:NAZWA>070 002 876</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070002876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310897.645000 612231.975000</gml:lowerCorner>
        		<gml:upperCorner>310897.645000 612231.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310897.645000 612231.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 019 371</ms:GML_ID>
        <ms:NAZWA>073 019 371</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073019371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311649.477000 612386.528000</gml:lowerCorner>
        		<gml:upperCorner>311649.477000 612386.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311649.477000 612386.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 018 595</ms:GML_ID>
        <ms:NAZWA>073 018 595</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073018595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312973.770000 612412.411000</gml:lowerCorner>
        		<gml:upperCorner>312973.770000 612412.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312973.770000 612412.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 017 279</ms:GML_ID>
        <ms:NAZWA>073 017 279</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073017279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315224.573000 612396.749000</gml:lowerCorner>
        		<gml:upperCorner>315224.573000 612396.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315224.573000 612396.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 014 991</ms:GML_ID>
        <ms:NAZWA>073 014 991</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073014991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318041.437000 613086.246000</gml:lowerCorner>
        		<gml:upperCorner>318041.437000 613086.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318041.437000 613086.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 011 964</ms:GML_ID>
        <ms:NAZWA>073 011 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073011964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318704.631000 612637.548000</gml:lowerCorner>
        		<gml:upperCorner>318704.631000 612637.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318704.631000 612637.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 011 162</ms:GML_ID>
        <ms:NAZWA>073 011 162</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073011162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319208.954000 612296.523000</gml:lowerCorner>
        		<gml:upperCorner>319208.954000 612296.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319208.954000 612296.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 010 552</ms:GML_ID>
        <ms:NAZWA>073 010 552</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073010552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319354.457000 600920.899000</gml:lowerCorner>
        		<gml:upperCorner>319354.457000 600920.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319354.457000 600920.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 211 825</ms:GML_ID>
        <ms:NAZWA>008 211 825</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008211825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321615.801276 604354.690051</gml:lowerCorner>
        		<gml:upperCorner>321615.801276 604354.690051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321615.801276 604354.690051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 207 025</ms:GML_ID>
        <ms:NAZWA>008 207 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008207025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321635.697046 604230.409170</gml:lowerCorner>
        		<gml:upperCorner>321635.697046 604230.409170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321635.697046 604230.409170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 207 156</ms:GML_ID>
        <ms:NAZWA>008 207 156</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008207156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323211.234000 606825.436000</gml:lowerCorner>
        		<gml:upperCorner>323211.234000 606825.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323211.234000 606825.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 204 043</ms:GML_ID>
        <ms:NAZWA>008 204 043</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008204043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323868.364000 610666.384000</gml:lowerCorner>
        		<gml:upperCorner>323868.364000 610666.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323868.364000 610666.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 005 519</ms:GML_ID>
        <ms:NAZWA>073 005 519</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073005519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327370.547000 609363.701000</gml:lowerCorner>
        		<gml:upperCorner>327370.547000 609363.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327370.547000 609363.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 199 073</ms:GML_ID>
        <ms:NAZWA>008 199 073</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008199073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324890.867000 607774.153000</gml:lowerCorner>
        		<gml:upperCorner>324890.867000 607774.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324890.867000 607774.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 202 108</ms:GML_ID>
        <ms:NAZWA>008 202 108</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008202108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324958.611000 610093.698000</gml:lowerCorner>
        		<gml:upperCorner>324958.611000 610093.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324958.611000 610093.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.569 002 489</ms:GML_ID>
        <ms:NAZWA>569 002 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>569002489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325015.498000 610111.034000</gml:lowerCorner>
        		<gml:upperCorner>325015.498000 610111.034000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325015.498000 610111.034000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 004 239</ms:GML_ID>
        <ms:NAZWA>073 004 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073004239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325287.602302 609874.605720</gml:lowerCorner>
        		<gml:upperCorner>325287.602302 609874.605720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325287.602302 609874.605720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.073 003 878</ms:GML_ID>
        <ms:NAZWA>073 003 878</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>073003878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327331.960969 609484.046795</gml:lowerCorner>
        		<gml:upperCorner>327331.960969 609484.046795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327331.960969 609484.046795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 199 083</ms:GML_ID>
        <ms:NAZWA>008 199 083</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008199083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328345.770018 609351.524959</gml:lowerCorner>
        		<gml:upperCorner>328345.770018 609351.524959</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328345.770018 609351.524959</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 198 062</ms:GML_ID>
        <ms:NAZWA>008 198 062</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008198062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330747.681000 608316.856000</gml:lowerCorner>
        		<gml:upperCorner>330747.681000 608316.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330747.681000 608316.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 195 385</ms:GML_ID>
        <ms:NAZWA>008 195 385</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008195385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331642.247000 608193.741000</gml:lowerCorner>
        		<gml:upperCorner>331642.247000 608193.741000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331642.247000 608193.741000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.568 001 640</ms:GML_ID>
        <ms:NAZWA>568 001 640</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>568001640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331889.083000 608989.213000</gml:lowerCorner>
        		<gml:upperCorner>331889.083000 608989.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331889.083000 608989.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 193 993</ms:GML_ID>
        <ms:NAZWA>008 193 993</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008193993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332692.710702 609948.650623</gml:lowerCorner>
        		<gml:upperCorner>332692.710702 609948.650623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332692.710702 609948.650623</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 192 736</ms:GML_ID>
        <ms:NAZWA>008 192 736</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008192736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334611.215000 602811.235000</gml:lowerCorner>
        		<gml:upperCorner>334611.215000 602811.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334611.215000 602811.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 013 062</ms:GML_ID>
        <ms:NAZWA>061 013 062</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061013062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334646.180000 602086.595000</gml:lowerCorner>
        		<gml:upperCorner>334646.180000 602086.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334646.180000 602086.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 013 796</ms:GML_ID>
        <ms:NAZWA>061 013 796</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061013796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334748.400000 599698.056000</gml:lowerCorner>
        		<gml:upperCorner>334748.400000 599698.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334748.400000 599698.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 016 281</ms:GML_ID>
        <ms:NAZWA>061 016 281</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061016281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334926.920000 601354.348000</gml:lowerCorner>
        		<gml:upperCorner>334926.920000 601354.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334926.920000 601354.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 014 582</ms:GML_ID>
        <ms:NAZWA>061 014 582</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061014582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334956.787000 603548.960000</gml:lowerCorner>
        		<gml:upperCorner>334956.787000 603548.960000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334956.787000 603548.960000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 012 243</ms:GML_ID>
        <ms:NAZWA>061 012 243</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061012243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336280.728000 607153.060000</gml:lowerCorner>
        		<gml:upperCorner>336280.728000 607153.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336280.728000 607153.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 008 320</ms:GML_ID>
        <ms:NAZWA>061 008 320</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061008320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336283.780000 606420.487000</gml:lowerCorner>
        		<gml:upperCorner>336283.780000 606420.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336283.780000 606420.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 009 065</ms:GML_ID>
        <ms:NAZWA>061 009 065</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061009065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364976.756000 604155.862000</gml:lowerCorner>
        		<gml:upperCorner>364976.756000 604155.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364976.756000 604155.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 113 055</ms:GML_ID>
        <ms:NAZWA>025 113 055</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025113055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365098.965000 611638.332000</gml:lowerCorner>
        		<gml:upperCorner>365098.965000 611638.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365098.965000 611638.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 120 683</ms:GML_ID>
        <ms:NAZWA>025 120 683</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025120683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365114.803293 608682.377391</gml:lowerCorner>
        		<gml:upperCorner>365114.803293 608682.377391</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365114.803293 608682.377391</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 117 685</ms:GML_ID>
        <ms:NAZWA>025 117 685</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025117685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365209.635498 606254.149305</gml:lowerCorner>
        		<gml:upperCorner>365209.635498 606254.149305</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365209.635498 606254.149305</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 115 180</ms:GML_ID>
        <ms:NAZWA>025 115 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025115180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365292.210589 609729.414323</gml:lowerCorner>
        		<gml:upperCorner>365292.210589 609729.414323</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365292.210589 609729.414323</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 118 761</ms:GML_ID>
        <ms:NAZWA>025 118 761</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025118761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365391.200000 606834.533000</gml:lowerCorner>
        		<gml:upperCorner>365391.200000 606834.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365391.200000 606834.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 115 789</ms:GML_ID>
        <ms:NAZWA>025 115 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025115789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365433.520000 607401.934000</gml:lowerCorner>
        		<gml:upperCorner>365433.520000 607401.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365433.520000 607401.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 116 364</ms:GML_ID>
        <ms:NAZWA>025 116 364</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025116364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365952.963000 613001.786000</gml:lowerCorner>
        		<gml:upperCorner>365952.963000 613001.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365952.963000 613001.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 122 321</ms:GML_ID>
        <ms:NAZWA>025 122 321</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025122321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366416.031000 614035.872000</gml:lowerCorner>
        		<gml:upperCorner>366416.031000 614035.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366416.031000 614035.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 123 455</ms:GML_ID>
        <ms:NAZWA>025 123 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025123455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366477.861000 615684.631000</gml:lowerCorner>
        		<gml:upperCorner>366477.861000 615684.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366477.861000 615684.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 125 176</ms:GML_ID>
        <ms:NAZWA>025 125 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025125176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369128.513000 600069.074000</gml:lowerCorner>
        		<gml:upperCorner>369128.513000 600069.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369128.513000 600069.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 106 964</ms:GML_ID>
        <ms:NAZWA>025 106 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025106964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369759.954303 599616.049041</gml:lowerCorner>
        		<gml:upperCorner>369759.954303 599616.049041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369759.954303 599616.049041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 106 183</ms:GML_ID>
        <ms:NAZWA>025 106 183</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025106183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370634.727929 599233.945472</gml:lowerCorner>
        		<gml:upperCorner>370634.727929 599233.945472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370634.727929 599233.945472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 105 229</ms:GML_ID>
        <ms:NAZWA>025 105 229</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025105229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372322.395437 598699.644512</gml:lowerCorner>
        		<gml:upperCorner>372322.395437 598699.644512</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372322.395437 598699.644512</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 103 444</ms:GML_ID>
        <ms:NAZWA>025 103 444</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025103444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373226.231789 598077.131125</gml:lowerCorner>
        		<gml:upperCorner>373226.231789 598077.131125</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373226.231789 598077.131125</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 102 344</ms:GML_ID>
        <ms:NAZWA>025 102 344</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025102344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390086.900000 620217.523000</gml:lowerCorner>
        		<gml:upperCorner>390086.900000 620217.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390086.900000 620217.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 056 429</ms:GML_ID>
        <ms:NAZWA>022 056 429</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022056429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390144.209000 619726.362000</gml:lowerCorner>
        		<gml:upperCorner>390144.209000 619726.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390144.209000 619726.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 055 932</ms:GML_ID>
        <ms:NAZWA>022 055 932</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022055932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390494.559052 618307.601210</gml:lowerCorner>
        		<gml:upperCorner>390494.559052 618307.601210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390494.559052 618307.601210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 054 465</ms:GML_ID>
        <ms:NAZWA>022 054 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022054465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390814.935993 617348.314156</gml:lowerCorner>
        		<gml:upperCorner>390814.935993 617348.314156</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390814.935993 617348.314156</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 053 462</ms:GML_ID>
        <ms:NAZWA>022 053 462</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022053462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391103.247127 616483.925269</gml:lowerCorner>
        		<gml:upperCorner>391103.247127 616483.925269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391103.247127 616483.925269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 052 538</ms:GML_ID>
        <ms:NAZWA>022 052 538</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022052538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391655.212022 614837.842039</gml:lowerCorner>
        		<gml:upperCorner>391655.212022 614837.842039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391655.212022 614837.842039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 050 804</ms:GML_ID>
        <ms:NAZWA>022 050 804</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022050804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393067.797708 612371.081753</gml:lowerCorner>
        		<gml:upperCorner>393067.797708 612371.081753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393067.797708 612371.081753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 047 772</ms:GML_ID>
        <ms:NAZWA>022 047 772</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022047772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393300.628000 611562.577000</gml:lowerCorner>
        		<gml:upperCorner>393300.628000 611562.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393300.628000 611562.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 046 910</ms:GML_ID>
        <ms:NAZWA>022 046 910</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022046910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393534.158000 611204.448000</gml:lowerCorner>
        		<gml:upperCorner>393534.158000 611204.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393534.158000 611204.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 046 497</ms:GML_ID>
        <ms:NAZWA>022 046 497</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022046497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394603.400148 609538.245051</gml:lowerCorner>
        		<gml:upperCorner>394603.400148 609538.245051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394603.400148 609538.245051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 044 503</ms:GML_ID>
        <ms:NAZWA>022 044 503</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022044503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395253.989036 608286.087349</gml:lowerCorner>
        		<gml:upperCorner>395253.989036 608286.087349</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395253.989036 608286.087349</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 043 091</ms:GML_ID>
        <ms:NAZWA>022 043 091</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022043091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395701.851408 606517.526428</gml:lowerCorner>
        		<gml:upperCorner>395701.851408 606517.526428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395701.851408 606517.526428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 041 264</ms:GML_ID>
        <ms:NAZWA>022 041 264</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022041264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396362.138471 604328.681883</gml:lowerCorner>
        		<gml:upperCorner>396362.138471 604328.681883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396362.138471 604328.681883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 038 974</ms:GML_ID>
        <ms:NAZWA>022 038 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022038974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397947.215000 601562.294000</gml:lowerCorner>
        		<gml:upperCorner>397947.215000 601562.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397947.215000 601562.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 035 757</ms:GML_ID>
        <ms:NAZWA>022 035 757</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022035757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399765.104000 598384.716000</gml:lowerCorner>
        		<gml:upperCorner>399765.104000 598384.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399765.104000 598384.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 032 019</ms:GML_ID>
        <ms:NAZWA>022 032 019</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022032019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400299.909000 597740.534000</gml:lowerCorner>
        		<gml:upperCorner>400299.909000 597740.534000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400299.909000 597740.534000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 031 179</ms:GML_ID>
        <ms:NAZWA>022 031 179</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022031179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307355.684000 586962.206000</gml:lowerCorner>
        		<gml:upperCorner>307355.684000 586962.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307355.684000 586962.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 235 647</ms:GML_ID>
        <ms:NAZWA>008 235 647</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008235647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308015.991000 587936.107000</gml:lowerCorner>
        		<gml:upperCorner>308015.991000 587936.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308015.991000 587936.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 234 462</ms:GML_ID>
        <ms:NAZWA>008 234 462</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008234462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308899.329558 589870.094862</gml:lowerCorner>
        		<gml:upperCorner>308899.329558 589870.094862</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308899.329558 589870.094862</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 232 283</ms:GML_ID>
        <ms:NAZWA>008 232 283</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008232283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309751.508476 590404.134292</gml:lowerCorner>
        		<gml:upperCorner>309751.508476 590404.134292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309751.508476 590404.134292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 231 276</ms:GML_ID>
        <ms:NAZWA>008 231 276</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008231276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310272.023000 591935.923000</gml:lowerCorner>
        		<gml:upperCorner>310272.023000 591935.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310272.023000 591935.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 229 590</ms:GML_ID>
        <ms:NAZWA>008 229 590</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008229590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311669.771016 593329.280484</gml:lowerCorner>
        		<gml:upperCorner>311669.771016 593329.280484</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311669.771016 593329.280484</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 227 416</ms:GML_ID>
        <ms:NAZWA>008 227 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008227416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313687.245000 593478.262000</gml:lowerCorner>
        		<gml:upperCorner>313687.245000 593478.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313687.245000 593478.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 225 387</ms:GML_ID>
        <ms:NAZWA>008 225 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008225387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316508.981000 594136.477000</gml:lowerCorner>
        		<gml:upperCorner>316508.981000 594136.477000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316508.981000 594136.477000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 222 436</ms:GML_ID>
        <ms:NAZWA>008 222 436</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008222436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317819.692000 595150.111000</gml:lowerCorner>
        		<gml:upperCorner>317819.692000 595150.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317819.692000 595150.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 220 676</ms:GML_ID>
        <ms:NAZWA>008 220 676</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008220676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317769.007970 596674.732388</gml:lowerCorner>
        		<gml:upperCorner>317769.007970 596674.732388</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317769.007970 596674.732388</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 219 138</ms:GML_ID>
        <ms:NAZWA>008 219 138</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008219138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317082.373000 598914.149000</gml:lowerCorner>
        		<gml:upperCorner>317082.373000 598914.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317082.373000 598914.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 216 754</ms:GML_ID>
        <ms:NAZWA>008 216 754</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008216754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316398.948000 600353.751000</gml:lowerCorner>
        		<gml:upperCorner>316398.948000 600353.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316398.948000 600353.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 215 123</ms:GML_ID>
        <ms:NAZWA>008 215 123</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008215123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378244.267498 596407.142874</gml:lowerCorner>
        		<gml:upperCorner>378244.267498 596407.142874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378244.267498 596407.142874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 096 872</ms:GML_ID>
        <ms:NAZWA>025 096 872</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025096872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379815.362158 595899.025975</gml:lowerCorner>
        		<gml:upperCorner>379815.362158 595899.025975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379815.362158 595899.025975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 095 207</ms:GML_ID>
        <ms:NAZWA>025 095 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025095207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380341.045990 595712.533590</gml:lowerCorner>
        		<gml:upperCorner>380341.045990 595712.533590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380341.045990 595712.533590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 094 647</ms:GML_ID>
        <ms:NAZWA>025 094 647</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025094647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381207.507000 595397.060000</gml:lowerCorner>
        		<gml:upperCorner>381207.507000 595397.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381207.507000 595397.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 093 730</ms:GML_ID>
        <ms:NAZWA>025 093 730</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025093730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381739.637338 595099.334187</gml:lowerCorner>
        		<gml:upperCorner>381739.637338 595099.334187</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381739.637338 595099.334187</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 093 115</ms:GML_ID>
        <ms:NAZWA>025 093 115</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025093115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382317.321605 594761.447685</gml:lowerCorner>
        		<gml:upperCorner>382317.321605 594761.447685</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382317.321605 594761.447685</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 092 445</ms:GML_ID>
        <ms:NAZWA>025 092 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025092445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383062.515000 594325.739940</gml:lowerCorner>
        		<gml:upperCorner>383062.515000 594325.739940</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383062.515000 594325.739940</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 091 581</ms:GML_ID>
        <ms:NAZWA>025 091 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025091581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384307.310000 593597.481000</gml:lowerCorner>
        		<gml:upperCorner>384307.310000 593597.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384307.310000 593597.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 090 139</ms:GML_ID>
        <ms:NAZWA>025 090 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025090139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386715.223148 592187.413058</gml:lowerCorner>
        		<gml:upperCorner>386715.223148 592187.413058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386715.223148 592187.413058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 087 348</ms:GML_ID>
        <ms:NAZWA>025 087 348</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025087348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387335.810594 591824.331008</gml:lowerCorner>
        		<gml:upperCorner>387335.810594 591824.331008</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387335.810594 591824.331008</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 086 627</ms:GML_ID>
        <ms:NAZWA>025 086 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025086627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387933.255370 591474.603012</gml:lowerCorner>
        		<gml:upperCorner>387933.255370 591474.603012</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387933.255370 591474.603012</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 085 935</ms:GML_ID>
        <ms:NAZWA>025 085 935</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025085935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388395.075000 591204.306000</gml:lowerCorner>
        		<gml:upperCorner>388395.075000 591204.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388395.075000 591204.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 085 398</ms:GML_ID>
        <ms:NAZWA>025 085 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025085398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388731.355000 591007.388475</gml:lowerCorner>
        		<gml:upperCorner>388731.355000 591007.388475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388731.355000 591007.388475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 085 008</ms:GML_ID>
        <ms:NAZWA>025 085 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025085008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389604.323001 590283.737873</gml:lowerCorner>
        		<gml:upperCorner>389604.323001 590283.737873</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389604.323001 590283.737873</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 083 863</ms:GML_ID>
        <ms:NAZWA>025 083 863</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025083863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389975.209000 589490.030000</gml:lowerCorner>
        		<gml:upperCorner>389975.209000 589490.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389975.209000 589490.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 082 981</ms:GML_ID>
        <ms:NAZWA>025 082 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025082981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390148.380183 589016.945581</gml:lowerCorner>
        		<gml:upperCorner>390148.380183 589016.945581</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390148.380183 589016.945581</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 082 477</ms:GML_ID>
        <ms:NAZWA>025 082 477</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025082477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390501.375284 588068.333205</gml:lowerCorner>
        		<gml:upperCorner>390501.375284 588068.333205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390501.375284 588068.333205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 081 465</ms:GML_ID>
        <ms:NAZWA>025 081 465</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025081465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391435.894104 586152.242275</gml:lowerCorner>
        		<gml:upperCorner>391435.894104 586152.242275</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391435.894104 586152.242275</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 079 329</ms:GML_ID>
        <ms:NAZWA>025 079 329</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025079329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404938.257818 574199.481643</gml:lowerCorner>
        		<gml:upperCorner>404938.257818 574199.481643</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404938.257818 574199.481643</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 060 897</ms:GML_ID>
        <ms:NAZWA>025 060 897</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025060897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404237.732144 574605.377734</gml:lowerCorner>
        		<gml:upperCorner>404237.732144 574605.377734</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404237.732144 574605.377734</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 061 707</ms:GML_ID>
        <ms:NAZWA>025 061 707</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025061707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406855.022000 574695.671000</gml:lowerCorner>
        		<gml:upperCorner>406855.022000 574695.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406855.022000 574695.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 004 360</ms:GML_ID>
        <ms:NAZWA>022 004 360</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022004360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410265.935464 575982.293237</gml:lowerCorner>
        		<gml:upperCorner>410265.935464 575982.293237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410265.935464 575982.293237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 005 430</ms:GML_ID>
        <ms:NAZWA>053 005 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053005430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406596.775000 576195.974000</gml:lowerCorner>
        		<gml:upperCorner>406596.775000 576195.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406596.775000 576195.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 005 884</ms:GML_ID>
        <ms:NAZWA>022 005 884</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022005884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398897.682182 577709.814352</gml:lowerCorner>
        		<gml:upperCorner>398897.682182 577709.814352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398897.682182 577709.814352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 067 890</ms:GML_ID>
        <ms:NAZWA>025 067 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025067890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398640.759000 577971.651000</gml:lowerCorner>
        		<gml:upperCorner>398640.759000 577971.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398640.759000 577971.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 068 257</ms:GML_ID>
        <ms:NAZWA>025 068 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025068257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410634.677045 577982.448436</gml:lowerCorner>
        		<gml:upperCorner>410634.677045 577982.448436</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410634.677045 577982.448436</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 007 591</ms:GML_ID>
        <ms:NAZWA>053 007 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053007591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410556.355210 578504.311350</gml:lowerCorner>
        		<gml:upperCorner>410556.355210 578504.311350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410556.355210 578504.311350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 008 134</ms:GML_ID>
        <ms:NAZWA>053 008 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053008134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397986.321108 578699.534351</gml:lowerCorner>
        		<gml:upperCorner>397986.321108 578699.534351</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397986.321108 578699.534351</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 069 237</ms:GML_ID>
        <ms:NAZWA>025 069 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025069237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397391.504651 579361.563839</gml:lowerCorner>
        		<gml:upperCorner>397391.504651 579361.563839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397391.504651 579361.563839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 070 128</ms:GML_ID>
        <ms:NAZWA>025 070 128</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025070128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403698.425000 579564.983000</gml:lowerCorner>
        		<gml:upperCorner>403698.425000 579564.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403698.425000 579564.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 010 664</ms:GML_ID>
        <ms:NAZWA>022 010 664</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022010664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401796.604000 580152.814000</gml:lowerCorner>
        		<gml:upperCorner>401796.604000 580152.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401796.604000 580152.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 012 665</ms:GML_ID>
        <ms:NAZWA>022 012 665</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022012665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396223.270047 580646.716751</gml:lowerCorner>
        		<gml:upperCorner>396223.270047 580646.716751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396223.270047 580646.716751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 071 865</ms:GML_ID>
        <ms:NAZWA>025 071 865</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025071865</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395713.164266 581012.037471</gml:lowerCorner>
        		<gml:upperCorner>395713.164266 581012.037471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395713.164266 581012.037471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 072 496</ms:GML_ID>
        <ms:NAZWA>025 072 496</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025072496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395391.045231 581264.384688</gml:lowerCorner>
        		<gml:upperCorner>395391.045231 581264.384688</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395391.045231 581264.384688</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 072 904</ms:GML_ID>
        <ms:NAZWA>025 072 904</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025072904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394985.523517 581775.011401</gml:lowerCorner>
        		<gml:upperCorner>394985.523517 581775.011401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394985.523517 581775.011401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 073 560</ms:GML_ID>
        <ms:NAZWA>025 073 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025073560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394370.054846 582728.398553</gml:lowerCorner>
        		<gml:upperCorner>394370.054846 582728.398553</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394370.054846 582728.398553</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 074 697</ms:GML_ID>
        <ms:NAZWA>025 074 697</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025074697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394040.735000 583095.877000</gml:lowerCorner>
        		<gml:upperCorner>394040.735000 583095.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394040.735000 583095.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 075 194</ms:GML_ID>
        <ms:NAZWA>025 075 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025075194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401721.819000 583279.009000</gml:lowerCorner>
        		<gml:upperCorner>401721.819000 583279.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401721.819000 583279.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 015 981</ms:GML_ID>
        <ms:NAZWA>022 015 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022015981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393436.123327 583770.853063</gml:lowerCorner>
        		<gml:upperCorner>393436.123327 583770.853063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393436.123327 583770.853063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 076 097</ms:GML_ID>
        <ms:NAZWA>025 076 097</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025076097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392565.737000 584686.533000</gml:lowerCorner>
        		<gml:upperCorner>392565.737000 584686.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392565.737000 584686.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 077 367</ms:GML_ID>
        <ms:NAZWA>025 077 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025077367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391802.549328 585188.244725</gml:lowerCorner>
        		<gml:upperCorner>391802.549328 585188.244725</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391802.549328 585188.244725</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 078 288</ms:GML_ID>
        <ms:NAZWA>025 078 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025078288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402589.078411 588996.720859</gml:lowerCorner>
        		<gml:upperCorner>402589.078411 588996.720859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402589.078411 588996.720859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 021 776</ms:GML_ID>
        <ms:NAZWA>022 021 776</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022021776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401251.816225 596295.542286</gml:lowerCorner>
        		<gml:upperCorner>401251.816225 596295.542286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401251.816225 596295.542286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 029 420</ms:GML_ID>
        <ms:NAZWA>022 029 420</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022029420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400851.583000 597165.758000</gml:lowerCorner>
        		<gml:upperCorner>400851.583000 597165.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400851.583000 597165.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 030 380</ms:GML_ID>
        <ms:NAZWA>022 030 380</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022030380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329723.353175 569732.560766</gml:lowerCorner>
        		<gml:upperCorner>329723.353175 569732.560766</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329723.353175 569732.560766</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 049 756</ms:GML_ID>
        <ms:NAZWA>061 049 756</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061049756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330544.871382 570854.933964</gml:lowerCorner>
        		<gml:upperCorner>330544.871382 570854.933964</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330544.871382 570854.933964</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 048 293</ms:GML_ID>
        <ms:NAZWA>061 048 293</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061048293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330745.028362 572461.910276</gml:lowerCorner>
        		<gml:upperCorner>330745.028362 572461.910276</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330745.028362 572461.910276</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 046 661</ms:GML_ID>
        <ms:NAZWA>061 046 661</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061046661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331695.814000 576174.386000</gml:lowerCorner>
        		<gml:upperCorner>331695.814000 576174.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331695.814000 576174.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 042 763</ms:GML_ID>
        <ms:NAZWA>061 042 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061042763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331772.368000 578507.540000</gml:lowerCorner>
        		<gml:upperCorner>331772.368000 578507.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331772.368000 578507.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 040 423</ms:GML_ID>
        <ms:NAZWA>061 040 423</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061040423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331683.462000 579485.293000</gml:lowerCorner>
        		<gml:upperCorner>331683.462000 579485.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331683.462000 579485.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 039 427</ms:GML_ID>
        <ms:NAZWA>061 039 427</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061039427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332668.358555 581887.735795</gml:lowerCorner>
        		<gml:upperCorner>332668.358555 581887.735795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332668.358555 581887.735795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 036 346</ms:GML_ID>
        <ms:NAZWA>061 036 346</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061036346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333802.169000 582246.985000</gml:lowerCorner>
        		<gml:upperCorner>333802.169000 582246.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333802.169000 582246.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 035 043</ms:GML_ID>
        <ms:NAZWA>061 035 043</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061035043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333459.690000 583504.075000</gml:lowerCorner>
        		<gml:upperCorner>333459.690000 583504.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333459.690000 583504.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 033 603</ms:GML_ID>
        <ms:NAZWA>061 033 603</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061033603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333207.716000 584409.801000</gml:lowerCorner>
        		<gml:upperCorner>333207.716000 584409.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333207.716000 584409.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 032 655</ms:GML_ID>
        <ms:NAZWA>061 032 655</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061032655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332407.298000 590895.651000</gml:lowerCorner>
        		<gml:upperCorner>332407.298000 590895.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332407.298000 590895.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 025 911</ms:GML_ID>
        <ms:NAZWA>061 025 911</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061025911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334054.531000 592502.867000</gml:lowerCorner>
        		<gml:upperCorner>334054.531000 592502.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334054.531000 592502.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 023 575</ms:GML_ID>
        <ms:NAZWA>061 023 575</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061023575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334066.172000 593051.827000</gml:lowerCorner>
        		<gml:upperCorner>334066.172000 593051.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334066.172000 593051.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 023 000</ms:GML_ID>
        <ms:NAZWA>061 023 000</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061023000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333971.701000 593815.615000</gml:lowerCorner>
        		<gml:upperCorner>333971.701000 593815.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333971.701000 593815.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 022 241</ms:GML_ID>
        <ms:NAZWA>061 022 241</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061022241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333956.209000 594672.327000</gml:lowerCorner>
        		<gml:upperCorner>333956.209000 594672.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333956.209000 594672.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 021 381</ms:GML_ID>
        <ms:NAZWA>061 021 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061021381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334180.958000 596012.333000</gml:lowerCorner>
        		<gml:upperCorner>334180.958000 596012.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334180.958000 596012.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 020 028</ms:GML_ID>
        <ms:NAZWA>061 020 028</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061020028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334302.058000 596604.886000</gml:lowerCorner>
        		<gml:upperCorner>334302.058000 596604.886000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334302.058000 596604.886000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 019 412</ms:GML_ID>
        <ms:NAZWA>061 019 412</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061019412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334704.009000 599080.320000</gml:lowerCorner>
        		<gml:upperCorner>334704.009000 599080.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334704.009000 599080.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 016 900</ms:GML_ID>
        <ms:NAZWA>061 016 900</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061016900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282508.058000 567696.982000</gml:lowerCorner>
        		<gml:upperCorner>282508.058000 567696.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282508.058000 567696.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 005 938</ms:GML_ID>
        <ms:NAZWA>062 005 938</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062005938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282792.900658 571396.577062</gml:lowerCorner>
        		<gml:upperCorner>282792.900658 571396.577062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282792.900658 571396.577062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 271 185</ms:GML_ID>
        <ms:NAZWA>008 271 185</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008271185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282874.475000 567383.295000</gml:lowerCorner>
        		<gml:upperCorner>282874.475000 567383.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282874.475000 567383.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 005 457</ms:GML_ID>
        <ms:NAZWA>062 005 457</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062005457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283108.605192 571071.523388</gml:lowerCorner>
        		<gml:upperCorner>283108.605192 571071.523388</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283108.605192 571071.523388</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 270 731</ms:GML_ID>
        <ms:NAZWA>008 270 731</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008270731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283758.213000 567408.596000</gml:lowerCorner>
        		<gml:upperCorner>283758.213000 567408.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283758.213000 567408.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 004 484</ms:GML_ID>
        <ms:NAZWA>062 004 484</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062004484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283893.347000 568408.259000</gml:lowerCorner>
        		<gml:upperCorner>283893.347000 568408.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283893.347000 568408.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 003 434</ms:GML_ID>
        <ms:NAZWA>062 003 434</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062003434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285523.107074 570348.304884</gml:lowerCorner>
        		<gml:upperCorner>285523.107074 570348.304884</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285523.107074 570348.304884</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 268 054</ms:GML_ID>
        <ms:NAZWA>008 268 054</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008268054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287626.155308 571958.797899</gml:lowerCorner>
        		<gml:upperCorner>287626.155308 571958.797899</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287626.155308 571958.797899</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 265 067</ms:GML_ID>
        <ms:NAZWA>008 265 067</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008265067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291833.817314 572091.279342</gml:lowerCorner>
        		<gml:upperCorner>291833.817314 572091.279342</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291833.817314 572091.279342</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 260 481</ms:GML_ID>
        <ms:NAZWA>008 260 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008260481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292644.136287 572258.218517</gml:lowerCorner>
        		<gml:upperCorner>292644.136287 572258.218517</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292644.136287 572258.218517</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 259 621</ms:GML_ID>
        <ms:NAZWA>008 259 621</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008259621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292811.266771 572383.195931</gml:lowerCorner>
        		<gml:upperCorner>292811.266771 572383.195931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292811.266771 572383.195931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 259 421</ms:GML_ID>
        <ms:NAZWA>008 259 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008259421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293966.245000 570637.217000</gml:lowerCorner>
        		<gml:upperCorner>293966.245000 570637.217000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293966.245000 570637.217000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 004 451</ms:GML_ID>
        <ms:NAZWA>064 004 451</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064004451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294255.189000 569530.660000</gml:lowerCorner>
        		<gml:upperCorner>294255.189000 569530.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294255.189000 569530.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 005 596</ms:GML_ID>
        <ms:NAZWA>064 005 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064005596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294393.609000 569000.241000</gml:lowerCorner>
        		<gml:upperCorner>294393.609000 569000.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294393.609000 569000.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 006 143</ms:GML_ID>
        <ms:NAZWA>064 006 143</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064006143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295200.666599 572833.727171</gml:lowerCorner>
        		<gml:upperCorner>295200.666599 572833.727171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295200.666599 572833.727171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 256 987</ms:GML_ID>
        <ms:NAZWA>008 256 987</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008256987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295743.641691 572950.847221</gml:lowerCorner>
        		<gml:upperCorner>295743.641691 572950.847221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295743.641691 572950.847221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 256 430</ms:GML_ID>
        <ms:NAZWA>008 256 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008256430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296726.213437 567352.346124</gml:lowerCorner>
        		<gml:upperCorner>296726.213437 567352.346124</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296726.213437 567352.346124</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 009 131</ms:GML_ID>
        <ms:NAZWA>064 009 131</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064009131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297593.788000 573965.528000</gml:lowerCorner>
        		<gml:upperCorner>297593.788000 573965.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297593.788000 573965.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 254 300</ms:GML_ID>
        <ms:NAZWA>008 254 300</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008254300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298521.088000 573908.067000</gml:lowerCorner>
        		<gml:upperCorner>298521.088000 573908.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298521.088000 573908.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 253 362</ms:GML_ID>
        <ms:NAZWA>008 253 362</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008253362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298953.699000 565802.523000</gml:lowerCorner>
        		<gml:upperCorner>298953.699000 565802.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298953.699000 565802.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 011 846</ms:GML_ID>
        <ms:NAZWA>064 011 846</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064011846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299706.910000 564919.045000</gml:lowerCorner>
        		<gml:upperCorner>299706.910000 564919.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299706.910000 564919.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 013 034</ms:GML_ID>
        <ms:NAZWA>064 013 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064013034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300770.184159 575165.930257</gml:lowerCorner>
        		<gml:upperCorner>300770.184159 575165.930257</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300770.184159 575165.930257</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 250 501</ms:GML_ID>
        <ms:NAZWA>008 250 501</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008250501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301293.210000 563083.085000</gml:lowerCorner>
        		<gml:upperCorner>301293.210000 563083.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301293.210000 563083.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 015 618</ms:GML_ID>
        <ms:NAZWA>064 015 618</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064015618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301891.051687 577659.597745</gml:lowerCorner>
        		<gml:upperCorner>301891.051687 577659.597745</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301891.051687 577659.597745</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 247 751</ms:GML_ID>
        <ms:NAZWA>008 247 751</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008247751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302339.744012 579209.603388</gml:lowerCorner>
        		<gml:upperCorner>302339.744012 579209.603388</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302339.744012 579209.603388</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 246 135</ms:GML_ID>
        <ms:NAZWA>008 246 135</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008246135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302368.241048 562744.152062</gml:lowerCorner>
        		<gml:upperCorner>302368.241048 562744.152062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302368.241048 562744.152062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 016 747</ms:GML_ID>
        <ms:NAZWA>064 016 747</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064016747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302872.643190 580608.173689</gml:lowerCorner>
        		<gml:upperCorner>302872.643190 580608.173689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302872.643190 580608.173689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 244 630</ms:GML_ID>
        <ms:NAZWA>008 244 630</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008244630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303276.469000 562456.536000</gml:lowerCorner>
        		<gml:upperCorner>303276.469000 562456.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303276.469000 562456.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 017 690</ms:GML_ID>
        <ms:NAZWA>064 017 690</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064017690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303509.646701 582712.291402</gml:lowerCorner>
        		<gml:upperCorner>303509.646701 582712.291402</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303509.646701 582712.291402</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 242 341</ms:GML_ID>
        <ms:NAZWA>008 242 341</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008242341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236077.730000 575451.948000</gml:lowerCorner>
        		<gml:upperCorner>236077.730000 575451.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236077.730000 575451.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.109 005 071</ms:GML_ID>
        <ms:NAZWA>109 005 071</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>109005071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236377.553588 575151.507562</gml:lowerCorner>
        		<gml:upperCorner>236377.553588 575151.507562</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236377.553588 575151.507562</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.109 004 632</ms:GML_ID>
        <ms:NAZWA>109 004 632</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>109004632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238713.570000 574153.143000</gml:lowerCorner>
        		<gml:upperCorner>238713.570000 574153.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238713.570000 574153.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.109 001 488</ms:GML_ID>
        <ms:NAZWA>109 001 488</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>109001488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239478.011000 573850.972000</gml:lowerCorner>
        		<gml:upperCorner>239478.011000 573850.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239478.011000 573850.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.109 000 662</ms:GML_ID>
        <ms:NAZWA>109 000 662</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>109000662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239741.812428 574287.928621</gml:lowerCorner>
        		<gml:upperCorner>239741.812428 574287.928621</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239741.812428 574287.928621</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.091 008 939</ms:GML_ID>
        <ms:NAZWA>091 008 939</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>091008939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239765.237154 574388.872627</gml:lowerCorner>
        		<gml:upperCorner>239765.237154 574388.872627</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239765.237154 574388.872627</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 018 036</ms:GML_ID>
        <ms:NAZWA>100 018 036</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100018036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239819.307176 573657.281538</gml:lowerCorner>
        		<gml:upperCorner>239819.307176 573657.281538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239819.307176 573657.281538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.109 000 266</ms:GML_ID>
        <ms:NAZWA>109 000 266</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>109000266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239829.938144 574202.935218</gml:lowerCorner>
        		<gml:upperCorner>239829.938144 574202.935218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239829.938144 574202.935218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 017 890</ms:GML_ID>
        <ms:NAZWA>100 017 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100017890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240342.102584 572737.831462</gml:lowerCorner>
        		<gml:upperCorner>240342.102584 572737.831462</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240342.102584 572737.831462</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.603 001 615</ms:GML_ID>
        <ms:NAZWA>603 001 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>603001615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240370.825652 572893.585779</gml:lowerCorner>
        		<gml:upperCorner>240370.825652 572893.585779</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240370.825652 572893.585779</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 016 414</ms:GML_ID>
        <ms:NAZWA>100 016 414</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100016414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240379.311198 572528.421814</gml:lowerCorner>
        		<gml:upperCorner>240379.311198 572528.421814</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240379.311198 572528.421814</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.100 016 039</ms:GML_ID>
        <ms:NAZWA>100 016 039</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>100016039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240413.747000 572380.245000</gml:lowerCorner>
        		<gml:upperCorner>240413.747000 572380.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240413.747000 572380.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.945 000 136</ms:GML_ID>
        <ms:NAZWA>945 000 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>945000136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250952.392819 576011.889514</gml:lowerCorner>
        		<gml:upperCorner>250952.392819 576011.889514</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250952.392819 576011.889514</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 308 055</ms:GML_ID>
        <ms:NAZWA>008 308 055</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008308055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257961.123755 575766.268413</gml:lowerCorner>
        		<gml:upperCorner>257961.123755 575766.268413</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257961.123755 575766.268413</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 299 007</ms:GML_ID>
        <ms:NAZWA>008 299 007</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008299007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262025.897305 577030.562281</gml:lowerCorner>
        		<gml:upperCorner>262025.897305 577030.562281</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262025.897305 577030.562281</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 294 076</ms:GML_ID>
        <ms:NAZWA>008 294 076</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008294076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262373.946267 577048.888052</gml:lowerCorner>
        		<gml:upperCorner>262373.946267 577048.888052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262373.946267 577048.888052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 293 726</ms:GML_ID>
        <ms:NAZWA>008 293 726</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008293726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264856.632171 575914.164099</gml:lowerCorner>
        		<gml:upperCorner>264856.632171 575914.164099</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264856.632171 575914.164099</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 290 806</ms:GML_ID>
        <ms:NAZWA>008 290 806</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008290806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266309.471000 575323.647000</gml:lowerCorner>
        		<gml:upperCorner>266309.471000 575323.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266309.471000 575323.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 289 206</ms:GML_ID>
        <ms:NAZWA>008 289 206</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008289206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267903.757282 574625.832103</gml:lowerCorner>
        		<gml:upperCorner>267903.757282 574625.832103</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267903.757282 574625.832103</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 287 464</ms:GML_ID>
        <ms:NAZWA>008 287 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008287464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268795.783028 573989.504443</gml:lowerCorner>
        		<gml:upperCorner>268795.783028 573989.504443</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268795.783028 573989.504443</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 286 365</ms:GML_ID>
        <ms:NAZWA>008 286 365</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008286365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269584.305775 573746.123632</gml:lowerCorner>
        		<gml:upperCorner>269584.305775 573746.123632</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269584.305775 573746.123632</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 285 538</ms:GML_ID>
        <ms:NAZWA>008 285 538</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008285538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270071.950849 573547.426962</gml:lowerCorner>
        		<gml:upperCorner>270071.950849 573547.426962</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270071.950849 573547.426962</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 285 010</ms:GML_ID>
        <ms:NAZWA>008 285 010</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008285010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271683.557674 572589.873643</gml:lowerCorner>
        		<gml:upperCorner>271683.557674 572589.873643</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271683.557674 572589.873643</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 283 103</ms:GML_ID>
        <ms:NAZWA>008 283 103</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008283103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272071.124817 572314.307916</gml:lowerCorner>
        		<gml:upperCorner>272071.124817 572314.307916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272071.124817 572314.307916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 282 649</ms:GML_ID>
        <ms:NAZWA>008 282 649</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008282649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272583.183230 572115.111805</gml:lowerCorner>
        		<gml:upperCorner>272583.183230 572115.111805</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272583.183230 572115.111805</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 282 090</ms:GML_ID>
        <ms:NAZWA>008 282 090</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008282090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273965.406712 571500.819520</gml:lowerCorner>
        		<gml:upperCorner>273965.406712 571500.819520</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273965.406712 571500.819520</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 280 570</ms:GML_ID>
        <ms:NAZWA>008 280 570</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008280570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275761.561891 571464.854611</gml:lowerCorner>
        		<gml:upperCorner>275761.561891 571464.854611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275761.561891 571464.854611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 278 566</ms:GML_ID>
        <ms:NAZWA>008 278 566</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>008278566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279664.532000 556257.790000</gml:lowerCorner>
        		<gml:upperCorner>279664.532000 556257.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279664.532000 556257.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 020 184</ms:GML_ID>
        <ms:NAZWA>062 020 184</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062020184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281407.587000 567366.452000</gml:lowerCorner>
        		<gml:upperCorner>281407.587000 567366.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281407.587000 567366.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 007 362</ms:GML_ID>
        <ms:NAZWA>062 007 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062007362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281428.333648 566181.674726</gml:lowerCorner>
        		<gml:upperCorner>281428.333648 566181.674726</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281428.333648 566181.674726</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 008 562</ms:GML_ID>
        <ms:NAZWA>062 008 562</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062008562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281646.809000 557856.466000</gml:lowerCorner>
        		<gml:upperCorner>281646.809000 557856.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281646.809000 557856.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 017 416</ms:GML_ID>
        <ms:NAZWA>062 017 416</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062017416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282230.496000 559269.696000</gml:lowerCorner>
        		<gml:upperCorner>282230.496000 559269.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282230.496000 559269.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 015 830</ms:GML_ID>
        <ms:NAZWA>062 015 830</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062015830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427275.344528 555356.243986</gml:lowerCorner>
        		<gml:upperCorner>427275.344528 555356.243986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427275.344528 555356.243986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 109 328</ms:GML_ID>
        <ms:NAZWA>001 109 328</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001109328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427947.331471 555556.861017</gml:lowerCorner>
        		<gml:upperCorner>427947.331471 555556.861017</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427947.331471 555556.861017</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 108 626</ms:GML_ID>
        <ms:NAZWA>001 108 626</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001108626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430508.710181 556278.576043</gml:lowerCorner>
        		<gml:upperCorner>430508.710181 556278.576043</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430508.710181 556278.576043</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 025 355</ms:GML_ID>
        <ms:NAZWA>017 025 355</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017025355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430121.585000 556474.080000</gml:lowerCorner>
        		<gml:upperCorner>430121.585000 556474.080000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430121.585000 556474.080000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.534 001 176</ms:GML_ID>
        <ms:NAZWA>534 001 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>534001176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432611.743000 557048.417000</gml:lowerCorner>
        		<gml:upperCorner>432611.743000 557048.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432611.743000 557048.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 103 724</ms:GML_ID>
        <ms:NAZWA>001 103 724</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001103724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433556.246000 557419.113000</gml:lowerCorner>
        		<gml:upperCorner>433556.246000 557419.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433556.246000 557419.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 102 708</ms:GML_ID>
        <ms:NAZWA>001 102 708</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001102708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434208.670000 557674.714000</gml:lowerCorner>
        		<gml:upperCorner>434208.670000 557674.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434208.670000 557674.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 102 004</ms:GML_ID>
        <ms:NAZWA>001 102 004</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001102004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436056.210000 558398.327000</gml:lowerCorner>
        		<gml:upperCorner>436056.210000 558398.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436056.210000 558398.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 100 020</ms:GML_ID>
        <ms:NAZWA>001 100 020</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001100020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436424.959000 558557.448000</gml:lowerCorner>
        		<gml:upperCorner>436424.959000 558557.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436424.959000 558557.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 099 619</ms:GML_ID>
        <ms:NAZWA>001 099 619</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001099619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439896.281000 561444.969000</gml:lowerCorner>
        		<gml:upperCorner>439896.281000 561444.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439896.281000 561444.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 095 099</ms:GML_ID>
        <ms:NAZWA>001 095 099</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001095099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425093.836000 562196.070000</gml:lowerCorner>
        		<gml:upperCorner>425093.836000 562196.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425093.836000 562196.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.044 004 040</ms:GML_ID>
        <ms:NAZWA>044 004 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>044004040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442026.261000 563179.761000</gml:lowerCorner>
        		<gml:upperCorner>442026.261000 563179.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442026.261000 563179.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 092 345</ms:GML_ID>
        <ms:NAZWA>001 092 345</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001092345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444516.282000 563548.299000</gml:lowerCorner>
        		<gml:upperCorner>444516.282000 563548.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444516.282000 563548.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 089 822</ms:GML_ID>
        <ms:NAZWA>001 089 822</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001089822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446651.839000 563830.356000</gml:lowerCorner>
        		<gml:upperCorner>446651.839000 563830.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446651.839000 563830.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 087 666</ms:GML_ID>
        <ms:NAZWA>001 087 666</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001087666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448710.759000 564193.757000</gml:lowerCorner>
        		<gml:upperCorner>448710.759000 564193.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448710.759000 564193.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 085 565</ms:GML_ID>
        <ms:NAZWA>001 085 565</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001085565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449194.113000 564870.016000</gml:lowerCorner>
        		<gml:upperCorner>449194.113000 564870.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449194.113000 564870.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 084 710</ms:GML_ID>
        <ms:NAZWA>001 084 710</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001084710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449343.971000 567705.786000</gml:lowerCorner>
        		<gml:upperCorner>449343.971000 567705.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449343.971000 567705.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 081 807</ms:GML_ID>
        <ms:NAZWA>001 081 807</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001081807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449798.361000 568167.622000</gml:lowerCorner>
        		<gml:upperCorner>449798.361000 568167.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449798.361000 568167.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 081 160</ms:GML_ID>
        <ms:NAZWA>001 081 160</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001081160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415638.244000 550474.866000</gml:lowerCorner>
        		<gml:upperCorner>415638.244000 550474.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415638.244000 550474.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 122 070</ms:GML_ID>
        <ms:NAZWA>001 122 070</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001122070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416775.715381 551071.005956</gml:lowerCorner>
        		<gml:upperCorner>416775.715381 551071.005956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416775.715381 551071.005956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 120 779</ms:GML_ID>
        <ms:NAZWA>001 120 779</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001120779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418669.215088 552288.501468</gml:lowerCorner>
        		<gml:upperCorner>418669.215088 552288.501468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418669.215088 552288.501468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 118 525</ms:GML_ID>
        <ms:NAZWA>001 118 525</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001118525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419942.739000 553110.164000</gml:lowerCorner>
        		<gml:upperCorner>419942.739000 553110.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419942.739000 553110.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 117 009</ms:GML_ID>
        <ms:NAZWA>001 117 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001117009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422498.317368 553930.466060</gml:lowerCorner>
        		<gml:upperCorner>422498.317368 553930.466060</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422498.317368 553930.466060</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 114 316</ms:GML_ID>
        <ms:NAZWA>001 114 316</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001114316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422234.964322 562365.215576</gml:lowerCorner>
        		<gml:upperCorner>422234.964322 562365.215576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422234.964322 562365.215576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 039 679</ms:GML_ID>
        <ms:NAZWA>025 039 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025039679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418866.508418 564664.378836</gml:lowerCorner>
        		<gml:upperCorner>418866.508418 564664.378836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418866.508418 564664.378836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 043 754</ms:GML_ID>
        <ms:NAZWA>025 043 754</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025043754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415631.073355 566863.811770</gml:lowerCorner>
        		<gml:upperCorner>415631.073355 566863.811770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415631.073355 566863.811770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 047 673</ms:GML_ID>
        <ms:NAZWA>025 047 673</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025047673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412535.028792 568986.292123</gml:lowerCorner>
        		<gml:upperCorner>412535.028792 568986.292123</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412535.028792 568986.292123</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 051 430</ms:GML_ID>
        <ms:NAZWA>025 051 430</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025051430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410483.983456 570140.019881</gml:lowerCorner>
        		<gml:upperCorner>410483.983456 570140.019881</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410483.983456 570140.019881</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 053 830</ms:GML_ID>
        <ms:NAZWA>025 053 830</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025053830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410273.959213 570554.579739</gml:lowerCorner>
        		<gml:upperCorner>410273.959213 570554.579739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410273.959213 570554.579739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 054 296</ms:GML_ID>
        <ms:NAZWA>025 054 296</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025054296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408678.397286 572085.206103</gml:lowerCorner>
        		<gml:upperCorner>408678.397286 572085.206103</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408678.397286 572085.206103</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 056 596</ms:GML_ID>
        <ms:NAZWA>025 056 596</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025056596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408974.571159 572970.722864</gml:lowerCorner>
        		<gml:upperCorner>408974.571159 572970.722864</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408974.571159 572970.722864</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 001 959</ms:GML_ID>
        <ms:NAZWA>053 001 959</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053001959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406787.884219 573148.172950</gml:lowerCorner>
        		<gml:upperCorner>406787.884219 573148.172950</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406787.884219 573148.172950</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 058 769</ms:GML_ID>
        <ms:NAZWA>025 058 769</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025058769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407127.898320 573232.232325</gml:lowerCorner>
        		<gml:upperCorner>407127.898320 573232.232325</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407127.898320 573232.232325</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.022 002 890</ms:GML_ID>
        <ms:NAZWA>022 002 890</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>022002890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405974.153436 573610.678929</gml:lowerCorner>
        		<gml:upperCorner>405974.153436 573610.678929</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405974.153436 573610.678929</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 059 704</ms:GML_ID>
        <ms:NAZWA>025 059 704</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025059704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409674.919735 573646.875625</gml:lowerCorner>
        		<gml:upperCorner>409674.919735 573646.875625</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409674.919735 573646.875625</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 002 944</ms:GML_ID>
        <ms:NAZWA>053 002 944</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053002944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409684.987248 573671.462689</gml:lowerCorner>
        		<gml:upperCorner>409684.987248 573671.462689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409684.987248 573671.462689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.053 002 971</ms:GML_ID>
        <ms:NAZWA>053 002 971</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>053002971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432644.196000 535493.175000</gml:lowerCorner>
        		<gml:upperCorner>432644.196000 535493.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432644.196000 535493.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.540 005 285</ms:GML_ID>
        <ms:NAZWA>540 005 285</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>540005285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447844.495000 535509.434000</gml:lowerCorner>
        		<gml:upperCorner>447844.495000 535509.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447844.495000 535509.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 048 520</ms:GML_ID>
        <ms:NAZWA>015 048 520</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015048520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434204.345381 535812.200898</gml:lowerCorner>
        		<gml:upperCorner>434204.345381 535812.200898</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434204.345381 535812.200898</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 002 045</ms:GML_ID>
        <ms:NAZWA>016 002 045</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016002045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448605.879000 535884.538000</gml:lowerCorner>
        		<gml:upperCorner>448605.879000 535884.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448605.879000 535884.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 047 655</ms:GML_ID>
        <ms:NAZWA>015 047 655</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015047655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433430.837970 536663.815217</gml:lowerCorner>
        		<gml:upperCorner>433430.837970 536663.815217</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433430.837970 536663.815217</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 000 896</ms:GML_ID>
        <ms:NAZWA>016 000 896</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016000896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449043.986000 537213.978000</gml:lowerCorner>
        		<gml:upperCorner>449043.986000 537213.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449043.986000 537213.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 046 182</ms:GML_ID>
        <ms:NAZWA>015 046 182</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015046182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433258.425757 537311.298132</gml:lowerCorner>
        		<gml:upperCorner>433258.425757 537311.298132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433258.425757 537311.298132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 005 067</ms:GML_ID>
        <ms:NAZWA>017 005 067</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017005067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449421.072000 537471.740000</gml:lowerCorner>
        		<gml:upperCorner>449421.072000 537471.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449421.072000 537471.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 045 720</ms:GML_ID>
        <ms:NAZWA>015 045 720</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015045720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428840.924453 537561.564894</gml:lowerCorner>
        		<gml:upperCorner>428840.924453 537561.564894</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428840.924453 537561.564894</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 011 140</ms:GML_ID>
        <ms:NAZWA>025 011 140</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025011140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449513.047000 538526.623000</gml:lowerCorner>
        		<gml:upperCorner>449513.047000 538526.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449513.047000 538526.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 044 627</ms:GML_ID>
        <ms:NAZWA>015 044 627</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015044627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428880.528854 538706.900518</gml:lowerCorner>
        		<gml:upperCorner>428880.528854 538706.900518</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428880.528854 538706.900518</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 012 270</ms:GML_ID>
        <ms:NAZWA>025 012 270</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025012270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432474.121000 539835.531000</gml:lowerCorner>
        		<gml:upperCorner>432474.121000 539835.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432474.121000 539835.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 007 709</ms:GML_ID>
        <ms:NAZWA>017 007 709</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017007709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449384.584743 539930.990391</gml:lowerCorner>
        		<gml:upperCorner>449384.584743 539930.990391</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449384.584743 539930.990391</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 043 221</ms:GML_ID>
        <ms:NAZWA>015 043 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015043221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449494.575173 540641.825112</gml:lowerCorner>
        		<gml:upperCorner>449494.575173 540641.825112</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449494.575173 540641.825112</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 042 495</ms:GML_ID>
        <ms:NAZWA>015 042 495</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015042495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432016.697000 540848.579000</gml:lowerCorner>
        		<gml:upperCorner>432016.697000 540848.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432016.697000 540848.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 008 834</ms:GML_ID>
        <ms:NAZWA>017 008 834</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017008834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449681.755591 541519.038973</gml:lowerCorner>
        		<gml:upperCorner>449681.755591 541519.038973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449681.755591 541519.038973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 041 590</ms:GML_ID>
        <ms:NAZWA>015 041 590</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015041590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429724.252297 541636.457815</gml:lowerCorner>
        		<gml:upperCorner>429724.252297 541636.457815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429724.252297 541636.457815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.830 015 230</ms:GML_ID>
        <ms:NAZWA>830 015 230</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>830015230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430704.233472 542313.086854</gml:lowerCorner>
        		<gml:upperCorner>430704.233472 542313.086854</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430704.233472 542313.086854</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.541 005 558</ms:GML_ID>
        <ms:NAZWA>541 005 558</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>541005558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430569.614402 542316.263591</gml:lowerCorner>
        		<gml:upperCorner>430569.614402 542316.263591</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430569.614402 542316.263591</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.541 005 696</ms:GML_ID>
        <ms:NAZWA>541 005 696</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>541005696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430813.850092 542415.898584</gml:lowerCorner>
        		<gml:upperCorner>430813.850092 542415.898584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430813.850092 542415.898584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 010 813</ms:GML_ID>
        <ms:NAZWA>017 010 813</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017010813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450537.107288 542432.671938</gml:lowerCorner>
        		<gml:upperCorner>450537.107288 542432.671938</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450537.107288 542432.671938</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 040 313</ms:GML_ID>
        <ms:NAZWA>015 040 313</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015040313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429861.467000 543108.831000</gml:lowerCorner>
        		<gml:upperCorner>429861.467000 543108.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429861.467000 543108.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 016 810</ms:GML_ID>
        <ms:NAZWA>025 016 810</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025016810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429805.084000 543474.634000</gml:lowerCorner>
        		<gml:upperCorner>429805.084000 543474.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429805.084000 543474.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 017 179</ms:GML_ID>
        <ms:NAZWA>025 017 179</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025017179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430021.639000 543654.249000</gml:lowerCorner>
        		<gml:upperCorner>430021.639000 543654.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430021.639000 543654.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 012 284</ms:GML_ID>
        <ms:NAZWA>017 012 284</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017012284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429566.181000 547306.585000</gml:lowerCorner>
        		<gml:upperCorner>429566.181000 547306.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429566.181000 547306.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 016 046</ms:GML_ID>
        <ms:NAZWA>017 016 046</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017016046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429341.777000 552015.647000</gml:lowerCorner>
        		<gml:upperCorner>429341.777000 552015.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429341.777000 552015.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 020 831</ms:GML_ID>
        <ms:NAZWA>017 020 831</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017020831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429431.135000 553159.740000</gml:lowerCorner>
        		<gml:upperCorner>429431.135000 553159.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429431.135000 553159.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 022 005</ms:GML_ID>
        <ms:NAZWA>017 022 005</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017022005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429568.478000 554391.297000</gml:lowerCorner>
        		<gml:upperCorner>429568.478000 554391.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429568.478000 554391.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 028 275</ms:GML_ID>
        <ms:NAZWA>025 028 275</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025028275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429498.699000 554597.058000</gml:lowerCorner>
        		<gml:upperCorner>429498.699000 554597.058000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429498.699000 554597.058000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 028 490</ms:GML_ID>
        <ms:NAZWA>025 028 490</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025028490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429824.570000 554606.510000</gml:lowerCorner>
        		<gml:upperCorner>429824.570000 554606.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429824.570000 554606.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 023 506</ms:GML_ID>
        <ms:NAZWA>017 023 506</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017023506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425782.299000 554910.769000</gml:lowerCorner>
        		<gml:upperCorner>425782.299000 554910.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425782.299000 554910.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 110 887</ms:GML_ID>
        <ms:NAZWA>001 110 887</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001110887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430059.603000 555468.797000</gml:lowerCorner>
        		<gml:upperCorner>430059.603000 555468.797000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430059.603000 555468.797000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.017 024 400</ms:GML_ID>
        <ms:NAZWA>017 024 400</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>017024400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429510.116000 556468.266000</gml:lowerCorner>
        		<gml:upperCorner>429510.116000 556468.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429510.116000 556468.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.536 001 786</ms:GML_ID>
        <ms:NAZWA>536 001 786</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>536001786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426180.209861 560046.182439</gml:lowerCorner>
        		<gml:upperCorner>426180.209861 560046.182439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426180.209861 560046.182439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 035 070</ms:GML_ID>
        <ms:NAZWA>025 035 070</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025035070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322117.702000 534226.927000</gml:lowerCorner>
        		<gml:upperCorner>322117.702000 534226.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322117.702000 534226.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 087 021</ms:GML_ID>
        <ms:NAZWA>061 087 021</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061087021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322119.018651 537215.593253</gml:lowerCorner>
        		<gml:upperCorner>322119.018651 537215.593253</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322119.018651 537215.593253</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 083 989</ms:GML_ID>
        <ms:NAZWA>061 083 989</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061083989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323607.296000 547388.375000</gml:lowerCorner>
        		<gml:upperCorner>323607.296000 547388.375000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323607.296000 547388.375000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 073 439</ms:GML_ID>
        <ms:NAZWA>061 073 439</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061073439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323386.746000 548153.501000</gml:lowerCorner>
        		<gml:upperCorner>323386.746000 548153.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323386.746000 548153.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 072 642</ms:GML_ID>
        <ms:NAZWA>061 072 642</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061072642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323298.063000 548567.315000</gml:lowerCorner>
        		<gml:upperCorner>323298.063000 548567.315000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323298.063000 548567.315000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 072 205</ms:GML_ID>
        <ms:NAZWA>061 072 205</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061072205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323778.501000 550414.202000</gml:lowerCorner>
        		<gml:upperCorner>323778.501000 550414.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323778.501000 550414.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 070 296</ms:GML_ID>
        <ms:NAZWA>061 070 296</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061070296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320385.803000 553822.001000</gml:lowerCorner>
        		<gml:upperCorner>320385.803000 553822.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320385.803000 553822.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 037 423</ms:GML_ID>
        <ms:NAZWA>064 037 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064037423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325461.861000 554417.244000</gml:lowerCorner>
        		<gml:upperCorner>325461.861000 554417.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325461.861000 554417.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 065 902</ms:GML_ID>
        <ms:NAZWA>061 065 902</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061065902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319335.020000 554806.035000</gml:lowerCorner>
        		<gml:upperCorner>319335.020000 554806.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319335.020000 554806.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 035 981</ms:GML_ID>
        <ms:NAZWA>064 035 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064035981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318399.947000 555601.838000</gml:lowerCorner>
        		<gml:upperCorner>318399.947000 555601.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318399.947000 555601.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 034 751</ms:GML_ID>
        <ms:NAZWA>064 034 751</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064034751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310554.543000 558077.958000</gml:lowerCorner>
        		<gml:upperCorner>310554.543000 558077.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310554.543000 558077.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 026 430</ms:GML_ID>
        <ms:NAZWA>064 026 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064026430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326573.061547 560272.041484</gml:lowerCorner>
        		<gml:upperCorner>326573.061547 560272.041484</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326573.061547 560272.041484</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 059 899</ms:GML_ID>
        <ms:NAZWA>061 059 899</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061059899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305606.758000 561317.432000</gml:lowerCorner>
        		<gml:upperCorner>305606.758000 561317.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305606.758000 561317.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 020 340</ms:GML_ID>
        <ms:NAZWA>064 020 340</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064020340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327211.402518 561659.549132</gml:lowerCorner>
        		<gml:upperCorner>327211.402518 561659.549132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327211.402518 561659.549132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 058 367</ms:GML_ID>
        <ms:NAZWA>061 058 367</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061058367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304488.793000 562073.794000</gml:lowerCorner>
        		<gml:upperCorner>304488.793000 562073.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304488.793000 562073.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.064 018 975</ms:GML_ID>
        <ms:NAZWA>064 018 975</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>064018975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328141.469000 563630.938000</gml:lowerCorner>
        		<gml:upperCorner>328141.469000 563630.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328141.469000 563630.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 056 129</ms:GML_ID>
        <ms:NAZWA>061 056 129</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061056129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328310.828000 565069.078000</gml:lowerCorner>
        		<gml:upperCorner>328310.828000 565069.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328310.828000 565069.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.571 001 551</ms:GML_ID>
        <ms:NAZWA>571 001 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>571001551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328984.430000 566612.831000</gml:lowerCorner>
        		<gml:upperCorner>328984.430000 566612.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328984.430000 566612.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 052 984</ms:GML_ID>
        <ms:NAZWA>061 052 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061052984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329107.379000 567372.784000</gml:lowerCorner>
        		<gml:upperCorner>329107.379000 567372.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329107.379000 567372.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 052 205</ms:GML_ID>
        <ms:NAZWA>061 052 205</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>061052205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305482.020000 583214.902000</gml:lowerCorner>
        		<gml:upperCorner>305482.020000 583214.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305482.020000 583214.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.008 239 922</ms:GML_ID>
        <ms:NAZWA>008 239 922</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>008239922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387719.086000 533780.334000</gml:lowerCorner>
        		<gml:upperCorner>387719.086000 533780.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387719.086000 533780.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 018 706</ms:GML_ID>
        <ms:NAZWA>024 018 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024018706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387161.867977 538768.191127</gml:lowerCorner>
        		<gml:upperCorner>387161.867977 538768.191127</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387161.867977 538768.191127</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 013 659</ms:GML_ID>
        <ms:NAZWA>024 013 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024013659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387760.192034 547026.033222</gml:lowerCorner>
        		<gml:upperCorner>387760.192034 547026.033222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387760.192034 547026.033222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 150 510</ms:GML_ID>
        <ms:NAZWA>001 150 510</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001150510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388679.602696 547112.623312</gml:lowerCorner>
        		<gml:upperCorner>388679.602696 547112.623312</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388679.602696 547112.623312</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 149 586</ms:GML_ID>
        <ms:NAZWA>001 149 586</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001149586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389871.230908 547224.105072</gml:lowerCorner>
        		<gml:upperCorner>389871.230908 547224.105072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389871.230908 547224.105072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 148 388</ms:GML_ID>
        <ms:NAZWA>001 148 388</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001148388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392017.758284 547425.385404</gml:lowerCorner>
        		<gml:upperCorner>392017.758284 547425.385404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392017.758284 547425.385404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 146 232</ms:GML_ID>
        <ms:NAZWA>001 146 232</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001146232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393848.435000 547595.786000</gml:lowerCorner>
        		<gml:upperCorner>393848.435000 547595.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393848.435000 547595.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 144 391</ms:GML_ID>
        <ms:NAZWA>001 144 391</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001144391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395420.421512 547744.209080</gml:lowerCorner>
        		<gml:upperCorner>395420.421512 547744.209080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395420.421512 547744.209080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 142 811</ms:GML_ID>
        <ms:NAZWA>001 142 811</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001142811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399666.697207 548136.485605</gml:lowerCorner>
        		<gml:upperCorner>399666.697207 548136.485605</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399666.697207 548136.485605</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 138 544</ms:GML_ID>
        <ms:NAZWA>001 138 544</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001138544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402941.510921 548422.256899</gml:lowerCorner>
        		<gml:upperCorner>402941.510921 548422.256899</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402941.510921 548422.256899</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 135 255</ms:GML_ID>
        <ms:NAZWA>001 135 255</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001135255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404233.378096 548566.608880</gml:lowerCorner>
        		<gml:upperCorner>404233.378096 548566.608880</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404233.378096 548566.608880</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 133 955</ms:GML_ID>
        <ms:NAZWA>001 133 955</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001133955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405836.856799 549040.169255</gml:lowerCorner>
        		<gml:upperCorner>405836.856799 549040.169255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405836.856799 549040.169255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 132 280</ms:GML_ID>
        <ms:NAZWA>001 132 280</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001132280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407364.932714 549490.206595</gml:lowerCorner>
        		<gml:upperCorner>407364.932714 549490.206595</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407364.932714 549490.206595</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 130 686</ms:GML_ID>
        <ms:NAZWA>001 130 686</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001130686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408193.450000 549731.284000</gml:lowerCorner>
        		<gml:upperCorner>408193.450000 549731.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408193.450000 549731.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 129 828</ms:GML_ID>
        <ms:NAZWA>001 129 828</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001129828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413246.151436 549866.483589</gml:lowerCorner>
        		<gml:upperCorner>413246.151436 549866.483589</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413246.151436 549866.483589</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 124 549</ms:GML_ID>
        <ms:NAZWA>001 124 549</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001124549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414226.981000 550063.485000</gml:lowerCorner>
        		<gml:upperCorner>414226.981000 550063.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414226.981000 550063.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 123 541</ms:GML_ID>
        <ms:NAZWA>001 123 541</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001123541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412028.693621 550252.661607</gml:lowerCorner>
        		<gml:upperCorner>412028.693621 550252.661607</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412028.693621 550252.661607</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 125 825</ms:GML_ID>
        <ms:NAZWA>001 125 825</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001125825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410475.482910 550406.985796</gml:lowerCorner>
        		<gml:upperCorner>410475.482910 550406.985796</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410475.482910 550406.985796</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 127 441</ms:GML_ID>
        <ms:NAZWA>001 127 441</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001127441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445094.531502 525179.082343</gml:lowerCorner>
        		<gml:upperCorner>445094.531502 525179.082343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445094.531502 525179.082343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 019 683</ms:GML_ID>
        <ms:NAZWA>016 019 683</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016019683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444844.748620 526359.650384</gml:lowerCorner>
        		<gml:upperCorner>444844.748620 526359.650384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444844.748620 526359.650384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 018 474</ms:GML_ID>
        <ms:NAZWA>016 018 474</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016018474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429706.160014 526364.365589</gml:lowerCorner>
        		<gml:upperCorner>429706.160014 526364.365589</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429706.160014 526364.365589</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 004 883</ms:GML_ID>
        <ms:NAZWA>014 004 883</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014004883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444712.505322 527020.896292</gml:lowerCorner>
        		<gml:upperCorner>444712.505322 527020.896292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444712.505322 527020.896292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 017 797</ms:GML_ID>
        <ms:NAZWA>016 017 797</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016017797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430176.148104 527346.815424</gml:lowerCorner>
        		<gml:upperCorner>430176.148104 527346.815424</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430176.148104 527346.815424</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 003 794</ms:GML_ID>
        <ms:NAZWA>014 003 794</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014003794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438873.062265 528352.071700</gml:lowerCorner>
        		<gml:upperCorner>438873.062265 528352.071700</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438873.062265 528352.071700</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 061 527</ms:GML_ID>
        <ms:NAZWA>015 061 527</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015061527</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435125.198237 528553.197328</gml:lowerCorner>
        		<gml:upperCorner>435125.198237 528553.197328</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435125.198237 528553.197328</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 065 486</ms:GML_ID>
        <ms:NAZWA>015 065 486</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015065486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430772.628457 528593.899579</gml:lowerCorner>
        		<gml:upperCorner>430772.628457 528593.899579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430772.628457 528593.899579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 002 412</ms:GML_ID>
        <ms:NAZWA>014 002 412</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014002412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440892.930229 528684.507749</gml:lowerCorner>
        		<gml:upperCorner>440892.930229 528684.507749</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440892.930229 528684.507749</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 059 435</ms:GML_ID>
        <ms:NAZWA>015 059 435</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015059435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440120.218000 528734.303000</gml:lowerCorner>
        		<gml:upperCorner>440120.218000 528734.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440120.218000 528734.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 060 213</ms:GML_ID>
        <ms:NAZWA>015 060 213</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015060213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444325.786000 528992.329000</gml:lowerCorner>
        		<gml:upperCorner>444325.786000 528992.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444325.786000 528992.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 015 700</ms:GML_ID>
        <ms:NAZWA>016 015 700</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016015700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442139.654659 529001.825186</gml:lowerCorner>
        		<gml:upperCorner>442139.654659 529001.825186</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442139.654659 529001.825186</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 058 104</ms:GML_ID>
        <ms:NAZWA>015 058 104</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015058104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441148.006545 529347.916815</gml:lowerCorner>
        		<gml:upperCorner>441148.006545 529347.916815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441148.006545 529347.916815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 011 952</ms:GML_ID>
        <ms:NAZWA>016 011 952</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016011952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431391.771928 529573.267033</gml:lowerCorner>
        		<gml:upperCorner>431391.771928 529573.267033</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431391.771928 529573.267033</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 001 240</ms:GML_ID>
        <ms:NAZWA>014 001 240</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014001240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443472.527066 529620.277546</gml:lowerCorner>
        		<gml:upperCorner>443472.527066 529620.277546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443472.527066 529620.277546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 014 617</ms:GML_ID>
        <ms:NAZWA>016 014 617</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016014617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431118.273030 530004.207195</gml:lowerCorner>
        		<gml:upperCorner>431118.273030 530004.207195</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431118.273030 530004.207195</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.539 000 310</ms:GML_ID>
        <ms:NAZWA>539 000 310</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>539000310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443892.515413 530037.291471</gml:lowerCorner>
        		<gml:upperCorner>443892.515413 530037.291471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443892.515413 530037.291471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 056 064</ms:GML_ID>
        <ms:NAZWA>015 056 064</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015056064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431145.855488 530069.842115</gml:lowerCorner>
        		<gml:upperCorner>431145.855488 530069.842115</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431145.855488 530069.842115</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 001 503</ms:GML_ID>
        <ms:NAZWA>025 001 503</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025001503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440378.677090 530257.230853</gml:lowerCorner>
        		<gml:upperCorner>440378.677090 530257.230853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440378.677090 530257.230853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 010 769</ms:GML_ID>
        <ms:NAZWA>016 010 769</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016010769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440057.470194 530636.584497</gml:lowerCorner>
        		<gml:upperCorner>440057.470194 530636.584497</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440057.470194 530636.584497</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 010 264</ms:GML_ID>
        <ms:NAZWA>016 010 264</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016010264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438695.856044 531640.133645</gml:lowerCorner>
        		<gml:upperCorner>438695.856044 531640.133645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438695.856044 531640.133645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 008 554</ms:GML_ID>
        <ms:NAZWA>016 008 554</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016008554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428477.754237 532017.969130</gml:lowerCorner>
        		<gml:upperCorner>428477.754237 532017.969130</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428477.754237 532017.969130</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 005 281</ms:GML_ID>
        <ms:NAZWA>025 005 281</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025005281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444585.682136 532033.735758</gml:lowerCorner>
        		<gml:upperCorner>444585.682136 532033.735758</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444585.682136 532033.735758</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 053 880</ms:GML_ID>
        <ms:NAZWA>015 053 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015053880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445808.194027 532233.242380</gml:lowerCorner>
        		<gml:upperCorner>445808.194027 532233.242380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445808.194027 532233.242380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 052 586</ms:GML_ID>
        <ms:NAZWA>015 052 586</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015052586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428989.162595 532608.487847</gml:lowerCorner>
        		<gml:upperCorner>428989.162595 532608.487847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428989.162595 532608.487847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 006 064</ms:GML_ID>
        <ms:NAZWA>025 006 064</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025006064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446150.038000 532769.701000</gml:lowerCorner>
        		<gml:upperCorner>446150.038000 532769.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446150.038000 532769.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 051 941</ms:GML_ID>
        <ms:NAZWA>015 051 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015051941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446342.596224 533082.935252</gml:lowerCorner>
        		<gml:upperCorner>446342.596224 533082.935252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446342.596224 533082.935252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 051 572</ms:GML_ID>
        <ms:NAZWA>015 051 572</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015051572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429021.344354 533188.223812</gml:lowerCorner>
        		<gml:upperCorner>429021.344354 533188.223812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429021.344354 533188.223812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 006 657</ms:GML_ID>
        <ms:NAZWA>025 006 657</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025006657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429064.885825 533193.008603</gml:lowerCorner>
        		<gml:upperCorner>429064.885825 533193.008603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429064.885825 533193.008603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 006 658</ms:GML_ID>
        <ms:NAZWA>025 006 658</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025006658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446513.998000 533545.677000</gml:lowerCorner>
        		<gml:upperCorner>446513.998000 533545.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446513.998000 533545.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 051 077</ms:GML_ID>
        <ms:NAZWA>015 051 077</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015051077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446812.605258 534081.851663</gml:lowerCorner>
        		<gml:upperCorner>446812.605258 534081.851663</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446812.605258 534081.851663</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.015 050 457</ms:GML_ID>
        <ms:NAZWA>015 050 457</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>015050457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428889.072231 534189.752939</gml:lowerCorner>
        		<gml:upperCorner>428889.072231 534189.752939</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428889.072231 534189.752939</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 007 669</ms:GML_ID>
        <ms:NAZWA>025 007 669</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>025007669</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429155.495000 535070.125000</gml:lowerCorner>
        		<gml:upperCorner>429155.495000 535070.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429155.495000 535070.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.540 001 749</ms:GML_ID>
        <ms:NAZWA>540 001 749</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>540001749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324246.297757 508313.939180</gml:lowerCorner>
        		<gml:upperCorner>324246.297757 508313.939180</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324246.297757 508313.939180</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 115 430</ms:GML_ID>
        <ms:NAZWA>061 115 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061115430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323375.130000 508782.753000</gml:lowerCorner>
        		<gml:upperCorner>323375.130000 508782.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323375.130000 508782.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 114 376</ms:GML_ID>
        <ms:NAZWA>061 114 376</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061114376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328377.477000 508876.847000</gml:lowerCorner>
        		<gml:upperCorner>328377.477000 508876.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328377.477000 508876.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 228 157</ms:GML_ID>
        <ms:NAZWA>001 228 157</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001228157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323163.714000 508968.579000</gml:lowerCorner>
        		<gml:upperCorner>323163.714000 508968.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323163.714000 508968.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 114 095</ms:GML_ID>
        <ms:NAZWA>061 114 095</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061114095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328783.815000 509298.085000</gml:lowerCorner>
        		<gml:upperCorner>328783.815000 509298.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328783.815000 509298.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 227 571</ms:GML_ID>
        <ms:NAZWA>001 227 571</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001227571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329134.457000 509758.716000</gml:lowerCorner>
        		<gml:upperCorner>329134.457000 509758.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329134.457000 509758.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 226 992</ms:GML_ID>
        <ms:NAZWA>001 226 992</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001226992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325185.575900 510078.249522</gml:lowerCorner>
        		<gml:upperCorner>325185.575900 510078.249522</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325185.575900 510078.249522</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 232 400</ms:GML_ID>
        <ms:NAZWA>001 232 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001232400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329756.519000 510576.619000</gml:lowerCorner>
        		<gml:upperCorner>329756.519000 510576.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329756.519000 510576.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 225 962</ms:GML_ID>
        <ms:NAZWA>001 225 962</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001225962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330769.883000 511221.327000</gml:lowerCorner>
        		<gml:upperCorner>330769.883000 511221.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330769.883000 511221.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 224 733</ms:GML_ID>
        <ms:NAZWA>001 224 733</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001224733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331408.709000 511479.471000</gml:lowerCorner>
        		<gml:upperCorner>331408.709000 511479.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331408.709000 511479.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 224 045</ms:GML_ID>
        <ms:NAZWA>001 224 045</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001224045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322283.017000 511934.085000</gml:lowerCorner>
        		<gml:upperCorner>322283.017000 511934.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322283.017000 511934.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 235 958</ms:GML_ID>
        <ms:NAZWA>001 235 958</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001235958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334186.743000 512112.868000</gml:lowerCorner>
        		<gml:upperCorner>334186.743000 512112.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334186.743000 512112.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 001 719</ms:GML_ID>
        <ms:NAZWA>146 001 719</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146001719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333894.227000 512209.579000</gml:lowerCorner>
        		<gml:upperCorner>333894.227000 512209.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333894.227000 512209.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 001 377</ms:GML_ID>
        <ms:NAZWA>146 001 377</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146001377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334264.955000 515087.700000</gml:lowerCorner>
        		<gml:upperCorner>334264.955000 515087.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334264.955000 515087.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 218 996</ms:GML_ID>
        <ms:NAZWA>001 218 996</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001218996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323257.985000 517590.502000</gml:lowerCorner>
        		<gml:upperCorner>323257.985000 517590.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323257.985000 517590.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 105 096</ms:GML_ID>
        <ms:NAZWA>061 105 096</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061105096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323462.270000 519297.375000</gml:lowerCorner>
        		<gml:upperCorner>323462.270000 519297.375000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323462.270000 519297.375000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 103 342</ms:GML_ID>
        <ms:NAZWA>061 103 342</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061103342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323003.511000 521137.253000</gml:lowerCorner>
        		<gml:upperCorner>323003.511000 521137.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323003.511000 521137.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 101 263</ms:GML_ID>
        <ms:NAZWA>061 101 263</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061101263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336192.155000 521375.201000</gml:lowerCorner>
        		<gml:upperCorner>336192.155000 521375.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336192.155000 521375.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 212 418</ms:GML_ID>
        <ms:NAZWA>001 212 418</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001212418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323036.589000 521791.850000</gml:lowerCorner>
        		<gml:upperCorner>323036.589000 521791.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323036.589000 521791.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 100 603</ms:GML_ID>
        <ms:NAZWA>061 100 603</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061100603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322560.833495 522297.677294</gml:lowerCorner>
        		<gml:upperCorner>322560.833495 522297.677294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322560.833495 522297.677294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 099 888</ms:GML_ID>
        <ms:NAZWA>061 099 888</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061099888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322076.168000 533651.980000</gml:lowerCorner>
        		<gml:upperCorner>322076.168000 533651.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322076.168000 533651.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 087 596</ms:GML_ID>
        <ms:NAZWA>061 087 596</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061087596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322306.676000 535070.550000</gml:lowerCorner>
        		<gml:upperCorner>322306.676000 535070.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322306.676000 535070.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 086 156</ms:GML_ID>
        <ms:NAZWA>061 086 156</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061086156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322011.756550 538011.309681</gml:lowerCorner>
        		<gml:upperCorner>322011.756550 538011.309681</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322011.756550 538011.309681</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 083 186</ms:GML_ID>
        <ms:NAZWA>061 083 186</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061083186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322055.531174 539655.849078</gml:lowerCorner>
        		<gml:upperCorner>322055.531174 539655.849078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322055.531174 539655.849078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 081 538</ms:GML_ID>
        <ms:NAZWA>061 081 538</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061081538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321928.340000 541151.453000</gml:lowerCorner>
        		<gml:upperCorner>321928.340000 541151.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321928.340000 541151.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 080 016</ms:GML_ID>
        <ms:NAZWA>061 080 016</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061080016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322201.140000 543254.323000</gml:lowerCorner>
        		<gml:upperCorner>322201.140000 543254.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322201.140000 543254.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 077 878</ms:GML_ID>
        <ms:NAZWA>061 077 878</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061077878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323044.642000 546051.863000</gml:lowerCorner>
        		<gml:upperCorner>323044.642000 546051.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323044.642000 546051.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 074 899</ms:GML_ID>
        <ms:NAZWA>061 074 899</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061074899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223648.256683 533071.422434</gml:lowerCorner>
        		<gml:upperCorner>223648.256683 533071.422434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223648.256683 533071.422434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 021 149</ms:GML_ID>
        <ms:NAZWA>117 021 149</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117021149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232055.486000 533308.277000</gml:lowerCorner>
        		<gml:upperCorner>232055.486000 533308.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232055.486000 533308.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 029 272</ms:GML_ID>
        <ms:NAZWA>103 029 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103029272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231830.959704 533451.717730</gml:lowerCorner>
        		<gml:upperCorner>231830.959704 533451.717730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231830.959704 533451.717730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 029 539</ms:GML_ID>
        <ms:NAZWA>103 029 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103029539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224394.711000 533983.214000</gml:lowerCorner>
        		<gml:upperCorner>224394.711000 533983.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224394.711000 533983.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 019 928</ms:GML_ID>
        <ms:NAZWA>117 019 928</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117019928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230860.954000 534068.536000</gml:lowerCorner>
        		<gml:upperCorner>230860.954000 534068.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230860.954000 534068.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 030 688</ms:GML_ID>
        <ms:NAZWA>103 030 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103030688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230248.495000 534458.205000</gml:lowerCorner>
        		<gml:upperCorner>230248.495000 534458.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230248.495000 534458.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 031 417</ms:GML_ID>
        <ms:NAZWA>103 031 417</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103031417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224568.511000 534521.526000</gml:lowerCorner>
        		<gml:upperCorner>224568.511000 534521.526000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224568.511000 534521.526000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 019 368</ms:GML_ID>
        <ms:NAZWA>117 019 368</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117019368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229934.201627 534658.590171</gml:lowerCorner>
        		<gml:upperCorner>229934.201627 534658.590171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229934.201627 534658.590171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 031 789</ms:GML_ID>
        <ms:NAZWA>103 031 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103031789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227982.448000 534761.069000</gml:lowerCorner>
        		<gml:upperCorner>227982.448000 534761.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227982.448000 534761.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 033 770</ms:GML_ID>
        <ms:NAZWA>103 033 770</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103033770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229708.335000 534763.861000</gml:lowerCorner>
        		<gml:upperCorner>229708.335000 534763.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229708.335000 534763.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 032 041</ms:GML_ID>
        <ms:NAZWA>103 032 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103032041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228911.088000 534763.904000</gml:lowerCorner>
        		<gml:upperCorner>228911.088000 534763.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228911.088000 534763.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 032 840</ms:GML_ID>
        <ms:NAZWA>103 032 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103032840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227428.385000 534833.110000</gml:lowerCorner>
        		<gml:upperCorner>227428.385000 534833.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227428.385000 534833.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 034 333</ms:GML_ID>
        <ms:NAZWA>103 034 333</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103034333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227098.952344 534926.769535</gml:lowerCorner>
        		<gml:upperCorner>227098.952344 534926.769535</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227098.952344 534926.769535</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 034 675</ms:GML_ID>
        <ms:NAZWA>103 034 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103034675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226833.266000 535002.489000</gml:lowerCorner>
        		<gml:upperCorner>226833.266000 535002.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226833.266000 535002.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 034 953</ms:GML_ID>
        <ms:NAZWA>103 034 953</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103034953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224866.263469 535268.181819</gml:lowerCorner>
        		<gml:upperCorner>224866.263469 535268.181819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224866.263469 535268.181819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 018 557</ms:GML_ID>
        <ms:NAZWA>117 018 557</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117018557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226078.307625 535273.127347</gml:lowerCorner>
        		<gml:upperCorner>226078.307625 535273.127347</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226078.307625 535273.127347</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 035 756</ms:GML_ID>
        <ms:NAZWA>103 035 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103035756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224130.760623 536152.105684</gml:lowerCorner>
        		<gml:upperCorner>224130.760623 536152.105684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224130.760623 536152.105684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 017 282</ms:GML_ID>
        <ms:NAZWA>117 017 282</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117017282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223445.693000 537004.350000</gml:lowerCorner>
        		<gml:upperCorner>223445.693000 537004.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223445.693000 537004.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 016 130</ms:GML_ID>
        <ms:NAZWA>117 016 130</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117016130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222461.388414 539290.258207</gml:lowerCorner>
        		<gml:upperCorner>222461.388414 539290.258207</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222461.388414 539290.258207</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 012 827</ms:GML_ID>
        <ms:NAZWA>117 012 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117012827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222402.055569 539426.035777</gml:lowerCorner>
        		<gml:upperCorner>222402.055569 539426.035777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222402.055569 539426.035777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 012 679</ms:GML_ID>
        <ms:NAZWA>117 012 679</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117012679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222386.459477 539567.072502</gml:lowerCorner>
        		<gml:upperCorner>222386.459477 539567.072502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222386.459477 539567.072502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 012 536</ms:GML_ID>
        <ms:NAZWA>117 012 536</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117012536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222175.743000 541058.004000</gml:lowerCorner>
        		<gml:upperCorner>222175.743000 541058.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222175.743000 541058.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 010 961</ms:GML_ID>
        <ms:NAZWA>117 010 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117010961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221963.975737 541521.475282</gml:lowerCorner>
        		<gml:upperCorner>221963.975737 541521.475282</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221963.975737 541521.475282</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 010 428</ms:GML_ID>
        <ms:NAZWA>117 010 428</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117010428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222923.261303 541862.309584</gml:lowerCorner>
        		<gml:upperCorner>222923.261303 541862.309584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222923.261303 541862.309584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 009 127</ms:GML_ID>
        <ms:NAZWA>117 009 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117009127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238385.733000 535978.381000</gml:lowerCorner>
        		<gml:upperCorner>238385.733000 535978.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238385.733000 535978.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 020 635</ms:GML_ID>
        <ms:NAZWA>103 020 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103020635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238698.110727 536098.024489</gml:lowerCorner>
        		<gml:upperCorner>238698.110727 536098.024489</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238698.110727 536098.024489</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 020 299</ms:GML_ID>
        <ms:NAZWA>103 020 299</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103020299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238921.525980 536155.009376</gml:lowerCorner>
        		<gml:upperCorner>238921.525980 536155.009376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238921.525980 536155.009376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 020 070</ms:GML_ID>
        <ms:NAZWA>103 020 070</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103020070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239639.613000 536337.293000</gml:lowerCorner>
        		<gml:upperCorner>239639.613000 536337.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239639.613000 536337.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 019 327</ms:GML_ID>
        <ms:NAZWA>103 019 327</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103019327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240619.442710 537435.317428</gml:lowerCorner>
        		<gml:upperCorner>240619.442710 537435.317428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240619.442710 537435.317428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 017 831</ms:GML_ID>
        <ms:NAZWA>103 017 831</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103017831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240900.498276 537921.509742</gml:lowerCorner>
        		<gml:upperCorner>240900.498276 537921.509742</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240900.498276 537921.509742</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 017 260</ms:GML_ID>
        <ms:NAZWA>103 017 260</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103017260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241509.496989 538067.587651</gml:lowerCorner>
        		<gml:upperCorner>241509.496989 538067.587651</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241509.496989 538067.587651</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 016 592</ms:GML_ID>
        <ms:NAZWA>103 016 592</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103016592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243164.181483 537481.279982</gml:lowerCorner>
        		<gml:upperCorner>243164.181483 537481.279982</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243164.181483 537481.279982</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 014 819</ms:GML_ID>
        <ms:NAZWA>103 014 819</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103014819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244052.676000 537747.910000</gml:lowerCorner>
        		<gml:upperCorner>244052.676000 537747.910000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244052.676000 537747.910000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 013 875</ms:GML_ID>
        <ms:NAZWA>103 013 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103013875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244628.588179 537855.571202</gml:lowerCorner>
        		<gml:upperCorner>244628.588179 537855.571202</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244628.588179 537855.571202</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 013 288</ms:GML_ID>
        <ms:NAZWA>103 013 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103013288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245283.838227 538022.790917</gml:lowerCorner>
        		<gml:upperCorner>245283.838227 538022.790917</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245283.838227 538022.790917</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 012 603</ms:GML_ID>
        <ms:NAZWA>103 012 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103012603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246103.382000 537721.674000</gml:lowerCorner>
        		<gml:upperCorner>246103.382000 537721.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246103.382000 537721.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 011 705</ms:GML_ID>
        <ms:NAZWA>103 011 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103011705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246242.072000 537820.987000</gml:lowerCorner>
        		<gml:upperCorner>246242.072000 537820.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246242.072000 537820.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 011 532</ms:GML_ID>
        <ms:NAZWA>103 011 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103011532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246352.531000 537981.206000</gml:lowerCorner>
        		<gml:upperCorner>246352.531000 537981.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246352.531000 537981.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 011 321</ms:GML_ID>
        <ms:NAZWA>103 011 321</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103011321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246754.970000 538200.114000</gml:lowerCorner>
        		<gml:upperCorner>246754.970000 538200.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246754.970000 538200.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 010 858</ms:GML_ID>
        <ms:NAZWA>103 010 858</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103010858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247191.776000 537981.517000</gml:lowerCorner>
        		<gml:upperCorner>247191.776000 537981.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247191.776000 537981.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 010 355</ms:GML_ID>
        <ms:NAZWA>103 010 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103010355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247346.089000 537881.129000</gml:lowerCorner>
        		<gml:upperCorner>247346.089000 537881.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247346.089000 537881.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 010 173</ms:GML_ID>
        <ms:NAZWA>103 010 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103010173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247888.615694 537772.707468</gml:lowerCorner>
        		<gml:upperCorner>247888.615694 537772.707468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247888.615694 537772.707468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 009 585</ms:GML_ID>
        <ms:NAZWA>103 009 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103009585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248149.210000 537599.405000</gml:lowerCorner>
        		<gml:upperCorner>248149.210000 537599.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248149.210000 537599.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 009 258</ms:GML_ID>
        <ms:NAZWA>103 009 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103009258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248236.780000 537315.213000</gml:lowerCorner>
        		<gml:upperCorner>248236.780000 537315.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248236.780000 537315.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 008 958</ms:GML_ID>
        <ms:NAZWA>103 008 958</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103008958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248416.267000 537082.891000</gml:lowerCorner>
        		<gml:upperCorner>248416.267000 537082.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248416.267000 537082.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 008 664</ms:GML_ID>
        <ms:NAZWA>103 008 664</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103008664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248946.501000 536466.862000</gml:lowerCorner>
        		<gml:upperCorner>248946.501000 536466.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248946.501000 536466.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 007 853</ms:GML_ID>
        <ms:NAZWA>103 007 853</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103007853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249702.942665 531612.633705</gml:lowerCorner>
        		<gml:upperCorner>249702.942665 531612.633705</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249702.942665 531612.633705</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.126 007 060</ms:GML_ID>
        <ms:NAZWA>126 007 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>126007060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250592.189000 534210.206000</gml:lowerCorner>
        		<gml:upperCorner>250592.189000 534210.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250592.189000 534210.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 005 052</ms:GML_ID>
        <ms:NAZWA>103 005 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103005052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251022.214000 533642.343000</gml:lowerCorner>
        		<gml:upperCorner>251022.214000 533642.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251022.214000 533642.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 004 338</ms:GML_ID>
        <ms:NAZWA>103 004 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103004338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251633.554697 533199.797039</gml:lowerCorner>
        		<gml:upperCorner>251633.554697 533199.797039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251633.554697 533199.797039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 003 554</ms:GML_ID>
        <ms:NAZWA>103 003 554</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103003554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251874.129000 533117.241000</gml:lowerCorner>
        		<gml:upperCorner>251874.129000 533117.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251874.129000 533117.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 003 300</ms:GML_ID>
        <ms:NAZWA>103 003 300</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103003300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252164.392219 533017.868692</gml:lowerCorner>
        		<gml:upperCorner>252164.392219 533017.868692</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252164.392219 533017.868692</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 002 994</ms:GML_ID>
        <ms:NAZWA>103 002 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103002994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252322.721000 532969.978000</gml:lowerCorner>
        		<gml:upperCorner>252322.721000 532969.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252322.721000 532969.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 002 828</ms:GML_ID>
        <ms:NAZWA>103 002 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103002828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252715.411000 537994.184000</gml:lowerCorner>
        		<gml:upperCorner>252715.411000 537994.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252715.411000 537994.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 037 591</ms:GML_ID>
        <ms:NAZWA>133 037 591</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>133037591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252734.805000 533134.450000</gml:lowerCorner>
        		<gml:upperCorner>252734.805000 533134.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252734.805000 533134.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 002 377</ms:GML_ID>
        <ms:NAZWA>103 002 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103002377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253227.083000 533415.465000</gml:lowerCorner>
        		<gml:upperCorner>253227.083000 533415.465000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253227.083000 533415.465000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 001 807</ms:GML_ID>
        <ms:NAZWA>103 001 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103001807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198292.331000 524152.055000</gml:lowerCorner>
        		<gml:upperCorner>198292.331000 524152.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198292.331000 524152.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 069 174</ms:GML_ID>
        <ms:NAZWA>097 069 174</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097069174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198967.647000 525003.905000</gml:lowerCorner>
        		<gml:upperCorner>198967.647000 525003.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198967.647000 525003.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 068 083</ms:GML_ID>
        <ms:NAZWA>097 068 083</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097068083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199260.921697 525384.567557</gml:lowerCorner>
        		<gml:upperCorner>199260.921697 525384.567557</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199260.921697 525384.567557</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 067 600</ms:GML_ID>
        <ms:NAZWA>097 067 600</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097067600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199899.442000 526891.297000</gml:lowerCorner>
        		<gml:upperCorner>199899.442000 526891.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199899.442000 526891.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 065 800</ms:GML_ID>
        <ms:NAZWA>097 065 800</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097065800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200204.372000 527356.679000</gml:lowerCorner>
        		<gml:upperCorner>200204.372000 527356.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200204.372000 527356.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 065 221</ms:GML_ID>
        <ms:NAZWA>097 065 221</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097065221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201994.218000 529240.530000</gml:lowerCorner>
        		<gml:upperCorner>201994.218000 529240.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201994.218000 529240.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 062 334</ms:GML_ID>
        <ms:NAZWA>097 062 334</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097062334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204228.170000 530454.772000</gml:lowerCorner>
        		<gml:upperCorner>204228.170000 530454.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204228.170000 530454.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 059 460</ms:GML_ID>
        <ms:NAZWA>097 059 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097059460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204564.439000 531187.666000</gml:lowerCorner>
        		<gml:upperCorner>204564.439000 531187.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204564.439000 531187.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 058 613</ms:GML_ID>
        <ms:NAZWA>097 058 613</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097058613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204336.033000 532805.360000</gml:lowerCorner>
        		<gml:upperCorner>204336.033000 532805.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204336.033000 532805.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 056 810</ms:GML_ID>
        <ms:NAZWA>097 056 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097056810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204640.356431 533520.827229</gml:lowerCorner>
        		<gml:upperCorner>204640.356431 533520.827229</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204640.356431 533520.827229</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 055 891</ms:GML_ID>
        <ms:NAZWA>097 055 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097055891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204708.111000 533697.745000</gml:lowerCorner>
        		<gml:upperCorner>204708.111000 533697.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204708.111000 533697.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 055 698</ms:GML_ID>
        <ms:NAZWA>097 055 698</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097055698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204942.149000 533923.915000</gml:lowerCorner>
        		<gml:upperCorner>204942.149000 533923.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204942.149000 533923.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 055 368</ms:GML_ID>
        <ms:NAZWA>097 055 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097055368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205150.897000 534146.085000</gml:lowerCorner>
        		<gml:upperCorner>205150.897000 534146.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205150.897000 534146.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 055 060</ms:GML_ID>
        <ms:NAZWA>097 055 060</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097055060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205291.164019 534266.464924</gml:lowerCorner>
        		<gml:upperCorner>205291.164019 534266.464924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205291.164019 534266.464924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 054 875</ms:GML_ID>
        <ms:NAZWA>097 054 875</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097054875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205482.899000 534711.602000</gml:lowerCorner>
        		<gml:upperCorner>205482.899000 534711.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205482.899000 534711.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 054 356</ms:GML_ID>
        <ms:NAZWA>097 054 356</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097054356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205472.048000 534905.359000</gml:lowerCorner>
        		<gml:upperCorner>205472.048000 534905.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205472.048000 534905.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 054 161</ms:GML_ID>
        <ms:NAZWA>097 054 161</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097054161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205506.318200 535122.430843</gml:lowerCorner>
        		<gml:upperCorner>205506.318200 535122.430843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205506.318200 535122.430843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 053 941</ms:GML_ID>
        <ms:NAZWA>097 053 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097053941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205674.382000 535366.205000</gml:lowerCorner>
        		<gml:upperCorner>205674.382000 535366.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205674.382000 535366.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 053 642</ms:GML_ID>
        <ms:NAZWA>097 053 642</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097053642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205893.004000 535826.180000</gml:lowerCorner>
        		<gml:upperCorner>205893.004000 535826.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205893.004000 535826.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 053 125</ms:GML_ID>
        <ms:NAZWA>097 053 125</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097053125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206917.137000 536777.329000</gml:lowerCorner>
        		<gml:upperCorner>206917.137000 536777.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206917.137000 536777.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 051 724</ms:GML_ID>
        <ms:NAZWA>097 051 724</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>097051724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224111.252000 516989.181000</gml:lowerCorner>
        		<gml:upperCorner>224111.252000 516989.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224111.252000 516989.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 041 062</ms:GML_ID>
        <ms:NAZWA>117 041 062</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117041062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224200.347000 517184.695000</gml:lowerCorner>
        		<gml:upperCorner>224200.347000 517184.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224200.347000 517184.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 040 832</ms:GML_ID>
        <ms:NAZWA>117 040 832</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117040832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224022.137000 517749.163000</gml:lowerCorner>
        		<gml:upperCorner>224022.137000 517749.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224022.137000 517749.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 040 249</ms:GML_ID>
        <ms:NAZWA>117 040 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117040249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220622.197428 523788.719913</gml:lowerCorner>
        		<gml:upperCorner>220622.197428 523788.719913</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220622.197428 523788.719913</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 032 922</ms:GML_ID>
        <ms:NAZWA>117 032 922</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117032922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220238.835344 524070.274142</gml:lowerCorner>
        		<gml:upperCorner>220238.835344 524070.274142</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220238.835344 524070.274142</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 032 447</ms:GML_ID>
        <ms:NAZWA>117 032 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117032447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220046.237000 524296.583000</gml:lowerCorner>
        		<gml:upperCorner>220046.237000 524296.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220046.237000 524296.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 032 142</ms:GML_ID>
        <ms:NAZWA>117 032 142</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117032142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220014.519000 524458.815000</gml:lowerCorner>
        		<gml:upperCorner>220014.519000 524458.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220014.519000 524458.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 031 976</ms:GML_ID>
        <ms:NAZWA>117 031 976</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117031976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220008.372000 524614.976000</gml:lowerCorner>
        		<gml:upperCorner>220008.372000 524614.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220008.372000 524614.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 031 820</ms:GML_ID>
        <ms:NAZWA>117 031 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117031820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220106.700491 524840.828320</gml:lowerCorner>
        		<gml:upperCorner>220106.700491 524840.828320</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220106.700491 524840.828320</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 031 566</ms:GML_ID>
        <ms:NAZWA>117 031 566</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117031566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220316.567817 524986.684166</gml:lowerCorner>
        		<gml:upperCorner>220316.567817 524986.684166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220316.567817 524986.684166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 031 309</ms:GML_ID>
        <ms:NAZWA>117 031 309</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117031309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220859.184582 525159.217444</gml:lowerCorner>
        		<gml:upperCorner>220859.184582 525159.217444</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220859.184582 525159.217444</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 030 714</ms:GML_ID>
        <ms:NAZWA>117 030 714</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117030714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221049.792454 526367.180407</gml:lowerCorner>
        		<gml:upperCorner>221049.792454 526367.180407</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221049.792454 526367.180407</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 029 452</ms:GML_ID>
        <ms:NAZWA>117 029 452</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117029452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221185.812803 526622.141848</gml:lowerCorner>
        		<gml:upperCorner>221185.812803 526622.141848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221185.812803 526622.141848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 029 158</ms:GML_ID>
        <ms:NAZWA>117 029 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117029158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220913.842000 527224.470000</gml:lowerCorner>
        		<gml:upperCorner>220913.842000 527224.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220913.842000 527224.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 028 492</ms:GML_ID>
        <ms:NAZWA>117 028 492</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117028492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220846.223000 527583.685000</gml:lowerCorner>
        		<gml:upperCorner>220846.223000 527583.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220846.223000 527583.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 028 120</ms:GML_ID>
        <ms:NAZWA>117 028 120</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117028120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220719.091473 527823.699676</gml:lowerCorner>
        		<gml:upperCorner>220719.091473 527823.699676</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220719.091473 527823.699676</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 027 848</ms:GML_ID>
        <ms:NAZWA>117 027 848</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117027848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220777.933000 528265.391000</gml:lowerCorner>
        		<gml:upperCorner>220777.933000 528265.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220777.933000 528265.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 027 388</ms:GML_ID>
        <ms:NAZWA>117 027 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117027388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220977.049000 529037.822000</gml:lowerCorner>
        		<gml:upperCorner>220977.049000 529037.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220977.049000 529037.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 026 540</ms:GML_ID>
        <ms:NAZWA>117 026 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117026540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

