<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:21" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=3000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=5000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>180115.195000 481793.097000</gml:lowerCorner>
      		<gml:upperCorner>729496.871915 658560.781000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220938.017960 529698.161082</gml:lowerCorner>
        		<gml:upperCorner>220938.017960 529698.161082</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220938.017960 529698.161082</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 025 863</ms:GML_ID>
        <ms:NAZWA>117 025 863</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117025863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221886.988000 531107.209000</gml:lowerCorner>
        		<gml:upperCorner>221886.988000 531107.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221886.988000 531107.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 023 889</ms:GML_ID>
        <ms:NAZWA>117 023 889</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117023889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222999.445000 532411.429000</gml:lowerCorner>
        		<gml:upperCorner>222999.445000 532411.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222999.445000 532411.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 022 083</ms:GML_ID>
        <ms:NAZWA>117 022 083</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117022083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232705.529000 532791.673000</gml:lowerCorner>
        		<gml:upperCorner>232705.529000 532791.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232705.529000 532791.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 028 441</ms:GML_ID>
        <ms:NAZWA>103 028 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103028441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223431.156000 532868.833000</gml:lowerCorner>
        		<gml:upperCorner>223431.156000 532868.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223431.156000 532868.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 021 449</ms:GML_ID>
        <ms:NAZWA>117 021 449</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117021449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268270.194000 516071.755000</gml:lowerCorner>
        		<gml:upperCorner>268270.194000 516071.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268270.194000 516071.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 074 512</ms:GML_ID>
        <ms:NAZWA>062 074 512</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062074512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268975.807694 516519.523892</gml:lowerCorner>
        		<gml:upperCorner>268975.807694 516519.523892</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268975.807694 516519.523892</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.163 000 064</ms:GML_ID>
        <ms:NAZWA>163 000 064</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>163000064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269207.140736 527027.732441</gml:lowerCorner>
        		<gml:upperCorner>269207.140736 527027.732441</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269207.140736 527027.732441</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 060 452</ms:GML_ID>
        <ms:NAZWA>062 060 452</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062060452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269474.522000 516809.104000</gml:lowerCorner>
        		<gml:upperCorner>269474.522000 516809.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269474.522000 516809.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 073 068</ms:GML_ID>
        <ms:NAZWA>062 073 068</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062073068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269937.886000 517233.004000</gml:lowerCorner>
        		<gml:upperCorner>269937.886000 517233.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269937.886000 517233.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 072 441</ms:GML_ID>
        <ms:NAZWA>062 072 441</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062072441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270197.496198 526302.805535</gml:lowerCorner>
        		<gml:upperCorner>270197.496198 526302.805535</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270197.496198 526302.805535</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 061 708</ms:GML_ID>
        <ms:NAZWA>062 061 708</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062061708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271609.283967 516867.392739</gml:lowerCorner>
        		<gml:upperCorner>271609.283967 516867.392739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271609.283967 516867.392739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 071 100</ms:GML_ID>
        <ms:NAZWA>062 071 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062071100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271709.633993 517597.466527</gml:lowerCorner>
        		<gml:upperCorner>271709.633993 517597.466527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271709.633993 517597.466527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 070 900</ms:GML_ID>
        <ms:NAZWA>062 070 900</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062070900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271800.546157 517961.853807</gml:lowerCorner>
        		<gml:upperCorner>271800.546157 517961.853807</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271800.546157 517961.853807</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 070 395</ms:GML_ID>
        <ms:NAZWA>062 070 395</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062070395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272049.712077 520461.317190</gml:lowerCorner>
        		<gml:upperCorner>272049.712077 520461.317190</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272049.712077 520461.317190</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 007 025</ms:GML_ID>
        <ms:NAZWA>133 007 025</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>133007025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272073.836000 518309.550000</gml:lowerCorner>
        		<gml:upperCorner>272073.836000 518309.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272073.836000 518309.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.162 000 897</ms:GML_ID>
        <ms:NAZWA>162 000 897</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>162000897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272999.847000 518021.093000</gml:lowerCorner>
        		<gml:upperCorner>272999.847000 518021.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272999.847000 518021.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.162 001 942</ms:GML_ID>
        <ms:NAZWA>162 001 942</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>162001942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273732.014000 518407.926000</gml:lowerCorner>
        		<gml:upperCorner>273732.014000 518407.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273732.014000 518407.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.162 002 780</ms:GML_ID>
        <ms:NAZWA>162 002 780</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>162002780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276306.578000 517623.846000</gml:lowerCorner>
        		<gml:upperCorner>276306.578000 517623.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276306.578000 517623.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 294 830</ms:GML_ID>
        <ms:NAZWA>001 294 830</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001294830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277057.993000 517692.133000</gml:lowerCorner>
        		<gml:upperCorner>277057.993000 517692.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277057.993000 517692.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 001 530</ms:GML_ID>
        <ms:NAZWA>183 001 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183001530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280225.798000 521137.018000</gml:lowerCorner>
        		<gml:upperCorner>280225.798000 521137.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280225.798000 521137.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 289 319</ms:GML_ID>
        <ms:NAZWA>001 289 319</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001289319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281377.886857 523331.574013</gml:lowerCorner>
        		<gml:upperCorner>281377.886857 523331.574013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281377.886857 523331.574013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.160 286 958</ms:GML_ID>
        <ms:NAZWA>160 286 958</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>160286958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285170.896523 528179.982217</gml:lowerCorner>
        		<gml:upperCorner>285170.896523 528179.982217</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285170.896523 528179.982217</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 280 245</ms:GML_ID>
        <ms:NAZWA>001 280 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001280245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289223.546707 527323.259058</gml:lowerCorner>
        		<gml:upperCorner>289223.546707 527323.259058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289223.546707 527323.259058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 041 134</ms:GML_ID>
        <ms:NAZWA>182 041 134</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182041134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289261.198897 528645.787668</gml:lowerCorner>
        		<gml:upperCorner>289261.198897 528645.787668</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289261.198897 528645.787668</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 042 458</ms:GML_ID>
        <ms:NAZWA>182 042 458</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182042458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249594.796000 531323.827000</gml:lowerCorner>
        		<gml:upperCorner>249594.796000 531323.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249594.796000 531323.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.126 006 750</ms:GML_ID>
        <ms:NAZWA>126 006 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>126006750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255503.832268 531330.469176</gml:lowerCorner>
        		<gml:upperCorner>255503.832268 531330.469176</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255503.832268 531330.469176</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 001 782</ms:GML_ID>
        <ms:NAZWA>114 001 782</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114001782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255829.591008 531176.722400</gml:lowerCorner>
        		<gml:upperCorner>255829.591008 531176.722400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255829.591008 531176.722400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 002 142</ms:GML_ID>
        <ms:NAZWA>114 002 142</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114002142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256443.117000 530927.093000</gml:lowerCorner>
        		<gml:upperCorner>256443.117000 530927.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256443.117000 530927.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 003 615</ms:GML_ID>
        <ms:NAZWA>114 003 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114003615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256467.080000 530662.340000</gml:lowerCorner>
        		<gml:upperCorner>256467.080000 530662.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256467.080000 530662.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 003 341</ms:GML_ID>
        <ms:NAZWA>114 003 341</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114003341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256878.083813 531942.113434</gml:lowerCorner>
        		<gml:upperCorner>256878.083813 531942.113434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256878.083813 531942.113434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 004 803</ms:GML_ID>
        <ms:NAZWA>114 004 803</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114004803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264298.012000 522068.645000</gml:lowerCorner>
        		<gml:upperCorner>264298.012000 522068.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264298.012000 522068.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.714 001 657</ms:GML_ID>
        <ms:NAZWA>714 001 657</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>714001657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264550.836926 521054.016840</gml:lowerCorner>
        		<gml:upperCorner>264550.836926 521054.016840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264550.836926 521054.016840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.714 000 528</ms:GML_ID>
        <ms:NAZWA>714 000 528</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>714000528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264632.395178 520998.964439</gml:lowerCorner>
        		<gml:upperCorner>264632.395178 520998.964439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264632.395178 520998.964439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.714 000 596</ms:GML_ID>
        <ms:NAZWA>714 000 596</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>714000596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264811.685000 519627.751000</gml:lowerCorner>
        		<gml:upperCorner>264811.685000 519627.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264811.685000 519627.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.134 001 324</ms:GML_ID>
        <ms:NAZWA>134 001 324</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>134001324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264934.010000 519599.950000</gml:lowerCorner>
        		<gml:upperCorner>264934.010000 519599.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264934.010000 519599.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.667 000 367</ms:GML_ID>
        <ms:NAZWA>667 000 367</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>667000367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265124.251000 519712.574000</gml:lowerCorner>
        		<gml:upperCorner>265124.251000 519712.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265124.251000 519712.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 014 353</ms:GML_ID>
        <ms:NAZWA>133 014 353</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>133014353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266490.819059 519014.212422</gml:lowerCorner>
        		<gml:upperCorner>266490.819059 519014.212422</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266490.819059 519014.212422</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.163 003 819</ms:GML_ID>
        <ms:NAZWA>163 003 819</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>163003819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266695.038000 519154.096000</gml:lowerCorner>
        		<gml:upperCorner>266695.038000 519154.096000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266695.038000 519154.096000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.133 012 633</ms:GML_ID>
        <ms:NAZWA>133 012 633</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>133012633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266745.616438 534257.598132</gml:lowerCorner>
        		<gml:upperCorner>266745.616438 534257.598132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266745.616438 534257.598132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 051 916</ms:GML_ID>
        <ms:NAZWA>062 051 916</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062051916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267258.852000 515992.324000</gml:lowerCorner>
        		<gml:upperCorner>267258.852000 515992.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267258.852000 515992.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.171 020 789</ms:GML_ID>
        <ms:NAZWA>171 020 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>171020789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267660.519000 529056.072000</gml:lowerCorner>
        		<gml:upperCorner>267660.519000 529056.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267660.519000 529056.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 057 473</ms:GML_ID>
        <ms:NAZWA>062 057 473</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062057473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267815.833000 539822.155000</gml:lowerCorner>
        		<gml:upperCorner>267815.833000 539822.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267815.833000 539822.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 046 118</ms:GML_ID>
        <ms:NAZWA>062 046 118</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>062046118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268024.390000 515837.479000</gml:lowerCorner>
        		<gml:upperCorner>268024.390000 515837.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268024.390000 515837.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 074 858</ms:GML_ID>
        <ms:NAZWA>062 074 858</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062074858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197891.557000 511876.703000</gml:lowerCorner>
        		<gml:upperCorner>197891.557000 511876.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197891.557000 511876.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 080 366</ms:GML_ID>
        <ms:NAZWA>139 080 366</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139080366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198292.452610 523470.393955</gml:lowerCorner>
        		<gml:upperCorner>198292.452610 523470.393955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198292.452610 523470.393955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 069 881</ms:GML_ID>
        <ms:NAZWA>097 069 881</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097069881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198369.793634 522902.078807</gml:lowerCorner>
        		<gml:upperCorner>198369.793634 522902.078807</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198369.793634 522902.078807</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 070 464</ms:GML_ID>
        <ms:NAZWA>097 070 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097070464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198726.656000 522244.283000</gml:lowerCorner>
        		<gml:upperCorner>198726.656000 522244.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198726.656000 522244.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 071 281</ms:GML_ID>
        <ms:NAZWA>097 071 281</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097071281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199075.507000 521973.263000</gml:lowerCorner>
        		<gml:upperCorner>199075.507000 521973.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199075.507000 521973.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 071 723</ms:GML_ID>
        <ms:NAZWA>097 071 723</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097071723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199333.625000 521408.447000</gml:lowerCorner>
        		<gml:upperCorner>199333.625000 521408.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199333.625000 521408.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 072 348</ms:GML_ID>
        <ms:NAZWA>097 072 348</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097072348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199597.542000 520799.868000</gml:lowerCorner>
        		<gml:upperCorner>199597.542000 520799.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199597.542000 520799.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 073 012</ms:GML_ID>
        <ms:NAZWA>097 073 012</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097073012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199888.273000 512988.349000</gml:lowerCorner>
        		<gml:upperCorner>199888.273000 512988.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199888.273000 512988.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 078 026</ms:GML_ID>
        <ms:NAZWA>139 078 026</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139078026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200041.450000 520080.420000</gml:lowerCorner>
        		<gml:upperCorner>200041.450000 520080.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200041.450000 520080.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 073 869</ms:GML_ID>
        <ms:NAZWA>097 073 869</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097073869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200316.832000 513137.074000</gml:lowerCorner>
        		<gml:upperCorner>200316.832000 513137.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200316.832000 513137.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 077 573</ms:GML_ID>
        <ms:NAZWA>139 077 573</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139077573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200399.540000 517602.143000</gml:lowerCorner>
        		<gml:upperCorner>200399.540000 517602.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200399.540000 517602.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 076 530</ms:GML_ID>
        <ms:NAZWA>097 076 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097076530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200435.763000 517352.665000</gml:lowerCorner>
        		<gml:upperCorner>200435.763000 517352.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200435.763000 517352.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 076 783</ms:GML_ID>
        <ms:NAZWA>097 076 783</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097076783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200509.051000 519018.696000</gml:lowerCorner>
        		<gml:upperCorner>200509.051000 519018.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200509.051000 519018.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 075 076</ms:GML_ID>
        <ms:NAZWA>097 075 076</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097075076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200709.408000 516741.245000</gml:lowerCorner>
        		<gml:upperCorner>200709.408000 516741.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200709.408000 516741.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 077 456</ms:GML_ID>
        <ms:NAZWA>097 077 456</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097077456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200914.184000 516303.611000</gml:lowerCorner>
        		<gml:upperCorner>200914.184000 516303.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200914.184000 516303.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 077 938</ms:GML_ID>
        <ms:NAZWA>097 077 938</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097077938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201124.949000 515537.925000</gml:lowerCorner>
        		<gml:upperCorner>201124.949000 515537.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201124.949000 515537.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 078 739</ms:GML_ID>
        <ms:NAZWA>097 078 739</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097078739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201191.220349 513348.606068</gml:lowerCorner>
        		<gml:upperCorner>201191.220349 513348.606068</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201191.220349 513348.606068</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 076 670</ms:GML_ID>
        <ms:NAZWA>139 076 670</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139076670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201542.052028 514684.363430</gml:lowerCorner>
        		<gml:upperCorner>201542.052028 514684.363430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201542.052028 514684.363430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.097 079 630</ms:GML_ID>
        <ms:NAZWA>097 079 630</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>097079630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201667.826000 513502.113000</gml:lowerCorner>
        		<gml:upperCorner>201667.826000 513502.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201667.826000 513502.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 076 166</ms:GML_ID>
        <ms:NAZWA>139 076 166</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139076166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204130.781000 512910.469000</gml:lowerCorner>
        		<gml:upperCorner>204130.781000 512910.469000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204130.781000 512910.469000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 073 619</ms:GML_ID>
        <ms:NAZWA>139 073 619</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139073619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205120.685000 511849.925000</gml:lowerCorner>
        		<gml:upperCorner>205120.685000 511849.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205120.685000 511849.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 072 082</ms:GML_ID>
        <ms:NAZWA>139 072 082</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139072082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255831.592758 511206.910036</gml:lowerCorner>
        		<gml:upperCorner>255831.592758 511206.910036</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255831.592758 511206.910036</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 024 952</ms:GML_ID>
        <ms:NAZWA>179 024 952</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179024952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256029.015000 511560.675000</gml:lowerCorner>
        		<gml:upperCorner>256029.015000 511560.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256029.015000 511560.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 015 321</ms:GML_ID>
        <ms:NAZWA>138 015 321</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138015321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253716.676000 512300.056000</gml:lowerCorner>
        		<gml:upperCorner>253716.676000 512300.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253716.676000 512300.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 012 897</ms:GML_ID>
        <ms:NAZWA>138 012 897</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138012897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252936.853258 512553.627076</gml:lowerCorner>
        		<gml:upperCorner>252936.853258 512553.627076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252936.853258 512553.627076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 012 074</ms:GML_ID>
        <ms:NAZWA>138 012 074</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138012074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238650.623000 512883.991000</gml:lowerCorner>
        		<gml:upperCorner>238650.623000 512883.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238650.623000 512883.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 028 561</ms:GML_ID>
        <ms:NAZWA>093 028 561</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093028561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250250.311000 512975.130000</gml:lowerCorner>
        		<gml:upperCorner>250250.311000 512975.130000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250250.311000 512975.130000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 009 348</ms:GML_ID>
        <ms:NAZWA>138 009 348</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138009348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249348.607000 513111.632000</gml:lowerCorner>
        		<gml:upperCorner>249348.607000 513111.632000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249348.607000 513111.632000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 008 435</ms:GML_ID>
        <ms:NAZWA>138 008 435</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138008435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248914.536000 513177.120000</gml:lowerCorner>
        		<gml:upperCorner>248914.536000 513177.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248914.536000 513177.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 007 996</ms:GML_ID>
        <ms:NAZWA>138 007 996</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138007996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239571.044785 513240.763757</gml:lowerCorner>
        		<gml:upperCorner>239571.044785 513240.763757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239571.044785 513240.763757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 027 575</ms:GML_ID>
        <ms:NAZWA>093 027 575</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093027575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243509.441017 514274.182008</gml:lowerCorner>
        		<gml:upperCorner>243509.441017 514274.182008</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243509.441017 514274.182008</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 002 221</ms:GML_ID>
        <ms:NAZWA>138 002 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>138002221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241777.843799 514311.612447</gml:lowerCorner>
        		<gml:upperCorner>241777.843799 514311.612447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241777.843799 514311.612447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 025 130</ms:GML_ID>
        <ms:NAZWA>093 025 130</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093025130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242724.698000 514677.337000</gml:lowerCorner>
        		<gml:upperCorner>242724.698000 514677.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242724.698000 514677.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 001 338</ms:GML_ID>
        <ms:NAZWA>138 001 338</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>138001338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242418.016897 514881.228226</gml:lowerCorner>
        		<gml:upperCorner>242418.016897 514881.228226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242418.016897 514881.228226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.699 000 334</ms:GML_ID>
        <ms:NAZWA>699 000 334</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>699000334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242146.163000 518110.475000</gml:lowerCorner>
        		<gml:upperCorner>242146.163000 518110.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242146.163000 518110.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 059 723</ms:GML_ID>
        <ms:NAZWA>094 059 723</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094059723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248129.491000 518217.379000</gml:lowerCorner>
        		<gml:upperCorner>248129.491000 518217.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248129.491000 518217.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 017 431</ms:GML_ID>
        <ms:NAZWA>093 017 431</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093017431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242137.180890 520193.419731</gml:lowerCorner>
        		<gml:upperCorner>242137.180890 520193.419731</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242137.180890 520193.419731</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 057 732</ms:GML_ID>
        <ms:NAZWA>094 057 732</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094057732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242059.373394 520424.707790</gml:lowerCorner>
        		<gml:upperCorner>242059.373394 520424.707790</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242059.373394 520424.707790</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 057 375</ms:GML_ID>
        <ms:NAZWA>094 057 375</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094057375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240285.361802 522290.229030</gml:lowerCorner>
        		<gml:upperCorner>240285.361802 522290.229030</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240285.361802 522290.229030</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 054 695</ms:GML_ID>
        <ms:NAZWA>094 054 695</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094054695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249816.265000 522670.875000</gml:lowerCorner>
        		<gml:upperCorner>249816.265000 522670.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249816.265000 522670.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 012 024</ms:GML_ID>
        <ms:NAZWA>093 012 024</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093012024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239599.092811 523469.630656</gml:lowerCorner>
        		<gml:upperCorner>239599.092811 523469.630656</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239599.092811 523469.630656</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 053 318</ms:GML_ID>
        <ms:NAZWA>094 053 318</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094053318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239512.225373 523736.861808</gml:lowerCorner>
        		<gml:upperCorner>239512.225373 523736.861808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239512.225373 523736.861808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 053 034</ms:GML_ID>
        <ms:NAZWA>094 053 034</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094053034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249421.736267 524203.080984</gml:lowerCorner>
        		<gml:upperCorner>249421.736267 524203.080984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249421.736267 524203.080984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 010 418</ms:GML_ID>
        <ms:NAZWA>093 010 418</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093010418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239341.898830 524264.216517</gml:lowerCorner>
        		<gml:upperCorner>239341.898830 524264.216517</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239341.898830 524264.216517</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 052 481</ms:GML_ID>
        <ms:NAZWA>094 052 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094052481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239020.463690 525261.011814</gml:lowerCorner>
        		<gml:upperCorner>239020.463690 525261.011814</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239020.463690 525261.011814</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 051 435</ms:GML_ID>
        <ms:NAZWA>094 051 435</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094051435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238737.897484 525971.578757</gml:lowerCorner>
        		<gml:upperCorner>238737.897484 525971.578757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238737.897484 525971.578757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 050 670</ms:GML_ID>
        <ms:NAZWA>094 050 670</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094050670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238378.064912 526751.633422</gml:lowerCorner>
        		<gml:upperCorner>238378.064912 526751.633422</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238378.064912 526751.633422</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 049 809</ms:GML_ID>
        <ms:NAZWA>094 049 809</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094049809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249947.047745 529313.365133</gml:lowerCorner>
        		<gml:upperCorner>249947.047745 529313.365133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249947.047745 529313.365133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.126 004 501</ms:GML_ID>
        <ms:NAZWA>126 004 501</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>126004501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249630.043000 529553.458000</gml:lowerCorner>
        		<gml:upperCorner>249630.043000 529553.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249630.043000 529553.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.126 004 936</ms:GML_ID>
        <ms:NAZWA>126 004 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>126004936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249642.144906 530705.537898</gml:lowerCorner>
        		<gml:upperCorner>249642.144906 530705.537898</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249642.144906 530705.537898</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.126 006 128</ms:GML_ID>
        <ms:NAZWA>126 006 128</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>126006128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255865.495000 530918.809000</gml:lowerCorner>
        		<gml:upperCorner>255865.495000 530918.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255865.495000 530918.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 002 416</ms:GML_ID>
        <ms:NAZWA>114 002 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114002416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255137.873720 531461.297105</gml:lowerCorner>
        		<gml:upperCorner>255137.873720 531461.297105</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255137.873720 531461.297105</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.114 001 394</ms:GML_ID>
        <ms:NAZWA>114 001 394</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>114001394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205726.829000 511138.893000</gml:lowerCorner>
        		<gml:upperCorner>205726.829000 511138.893000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205726.829000 511138.893000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 071 145</ms:GML_ID>
        <ms:NAZWA>139 071 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139071145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220870.387000 523605.886000</gml:lowerCorner>
        		<gml:upperCorner>220870.387000 523605.886000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220870.387000 523605.886000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 033 229</ms:GML_ID>
        <ms:NAZWA>117 033 229</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117033229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221154.893000 511827.008000</gml:lowerCorner>
        		<gml:upperCorner>221154.893000 511827.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221154.893000 511827.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 047 989</ms:GML_ID>
        <ms:NAZWA>117 047 989</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117047989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221205.168000 523357.980000</gml:lowerCorner>
        		<gml:upperCorner>221205.168000 523357.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221205.168000 523357.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 033 647</ms:GML_ID>
        <ms:NAZWA>117 033 647</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117033647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221695.031309 522716.272016</gml:lowerCorner>
        		<gml:upperCorner>221695.031309 522716.272016</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221695.031309 522716.272016</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 034 457</ms:GML_ID>
        <ms:NAZWA>117 034 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117034457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221842.017450 522488.123791</gml:lowerCorner>
        		<gml:upperCorner>221842.017450 522488.123791</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221842.017450 522488.123791</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 034 721</ms:GML_ID>
        <ms:NAZWA>117 034 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117034721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221975.427000 512093.098000</gml:lowerCorner>
        		<gml:upperCorner>221975.427000 512093.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221975.427000 512093.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 047 034</ms:GML_ID>
        <ms:NAZWA>117 047 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117047034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222335.195000 521968.216000</gml:lowerCorner>
        		<gml:upperCorner>222335.195000 521968.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222335.195000 521968.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 035 481</ms:GML_ID>
        <ms:NAZWA>117 035 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117035481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223186.339949 520903.389488</gml:lowerCorner>
        		<gml:upperCorner>223186.339949 520903.389488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223186.339949 520903.389488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 036 895</ms:GML_ID>
        <ms:NAZWA>117 036 895</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117036895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223280.032219 512843.309200</gml:lowerCorner>
        		<gml:upperCorner>223280.032219 512843.309200</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223280.032219 512843.309200</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 045 410</ms:GML_ID>
        <ms:NAZWA>117 045 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117045410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223437.197000 514114.600000</gml:lowerCorner>
        		<gml:upperCorner>223437.197000 514114.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223437.197000 514114.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 044 116</ms:GML_ID>
        <ms:NAZWA>117 044 116</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117044116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223598.224050 519939.059825</gml:lowerCorner>
        		<gml:upperCorner>223598.224050 519939.059825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223598.224050 519939.059825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 037 974</ms:GML_ID>
        <ms:NAZWA>117 037 974</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117037974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223627.760000 515225.979000</gml:lowerCorner>
        		<gml:upperCorner>223627.760000 515225.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223627.760000 515225.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 042 962</ms:GML_ID>
        <ms:NAZWA>117 042 962</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117042962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223643.578000 515387.894000</gml:lowerCorner>
        		<gml:upperCorner>223643.578000 515387.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223643.578000 515387.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 042 799</ms:GML_ID>
        <ms:NAZWA>117 042 799</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117042799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223670.283000 519531.257000</gml:lowerCorner>
        		<gml:upperCorner>223670.283000 519531.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223670.283000 519531.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 038 388</ms:GML_ID>
        <ms:NAZWA>117 038 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117038388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223672.198000 515674.672000</gml:lowerCorner>
        		<gml:upperCorner>223672.198000 515674.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223672.198000 515674.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 042 510</ms:GML_ID>
        <ms:NAZWA>117 042 510</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117042510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223674.479379 518826.980190</gml:lowerCorner>
        		<gml:upperCorner>223674.479379 518826.980190</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223674.479379 518826.980190</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 039 094</ms:GML_ID>
        <ms:NAZWA>117 039 094</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117039094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223705.773000 516006.695000</gml:lowerCorner>
        		<gml:upperCorner>223705.773000 516006.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223705.773000 516006.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 042 177</ms:GML_ID>
        <ms:NAZWA>117 042 177</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117042177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223732.898000 518426.962000</gml:lowerCorner>
        		<gml:upperCorner>223732.898000 518426.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223732.898000 518426.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 039 500</ms:GML_ID>
        <ms:NAZWA>117 039 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117039500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223789.087842 518178.573496</gml:lowerCorner>
        		<gml:upperCorner>223789.087842 518178.573496</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223789.087842 518178.573496</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 039 753</ms:GML_ID>
        <ms:NAZWA>117 039 753</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117039753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223999.606000 516863.421000</gml:lowerCorner>
        		<gml:upperCorner>223999.606000 516863.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223999.606000 516863.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 041 232</ms:GML_ID>
        <ms:NAZWA>117 041 232</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>117041232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233312.507000 532581.981000</gml:lowerCorner>
        		<gml:upperCorner>233312.507000 532581.981000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233312.507000 532581.981000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 027 768</ms:GML_ID>
        <ms:NAZWA>103 027 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103027768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234041.065000 532655.812000</gml:lowerCorner>
        		<gml:upperCorner>234041.065000 532655.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234041.065000 532655.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 027 034</ms:GML_ID>
        <ms:NAZWA>103 027 034</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103027034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234447.968000 532696.732000</gml:lowerCorner>
        		<gml:upperCorner>234447.968000 532696.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234447.968000 532696.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 026 624</ms:GML_ID>
        <ms:NAZWA>103 026 624</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103026624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234727.420381 532725.278142</gml:lowerCorner>
        		<gml:upperCorner>234727.420381 532725.278142</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234727.420381 532725.278142</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 026 342</ms:GML_ID>
        <ms:NAZWA>103 026 342</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103026342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234908.151000 532743.034000</gml:lowerCorner>
        		<gml:upperCorner>234908.151000 532743.034000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234908.151000 532743.034000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 026 161</ms:GML_ID>
        <ms:NAZWA>103 026 161</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103026161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235355.467551 532788.002029</gml:lowerCorner>
        		<gml:upperCorner>235355.467551 532788.002029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235355.467551 532788.002029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 025 711</ms:GML_ID>
        <ms:NAZWA>103 025 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103025711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235715.003671 532824.062850</gml:lowerCorner>
        		<gml:upperCorner>235715.003671 532824.062850</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235715.003671 532824.062850</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 025 350</ms:GML_ID>
        <ms:NAZWA>103 025 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103025350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236008.034750 532860.468436</gml:lowerCorner>
        		<gml:upperCorner>236008.034750 532860.468436</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236008.034750 532860.468436</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 025 056</ms:GML_ID>
        <ms:NAZWA>103 025 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103025056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236177.298000 532926.733000</gml:lowerCorner>
        		<gml:upperCorner>236177.298000 532926.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236177.298000 532926.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 024 872</ms:GML_ID>
        <ms:NAZWA>103 024 872</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103024872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236243.569000 532967.769000</gml:lowerCorner>
        		<gml:upperCorner>236243.569000 532967.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236243.569000 532967.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 024 793</ms:GML_ID>
        <ms:NAZWA>103 024 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103024793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236329.846000 533040.295000</gml:lowerCorner>
        		<gml:upperCorner>236329.846000 533040.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236329.846000 533040.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 024 680</ms:GML_ID>
        <ms:NAZWA>103 024 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103024680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236470.196000 511003.109000</gml:lowerCorner>
        		<gml:upperCorner>236470.196000 511003.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236470.196000 511003.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 031 575</ms:GML_ID>
        <ms:NAZWA>093 031 575</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093031575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236520.842000 533380.186000</gml:lowerCorner>
        		<gml:upperCorner>236520.842000 533380.186000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236520.842000 533380.186000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 024 286</ms:GML_ID>
        <ms:NAZWA>103 024 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103024286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236549.340062 533690.037508</gml:lowerCorner>
        		<gml:upperCorner>236549.340062 533690.037508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236549.340062 533690.037508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 042 539</ms:GML_ID>
        <ms:NAZWA>094 042 539</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094042539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236693.337000 533275.403000</gml:lowerCorner>
        		<gml:upperCorner>236693.337000 533275.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236693.337000 533275.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 042 985</ms:GML_ID>
        <ms:NAZWA>094 042 985</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094042985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236906.627000 535652.677000</gml:lowerCorner>
        		<gml:upperCorner>236906.627000 535652.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236906.627000 535652.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 040 510</ms:GML_ID>
        <ms:NAZWA>094 040 510</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094040510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236911.694901 532903.113321</gml:lowerCorner>
        		<gml:upperCorner>236911.694901 532903.113321</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236911.694901 532903.113321</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 043 418</ms:GML_ID>
        <ms:NAZWA>094 043 418</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094043418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237060.937803 532266.686787</gml:lowerCorner>
        		<gml:upperCorner>237060.937803 532266.686787</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237060.937803 532266.686787</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 044 081</ms:GML_ID>
        <ms:NAZWA>094 044 081</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094044081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237130.201000 535228.010000</gml:lowerCorner>
        		<gml:upperCorner>237130.201000 535228.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237130.201000 535228.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.103 022 120</ms:GML_ID>
        <ms:NAZWA>103 022 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>103022120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237238.695333 531019.832779</gml:lowerCorner>
        		<gml:upperCorner>237238.695333 531019.832779</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237238.695333 531019.832779</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 045 343</ms:GML_ID>
        <ms:NAZWA>094 045 343</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094045343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237351.549000 512313.520000</gml:lowerCorner>
        		<gml:upperCorner>237351.549000 512313.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237351.549000 512313.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 029 987</ms:GML_ID>
        <ms:NAZWA>093 029 987</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093029987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237418.550218 530249.766560</gml:lowerCorner>
        		<gml:upperCorner>237418.550218 530249.766560</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237418.550218 530249.766560</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 046 135</ms:GML_ID>
        <ms:NAZWA>094 046 135</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094046135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237654.893000 528997.177000</gml:lowerCorner>
        		<gml:upperCorner>237654.893000 528997.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237654.893000 528997.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 047 413</ms:GML_ID>
        <ms:NAZWA>094 047 413</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094047413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237706.543223 528600.883872</gml:lowerCorner>
        		<gml:upperCorner>237706.543223 528600.883872</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237706.543223 528600.883872</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 047 814</ms:GML_ID>
        <ms:NAZWA>094 047 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094047814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237757.824000 528202.088000</gml:lowerCorner>
        		<gml:upperCorner>237757.824000 528202.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237757.824000 528202.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 048 214</ms:GML_ID>
        <ms:NAZWA>094 048 214</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094048214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238083.009142 527334.077907</gml:lowerCorner>
        		<gml:upperCorner>238083.009142 527334.077907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238083.009142 527334.077907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 049 159</ms:GML_ID>
        <ms:NAZWA>094 049 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094049159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238183.587690 527155.050956</gml:lowerCorner>
        		<gml:upperCorner>238183.587690 527155.050956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238183.587690 527155.050956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.094 049 362</ms:GML_ID>
        <ms:NAZWA>094 049 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>094049362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189178.966000 506944.796000</gml:lowerCorner>
        		<gml:upperCorner>189178.966000 506944.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189178.966000 506944.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 091 082</ms:GML_ID>
        <ms:NAZWA>139 091 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139091082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>189566.470000 507232.180000</gml:lowerCorner>
        		<gml:upperCorner>189566.470000 507232.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>189566.470000 507232.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 090 595</ms:GML_ID>
        <ms:NAZWA>139 090 595</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139090595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>190609.582000 507588.388000</gml:lowerCorner>
        		<gml:upperCorner>190609.582000 507588.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>190609.582000 507588.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 089 476</ms:GML_ID>
        <ms:NAZWA>139 089 476</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139089476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191047.784000 507626.619000</gml:lowerCorner>
        		<gml:upperCorner>191047.784000 507626.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191047.784000 507626.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 089 015</ms:GML_ID>
        <ms:NAZWA>139 089 015</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139089015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>191419.975000 507704.836000</gml:lowerCorner>
        		<gml:upperCorner>191419.975000 507704.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>191419.975000 507704.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 088 626</ms:GML_ID>
        <ms:NAZWA>139 088 626</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139088626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192447.675000 508026.977000</gml:lowerCorner>
        		<gml:upperCorner>192447.675000 508026.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192447.675000 508026.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 087 535</ms:GML_ID>
        <ms:NAZWA>139 087 535</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139087535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>192779.040000 508335.309000</gml:lowerCorner>
        		<gml:upperCorner>192779.040000 508335.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>192779.040000 508335.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 087 081</ms:GML_ID>
        <ms:NAZWA>139 087 081</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139087081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193109.749000 509350.568000</gml:lowerCorner>
        		<gml:upperCorner>193109.749000 509350.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193109.749000 509350.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 085 988</ms:GML_ID>
        <ms:NAZWA>139 085 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139085988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193185.575000 509488.724000</gml:lowerCorner>
        		<gml:upperCorner>193185.575000 509488.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193185.575000 509488.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 085 831</ms:GML_ID>
        <ms:NAZWA>139 085 831</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139085831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193494.741000 509771.603000</gml:lowerCorner>
        		<gml:upperCorner>193494.741000 509771.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193494.741000 509771.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 085 411</ms:GML_ID>
        <ms:NAZWA>139 085 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139085411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>193682.042000 509910.638000</gml:lowerCorner>
        		<gml:upperCorner>193682.042000 509910.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>193682.042000 509910.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 085 176</ms:GML_ID>
        <ms:NAZWA>139 085 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139085176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194402.192000 510450.236000</gml:lowerCorner>
        		<gml:upperCorner>194402.192000 510450.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194402.192000 510450.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 084 256</ms:GML_ID>
        <ms:NAZWA>139 084 256</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139084256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194629.487000 510780.314000</gml:lowerCorner>
        		<gml:upperCorner>194629.487000 510780.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194629.487000 510780.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 083 851</ms:GML_ID>
        <ms:NAZWA>139 083 851</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139083851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195001.227000 510996.985000</gml:lowerCorner>
        		<gml:upperCorner>195001.227000 510996.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195001.227000 510996.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 083 406</ms:GML_ID>
        <ms:NAZWA>139 083 406</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139083406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195440.357000 511094.510000</gml:lowerCorner>
        		<gml:upperCorner>195440.357000 511094.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195440.357000 511094.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 082 956</ms:GML_ID>
        <ms:NAZWA>139 082 956</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139082956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205878.156000 510741.898000</gml:lowerCorner>
        		<gml:upperCorner>205878.156000 510741.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205878.156000 510741.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 070 719</ms:GML_ID>
        <ms:NAZWA>139 070 719</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139070719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206298.320225 510296.721130</gml:lowerCorner>
        		<gml:upperCorner>206298.320225 510296.721130</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206298.320225 510296.721130</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 070 101</ms:GML_ID>
        <ms:NAZWA>139 070 101</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139070101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206621.942162 510021.294769</gml:lowerCorner>
        		<gml:upperCorner>206621.942162 510021.294769</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206621.942162 510021.294769</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 069 674</ms:GML_ID>
        <ms:NAZWA>139 069 674</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139069674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207235.370000 509375.969000</gml:lowerCorner>
        		<gml:upperCorner>207235.370000 509375.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207235.370000 509375.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 068 779</ms:GML_ID>
        <ms:NAZWA>139 068 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139068779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207551.698000 508981.367000</gml:lowerCorner>
        		<gml:upperCorner>207551.698000 508981.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207551.698000 508981.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 068 276</ms:GML_ID>
        <ms:NAZWA>139 068 276</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139068276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207809.995000 508658.840000</gml:lowerCorner>
        		<gml:upperCorner>207809.995000 508658.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207809.995000 508658.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 067 861</ms:GML_ID>
        <ms:NAZWA>139 067 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139067861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209017.705000 507249.429000</gml:lowerCorner>
        		<gml:upperCorner>209017.705000 507249.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209017.705000 507249.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 065 990</ms:GML_ID>
        <ms:NAZWA>139 065 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139065990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209406.204000 506955.592000</gml:lowerCorner>
        		<gml:upperCorner>209406.204000 506955.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209406.204000 506955.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 065 504</ms:GML_ID>
        <ms:NAZWA>139 065 504</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139065504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209797.404642 506658.366666</gml:lowerCorner>
        		<gml:upperCorner>209797.404642 506658.366666</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209797.404642 506658.366666</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 065 006</ms:GML_ID>
        <ms:NAZWA>139 065 006</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139065006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180115.195000 504370.269000</gml:lowerCorner>
        		<gml:upperCorner>180115.195000 504370.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180115.195000 504370.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 103 876</ms:GML_ID>
        <ms:NAZWA>139 103 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139103876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180199.654000 504993.271000</gml:lowerCorner>
        		<gml:upperCorner>180199.654000 504993.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180199.654000 504993.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 103 221</ms:GML_ID>
        <ms:NAZWA>139 103 221</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139103221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180384.063000 503897.232000</gml:lowerCorner>
        		<gml:upperCorner>180384.063000 503897.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180384.063000 503897.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 104 426</ms:GML_ID>
        <ms:NAZWA>139 104 426</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139104426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180523.783000 505558.918000</gml:lowerCorner>
        		<gml:upperCorner>180523.783000 505558.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180523.783000 505558.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 102 537</ms:GML_ID>
        <ms:NAZWA>139 102 537</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139102537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>180857.317000 505823.930000</gml:lowerCorner>
        		<gml:upperCorner>180857.317000 505823.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>180857.317000 505823.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 102 110</ms:GML_ID>
        <ms:NAZWA>139 102 110</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139102110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181131.310000 505894.753000</gml:lowerCorner>
        		<gml:upperCorner>181131.310000 505894.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181131.310000 505894.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 101 825</ms:GML_ID>
        <ms:NAZWA>139 101 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139101825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181141.001000 503536.640000</gml:lowerCorner>
        		<gml:upperCorner>181141.001000 503536.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181141.001000 503536.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 105 278</ms:GML_ID>
        <ms:NAZWA>139 105 278</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139105278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181458.521000 503224.816000</gml:lowerCorner>
        		<gml:upperCorner>181458.521000 503224.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181458.521000 503224.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 105 737</ms:GML_ID>
        <ms:NAZWA>139 105 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139105737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>181558.426000 506068.948000</gml:lowerCorner>
        		<gml:upperCorner>181558.426000 506068.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>181558.426000 506068.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 101 353</ms:GML_ID>
        <ms:NAZWA>139 101 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139101353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>182144.764000 503280.764000</gml:lowerCorner>
        		<gml:upperCorner>182144.764000 503280.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>182144.764000 503280.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 106 461</ms:GML_ID>
        <ms:NAZWA>139 106 461</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139106461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183091.095423 508266.640603</gml:lowerCorner>
        		<gml:upperCorner>183091.095423 508266.640603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183091.095423 508266.640603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 098 413</ms:GML_ID>
        <ms:NAZWA>139 098 413</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139098413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183489.884000 502083.710000</gml:lowerCorner>
        		<gml:upperCorner>183489.884000 502083.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183489.884000 502083.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 108 302</ms:GML_ID>
        <ms:NAZWA>139 108 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139108302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183537.407330 507975.706682</gml:lowerCorner>
        		<gml:upperCorner>183537.407330 507975.706682</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183537.407330 507975.706682</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 097 878</ms:GML_ID>
        <ms:NAZWA>139 097 878</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139097878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183861.505000 507860.245000</gml:lowerCorner>
        		<gml:upperCorner>183861.505000 507860.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183861.505000 507860.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 097 534</ms:GML_ID>
        <ms:NAZWA>139 097 534</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139097534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>185928.068000 507400.112000</gml:lowerCorner>
        		<gml:upperCorner>185928.068000 507400.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>185928.068000 507400.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 095 190</ms:GML_ID>
        <ms:NAZWA>139 095 190</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139095190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186256.792000 507039.376000</gml:lowerCorner>
        		<gml:upperCorner>186256.792000 507039.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186256.792000 507039.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 094 698</ms:GML_ID>
        <ms:NAZWA>139 094 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139094698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186576.092000 506516.451000</gml:lowerCorner>
        		<gml:upperCorner>186576.092000 506516.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186576.092000 506516.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 094 084</ms:GML_ID>
        <ms:NAZWA>139 094 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139094084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>186980.533000 506263.398000</gml:lowerCorner>
        		<gml:upperCorner>186980.533000 506263.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>186980.533000 506263.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 093 541</ms:GML_ID>
        <ms:NAZWA>139 093 541</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139093541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187295.867000 506632.812000</gml:lowerCorner>
        		<gml:upperCorner>187295.867000 506632.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187295.867000 506632.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 093 050</ms:GML_ID>
        <ms:NAZWA>139 093 050</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139093050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>187810.467000 506798.791000</gml:lowerCorner>
        		<gml:upperCorner>187810.467000 506798.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>187810.467000 506798.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 092 496</ms:GML_ID>
        <ms:NAZWA>139 092 496</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139092496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188288.835000 506749.353000</gml:lowerCorner>
        		<gml:upperCorner>188288.835000 506749.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188288.835000 506749.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 092 013</ms:GML_ID>
        <ms:NAZWA>139 092 013</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139092013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>188748.868000 506770.822000</gml:lowerCorner>
        		<gml:upperCorner>188748.868000 506770.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>188748.868000 506770.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 091 545</ms:GML_ID>
        <ms:NAZWA>139 091 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139091545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210576.929800 506241.246411</gml:lowerCorner>
        		<gml:upperCorner>210576.929800 506241.246411</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210576.929800 506241.246411</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 064 133</ms:GML_ID>
        <ms:NAZWA>139 064 133</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139064133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211011.257000 506234.247000</gml:lowerCorner>
        		<gml:upperCorner>211011.257000 506234.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211011.257000 506234.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 063 688</ms:GML_ID>
        <ms:NAZWA>139 063 688</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139063688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212072.743000 505853.594000</gml:lowerCorner>
        		<gml:upperCorner>212072.743000 505853.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212072.743000 505853.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 062 486</ms:GML_ID>
        <ms:NAZWA>139 062 486</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139062486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212303.824000 505624.863000</gml:lowerCorner>
        		<gml:upperCorner>212303.824000 505624.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212303.824000 505624.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 062 158</ms:GML_ID>
        <ms:NAZWA>139 062 158</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139062158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212896.230000 505309.307000</gml:lowerCorner>
        		<gml:upperCorner>212896.230000 505309.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212896.230000 505309.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 061 487</ms:GML_ID>
        <ms:NAZWA>139 061 487</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139061487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213191.196000 505156.466000</gml:lowerCorner>
        		<gml:upperCorner>213191.196000 505156.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213191.196000 505156.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 061 153</ms:GML_ID>
        <ms:NAZWA>139 061 153</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139061153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213532.136000 504974.137000</gml:lowerCorner>
        		<gml:upperCorner>213532.136000 504974.137000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213532.136000 504974.137000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 060 768</ms:GML_ID>
        <ms:NAZWA>139 060 768</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139060768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213916.496000 504722.263000</gml:lowerCorner>
        		<gml:upperCorner>213916.496000 504722.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213916.496000 504722.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 060 307</ms:GML_ID>
        <ms:NAZWA>139 060 307</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139060307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214360.381553 504410.960574</gml:lowerCorner>
        		<gml:upperCorner>214360.381553 504410.960574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214360.381553 504410.960574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 059 762</ms:GML_ID>
        <ms:NAZWA>139 059 762</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139059762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214949.330754 503973.028042</gml:lowerCorner>
        		<gml:upperCorner>214949.330754 503973.028042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214949.330754 503973.028042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 059 025</ms:GML_ID>
        <ms:NAZWA>139 059 025</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139059025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215603.546441 503568.540050</gml:lowerCorner>
        		<gml:upperCorner>215603.546441 503568.540050</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215603.546441 503568.540050</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 058 244</ms:GML_ID>
        <ms:NAZWA>139 058 244</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139058244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216702.829000 503487.740000</gml:lowerCorner>
        		<gml:upperCorner>216702.829000 503487.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216702.829000 503487.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 057 129</ms:GML_ID>
        <ms:NAZWA>139 057 129</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139057129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216876.073000 503398.509000</gml:lowerCorner>
        		<gml:upperCorner>216876.073000 503398.509000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216876.073000 503398.509000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 056 935</ms:GML_ID>
        <ms:NAZWA>139 056 935</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139056935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216991.518000 503338.958000</gml:lowerCorner>
        		<gml:upperCorner>216991.518000 503338.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216991.518000 503338.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 056 805</ms:GML_ID>
        <ms:NAZWA>139 056 805</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139056805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217832.726000 501868.732000</gml:lowerCorner>
        		<gml:upperCorner>217832.726000 501868.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217832.726000 501868.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 003 303</ms:GML_ID>
        <ms:NAZWA>190 003 303</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190003303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217895.157130 503277.209710</gml:lowerCorner>
        		<gml:upperCorner>217895.157130 503277.209710</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217895.157130 503277.209710</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 055 870</ms:GML_ID>
        <ms:NAZWA>139 055 870</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139055870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218021.463000 505774.512000</gml:lowerCorner>
        		<gml:upperCorner>218021.463000 505774.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218021.463000 505774.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 055 278</ms:GML_ID>
        <ms:NAZWA>117 055 278</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117055278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218024.168000 502327.680000</gml:lowerCorner>
        		<gml:upperCorner>218024.168000 502327.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218024.168000 502327.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 002 795</ms:GML_ID>
        <ms:NAZWA>190 002 795</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190002795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218213.227058 503250.029980</gml:lowerCorner>
        		<gml:upperCorner>218213.227058 503250.029980</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218213.227058 503250.029980</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 055 548</ms:GML_ID>
        <ms:NAZWA>139 055 548</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139055548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218539.511000 504567.534000</gml:lowerCorner>
        		<gml:upperCorner>218539.511000 504567.534000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218539.511000 504567.534000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 056 640</ms:GML_ID>
        <ms:NAZWA>117 056 640</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117056640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218574.832496 504315.515443</gml:lowerCorner>
        		<gml:upperCorner>218574.832496 504315.515443</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218574.832496 504315.515443</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 056 912</ms:GML_ID>
        <ms:NAZWA>117 056 912</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117056912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218600.027707 504103.990166</gml:lowerCorner>
        		<gml:upperCorner>218600.027707 504103.990166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218600.027707 504103.990166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 057 108</ms:GML_ID>
        <ms:NAZWA>117 057 108</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117057108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218621.575000 503922.042000</gml:lowerCorner>
        		<gml:upperCorner>218621.575000 503922.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218621.575000 503922.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 057 290</ms:GML_ID>
        <ms:NAZWA>117 057 290</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117057290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220059.739000 509606.048000</gml:lowerCorner>
        		<gml:upperCorner>220059.739000 509606.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220059.739000 509606.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 050 714</ms:GML_ID>
        <ms:NAZWA>117 050 714</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117050714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220060.561000 509730.042000</gml:lowerCorner>
        		<gml:upperCorner>220060.561000 509730.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220060.561000 509730.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 050 591</ms:GML_ID>
        <ms:NAZWA>117 050 591</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117050591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220217.966000 510155.987000</gml:lowerCorner>
        		<gml:upperCorner>220217.966000 510155.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220217.966000 510155.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 050 131</ms:GML_ID>
        <ms:NAZWA>117 050 131</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117050131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220333.753347 510348.345765</gml:lowerCorner>
        		<gml:upperCorner>220333.753347 510348.345765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220333.753347 510348.345765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.117 049 904</ms:GML_ID>
        <ms:NAZWA>117 049 904</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>117049904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>221461.824068 502565.630125</gml:lowerCorner>
        		<gml:upperCorner>221461.824068 502565.630125</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>221461.824068 502565.630125</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 052 233</ms:GML_ID>
        <ms:NAZWA>139 052 233</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139052233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222691.617000 502383.656000</gml:lowerCorner>
        		<gml:upperCorner>222691.617000 502383.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222691.617000 502383.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 050 983</ms:GML_ID>
        <ms:NAZWA>139 050 983</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139050983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223685.420832 502196.150533</gml:lowerCorner>
        		<gml:upperCorner>223685.420832 502196.150533</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223685.420832 502196.150533</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 049 969</ms:GML_ID>
        <ms:NAZWA>139 049 969</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139049969</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249875.332000 496944.368000</gml:lowerCorner>
        		<gml:upperCorner>249875.332000 496944.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249875.332000 496944.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 019 366</ms:GML_ID>
        <ms:NAZWA>139 019 366</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139019366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250086.447143 497036.172331</gml:lowerCorner>
        		<gml:upperCorner>250086.447143 497036.172331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250086.447143 497036.172331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 019 138</ms:GML_ID>
        <ms:NAZWA>139 019 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139019138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257861.322000 497163.390000</gml:lowerCorner>
        		<gml:upperCorner>257861.322000 497163.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257861.322000 497163.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 010 924</ms:GML_ID>
        <ms:NAZWA>139 010 924</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139010924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259846.369000 497192.943000</gml:lowerCorner>
        		<gml:upperCorner>259846.369000 497192.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259846.369000 497192.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 008 934</ms:GML_ID>
        <ms:NAZWA>139 008 934</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139008934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260295.856000 497239.574000</gml:lowerCorner>
        		<gml:upperCorner>260295.856000 497239.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260295.856000 497239.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 002 490</ms:GML_ID>
        <ms:NAZWA>140 002 490</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140002490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251426.802005 497267.432041</gml:lowerCorner>
        		<gml:upperCorner>251426.802005 497267.432041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251426.802005 497267.432041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 000 800</ms:GML_ID>
        <ms:NAZWA>169 000 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169000800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250961.023000 497342.401000</gml:lowerCorner>
        		<gml:upperCorner>250961.023000 497342.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250961.023000 497342.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 018 203</ms:GML_ID>
        <ms:NAZWA>139 018 203</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139018203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256263.959000 497500.446000</gml:lowerCorner>
        		<gml:upperCorner>256263.959000 497500.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256263.959000 497500.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 012 616</ms:GML_ID>
        <ms:NAZWA>139 012 616</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139012616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253836.148000 497650.122000</gml:lowerCorner>
        		<gml:upperCorner>253836.148000 497650.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253836.148000 497650.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 015 306</ms:GML_ID>
        <ms:NAZWA>139 015 306</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139015306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256003.689000 497785.350000</gml:lowerCorner>
        		<gml:upperCorner>256003.689000 497785.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256003.689000 497785.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 013 002</ms:GML_ID>
        <ms:NAZWA>139 013 002</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139013002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255786.373000 498259.416000</gml:lowerCorner>
        		<gml:upperCorner>255786.373000 498259.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255786.373000 498259.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 011 462</ms:GML_ID>
        <ms:NAZWA>142 011 462</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142011462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256606.097341 498513.542052</gml:lowerCorner>
        		<gml:upperCorner>256606.097341 498513.542052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256606.097341 498513.542052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 010 605</ms:GML_ID>
        <ms:NAZWA>142 010 605</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142010605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256998.412000 498644.197000</gml:lowerCorner>
        		<gml:upperCorner>256998.412000 498644.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256998.412000 498644.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 010 190</ms:GML_ID>
        <ms:NAZWA>142 010 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142010190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257471.508000 499790.333000</gml:lowerCorner>
        		<gml:upperCorner>257471.508000 499790.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257471.508000 499790.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 008 874</ms:GML_ID>
        <ms:NAZWA>142 008 874</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142008874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259282.016131 501863.664215</gml:lowerCorner>
        		<gml:upperCorner>259282.016131 501863.664215</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259282.016131 501863.664215</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 005 479</ms:GML_ID>
        <ms:NAZWA>142 005 479</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142005479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258598.598000 502080.334000</gml:lowerCorner>
        		<gml:upperCorner>258598.598000 502080.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258598.598000 502080.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 006 253</ms:GML_ID>
        <ms:NAZWA>142 006 253</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142006253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248833.262000 502370.681000</gml:lowerCorner>
        		<gml:upperCorner>248833.262000 502370.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248833.262000 502370.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 006 901</ms:GML_ID>
        <ms:NAZWA>179 006 901</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179006901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248297.308641 503276.500896</gml:lowerCorner>
        		<gml:upperCorner>248297.308641 503276.500896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248297.308641 503276.500896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 007 956</ms:GML_ID>
        <ms:NAZWA>179 007 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179007956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247713.651000 504529.072000</gml:lowerCorner>
        		<gml:upperCorner>247713.651000 504529.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247713.651000 504529.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 009 343</ms:GML_ID>
        <ms:NAZWA>179 009 343</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179009343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247027.259000 505753.057000</gml:lowerCorner>
        		<gml:upperCorner>247027.259000 505753.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247027.259000 505753.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 010 748</ms:GML_ID>
        <ms:NAZWA>179 010 748</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179010748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246362.546340 506928.543744</gml:lowerCorner>
        		<gml:upperCorner>246362.546340 506928.543744</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246362.546340 506928.543744</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 012 099</ms:GML_ID>
        <ms:NAZWA>179 012 099</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179012099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246121.472211 507729.501380</gml:lowerCorner>
        		<gml:upperCorner>246121.472211 507729.501380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246121.472211 507729.501380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 012 950</ms:GML_ID>
        <ms:NAZWA>179 012 950</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179012950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252683.513171 509071.346247</gml:lowerCorner>
        		<gml:upperCorner>252683.513171 509071.346247</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252683.513171 509071.346247</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 020 817</ms:GML_ID>
        <ms:NAZWA>179 020 817</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179020817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253909.531000 509327.907000</gml:lowerCorner>
        		<gml:upperCorner>253909.531000 509327.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253909.531000 509327.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 022 132</ms:GML_ID>
        <ms:NAZWA>179 022 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179022132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247826.610000 509340.449000</gml:lowerCorner>
        		<gml:upperCorner>247826.610000 509340.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247826.610000 509340.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.179 015 784</ms:GML_ID>
        <ms:NAZWA>179 015 784</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>179015784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260040.493000 510686.732000</gml:lowerCorner>
        		<gml:upperCorner>260040.493000 510686.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260040.493000 510686.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 019 464</ms:GML_ID>
        <ms:NAZWA>138 019 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138019464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258370.785000 511164.441000</gml:lowerCorner>
        		<gml:upperCorner>258370.785000 511164.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258370.785000 511164.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 017 718</ms:GML_ID>
        <ms:NAZWA>138 017 718</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138017718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224232.011000 501971.216000</gml:lowerCorner>
        		<gml:upperCorner>224232.011000 501971.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224232.011000 501971.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 049 375</ms:GML_ID>
        <ms:NAZWA>139 049 375</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139049375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224275.610367 501952.138106</gml:lowerCorner>
        		<gml:upperCorner>224275.610367 501952.138106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224275.610367 501952.138106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 049 326</ms:GML_ID>
        <ms:NAZWA>139 049 326</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139049326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225867.816000 501570.357000</gml:lowerCorner>
        		<gml:upperCorner>225867.816000 501570.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225867.816000 501570.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 047 653</ms:GML_ID>
        <ms:NAZWA>139 047 653</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139047653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226460.253399 492646.600606</gml:lowerCorner>
        		<gml:upperCorner>226460.253399 492646.600606</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226460.253399 492646.600606</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.693 003 247</ms:GML_ID>
        <ms:NAZWA>693 003 247</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>693003247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226477.345233 493814.340091</gml:lowerCorner>
        		<gml:upperCorner>226477.345233 493814.340091</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226477.345233 493814.340091</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.150 006 231</ms:GML_ID>
        <ms:NAZWA>150 006 231</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>150006231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226538.272339 493696.487043</gml:lowerCorner>
        		<gml:upperCorner>226538.272339 493696.487043</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226538.272339 493696.487043</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.693 002 127</ms:GML_ID>
        <ms:NAZWA>693 002 127</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>693002127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226614.601000 501607.487000</gml:lowerCorner>
        		<gml:upperCorner>226614.601000 501607.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226614.601000 501607.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 046 899</ms:GML_ID>
        <ms:NAZWA>139 046 899</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139046899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>226968.097000 501760.670000</gml:lowerCorner>
        		<gml:upperCorner>226968.097000 501760.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>226968.097000 501760.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 046 514</ms:GML_ID>
        <ms:NAZWA>139 046 514</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139046514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227560.797644 501274.746432</gml:lowerCorner>
        		<gml:upperCorner>227560.797644 501274.746432</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227560.797644 501274.746432</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 045 637</ms:GML_ID>
        <ms:NAZWA>093 045 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093045637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227590.168277 501296.217475</gml:lowerCorner>
        		<gml:upperCorner>227590.168277 501296.217475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227590.168277 501296.217475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 045 638</ms:GML_ID>
        <ms:NAZWA>093 045 638</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093045638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227637.606534 501330.861815</gml:lowerCorner>
        		<gml:upperCorner>227637.606534 501330.861815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227637.606534 501330.861815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 045 670</ms:GML_ID>
        <ms:NAZWA>093 045 670</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093045670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227903.578503 498737.266043</gml:lowerCorner>
        		<gml:upperCorner>227903.578503 498737.266043</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227903.578503 498737.266043</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.790 001 314</ms:GML_ID>
        <ms:NAZWA>790 001 314</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>790001314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228172.183910 498945.467769</gml:lowerCorner>
        		<gml:upperCorner>228172.183910 498945.467769</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228172.183910 498945.467769</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.790 000 981</ms:GML_ID>
        <ms:NAZWA>790 000 981</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>790000981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228736.177000 503732.564000</gml:lowerCorner>
        		<gml:upperCorner>228736.177000 503732.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228736.177000 503732.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 043 032</ms:GML_ID>
        <ms:NAZWA>093 043 032</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093043032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229329.851000 504754.011000</gml:lowerCorner>
        		<gml:upperCorner>229329.851000 504754.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229329.851000 504754.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 041 853</ms:GML_ID>
        <ms:NAZWA>093 041 853</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093041853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229505.978000 505057.150000</gml:lowerCorner>
        		<gml:upperCorner>229505.978000 505057.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229505.978000 505057.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 041 498</ms:GML_ID>
        <ms:NAZWA>093 041 498</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093041498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229785.225000 505536.422000</gml:lowerCorner>
        		<gml:upperCorner>229785.225000 505536.422000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229785.225000 505536.422000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 040 944</ms:GML_ID>
        <ms:NAZWA>093 040 944</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093040944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229961.784000 505841.244000</gml:lowerCorner>
        		<gml:upperCorner>229961.784000 505841.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229961.784000 505841.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 040 593</ms:GML_ID>
        <ms:NAZWA>093 040 593</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093040593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230873.602322 497542.382306</gml:lowerCorner>
        		<gml:upperCorner>230873.602322 497542.382306</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230873.602322 497542.382306</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 039 510</ms:GML_ID>
        <ms:NAZWA>139 039 510</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139039510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230955.188000 507548.641000</gml:lowerCorner>
        		<gml:upperCorner>230955.188000 507548.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230955.188000 507548.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 038 616</ms:GML_ID>
        <ms:NAZWA>093 038 616</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093038616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230964.338000 507564.371000</gml:lowerCorner>
        		<gml:upperCorner>230964.338000 507564.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230964.338000 507564.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 038 596</ms:GML_ID>
        <ms:NAZWA>093 038 596</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093038596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231438.000000 508378.530000</gml:lowerCorner>
        		<gml:upperCorner>231438.000000 508378.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231438.000000 508378.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 037 648</ms:GML_ID>
        <ms:NAZWA>093 037 648</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093037648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233162.100297 509082.117132</gml:lowerCorner>
        		<gml:upperCorner>233162.100297 509082.117132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233162.100297 509082.117132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 035 696</ms:GML_ID>
        <ms:NAZWA>093 035 696</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093035696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234178.331000 509258.884000</gml:lowerCorner>
        		<gml:upperCorner>234178.331000 509258.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234178.331000 509258.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 034 666</ms:GML_ID>
        <ms:NAZWA>093 034 666</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093034666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234341.393535 496677.796280</gml:lowerCorner>
        		<gml:upperCorner>234341.393535 496677.796280</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234341.393535 496677.796280</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 035 790</ms:GML_ID>
        <ms:NAZWA>139 035 790</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139035790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235438.610000 509587.030000</gml:lowerCorner>
        		<gml:upperCorner>235438.610000 509587.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235438.610000 509587.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 033 349</ms:GML_ID>
        <ms:NAZWA>093 033 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093033349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235750.878000 496632.842000</gml:lowerCorner>
        		<gml:upperCorner>235750.878000 496632.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235750.878000 496632.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 034 368</ms:GML_ID>
        <ms:NAZWA>139 034 368</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139034368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235766.733254 509882.347747</gml:lowerCorner>
        		<gml:upperCorner>235766.733254 509882.347747</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235766.733254 509882.347747</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 032 903</ms:GML_ID>
        <ms:NAZWA>093 032 903</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK KRAKÓW</ms:IDDE>
        <ms:SEARCH>093032903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236528.597000 496359.918000</gml:lowerCorner>
        		<gml:upperCorner>236528.597000 496359.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236528.597000 496359.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 033 541</ms:GML_ID>
        <ms:NAZWA>139 033 541</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139033541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237058.458000 495846.840000</gml:lowerCorner>
        		<gml:upperCorner>237058.458000 495846.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237058.458000 495846.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 003 135</ms:GML_ID>
        <ms:NAZWA>148 003 135</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148003135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237286.155000 495557.971000</gml:lowerCorner>
        		<gml:upperCorner>237286.155000 495557.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237286.155000 495557.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 003 498</ms:GML_ID>
        <ms:NAZWA>148 003 498</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148003498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237517.191000 496009.071000</gml:lowerCorner>
        		<gml:upperCorner>237517.191000 496009.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237517.191000 496009.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 032 493</ms:GML_ID>
        <ms:NAZWA>139 032 493</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139032493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238300.978000 494273.014000</gml:lowerCorner>
        		<gml:upperCorner>238300.978000 494273.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238300.978000 494273.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 005 137</ms:GML_ID>
        <ms:NAZWA>148 005 137</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148005137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238385.122594 495701.345246</gml:lowerCorner>
        		<gml:upperCorner>238385.122594 495701.345246</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238385.122594 495701.345246</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 031 572</ms:GML_ID>
        <ms:NAZWA>139 031 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139031572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270267.468000 491317.463000</gml:lowerCorner>
        		<gml:upperCorner>270267.468000 491317.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270267.468000 491317.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.187 006 830</ms:GML_ID>
        <ms:NAZWA>187 006 830</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>187006830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270541.467000 491337.934000</gml:lowerCorner>
        		<gml:upperCorner>270541.467000 491337.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270541.467000 491337.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.187 007 110</ms:GML_ID>
        <ms:NAZWA>187 007 110</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>187007110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275883.100000 491572.992000</gml:lowerCorner>
        		<gml:upperCorner>275883.100000 491572.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275883.100000 491572.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.165 000 740</ms:GML_ID>
        <ms:NAZWA>165 000 740</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>165000740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284929.961000 492444.078000</gml:lowerCorner>
        		<gml:upperCorner>284929.961000 492444.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284929.961000 492444.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 030 867</ms:GML_ID>
        <ms:NAZWA>131 030 867</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131030867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270454.432797 492964.955958</gml:lowerCorner>
        		<gml:upperCorner>270454.432797 492964.955958</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270454.432797 492964.955958</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.189 001 138</ms:GML_ID>
        <ms:NAZWA>189 001 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>189001138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280039.245777 493170.293160</gml:lowerCorner>
        		<gml:upperCorner>280039.245777 493170.293160</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280039.245777 493170.293160</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.145 014 742</ms:GML_ID>
        <ms:NAZWA>145 014 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>145014742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270795.795147 493223.388588</gml:lowerCorner>
        		<gml:upperCorner>270795.795147 493223.388588</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270795.795147 493223.388588</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.189 001 568</ms:GML_ID>
        <ms:NAZWA>189 001 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>189001568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271031.803516 493370.399546</gml:lowerCorner>
        		<gml:upperCorner>271031.803516 493370.399546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271031.803516 493370.399546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.189 001 848</ms:GML_ID>
        <ms:NAZWA>189 001 848</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>189001848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284234.640000 493742.196000</gml:lowerCorner>
        		<gml:upperCorner>284234.640000 493742.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284234.640000 493742.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 029 333</ms:GML_ID>
        <ms:NAZWA>131 029 333</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131029333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277363.195000 495565.411000</gml:lowerCorner>
        		<gml:upperCorner>277363.195000 495565.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277363.195000 495565.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.145 011 003</ms:GML_ID>
        <ms:NAZWA>145 011 003</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>145011003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271477.394000 499814.587000</gml:lowerCorner>
        		<gml:upperCorner>271477.394000 499814.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271477.394000 499814.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.161 009 338</ms:GML_ID>
        <ms:NAZWA>161 009 338</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>161009338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271508.517000 500271.292000</gml:lowerCorner>
        		<gml:upperCorner>271508.517000 500271.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271508.517000 500271.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.161 008 880</ms:GML_ID>
        <ms:NAZWA>161 008 880</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>161008880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270366.253000 502209.760000</gml:lowerCorner>
        		<gml:upperCorner>270366.253000 502209.760000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270366.253000 502209.760000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.161 006 513</ms:GML_ID>
        <ms:NAZWA>161 006 513</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>161006513</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289489.338000 503425.023000</gml:lowerCorner>
        		<gml:upperCorner>289489.338000 503425.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289489.338000 503425.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 016 186</ms:GML_ID>
        <ms:NAZWA>182 016 186</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182016186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289080.136000 505110.346000</gml:lowerCorner>
        		<gml:upperCorner>289080.136000 505110.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289080.136000 505110.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 017 922</ms:GML_ID>
        <ms:NAZWA>182 017 922</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182017922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288702.569212 506690.520975</gml:lowerCorner>
        		<gml:upperCorner>288702.569212 506690.520975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288702.569212 506690.520975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 019 549</ms:GML_ID>
        <ms:NAZWA>182 019 549</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182019549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278598.282426 506957.734042</gml:lowerCorner>
        		<gml:upperCorner>278598.282426 506957.734042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278598.282426 506957.734042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 004 358</ms:GML_ID>
        <ms:NAZWA>183 004 358</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183004358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278551.488442 507265.247542</gml:lowerCorner>
        		<gml:upperCorner>278551.488442 507265.247542</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278551.488442 507265.247542</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 004 046</ms:GML_ID>
        <ms:NAZWA>183 004 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183004046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278281.894989 507521.581749</gml:lowerCorner>
        		<gml:upperCorner>278281.894989 507521.581749</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278281.894989 507521.581749</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 003 670</ms:GML_ID>
        <ms:NAZWA>183 003 670</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183003670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278095.555593 507966.452836</gml:lowerCorner>
        		<gml:upperCorner>278095.555593 507966.452836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278095.555593 507966.452836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 003 165</ms:GML_ID>
        <ms:NAZWA>183 003 165</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183003165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288476.892000 507997.507000</gml:lowerCorner>
        		<gml:upperCorner>288476.892000 507997.507000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288476.892000 507997.507000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 020 881</ms:GML_ID>
        <ms:NAZWA>182 020 881</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182020881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288561.895328 510464.519313</gml:lowerCorner>
        		<gml:upperCorner>288561.895328 510464.519313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288561.895328 510464.519313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 023 361</ms:GML_ID>
        <ms:NAZWA>182 023 361</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182023361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273752.856000 511350.747000</gml:lowerCorner>
        		<gml:upperCorner>273752.856000 511350.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273752.856000 511350.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 302 015</ms:GML_ID>
        <ms:NAZWA>001 302 015</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001302015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273753.889000 511355.408000</gml:lowerCorner>
        		<gml:upperCorner>273753.889000 511355.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273753.889000 511355.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 302 012</ms:GML_ID>
        <ms:NAZWA>001 302 012</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001302012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276650.656000 513074.228000</gml:lowerCorner>
        		<gml:upperCorner>276650.656000 513074.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276650.656000 513074.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 006 380</ms:GML_ID>
        <ms:NAZWA>183 006 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183006380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274473.132000 515023.866000</gml:lowerCorner>
        		<gml:upperCorner>274473.132000 515023.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274473.132000 515023.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 298 023</ms:GML_ID>
        <ms:NAZWA>001 298 023</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001298023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277501.103504 515081.531942</gml:lowerCorner>
        		<gml:upperCorner>277501.103504 515081.531942</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277501.103504 515081.531942</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.183 004 179</ms:GML_ID>
        <ms:NAZWA>183 004 179</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>183004179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>271988.794143 515174.770344</gml:lowerCorner>
        		<gml:upperCorner>271988.794143 515174.770344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>271988.794143 515174.770344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 071 500</ms:GML_ID>
        <ms:NAZWA>062 071 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062071500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260787.989000 498012.989000</gml:lowerCorner>
        		<gml:upperCorner>260787.989000 498012.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260787.989000 498012.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 001 545</ms:GML_ID>
        <ms:NAZWA>140 001 545</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140001545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>260819.126392 500516.635336</gml:lowerCorner>
        		<gml:upperCorner>260819.126392 500516.635336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>260819.126392 500516.635336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 003 397</ms:GML_ID>
        <ms:NAZWA>142 003 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142003397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261147.788000 499274.215000</gml:lowerCorner>
        		<gml:upperCorner>261147.788000 499274.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261147.788000 499274.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.142 001 836</ms:GML_ID>
        <ms:NAZWA>142 001 836</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>142001836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261496.006000 499609.106000</gml:lowerCorner>
        		<gml:upperCorner>261496.006000 499609.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261496.006000 499609.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.653 001 421</ms:GML_ID>
        <ms:NAZWA>653 001 421</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>653001421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261823.905000 500273.700000</gml:lowerCorner>
        		<gml:upperCorner>261823.905000 500273.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261823.905000 500273.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.707 000 500</ms:GML_ID>
        <ms:NAZWA>707 000 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>707000500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262010.533140 500408.311008</gml:lowerCorner>
        		<gml:upperCorner>262010.533140 500408.311008</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262010.533140 500408.311008</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.652 000 470</ms:GML_ID>
        <ms:NAZWA>652 000 470</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>652000470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262073.046000 500387.211000</gml:lowerCorner>
        		<gml:upperCorner>262073.046000 500387.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262073.046000 500387.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.171 038 097</ms:GML_ID>
        <ms:NAZWA>171 038 097</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>171038097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263409.769778 498351.243508</gml:lowerCorner>
        		<gml:upperCorner>263409.769778 498351.243508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263409.769778 498351.243508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 004 647</ms:GML_ID>
        <ms:NAZWA>139 004 647</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139004647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263531.779000 496896.313000</gml:lowerCorner>
        		<gml:upperCorner>263531.779000 496896.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263531.779000 496896.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 002 567</ms:GML_ID>
        <ms:NAZWA>141 002 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141002567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265250.929852 499972.146765</gml:lowerCorner>
        		<gml:upperCorner>265250.929852 499972.146765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265250.929852 499972.146765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 001 705</ms:GML_ID>
        <ms:NAZWA>139 001 705</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139001705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265385.237000 494627.410000</gml:lowerCorner>
        		<gml:upperCorner>265385.237000 494627.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265385.237000 494627.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 005 698</ms:GML_ID>
        <ms:NAZWA>141 005 698</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141005698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265572.360635 503963.007106</gml:lowerCorner>
        		<gml:upperCorner>265572.360635 503963.007106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265572.360635 503963.007106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.138 030 213</ms:GML_ID>
        <ms:NAZWA>138 030 213</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>138030213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265591.857488 503964.612226</gml:lowerCorner>
        		<gml:upperCorner>265591.857488 503964.612226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265591.857488 503964.612226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 315 622</ms:GML_ID>
        <ms:NAZWA>001 315 622</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001315622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265599.406000 503965.612000</gml:lowerCorner>
        		<gml:upperCorner>265599.406000 503965.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265599.406000 503965.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 315 621</ms:GML_ID>
        <ms:NAZWA>001 315 621</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001315621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265670.364000 492165.760000</gml:lowerCorner>
        		<gml:upperCorner>265670.364000 492165.760000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265670.364000 492165.760000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 008 197</ms:GML_ID>
        <ms:NAZWA>141 008 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141008197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265788.219000 488540.288000</gml:lowerCorner>
        		<gml:upperCorner>265788.219000 488540.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265788.219000 488540.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 011 938</ms:GML_ID>
        <ms:NAZWA>141 011 938</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141011938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265803.028635 489926.540229</gml:lowerCorner>
        		<gml:upperCorner>265803.028635 489926.540229</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265803.028635 489926.540229</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 010 545</ms:GML_ID>
        <ms:NAZWA>141 010 545</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141010545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266345.322000 509860.592000</gml:lowerCorner>
        		<gml:upperCorner>266345.322000 509860.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266345.322000 509860.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 081 592</ms:GML_ID>
        <ms:NAZWA>062 081 592</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062081592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266475.923000 510922.856000</gml:lowerCorner>
        		<gml:upperCorner>266475.923000 510922.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266475.923000 510922.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 080 477</ms:GML_ID>
        <ms:NAZWA>062 080 477</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062080477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266861.597000 496834.953000</gml:lowerCorner>
        		<gml:upperCorner>266861.597000 496834.953000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266861.597000 496834.953000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.164 001 604</ms:GML_ID>
        <ms:NAZWA>164 001 604</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>164001604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267127.107000 515344.652000</gml:lowerCorner>
        		<gml:upperCorner>267127.107000 515344.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267127.107000 515344.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.171 021 452</ms:GML_ID>
        <ms:NAZWA>171 021 452</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>171021452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267332.338000 515484.228000</gml:lowerCorner>
        		<gml:upperCorner>267332.338000 515484.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267332.338000 515484.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 075 637</ms:GML_ID>
        <ms:NAZWA>062 075 637</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062075637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267334.421000 496926.756000</gml:lowerCorner>
        		<gml:upperCorner>267334.421000 496926.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267334.421000 496926.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.164 001 044</ms:GML_ID>
        <ms:NAZWA>164 001 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>164001044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267402.245000 508530.446000</gml:lowerCorner>
        		<gml:upperCorner>267402.245000 508530.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267402.245000 508530.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.660 000 644</ms:GML_ID>
        <ms:NAZWA>660 000 644</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>660000644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267420.419000 508602.348000</gml:lowerCorner>
        		<gml:upperCorner>267420.419000 508602.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267420.419000 508602.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.062 083 336</ms:GML_ID>
        <ms:NAZWA>062 083 336</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>062083336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267728.692000 504686.918000</gml:lowerCorner>
        		<gml:upperCorner>267728.692000 504686.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267728.692000 504686.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.161 002 813</ms:GML_ID>
        <ms:NAZWA>161 002 813</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>161002813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269009.053000 490722.394000</gml:lowerCorner>
        		<gml:upperCorner>269009.053000 490722.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269009.053000 490722.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.187 005 253</ms:GML_ID>
        <ms:NAZWA>187 005 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>187005253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215940.264049 487823.172402</gml:lowerCorner>
        		<gml:upperCorner>215940.264049 487823.172402</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215940.264049 487823.172402</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 018 653</ms:GML_ID>
        <ms:NAZWA>190 018 653</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190018653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225307.988000 487952.582000</gml:lowerCorner>
        		<gml:upperCorner>225307.988000 487952.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225307.988000 487952.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.694 002 215</ms:GML_ID>
        <ms:NAZWA>694 002 215</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>694002215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215930.116000 488690.294000</gml:lowerCorner>
        		<gml:upperCorner>215930.116000 488690.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215930.116000 488690.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 017 775</ms:GML_ID>
        <ms:NAZWA>190 017 775</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190017775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215848.666000 489297.172000</gml:lowerCorner>
        		<gml:upperCorner>215848.666000 489297.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215848.666000 489297.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 017 134</ms:GML_ID>
        <ms:NAZWA>190 017 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190017134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225819.395000 490570.223000</gml:lowerCorner>
        		<gml:upperCorner>225819.395000 490570.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225819.395000 490570.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 056 611</ms:GML_ID>
        <ms:NAZWA>093 056 611</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093056611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216046.722000 491217.351000</gml:lowerCorner>
        		<gml:upperCorner>216046.722000 491217.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216046.722000 491217.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 014 811</ms:GML_ID>
        <ms:NAZWA>190 014 811</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190014811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216034.941000 492024.781000</gml:lowerCorner>
        		<gml:upperCorner>216034.941000 492024.781000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216034.941000 492024.781000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 013 989</ms:GML_ID>
        <ms:NAZWA>190 013 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190013989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215738.934000 492853.919000</gml:lowerCorner>
        		<gml:upperCorner>215738.934000 492853.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215738.934000 492853.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 013 108</ms:GML_ID>
        <ms:NAZWA>190 013 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190013108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215552.287000 493357.421000</gml:lowerCorner>
        		<gml:upperCorner>215552.287000 493357.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215552.287000 493357.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 012 570</ms:GML_ID>
        <ms:NAZWA>190 012 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190012570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215451.862749 493615.154067</gml:lowerCorner>
        		<gml:upperCorner>215451.862749 493615.154067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215451.862749 493615.154067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 012 291</ms:GML_ID>
        <ms:NAZWA>190 012 291</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190012291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215429.580314 494575.356441</gml:lowerCorner>
        		<gml:upperCorner>215429.580314 494575.356441</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215429.580314 494575.356441</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 011 326</ms:GML_ID>
        <ms:NAZWA>190 011 326</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190011326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215471.968085 495143.485434</gml:lowerCorner>
        		<gml:upperCorner>215471.968085 495143.485434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215471.968085 495143.485434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 010 755</ms:GML_ID>
        <ms:NAZWA>190 010 755</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190010755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215504.771338 495394.902704</gml:lowerCorner>
        		<gml:upperCorner>215504.771338 495394.902704</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215504.771338 495394.902704</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 010 503</ms:GML_ID>
        <ms:NAZWA>190 010 503</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190010503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215582.205000 496055.399000</gml:lowerCorner>
        		<gml:upperCorner>215582.205000 496055.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215582.205000 496055.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 009 836</ms:GML_ID>
        <ms:NAZWA>190 009 836</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190009836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215837.902000 497476.503000</gml:lowerCorner>
        		<gml:upperCorner>215837.902000 497476.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215837.902000 497476.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 008 392</ms:GML_ID>
        <ms:NAZWA>190 008 392</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190008392</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215882.521000 497723.722000</gml:lowerCorner>
        		<gml:upperCorner>215882.521000 497723.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215882.521000 497723.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 008 140</ms:GML_ID>
        <ms:NAZWA>190 008 140</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190008140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215935.099000 498016.456000</gml:lowerCorner>
        		<gml:upperCorner>215935.099000 498016.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215935.099000 498016.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 007 843</ms:GML_ID>
        <ms:NAZWA>190 007 843</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190007843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215969.818453 498426.947401</gml:lowerCorner>
        		<gml:upperCorner>215969.818453 498426.947401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215969.818453 498426.947401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 007 426</ms:GML_ID>
        <ms:NAZWA>190 007 426</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190007426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215968.344630 498600.894830</gml:lowerCorner>
        		<gml:upperCorner>215968.344630 498600.894830</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215968.344630 498600.894830</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 007 272</ms:GML_ID>
        <ms:NAZWA>190 007 272</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190007272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215967.182026 498612.100225</gml:lowerCorner>
        		<gml:upperCorner>215967.182026 498612.100225</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215967.182026 498612.100225</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 007 260</ms:GML_ID>
        <ms:NAZWA>190 007 260</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190007260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215942.983000 498871.645000</gml:lowerCorner>
        		<gml:upperCorner>215942.983000 498871.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215942.983000 498871.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 006 982</ms:GML_ID>
        <ms:NAZWA>190 006 982</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190006982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216193.162000 499585.833000</gml:lowerCorner>
        		<gml:upperCorner>216193.162000 499585.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216193.162000 499585.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 006 213</ms:GML_ID>
        <ms:NAZWA>190 006 213</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190006213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216432.708000 500068.203000</gml:lowerCorner>
        		<gml:upperCorner>216432.708000 500068.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216432.708000 500068.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 005 620</ms:GML_ID>
        <ms:NAZWA>190 005 620</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190005620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216559.706000 500254.903000</gml:lowerCorner>
        		<gml:upperCorner>216559.706000 500254.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216559.706000 500254.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 005 439</ms:GML_ID>
        <ms:NAZWA>190 005 439</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190005439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217307.983000 501146.266000</gml:lowerCorner>
        		<gml:upperCorner>217307.983000 501146.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217307.983000 501146.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 004 233</ms:GML_ID>
        <ms:NAZWA>190 004 233</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190004233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217494.701000 501308.225000</gml:lowerCorner>
        		<gml:upperCorner>217494.701000 501308.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217494.701000 501308.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 003 983</ms:GML_ID>
        <ms:NAZWA>190 003 983</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190003983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217673.904000 501532.948000</gml:lowerCorner>
        		<gml:upperCorner>217673.904000 501532.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217673.904000 501532.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 003 685</ms:GML_ID>
        <ms:NAZWA>190 003 685</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190003685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225092.609000 501598.001000</gml:lowerCorner>
        		<gml:upperCorner>225092.609000 501598.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225092.609000 501598.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 048 436</ms:GML_ID>
        <ms:NAZWA>139 048 436</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139048436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183886.570000 499888.638000</gml:lowerCorner>
        		<gml:upperCorner>183886.570000 499888.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183886.570000 499888.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 110 676</ms:GML_ID>
        <ms:NAZWA>139 110 676</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139110676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>183975.999000 500645.927000</gml:lowerCorner>
        		<gml:upperCorner>183975.999000 500645.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>183975.999000 500645.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 109 904</ms:GML_ID>
        <ms:NAZWA>139 109 904</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139109904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194913.253000 491141.505000</gml:lowerCorner>
        		<gml:upperCorner>194913.253000 491141.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194913.253000 491141.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 019 867</ms:GML_ID>
        <ms:NAZWA>191 019 867</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191019867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>194938.611910 490980.258644</gml:lowerCorner>
        		<gml:upperCorner>194938.611910 490980.258644</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>194938.611910 490980.258644</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 019 710</ms:GML_ID>
        <ms:NAZWA>191 019 710</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191019710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>195717.613000 490819.142000</gml:lowerCorner>
        		<gml:upperCorner>195717.613000 490819.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>195717.613000 490819.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 018 664</ms:GML_ID>
        <ms:NAZWA>191 018 664</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191018664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>196903.895000 490464.579000</gml:lowerCorner>
        		<gml:upperCorner>196903.895000 490464.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>196903.895000 490464.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 017 361</ms:GML_ID>
        <ms:NAZWA>191 017 361</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191017361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>197283.432000 490433.205000</gml:lowerCorner>
        		<gml:upperCorner>197283.432000 490433.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>197283.432000 490433.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 016 960</ms:GML_ID>
        <ms:NAZWA>191 016 960</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191016960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198213.592000 490140.413000</gml:lowerCorner>
        		<gml:upperCorner>198213.592000 490140.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198213.592000 490140.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 015 659</ms:GML_ID>
        <ms:NAZWA>191 015 659</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191015659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198436.264000 489823.102000</gml:lowerCorner>
        		<gml:upperCorner>198436.264000 489823.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198436.264000 489823.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 015 248</ms:GML_ID>
        <ms:NAZWA>191 015 248</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191015248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198708.961068 489690.718345</gml:lowerCorner>
        		<gml:upperCorner>198708.961068 489690.718345</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198708.961068 489690.718345</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 014 945</ms:GML_ID>
        <ms:NAZWA>191 014 945</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191014945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198831.222803 489630.226998</gml:lowerCorner>
        		<gml:upperCorner>198831.222803 489630.226998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198831.222803 489630.226998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 014 809</ms:GML_ID>
        <ms:NAZWA>191 014 809</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191014809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>198896.026459 489598.148678</gml:lowerCorner>
        		<gml:upperCorner>198896.026459 489598.148678</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>198896.026459 489598.148678</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 014 736</ms:GML_ID>
        <ms:NAZWA>191 014 736</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191014736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199098.389193 489453.628032</gml:lowerCorner>
        		<gml:upperCorner>199098.389193 489453.628032</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199098.389193 489453.628032</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 014 487</ms:GML_ID>
        <ms:NAZWA>191 014 487</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191014487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>199863.407000 489029.289000</gml:lowerCorner>
        		<gml:upperCorner>199863.407000 489029.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>199863.407000 489029.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 013 578</ms:GML_ID>
        <ms:NAZWA>191 013 578</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191013578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200495.107000 489052.488000</gml:lowerCorner>
        		<gml:upperCorner>200495.107000 489052.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200495.107000 489052.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 012 919</ms:GML_ID>
        <ms:NAZWA>191 012 919</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191012919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>200821.856000 489111.360000</gml:lowerCorner>
        		<gml:upperCorner>200821.856000 489111.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>200821.856000 489111.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 012 586</ms:GML_ID>
        <ms:NAZWA>191 012 586</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191012586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201036.556596 489070.246312</gml:lowerCorner>
        		<gml:upperCorner>201036.556596 489070.246312</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201036.556596 489070.246312</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 012 361</ms:GML_ID>
        <ms:NAZWA>191 012 361</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191012361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>201809.342000 488400.893000</gml:lowerCorner>
        		<gml:upperCorner>201809.342000 488400.893000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>201809.342000 488400.893000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 011 257</ms:GML_ID>
        <ms:NAZWA>191 011 257</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191011257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202359.259000 488156.336000</gml:lowerCorner>
        		<gml:upperCorner>202359.259000 488156.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202359.259000 488156.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 010 654</ms:GML_ID>
        <ms:NAZWA>191 010 654</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191010654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202733.845000 487989.364000</gml:lowerCorner>
        		<gml:upperCorner>202733.845000 487989.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202733.845000 487989.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 010 243</ms:GML_ID>
        <ms:NAZWA>191 010 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191010243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>202953.047000 487891.599000</gml:lowerCorner>
        		<gml:upperCorner>202953.047000 487891.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>202953.047000 487891.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 010 003</ms:GML_ID>
        <ms:NAZWA>191 010 003</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191010003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203095.722000 487827.998000</gml:lowerCorner>
        		<gml:upperCorner>203095.722000 487827.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203095.722000 487827.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 009 848</ms:GML_ID>
        <ms:NAZWA>191 009 848</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191009848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203154.942337 487797.155688</gml:lowerCorner>
        		<gml:upperCorner>203154.942337 487797.155688</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203154.942337 487797.155688</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 009 780</ms:GML_ID>
        <ms:NAZWA>191 009 780</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191009780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203191.957246 487775.827643</gml:lowerCorner>
        		<gml:upperCorner>203191.957246 487775.827643</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203191.957246 487775.827643</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 009 738</ms:GML_ID>
        <ms:NAZWA>191 009 738</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191009738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215388.175000 494063.883000</gml:lowerCorner>
        		<gml:upperCorner>215388.175000 494063.883000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215388.175000 494063.883000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 011 839</ms:GML_ID>
        <ms:NAZWA>190 011 839</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190011839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215409.827000 494364.026000</gml:lowerCorner>
        		<gml:upperCorner>215409.827000 494364.026000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215409.827000 494364.026000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 011 539</ms:GML_ID>
        <ms:NAZWA>190 011 539</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190011539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251760.958876 487837.889534</gml:lowerCorner>
        		<gml:upperCorner>251760.958876 487837.889534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251760.958876 487837.889534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 010 494</ms:GML_ID>
        <ms:NAZWA>169 010 494</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169010494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251724.886000 488090.558000</gml:lowerCorner>
        		<gml:upperCorner>251724.886000 488090.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251724.886000 488090.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 010 235</ms:GML_ID>
        <ms:NAZWA>169 010 235</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169010235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251714.884848 488175.192501</gml:lowerCorner>
        		<gml:upperCorner>251714.884848 488175.192501</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251714.884848 488175.192501</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 010 152</ms:GML_ID>
        <ms:NAZWA>169 010 152</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169010152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240506.643000 488299.664000</gml:lowerCorner>
        		<gml:upperCorner>240506.643000 488299.664000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240506.643000 488299.664000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 011 544</ms:GML_ID>
        <ms:NAZWA>148 011 544</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148011544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251677.757000 488486.297000</gml:lowerCorner>
        		<gml:upperCorner>251677.757000 488486.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251677.757000 488486.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 009 832</ms:GML_ID>
        <ms:NAZWA>169 009 832</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169009832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251662.956000 488608.218000</gml:lowerCorner>
        		<gml:upperCorner>251662.956000 488608.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251662.956000 488608.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 009 715</ms:GML_ID>
        <ms:NAZWA>169 009 715</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169009715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254697.877000 488813.975000</gml:lowerCorner>
        		<gml:upperCorner>254697.877000 488813.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254697.877000 488813.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 013 127</ms:GML_ID>
        <ms:NAZWA>140 013 127</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140013127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254730.639000 489092.835000</gml:lowerCorner>
        		<gml:upperCorner>254730.639000 489092.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254730.639000 489092.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 012 849</ms:GML_ID>
        <ms:NAZWA>140 012 849</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140012849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251363.515411 491038.363124</gml:lowerCorner>
        		<gml:upperCorner>251363.515411 491038.363124</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251363.515411 491038.363124</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 007 267</ms:GML_ID>
        <ms:NAZWA>169 007 267</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169007267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251142.442000 491463.868000</gml:lowerCorner>
        		<gml:upperCorner>251142.442000 491463.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251142.442000 491463.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 006 780</ms:GML_ID>
        <ms:NAZWA>169 006 780</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169006780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250965.981000 491719.369000</gml:lowerCorner>
        		<gml:upperCorner>250965.981000 491719.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250965.981000 491719.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 006 468</ms:GML_ID>
        <ms:NAZWA>169 006 468</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169006468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239324.572000 491865.942000</gml:lowerCorner>
        		<gml:upperCorner>239324.572000 491865.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239324.572000 491865.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 007 784</ms:GML_ID>
        <ms:NAZWA>148 007 784</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148007784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255925.610000 491976.011000</gml:lowerCorner>
        		<gml:upperCorner>255925.610000 491976.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255925.610000 491976.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 009 662</ms:GML_ID>
        <ms:NAZWA>140 009 662</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140009662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239041.258000 492720.821000</gml:lowerCorner>
        		<gml:upperCorner>239041.258000 492720.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239041.258000 492720.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 006 879</ms:GML_ID>
        <ms:NAZWA>148 006 879</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148006879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250847.468000 492773.621000</gml:lowerCorner>
        		<gml:upperCorner>250847.468000 492773.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250847.468000 492773.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 005 397</ms:GML_ID>
        <ms:NAZWA>169 005 397</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169005397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257215.494000 493213.550000</gml:lowerCorner>
        		<gml:upperCorner>257215.494000 493213.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257215.494000 493213.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 007 629</ms:GML_ID>
        <ms:NAZWA>140 007 629</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140007629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250820.927000 493306.198000</gml:lowerCorner>
        		<gml:upperCorner>250820.927000 493306.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250820.927000 493306.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 004 863</ms:GML_ID>
        <ms:NAZWA>169 004 863</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169004863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238812.251000 493410.450000</gml:lowerCorner>
        		<gml:upperCorner>238812.251000 493410.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238812.251000 493410.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 006 155</ms:GML_ID>
        <ms:NAZWA>148 006 155</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148006155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250809.844000 493534.268000</gml:lowerCorner>
        		<gml:upperCorner>250809.844000 493534.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250809.844000 493534.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 004 635</ms:GML_ID>
        <ms:NAZWA>169 004 635</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169004635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258213.888000 493982.892000</gml:lowerCorner>
        		<gml:upperCorner>258213.888000 493982.892000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258213.888000 493982.892000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 006 361</ms:GML_ID>
        <ms:NAZWA>140 006 361</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140006361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238525.822000 493988.133000</gml:lowerCorner>
        		<gml:upperCorner>238525.822000 493988.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238525.822000 493988.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 005 501</ms:GML_ID>
        <ms:NAZWA>148 005 501</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148005501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258486.264926 494393.244584</gml:lowerCorner>
        		<gml:upperCorner>258486.264926 494393.244584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258486.264926 494393.244584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 005 869</ms:GML_ID>
        <ms:NAZWA>140 005 869</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140005869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250762.795000 494748.576000</gml:lowerCorner>
        		<gml:upperCorner>250762.795000 494748.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250762.795000 494748.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 003 418</ms:GML_ID>
        <ms:NAZWA>169 003 418</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169003418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258912.977000 495070.933000</gml:lowerCorner>
        		<gml:upperCorner>258912.977000 495070.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258912.977000 495070.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 005 065</ms:GML_ID>
        <ms:NAZWA>140 005 065</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140005065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249202.284000 496649.129000</gml:lowerCorner>
        		<gml:upperCorner>249202.284000 496649.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249202.284000 496649.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.139 020 101</ms:GML_ID>
        <ms:NAZWA>139 020 101</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>139020101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214074.292589 484927.195137</gml:lowerCorner>
        		<gml:upperCorner>214074.292589 484927.195137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214074.292589 484927.195137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 022 148</ms:GML_ID>
        <ms:NAZWA>190 022 148</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190022148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214279.545000 485116.367000</gml:lowerCorner>
        		<gml:upperCorner>214279.545000 485116.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214279.545000 485116.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 021 864</ms:GML_ID>
        <ms:NAZWA>190 021 864</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190021864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214463.467000 485744.982000</gml:lowerCorner>
        		<gml:upperCorner>214463.467000 485744.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214463.467000 485744.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 021 210</ms:GML_ID>
        <ms:NAZWA>190 021 210</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190021210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214547.279895 485669.759933</gml:lowerCorner>
        		<gml:upperCorner>214547.279895 485669.759933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214547.279895 485669.759933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 023 443</ms:GML_ID>
        <ms:NAZWA>157 023 443</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157023443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>214778.002000 486256.503000</gml:lowerCorner>
        		<gml:upperCorner>214778.002000 486256.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>214778.002000 486256.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 020 603</ms:GML_ID>
        <ms:NAZWA>190 020 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190020603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215036.903000 486598.003000</gml:lowerCorner>
        		<gml:upperCorner>215036.903000 486598.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215036.903000 486598.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 020 175</ms:GML_ID>
        <ms:NAZWA>190 020 175</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190020175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215098.476000 485797.595000</gml:lowerCorner>
        		<gml:upperCorner>215098.476000 485797.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215098.476000 485797.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 022 875</ms:GML_ID>
        <ms:NAZWA>157 022 875</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157022875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215337.215000 486993.661000</gml:lowerCorner>
        		<gml:upperCorner>215337.215000 486993.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215337.215000 486993.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 019 677</ms:GML_ID>
        <ms:NAZWA>190 019 677</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190019677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215835.625204 487642.253887</gml:lowerCorner>
        		<gml:upperCorner>215835.625204 487642.253887</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215835.625204 487642.253887</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 018 861</ms:GML_ID>
        <ms:NAZWA>190 018 861</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190018861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215836.694000 485955.313000</gml:lowerCorner>
        		<gml:upperCorner>215836.694000 485955.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215836.694000 485955.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 022 120</ms:GML_ID>
        <ms:NAZWA>157 022 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157022120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215907.279900 487759.232218</gml:lowerCorner>
        		<gml:upperCorner>215907.279900 487759.232218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215907.279900 487759.232218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 018 719</ms:GML_ID>
        <ms:NAZWA>190 018 719</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190018719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>216988.199000 486202.809000</gml:lowerCorner>
        		<gml:upperCorner>216988.199000 486202.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>216988.199000 486202.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 020 942</ms:GML_ID>
        <ms:NAZWA>157 020 942</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157020942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>217631.421000 486373.879000</gml:lowerCorner>
        		<gml:upperCorner>217631.421000 486373.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>217631.421000 486373.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 020 274</ms:GML_ID>
        <ms:NAZWA>157 020 274</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157020274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218216.447800 486606.906191</gml:lowerCorner>
        		<gml:upperCorner>218216.447800 486606.906191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218216.447800 486606.906191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 019 645</ms:GML_ID>
        <ms:NAZWA>157 019 645</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157019645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218618.053000 486759.167000</gml:lowerCorner>
        		<gml:upperCorner>218618.053000 486759.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218618.053000 486759.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 019 213</ms:GML_ID>
        <ms:NAZWA>157 019 213</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157019213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219044.816000 486865.734000</gml:lowerCorner>
        		<gml:upperCorner>219044.816000 486865.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219044.816000 486865.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 018 773</ms:GML_ID>
        <ms:NAZWA>157 018 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157018773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222647.476000 486454.408000</gml:lowerCorner>
        		<gml:upperCorner>222647.476000 486454.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222647.476000 486454.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 015 040</ms:GML_ID>
        <ms:NAZWA>157 015 040</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157015040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223284.629000 486626.243000</gml:lowerCorner>
        		<gml:upperCorner>223284.629000 486626.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223284.629000 486626.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 014 375</ms:GML_ID>
        <ms:NAZWA>157 014 375</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157014375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223582.119000 486645.745000</gml:lowerCorner>
        		<gml:upperCorner>223582.119000 486645.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223582.119000 486645.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 014 076</ms:GML_ID>
        <ms:NAZWA>157 014 076</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157014076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224101.895000 486739.446000</gml:lowerCorner>
        		<gml:upperCorner>224101.895000 486739.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224101.895000 486739.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 013 543</ms:GML_ID>
        <ms:NAZWA>157 013 543</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157013543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224411.441000 487050.094000</gml:lowerCorner>
        		<gml:upperCorner>224411.441000 487050.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224411.441000 487050.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 013 103</ms:GML_ID>
        <ms:NAZWA>157 013 103</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157013103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224519.119000 483171.192000</gml:lowerCorner>
        		<gml:upperCorner>224519.119000 483171.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224519.119000 483171.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 064 126</ms:GML_ID>
        <ms:NAZWA>093 064 126</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093064126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224605.286000 483660.657000</gml:lowerCorner>
        		<gml:upperCorner>224605.286000 483660.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224605.286000 483660.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 063 629</ms:GML_ID>
        <ms:NAZWA>093 063 629</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093063629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224752.552000 484498.435000</gml:lowerCorner>
        		<gml:upperCorner>224752.552000 484498.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224752.552000 484498.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 062 777</ms:GML_ID>
        <ms:NAZWA>093 062 777</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093062777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224756.613000 487412.877000</gml:lowerCorner>
        		<gml:upperCorner>224756.613000 487412.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224756.613000 487412.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 012 597</ms:GML_ID>
        <ms:NAZWA>157 012 597</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157012597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225078.625000 487397.939000</gml:lowerCorner>
        		<gml:upperCorner>225078.625000 487397.939000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225078.625000 487397.939000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 012 253</ms:GML_ID>
        <ms:NAZWA>157 012 253</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157012253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225100.520090 486473.314135</gml:lowerCorner>
        		<gml:upperCorner>225100.520090 486473.314135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225100.520090 486473.314135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 060 771</ms:GML_ID>
        <ms:NAZWA>093 060 771</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093060771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225155.994124 486788.988474</gml:lowerCorner>
        		<gml:upperCorner>225155.994124 486788.988474</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225155.994124 486788.988474</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 060 447</ms:GML_ID>
        <ms:NAZWA>093 060 447</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093060447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225219.356000 487152.799000</gml:lowerCorner>
        		<gml:upperCorner>225219.356000 487152.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225219.356000 487152.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 060 083</ms:GML_ID>
        <ms:NAZWA>093 060 083</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093060083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208277.682000 481793.097000</gml:lowerCorner>
        		<gml:upperCorner>208277.682000 481793.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208277.682000 481793.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 000 711</ms:GML_ID>
        <ms:NAZWA>191 000 711</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191000711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208816.703530 481871.301148</gml:lowerCorner>
        		<gml:upperCorner>208816.703530 481871.301148</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208816.703530 481871.301148</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 028 518</ms:GML_ID>
        <ms:NAZWA>190 028 518</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190028518</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209050.042359 482132.106073</gml:lowerCorner>
        		<gml:upperCorner>209050.042359 482132.106073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209050.042359 482132.106073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 028 161</ms:GML_ID>
        <ms:NAZWA>190 028 161</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190028161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208150.302000 482147.573000</gml:lowerCorner>
        		<gml:upperCorner>208150.302000 482147.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208150.302000 482147.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 001 089</ms:GML_ID>
        <ms:NAZWA>191 001 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191001089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209472.412000 482425.082000</gml:lowerCorner>
        		<gml:upperCorner>209472.412000 482425.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209472.412000 482425.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 027 645</ms:GML_ID>
        <ms:NAZWA>190 027 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190027645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207989.671000 482740.791000</gml:lowerCorner>
        		<gml:upperCorner>207989.671000 482740.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207989.671000 482740.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 001 707</ms:GML_ID>
        <ms:NAZWA>191 001 707</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191001707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210411.068000 482992.823000</gml:lowerCorner>
        		<gml:upperCorner>210411.068000 482992.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210411.068000 482992.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 026 531</ms:GML_ID>
        <ms:NAZWA>190 026 531</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190026531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207975.798000 482993.437000</gml:lowerCorner>
        		<gml:upperCorner>207975.798000 482993.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207975.798000 482993.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 001 962</ms:GML_ID>
        <ms:NAZWA>191 001 962</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191001962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211575.701000 484051.799000</gml:lowerCorner>
        		<gml:upperCorner>211575.701000 484051.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211575.701000 484051.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 024 859</ms:GML_ID>
        <ms:NAZWA>190 024 859</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190024859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207682.607000 484202.132000</gml:lowerCorner>
        		<gml:upperCorner>207682.607000 484202.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207682.607000 484202.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 003 315</ms:GML_ID>
        <ms:NAZWA>191 003 315</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191003315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212442.645000 484421.743000</gml:lowerCorner>
        		<gml:upperCorner>212442.645000 484421.743000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212442.645000 484421.743000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 023 901</ms:GML_ID>
        <ms:NAZWA>190 023 901</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190023901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207298.313000 484743.078000</gml:lowerCorner>
        		<gml:upperCorner>207298.313000 484743.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207298.313000 484743.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 004 030</ms:GML_ID>
        <ms:NAZWA>191 004 030</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191004030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206726.608000 485241.776000</gml:lowerCorner>
        		<gml:upperCorner>206726.608000 485241.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206726.608000 485241.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 004 815</ms:GML_ID>
        <ms:NAZWA>191 004 815</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191004815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206730.971958 485515.954649</gml:lowerCorner>
        		<gml:upperCorner>206730.971958 485515.954649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206730.971958 485515.954649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 005 091</ms:GML_ID>
        <ms:NAZWA>191 005 091</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191005091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206760.745403 485803.586464</gml:lowerCorner>
        		<gml:upperCorner>206760.745403 485803.586464</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206760.745403 485803.586464</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 005 393</ms:GML_ID>
        <ms:NAZWA>191 005 393</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191005393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206774.822000 485999.076000</gml:lowerCorner>
        		<gml:upperCorner>206774.822000 485999.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206774.822000 485999.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 005 577</ms:GML_ID>
        <ms:NAZWA>191 005 577</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191005577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206591.633000 486211.664000</gml:lowerCorner>
        		<gml:upperCorner>206591.633000 486211.664000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206591.633000 486211.664000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 005 872</ms:GML_ID>
        <ms:NAZWA>191 005 872</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191005872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>206014.885000 486708.861000</gml:lowerCorner>
        		<gml:upperCorner>206014.885000 486708.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>206014.885000 486708.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 006 640</ms:GML_ID>
        <ms:NAZWA>191 006 640</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191006640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>205470.404000 487069.644000</gml:lowerCorner>
        		<gml:upperCorner>205470.404000 487069.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>205470.404000 487069.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 007 301</ms:GML_ID>
        <ms:NAZWA>191 007 301</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191007301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>204655.562000 487137.627000</gml:lowerCorner>
        		<gml:upperCorner>204655.562000 487137.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>204655.562000 487137.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 008 123</ms:GML_ID>
        <ms:NAZWA>191 008 123</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191008123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>203451.620000 487669.506000</gml:lowerCorner>
        		<gml:upperCorner>203451.620000 487669.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>203451.620000 487669.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 009 457</ms:GML_ID>
        <ms:NAZWA>191 009 457</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191009457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700381.001000 635812.423000</gml:lowerCorner>
        		<gml:upperCorner>700381.001000 635812.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700381.001000 635812.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 361 109</ms:GML_ID>
        <ms:NAZWA>353 361 109</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353361109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704040.028000 636855.496000</gml:lowerCorner>
        		<gml:upperCorner>704040.028000 636855.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704040.028000 636855.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 204 785</ms:GML_ID>
        <ms:NAZWA>038 204 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038204785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702586.810000 637403.034000</gml:lowerCorner>
        		<gml:upperCorner>702586.810000 637403.034000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702586.810000 637403.034000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 363 828</ms:GML_ID>
        <ms:NAZWA>353 363 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353363828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703341.758000 638674.087000</gml:lowerCorner>
        		<gml:upperCorner>703341.758000 638674.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703341.758000 638674.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 202 833</ms:GML_ID>
        <ms:NAZWA>038 202 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038202833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703420.908000 638676.904000</gml:lowerCorner>
        		<gml:upperCorner>703420.908000 638676.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703420.908000 638676.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 365 555</ms:GML_ID>
        <ms:NAZWA>353 365 555</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353365555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702896.583067 639643.358091</gml:lowerCorner>
        		<gml:upperCorner>702896.583067 639643.358091</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702896.583067 639643.358091</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 201 764</ms:GML_ID>
        <ms:NAZWA>038 201 764</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038201764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702949.387130 639657.273468</gml:lowerCorner>
        		<gml:upperCorner>702949.387130 639657.273468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702949.387130 639657.273468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 366 644</ms:GML_ID>
        <ms:NAZWA>353 366 644</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353366644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702359.247275 640955.543024</gml:lowerCorner>
        		<gml:upperCorner>702359.247275 640955.543024</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702359.247275 640955.543024</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 200 344</ms:GML_ID>
        <ms:NAZWA>038 200 344</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038200344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703643.427000 641953.082000</gml:lowerCorner>
        		<gml:upperCorner>703643.427000 641953.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703643.427000 641953.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 369 542</ms:GML_ID>
        <ms:NAZWA>353 369 542</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353369542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701290.208000 642300.980000</gml:lowerCorner>
        		<gml:upperCorner>701290.208000 642300.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701290.208000 642300.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 198 579</ms:GML_ID>
        <ms:NAZWA>038 198 579</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038198579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704740.596000 642509.583000</gml:lowerCorner>
        		<gml:upperCorner>704740.596000 642509.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704740.596000 642509.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 370 775</ms:GML_ID>
        <ms:NAZWA>353 370 775</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353370775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699872.101000 643315.523000</gml:lowerCorner>
        		<gml:upperCorner>699872.101000 643315.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699872.101000 643315.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 196 836</ms:GML_ID>
        <ms:NAZWA>038 196 836</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038196836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708293.515000 644508.499000</gml:lowerCorner>
        		<gml:upperCorner>708293.515000 644508.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708293.515000 644508.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 374 856</ms:GML_ID>
        <ms:NAZWA>353 374 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353374856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709681.023000 645398.402000</gml:lowerCorner>
        		<gml:upperCorner>709681.023000 645398.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709681.023000 645398.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 376 505</ms:GML_ID>
        <ms:NAZWA>353 376 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353376505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710670.268000 646030.831000</gml:lowerCorner>
        		<gml:upperCorner>710670.268000 646030.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710670.268000 646030.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 377 679</ms:GML_ID>
        <ms:NAZWA>353 377 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353377679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711337.641000 646458.140000</gml:lowerCorner>
        		<gml:upperCorner>711337.641000 646458.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711337.641000 646458.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 378 472</ms:GML_ID>
        <ms:NAZWA>353 378 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353378472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713989.090284 647796.564218</gml:lowerCorner>
        		<gml:upperCorner>713989.090284 647796.564218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713989.090284 647796.564218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 381 469</ms:GML_ID>
        <ms:NAZWA>353 381 469</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353381469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718254.178000 648602.438000</gml:lowerCorner>
        		<gml:upperCorner>718254.178000 648602.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718254.178000 648602.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 385 820</ms:GML_ID>
        <ms:NAZWA>353 385 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353385820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718247.072060 648647.832211</gml:lowerCorner>
        		<gml:upperCorner>718247.072060 648647.832211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718247.072060 648647.832211</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.205 050 834</ms:GML_ID>
        <ms:NAZWA>205 050 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>205050834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719536.835521 648811.581810</gml:lowerCorner>
        		<gml:upperCorner>719536.835521 648811.581810</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719536.835521 648811.581810</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 387 119</ms:GML_ID>
        <ms:NAZWA>353 387 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353387119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717200.341169 648909.789456</gml:lowerCorner>
        		<gml:upperCorner>717200.341169 648909.789456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717200.341169 648909.789456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.205 051 947</ms:GML_ID>
        <ms:NAZWA>205 051 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>205051947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715241.313000 649685.073000</gml:lowerCorner>
        		<gml:upperCorner>715241.313000 649685.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715241.313000 649685.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.205 054 056</ms:GML_ID>
        <ms:NAZWA>205 054 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>205054056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689776.725000 631946.621000</gml:lowerCorner>
        		<gml:upperCorner>689776.725000 631946.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689776.725000 631946.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 349 396</ms:GML_ID>
        <ms:NAZWA>353 349 396</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353349396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690640.548000 632320.882000</gml:lowerCorner>
        		<gml:upperCorner>690640.548000 632320.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690640.548000 632320.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 350 351</ms:GML_ID>
        <ms:NAZWA>353 350 351</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353350351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691154.868660 632357.943437</gml:lowerCorner>
        		<gml:upperCorner>691154.868660 632357.943437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691154.868660 632357.943437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 350 866</ms:GML_ID>
        <ms:NAZWA>353 350 866</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353350866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692083.617286 632437.029177</gml:lowerCorner>
        		<gml:upperCorner>692083.617286 632437.029177</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692083.617286 632437.029177</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 351 802</ms:GML_ID>
        <ms:NAZWA>353 351 802</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353351802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692919.435618 632512.254446</gml:lowerCorner>
        		<gml:upperCorner>692919.435618 632512.254446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692919.435618 632512.254446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 352 637</ms:GML_ID>
        <ms:NAZWA>353 352 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353352637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695919.426572 633953.528771</gml:lowerCorner>
        		<gml:upperCorner>695919.426572 633953.528771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695919.426572 633953.528771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 356 111</ms:GML_ID>
        <ms:NAZWA>353 356 111</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353356111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696526.015000 634215.235000</gml:lowerCorner>
        		<gml:upperCorner>696526.015000 634215.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696526.015000 634215.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 356 780</ms:GML_ID>
        <ms:NAZWA>353 356 780</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353356780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699852.786000 635403.706000</gml:lowerCorner>
        		<gml:upperCorner>699852.786000 635403.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699852.786000 635403.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 360 442</ms:GML_ID>
        <ms:NAZWA>353 360 442</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353360442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697969.276035 645412.977279</gml:lowerCorner>
        		<gml:upperCorner>697969.276035 645412.977279</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697969.276035 645412.977279</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 193 994</ms:GML_ID>
        <ms:NAZWA>038 193 994</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038193994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697430.204000 645911.446000</gml:lowerCorner>
        		<gml:upperCorner>697430.204000 645911.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697430.204000 645911.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 193 249</ms:GML_ID>
        <ms:NAZWA>038 193 249</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038193249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695468.992000 647037.002000</gml:lowerCorner>
        		<gml:upperCorner>695468.992000 647037.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695468.992000 647037.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 190 986</ms:GML_ID>
        <ms:NAZWA>038 190 986</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038190986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694230.876061 648010.850838</gml:lowerCorner>
        		<gml:upperCorner>694230.876061 648010.850838</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694230.876061 648010.850838</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 189 396</ms:GML_ID>
        <ms:NAZWA>038 189 396</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038189396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668633.672000 648571.488000</gml:lowerCorner>
        		<gml:upperCorner>668633.672000 648571.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668633.672000 648571.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 031 068</ms:GML_ID>
        <ms:NAZWA>223 031 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223031068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693722.567060 649020.511980</gml:lowerCorner>
        		<gml:upperCorner>693722.567060 649020.511980</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693722.567060 649020.511980</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 188 266</ms:GML_ID>
        <ms:NAZWA>038 188 266</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038188266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692991.123194 650499.165162</gml:lowerCorner>
        		<gml:upperCorner>692991.123194 650499.165162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692991.123194 650499.165162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 186 614</ms:GML_ID>
        <ms:NAZWA>038 186 614</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038186614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692210.408000 651489.803000</gml:lowerCorner>
        		<gml:upperCorner>692210.408000 651489.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692210.408000 651489.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 185 334</ms:GML_ID>
        <ms:NAZWA>038 185 334</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038185334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691540.692267 652649.376111</gml:lowerCorner>
        		<gml:upperCorner>691540.692267 652649.376111</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691540.692267 652649.376111</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 183 956</ms:GML_ID>
        <ms:NAZWA>038 183 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038183956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692486.181966 655717.793383</gml:lowerCorner>
        		<gml:upperCorner>692486.181966 655717.793383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692486.181966 655717.793383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 180 678</ms:GML_ID>
        <ms:NAZWA>038 180 678</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038180678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692137.746000 658560.781000</gml:lowerCorner>
        		<gml:upperCorner>692137.746000 658560.781000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692137.746000 658560.781000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 177 758</ms:GML_ID>
        <ms:NAZWA>038 177 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038177758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635240.702000 647190.195000</gml:lowerCorner>
        		<gml:upperCorner>635240.702000 647190.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635240.702000 647190.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 060 093</ms:GML_ID>
        <ms:NAZWA>219 060 093</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219060093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635364.098000 647506.703000</gml:lowerCorner>
        		<gml:upperCorner>635364.098000 647506.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635364.098000 647506.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 060 434</ms:GML_ID>
        <ms:NAZWA>219 060 434</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219060434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635886.489000 648474.544000</gml:lowerCorner>
        		<gml:upperCorner>635886.489000 648474.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635886.489000 648474.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 061 535</ms:GML_ID>
        <ms:NAZWA>219 061 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219061535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635991.658000 650305.512000</gml:lowerCorner>
        		<gml:upperCorner>635991.658000 650305.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635991.658000 650305.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 063 375</ms:GML_ID>
        <ms:NAZWA>219 063 375</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219063375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665230.132000 634765.178000</gml:lowerCorner>
        		<gml:upperCorner>665230.132000 634765.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665230.132000 634765.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 014 990</ms:GML_ID>
        <ms:NAZWA>223 014 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223014990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665275.425000 634216.876000</gml:lowerCorner>
        		<gml:upperCorner>665275.425000 634216.876000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665275.425000 634216.876000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 014 430</ms:GML_ID>
        <ms:NAZWA>223 014 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223014430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665301.838000 635472.150000</gml:lowerCorner>
        		<gml:upperCorner>665301.838000 635472.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665301.838000 635472.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 015 710</ms:GML_ID>
        <ms:NAZWA>223 015 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223015710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665693.035000 656019.128000</gml:lowerCorner>
        		<gml:upperCorner>665693.035000 656019.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665693.035000 656019.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 041 180</ms:GML_ID>
        <ms:NAZWA>223 041 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223041180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665896.867000 635998.055000</gml:lowerCorner>
        		<gml:upperCorner>665896.867000 635998.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665896.867000 635998.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 016 512</ms:GML_ID>
        <ms:NAZWA>223 016 512</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223016512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665908.674000 632313.592000</gml:lowerCorner>
        		<gml:upperCorner>665908.674000 632313.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665908.674000 632313.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 012 390</ms:GML_ID>
        <ms:NAZWA>223 012 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223012390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665973.003943 636071.556892</gml:lowerCorner>
        		<gml:upperCorner>665973.003943 636071.556892</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665973.003943 636071.556892</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 016 618</ms:GML_ID>
        <ms:NAZWA>223 016 618</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223016618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666116.126000 636255.317000</gml:lowerCorner>
        		<gml:upperCorner>666116.126000 636255.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666116.126000 636255.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 016 849</ms:GML_ID>
        <ms:NAZWA>223 016 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223016849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666379.374521 631272.029987</gml:lowerCorner>
        		<gml:upperCorner>666379.374521 631272.029987</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666379.374521 631272.029987</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 011 230</ms:GML_ID>
        <ms:NAZWA>223 011 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223011230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667098.108000 646251.930000</gml:lowerCorner>
        		<gml:upperCorner>667098.108000 646251.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667098.108000 646251.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 028 179</ms:GML_ID>
        <ms:NAZWA>223 028 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223028179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667420.146000 646885.492000</gml:lowerCorner>
        		<gml:upperCorner>667420.146000 646885.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667420.146000 646885.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 028 891</ms:GML_ID>
        <ms:NAZWA>223 028 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223028891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667466.099959 647045.345473</gml:lowerCorner>
        		<gml:upperCorner>667466.099959 647045.345473</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667466.099959 647045.345473</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 029 058</ms:GML_ID>
        <ms:NAZWA>223 029 058</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223029058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667627.707000 647613.143000</gml:lowerCorner>
        		<gml:upperCorner>667627.707000 647613.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667627.707000 647613.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 029 649</ms:GML_ID>
        <ms:NAZWA>223 029 649</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223029649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668231.592000 648329.116000</gml:lowerCorner>
        		<gml:upperCorner>668231.592000 648329.116000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668231.592000 648329.116000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 030 596</ms:GML_ID>
        <ms:NAZWA>223 030 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223030596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634059.925000 641548.084000</gml:lowerCorner>
        		<gml:upperCorner>634059.925000 641548.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634059.925000 641548.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 054 290</ms:GML_ID>
        <ms:NAZWA>219 054 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219054290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634122.251000 640412.393000</gml:lowerCorner>
        		<gml:upperCorner>634122.251000 640412.393000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634122.251000 640412.393000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 053 153</ms:GML_ID>
        <ms:NAZWA>219 053 153</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219053153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634149.841401 642732.325866</gml:lowerCorner>
        		<gml:upperCorner>634149.841401 642732.325866</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634149.841401 642732.325866</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 055 489</ms:GML_ID>
        <ms:NAZWA>219 055 489</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219055489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634174.098000 639473.383000</gml:lowerCorner>
        		<gml:upperCorner>634174.098000 639473.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634174.098000 639473.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 052 210</ms:GML_ID>
        <ms:NAZWA>219 052 210</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219052210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634330.361990 633907.299399</gml:lowerCorner>
        		<gml:upperCorner>634330.361990 633907.299399</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634330.361990 633907.299399</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 046 624</ms:GML_ID>
        <ms:NAZWA>219 046 624</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219046624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634347.055000 643608.028000</gml:lowerCorner>
        		<gml:upperCorner>634347.055000 643608.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634347.055000 643608.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 056 385</ms:GML_ID>
        <ms:NAZWA>219 056 385</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219056385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634396.680000 635838.014000</gml:lowerCorner>
        		<gml:upperCorner>634396.680000 635838.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634396.680000 635838.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 048 563</ms:GML_ID>
        <ms:NAZWA>219 048 563</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219048563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634421.703000 633093.829000</gml:lowerCorner>
        		<gml:upperCorner>634421.703000 633093.829000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634421.703000 633093.829000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 045 800</ms:GML_ID>
        <ms:NAZWA>219 045 800</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219045800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634452.100000 644063.627000</gml:lowerCorner>
        		<gml:upperCorner>634452.100000 644063.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634452.100000 644063.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 056 854</ms:GML_ID>
        <ms:NAZWA>219 056 854</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219056854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634512.751304 632754.964795</gml:lowerCorner>
        		<gml:upperCorner>634512.751304 632754.964795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634512.751304 632754.964795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 045 449</ms:GML_ID>
        <ms:NAZWA>219 045 449</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219045449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634601.776000 631313.015000</gml:lowerCorner>
        		<gml:upperCorner>634601.776000 631313.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634601.776000 631313.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 091 396</ms:GML_ID>
        <ms:NAZWA>035 091 396</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035091396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634739.167000 645322.597000</gml:lowerCorner>
        		<gml:upperCorner>634739.167000 645322.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634739.167000 645322.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 058 145</ms:GML_ID>
        <ms:NAZWA>219 058 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219058145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634763.599234 631903.090990</gml:lowerCorner>
        		<gml:upperCorner>634763.599234 631903.090990</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634763.599234 631903.090990</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 044 564</ms:GML_ID>
        <ms:NAZWA>219 044 564</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219044564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634919.057000 631398.042000</gml:lowerCorner>
        		<gml:upperCorner>634919.057000 631398.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634919.057000 631398.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 044 033</ms:GML_ID>
        <ms:NAZWA>219 044 033</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219044033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635008.012829 631048.870126</gml:lowerCorner>
        		<gml:upperCorner>635008.012829 631048.870126</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635008.012829 631048.870126</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 043 650</ms:GML_ID>
        <ms:NAZWA>219 043 650</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219043650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635072.190000 630867.464000</gml:lowerCorner>
        		<gml:upperCorner>635072.190000 630867.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635072.190000 630867.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 043 481</ms:GML_ID>
        <ms:NAZWA>219 043 481</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219043481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635094.918000 646270.736000</gml:lowerCorner>
        		<gml:upperCorner>635094.918000 646270.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635094.918000 646270.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 059 161</ms:GML_ID>
        <ms:NAZWA>219 059 161</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219059161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635174.620000 646779.951000</gml:lowerCorner>
        		<gml:upperCorner>635174.620000 646779.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635174.620000 646779.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 059 677</ms:GML_ID>
        <ms:NAZWA>219 059 677</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219059677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612031.232337 626806.409179</gml:lowerCorner>
        		<gml:upperCorner>612031.232337 626806.409179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612031.232337 626806.409179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 065 413</ms:GML_ID>
        <ms:NAZWA>035 065 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035065413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613192.066423 627382.063944</gml:lowerCorner>
        		<gml:upperCorner>613192.066423 627382.063944</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613192.066423 627382.063944</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 066 710</ms:GML_ID>
        <ms:NAZWA>035 066 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035066710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605986.703000 627725.048000</gml:lowerCorner>
        		<gml:upperCorner>605986.703000 627725.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605986.703000 627725.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 059 017</ms:GML_ID>
        <ms:NAZWA>035 059 017</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035059017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605044.641000 627945.332000</gml:lowerCorner>
        		<gml:upperCorner>605044.641000 627945.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605044.641000 627945.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 058 043</ms:GML_ID>
        <ms:NAZWA>035 058 043</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035058043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615270.673000 628028.740000</gml:lowerCorner>
        		<gml:upperCorner>615270.673000 628028.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615270.673000 628028.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 039 695</ms:GML_ID>
        <ms:NAZWA>225 039 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225039695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614895.174713 628308.246157</gml:lowerCorner>
        		<gml:upperCorner>614895.174713 628308.246157</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614895.174713 628308.246157</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.733 000 225</ms:GML_ID>
        <ms:NAZWA>733 000 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>733000225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615539.571000 628981.486000</gml:lowerCorner>
        		<gml:upperCorner>615539.571000 628981.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615539.571000 628981.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 040 685</ms:GML_ID>
        <ms:NAZWA>225 040 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225040685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603871.064171 629006.532073</gml:lowerCorner>
        		<gml:upperCorner>603871.064171 629006.532073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603871.064171 629006.532073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 056 457</ms:GML_ID>
        <ms:NAZWA>035 056 457</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035056457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615593.753602 629239.759076</gml:lowerCorner>
        		<gml:upperCorner>615593.753602 629239.759076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615593.753602 629239.759076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 069 819</ms:GML_ID>
        <ms:NAZWA>035 069 819</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035069819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615863.847475 629583.380275</gml:lowerCorner>
        		<gml:upperCorner>615863.847475 629583.380275</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615863.847475 629583.380275</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 070 258</ms:GML_ID>
        <ms:NAZWA>035 070 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035070258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628531.784000 629758.638000</gml:lowerCorner>
        		<gml:upperCorner>628531.784000 629758.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628531.784000 629758.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 084 751</ms:GML_ID>
        <ms:NAZWA>035 084 751</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035084751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616476.713861 629788.247821</gml:lowerCorner>
        		<gml:upperCorner>616476.713861 629788.247821</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616476.713861 629788.247821</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 070 914</ms:GML_ID>
        <ms:NAZWA>035 070 914</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035070914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626769.559000 630049.973000</gml:lowerCorner>
        		<gml:upperCorner>626769.559000 630049.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626769.559000 630049.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 082 925</ms:GML_ID>
        <ms:NAZWA>035 082 925</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035082925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629237.195632 630057.698956</gml:lowerCorner>
        		<gml:upperCorner>629237.195632 630057.698956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629237.195632 630057.698956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 085 526</ms:GML_ID>
        <ms:NAZWA>035 085 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035085526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630718.426540 630656.357504</gml:lowerCorner>
        		<gml:upperCorner>630718.426540 630656.357504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630718.426540 630656.357504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 087 140</ms:GML_ID>
        <ms:NAZWA>035 087 140</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035087140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626158.063000 630825.281000</gml:lowerCorner>
        		<gml:upperCorner>626158.063000 630825.281000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626158.063000 630825.281000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 081 937</ms:GML_ID>
        <ms:NAZWA>035 081 937</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035081937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619759.087832 631429.581059</gml:lowerCorner>
        		<gml:upperCorner>619759.087832 631429.581059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619759.087832 631429.581059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 074 702</ms:GML_ID>
        <ms:NAZWA>035 074 702</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035074702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625402.477871 631447.932059</gml:lowerCorner>
        		<gml:upperCorner>625402.477871 631447.932059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625402.477871 631447.932059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 080 952</ms:GML_ID>
        <ms:NAZWA>035 080 952</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035080952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620186.267905 631663.163662</gml:lowerCorner>
        		<gml:upperCorner>620186.267905 631663.163662</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620186.267905 631663.163662</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 075 179</ms:GML_ID>
        <ms:NAZWA>035 075 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035075179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620858.644232 632053.415380</gml:lowerCorner>
        		<gml:upperCorner>620858.644232 632053.415380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620858.644232 632053.415380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 075 967</ms:GML_ID>
        <ms:NAZWA>035 075 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035075967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621834.614000 632491.249000</gml:lowerCorner>
        		<gml:upperCorner>621834.614000 632491.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621834.614000 632491.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 077 053</ms:GML_ID>
        <ms:NAZWA>035 077 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035077053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723210.335000 611264.735000</gml:lowerCorner>
        		<gml:upperCorner>723210.335000 611264.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723210.335000 611264.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 239 743</ms:GML_ID>
        <ms:NAZWA>038 239 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038239743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720807.622000 613242.066000</gml:lowerCorner>
        		<gml:upperCorner>720807.622000 613242.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720807.622000 613242.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 236 630</ms:GML_ID>
        <ms:NAZWA>038 236 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038236630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720364.146000 613626.358000</gml:lowerCorner>
        		<gml:upperCorner>720364.146000 613626.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720364.146000 613626.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 236 044</ms:GML_ID>
        <ms:NAZWA>038 236 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038236044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719367.680000 614493.347000</gml:lowerCorner>
        		<gml:upperCorner>719367.680000 614493.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719367.680000 614493.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 234 719</ms:GML_ID>
        <ms:NAZWA>038 234 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038234719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715570.968000 616307.727000</gml:lowerCorner>
        		<gml:upperCorner>715570.968000 616307.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715570.968000 616307.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 230 450</ms:GML_ID>
        <ms:NAZWA>038 230 450</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038230450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713962.274000 617018.389000</gml:lowerCorner>
        		<gml:upperCorner>713962.274000 617018.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713962.274000 617018.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 228 690</ms:GML_ID>
        <ms:NAZWA>038 228 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038228690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711958.301181 617941.336176</gml:lowerCorner>
        		<gml:upperCorner>711958.301181 617941.336176</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711958.301181 617941.336176</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 226 479</ms:GML_ID>
        <ms:NAZWA>038 226 479</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038226479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710679.665000 619261.741000</gml:lowerCorner>
        		<gml:upperCorner>710679.665000 619261.741000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710679.665000 619261.741000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 224 578</ms:GML_ID>
        <ms:NAZWA>038 224 578</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038224578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710818.955000 624775.543000</gml:lowerCorner>
        		<gml:upperCorner>710818.955000 624775.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710818.955000 624775.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 219 041</ms:GML_ID>
        <ms:NAZWA>038 219 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038219041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710450.151000 626520.714000</gml:lowerCorner>
        		<gml:upperCorner>710450.151000 626520.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710450.151000 626520.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 217 250</ms:GML_ID>
        <ms:NAZWA>038 217 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038217250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710132.037000 627747.244000</gml:lowerCorner>
        		<gml:upperCorner>710132.037000 627747.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710132.037000 627747.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 215 983</ms:GML_ID>
        <ms:NAZWA>038 215 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038215983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709683.595288 628808.924568</gml:lowerCorner>
        		<gml:upperCorner>709683.595288 628808.924568</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709683.595288 628808.924568</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 214 825</ms:GML_ID>
        <ms:NAZWA>038 214 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038214825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709098.103000 629959.531000</gml:lowerCorner>
        		<gml:upperCorner>709098.103000 629959.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709098.103000 629959.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 213 533</ms:GML_ID>
        <ms:NAZWA>038 213 533</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038213533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708928.970000 630293.741000</gml:lowerCorner>
        		<gml:upperCorner>708928.970000 630293.741000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708928.970000 630293.741000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 213 158</ms:GML_ID>
        <ms:NAZWA>038 213 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038213158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708794.058000 630559.479000</gml:lowerCorner>
        		<gml:upperCorner>708794.058000 630559.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708794.058000 630559.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 212 860</ms:GML_ID>
        <ms:NAZWA>038 212 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038212860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708571.616000 630996.812000</gml:lowerCorner>
        		<gml:upperCorner>708571.616000 630996.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708571.616000 630996.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 212 369</ms:GML_ID>
        <ms:NAZWA>038 212 369</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038212369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707896.258000 632323.881000</gml:lowerCorner>
        		<gml:upperCorner>707896.258000 632323.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707896.258000 632323.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 210 879</ms:GML_ID>
        <ms:NAZWA>038 210 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038210879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707515.919000 633070.263000</gml:lowerCorner>
        		<gml:upperCorner>707515.919000 633070.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707515.919000 633070.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 210 041</ms:GML_ID>
        <ms:NAZWA>038 210 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038210041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706931.594000 633914.420000</gml:lowerCorner>
        		<gml:upperCorner>706931.594000 633914.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706931.594000 633914.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 209 000</ms:GML_ID>
        <ms:NAZWA>038 209 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038209000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706084.570000 634592.264000</gml:lowerCorner>
        		<gml:upperCorner>706084.570000 634592.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706084.570000 634592.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 207 914</ms:GML_ID>
        <ms:NAZWA>038 207 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038207914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704972.631000 635473.279000</gml:lowerCorner>
        		<gml:upperCorner>704972.631000 635473.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704972.631000 635473.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.038 206 495</ms:GML_ID>
        <ms:NAZWA>038 206 495</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>038206495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648481.240000 611019.840000</gml:lowerCorner>
        		<gml:upperCorner>648481.240000 611019.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648481.240000 611019.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 017 704</ms:GML_ID>
        <ms:NAZWA>219 017 704</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219017704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648095.766000 611448.463000</gml:lowerCorner>
        		<gml:upperCorner>648095.766000 611448.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648095.766000 611448.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 018 281</ms:GML_ID>
        <ms:NAZWA>219 018 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219018281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665664.244034 611580.729381</gml:lowerCorner>
        		<gml:upperCorner>665664.244034 611580.729381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665664.244034 611580.729381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 313 635</ms:GML_ID>
        <ms:NAZWA>353 313 635</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353313635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644334.705000 614667.742000</gml:lowerCorner>
        		<gml:upperCorner>644334.705000 614667.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644334.705000 614667.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 023 651</ms:GML_ID>
        <ms:NAZWA>219 023 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219023651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642964.707000 615612.444000</gml:lowerCorner>
        		<gml:upperCorner>642964.707000 615612.444000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642964.707000 615612.444000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 025 323</ms:GML_ID>
        <ms:NAZWA>219 025 323</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219025323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642485.232000 616146.554000</gml:lowerCorner>
        		<gml:upperCorner>642485.232000 616146.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642485.232000 616146.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 026 056</ms:GML_ID>
        <ms:NAZWA>219 026 056</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219026056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642082.307000 616906.756000</gml:lowerCorner>
        		<gml:upperCorner>642082.307000 616906.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642082.307000 616906.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 026 935</ms:GML_ID>
        <ms:NAZWA>219 026 935</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219026935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640623.441000 618097.728000</gml:lowerCorner>
        		<gml:upperCorner>640623.441000 618097.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640623.441000 618097.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 028 827</ms:GML_ID>
        <ms:NAZWA>219 028 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219028827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640099.762000 620362.878000</gml:lowerCorner>
        		<gml:upperCorner>640099.762000 620362.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640099.762000 620362.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 031 234</ms:GML_ID>
        <ms:NAZWA>219 031 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219031234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639961.038000 622343.970000</gml:lowerCorner>
        		<gml:upperCorner>639961.038000 622343.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639961.038000 622343.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 033 252</ms:GML_ID>
        <ms:NAZWA>219 033 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219033252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639843.242000 622767.233000</gml:lowerCorner>
        		<gml:upperCorner>639843.242000 622767.233000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639843.242000 622767.233000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 033 692</ms:GML_ID>
        <ms:NAZWA>219 033 692</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219033692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639610.761000 623101.839000</gml:lowerCorner>
        		<gml:upperCorner>639610.761000 623101.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639610.761000 623101.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 034 104</ms:GML_ID>
        <ms:NAZWA>219 034 104</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219034104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638709.581000 624363.728000</gml:lowerCorner>
        		<gml:upperCorner>638709.581000 624363.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638709.581000 624363.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 035 733</ms:GML_ID>
        <ms:NAZWA>219 035 733</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219035733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668747.378318 628830.018111</gml:lowerCorner>
        		<gml:upperCorner>668747.378318 628830.018111</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668747.378318 628830.018111</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 007 814</ms:GML_ID>
        <ms:NAZWA>223 007 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223007814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668553.099533 629082.796474</gml:lowerCorner>
        		<gml:upperCorner>668553.099533 629082.796474</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668553.099533 629082.796474</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 008 132</ms:GML_ID>
        <ms:NAZWA>223 008 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223008132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668265.588767 629313.143193</gml:lowerCorner>
        		<gml:upperCorner>668265.588767 629313.143193</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668265.588767 629313.143193</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 008 503</ms:GML_ID>
        <ms:NAZWA>223 008 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223008503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635415.475000 629654.545000</gml:lowerCorner>
        		<gml:upperCorner>635415.475000 629654.545000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635415.475000 629654.545000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 042 214</ms:GML_ID>
        <ms:NAZWA>219 042 214</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219042214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667693.725840 629783.336060</gml:lowerCorner>
        		<gml:upperCorner>667693.725840 629783.336060</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667693.725840 629783.336060</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 009 247</ms:GML_ID>
        <ms:NAZWA>223 009 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223009247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635256.537000 630206.099000</gml:lowerCorner>
        		<gml:upperCorner>635256.537000 630206.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635256.537000 630206.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 042 792</ms:GML_ID>
        <ms:NAZWA>219 042 792</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219042792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632643.329246 630377.959271</gml:lowerCorner>
        		<gml:upperCorner>632643.329246 630377.959271</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632643.329246 630377.959271</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 089 120</ms:GML_ID>
        <ms:NAZWA>035 089 120</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035089120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633804.401000 630755.821000</gml:lowerCorner>
        		<gml:upperCorner>633804.401000 630755.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633804.401000 630755.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 090 422</ms:GML_ID>
        <ms:NAZWA>035 090 422</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035090422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613062.092055 606749.247160</gml:lowerCorner>
        		<gml:upperCorner>613062.092055 606749.247160</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613062.092055 606749.247160</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 017 470</ms:GML_ID>
        <ms:NAZWA>225 017 470</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225017470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611909.954112 608707.598261</gml:lowerCorner>
        		<gml:upperCorner>611909.954112 608707.598261</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611909.954112 608707.598261</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 019 722</ms:GML_ID>
        <ms:NAZWA>225 019 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225019722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611802.683183 609190.661475</gml:lowerCorner>
        		<gml:upperCorner>611802.683183 609190.661475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611802.683183 609190.661475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 020 257</ms:GML_ID>
        <ms:NAZWA>225 020 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225020257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611666.046042 609809.024880</gml:lowerCorner>
        		<gml:upperCorner>611666.046042 609809.024880</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611666.046042 609809.024880</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 020 891</ms:GML_ID>
        <ms:NAZWA>225 020 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225020891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611433.183000 611352.269000</gml:lowerCorner>
        		<gml:upperCorner>611433.183000 611352.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611433.183000 611352.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 022 468</ms:GML_ID>
        <ms:NAZWA>225 022 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225022468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611686.537000 612316.769000</gml:lowerCorner>
        		<gml:upperCorner>611686.537000 612316.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611686.537000 612316.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 023 466</ms:GML_ID>
        <ms:NAZWA>225 023 466</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225023466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611885.409000 613069.907000</gml:lowerCorner>
        		<gml:upperCorner>611885.409000 613069.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611885.409000 613069.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 024 242</ms:GML_ID>
        <ms:NAZWA>225 024 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225024242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612280.212000 614583.505000</gml:lowerCorner>
        		<gml:upperCorner>612280.212000 614583.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612280.212000 614583.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 025 810</ms:GML_ID>
        <ms:NAZWA>225 025 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225025810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612382.277000 615012.766000</gml:lowerCorner>
        		<gml:upperCorner>612382.277000 615012.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612382.277000 615012.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 026 250</ms:GML_ID>
        <ms:NAZWA>225 026 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225026250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612789.133973 617172.064075</gml:lowerCorner>
        		<gml:upperCorner>612789.133973 617172.064075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612789.133973 617172.064075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 028 454</ms:GML_ID>
        <ms:NAZWA>225 028 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225028454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613256.878000 619013.809000</gml:lowerCorner>
        		<gml:upperCorner>613256.878000 619013.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613256.878000 619013.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 030 415</ms:GML_ID>
        <ms:NAZWA>225 030 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225030415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613302.772000 619484.833000</gml:lowerCorner>
        		<gml:upperCorner>613302.772000 619484.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613302.772000 619484.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 030 889</ms:GML_ID>
        <ms:NAZWA>225 030 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225030889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613455.552000 620636.162000</gml:lowerCorner>
        		<gml:upperCorner>613455.552000 620636.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613455.552000 620636.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 032 051</ms:GML_ID>
        <ms:NAZWA>225 032 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225032051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613555.920000 621296.257000</gml:lowerCorner>
        		<gml:upperCorner>613555.920000 621296.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613555.920000 621296.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 032 719</ms:GML_ID>
        <ms:NAZWA>225 032 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225032719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613601.443000 621594.828000</gml:lowerCorner>
        		<gml:upperCorner>613601.443000 621594.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613601.443000 621594.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 033 021</ms:GML_ID>
        <ms:NAZWA>225 033 021</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225033021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613693.205000 622201.565000</gml:lowerCorner>
        		<gml:upperCorner>613693.205000 622201.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613693.205000 622201.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 033 635</ms:GML_ID>
        <ms:NAZWA>225 033 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225033635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613797.627000 622885.764000</gml:lowerCorner>
        		<gml:upperCorner>613797.627000 622885.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613797.627000 622885.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 034 328</ms:GML_ID>
        <ms:NAZWA>225 034 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225034328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613930.195000 623736.890000</gml:lowerCorner>
        		<gml:upperCorner>613930.195000 623736.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613930.195000 623736.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 035 191</ms:GML_ID>
        <ms:NAZWA>225 035 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225035191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614482.878000 625247.283000</gml:lowerCorner>
        		<gml:upperCorner>614482.878000 625247.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614482.878000 625247.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 036 803</ms:GML_ID>
        <ms:NAZWA>225 036 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225036803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614721.956000 626090.686000</gml:lowerCorner>
        		<gml:upperCorner>614721.956000 626090.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614721.956000 626090.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 037 680</ms:GML_ID>
        <ms:NAZWA>225 037 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225037680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611045.254997 626567.846203</gml:lowerCorner>
        		<gml:upperCorner>611045.254997 626567.846203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611045.254997 626567.846203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 064 379</ms:GML_ID>
        <ms:NAZWA>035 064 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>035064379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643333.589323 592798.344567</gml:lowerCorner>
        		<gml:upperCorner>643333.589323 592798.344567</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643333.589323 592798.344567</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 063 509</ms:GML_ID>
        <ms:NAZWA>216 063 509</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216063509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643913.273000 593061.371000</gml:lowerCorner>
        		<gml:upperCorner>643913.273000 593061.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643913.273000 593061.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 064 146</ms:GML_ID>
        <ms:NAZWA>216 064 146</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216064146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644275.660000 593715.169000</gml:lowerCorner>
        		<gml:upperCorner>644275.660000 593715.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644275.660000 593715.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 064 956</ms:GML_ID>
        <ms:NAZWA>216 064 956</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216064956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660095.041000 594433.780000</gml:lowerCorner>
        		<gml:upperCorner>660095.041000 594433.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660095.041000 594433.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 005 514</ms:GML_ID>
        <ms:NAZWA>220 005 514</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220005514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644963.841063 594891.870562</gml:lowerCorner>
        		<gml:upperCorner>644963.841063 594891.870562</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644963.841063 594891.870562</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 066 552</ms:GML_ID>
        <ms:NAZWA>216 066 552</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216066552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646699.617881 594891.950858</gml:lowerCorner>
        		<gml:upperCorner>646699.617881 594891.950858</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646699.617881 594891.950858</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 068 327</ms:GML_ID>
        <ms:NAZWA>216 068 327</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216068327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653853.095000 595174.189000</gml:lowerCorner>
        		<gml:upperCorner>653853.095000 595174.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653853.095000 595174.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 075 720</ms:GML_ID>
        <ms:NAZWA>216 075 720</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216075720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659140.193041 595239.345403</gml:lowerCorner>
        		<gml:upperCorner>659140.193041 595239.345403</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659140.193041 595239.345403</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 004 237</ms:GML_ID>
        <ms:NAZWA>220 004 237</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220004237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658725.030435 595444.954524</gml:lowerCorner>
        		<gml:upperCorner>658725.030435 595444.954524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658725.030435 595444.954524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 003 767</ms:GML_ID>
        <ms:NAZWA>220 003 767</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220003767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659147.027074 598943.633475</gml:lowerCorner>
        		<gml:upperCorner>659147.027074 598943.633475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659147.027074 598943.633475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 299 200</ms:GML_ID>
        <ms:NAZWA>353 299 200</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353299200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657409.871000 601203.403000</gml:lowerCorner>
        		<gml:upperCorner>657409.871000 601203.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657409.871000 601203.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 003 648</ms:GML_ID>
        <ms:NAZWA>219 003 648</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219003648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656098.020000 602218.169000</gml:lowerCorner>
        		<gml:upperCorner>656098.020000 602218.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656098.020000 602218.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 005 308</ms:GML_ID>
        <ms:NAZWA>219 005 308</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219005308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655162.845000 602703.100000</gml:lowerCorner>
        		<gml:upperCorner>655162.845000 602703.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655162.845000 602703.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 006 383</ms:GML_ID>
        <ms:NAZWA>219 006 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219006383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653619.642000 603371.127000</gml:lowerCorner>
        		<gml:upperCorner>653619.642000 603371.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653619.642000 603371.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 008 104</ms:GML_ID>
        <ms:NAZWA>219 008 104</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219008104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652746.872000 604888.738000</gml:lowerCorner>
        		<gml:upperCorner>652746.872000 604888.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652746.872000 604888.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 009 979</ms:GML_ID>
        <ms:NAZWA>219 009 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219009979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662676.030639 606011.373799</gml:lowerCorner>
        		<gml:upperCorner>662676.030639 606011.373799</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662676.030639 606011.373799</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 307 214</ms:GML_ID>
        <ms:NAZWA>353 307 214</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353307214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663187.621112 606582.014289</gml:lowerCorner>
        		<gml:upperCorner>663187.621112 606582.014289</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663187.621112 606582.014289</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 307 980</ms:GML_ID>
        <ms:NAZWA>353 307 980</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353307980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649996.296000 609096.344000</gml:lowerCorner>
        		<gml:upperCorner>649996.296000 609096.344000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649996.296000 609096.344000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 015 228</ms:GML_ID>
        <ms:NAZWA>219 015 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219015228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664938.114000 609327.459000</gml:lowerCorner>
        		<gml:upperCorner>664938.114000 609327.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664938.114000 609327.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 311 255</ms:GML_ID>
        <ms:NAZWA>353 311 255</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353311255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648976.928397 610468.001435</gml:lowerCorner>
        		<gml:upperCorner>648976.928397 610468.001435</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648976.928397 610468.001435</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.219 016 961</ms:GML_ID>
        <ms:NAZWA>219 016 961</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>219016961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679066.076000 591616.134000</gml:lowerCorner>
        		<gml:upperCorner>679066.076000 591616.134000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679066.076000 591616.134000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 020 973</ms:GML_ID>
        <ms:NAZWA>221 020 973</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221020973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672754.929896 591719.592780</gml:lowerCorner>
        		<gml:upperCorner>672754.929896 591719.592780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672754.929896 591719.592780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 014 474</ms:GML_ID>
        <ms:NAZWA>221 014 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221014474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678267.467000 591818.698000</gml:lowerCorner>
        		<gml:upperCorner>678267.467000 591818.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678267.467000 591818.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 020 148</ms:GML_ID>
        <ms:NAZWA>221 020 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221020148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671464.328000 617908.808000</gml:lowerCorner>
        		<gml:upperCorner>671464.328000 617908.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671464.328000 617908.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 322 417</ms:GML_ID>
        <ms:NAZWA>353 322 417</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353322417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672531.218000 621520.555000</gml:lowerCorner>
        		<gml:upperCorner>672531.218000 621520.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672531.218000 621520.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 326 183</ms:GML_ID>
        <ms:NAZWA>353 326 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353326183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673117.633146 623475.068570</gml:lowerCorner>
        		<gml:upperCorner>673117.633146 623475.068570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673117.633146 623475.068570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 328 237</ms:GML_ID>
        <ms:NAZWA>353 328 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353328237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674038.402305 624547.769979</gml:lowerCorner>
        		<gml:upperCorner>674038.402305 624547.769979</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674038.402305 624547.769979</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 329 654</ms:GML_ID>
        <ms:NAZWA>353 329 654</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353329654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673288.821000 625679.779000</gml:lowerCorner>
        		<gml:upperCorner>673288.821000 625679.779000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673288.821000 625679.779000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 001 963</ms:GML_ID>
        <ms:NAZWA>223 001 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223001963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675041.041000 625938.788000</gml:lowerCorner>
        		<gml:upperCorner>675041.041000 625938.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675041.041000 625938.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 331 381</ms:GML_ID>
        <ms:NAZWA>353 331 381</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353331381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671774.737000 626380.645000</gml:lowerCorner>
        		<gml:upperCorner>671774.737000 626380.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671774.737000 626380.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 003 642</ms:GML_ID>
        <ms:NAZWA>223 003 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223003642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676063.334669 627599.364705</gml:lowerCorner>
        		<gml:upperCorner>676063.334669 627599.364705</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676063.334669 627599.364705</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 333 340</ms:GML_ID>
        <ms:NAZWA>353 333 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353333340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669207.310755 628042.884539</gml:lowerCorner>
        		<gml:upperCorner>669207.310755 628042.884539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669207.310755 628042.884539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 006 901</ms:GML_ID>
        <ms:NAZWA>223 006 901</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223006901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669075.329765 628258.597997</gml:lowerCorner>
        		<gml:upperCorner>669075.329765 628258.597997</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669075.329765 628258.597997</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.223 007 152</ms:GML_ID>
        <ms:NAZWA>223 007 152</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>223007152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686523.488632 629471.665076</gml:lowerCorner>
        		<gml:upperCorner>686523.488632 629471.665076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686523.488632 629471.665076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 345 234</ms:GML_ID>
        <ms:NAZWA>353 345 234</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353345234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685301.978000 629874.968000</gml:lowerCorner>
        		<gml:upperCorner>685301.978000 629874.968000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685301.978000 629874.968000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 343 942</ms:GML_ID>
        <ms:NAZWA>353 343 942</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353343942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678103.962000 630034.154000</gml:lowerCorner>
        		<gml:upperCorner>678103.962000 630034.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678103.962000 630034.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 336 557</ms:GML_ID>
        <ms:NAZWA>353 336 557</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353336557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683772.619000 630115.458000</gml:lowerCorner>
        		<gml:upperCorner>683772.619000 630115.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683772.619000 630115.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 342 387</ms:GML_ID>
        <ms:NAZWA>353 342 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353342387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680374.347000 630240.209000</gml:lowerCorner>
        		<gml:upperCorner>680374.347000 630240.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680374.347000 630240.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 338 850</ms:GML_ID>
        <ms:NAZWA>353 338 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353338850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609732.557000 590961.383000</gml:lowerCorner>
        		<gml:upperCorner>609732.557000 590961.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609732.557000 590961.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 020 307</ms:GML_ID>
        <ms:NAZWA>216 020 307</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216020307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619609.003000 592138.125000</gml:lowerCorner>
        		<gml:upperCorner>619609.003000 592138.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619609.003000 592138.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 033 239</ms:GML_ID>
        <ms:NAZWA>216 033 239</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216033239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618556.279956 592720.377843</gml:lowerCorner>
        		<gml:upperCorner>618556.279956 592720.377843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618556.279956 592720.377843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 032 036</ms:GML_ID>
        <ms:NAZWA>216 032 036</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216032036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618058.288000 592994.810000</gml:lowerCorner>
        		<gml:upperCorner>618058.288000 592994.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618058.288000 592994.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 031 466</ms:GML_ID>
        <ms:NAZWA>216 031 466</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216031466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617646.547000 593222.396000</gml:lowerCorner>
        		<gml:upperCorner>617646.547000 593222.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617646.547000 593222.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 030 996</ms:GML_ID>
        <ms:NAZWA>216 030 996</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216030996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614648.820428 593841.039258</gml:lowerCorner>
        		<gml:upperCorner>614648.820428 593841.039258</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614648.820428 593841.039258</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 027 891</ms:GML_ID>
        <ms:NAZWA>216 027 891</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216027891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613374.092522 593887.227533</gml:lowerCorner>
        		<gml:upperCorner>613374.092522 593887.227533</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613374.092522 593887.227533</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 026 614</ms:GML_ID>
        <ms:NAZWA>216 026 614</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216026614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610264.009605 593940.799646</gml:lowerCorner>
        		<gml:upperCorner>610264.009605 593940.799646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610264.009605 593940.799646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 023 455</ms:GML_ID>
        <ms:NAZWA>216 023 455</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216023455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611802.748821 594053.538746</gml:lowerCorner>
        		<gml:upperCorner>611802.748821 594053.538746</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611802.748821 594053.538746</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 025 014</ms:GML_ID>
        <ms:NAZWA>216 025 014</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216025014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611579.758987 594058.285502</gml:lowerCorner>
        		<gml:upperCorner>611579.758987 594058.285502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611579.758987 594058.285502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 024 813</ms:GML_ID>
        <ms:NAZWA>216 024 813</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216024813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614552.068750 594082.176913</gml:lowerCorner>
        		<gml:upperCorner>614552.068750 594082.176913</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614552.068750 594082.176913</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 003 475</ms:GML_ID>
        <ms:NAZWA>225 003 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225003475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614792.041000 594474.912000</gml:lowerCorner>
        		<gml:upperCorner>614792.041000 594474.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614792.041000 594474.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 003 938</ms:GML_ID>
        <ms:NAZWA>225 003 938</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225003938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615201.321000 595182.184000</gml:lowerCorner>
        		<gml:upperCorner>615201.321000 595182.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615201.321000 595182.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 004 753</ms:GML_ID>
        <ms:NAZWA>225 004 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225004753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616044.012000 596684.790000</gml:lowerCorner>
        		<gml:upperCorner>616044.012000 596684.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616044.012000 596684.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 006 479</ms:GML_ID>
        <ms:NAZWA>225 006 479</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225006479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616168.491000 597955.159000</gml:lowerCorner>
        		<gml:upperCorner>616168.491000 597955.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616168.491000 597955.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 007 764</ms:GML_ID>
        <ms:NAZWA>225 007 764</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225007764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615973.017000 598621.112000</gml:lowerCorner>
        		<gml:upperCorner>615973.017000 598621.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615973.017000 598621.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 008 465</ms:GML_ID>
        <ms:NAZWA>225 008 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225008465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615332.596174 601037.364015</gml:lowerCorner>
        		<gml:upperCorner>615332.596174 601037.364015</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615332.596174 601037.364015</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 011 002</ms:GML_ID>
        <ms:NAZWA>225 011 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225011002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614610.862000 603516.648000</gml:lowerCorner>
        		<gml:upperCorner>614610.862000 603516.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614610.862000 603516.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 013 704</ms:GML_ID>
        <ms:NAZWA>225 013 704</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225013704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614407.292000 603892.454000</gml:lowerCorner>
        		<gml:upperCorner>614407.292000 603892.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614407.292000 603892.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 014 132</ms:GML_ID>
        <ms:NAZWA>225 014 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225014132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614055.965000 605191.738000</gml:lowerCorner>
        		<gml:upperCorner>614055.965000 605191.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614055.965000 605191.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 015 499</ms:GML_ID>
        <ms:NAZWA>225 015 499</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225015499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613767.517697 606090.934736</gml:lowerCorner>
        		<gml:upperCorner>613767.517697 606090.934736</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613767.517697 606090.934736</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 016 481</ms:GML_ID>
        <ms:NAZWA>225 016 481</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225016481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613527.527112 606212.192801</gml:lowerCorner>
        		<gml:upperCorner>613527.527112 606212.192801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613527.527112 606212.192801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.225 016 750</ms:GML_ID>
        <ms:NAZWA>225 016 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>225016750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598762.266000 571941.652000</gml:lowerCorner>
        		<gml:upperCorner>598762.266000 571941.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598762.266000 571941.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 006 767</ms:GML_ID>
        <ms:NAZWA>208 006 767</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208006767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547435.743000 572540.100000</gml:lowerCorner>
        		<gml:upperCorner>547435.743000 572540.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547435.743000 572540.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 057 898</ms:GML_ID>
        <ms:NAZWA>027 057 898</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027057898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598753.101000 573607.911000</gml:lowerCorner>
        		<gml:upperCorner>598753.101000 573607.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598753.101000 573607.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 005 075</ms:GML_ID>
        <ms:NAZWA>208 005 075</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208005075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598836.215000 574329.339000</gml:lowerCorner>
        		<gml:upperCorner>598836.215000 574329.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598836.215000 574329.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 004 349</ms:GML_ID>
        <ms:NAZWA>208 004 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208004349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603202.946733 574363.654693</gml:lowerCorner>
        		<gml:upperCorner>603202.946733 574363.654693</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603202.946733 574363.654693</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 155 148</ms:GML_ID>
        <ms:NAZWA>009 155 148</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009155148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546390.420000 574640.392000</gml:lowerCorner>
        		<gml:upperCorner>546390.420000 574640.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546390.420000 574640.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 055 546</ms:GML_ID>
        <ms:NAZWA>027 055 546</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027055546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545455.302000 575495.700000</gml:lowerCorner>
        		<gml:upperCorner>545455.302000 575495.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545455.302000 575495.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 054 278</ms:GML_ID>
        <ms:NAZWA>027 054 278</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027054278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598902.966000 575719.473000</gml:lowerCorner>
        		<gml:upperCorner>598902.966000 575719.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598902.966000 575719.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 002 951</ms:GML_ID>
        <ms:NAZWA>208 002 951</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208002951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544813.211000 576076.652000</gml:lowerCorner>
        		<gml:upperCorner>544813.211000 576076.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544813.211000 576076.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 053 412</ms:GML_ID>
        <ms:NAZWA>027 053 412</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027053412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600920.887000 580129.254000</gml:lowerCorner>
        		<gml:upperCorner>600920.887000 580129.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600920.887000 580129.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 005 208</ms:GML_ID>
        <ms:NAZWA>216 005 208</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216005208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600976.187000 580887.845000</gml:lowerCorner>
        		<gml:upperCorner>600976.187000 580887.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600976.187000 580887.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 005 980</ms:GML_ID>
        <ms:NAZWA>216 005 980</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216005980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601932.909000 582593.601000</gml:lowerCorner>
        		<gml:upperCorner>601932.909000 582593.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601932.909000 582593.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 008 078</ms:GML_ID>
        <ms:NAZWA>216 008 078</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216008078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602567.111000 585099.597000</gml:lowerCorner>
        		<gml:upperCorner>602567.111000 585099.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602567.111000 585099.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 010 690</ms:GML_ID>
        <ms:NAZWA>216 010 690</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216010690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558596.081151 607081.775886</gml:lowerCorner>
        		<gml:upperCorner>558596.081151 607081.775886</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558596.081151 607081.775886</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 097 940</ms:GML_ID>
        <ms:NAZWA>009 097 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009097940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602508.829000 630313.224000</gml:lowerCorner>
        		<gml:upperCorner>602508.829000 630313.224000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602508.829000 630313.224000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 054 569</ms:GML_ID>
        <ms:NAZWA>035 054 569</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035054569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601397.813000 631830.142000</gml:lowerCorner>
        		<gml:upperCorner>601397.813000 631830.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601397.813000 631830.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 052 654</ms:GML_ID>
        <ms:NAZWA>035 052 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035052654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600247.653000 633246.622000</gml:lowerCorner>
        		<gml:upperCorner>600247.653000 633246.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600247.653000 633246.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 050 792</ms:GML_ID>
        <ms:NAZWA>035 050 792</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035050792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599805.716362 633625.408850</gml:lowerCorner>
        		<gml:upperCorner>599805.716362 633625.408850</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599805.716362 633625.408850</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 050 212</ms:GML_ID>
        <ms:NAZWA>035 050 212</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035050212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599210.328239 634135.397658</gml:lowerCorner>
        		<gml:upperCorner>599210.328239 634135.397658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599210.328239 634135.397658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 049 423</ms:GML_ID>
        <ms:NAZWA>035 049 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035049423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598293.421965 634882.005437</gml:lowerCorner>
        		<gml:upperCorner>598293.421965 634882.005437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598293.421965 634882.005437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 048 236</ms:GML_ID>
        <ms:NAZWA>035 048 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035048236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596704.908813 637063.440647</gml:lowerCorner>
        		<gml:upperCorner>596704.908813 637063.440647</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596704.908813 637063.440647</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 045 512</ms:GML_ID>
        <ms:NAZWA>035 045 512</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035045512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595754.727613 638057.611577</gml:lowerCorner>
        		<gml:upperCorner>595754.727613 638057.611577</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595754.727613 638057.611577</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 044 133</ms:GML_ID>
        <ms:NAZWA>035 044 133</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035044133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594659.398156 639203.403276</gml:lowerCorner>
        		<gml:upperCorner>594659.398156 639203.403276</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594659.398156 639203.403276</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 042 551</ms:GML_ID>
        <ms:NAZWA>035 042 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035042551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591793.384160 643361.358236</gml:lowerCorner>
        		<gml:upperCorner>591793.384160 643361.358236</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591793.384160 643361.358236</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 037 385</ms:GML_ID>
        <ms:NAZWA>035 037 385</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035037385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590837.756188 644632.695065</gml:lowerCorner>
        		<gml:upperCorner>590837.756188 644632.695065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590837.756188 644632.695065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 035 783</ms:GML_ID>
        <ms:NAZWA>035 035 783</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035035783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589310.608000 647405.921000</gml:lowerCorner>
        		<gml:upperCorner>589310.608000 647405.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589310.608000 647405.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 032 528</ms:GML_ID>
        <ms:NAZWA>035 032 528</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035032528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588517.740162 648818.381713</gml:lowerCorner>
        		<gml:upperCorner>588517.740162 648818.381713</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588517.740162 648818.381713</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 030 878</ms:GML_ID>
        <ms:NAZWA>035 030 878</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035030878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588092.304000 649234.573000</gml:lowerCorner>
        		<gml:upperCorner>588092.304000 649234.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588092.304000 649234.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 030 280</ms:GML_ID>
        <ms:NAZWA>035 030 280</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035030280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587597.573229 650327.206978</gml:lowerCorner>
        		<gml:upperCorner>587597.573229 650327.206978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587597.573229 650327.206978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 029 082</ms:GML_ID>
        <ms:NAZWA>035 029 082</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035029082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586805.275545 651289.468210</gml:lowerCorner>
        		<gml:upperCorner>586805.275545 651289.468210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586805.275545 651289.468210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 027 827</ms:GML_ID>
        <ms:NAZWA>035 027 827</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035027827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582536.786863 655652.255237</gml:lowerCorner>
        		<gml:upperCorner>582536.786863 655652.255237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582536.786863 655652.255237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 021 056</ms:GML_ID>
        <ms:NAZWA>035 021 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035021056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582458.925498 657610.685684</gml:lowerCorner>
        		<gml:upperCorner>582458.925498 657610.685684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582458.925498 657610.685684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 019 089</ms:GML_ID>
        <ms:NAZWA>035 019 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035019089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582694.996764 658444.811812</gml:lowerCorner>
        		<gml:upperCorner>582694.996764 658444.811812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582694.996764 658444.811812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 018 206</ms:GML_ID>
        <ms:NAZWA>035 018 206</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035018206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668595.640955 566699.075472</gml:lowerCorner>
        		<gml:upperCorner>668595.640955 566699.075472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668595.640955 566699.075472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 037 426</ms:GML_ID>
        <ms:NAZWA>220 037 426</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220037426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666717.569000 570296.112000</gml:lowerCorner>
        		<gml:upperCorner>666717.569000 570296.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666717.569000 570296.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 032 876</ms:GML_ID>
        <ms:NAZWA>220 032 876</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220032876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666054.630000 571004.707000</gml:lowerCorner>
        		<gml:upperCorner>666054.630000 571004.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666054.630000 571004.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 031 858</ms:GML_ID>
        <ms:NAZWA>220 031 858</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220031858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665219.732000 573797.729000</gml:lowerCorner>
        		<gml:upperCorner>665219.732000 573797.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665219.732000 573797.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 028 530</ms:GML_ID>
        <ms:NAZWA>220 028 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220028530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665259.306000 574418.066000</gml:lowerCorner>
        		<gml:upperCorner>665259.306000 574418.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665259.306000 574418.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 027 907</ms:GML_ID>
        <ms:NAZWA>220 027 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220027907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664089.285000 576547.860000</gml:lowerCorner>
        		<gml:upperCorner>664089.285000 576547.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664089.285000 576547.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 025 430</ms:GML_ID>
        <ms:NAZWA>220 025 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220025430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662524.900000 578027.650000</gml:lowerCorner>
        		<gml:upperCorner>662524.900000 578027.650000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662524.900000 578027.650000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 023 187</ms:GML_ID>
        <ms:NAZWA>220 023 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220023187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662272.490000 578752.886000</gml:lowerCorner>
        		<gml:upperCorner>662272.490000 578752.886000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662272.490000 578752.886000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 022 393</ms:GML_ID>
        <ms:NAZWA>220 022 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220022393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661803.604000 580924.752000</gml:lowerCorner>
        		<gml:upperCorner>661803.604000 580924.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661803.604000 580924.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 019 785</ms:GML_ID>
        <ms:NAZWA>220 019 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220019785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662038.293000 581811.486000</gml:lowerCorner>
        		<gml:upperCorner>662038.293000 581811.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662038.293000 581811.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 018 868</ms:GML_ID>
        <ms:NAZWA>220 018 868</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220018868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662199.871000 582420.862000</gml:lowerCorner>
        		<gml:upperCorner>662199.871000 582420.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662199.871000 582420.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 018 235</ms:GML_ID>
        <ms:NAZWA>220 018 235</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220018235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662413.081000 583242.753000</gml:lowerCorner>
        		<gml:upperCorner>662413.081000 583242.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662413.081000 583242.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 017 388</ms:GML_ID>
        <ms:NAZWA>220 017 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220017388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662265.723000 584219.666000</gml:lowerCorner>
        		<gml:upperCorner>662265.723000 584219.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662265.723000 584219.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 016 391</ms:GML_ID>
        <ms:NAZWA>220 016 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220016391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662009.419000 585678.112000</gml:lowerCorner>
        		<gml:upperCorner>662009.419000 585678.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662009.419000 585678.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 014 903</ms:GML_ID>
        <ms:NAZWA>220 014 903</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220014903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662372.504000 587077.702000</gml:lowerCorner>
        		<gml:upperCorner>662372.504000 587077.702000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662372.504000 587077.702000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 013 441</ms:GML_ID>
        <ms:NAZWA>220 013 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220013441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662363.456322 587539.261155</gml:lowerCorner>
        		<gml:upperCorner>662363.456322 587539.261155</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662363.456322 587539.261155</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 012 972</ms:GML_ID>
        <ms:NAZWA>220 012 972</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220012972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661796.642000 589512.026000</gml:lowerCorner>
        		<gml:upperCorner>661796.642000 589512.026000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661796.642000 589512.026000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 010 918</ms:GML_ID>
        <ms:NAZWA>220 010 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220010918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665499.834780 590029.545224</gml:lowerCorner>
        		<gml:upperCorner>665499.834780 590029.545224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665499.834780 590029.545224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 006 409</ms:GML_ID>
        <ms:NAZWA>221 006 409</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221006409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661602.074000 590186.975000</gml:lowerCorner>
        		<gml:upperCorner>661602.074000 590186.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661602.074000 590186.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 010 217</ms:GML_ID>
        <ms:NAZWA>220 010 217</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220010217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663482.653000 590613.072000</gml:lowerCorner>
        		<gml:upperCorner>663482.653000 590613.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663482.653000 590613.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 004 303</ms:GML_ID>
        <ms:NAZWA>221 004 303</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221004303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668381.711000 591052.067000</gml:lowerCorner>
        		<gml:upperCorner>668381.711000 591052.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668381.711000 591052.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 009 739</ms:GML_ID>
        <ms:NAZWA>221 009 739</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221009739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661369.350000 591829.438000</gml:lowerCorner>
        		<gml:upperCorner>661369.350000 591829.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661369.350000 591829.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 008 541</ms:GML_ID>
        <ms:NAZWA>220 008 541</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220008541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661364.931803 592591.201207</gml:lowerCorner>
        		<gml:upperCorner>661364.931803 592591.201207</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661364.931803 592591.201207</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 007 779</ms:GML_ID>
        <ms:NAZWA>220 007 779</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220007779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648870.413000 563221.206000</gml:lowerCorner>
        		<gml:upperCorner>648870.413000 563221.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648870.413000 563221.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 259 555</ms:GML_ID>
        <ms:NAZWA>353 259 555</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353259555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648883.325000 563364.275000</gml:lowerCorner>
        		<gml:upperCorner>648883.325000 563364.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648883.325000 563364.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 259 698</ms:GML_ID>
        <ms:NAZWA>353 259 698</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353259698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648992.122011 567356.391142</gml:lowerCorner>
        		<gml:upperCorner>648992.122011 567356.391142</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648992.122011 567356.391142</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 263 824</ms:GML_ID>
        <ms:NAZWA>353 263 824</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353263824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649965.392000 576988.004000</gml:lowerCorner>
        		<gml:upperCorner>649965.392000 576988.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649965.392000 576988.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 274 398</ms:GML_ID>
        <ms:NAZWA>353 274 398</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353274398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651083.774000 578140.801000</gml:lowerCorner>
        		<gml:upperCorner>651083.774000 578140.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651083.774000 578140.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 276 019</ms:GML_ID>
        <ms:NAZWA>353 276 019</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353276019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651357.503379 579006.568836</gml:lowerCorner>
        		<gml:upperCorner>651357.503379 579006.568836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651357.503379 579006.568836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 276 928</ms:GML_ID>
        <ms:NAZWA>353 276 928</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353276928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651601.424000 579879.542000</gml:lowerCorner>
        		<gml:upperCorner>651601.424000 579879.542000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651601.424000 579879.542000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 277 835</ms:GML_ID>
        <ms:NAZWA>353 277 835</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353277835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651768.233000 580418.352000</gml:lowerCorner>
        		<gml:upperCorner>651768.233000 580418.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651768.233000 580418.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 278 394</ms:GML_ID>
        <ms:NAZWA>353 278 394</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353278394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652228.426000 585127.588000</gml:lowerCorner>
        		<gml:upperCorner>652228.426000 585127.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652228.426000 585127.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 283 364</ms:GML_ID>
        <ms:NAZWA>353 283 364</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353283364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652237.959000 583627.697000</gml:lowerCorner>
        		<gml:upperCorner>652237.959000 583627.697000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652237.959000 583627.697000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 281 831</ms:GML_ID>
        <ms:NAZWA>353 281 831</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353281831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652404.647000 581568.652000</gml:lowerCorner>
        		<gml:upperCorner>652404.647000 581568.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652404.647000 581568.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 279 715</ms:GML_ID>
        <ms:NAZWA>353 279 715</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353279715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652442.677000 586030.205000</gml:lowerCorner>
        		<gml:upperCorner>652442.677000 586030.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652442.677000 586030.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 284 291</ms:GML_ID>
        <ms:NAZWA>353 284 291</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353284291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652533.719000 586408.824000</gml:lowerCorner>
        		<gml:upperCorner>652533.719000 586408.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652533.719000 586408.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 284 680</ms:GML_ID>
        <ms:NAZWA>353 284 680</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353284680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653274.727000 587958.370000</gml:lowerCorner>
        		<gml:upperCorner>653274.727000 587958.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653274.727000 587958.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 286 407</ms:GML_ID>
        <ms:NAZWA>353 286 407</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353286407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653555.819000 588494.898000</gml:lowerCorner>
        		<gml:upperCorner>653555.819000 588494.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653555.819000 588494.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 287 014</ms:GML_ID>
        <ms:NAZWA>353 287 014</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353287014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653742.347000 589004.944000</gml:lowerCorner>
        		<gml:upperCorner>653742.347000 589004.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653742.347000 589004.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 287 547</ms:GML_ID>
        <ms:NAZWA>353 287 547</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353287547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654151.230830 590131.413671</gml:lowerCorner>
        		<gml:upperCorner>654151.230830 590131.413671</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654151.230830 590131.413671</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 288 757</ms:GML_ID>
        <ms:NAZWA>353 288 757</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353288757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654767.026000 591827.273000</gml:lowerCorner>
        		<gml:upperCorner>654767.026000 591827.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654767.026000 591827.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 290 561</ms:GML_ID>
        <ms:NAZWA>353 290 561</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353290561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547712.915220 571316.007956</gml:lowerCorner>
        		<gml:upperCorner>547712.915220 571316.007956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547712.915220 571316.007956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 059 167</ms:GML_ID>
        <ms:NAZWA>027 059 167</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027059167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548196.907211 569713.497846</gml:lowerCorner>
        		<gml:upperCorner>548196.907211 569713.497846</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548196.907211 569713.497846</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 060 848</ms:GML_ID>
        <ms:NAZWA>027 060 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027060848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548352.236449 568622.592134</gml:lowerCorner>
        		<gml:upperCorner>548352.236449 568622.592134</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548352.236449 568622.592134</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 061 950</ms:GML_ID>
        <ms:NAZWA>027 061 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027061950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548487.791000 567669.556000</gml:lowerCorner>
        		<gml:upperCorner>548487.791000 567669.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548487.791000 567669.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 062 913</ms:GML_ID>
        <ms:NAZWA>027 062 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027062913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548589.363587 566951.388895</gml:lowerCorner>
        		<gml:upperCorner>548589.363587 566951.388895</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548589.363587 566951.388895</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 063 639</ms:GML_ID>
        <ms:NAZWA>027 063 639</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027063639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548659.448472 566461.205202</gml:lowerCorner>
        		<gml:upperCorner>548659.448472 566461.205202</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548659.448472 566461.205202</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 064 136</ms:GML_ID>
        <ms:NAZWA>027 064 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027064136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549114.272117 565074.993962</gml:lowerCorner>
        		<gml:upperCorner>549114.272117 565074.993962</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549114.272117 565074.993962</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 065 597</ms:GML_ID>
        <ms:NAZWA>027 065 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027065597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549459.257000 564144.276000</gml:lowerCorner>
        		<gml:upperCorner>549459.257000 564144.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549459.257000 564144.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 066 591</ms:GML_ID>
        <ms:NAZWA>027 066 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027066591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549652.688000 563620.866000</gml:lowerCorner>
        		<gml:upperCorner>549652.688000 563620.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549652.688000 563620.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 067 150</ms:GML_ID>
        <ms:NAZWA>027 067 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027067150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549839.547296 563112.016823</gml:lowerCorner>
        		<gml:upperCorner>549839.547296 563112.016823</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549839.547296 563112.016823</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 067 692</ms:GML_ID>
        <ms:NAZWA>027 067 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027067692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550005.884690 562662.949684</gml:lowerCorner>
        		<gml:upperCorner>550005.884690 562662.949684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550005.884690 562662.949684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 068 171</ms:GML_ID>
        <ms:NAZWA>027 068 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027068171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550120.540075 562353.481694</gml:lowerCorner>
        		<gml:upperCorner>550120.540075 562353.481694</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550120.540075 562353.481694</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 068 502</ms:GML_ID>
        <ms:NAZWA>027 068 502</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027068502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550261.052952 561974.121832</gml:lowerCorner>
        		<gml:upperCorner>550261.052952 561974.121832</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550261.052952 561974.121832</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 068 906</ms:GML_ID>
        <ms:NAZWA>027 068 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027068906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550508.564000 561304.620000</gml:lowerCorner>
        		<gml:upperCorner>550508.564000 561304.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550508.564000 561304.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 069 621</ms:GML_ID>
        <ms:NAZWA>027 069 621</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027069621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550674.323071 560857.749712</gml:lowerCorner>
        		<gml:upperCorner>550674.323071 560857.749712</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550674.323071 560857.749712</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 070 097</ms:GML_ID>
        <ms:NAZWA>027 070 097</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027070097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550947.830745 560119.382203</gml:lowerCorner>
        		<gml:upperCorner>550947.830745 560119.382203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550947.830745 560119.382203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 070 886</ms:GML_ID>
        <ms:NAZWA>027 070 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027070886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551327.227225 559093.484723</gml:lowerCorner>
        		<gml:upperCorner>551327.227225 559093.484723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551327.227225 559093.484723</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 071 980</ms:GML_ID>
        <ms:NAZWA>027 071 980</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027071980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551472.679337 558700.364205</gml:lowerCorner>
        		<gml:upperCorner>551472.679337 558700.364205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551472.679337 558700.364205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 072 398</ms:GML_ID>
        <ms:NAZWA>027 072 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027072398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598846.786000 571031.932000</gml:lowerCorner>
        		<gml:upperCorner>598846.786000 571031.932000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598846.786000 571031.932000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 007 686</ms:GML_ID>
        <ms:NAZWA>208 007 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208007686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598906.413000 570604.308000</gml:lowerCorner>
        		<gml:upperCorner>598906.413000 570604.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598906.413000 570604.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 008 119</ms:GML_ID>
        <ms:NAZWA>208 008 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208008119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598954.157748 570269.068506</gml:lowerCorner>
        		<gml:upperCorner>598954.157748 570269.068506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598954.157748 570269.068506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 008 458</ms:GML_ID>
        <ms:NAZWA>208 008 458</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208008458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599052.490000 569851.228000</gml:lowerCorner>
        		<gml:upperCorner>599052.490000 569851.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599052.490000 569851.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 008 889</ms:GML_ID>
        <ms:NAZWA>208 008 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208008889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599590.258025 559565.058101</gml:lowerCorner>
        		<gml:upperCorner>599590.258025 559565.058101</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599590.258025 559565.058101</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 019 688</ms:GML_ID>
        <ms:NAZWA>208 019 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208019688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599669.827000 560092.067000</gml:lowerCorner>
        		<gml:upperCorner>599669.827000 560092.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599669.827000 560092.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 019 152</ms:GML_ID>
        <ms:NAZWA>208 019 152</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208019152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599875.063000 560975.094000</gml:lowerCorner>
        		<gml:upperCorner>599875.063000 560975.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599875.063000 560975.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 018 245</ms:GML_ID>
        <ms:NAZWA>208 018 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208018245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600262.307307 567677.315789</gml:lowerCorner>
        		<gml:upperCorner>600262.307307 567677.315789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600262.307307 567677.315789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 011 398</ms:GML_ID>
        <ms:NAZWA>208 011 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208011398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600347.657000 567518.680000</gml:lowerCorner>
        		<gml:upperCorner>600347.657000 567518.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600347.657000 567518.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 011 572</ms:GML_ID>
        <ms:NAZWA>208 011 572</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208011572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600356.171000 564794.703000</gml:lowerCorner>
        		<gml:upperCorner>600356.171000 564794.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600356.171000 564794.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 014 390</ms:GML_ID>
        <ms:NAZWA>208 014 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208014390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600656.264663 566557.855221</gml:lowerCorner>
        		<gml:upperCorner>600656.264663 566557.855221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600656.264663 566557.855221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 012 598</ms:GML_ID>
        <ms:NAZWA>208 012 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208012598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672127.678000 554755.970000</gml:lowerCorner>
        		<gml:upperCorner>672127.678000 554755.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672127.678000 554755.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 051 321</ms:GML_ID>
        <ms:NAZWA>220 051 321</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220051321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672729.861240 561494.597294</gml:lowerCorner>
        		<gml:upperCorner>672729.861240 561494.597294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672729.861240 561494.597294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 044 258</ms:GML_ID>
        <ms:NAZWA>220 044 258</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220044258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672648.512300 561576.418232</gml:lowerCorner>
        		<gml:upperCorner>672648.512300 561576.418232</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672648.512300 561576.418232</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 044 142</ms:GML_ID>
        <ms:NAZWA>220 044 142</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220044142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672041.442373 562188.258569</gml:lowerCorner>
        		<gml:upperCorner>672041.442373 562188.258569</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672041.442373 562188.258569</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 043 280</ms:GML_ID>
        <ms:NAZWA>220 043 280</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220043280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669495.523000 564580.115000</gml:lowerCorner>
        		<gml:upperCorner>669495.523000 564580.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669495.523000 564580.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 039 780</ms:GML_ID>
        <ms:NAZWA>220 039 780</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220039780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669105.507000 565848.382000</gml:lowerCorner>
        		<gml:upperCorner>669105.507000 565848.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669105.507000 565848.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 038 422</ms:GML_ID>
        <ms:NAZWA>220 038 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220038422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698641.300000 574592.187000</gml:lowerCorner>
        		<gml:upperCorner>698641.300000 574592.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698641.300000 574592.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 048 703</ms:GML_ID>
        <ms:NAZWA>221 048 703</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221048703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698302.388000 574639.753000</gml:lowerCorner>
        		<gml:upperCorner>698302.388000 574639.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698302.388000 574639.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 048 360</ms:GML_ID>
        <ms:NAZWA>221 048 360</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221048360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694102.314000 576031.385000</gml:lowerCorner>
        		<gml:upperCorner>694102.314000 576031.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694102.314000 576031.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 043 711</ms:GML_ID>
        <ms:NAZWA>221 043 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221043711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690968.615000 579816.739000</gml:lowerCorner>
        		<gml:upperCorner>690968.615000 579816.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690968.615000 579816.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 038 734</ms:GML_ID>
        <ms:NAZWA>221 038 734</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221038734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689892.325000 580624.275210</gml:lowerCorner>
        		<gml:upperCorner>689892.325000 580624.275210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689892.325000 580624.275210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 037 367</ms:GML_ID>
        <ms:NAZWA>221 037 367</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221037367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687163.548000 583357.023000</gml:lowerCorner>
        		<gml:upperCorner>687163.548000 583357.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687163.548000 583357.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 033 295</ms:GML_ID>
        <ms:NAZWA>221 033 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221033295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686580.819000 584130.405000</gml:lowerCorner>
        		<gml:upperCorner>686580.819000 584130.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686580.819000 584130.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 032 329</ms:GML_ID>
        <ms:NAZWA>221 032 329</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221032329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686330.529000 584478.425000</gml:lowerCorner>
        		<gml:upperCorner>686330.529000 584478.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686330.529000 584478.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 031 899</ms:GML_ID>
        <ms:NAZWA>221 031 899</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221031899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685634.654000 584993.391000</gml:lowerCorner>
        		<gml:upperCorner>685634.654000 584993.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685634.654000 584993.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 031 021</ms:GML_ID>
        <ms:NAZWA>221 031 021</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221031021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684659.254000 586229.593000</gml:lowerCorner>
        		<gml:upperCorner>684659.254000 586229.593000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684659.254000 586229.593000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 029 405</ms:GML_ID>
        <ms:NAZWA>221 029 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221029405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684340.130000 586364.131000</gml:lowerCorner>
        		<gml:upperCorner>684340.130000 586364.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684340.130000 586364.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 029 060</ms:GML_ID>
        <ms:NAZWA>221 029 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221029060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683023.281976 586961.825310</gml:lowerCorner>
        		<gml:upperCorner>683023.281976 586961.825310</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683023.281976 586961.825310</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 027 612</ms:GML_ID>
        <ms:NAZWA>221 027 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221027612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681877.118000 588433.487000</gml:lowerCorner>
        		<gml:upperCorner>681877.118000 588433.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681877.118000 588433.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 025 632</ms:GML_ID>
        <ms:NAZWA>221 025 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221025632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681562.962000 589790.347000</gml:lowerCorner>
        		<gml:upperCorner>681562.962000 589790.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681562.962000 589790.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 024 228</ms:GML_ID>
        <ms:NAZWA>221 024 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221024228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681261.058179 590524.726358</gml:lowerCorner>
        		<gml:upperCorner>681261.058179 590524.726358</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681261.058179 590524.726358</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 023 443</ms:GML_ID>
        <ms:NAZWA>221 023 443</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221023443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680487.120609 590948.689221</gml:lowerCorner>
        		<gml:upperCorner>680487.120609 590948.689221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680487.120609 590948.689221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 022 553</ms:GML_ID>
        <ms:NAZWA>221 022 553</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221022553</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712466.388571 552034.530598</gml:lowerCorner>
        		<gml:upperCorner>712466.388571 552034.530598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712466.388571 552034.530598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 071 104</ms:GML_ID>
        <ms:NAZWA>204 071 104</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204071104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723731.394128 552243.586244</gml:lowerCorner>
        		<gml:upperCorner>723731.394128 552243.586244</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723731.394128 552243.586244</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 044 979</ms:GML_ID>
        <ms:NAZWA>254 044 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254044979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723711.132545 553091.924893</gml:lowerCorner>
        		<gml:upperCorner>723711.132545 553091.924893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723711.132545 553091.924893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 045 830</ms:GML_ID>
        <ms:NAZWA>254 045 830</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254045830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723704.496352 553196.449471</gml:lowerCorner>
        		<gml:upperCorner>723704.496352 553196.449471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723704.496352 553196.449471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 045 936</ms:GML_ID>
        <ms:NAZWA>254 045 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254045936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717630.685247 553955.631922</gml:lowerCorner>
        		<gml:upperCorner>717630.685247 553955.631922</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717630.685247 553955.631922</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 076 615</ms:GML_ID>
        <ms:NAZWA>204 076 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204076615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723481.293743 554008.209373</gml:lowerCorner>
        		<gml:upperCorner>723481.293743 554008.209373</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723481.293743 554008.209373</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 046 804</ms:GML_ID>
        <ms:NAZWA>254 046 804</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254046804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>726088.682285 554582.634045</gml:lowerCorner>
        		<gml:upperCorner>726088.682285 554582.634045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>726088.682285 554582.634045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 085 347</ms:GML_ID>
        <ms:NAZWA>204 085 347</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204085347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724668.147059 554609.167973</gml:lowerCorner>
        		<gml:upperCorner>724668.147059 554609.167973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724668.147059 554609.167973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 083 933</ms:GML_ID>
        <ms:NAZWA>204 083 933</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204083933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723516.363106 554722.220879</gml:lowerCorner>
        		<gml:upperCorner>723516.363106 554722.220879</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723516.363106 554722.220879</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 047 520</ms:GML_ID>
        <ms:NAZWA>254 047 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254047520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724211.557462 554746.462472</gml:lowerCorner>
        		<gml:upperCorner>724211.557462 554746.462472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724211.557462 554746.462472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 083 469</ms:GML_ID>
        <ms:NAZWA>204 083 469</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204083469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723213.731000 554994.505000</gml:lowerCorner>
        		<gml:upperCorner>723213.731000 554994.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723213.731000 554994.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 082 430</ms:GML_ID>
        <ms:NAZWA>204 082 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204082430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722958.317000 555060.133000</gml:lowerCorner>
        		<gml:upperCorner>722958.317000 555060.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722958.317000 555060.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 082 170</ms:GML_ID>
        <ms:NAZWA>204 082 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204082170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722124.038000 555239.738000</gml:lowerCorner>
        		<gml:upperCorner>722124.038000 555239.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722124.038000 555239.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 081 313</ms:GML_ID>
        <ms:NAZWA>204 081 313</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204081313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729496.871915 555288.991237</gml:lowerCorner>
        		<gml:upperCorner>729496.871915 555288.991237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729496.871915 555288.991237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 088 902</ms:GML_ID>
        <ms:NAZWA>204 088 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204088902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723649.475000 555499.874000</gml:lowerCorner>
        		<gml:upperCorner>723649.475000 555499.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723649.475000 555499.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 086 265</ms:GML_ID>
        <ms:NAZWA>221 086 265</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221086265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723043.230000 557004.673000</gml:lowerCorner>
        		<gml:upperCorner>723043.230000 557004.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723043.230000 557004.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 084 641</ms:GML_ID>
        <ms:NAZWA>221 084 641</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221084641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723000.317000 557432.248000</gml:lowerCorner>
        		<gml:upperCorner>723000.317000 557432.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723000.317000 557432.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 084 210</ms:GML_ID>
        <ms:NAZWA>221 084 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221084210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722656.596000 558149.881000</gml:lowerCorner>
        		<gml:upperCorner>722656.596000 558149.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722656.596000 558149.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 083 378</ms:GML_ID>
        <ms:NAZWA>221 083 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221083378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721718.636000 559290.520000</gml:lowerCorner>
        		<gml:upperCorner>721718.636000 559290.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721718.636000 559290.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 081 875</ms:GML_ID>
        <ms:NAZWA>221 081 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221081875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721452.341000 559960.889000</gml:lowerCorner>
        		<gml:upperCorner>721452.341000 559960.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721452.341000 559960.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 081 156</ms:GML_ID>
        <ms:NAZWA>221 081 156</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221081156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721123.312000 561432.479000</gml:lowerCorner>
        		<gml:upperCorner>721123.312000 561432.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721123.312000 561432.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 079 644</ms:GML_ID>
        <ms:NAZWA>221 079 644</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221079644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719876.073000 563121.616000</gml:lowerCorner>
        		<gml:upperCorner>719876.073000 563121.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719876.073000 563121.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 077 491</ms:GML_ID>
        <ms:NAZWA>221 077 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221077491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719489.350000 563368.760000</gml:lowerCorner>
        		<gml:upperCorner>719489.350000 563368.760000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719489.350000 563368.760000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 077 032</ms:GML_ID>
        <ms:NAZWA>221 077 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221077032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717331.833000 564484.364000</gml:lowerCorner>
        		<gml:upperCorner>717331.833000 564484.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717331.833000 564484.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 074 574</ms:GML_ID>
        <ms:NAZWA>221 074 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221074574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715706.273000 565293.536000</gml:lowerCorner>
        		<gml:upperCorner>715706.273000 565293.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715706.273000 565293.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 072 736</ms:GML_ID>
        <ms:NAZWA>221 072 736</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221072736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712931.843473 566651.477336</gml:lowerCorner>
        		<gml:upperCorner>712931.843473 566651.477336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712931.843473 566651.477336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 069 608</ms:GML_ID>
        <ms:NAZWA>221 069 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221069608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712768.201723 566720.465907</gml:lowerCorner>
        		<gml:upperCorner>712768.201723 566720.465907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712768.201723 566720.465907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 069 430</ms:GML_ID>
        <ms:NAZWA>221 069 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221069430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712240.496375 567201.764538</gml:lowerCorner>
        		<gml:upperCorner>712240.496375 567201.764538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712240.496375 567201.764538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 068 658</ms:GML_ID>
        <ms:NAZWA>221 068 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221068658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711153.244000 570807.340000</gml:lowerCorner>
        		<gml:upperCorner>711153.244000 570807.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711153.244000 570807.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 064 706</ms:GML_ID>
        <ms:NAZWA>221 064 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221064706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710995.257000 571014.207000</gml:lowerCorner>
        		<gml:upperCorner>710995.257000 571014.207000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710995.257000 571014.207000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 064 441</ms:GML_ID>
        <ms:NAZWA>221 064 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221064441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708884.030217 573211.279946</gml:lowerCorner>
        		<gml:upperCorner>708884.030217 573211.279946</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708884.030217 573211.279946</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 060 162</ms:GML_ID>
        <ms:NAZWA>221 060 162</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221060162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709500.274743 573507.161540</gml:lowerCorner>
        		<gml:upperCorner>709500.274743 573507.161540</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709500.274743 573507.161540</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 060 844</ms:GML_ID>
        <ms:NAZWA>221 060 844</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221060844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710331.040000 573524.368000</gml:lowerCorner>
        		<gml:upperCorner>710331.040000 573524.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710331.040000 573524.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 061 737</ms:GML_ID>
        <ms:NAZWA>221 061 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221061737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702655.032000 573920.700000</gml:lowerCorner>
        		<gml:upperCorner>702655.032000 573920.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702655.032000 573920.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.221 053 146</ms:GML_ID>
        <ms:NAZWA>221 053 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>221053146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617586.528550 551333.040373</gml:lowerCorner>
        		<gml:upperCorner>617586.528550 551333.040373</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617586.528550 551333.040373</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 184 439</ms:GML_ID>
        <ms:NAZWA>009 184 439</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009184439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616769.653885 552095.336876</gml:lowerCorner>
        		<gml:upperCorner>616769.653885 552095.336876</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616769.653885 552095.336876</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 183 309</ms:GML_ID>
        <ms:NAZWA>009 183 309</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009183309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645512.093947 553878.485456</gml:lowerCorner>
        		<gml:upperCorner>645512.093947 553878.485456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645512.093947 553878.485456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 249 348</ms:GML_ID>
        <ms:NAZWA>353 249 348</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353249348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616270.329629 554172.170689</gml:lowerCorner>
        		<gml:upperCorner>616270.329629 554172.170689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616270.329629 554172.170689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 181 092</ms:GML_ID>
        <ms:NAZWA>009 181 092</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009181092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645620.370000 556238.936000</gml:lowerCorner>
        		<gml:upperCorner>645620.370000 556238.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645620.370000 556238.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 251 716</ms:GML_ID>
        <ms:NAZWA>353 251 716</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353251716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646669.474000 557996.084847</gml:lowerCorner>
        		<gml:upperCorner>646669.474000 557996.084847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646669.474000 557996.084847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 253 778</ms:GML_ID>
        <ms:NAZWA>353 253 778</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353253778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613874.051073 559523.810501</gml:lowerCorner>
        		<gml:upperCorner>613874.051073 559523.810501</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613874.051073 559523.810501</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 174 475</ms:GML_ID>
        <ms:NAZWA>009 174 475</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009174475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613213.804107 561062.751481</gml:lowerCorner>
        		<gml:upperCorner>613213.804107 561062.751481</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613213.804107 561062.751481</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 172 769</ms:GML_ID>
        <ms:NAZWA>009 172 769</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009172769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612328.202722 561995.981040</gml:lowerCorner>
        		<gml:upperCorner>612328.202722 561995.981040</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612328.202722 561995.981040</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 171 430</ms:GML_ID>
        <ms:NAZWA>009 171 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009171430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610663.541053 563042.085014</gml:lowerCorner>
        		<gml:upperCorner>610663.541053 563042.085014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610663.541053 563042.085014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 169 458</ms:GML_ID>
        <ms:NAZWA>009 169 458</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009169458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609010.872428 565438.910822</gml:lowerCorner>
        		<gml:upperCorner>609010.872428 565438.910822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609010.872428 565438.910822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 166 476</ms:GML_ID>
        <ms:NAZWA>009 166 476</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009166476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648724.505000 568130.546000</gml:lowerCorner>
        		<gml:upperCorner>648724.505000 568130.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648724.505000 568130.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 264 643</ms:GML_ID>
        <ms:NAZWA>353 264 643</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353264643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648547.780921 568638.594829</gml:lowerCorner>
        		<gml:upperCorner>648547.780921 568638.594829</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648547.780921 568638.594829</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 265 181</ms:GML_ID>
        <ms:NAZWA>353 265 181</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353265181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647949.891000 572195.062000</gml:lowerCorner>
        		<gml:upperCorner>647949.891000 572195.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647949.891000 572195.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 268 984</ms:GML_ID>
        <ms:NAZWA>353 268 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353268984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635661.384306 585454.211385</gml:lowerCorner>
        		<gml:upperCorner>635661.384306 585454.211385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635661.384306 585454.211385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 052 223</ms:GML_ID>
        <ms:NAZWA>216 052 223</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216052223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635963.012595 585563.090616</gml:lowerCorner>
        		<gml:upperCorner>635963.012595 585563.090616</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635963.012595 585563.090616</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 052 546</ms:GML_ID>
        <ms:NAZWA>216 052 546</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216052546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636949.675021 585932.409899</gml:lowerCorner>
        		<gml:upperCorner>636949.675021 585932.409899</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636949.675021 585932.409899</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 053 603</ms:GML_ID>
        <ms:NAZWA>216 053 603</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216053603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638214.570000 586516.701000</gml:lowerCorner>
        		<gml:upperCorner>638214.570000 586516.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638214.570000 586516.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 055 000</ms:GML_ID>
        <ms:NAZWA>216 055 000</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216055000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604705.503000 586908.263000</gml:lowerCorner>
        		<gml:upperCorner>604705.503000 586908.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604705.503000 586908.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 013 691</ms:GML_ID>
        <ms:NAZWA>216 013 691</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216013691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605555.878060 587296.386211</gml:lowerCorner>
        		<gml:upperCorner>605555.878060 587296.386211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605555.878060 587296.386211</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 014 622</ms:GML_ID>
        <ms:NAZWA>216 014 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216014622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632921.790000 587757.534000</gml:lowerCorner>
        		<gml:upperCorner>632921.790000 587757.534000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632921.790000 587757.534000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 048 339</ms:GML_ID>
        <ms:NAZWA>216 048 339</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216048339</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631558.111000 587933.020000</gml:lowerCorner>
        		<gml:upperCorner>631558.111000 587933.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631558.111000 587933.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 046 932</ms:GML_ID>
        <ms:NAZWA>216 046 932</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216046932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630773.957371 588031.940319</gml:lowerCorner>
        		<gml:upperCorner>630773.957371 588031.940319</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630773.957371 588031.940319</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 046 120</ms:GML_ID>
        <ms:NAZWA>216 046 120</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216046120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607232.440401 588059.286137</gml:lowerCorner>
        		<gml:upperCorner>607232.440401 588059.286137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607232.440401 588059.286137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 016 469</ms:GML_ID>
        <ms:NAZWA>216 016 469</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216016469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639514.405000 588964.350000</gml:lowerCorner>
        		<gml:upperCorner>639514.405000 588964.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639514.405000 588964.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 057 861</ms:GML_ID>
        <ms:NAZWA>216 057 861</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216057861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628430.871835 589557.922487</gml:lowerCorner>
        		<gml:upperCorner>628430.871835 589557.922487</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628430.871835 589557.922487</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 043 280</ms:GML_ID>
        <ms:NAZWA>216 043 280</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216043280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640265.181903 590117.814839</gml:lowerCorner>
        		<gml:upperCorner>640265.181903 590117.814839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640265.181903 590117.814839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 059 387</ms:GML_ID>
        <ms:NAZWA>216 059 387</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216059387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609145.119000 590265.180000</gml:lowerCorner>
        		<gml:upperCorner>609145.119000 590265.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609145.119000 590265.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 019 397</ms:GML_ID>
        <ms:NAZWA>216 019 397</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216019397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623404.182559 591256.170300</gml:lowerCorner>
        		<gml:upperCorner>623404.182559 591256.170300</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623404.182559 591256.170300</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 037 505</ms:GML_ID>
        <ms:NAZWA>216 037 505</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216037505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624802.730187 591298.246208</gml:lowerCorner>
        		<gml:upperCorner>624802.730187 591298.246208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624802.730187 591298.246208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 038 919</ms:GML_ID>
        <ms:NAZWA>216 038 919</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216038919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641738.424096 591366.323765</gml:lowerCorner>
        		<gml:upperCorner>641738.424096 591366.323765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641738.424096 591366.323765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 061 356</ms:GML_ID>
        <ms:NAZWA>216 061 356</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216061356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642432.563121 591946.822631</gml:lowerCorner>
        		<gml:upperCorner>642432.563121 591946.822631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642432.563121 591946.822631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.216 062 264</ms:GML_ID>
        <ms:NAZWA>216 062 264</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>216062264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633951.312430 537621.190740</gml:lowerCorner>
        		<gml:upperCorner>633951.312430 537621.190740</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633951.312430 537621.190740</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.967 000 593</ms:GML_ID>
        <ms:NAZWA>967 000 593</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>967000593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637566.278000 539698.647000</gml:lowerCorner>
        		<gml:upperCorner>637566.278000 539698.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637566.278000 539698.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 232 519</ms:GML_ID>
        <ms:NAZWA>353 232 519</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353232519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638081.094000 540194.877000</gml:lowerCorner>
        		<gml:upperCorner>638081.094000 540194.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638081.094000 540194.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 233 235</ms:GML_ID>
        <ms:NAZWA>353 233 235</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353233235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639031.196000 541705.185000</gml:lowerCorner>
        		<gml:upperCorner>639031.196000 541705.185000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639031.196000 541705.185000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 235 034</ms:GML_ID>
        <ms:NAZWA>353 235 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353235034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639891.115687 542377.766035</gml:lowerCorner>
        		<gml:upperCorner>639891.115687 542377.766035</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639891.115687 542377.766035</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 236 129</ms:GML_ID>
        <ms:NAZWA>353 236 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353236129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640889.336000 543116.019000</gml:lowerCorner>
        		<gml:upperCorner>640889.336000 543116.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640889.336000 543116.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 237 371</ms:GML_ID>
        <ms:NAZWA>353 237 371</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353237371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641245.234000 543422.487000</gml:lowerCorner>
        		<gml:upperCorner>641245.234000 543422.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641245.234000 543422.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 237 848</ms:GML_ID>
        <ms:NAZWA>353 237 848</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353237848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642232.041000 545301.810000</gml:lowerCorner>
        		<gml:upperCorner>642232.041000 545301.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642232.041000 545301.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 239 977</ms:GML_ID>
        <ms:NAZWA>353 239 977</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353239977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680185.852000 545826.432000</gml:lowerCorner>
        		<gml:upperCorner>680185.852000 545826.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680185.852000 545826.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 065 770</ms:GML_ID>
        <ms:NAZWA>220 065 770</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220065770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679441.679000 546100.564000</gml:lowerCorner>
        		<gml:upperCorner>679441.679000 546100.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679441.679000 546100.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 064 976</ms:GML_ID>
        <ms:NAZWA>220 064 976</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220064976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642528.007000 546254.845000</gml:lowerCorner>
        		<gml:upperCorner>642528.007000 546254.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642528.007000 546254.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 240 971</ms:GML_ID>
        <ms:NAZWA>353 240 971</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353240971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678266.209000 546602.085000</gml:lowerCorner>
        		<gml:upperCorner>678266.209000 546602.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678266.209000 546602.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 063 695</ms:GML_ID>
        <ms:NAZWA>220 063 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220063695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642764.552000 547015.931000</gml:lowerCorner>
        		<gml:upperCorner>642764.552000 547015.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642764.552000 547015.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 241 768</ms:GML_ID>
        <ms:NAZWA>353 241 768</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353241768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676745.926000 547076.459000</gml:lowerCorner>
        		<gml:upperCorner>676745.926000 547076.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676745.926000 547076.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 062 089</ms:GML_ID>
        <ms:NAZWA>220 062 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220062089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676103.366000 547309.601000</gml:lowerCorner>
        		<gml:upperCorner>676103.366000 547309.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676103.366000 547309.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 061 405</ms:GML_ID>
        <ms:NAZWA>220 061 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220061405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620160.802652 547537.045172</gml:lowerCorner>
        		<gml:upperCorner>620160.802652 547537.045172</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620160.802652 547537.045172</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 189 363</ms:GML_ID>
        <ms:NAZWA>009 189 363</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009189363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643768.371000 548765.556000</gml:lowerCorner>
        		<gml:upperCorner>643768.371000 548765.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643768.371000 548765.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 243 808</ms:GML_ID>
        <ms:NAZWA>353 243 808</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353243808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672866.420000 548857.383000</gml:lowerCorner>
        		<gml:upperCorner>672866.420000 548857.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672866.420000 548857.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 057 566</ms:GML_ID>
        <ms:NAZWA>220 057 566</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220057566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644820.887000 550428.307000</gml:lowerCorner>
        		<gml:upperCorner>644820.887000 550428.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644820.887000 550428.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 245 768</ms:GML_ID>
        <ms:NAZWA>353 245 768</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353245768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555586.108000 539317.969000</gml:lowerCorner>
        		<gml:upperCorner>555586.108000 539317.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555586.108000 539317.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 092 951</ms:GML_ID>
        <ms:NAZWA>027 092 951</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027092951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555825.059000 537524.186000</gml:lowerCorner>
        		<gml:upperCorner>555825.059000 537524.186000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555825.059000 537524.186000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 094 762</ms:GML_ID>
        <ms:NAZWA>027 094 762</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027094762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557146.476000 542066.109000</gml:lowerCorner>
        		<gml:upperCorner>557146.476000 542066.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557146.476000 542066.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 091 362</ms:GML_ID>
        <ms:NAZWA>033 091 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033091362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597379.355000 550906.199000</gml:lowerCorner>
        		<gml:upperCorner>597379.355000 550906.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597379.355000 550906.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 029 208</ms:GML_ID>
        <ms:NAZWA>208 029 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208029208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597581.265000 550149.243000</gml:lowerCorner>
        		<gml:upperCorner>597581.265000 550149.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597581.265000 550149.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 029 996</ms:GML_ID>
        <ms:NAZWA>208 029 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208029996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597788.123000 551577.993000</gml:lowerCorner>
        		<gml:upperCorner>597788.123000 551577.993000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597788.123000 551577.993000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 028 410</ms:GML_ID>
        <ms:NAZWA>208 028 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208028410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597790.514000 545187.550000</gml:lowerCorner>
        		<gml:upperCorner>597790.514000 545187.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597790.514000 545187.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 035 307</ms:GML_ID>
        <ms:NAZWA>208 035 307</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208035307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598196.196000 541586.199000</gml:lowerCorner>
        		<gml:upperCorner>598196.196000 541586.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598196.196000 541586.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 039 108</ms:GML_ID>
        <ms:NAZWA>208 039 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208039108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598206.521000 544508.095000</gml:lowerCorner>
        		<gml:upperCorner>598206.521000 544508.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598206.521000 544508.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 036 103</ms:GML_ID>
        <ms:NAZWA>208 036 103</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208036103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598249.020000 542188.679000</gml:lowerCorner>
        		<gml:upperCorner>598249.020000 542188.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598249.020000 542188.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 038 496</ms:GML_ID>
        <ms:NAZWA>208 038 496</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208038496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598420.303049 540858.431903</gml:lowerCorner>
        		<gml:upperCorner>598420.303049 540858.431903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598420.303049 540858.431903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 039 887</ms:GML_ID>
        <ms:NAZWA>208 039 887</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208039887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598442.900000 542894.475000</gml:lowerCorner>
        		<gml:upperCorner>598442.900000 542894.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598442.900000 542894.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 037 763</ms:GML_ID>
        <ms:NAZWA>208 037 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208037763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598856.569000 540158.027000</gml:lowerCorner>
        		<gml:upperCorner>598856.569000 540158.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598856.569000 540158.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 040 713</ms:GML_ID>
        <ms:NAZWA>208 040 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208040713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599074.924000 539818.425000</gml:lowerCorner>
        		<gml:upperCorner>599074.924000 539818.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599074.924000 539818.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 041 117</ms:GML_ID>
        <ms:NAZWA>208 041 117</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208041117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599587.427000 539400.737000</gml:lowerCorner>
        		<gml:upperCorner>599587.427000 539400.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599587.427000 539400.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 041 784</ms:GML_ID>
        <ms:NAZWA>208 041 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208041784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599696.780000 557883.740000</gml:lowerCorner>
        		<gml:upperCorner>599696.780000 557883.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599696.780000 557883.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 021 374</ms:GML_ID>
        <ms:NAZWA>208 021 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208021374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599809.831000 557247.638000</gml:lowerCorner>
        		<gml:upperCorner>599809.831000 557247.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599809.831000 557247.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 022 022</ms:GML_ID>
        <ms:NAZWA>208 022 022</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208022022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599866.285925 556803.543174</gml:lowerCorner>
        		<gml:upperCorner>599866.285925 556803.543174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599866.285925 556803.543174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 022 468</ms:GML_ID>
        <ms:NAZWA>208 022 468</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208022468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599870.348000 539094.436000</gml:lowerCorner>
        		<gml:upperCorner>599870.348000 539094.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599870.348000 539094.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 042 204</ms:GML_ID>
        <ms:NAZWA>208 042 204</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208042204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600248.805000 538742.436000</gml:lowerCorner>
        		<gml:upperCorner>600248.805000 538742.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600248.805000 538742.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 042 720</ms:GML_ID>
        <ms:NAZWA>208 042 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208042720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600429.607000 536670.734000</gml:lowerCorner>
        		<gml:upperCorner>600429.607000 536670.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600429.607000 536670.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 044 920</ms:GML_ID>
        <ms:NAZWA>208 044 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208044920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600543.295000 537576.776000</gml:lowerCorner>
        		<gml:upperCorner>600543.295000 537576.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600543.295000 537576.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 044 005</ms:GML_ID>
        <ms:NAZWA>208 044 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208044005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700441.928000 549146.581000</gml:lowerCorner>
        		<gml:upperCorner>700441.928000 549146.581000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700441.928000 549146.581000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 058 388</ms:GML_ID>
        <ms:NAZWA>204 058 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204058388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701430.827817 525440.204510</gml:lowerCorner>
        		<gml:upperCorner>701430.827817 525440.204510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701430.827817 525440.204510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 005 480</ms:GML_ID>
        <ms:NAZWA>254 005 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254005480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702024.661000 548661.386000</gml:lowerCorner>
        		<gml:upperCorner>702024.661000 548661.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702024.661000 548661.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 060 050</ms:GML_ID>
        <ms:NAZWA>204 060 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204060050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702541.076692 548649.036658</gml:lowerCorner>
        		<gml:upperCorner>702541.076692 548649.036658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702541.076692 548649.036658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 060 566</ms:GML_ID>
        <ms:NAZWA>204 060 566</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204060566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703872.828000 525326.999000</gml:lowerCorner>
        		<gml:upperCorner>703872.828000 525326.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703872.828000 525326.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 006 716</ms:GML_ID>
        <ms:NAZWA>254 006 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254006716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704582.925000 525153.043000</gml:lowerCorner>
        		<gml:upperCorner>704582.925000 525153.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704582.925000 525153.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 007 441</ms:GML_ID>
        <ms:NAZWA>254 007 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254007441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704926.362000 549245.965000</gml:lowerCorner>
        		<gml:upperCorner>704926.362000 549245.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704926.362000 549245.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 063 055</ms:GML_ID>
        <ms:NAZWA>204 063 055</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204063055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705097.894000 525069.611000</gml:lowerCorner>
        		<gml:upperCorner>705097.894000 525069.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705097.894000 525069.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 007 981</ms:GML_ID>
        <ms:NAZWA>254 007 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254007981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705806.129000 525177.658000</gml:lowerCorner>
        		<gml:upperCorner>705806.129000 525177.658000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705806.129000 525177.658000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 008 692</ms:GML_ID>
        <ms:NAZWA>254 008 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254008692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707290.640000 550122.245000</gml:lowerCorner>
        		<gml:upperCorner>707290.640000 550122.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707290.640000 550122.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 065 579</ms:GML_ID>
        <ms:NAZWA>204 065 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204065579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710617.525130 551355.667444</gml:lowerCorner>
        		<gml:upperCorner>710617.525130 551355.667444</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710617.525130 551355.667444</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 069 131</ms:GML_ID>
        <ms:NAZWA>204 069 131</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204069131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722450.112267 547022.626952</gml:lowerCorner>
        		<gml:upperCorner>722450.112267 547022.626952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722450.112267 547022.626952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 039 416</ms:GML_ID>
        <ms:NAZWA>254 039 416</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254039416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722521.690207 545001.253636</gml:lowerCorner>
        		<gml:upperCorner>722521.690207 545001.253636</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722521.690207 545001.253636</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 037 311</ms:GML_ID>
        <ms:NAZWA>254 037 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254037311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722556.532319 545448.115187</gml:lowerCorner>
        		<gml:upperCorner>722556.532319 545448.115187</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722556.532319 545448.115187</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 037 794</ms:GML_ID>
        <ms:NAZWA>254 037 794</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254037794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722583.019949 550078.190913</gml:lowerCorner>
        		<gml:upperCorner>722583.019949 550078.190913</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722583.019949 550078.190913</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 042 517</ms:GML_ID>
        <ms:NAZWA>254 042 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254042517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722600.597360 549872.900788</gml:lowerCorner>
        		<gml:upperCorner>722600.597360 549872.900788</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722600.597360 549872.900788</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 042 308</ms:GML_ID>
        <ms:NAZWA>254 042 308</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254042308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722969.261484 550858.205903</gml:lowerCorner>
        		<gml:upperCorner>722969.261484 550858.205903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722969.261484 550858.205903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 043 394</ms:GML_ID>
        <ms:NAZWA>254 043 394</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254043394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723399.134000 551609.164000</gml:lowerCorner>
        		<gml:upperCorner>723399.134000 551609.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723399.134000 551609.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 044 273</ms:GML_ID>
        <ms:NAZWA>254 044 273</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254044273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723543.756618 551869.048154</gml:lowerCorner>
        		<gml:upperCorner>723543.756618 551869.048154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723543.756618 551869.048154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 044 585</ms:GML_ID>
        <ms:NAZWA>254 044 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254044585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>681383.780000 545373.672000</gml:lowerCorner>
        		<gml:upperCorner>681383.780000 545373.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>681383.780000 545373.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 067 052</ms:GML_ID>
        <ms:NAZWA>220 067 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220067052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682560.935000 544822.162000</gml:lowerCorner>
        		<gml:upperCorner>682560.935000 544822.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682560.935000 544822.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 068 351</ms:GML_ID>
        <ms:NAZWA>220 068 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220068351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684294.410000 542960.098000</gml:lowerCorner>
        		<gml:upperCorner>684294.410000 542960.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684294.410000 542960.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 072 434</ms:GML_ID>
        <ms:NAZWA>220 072 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220072434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685305.482000 542989.929000</gml:lowerCorner>
        		<gml:upperCorner>685305.482000 542989.929000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685305.482000 542989.929000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 073 447</ms:GML_ID>
        <ms:NAZWA>220 073 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220073447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685971.401000 543044.122000</gml:lowerCorner>
        		<gml:upperCorner>685971.401000 543044.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685971.401000 543044.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 074 118</ms:GML_ID>
        <ms:NAZWA>220 074 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220074118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688425.240000 542895.239000</gml:lowerCorner>
        		<gml:upperCorner>688425.240000 542895.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688425.240000 542895.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 076 615</ms:GML_ID>
        <ms:NAZWA>220 076 615</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220076615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688931.029000 542380.458000</gml:lowerCorner>
        		<gml:upperCorner>688931.029000 542380.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688931.029000 542380.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 077 366</ms:GML_ID>
        <ms:NAZWA>220 077 366</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220077366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689373.779000 540873.184000</gml:lowerCorner>
        		<gml:upperCorner>689373.779000 540873.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689373.779000 540873.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 078 967</ms:GML_ID>
        <ms:NAZWA>220 078 967</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220078967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692839.851071 536894.179108</gml:lowerCorner>
        		<gml:upperCorner>692839.851071 536894.179108</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692839.851071 536894.179108</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 040 835</ms:GML_ID>
        <ms:NAZWA>204 040 835</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204040835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693093.301203 537675.191722</gml:lowerCorner>
        		<gml:upperCorner>693093.301203 537675.191722</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693093.301203 537675.191722</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 041 658</ms:GML_ID>
        <ms:NAZWA>204 041 658</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204041658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693301.207000 539079.154000</gml:lowerCorner>
        		<gml:upperCorner>693301.207000 539079.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693301.207000 539079.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.220 083 390</ms:GML_ID>
        <ms:NAZWA>220 083 390</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>220083390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693521.750019 539064.079584</gml:lowerCorner>
        		<gml:upperCorner>693521.750019 539064.079584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693521.750019 539064.079584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 043 112</ms:GML_ID>
        <ms:NAZWA>204 043 112</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204043112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693923.855197 540309.451390</gml:lowerCorner>
        		<gml:upperCorner>693923.855197 540309.451390</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693923.855197 540309.451390</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 044 425</ms:GML_ID>
        <ms:NAZWA>204 044 425</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204044425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694310.469208 541507.654801</gml:lowerCorner>
        		<gml:upperCorner>694310.469208 541507.654801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694310.469208 541507.654801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 045 684</ms:GML_ID>
        <ms:NAZWA>204 045 684</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204045684</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695649.603979 545137.714252</gml:lowerCorner>
        		<gml:upperCorner>695649.603979 545137.714252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695649.603979 545137.714252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 049 560</ms:GML_ID>
        <ms:NAZWA>204 049 560</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204049560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696232.858063 546540.069590</gml:lowerCorner>
        		<gml:upperCorner>696232.858063 546540.069590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696232.858063 546540.069590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 051 082</ms:GML_ID>
        <ms:NAZWA>204 051 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204051082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696291.090427 548878.673022</gml:lowerCorner>
        		<gml:upperCorner>696291.090427 548878.673022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696291.090427 548878.673022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 053 460</ms:GML_ID>
        <ms:NAZWA>204 053 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204053460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698592.766000 524293.710000</gml:lowerCorner>
        		<gml:upperCorner>698592.766000 524293.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698592.766000 524293.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 001 928</ms:GML_ID>
        <ms:NAZWA>254 001 928</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254001928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602705.311000 523221.814000</gml:lowerCorner>
        		<gml:upperCorner>602705.311000 523221.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602705.311000 523221.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 060 314</ms:GML_ID>
        <ms:NAZWA>208 060 314</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208060314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603206.489000 522765.358000</gml:lowerCorner>
        		<gml:upperCorner>603206.489000 522765.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603206.489000 522765.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 060 994</ms:GML_ID>
        <ms:NAZWA>208 060 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208060994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603735.284410 522284.468691</gml:lowerCorner>
        		<gml:upperCorner>603735.284410 522284.468691</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603735.284410 522284.468691</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 061 708</ms:GML_ID>
        <ms:NAZWA>208 061 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208061708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604812.713559 521302.936508</gml:lowerCorner>
        		<gml:upperCorner>604812.713559 521302.936508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604812.713559 521302.936508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 063 166</ms:GML_ID>
        <ms:NAZWA>208 063 166</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208063166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605529.645370 520255.948394</gml:lowerCorner>
        		<gml:upperCorner>605529.645370 520255.948394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605529.645370 520255.948394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 064 438</ms:GML_ID>
        <ms:NAZWA>208 064 438</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208064438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607528.970000 516722.623000</gml:lowerCorner>
        		<gml:upperCorner>607528.970000 516722.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607528.970000 516722.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 068 563</ms:GML_ID>
        <ms:NAZWA>208 068 563</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208068563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609491.317000 515053.533000</gml:lowerCorner>
        		<gml:upperCorner>609491.317000 515053.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609491.317000 515053.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 071 148</ms:GML_ID>
        <ms:NAZWA>208 071 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208071148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611140.000000 514268.225000</gml:lowerCorner>
        		<gml:upperCorner>611140.000000 514268.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611140.000000 514268.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 073 002</ms:GML_ID>
        <ms:NAZWA>208 073 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208073002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612081.805000 514035.491000</gml:lowerCorner>
        		<gml:upperCorner>612081.805000 514035.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612081.805000 514035.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 073 979</ms:GML_ID>
        <ms:NAZWA>208 073 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208073979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612635.021428 513704.243502</gml:lowerCorner>
        		<gml:upperCorner>612635.021428 513704.243502</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612635.021428 513704.243502</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 074 629</ms:GML_ID>
        <ms:NAZWA>208 074 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208074629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614307.396625 512457.196183</gml:lowerCorner>
        		<gml:upperCorner>614307.396625 512457.196183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614307.396625 512457.196183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 076 723</ms:GML_ID>
        <ms:NAZWA>208 076 723</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208076723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614868.374000 512491.226000</gml:lowerCorner>
        		<gml:upperCorner>614868.374000 512491.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614868.374000 512491.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 195 774</ms:GML_ID>
        <ms:NAZWA>353 195 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353195774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615159.727000 513296.785000</gml:lowerCorner>
        		<gml:upperCorner>615159.727000 513296.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615159.727000 513296.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 196 631</ms:GML_ID>
        <ms:NAZWA>353 196 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353196631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615687.470779 514680.660205</gml:lowerCorner>
        		<gml:upperCorner>615687.470779 514680.660205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615687.470779 514680.660205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 198 116</ms:GML_ID>
        <ms:NAZWA>353 198 116</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353198116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616441.185739 515642.704306</gml:lowerCorner>
        		<gml:upperCorner>616441.185739 515642.704306</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616441.185739 515642.704306</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 199 338</ms:GML_ID>
        <ms:NAZWA>353 199 338</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353199338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618845.171697 517870.850515</gml:lowerCorner>
        		<gml:upperCorner>618845.171697 517870.850515</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618845.171697 517870.850515</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 202 621</ms:GML_ID>
        <ms:NAZWA>353 202 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353202621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622214.991903 521198.781352</gml:lowerCorner>
        		<gml:upperCorner>622214.991903 521198.781352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622214.991903 521198.781352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 207 501</ms:GML_ID>
        <ms:NAZWA>353 207 501</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353207501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622669.752026 522188.984524</gml:lowerCorner>
        		<gml:upperCorner>622669.752026 522188.984524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622669.752026 522188.984524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 208 592</ms:GML_ID>
        <ms:NAZWA>353 208 592</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353208592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623004.627458 522921.017344</gml:lowerCorner>
        		<gml:upperCorner>623004.627458 522921.017344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623004.627458 522921.017344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 209 397</ms:GML_ID>
        <ms:NAZWA>353 209 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353209397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623258.431810 523531.365865</gml:lowerCorner>
        		<gml:upperCorner>623258.431810 523531.365865</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623258.431810 523531.365865</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 210 059</ms:GML_ID>
        <ms:NAZWA>353 210 059</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353210059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623430.584859 523946.062653</gml:lowerCorner>
        		<gml:upperCorner>623430.584859 523946.062653</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623430.584859 523946.062653</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 210 508</ms:GML_ID>
        <ms:NAZWA>353 210 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353210508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623739.358088 524631.610590</gml:lowerCorner>
        		<gml:upperCorner>623739.358088 524631.610590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623739.358088 524631.610590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 211 262</ms:GML_ID>
        <ms:NAZWA>353 211 262</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353211262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625329.923790 526023.041783</gml:lowerCorner>
        		<gml:upperCorner>625329.923790 526023.041783</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625329.923790 526023.041783</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 213 430</ms:GML_ID>
        <ms:NAZWA>353 213 430</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353213430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626112.379891 527419.273717</gml:lowerCorner>
        		<gml:upperCorner>626112.379891 527419.273717</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626112.379891 527419.273717</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 215 068</ms:GML_ID>
        <ms:NAZWA>353 215 068</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353215068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627362.335876 530438.181806</gml:lowerCorner>
        		<gml:upperCorner>627362.335876 530438.181806</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627362.335876 530438.181806</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 218 347</ms:GML_ID>
        <ms:NAZWA>353 218 347</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353218347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630133.163014 533992.762736</gml:lowerCorner>
        		<gml:upperCorner>630133.163014 533992.762736</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630133.163014 533992.762736</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 222 870</ms:GML_ID>
        <ms:NAZWA>353 222 870</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353222870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688171.602000 514647.484000</gml:lowerCorner>
        		<gml:upperCorner>688171.602000 514647.484000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688171.602000 514647.484000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 012 309</ms:GML_ID>
        <ms:NAZWA>204 012 309</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204012309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689213.836000 516201.223000</gml:lowerCorner>
        		<gml:upperCorner>689213.836000 516201.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689213.836000 516201.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 014 183</ms:GML_ID>
        <ms:NAZWA>204 014 183</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204014183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689805.378000 517082.611000</gml:lowerCorner>
        		<gml:upperCorner>689805.378000 517082.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689805.378000 517082.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 015 245</ms:GML_ID>
        <ms:NAZWA>204 015 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204015245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690685.727000 518395.707000</gml:lowerCorner>
        		<gml:upperCorner>690685.727000 518395.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690685.727000 518395.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 016 849</ms:GML_ID>
        <ms:NAZWA>204 016 849</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204016849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691549.415421 519661.659446</gml:lowerCorner>
        		<gml:upperCorner>691549.415421 519661.659446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691549.415421 519661.659446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 018 365</ms:GML_ID>
        <ms:NAZWA>204 018 365</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204018365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691991.360227 520315.994947</gml:lowerCorner>
        		<gml:upperCorner>691991.360227 520315.994947</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691991.360227 520315.994947</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 019 147</ms:GML_ID>
        <ms:NAZWA>204 019 147</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204019147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693500.138513 533335.473390</gml:lowerCorner>
        		<gml:upperCorner>693500.138513 533335.473390</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693500.138513 533335.473390</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 037 190</ms:GML_ID>
        <ms:NAZWA>204 037 190</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204037190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693998.376000 531892.698000</gml:lowerCorner>
        		<gml:upperCorner>693998.376000 531892.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693998.376000 531892.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 035 665</ms:GML_ID>
        <ms:NAZWA>204 035 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204035665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694096.632000 522391.220000</gml:lowerCorner>
        		<gml:upperCorner>694096.632000 522391.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694096.632000 522391.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 022 128</ms:GML_ID>
        <ms:NAZWA>204 022 128</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204022128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694981.562000 530616.248000</gml:lowerCorner>
        		<gml:upperCorner>694981.562000 530616.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694981.562000 530616.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 034 022</ms:GML_ID>
        <ms:NAZWA>204 034 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204034022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695308.711000 523432.755000</gml:lowerCorner>
        		<gml:upperCorner>695308.711000 523432.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695308.711000 523432.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 023 729</ms:GML_ID>
        <ms:NAZWA>204 023 729</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204023729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696383.834000 529491.783000</gml:lowerCorner>
        		<gml:upperCorner>696383.834000 529491.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696383.834000 529491.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 032 223</ms:GML_ID>
        <ms:NAZWA>204 032 223</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204032223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696788.725000 524702.750000</gml:lowerCorner>
        		<gml:upperCorner>696788.725000 524702.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696788.725000 524702.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 025 677</ms:GML_ID>
        <ms:NAZWA>204 025 677</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204025677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698532.481114 526303.196337</gml:lowerCorner>
        		<gml:upperCorner>698532.481114 526303.196337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698532.481114 526303.196337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 028 051</ms:GML_ID>
        <ms:NAZWA>204 028 051</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204028051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698634.618039 526873.038857</gml:lowerCorner>
        		<gml:upperCorner>698634.618039 526873.038857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698634.618039 526873.038857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 028 645</ms:GML_ID>
        <ms:NAZWA>204 028 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204028645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701964.351515 525289.712547</gml:lowerCorner>
        		<gml:upperCorner>701964.351515 525289.712547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701964.351515 525289.712547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 004 797</ms:GML_ID>
        <ms:NAZWA>254 004 797</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254004797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703063.465665 507268.930404</gml:lowerCorner>
        		<gml:upperCorner>703063.465665 507268.930404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703063.465665 507268.930404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 022 218</ms:GML_ID>
        <ms:NAZWA>256 022 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256022218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703274.889062 525280.899065</gml:lowerCorner>
        		<gml:upperCorner>703274.889062 525280.899065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703274.889062 525280.899065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 006 114</ms:GML_ID>
        <ms:NAZWA>254 006 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254006114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703874.930391 507540.448134</gml:lowerCorner>
        		<gml:upperCorner>703874.930391 507540.448134</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703874.930391 507540.448134</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 023 090</ms:GML_ID>
        <ms:NAZWA>256 023 090</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256023090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

