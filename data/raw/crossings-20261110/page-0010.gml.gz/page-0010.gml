<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:30" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=9000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=11000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>387211.647282 193795.170000</gml:lowerCorner>
      		<gml:upperCorner>596133.169193 363535.340000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439116.433383 310865.672625</gml:lowerCorner>
        		<gml:upperCorner>439116.433383 310865.672625</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439116.433383 310865.672625</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 258 916</ms:GML_ID>
        <ms:NAZWA>014 258 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014258916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439292.070953 311921.438874</gml:lowerCorner>
        		<gml:upperCorner>439292.070953 311921.438874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439292.070953 311921.438874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 257 846</ms:GML_ID>
        <ms:NAZWA>014 257 846</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014257846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439589.347864 313711.044865</gml:lowerCorner>
        		<gml:upperCorner>439589.347864 313711.044865</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439589.347864 313711.044865</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 256 037</ms:GML_ID>
        <ms:NAZWA>014 256 037</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014256037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440037.074773 316375.673571</gml:lowerCorner>
        		<gml:upperCorner>440037.074773 316375.673571</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440037.074773 316375.673571</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 253 327</ms:GML_ID>
        <ms:NAZWA>014 253 327</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014253327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460300.092000 315539.886000</gml:lowerCorner>
        		<gml:upperCorner>460300.092000 315539.886000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460300.092000 315539.886000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 024 478</ms:GML_ID>
        <ms:NAZWA>359 024 478</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359024478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460691.733000 315255.205000</gml:lowerCorner>
        		<gml:upperCorner>460691.733000 315255.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460691.733000 315255.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 024 966</ms:GML_ID>
        <ms:NAZWA>359 024 966</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359024966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470123.137000 301286.750000</gml:lowerCorner>
        		<gml:upperCorner>470123.137000 301286.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470123.137000 301286.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 006 748</ms:GML_ID>
        <ms:NAZWA>371 006 748</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371006748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470441.650000 301489.447000</gml:lowerCorner>
        		<gml:upperCorner>470441.650000 301489.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470441.650000 301489.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 006 373</ms:GML_ID>
        <ms:NAZWA>371 006 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371006373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470757.216000 301695.041000</gml:lowerCorner>
        		<gml:upperCorner>470757.216000 301695.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470757.216000 301695.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 005 996</ms:GML_ID>
        <ms:NAZWA>371 005 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371005996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471310.169000 302130.845000</gml:lowerCorner>
        		<gml:upperCorner>471310.169000 302130.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471310.169000 302130.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 005 288</ms:GML_ID>
        <ms:NAZWA>371 005 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371005288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471631.186000 302430.600000</gml:lowerCorner>
        		<gml:upperCorner>471631.186000 302430.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471631.186000 302430.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 004 850</ms:GML_ID>
        <ms:NAZWA>371 004 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371004850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472116.187000 302886.066000</gml:lowerCorner>
        		<gml:upperCorner>472116.187000 302886.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472116.187000 302886.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 004 183</ms:GML_ID>
        <ms:NAZWA>371 004 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371004183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472394.030000 303147.176000</gml:lowerCorner>
        		<gml:upperCorner>472394.030000 303147.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472394.030000 303147.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 003 802</ms:GML_ID>
        <ms:NAZWA>371 003 802</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371003802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472759.037000 303464.208000</gml:lowerCorner>
        		<gml:upperCorner>472759.037000 303464.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472759.037000 303464.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 003 318</ms:GML_ID>
        <ms:NAZWA>371 003 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371003318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473000.749226 303749.028037</gml:lowerCorner>
        		<gml:upperCorner>473000.749226 303749.028037</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473000.749226 303749.028037</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 042 907</ms:GML_ID>
        <ms:NAZWA>359 042 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359042907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473684.653000 303385.928000</gml:lowerCorner>
        		<gml:upperCorner>473684.653000 303385.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473684.653000 303385.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 041 354</ms:GML_ID>
        <ms:NAZWA>357 041 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357041354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474379.552748 302858.033389</gml:lowerCorner>
        		<gml:upperCorner>474379.552748 302858.033389</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474379.552748 302858.033389</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 044 551</ms:GML_ID>
        <ms:NAZWA>359 044 551</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359044551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475084.248932 302413.904970</gml:lowerCorner>
        		<gml:upperCorner>475084.248932 302413.904970</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475084.248932 302413.904970</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 045 384</ms:GML_ID>
        <ms:NAZWA>359 045 384</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359045384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475821.429830 301959.424684</gml:lowerCorner>
        		<gml:upperCorner>475821.429830 301959.424684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475821.429830 301959.424684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 046 250</ms:GML_ID>
        <ms:NAZWA>359 046 250</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359046250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476265.738894 301693.639267</gml:lowerCorner>
        		<gml:upperCorner>476265.738894 301693.639267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476265.738894 301693.639267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 046 765</ms:GML_ID>
        <ms:NAZWA>359 046 765</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359046765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477085.686686 300480.325010</gml:lowerCorner>
        		<gml:upperCorner>477085.686686 300480.325010</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477085.686686 300480.325010</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 036 675</ms:GML_ID>
        <ms:NAZWA>357 036 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357036675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477196.149367 299299.494882</gml:lowerCorner>
        		<gml:upperCorner>477196.149367 299299.494882</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477196.149367 299299.494882</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 035 482</ms:GML_ID>
        <ms:NAZWA>357 035 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357035482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477977.079000 300649.209000</gml:lowerCorner>
        		<gml:upperCorner>477977.079000 300649.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477977.079000 300649.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 048 771</ms:GML_ID>
        <ms:NAZWA>359 048 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359048771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478590.406000 300276.136000</gml:lowerCorner>
        		<gml:upperCorner>478590.406000 300276.136000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478590.406000 300276.136000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 049 492</ms:GML_ID>
        <ms:NAZWA>359 049 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359049492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478978.352000 300038.844000</gml:lowerCorner>
        		<gml:upperCorner>478978.352000 300038.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478978.352000 300038.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 049 945</ms:GML_ID>
        <ms:NAZWA>359 049 945</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359049945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479786.161000 299545.352000</gml:lowerCorner>
        		<gml:upperCorner>479786.161000 299545.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479786.161000 299545.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 050 892</ms:GML_ID>
        <ms:NAZWA>359 050 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359050892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480338.513000 299208.216000</gml:lowerCorner>
        		<gml:upperCorner>480338.513000 299208.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480338.513000 299208.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 051 539</ms:GML_ID>
        <ms:NAZWA>359 051 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359051539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492632.903000 289702.364000</gml:lowerCorner>
        		<gml:upperCorner>492632.903000 289702.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492632.903000 289702.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 377 772</ms:GML_ID>
        <ms:NAZWA>003 377 772</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003377772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492568.163000 289724.300000</gml:lowerCorner>
        		<gml:upperCorner>492568.163000 289724.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492568.163000 289724.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 067 282</ms:GML_ID>
        <ms:NAZWA>359 067 282</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359067282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496082.569000 289860.671000</gml:lowerCorner>
        		<gml:upperCorner>496082.569000 289860.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496082.569000 289860.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 038 851</ms:GML_ID>
        <ms:NAZWA>373 038 851</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373038851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496831.305000 290246.217000</gml:lowerCorner>
        		<gml:upperCorner>496831.305000 290246.217000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496831.305000 290246.217000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 037 989</ms:GML_ID>
        <ms:NAZWA>373 037 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373037989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492353.173000 290269.238000</gml:lowerCorner>
        		<gml:upperCorner>492353.173000 290269.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492353.173000 290269.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 066 702</ms:GML_ID>
        <ms:NAZWA>359 066 702</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359066702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492602.444000 290343.483000</gml:lowerCorner>
        		<gml:upperCorner>492602.444000 290343.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492602.444000 290343.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 377 134</ms:GML_ID>
        <ms:NAZWA>003 377 134</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003377134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492084.500000 290694.572000</gml:lowerCorner>
        		<gml:upperCorner>492084.500000 290694.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492084.500000 290694.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 066 195</ms:GML_ID>
        <ms:NAZWA>359 066 195</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359066195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491944.652000 290869.847000</gml:lowerCorner>
        		<gml:upperCorner>491944.652000 290869.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491944.652000 290869.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 065 970</ms:GML_ID>
        <ms:NAZWA>359 065 970</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359065970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491679.788000 291195.686000</gml:lowerCorner>
        		<gml:upperCorner>491679.788000 291195.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491679.788000 291195.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 065 545</ms:GML_ID>
        <ms:NAZWA>359 065 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359065545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491438.235000 291492.711000</gml:lowerCorner>
        		<gml:upperCorner>491438.235000 291492.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491438.235000 291492.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 065 168</ms:GML_ID>
        <ms:NAZWA>359 065 168</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359065168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491013.297000 292015.810000</gml:lowerCorner>
        		<gml:upperCorner>491013.297000 292015.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491013.297000 292015.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 064 496</ms:GML_ID>
        <ms:NAZWA>359 064 496</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359064496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490726.982000 292366.693000</gml:lowerCorner>
        		<gml:upperCorner>490726.982000 292366.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490726.982000 292366.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 064 041</ms:GML_ID>
        <ms:NAZWA>359 064 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359064041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493156.559000 292393.050000</gml:lowerCorner>
        		<gml:upperCorner>493156.559000 292393.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493156.559000 292393.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 374 932</ms:GML_ID>
        <ms:NAZWA>003 374 932</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003374932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489768.363993 293407.708338</gml:lowerCorner>
        		<gml:upperCorner>489768.363993 293407.708338</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489768.363993 293407.708338</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 062 621</ms:GML_ID>
        <ms:NAZWA>359 062 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359062621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489228.139000 293778.187000</gml:lowerCorner>
        		<gml:upperCorner>489228.139000 293778.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489228.139000 293778.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 061 964</ms:GML_ID>
        <ms:NAZWA>359 061 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359061964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494857.754757 294857.901695</gml:lowerCorner>
        		<gml:upperCorner>494857.754757 294857.901695</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494857.754757 294857.901695</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 371 932</ms:GML_ID>
        <ms:NAZWA>003 371 932</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003371932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495777.456856 298148.912594</gml:lowerCorner>
        		<gml:upperCorner>495777.456856 298148.912594</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495777.456856 298148.912594</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 368 514</ms:GML_ID>
        <ms:NAZWA>003 368 514</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003368514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496195.992387 299665.619152</gml:lowerCorner>
        		<gml:upperCorner>496195.992387 299665.619152</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496195.992387 299665.619152</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 366 940</ms:GML_ID>
        <ms:NAZWA>003 366 940</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003366940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496914.114369 305989.463525</gml:lowerCorner>
        		<gml:upperCorner>496914.114369 305989.463525</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496914.114369 305989.463525</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 360 503</ms:GML_ID>
        <ms:NAZWA>003 360 503</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003360503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496796.488000 308023.640000</gml:lowerCorner>
        		<gml:upperCorner>496796.488000 308023.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496796.488000 308023.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 358 453</ms:GML_ID>
        <ms:NAZWA>003 358 453</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003358453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496717.988614 309392.055975</gml:lowerCorner>
        		<gml:upperCorner>496717.988614 309392.055975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496717.988614 309392.055975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 357 090</ms:GML_ID>
        <ms:NAZWA>003 357 090</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003357090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496552.020429 312264.075793</gml:lowerCorner>
        		<gml:upperCorner>496552.020429 312264.075793</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496552.020429 312264.075793</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 354 213</ms:GML_ID>
        <ms:NAZWA>003 354 213</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003354213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496390.032532 315062.819541</gml:lowerCorner>
        		<gml:upperCorner>496390.032532 315062.819541</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496390.032532 315062.819541</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 351 410</ms:GML_ID>
        <ms:NAZWA>003 351 410</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003351410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496330.611718 316059.736987</gml:lowerCorner>
        		<gml:upperCorner>496330.611718 316059.736987</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496330.611718 316059.736987</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 350 413</ms:GML_ID>
        <ms:NAZWA>003 350 413</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003350413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496169.414000 318934.830000</gml:lowerCorner>
        		<gml:upperCorner>496169.414000 318934.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496169.414000 318934.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 347 532</ms:GML_ID>
        <ms:NAZWA>003 347 532</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003347532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421298.014848 287866.259632</gml:lowerCorner>
        		<gml:upperCorner>421298.014848 287866.259632</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421298.014848 287866.259632</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 295 620</ms:GML_ID>
        <ms:NAZWA>014 295 620</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014295620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421442.610000 288964.919000</gml:lowerCorner>
        		<gml:upperCorner>421442.610000 288964.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421442.610000 288964.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 294 505</ms:GML_ID>
        <ms:NAZWA>014 294 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014294505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421630.867000 289537.838000</gml:lowerCorner>
        		<gml:upperCorner>421630.867000 289537.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421630.867000 289537.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 293 894</ms:GML_ID>
        <ms:NAZWA>014 293 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014293894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421958.369779 284464.756588</gml:lowerCorner>
        		<gml:upperCorner>421958.369779 284464.756588</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421958.369779 284464.756588</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 299 090</ms:GML_ID>
        <ms:NAZWA>014 299 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014299090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421967.145763 283630.025539</gml:lowerCorner>
        		<gml:upperCorner>421967.145763 283630.025539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421967.145763 283630.025539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 299 926</ms:GML_ID>
        <ms:NAZWA>014 299 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014299926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421972.763000 278724.653000</gml:lowerCorner>
        		<gml:upperCorner>421972.763000 278724.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421972.763000 278724.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 304 833</ms:GML_ID>
        <ms:NAZWA>014 304 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014304833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421985.890255 281827.775125</gml:lowerCorner>
        		<gml:upperCorner>421985.890255 281827.775125</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421985.890255 281827.775125</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 301 726</ms:GML_ID>
        <ms:NAZWA>014 301 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014301726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422004.643000 279987.116000</gml:lowerCorner>
        		<gml:upperCorner>422004.643000 279987.116000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422004.643000 279987.116000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 303 570</ms:GML_ID>
        <ms:NAZWA>014 303 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014303570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422010.072000 279353.105000</gml:lowerCorner>
        		<gml:upperCorner>422010.072000 279353.105000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422010.072000 279353.105000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 304 202</ms:GML_ID>
        <ms:NAZWA>014 304 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014304202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422054.450000 290804.177000</gml:lowerCorner>
        		<gml:upperCorner>422054.450000 290804.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422054.450000 290804.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 292 562</ms:GML_ID>
        <ms:NAZWA>014 292 562</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014292562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422905.063000 291785.199000</gml:lowerCorner>
        		<gml:upperCorner>422905.063000 291785.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422905.063000 291785.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 291 216</ms:GML_ID>
        <ms:NAZWA>014 291 216</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014291216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423673.523000 291899.175000</gml:lowerCorner>
        		<gml:upperCorner>423673.523000 291899.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423673.523000 291899.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 290 427</ms:GML_ID>
        <ms:NAZWA>014 290 427</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014290427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424306.074000 291685.752000</gml:lowerCorner>
        		<gml:upperCorner>424306.074000 291685.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424306.074000 291685.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 289 752</ms:GML_ID>
        <ms:NAZWA>014 289 752</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014289752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426494.444000 298486.341000</gml:lowerCorner>
        		<gml:upperCorner>426494.444000 298486.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426494.444000 298486.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 280 139</ms:GML_ID>
        <ms:NAZWA>014 280 139</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014280139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426590.010000 291692.295000</gml:lowerCorner>
        		<gml:upperCorner>426590.010000 291692.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426590.010000 291692.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 287 274</ms:GML_ID>
        <ms:NAZWA>014 287 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014287274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426812.293329 294400.163400</gml:lowerCorner>
        		<gml:upperCorner>426812.293329 294400.163400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426812.293329 294400.163400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 102 869</ms:GML_ID>
        <ms:NAZWA>273 102 869</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273102869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426850.974999 297028.902747</gml:lowerCorner>
        		<gml:upperCorner>426850.974999 297028.902747</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426850.974999 297028.902747</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 100 226</ms:GML_ID>
        <ms:NAZWA>273 100 226</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273100226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427273.910000 294646.549000</gml:lowerCorner>
        		<gml:upperCorner>427273.910000 294646.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427273.910000 294646.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 284 071</ms:GML_ID>
        <ms:NAZWA>014 284 071</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014284071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427320.660888 299022.472582</gml:lowerCorner>
        		<gml:upperCorner>427320.660888 299022.472582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427320.660888 299022.472582</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 279 044</ms:GML_ID>
        <ms:NAZWA>014 279 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014279044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427325.965000 293071.142000</gml:lowerCorner>
        		<gml:upperCorner>427325.965000 293071.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427325.965000 293071.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 285 667</ms:GML_ID>
        <ms:NAZWA>014 285 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014285667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427863.809000 298882.291000</gml:lowerCorner>
        		<gml:upperCorner>427863.809000 298882.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427863.809000 298882.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 278 455</ms:GML_ID>
        <ms:NAZWA>014 278 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014278455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397570.183670 274027.462592</gml:lowerCorner>
        		<gml:upperCorner>397570.183670 274027.462592</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397570.183670 274027.462592</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 101 200</ms:GML_ID>
        <ms:NAZWA>275 101 200</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275101200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397196.503000 274683.266000</gml:lowerCorner>
        		<gml:upperCorner>397196.503000 274683.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397196.503000 274683.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 100 443</ms:GML_ID>
        <ms:NAZWA>275 100 443</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275100443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395736.749000 277114.914000</gml:lowerCorner>
        		<gml:upperCorner>395736.749000 277114.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395736.749000 277114.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 097 602</ms:GML_ID>
        <ms:NAZWA>275 097 602</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275097602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395302.285239 277612.929729</gml:lowerCorner>
        		<gml:upperCorner>395302.285239 277612.929729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395302.285239 277612.929729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 096 940</ms:GML_ID>
        <ms:NAZWA>275 096 940</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275096940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394631.282815 278395.974163</gml:lowerCorner>
        		<gml:upperCorner>394631.282815 278395.974163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394631.282815 278395.974163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 095 908</ms:GML_ID>
        <ms:NAZWA>275 095 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275095908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393938.280000 279149.697000</gml:lowerCorner>
        		<gml:upperCorner>393938.280000 279149.697000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393938.280000 279149.697000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 094 885</ms:GML_ID>
        <ms:NAZWA>275 094 885</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275094885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392074.138000 282710.559000</gml:lowerCorner>
        		<gml:upperCorner>392074.138000 282710.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392074.138000 282710.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.303 002 599</ms:GML_ID>
        <ms:NAZWA>303 002 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>303002599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392716.374000 282887.797000</gml:lowerCorner>
        		<gml:upperCorner>392716.374000 282887.797000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392716.374000 282887.797000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.303 003 267</ms:GML_ID>
        <ms:NAZWA>303 003 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>303003267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390119.709931 283529.988100</gml:lowerCorner>
        		<gml:upperCorner>390119.709931 283529.988100</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390119.709931 283529.988100</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 089 068</ms:GML_ID>
        <ms:NAZWA>275 089 068</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275089068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395576.836899 283935.128442</gml:lowerCorner>
        		<gml:upperCorner>395576.836899 283935.128442</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395576.836899 283935.128442</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.303 006 386</ms:GML_ID>
        <ms:NAZWA>303 006 386</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>303006386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389392.526078 284389.021761</gml:lowerCorner>
        		<gml:upperCorner>389392.526078 284389.021761</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389392.526078 284389.021761</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 087 940</ms:GML_ID>
        <ms:NAZWA>275 087 940</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275087940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391511.394000 303795.167000</gml:lowerCorner>
        		<gml:upperCorner>391511.394000 303795.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391511.394000 303795.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 017 694</ms:GML_ID>
        <ms:NAZWA>289 017 694</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289017694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393792.167744 304606.341128</gml:lowerCorner>
        		<gml:upperCorner>393792.167744 304606.341128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393792.167744 304606.341128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 020 144</ms:GML_ID>
        <ms:NAZWA>289 020 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289020144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395470.906113 304724.963962</gml:lowerCorner>
        		<gml:upperCorner>395470.906113 304724.963962</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395470.906113 304724.963962</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 021 844</ms:GML_ID>
        <ms:NAZWA>289 021 844</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289021844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396173.953589 304910.490353</gml:lowerCorner>
        		<gml:upperCorner>396173.953589 304910.490353</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396173.953589 304910.490353</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 022 570</ms:GML_ID>
        <ms:NAZWA>289 022 570</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289022570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397166.605928 305243.477178</gml:lowerCorner>
        		<gml:upperCorner>397166.605928 305243.477178</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397166.605928 305243.477178</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 023 615</ms:GML_ID>
        <ms:NAZWA>289 023 615</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289023615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399670.625641 306207.852301</gml:lowerCorner>
        		<gml:upperCorner>399670.625641 306207.852301</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399670.625641 306207.852301</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 026 308</ms:GML_ID>
        <ms:NAZWA>289 026 308</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289026308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429411.495000 287171.674000</gml:lowerCorner>
        		<gml:upperCorner>429411.495000 287171.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429411.495000 287171.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 110 747</ms:GML_ID>
        <ms:NAZWA>273 110 747</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273110747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429702.546000 286704.089000</gml:lowerCorner>
        		<gml:upperCorner>429702.546000 286704.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429702.546000 286704.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 111 308</ms:GML_ID>
        <ms:NAZWA>273 111 308</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273111308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430052.431000 298071.820000</gml:lowerCorner>
        		<gml:upperCorner>430052.431000 298071.820000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430052.431000 298071.820000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 275 966</ms:GML_ID>
        <ms:NAZWA>014 275 966</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014275966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430662.247000 298139.915000</gml:lowerCorner>
        		<gml:upperCorner>430662.247000 298139.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430662.247000 298139.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 275 348</ms:GML_ID>
        <ms:NAZWA>014 275 348</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014275348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430747.140277 284916.813699</gml:lowerCorner>
        		<gml:upperCorner>430747.140277 284916.813699</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430747.140277 284916.813699</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 113 393</ms:GML_ID>
        <ms:NAZWA>273 113 393</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273113393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432017.040540 282688.350049</gml:lowerCorner>
        		<gml:upperCorner>432017.040540 282688.350049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432017.040540 282688.350049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 116 002</ms:GML_ID>
        <ms:NAZWA>273 116 002</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273116002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432549.677744 282194.521977</gml:lowerCorner>
        		<gml:upperCorner>432549.677744 282194.521977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432549.677744 282194.521977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 116 729</ms:GML_ID>
        <ms:NAZWA>273 116 729</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273116729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432965.684166 281703.642175</gml:lowerCorner>
        		<gml:upperCorner>432965.684166 281703.642175</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432965.684166 281703.642175</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 117 374</ms:GML_ID>
        <ms:NAZWA>273 117 374</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273117374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433508.622495 280917.155990</gml:lowerCorner>
        		<gml:upperCorner>433508.622495 280917.155990</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433508.622495 280917.155990</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 118 334</ms:GML_ID>
        <ms:NAZWA>273 118 334</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273118334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433567.880545 280760.792446</gml:lowerCorner>
        		<gml:upperCorner>433567.880545 280760.792446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433567.880545 280760.792446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 118 500</ms:GML_ID>
        <ms:NAZWA>273 118 500</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273118500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433895.970189 280042.794531</gml:lowerCorner>
        		<gml:upperCorner>433895.970189 280042.794531</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433895.970189 280042.794531</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 119 290</ms:GML_ID>
        <ms:NAZWA>273 119 290</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273119290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434483.220000 278263.998000</gml:lowerCorner>
        		<gml:upperCorner>434483.220000 278263.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434483.220000 278263.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 121 190</ms:GML_ID>
        <ms:NAZWA>273 121 190</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273121190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434659.095017 277973.095741</gml:lowerCorner>
        		<gml:upperCorner>434659.095017 277973.095741</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434659.095017 277973.095741</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 121 538</ms:GML_ID>
        <ms:NAZWA>273 121 538</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273121538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436981.603751 275759.274256</gml:lowerCorner>
        		<gml:upperCorner>436981.603751 275759.274256</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436981.603751 275759.274256</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 124 743</ms:GML_ID>
        <ms:NAZWA>273 124 743</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273124743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>437354.718421 275408.893235</gml:lowerCorner>
        		<gml:upperCorner>437354.718421 275408.893235</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>437354.718421 275408.893235</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 125 254</ms:GML_ID>
        <ms:NAZWA>273 125 254</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273125254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438415.747000 274411.266000</gml:lowerCorner>
        		<gml:upperCorner>438415.747000 274411.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438415.747000 274411.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 126 708</ms:GML_ID>
        <ms:NAZWA>273 126 708</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273126708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439254.165428 273966.364887</gml:lowerCorner>
        		<gml:upperCorner>439254.165428 273966.364887</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439254.165428 273966.364887</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 127 678</ms:GML_ID>
        <ms:NAZWA>273 127 678</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273127678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475188.989056 268642.698261</gml:lowerCorner>
        		<gml:upperCorner>475188.989056 268642.698261</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475188.989056 268642.698261</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 026 121</ms:GML_ID>
        <ms:NAZWA>358 026 121</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358026121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475268.758000 268753.626000</gml:lowerCorner>
        		<gml:upperCorner>475268.758000 268753.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475268.758000 268753.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 025 985</ms:GML_ID>
        <ms:NAZWA>358 025 985</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358025985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475622.618994 269117.314972</gml:lowerCorner>
        		<gml:upperCorner>475622.618994 269117.314972</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475622.618994 269117.314972</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 025 475</ms:GML_ID>
        <ms:NAZWA>358 025 475</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358025475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476492.234103 269801.599903</gml:lowerCorner>
        		<gml:upperCorner>476492.234103 269801.599903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476492.234103 269801.599903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 024 369</ms:GML_ID>
        <ms:NAZWA>358 024 369</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358024369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477147.138000 270311.907000</gml:lowerCorner>
        		<gml:upperCorner>477147.138000 270311.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477147.138000 270311.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 023 539</ms:GML_ID>
        <ms:NAZWA>358 023 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358023539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479260.428858 272597.322586</gml:lowerCorner>
        		<gml:upperCorner>479260.428858 272597.322586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479260.428858 272597.322586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 020 324</ms:GML_ID>
        <ms:NAZWA>358 020 324</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358020324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479295.773000 273002.763000</gml:lowerCorner>
        		<gml:upperCorner>479295.773000 273002.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479295.773000 273002.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 019 916</ms:GML_ID>
        <ms:NAZWA>358 019 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358019916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479337.737000 273470.578000</gml:lowerCorner>
        		<gml:upperCorner>479337.737000 273470.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479337.737000 273470.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 019 445</ms:GML_ID>
        <ms:NAZWA>358 019 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358019445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479426.763000 274469.476000</gml:lowerCorner>
        		<gml:upperCorner>479426.763000 274469.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479426.763000 274469.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 018 443</ms:GML_ID>
        <ms:NAZWA>358 018 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358018443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480254.638000 276616.195000</gml:lowerCorner>
        		<gml:upperCorner>480254.638000 276616.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480254.638000 276616.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 016 065</ms:GML_ID>
        <ms:NAZWA>358 016 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358016065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481219.703000 277790.714000</gml:lowerCorner>
        		<gml:upperCorner>481219.703000 277790.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481219.703000 277790.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 014 545</ms:GML_ID>
        <ms:NAZWA>358 014 545</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358014545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481631.090665 278577.652098</gml:lowerCorner>
        		<gml:upperCorner>481631.090665 278577.652098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481631.090665 278577.652098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 013 635</ms:GML_ID>
        <ms:NAZWA>358 013 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358013635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481564.801853 279172.322785</gml:lowerCorner>
        		<gml:upperCorner>481564.801853 279172.322785</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481564.801853 279172.322785</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 013 046</ms:GML_ID>
        <ms:NAZWA>358 013 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358013046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481501.620000 279611.410000</gml:lowerCorner>
        		<gml:upperCorner>481501.620000 279611.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481501.620000 279611.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 012 598</ms:GML_ID>
        <ms:NAZWA>358 012 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358012598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481382.546000 280440.867000</gml:lowerCorner>
        		<gml:upperCorner>481382.546000 280440.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481382.546000 280440.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 011 753</ms:GML_ID>
        <ms:NAZWA>358 011 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358011753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481722.541000 281569.136000</gml:lowerCorner>
        		<gml:upperCorner>481722.541000 281569.136000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481722.541000 281569.136000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 010 543</ms:GML_ID>
        <ms:NAZWA>358 010 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358010543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482450.498926 282081.069730</gml:lowerCorner>
        		<gml:upperCorner>482450.498926 282081.069730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482450.498926 282081.069730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 009 645</ms:GML_ID>
        <ms:NAZWA>358 009 645</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358009645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483339.018000 282543.461000</gml:lowerCorner>
        		<gml:upperCorner>483339.018000 282543.461000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483339.018000 282543.461000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 008 642</ms:GML_ID>
        <ms:NAZWA>358 008 642</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358008642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485019.983000 283325.331000</gml:lowerCorner>
        		<gml:upperCorner>485019.983000 283325.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485019.983000 283325.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 006 779</ms:GML_ID>
        <ms:NAZWA>358 006 779</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358006779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488089.156000 294471.626000</gml:lowerCorner>
        		<gml:upperCorner>488089.156000 294471.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488089.156000 294471.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 060 630</ms:GML_ID>
        <ms:NAZWA>359 060 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359060630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487100.986000 295075.922000</gml:lowerCorner>
        		<gml:upperCorner>487100.986000 295075.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487100.986000 295075.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 059 472</ms:GML_ID>
        <ms:NAZWA>359 059 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359059472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486261.560873 295588.043687</gml:lowerCorner>
        		<gml:upperCorner>486261.560873 295588.043687</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486261.560873 295588.043687</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 058 489</ms:GML_ID>
        <ms:NAZWA>359 058 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359058489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485695.416000 295934.249000</gml:lowerCorner>
        		<gml:upperCorner>485695.416000 295934.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485695.416000 295934.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 057 825</ms:GML_ID>
        <ms:NAZWA>359 057 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359057825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485110.249000 296292.527000</gml:lowerCorner>
        		<gml:upperCorner>485110.249000 296292.527000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485110.249000 296292.527000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 057 136</ms:GML_ID>
        <ms:NAZWA>359 057 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359057136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484361.683000 296685.721000</gml:lowerCorner>
        		<gml:upperCorner>484361.683000 296685.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484361.683000 296685.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 056 292</ms:GML_ID>
        <ms:NAZWA>359 056 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359056292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484057.407000 296854.387000</gml:lowerCorner>
        		<gml:upperCorner>484057.407000 296854.387000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484057.407000 296854.387000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 055 944</ms:GML_ID>
        <ms:NAZWA>359 055 944</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359055944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483918.358000 296954.629000</gml:lowerCorner>
        		<gml:upperCorner>483918.358000 296954.629000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483918.358000 296954.629000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 055 773</ms:GML_ID>
        <ms:NAZWA>359 055 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359055773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483114.020841 297512.045150</gml:lowerCorner>
        		<gml:upperCorner>483114.020841 297512.045150</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483114.020841 297512.045150</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 054 793</ms:GML_ID>
        <ms:NAZWA>359 054 793</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359054793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482646.958496 297797.046195</gml:lowerCorner>
        		<gml:upperCorner>482646.958496 297797.046195</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482646.958496 297797.046195</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 054 244</ms:GML_ID>
        <ms:NAZWA>359 054 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359054244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482143.899799 298104.080326</gml:lowerCorner>
        		<gml:upperCorner>482143.899799 298104.080326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482143.899799 298104.080326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 053 656</ms:GML_ID>
        <ms:NAZWA>359 053 656</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359053656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477114.269506 298311.272266</gml:lowerCorner>
        		<gml:upperCorner>477114.269506 298311.272266</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477114.269506 298311.272266</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 034 487</ms:GML_ID>
        <ms:NAZWA>357 034 487</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357034487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440064.562000 273768.020345</gml:lowerCorner>
        		<gml:upperCorner>440064.562000 273768.020345</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440064.562000 273768.020345</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 128 515</ms:GML_ID>
        <ms:NAZWA>273 128 515</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273128515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440587.105106 273640.179955</gml:lowerCorner>
        		<gml:upperCorner>440587.105106 273640.179955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440587.105106 273640.179955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 129 052</ms:GML_ID>
        <ms:NAZWA>273 129 052</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273129052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441482.698126 273334.434857</gml:lowerCorner>
        		<gml:upperCorner>441482.698126 273334.434857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441482.698126 273334.434857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 130 001</ms:GML_ID>
        <ms:NAZWA>273 130 001</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273130001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442322.190481 273052.659076</gml:lowerCorner>
        		<gml:upperCorner>442322.190481 273052.659076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442322.190481 273052.659076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 130 886</ms:GML_ID>
        <ms:NAZWA>273 130 886</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273130886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442713.430976 272921.932955</gml:lowerCorner>
        		<gml:upperCorner>442713.430976 272921.932955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442713.430976 272921.932955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 131 320</ms:GML_ID>
        <ms:NAZWA>273 131 320</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273131320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443831.225000 272516.902000</gml:lowerCorner>
        		<gml:upperCorner>443831.225000 272516.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443831.225000 272516.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 132 485</ms:GML_ID>
        <ms:NAZWA>273 132 485</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273132485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446371.342353 271596.724847</gml:lowerCorner>
        		<gml:upperCorner>446371.342353 271596.724847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446371.342353 271596.724847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 135 188</ms:GML_ID>
        <ms:NAZWA>273 135 188</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273135188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449722.502431 270368.239736</gml:lowerCorner>
        		<gml:upperCorner>449722.502431 270368.239736</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449722.502431 270368.239736</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 138 762</ms:GML_ID>
        <ms:NAZWA>273 138 762</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273138762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463291.327000 295195.373000</gml:lowerCorner>
        		<gml:upperCorner>463291.327000 295195.373000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463291.327000 295195.373000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 016 291</ms:GML_ID>
        <ms:NAZWA>371 016 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371016291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464156.451446 297029.119339</gml:lowerCorner>
        		<gml:upperCorner>464156.451446 297029.119339</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464156.451446 297029.119339</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 014 218</ms:GML_ID>
        <ms:NAZWA>371 014 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371014218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464348.489025 297120.421730</gml:lowerCorner>
        		<gml:upperCorner>464348.489025 297120.421730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464348.489025 297120.421730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 014 006</ms:GML_ID>
        <ms:NAZWA>371 014 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371014006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465675.137000 297636.641000</gml:lowerCorner>
        		<gml:upperCorner>465675.137000 297636.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465675.137000 297636.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 012 583</ms:GML_ID>
        <ms:NAZWA>371 012 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371012583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466496.611000 298011.942000</gml:lowerCorner>
        		<gml:upperCorner>466496.611000 298011.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466496.611000 298011.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 011 674</ms:GML_ID>
        <ms:NAZWA>371 011 674</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371011674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469892.925000 266628.347000</gml:lowerCorner>
        		<gml:upperCorner>469892.925000 266628.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469892.925000 266628.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.393 000 640</ms:GML_ID>
        <ms:NAZWA>393 000 640</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>393000640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472409.672000 266747.621000</gml:lowerCorner>
        		<gml:upperCorner>472409.672000 266747.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472409.672000 266747.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.379 029 604</ms:GML_ID>
        <ms:NAZWA>379 029 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>379029604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473078.376000 266593.398000</gml:lowerCorner>
        		<gml:upperCorner>473078.376000 266593.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473078.376000 266593.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.379 030 290</ms:GML_ID>
        <ms:NAZWA>379 030 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>379030290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473457.847000 266702.009000</gml:lowerCorner>
        		<gml:upperCorner>473457.847000 266702.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473457.847000 266702.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 028 722</ms:GML_ID>
        <ms:NAZWA>358 028 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358028722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473580.622000 266881.065000</gml:lowerCorner>
        		<gml:upperCorner>473580.622000 266881.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473580.622000 266881.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.379 030 906</ms:GML_ID>
        <ms:NAZWA>379 030 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>379030906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417264.836000 259100.543000</gml:lowerCorner>
        		<gml:upperCorner>417264.836000 259100.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417264.836000 259100.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 325 394</ms:GML_ID>
        <ms:NAZWA>014 325 394</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014325394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417173.037000 259423.167000</gml:lowerCorner>
        		<gml:upperCorner>417173.037000 259423.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417173.037000 259423.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 325 059</ms:GML_ID>
        <ms:NAZWA>014 325 059</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014325059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417111.836000 259744.018000</gml:lowerCorner>
        		<gml:upperCorner>417111.836000 259744.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417111.836000 259744.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 324 731</ms:GML_ID>
        <ms:NAZWA>014 324 731</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014324731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417085.290000 259914.864000</gml:lowerCorner>
        		<gml:upperCorner>417085.290000 259914.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417085.290000 259914.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 324 557</ms:GML_ID>
        <ms:NAZWA>014 324 557</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014324557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417152.236967 260638.107960</gml:lowerCorner>
        		<gml:upperCorner>417152.236967 260638.107960</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417152.236967 260638.107960</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 323 818</ms:GML_ID>
        <ms:NAZWA>014 323 818</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014323818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417273.791508 260908.870336</gml:lowerCorner>
        		<gml:upperCorner>417273.791508 260908.870336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417273.791508 260908.870336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 323 538</ms:GML_ID>
        <ms:NAZWA>014 323 538</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014323538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417375.282356 261018.511182</gml:lowerCorner>
        		<gml:upperCorner>417375.282356 261018.511182</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417375.282356 261018.511182</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 323 389</ms:GML_ID>
        <ms:NAZWA>014 323 389</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014323389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418192.531000 263089.047000</gml:lowerCorner>
        		<gml:upperCorner>418192.531000 263089.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418192.531000 263089.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 321 076</ms:GML_ID>
        <ms:NAZWA>014 321 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014321076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418261.446000 263683.900000</gml:lowerCorner>
        		<gml:upperCorner>418261.446000 263683.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418261.446000 263683.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 320 475</ms:GML_ID>
        <ms:NAZWA>014 320 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014320475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418327.707000 264252.404000</gml:lowerCorner>
        		<gml:upperCorner>418327.707000 264252.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418327.707000 264252.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 319 903</ms:GML_ID>
        <ms:NAZWA>014 319 903</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014319903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418475.693297 265525.346869</gml:lowerCorner>
        		<gml:upperCorner>418475.693297 265525.346869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418475.693297 265525.346869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 318 621</ms:GML_ID>
        <ms:NAZWA>014 318 621</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014318621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419745.267000 269319.290000</gml:lowerCorner>
        		<gml:upperCorner>419745.267000 269319.290000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419745.267000 269319.290000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 314 542</ms:GML_ID>
        <ms:NAZWA>014 314 542</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014314542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419751.661150 270603.793507</gml:lowerCorner>
        		<gml:upperCorner>419751.661150 270603.793507</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419751.661150 270603.793507</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 313 255</ms:GML_ID>
        <ms:NAZWA>014 313 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014313255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419875.314384 271154.518183</gml:lowerCorner>
        		<gml:upperCorner>419875.314384 271154.518183</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419875.314384 271154.518183</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 312 690</ms:GML_ID>
        <ms:NAZWA>014 312 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014312690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420110.070291 272012.353168</gml:lowerCorner>
        		<gml:upperCorner>420110.070291 272012.353168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420110.070291 272012.353168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 311 799</ms:GML_ID>
        <ms:NAZWA>014 311 799</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014311799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420795.438000 274463.689000</gml:lowerCorner>
        		<gml:upperCorner>420795.438000 274463.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420795.438000 274463.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 309 254</ms:GML_ID>
        <ms:NAZWA>014 309 254</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014309254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420957.966000 275050.006000</gml:lowerCorner>
        		<gml:upperCorner>420957.966000 275050.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420957.966000 275050.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 308 645</ms:GML_ID>
        <ms:NAZWA>014 308 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014308645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421295.688000 276264.102000</gml:lowerCorner>
        		<gml:upperCorner>421295.688000 276264.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421295.688000 276264.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 307 382</ms:GML_ID>
        <ms:NAZWA>014 307 382</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014307382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421572.330457 277236.296260</gml:lowerCorner>
        		<gml:upperCorner>421572.330457 277236.296260</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421572.330457 277236.296260</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 306 379</ms:GML_ID>
        <ms:NAZWA>014 306 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014306379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458327.899000 255242.792000</gml:lowerCorner>
        		<gml:upperCorner>458327.899000 255242.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458327.899000 255242.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 005 575</ms:GML_ID>
        <ms:NAZWA>370 005 575</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370005575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458492.901385 263942.149005</gml:lowerCorner>
        		<gml:upperCorner>458492.901385 263942.149005</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458492.901385 263942.149005</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 150 345</ms:GML_ID>
        <ms:NAZWA>273 150 345</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273150345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458795.277000 256307.877000</gml:lowerCorner>
        		<gml:upperCorner>458795.277000 256307.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458795.277000 256307.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 004 410</ms:GML_ID>
        <ms:NAZWA>370 004 410</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370004410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459051.118452 256948.182291</gml:lowerCorner>
        		<gml:upperCorner>459051.118452 256948.182291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459051.118452 256948.182291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 003 719</ms:GML_ID>
        <ms:NAZWA>370 003 719</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370003719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459062.136000 261825.327000</gml:lowerCorner>
        		<gml:upperCorner>459062.136000 261825.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459062.136000 261825.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 152 536</ms:GML_ID>
        <ms:NAZWA>273 152 536</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273152536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459212.943000 261173.233000</gml:lowerCorner>
        		<gml:upperCorner>459212.943000 261173.233000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459212.943000 261173.233000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 153 208</ms:GML_ID>
        <ms:NAZWA>273 153 208</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273153208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460555.048423 256268.356388</gml:lowerCorner>
        		<gml:upperCorner>460555.048423 256268.356388</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460555.048423 256268.356388</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 158 431</ms:GML_ID>
        <ms:NAZWA>273 158 431</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273158431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461375.484700 255579.397777</gml:lowerCorner>
        		<gml:upperCorner>461375.484700 255579.397777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461375.484700 255579.397777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 159 511</ms:GML_ID>
        <ms:NAZWA>273 159 511</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273159511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462094.411863 255344.667590</gml:lowerCorner>
        		<gml:upperCorner>462094.411863 255344.667590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462094.411863 255344.667590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 160 279</ms:GML_ID>
        <ms:NAZWA>273 160 279</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273160279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462730.799929 255484.026194</gml:lowerCorner>
        		<gml:upperCorner>462730.799929 255484.026194</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462730.799929 255484.026194</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 160 933</ms:GML_ID>
        <ms:NAZWA>273 160 933</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273160933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466773.786939 255727.069356</gml:lowerCorner>
        		<gml:upperCorner>466773.786939 255727.069356</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466773.786939 255727.069356</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.436 001 069</ms:GML_ID>
        <ms:NAZWA>436 001 069</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>436001069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466950.049000 254623.811000</gml:lowerCorner>
        		<gml:upperCorner>466950.049000 254623.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466950.049000 254623.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 043 075</ms:GML_ID>
        <ms:NAZWA>358 043 075</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358043075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466954.405522 254324.300036</gml:lowerCorner>
        		<gml:upperCorner>466954.405522 254324.300036</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466954.405522 254324.300036</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 043 375</ms:GML_ID>
        <ms:NAZWA>358 043 375</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358043375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466956.312000 254814.175000</gml:lowerCorner>
        		<gml:upperCorner>466956.312000 254814.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466956.312000 254814.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 042 887</ms:GML_ID>
        <ms:NAZWA>358 042 887</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358042887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466974.820000 255396.181000</gml:lowerCorner>
        		<gml:upperCorner>466974.820000 255396.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466974.820000 255396.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 042 303</ms:GML_ID>
        <ms:NAZWA>358 042 303</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358042303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467056.468012 254285.709661</gml:lowerCorner>
        		<gml:upperCorner>467056.468012 254285.709661</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467056.468012 254285.709661</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 166 143</ms:GML_ID>
        <ms:NAZWA>273 166 143</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273166143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467405.147000 256888.297000</gml:lowerCorner>
        		<gml:upperCorner>467405.147000 256888.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467405.147000 256888.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 040 741</ms:GML_ID>
        <ms:NAZWA>358 040 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358040741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467535.389000 257216.383000</gml:lowerCorner>
        		<gml:upperCorner>467535.389000 257216.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467535.389000 257216.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 040 387</ms:GML_ID>
        <ms:NAZWA>358 040 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358040387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387335.594000 250300.403000</gml:lowerCorner>
        		<gml:upperCorner>387335.594000 250300.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387335.594000 250300.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 067 666</ms:GML_ID>
        <ms:NAZWA>283 067 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283067666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387573.050000 250202.348000</gml:lowerCorner>
        		<gml:upperCorner>387573.050000 250202.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387573.050000 250202.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 067 925</ms:GML_ID>
        <ms:NAZWA>283 067 925</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283067925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388022.570000 250052.224000</gml:lowerCorner>
        		<gml:upperCorner>388022.570000 250052.224000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388022.570000 250052.224000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 068 398</ms:GML_ID>
        <ms:NAZWA>283 068 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283068398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388675.654000 250136.965000</gml:lowerCorner>
        		<gml:upperCorner>388675.654000 250136.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388675.654000 250136.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 069 088</ms:GML_ID>
        <ms:NAZWA>283 069 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283069088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389971.077000 250510.036000</gml:lowerCorner>
        		<gml:upperCorner>389971.077000 250510.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389971.077000 250510.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 070 452</ms:GML_ID>
        <ms:NAZWA>283 070 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283070452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390430.406998 250564.731954</gml:lowerCorner>
        		<gml:upperCorner>390430.406998 250564.731954</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390430.406998 250564.731954</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 070 915</ms:GML_ID>
        <ms:NAZWA>283 070 915</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283070915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391315.842000 250728.709000</gml:lowerCorner>
        		<gml:upperCorner>391315.842000 250728.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391315.842000 250728.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 071 816</ms:GML_ID>
        <ms:NAZWA>283 071 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283071816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392000.739000 250740.253000</gml:lowerCorner>
        		<gml:upperCorner>392000.739000 250740.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392000.739000 250740.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 072 505</ms:GML_ID>
        <ms:NAZWA>283 072 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283072505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393297.387000 250274.596000</gml:lowerCorner>
        		<gml:upperCorner>393297.387000 250274.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393297.387000 250274.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 073 892</ms:GML_ID>
        <ms:NAZWA>283 073 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283073892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393696.408000 250234.044000</gml:lowerCorner>
        		<gml:upperCorner>393696.408000 250234.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393696.408000 250234.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 074 293</ms:GML_ID>
        <ms:NAZWA>283 074 293</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283074293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412665.634000 256445.950000</gml:lowerCorner>
        		<gml:upperCorner>412665.634000 256445.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412665.634000 256445.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 124 583</ms:GML_ID>
        <ms:NAZWA>275 124 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275124583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413686.334000 255370.705000</gml:lowerCorner>
        		<gml:upperCorner>413686.334000 255370.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413686.334000 255370.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 126 064</ms:GML_ID>
        <ms:NAZWA>275 126 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275126064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414637.027144 254362.850994</gml:lowerCorner>
        		<gml:upperCorner>414637.027144 254362.850994</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414637.027144 254362.850994</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 127 448</ms:GML_ID>
        <ms:NAZWA>275 127 448</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275127448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415320.413861 253635.136189</gml:lowerCorner>
        		<gml:upperCorner>415320.413861 253635.136189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415320.413861 253635.136189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 128 448</ms:GML_ID>
        <ms:NAZWA>275 128 448</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275128448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415596.474000 253274.756000</gml:lowerCorner>
        		<gml:upperCorner>415596.474000 253274.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415596.474000 253274.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 128 901</ms:GML_ID>
        <ms:NAZWA>275 128 901</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275128901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415930.048000 252816.086000</gml:lowerCorner>
        		<gml:upperCorner>415930.048000 252816.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415930.048000 252816.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 129 468</ms:GML_ID>
        <ms:NAZWA>275 129 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275129468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417089.800000 251150.491000</gml:lowerCorner>
        		<gml:upperCorner>417089.800000 251150.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417089.800000 251150.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 131 499</ms:GML_ID>
        <ms:NAZWA>275 131 499</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275131499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417180.015000 250951.027000</gml:lowerCorner>
        		<gml:upperCorner>417180.015000 250951.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417180.015000 250951.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 131 718</ms:GML_ID>
        <ms:NAZWA>275 131 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275131718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432568.343000 239277.794000</gml:lowerCorner>
        		<gml:upperCorner>432568.343000 239277.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432568.343000 239277.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 151 803</ms:GML_ID>
        <ms:NAZWA>275 151 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275151803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442656.402604 239486.340081</gml:lowerCorner>
        		<gml:upperCorner>442656.402604 239486.340081</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442656.402604 239486.340081</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 030 575</ms:GML_ID>
        <ms:NAZWA>370 030 575</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370030575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443610.067219 240011.033700</gml:lowerCorner>
        		<gml:upperCorner>443610.067219 240011.033700</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443610.067219 240011.033700</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 029 479</ms:GML_ID>
        <ms:NAZWA>370 029 479</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370029479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448388.295000 242894.709000</gml:lowerCorner>
        		<gml:upperCorner>448388.295000 242894.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448388.295000 242894.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 023 846</ms:GML_ID>
        <ms:NAZWA>370 023 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370023846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448939.296000 243336.868000</gml:lowerCorner>
        		<gml:upperCorner>448939.296000 243336.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448939.296000 243336.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 023 139</ms:GML_ID>
        <ms:NAZWA>370 023 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370023139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451479.698000 246657.242000</gml:lowerCorner>
        		<gml:upperCorner>451479.698000 246657.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451479.698000 246657.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 018 819</ms:GML_ID>
        <ms:NAZWA>370 018 819</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370018819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451989.687000 246951.463000</gml:lowerCorner>
        		<gml:upperCorner>451989.687000 246951.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451989.687000 246951.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 018 230</ms:GML_ID>
        <ms:NAZWA>370 018 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370018230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452832.870000 247268.613000</gml:lowerCorner>
        		<gml:upperCorner>452832.870000 247268.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452832.870000 247268.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 017 301</ms:GML_ID>
        <ms:NAZWA>370 017 301</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370017301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453376.588000 246873.171000</gml:lowerCorner>
        		<gml:upperCorner>453376.588000 246873.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453376.588000 246873.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 016 623</ms:GML_ID>
        <ms:NAZWA>370 016 623</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370016623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454472.452000 246691.898000</gml:lowerCorner>
        		<gml:upperCorner>454472.452000 246691.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454472.452000 246691.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 015 435</ms:GML_ID>
        <ms:NAZWA>370 015 435</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370015435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455012.712000 246822.656000</gml:lowerCorner>
        		<gml:upperCorner>455012.712000 246822.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455012.712000 246822.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 014 880</ms:GML_ID>
        <ms:NAZWA>370 014 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370014880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455611.641000 247468.940000</gml:lowerCorner>
        		<gml:upperCorner>455611.641000 247468.940000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455611.641000 247468.940000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 013 977</ms:GML_ID>
        <ms:NAZWA>370 013 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370013977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456128.552000 248495.942000</gml:lowerCorner>
        		<gml:upperCorner>456128.552000 248495.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456128.552000 248495.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 012 818</ms:GML_ID>
        <ms:NAZWA>370 012 818</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370012818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456250.911000 249769.968000</gml:lowerCorner>
        		<gml:upperCorner>456250.911000 249769.968000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456250.911000 249769.968000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 011 532</ms:GML_ID>
        <ms:NAZWA>370 011 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370011532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457563.325000 251930.454000</gml:lowerCorner>
        		<gml:upperCorner>457563.325000 251930.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457563.325000 251930.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 008 994</ms:GML_ID>
        <ms:NAZWA>370 008 994</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370008994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457607.503000 252031.334000</gml:lowerCorner>
        		<gml:upperCorner>457607.503000 252031.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457607.503000 252031.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 008 884</ms:GML_ID>
        <ms:NAZWA>370 008 884</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370008884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457750.379000 252690.851000</gml:lowerCorner>
        		<gml:upperCorner>457750.379000 252690.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457750.379000 252690.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 008 208</ms:GML_ID>
        <ms:NAZWA>370 008 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370008208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458164.600689 265119.048266</gml:lowerCorner>
        		<gml:upperCorner>458164.600689 265119.048266</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458164.600689 265119.048266</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 149 123</ms:GML_ID>
        <ms:NAZWA>273 149 123</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273149123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478838.439943 239173.140342</gml:lowerCorner>
        		<gml:upperCorner>478838.439943 239173.140342</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478838.439943 239173.140342</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 186 045</ms:GML_ID>
        <ms:NAZWA>273 186 045</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273186045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470533.211000 240068.585000</gml:lowerCorner>
        		<gml:upperCorner>470533.211000 240068.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470533.211000 240068.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 058 259</ms:GML_ID>
        <ms:NAZWA>358 058 259</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358058259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477728.084141 240619.130337</gml:lowerCorner>
        		<gml:upperCorner>477728.084141 240619.130337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477728.084141 240619.130337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 184 224</ms:GML_ID>
        <ms:NAZWA>273 184 224</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273184224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470464.178000 240626.695000</gml:lowerCorner>
        		<gml:upperCorner>470464.178000 240626.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470464.178000 240626.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 057 698</ms:GML_ID>
        <ms:NAZWA>358 057 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358057698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470396.036000 241745.949000</gml:lowerCorner>
        		<gml:upperCorner>470396.036000 241745.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470396.036000 241745.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 056 577</ms:GML_ID>
        <ms:NAZWA>358 056 577</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358056577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470323.362000 242959.231000</gml:lowerCorner>
        		<gml:upperCorner>470323.362000 242959.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470323.362000 242959.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 055 362</ms:GML_ID>
        <ms:NAZWA>358 055 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358055362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476183.600455 244114.338491</gml:lowerCorner>
        		<gml:upperCorner>476183.600455 244114.338491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476183.600455 244114.338491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 180 291</ms:GML_ID>
        <ms:NAZWA>273 180 291</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273180291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470240.381321 244327.638358</gml:lowerCorner>
        		<gml:upperCorner>470240.381321 244327.638358</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470240.381321 244327.638358</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 053 990</ms:GML_ID>
        <ms:NAZWA>358 053 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358053990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475791.245258 244653.957350</gml:lowerCorner>
        		<gml:upperCorner>475791.245258 244653.957350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475791.245258 244653.957350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 179 622</ms:GML_ID>
        <ms:NAZWA>273 179 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273179622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470205.736000 244914.233000</gml:lowerCorner>
        		<gml:upperCorner>470205.736000 244914.233000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470205.736000 244914.233000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 053 404</ms:GML_ID>
        <ms:NAZWA>358 053 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358053404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475457.402000 245117.571000</gml:lowerCorner>
        		<gml:upperCorner>475457.402000 245117.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475457.402000 245117.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 179 052</ms:GML_ID>
        <ms:NAZWA>273 179 052</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273179052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469904.491503 246197.123952</gml:lowerCorner>
        		<gml:upperCorner>469904.491503 246197.123952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469904.491503 246197.123952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 052 081</ms:GML_ID>
        <ms:NAZWA>358 052 081</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358052081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469852.004214 246381.384743</gml:lowerCorner>
        		<gml:upperCorner>469852.004214 246381.384743</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469852.004214 246381.384743</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 051 891</ms:GML_ID>
        <ms:NAZWA>358 051 891</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358051891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469740.101735 246773.495548</gml:lowerCorner>
        		<gml:upperCorner>469740.101735 246773.495548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469740.101735 246773.495548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 051 482</ms:GML_ID>
        <ms:NAZWA>358 051 482</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358051482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469599.439057 247146.308228</gml:lowerCorner>
        		<gml:upperCorner>469599.439057 247146.308228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469599.439057 247146.308228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 051 082</ms:GML_ID>
        <ms:NAZWA>358 051 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358051082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473894.335414 247295.995559</gml:lowerCorner>
        		<gml:upperCorner>473894.335414 247295.995559</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473894.335414 247295.995559</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 176 367</ms:GML_ID>
        <ms:NAZWA>273 176 367</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273176367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473667.692537 247612.835935</gml:lowerCorner>
        		<gml:upperCorner>473667.692537 247612.835935</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473667.692537 247612.835935</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 175 977</ms:GML_ID>
        <ms:NAZWA>273 175 977</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273175977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472890.400797 248696.623161</gml:lowerCorner>
        		<gml:upperCorner>472890.400797 248696.623161</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472890.400797 248696.623161</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 174 645</ms:GML_ID>
        <ms:NAZWA>273 174 645</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273174645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468482.976566 249289.431485</gml:lowerCorner>
        		<gml:upperCorner>468482.976566 249289.431485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468482.976566 249289.431485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 048 640</ms:GML_ID>
        <ms:NAZWA>358 048 640</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358048640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471886.958000 250098.626000</gml:lowerCorner>
        		<gml:upperCorner>471886.958000 250098.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471886.958000 250098.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 172 918</ms:GML_ID>
        <ms:NAZWA>273 172 918</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273172918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469896.744506 251031.953118</gml:lowerCorner>
        		<gml:upperCorner>469896.744506 251031.953118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469896.744506 251031.953118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 170 680</ms:GML_ID>
        <ms:NAZWA>273 170 680</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273170680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467875.064254 251251.719295</gml:lowerCorner>
        		<gml:upperCorner>467875.064254 251251.719295</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467875.064254 251251.719295</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 046 587</ms:GML_ID>
        <ms:NAZWA>358 046 587</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358046587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467749.945000 257786.881000</gml:lowerCorner>
        		<gml:upperCorner>467749.945000 257786.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467749.945000 257786.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 039 778</ms:GML_ID>
        <ms:NAZWA>358 039 778</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358039778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468064.700000 258894.723000</gml:lowerCorner>
        		<gml:upperCorner>468064.700000 258894.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468064.700000 258894.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 038 621</ms:GML_ID>
        <ms:NAZWA>358 038 621</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358038621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468520.379040 260306.628719</gml:lowerCorner>
        		<gml:upperCorner>468520.379040 260306.628719</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468520.379040 260306.628719</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 037 138</ms:GML_ID>
        <ms:NAZWA>358 037 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358037138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470293.477000 261781.782000</gml:lowerCorner>
        		<gml:upperCorner>470293.477000 261781.782000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470293.477000 261781.782000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 034 783</ms:GML_ID>
        <ms:NAZWA>358 034 783</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358034783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472485.400000 265603.521000</gml:lowerCorner>
        		<gml:upperCorner>472485.400000 265603.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472485.400000 265603.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 030 189</ms:GML_ID>
        <ms:NAZWA>358 030 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358030189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469416.356000 266284.301000</gml:lowerCorner>
        		<gml:upperCorner>469416.356000 266284.301000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469416.356000 266284.301000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.393 001 267</ms:GML_ID>
        <ms:NAZWA>393 001 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>393001267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469168.320000 266349.927000</gml:lowerCorner>
        		<gml:upperCorner>469168.320000 266349.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469168.320000 266349.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.393 001 525</ms:GML_ID>
        <ms:NAZWA>393 001 525</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>393001525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417334.022000 258910.618000</gml:lowerCorner>
        		<gml:upperCorner>417334.022000 258910.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417334.022000 258910.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 325 597</ms:GML_ID>
        <ms:NAZWA>014 325 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014325597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417441.489000 258630.515000</gml:lowerCorner>
        		<gml:upperCorner>417441.489000 258630.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417441.489000 258630.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 325 896</ms:GML_ID>
        <ms:NAZWA>014 325 896</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014325896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417590.505000 258241.882000</gml:lowerCorner>
        		<gml:upperCorner>417590.505000 258241.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417590.505000 258241.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 326 310</ms:GML_ID>
        <ms:NAZWA>014 326 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014326310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417813.833000 257658.822000</gml:lowerCorner>
        		<gml:upperCorner>417813.833000 257658.822000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417813.833000 257658.822000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 326 936</ms:GML_ID>
        <ms:NAZWA>014 326 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014326936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418957.994000 253828.813000</gml:lowerCorner>
        		<gml:upperCorner>418957.994000 253828.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418957.994000 253828.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 330 951</ms:GML_ID>
        <ms:NAZWA>014 330 951</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014330951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419139.453000 252794.860000</gml:lowerCorner>
        		<gml:upperCorner>419139.453000 252794.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419139.453000 252794.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 332 005</ms:GML_ID>
        <ms:NAZWA>014 332 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014332005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419219.644746 252336.512289</gml:lowerCorner>
        		<gml:upperCorner>419219.644746 252336.512289</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419219.644746 252336.512289</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 332 466</ms:GML_ID>
        <ms:NAZWA>014 332 466</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014332466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419424.405000 237013.174000</gml:lowerCorner>
        		<gml:upperCorner>419424.405000 237013.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419424.405000 237013.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.389 008 532</ms:GML_ID>
        <ms:NAZWA>389 008 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>389008532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420107.936000 247198.897000</gml:lowerCorner>
        		<gml:upperCorner>420107.936000 247198.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420107.936000 247198.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 337 686</ms:GML_ID>
        <ms:NAZWA>014 337 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014337686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420380.037000 239143.592000</gml:lowerCorner>
        		<gml:upperCorner>420380.037000 239143.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420380.037000 239143.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.389 006 196</ms:GML_ID>
        <ms:NAZWA>389 006 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>389006196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420496.570000 246765.289000</gml:lowerCorner>
        		<gml:upperCorner>420496.570000 246765.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420496.570000 246765.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 137 216</ms:GML_ID>
        <ms:NAZWA>275 137 216</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275137216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421105.734000 246259.434000</gml:lowerCorner>
        		<gml:upperCorner>421105.734000 246259.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421105.734000 246259.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 138 025</ms:GML_ID>
        <ms:NAZWA>275 138 025</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275138025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421455.851000 242946.799000</gml:lowerCorner>
        		<gml:upperCorner>421455.851000 242946.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421455.851000 242946.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.389 002 225</ms:GML_ID>
        <ms:NAZWA>389 002 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>389002225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421562.394000 243134.194000</gml:lowerCorner>
        		<gml:upperCorner>421562.394000 243134.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421562.394000 243134.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.389 001 997</ms:GML_ID>
        <ms:NAZWA>389 001 997</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>389001997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421955.005062 243830.008430</gml:lowerCorner>
        		<gml:upperCorner>421955.005062 243830.008430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421955.005062 243830.008430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.389 001 197</ms:GML_ID>
        <ms:NAZWA>389 001 197</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>389001197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423308.175000 243764.642000</gml:lowerCorner>
        		<gml:upperCorner>423308.175000 243764.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423308.175000 243764.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 141 499</ms:GML_ID>
        <ms:NAZWA>275 141 499</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275141499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424125.184983 237241.199539</gml:lowerCorner>
        		<gml:upperCorner>424125.184983 237241.199539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424125.184983 237241.199539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 348 626</ms:GML_ID>
        <ms:NAZWA>014 348 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014348626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426640.550000 242216.042000</gml:lowerCorner>
        		<gml:upperCorner>426640.550000 242216.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426640.550000 242216.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 145 169</ms:GML_ID>
        <ms:NAZWA>275 145 169</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275145169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428486.832000 241358.119000</gml:lowerCorner>
        		<gml:upperCorner>428486.832000 241358.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428486.832000 241358.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 147 205</ms:GML_ID>
        <ms:NAZWA>275 147 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275147205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433059.106000 232474.536000</gml:lowerCorner>
        		<gml:upperCorner>433059.106000 232474.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433059.106000 232474.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 044 745</ms:GML_ID>
        <ms:NAZWA>370 044 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370044745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436318.939000 232614.442000</gml:lowerCorner>
        		<gml:upperCorner>436318.939000 232614.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436318.939000 232614.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 159 759</ms:GML_ID>
        <ms:NAZWA>275 159 759</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275159759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436022.396000 232993.521000</gml:lowerCorner>
        		<gml:upperCorner>436022.396000 232993.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436022.396000 232993.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 159 278</ms:GML_ID>
        <ms:NAZWA>275 159 278</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275159278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433399.442000 233048.774000</gml:lowerCorner>
        		<gml:upperCorner>433399.442000 233048.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433399.442000 233048.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 044 079</ms:GML_ID>
        <ms:NAZWA>370 044 079</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370044079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433588.578000 233368.179000</gml:lowerCorner>
        		<gml:upperCorner>433588.578000 233368.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433588.578000 233368.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 043 706</ms:GML_ID>
        <ms:NAZWA>370 043 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370043706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435059.809000 234243.311000</gml:lowerCorner>
        		<gml:upperCorner>435059.809000 234243.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435059.809000 234243.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 157 701</ms:GML_ID>
        <ms:NAZWA>275 157 701</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275157701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434888.405000 234667.757000</gml:lowerCorner>
        		<gml:upperCorner>434888.405000 234667.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434888.405000 234667.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 157 242</ms:GML_ID>
        <ms:NAZWA>275 157 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275157242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434365.184000 234679.335000</gml:lowerCorner>
        		<gml:upperCorner>434365.184000 234679.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434365.184000 234679.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 042 183</ms:GML_ID>
        <ms:NAZWA>370 042 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370042183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434643.054000 235149.260000</gml:lowerCorner>
        		<gml:upperCorner>434643.054000 235149.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434643.054000 235149.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 041 637</ms:GML_ID>
        <ms:NAZWA>370 041 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370041637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434802.354000 235188.418000</gml:lowerCorner>
        		<gml:upperCorner>434802.354000 235188.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434802.354000 235188.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 156 715</ms:GML_ID>
        <ms:NAZWA>275 156 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275156715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434732.420000 235624.074000</gml:lowerCorner>
        		<gml:upperCorner>434732.420000 235624.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434732.420000 235624.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 156 274</ms:GML_ID>
        <ms:NAZWA>275 156 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275156274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434674.820175 236010.049849</gml:lowerCorner>
        		<gml:upperCorner>434674.820175 236010.049849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434674.820175 236010.049849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 155 884</ms:GML_ID>
        <ms:NAZWA>275 155 884</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275155884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434518.067052 237008.516852</gml:lowerCorner>
        		<gml:upperCorner>434518.067052 237008.516852</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434518.067052 237008.516852</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 154 874</ms:GML_ID>
        <ms:NAZWA>275 154 874</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275154874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435247.029000 237740.966000</gml:lowerCorner>
        		<gml:upperCorner>435247.029000 237740.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435247.029000 237740.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 038 455</ms:GML_ID>
        <ms:NAZWA>370 038 455</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370038455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434115.291000 237888.503000</gml:lowerCorner>
        		<gml:upperCorner>434115.291000 237888.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434115.291000 237888.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 153 882</ms:GML_ID>
        <ms:NAZWA>275 153 882</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275153882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433721.596000 238242.520000</gml:lowerCorner>
        		<gml:upperCorner>433721.596000 238242.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433721.596000 238242.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 153 352</ms:GML_ID>
        <ms:NAZWA>275 153 352</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275153352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441631.597272 239058.165539</gml:lowerCorner>
        		<gml:upperCorner>441631.597272 239058.165539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441631.597272 239058.165539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 031 708</ms:GML_ID>
        <ms:NAZWA>370 031 708</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370031708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439303.397981 239166.897766</gml:lowerCorner>
        		<gml:upperCorner>439303.397981 239166.897766</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439303.397981 239166.897766</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 034 042</ms:GML_ID>
        <ms:NAZWA>370 034 042</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370034042</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387211.647282 236369.828179</gml:lowerCorner>
        		<gml:upperCorner>387211.647282 236369.828179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387211.647282 236369.828179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 000 428</ms:GML_ID>
        <ms:NAZWA>278 000 428</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278000428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387259.254390 236369.665544</gml:lowerCorner>
        		<gml:upperCorner>387259.254390 236369.665544</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387259.254390 236369.665544</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 061 929</ms:GML_ID>
        <ms:NAZWA>282 061 929</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282061929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387452.390067 224304.095317</gml:lowerCorner>
        		<gml:upperCorner>387452.390067 224304.095317</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387452.390067 224304.095317</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.295 012 556</ms:GML_ID>
        <ms:NAZWA>295 012 556</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>295012556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388341.285405 235247.252961</gml:lowerCorner>
        		<gml:upperCorner>388341.285405 235247.252961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388341.285405 235247.252961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 063 600</ms:GML_ID>
        <ms:NAZWA>282 063 600</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282063600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388786.507616 235071.988190</gml:lowerCorner>
        		<gml:upperCorner>388786.507616 235071.988190</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388786.507616 235071.988190</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 064 078</ms:GML_ID>
        <ms:NAZWA>282 064 078</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282064078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388936.946043 235012.865916</gml:lowerCorner>
        		<gml:upperCorner>388936.946043 235012.865916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388936.946043 235012.865916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 064 238</ms:GML_ID>
        <ms:NAZWA>282 064 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282064238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389154.554541 234927.153774</gml:lowerCorner>
        		<gml:upperCorner>389154.554541 234927.153774</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389154.554541 234927.153774</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 064 473</ms:GML_ID>
        <ms:NAZWA>282 064 473</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282064473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389387.433000 234835.796000</gml:lowerCorner>
        		<gml:upperCorner>389387.433000 234835.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389387.433000 234835.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 064 722</ms:GML_ID>
        <ms:NAZWA>282 064 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282064722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389774.067000 234684.096000</gml:lowerCorner>
        		<gml:upperCorner>389774.067000 234684.096000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389774.067000 234684.096000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 065 138</ms:GML_ID>
        <ms:NAZWA>282 065 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282065138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390250.088000 234496.947000</gml:lowerCorner>
        		<gml:upperCorner>390250.088000 234496.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390250.088000 234496.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 065 649</ms:GML_ID>
        <ms:NAZWA>282 065 649</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282065649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390789.338000 234285.396000</gml:lowerCorner>
        		<gml:upperCorner>390789.338000 234285.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390789.338000 234285.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 066 230</ms:GML_ID>
        <ms:NAZWA>282 066 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282066230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391160.050000 234139.218000</gml:lowerCorner>
        		<gml:upperCorner>391160.050000 234139.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391160.050000 234139.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 066 627</ms:GML_ID>
        <ms:NAZWA>282 066 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282066627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393430.579000 233331.339000</gml:lowerCorner>
        		<gml:upperCorner>393430.579000 233331.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393430.579000 233331.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 069 044</ms:GML_ID>
        <ms:NAZWA>282 069 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282069044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395007.918000 233505.433000</gml:lowerCorner>
        		<gml:upperCorner>395007.918000 233505.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395007.918000 233505.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 070 633</ms:GML_ID>
        <ms:NAZWA>282 070 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282070633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395543.580000 233581.685000</gml:lowerCorner>
        		<gml:upperCorner>395543.580000 233581.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395543.580000 233581.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 071 175</ms:GML_ID>
        <ms:NAZWA>282 071 175</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282071175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396178.146000 233670.733000</gml:lowerCorner>
        		<gml:upperCorner>396178.146000 233670.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396178.146000 233670.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 071 816</ms:GML_ID>
        <ms:NAZWA>282 071 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282071816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396706.154000 233745.077000</gml:lowerCorner>
        		<gml:upperCorner>396706.154000 233745.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396706.154000 233745.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 072 349</ms:GML_ID>
        <ms:NAZWA>282 072 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282072349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397789.108000 233896.903000</gml:lowerCorner>
        		<gml:upperCorner>397789.108000 233896.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397789.108000 233896.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 073 443</ms:GML_ID>
        <ms:NAZWA>282 073 443</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282073443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399461.032698 234125.350057</gml:lowerCorner>
        		<gml:upperCorner>399461.032698 234125.350057</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399461.032698 234125.350057</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 075 128</ms:GML_ID>
        <ms:NAZWA>282 075 128</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282075128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412157.326784 227702.914086</gml:lowerCorner>
        		<gml:upperCorner>412157.326784 227702.914086</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412157.326784 227702.914086</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 013 654</ms:GML_ID>
        <ms:NAZWA>380 013 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380013654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412266.733000 224900.883000</gml:lowerCorner>
        		<gml:upperCorner>412266.733000 224900.883000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412266.733000 224900.883000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 016 509</ms:GML_ID>
        <ms:NAZWA>380 016 509</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380016509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412382.306000 223624.264000</gml:lowerCorner>
        		<gml:upperCorner>412382.306000 223624.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412382.306000 223624.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 017 800</ms:GML_ID>
        <ms:NAZWA>380 017 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380017800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412404.583000 223824.441000</gml:lowerCorner>
        		<gml:upperCorner>412404.583000 223824.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412404.583000 223824.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 017 560</ms:GML_ID>
        <ms:NAZWA>380 017 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380017560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412578.417119 228017.474209</gml:lowerCorner>
        		<gml:upperCorner>412578.417119 228017.474209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412578.417119 228017.474209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 013 125</ms:GML_ID>
        <ms:NAZWA>380 013 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380013125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415246.544104 228431.846512</gml:lowerCorner>
        		<gml:upperCorner>415246.544104 228431.846512</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415246.544104 228431.846512</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 010 305</ms:GML_ID>
        <ms:NAZWA>380 010 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380010305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415584.923000 236052.648000</gml:lowerCorner>
        		<gml:upperCorner>415584.923000 236052.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415584.923000 236052.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 091 371</ms:GML_ID>
        <ms:NAZWA>282 091 371</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282091371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415651.941000 236039.528000</gml:lowerCorner>
        		<gml:upperCorner>415651.941000 236039.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415651.941000 236039.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 091 438</ms:GML_ID>
        <ms:NAZWA>282 091 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282091438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416639.313000 235750.254000</gml:lowerCorner>
        		<gml:upperCorner>416639.313000 235750.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416639.313000 235750.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 092 468</ms:GML_ID>
        <ms:NAZWA>282 092 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282092468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418057.609000 232602.021000</gml:lowerCorner>
        		<gml:upperCorner>418057.609000 232602.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418057.609000 232602.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 003 170</ms:GML_ID>
        <ms:NAZWA>380 003 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380003170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418071.621000 232723.081000</gml:lowerCorner>
        		<gml:upperCorner>418071.621000 232723.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418071.621000 232723.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 003 050</ms:GML_ID>
        <ms:NAZWA>380 003 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380003050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418179.129000 232955.559000</gml:lowerCorner>
        		<gml:upperCorner>418179.129000 232955.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418179.129000 232955.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 002 792</ms:GML_ID>
        <ms:NAZWA>380 002 792</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380002792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418271.651881 235361.528968</gml:lowerCorner>
        		<gml:upperCorner>418271.651881 235361.528968</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418271.651881 235361.528968</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 094 148</ms:GML_ID>
        <ms:NAZWA>282 094 148</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282094148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418297.018000 232024.584000</gml:lowerCorner>
        		<gml:upperCorner>418297.018000 232024.584000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418297.018000 232024.584000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 003 799</ms:GML_ID>
        <ms:NAZWA>380 003 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380003799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418368.703145 233344.829093</gml:lowerCorner>
        		<gml:upperCorner>418368.703145 233344.829093</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418368.703145 233344.829093</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 002 359</ms:GML_ID>
        <ms:NAZWA>380 002 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380002359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418393.431554 231635.110223</gml:lowerCorner>
        		<gml:upperCorner>418393.431554 231635.110223</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418393.431554 231635.110223</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 004 197</ms:GML_ID>
        <ms:NAZWA>380 004 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380004197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418410.276000 231569.917000</gml:lowerCorner>
        		<gml:upperCorner>418410.276000 231569.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418410.276000 231569.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 004 275</ms:GML_ID>
        <ms:NAZWA>380 004 275</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380004275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400103.454936 234206.644529</gml:lowerCorner>
        		<gml:upperCorner>400103.454936 234206.644529</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400103.454936 234206.644529</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 075 776</ms:GML_ID>
        <ms:NAZWA>282 075 776</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282075776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400829.887000 234326.350000</gml:lowerCorner>
        		<gml:upperCorner>400829.887000 234326.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400829.887000 234326.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 076 512</ms:GML_ID>
        <ms:NAZWA>282 076 512</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282076512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401245.094000 219384.117000</gml:lowerCorner>
        		<gml:upperCorner>401245.094000 219384.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401245.094000 219384.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 032 900</ms:GML_ID>
        <ms:NAZWA>380 032 900</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380032900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401267.392000 234387.385000</gml:lowerCorner>
        		<gml:upperCorner>401267.392000 234387.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401267.392000 234387.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 076 954</ms:GML_ID>
        <ms:NAZWA>282 076 954</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282076954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401656.624000 234441.679000</gml:lowerCorner>
        		<gml:upperCorner>401656.624000 234441.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401656.624000 234441.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 077 347</ms:GML_ID>
        <ms:NAZWA>282 077 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282077347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402166.104682 220206.659696</gml:lowerCorner>
        		<gml:upperCorner>402166.104682 220206.659696</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402166.104682 220206.659696</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 031 666</ms:GML_ID>
        <ms:NAZWA>380 031 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380031666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402226.437134 220250.061923</gml:lowerCorner>
        		<gml:upperCorner>402226.437134 220250.061923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402226.437134 220250.061923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 031 590</ms:GML_ID>
        <ms:NAZWA>380 031 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380031590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402368.275000 234540.970000</gml:lowerCorner>
        		<gml:upperCorner>402368.275000 234540.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402368.275000 234540.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 078 065</ms:GML_ID>
        <ms:NAZWA>282 078 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282078065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403180.620411 220911.209468</gml:lowerCorner>
        		<gml:upperCorner>403180.620411 220911.209468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403180.620411 220911.209468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 030 429</ms:GML_ID>
        <ms:NAZWA>380 030 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380030429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403500.832803 221110.941726</gml:lowerCorner>
        		<gml:upperCorner>403500.832803 221110.941726</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403500.832803 221110.941726</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 030 050</ms:GML_ID>
        <ms:NAZWA>380 030 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380030050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403580.346000 234708.467000</gml:lowerCorner>
        		<gml:upperCorner>403580.346000 234708.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403580.346000 234708.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 079 288</ms:GML_ID>
        <ms:NAZWA>282 079 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282079288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403992.221475 221462.231236</gml:lowerCorner>
        		<gml:upperCorner>403992.221475 221462.231236</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403992.221475 221462.231236</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 029 447</ms:GML_ID>
        <ms:NAZWA>380 029 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380029447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404534.631828 221777.625725</gml:lowerCorner>
        		<gml:upperCorner>404534.631828 221777.625725</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404534.631828 221777.625725</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 028 802</ms:GML_ID>
        <ms:NAZWA>380 028 802</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380028802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407000.663000 235184.342000</gml:lowerCorner>
        		<gml:upperCorner>407000.663000 235184.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407000.663000 235184.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 082 742</ms:GML_ID>
        <ms:NAZWA>282 082 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282082742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407291.412000 220259.017000</gml:lowerCorner>
        		<gml:upperCorner>407291.412000 220259.017000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407291.412000 220259.017000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 025 534</ms:GML_ID>
        <ms:NAZWA>380 025 534</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380025534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408302.582000 219879.274000</gml:lowerCorner>
        		<gml:upperCorner>408302.582000 219879.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408302.582000 219879.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 024 449</ms:GML_ID>
        <ms:NAZWA>380 024 449</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380024449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409006.204000 219495.196000</gml:lowerCorner>
        		<gml:upperCorner>409006.204000 219495.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409006.204000 219495.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 023 642</ms:GML_ID>
        <ms:NAZWA>380 023 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380023642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409682.347000 235457.437000</gml:lowerCorner>
        		<gml:upperCorner>409682.347000 235457.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409682.347000 235457.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 085 437</ms:GML_ID>
        <ms:NAZWA>282 085 437</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282085437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410519.480804 235541.654295</gml:lowerCorner>
        		<gml:upperCorner>410519.480804 235541.654295</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410519.480804 235541.654295</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 086 278</ms:GML_ID>
        <ms:NAZWA>282 086 278</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282086278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429722.812353 218446.457651</gml:lowerCorner>
        		<gml:upperCorner>429722.812353 218446.457651</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429722.812353 218446.457651</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 368 572</ms:GML_ID>
        <ms:NAZWA>014 368 572</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014368572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429598.301000 218824.452000</gml:lowerCorner>
        		<gml:upperCorner>429598.301000 218824.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429598.301000 218824.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 368 177</ms:GML_ID>
        <ms:NAZWA>014 368 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014368177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429138.489000 220213.351000</gml:lowerCorner>
        		<gml:upperCorner>429138.489000 220213.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429138.489000 220213.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 366 714</ms:GML_ID>
        <ms:NAZWA>014 366 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014366714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426404.898000 226473.682000</gml:lowerCorner>
        		<gml:upperCorner>426404.898000 226473.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426404.898000 226473.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 359 816</ms:GML_ID>
        <ms:NAZWA>014 359 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014359816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426266.847000 226979.915000</gml:lowerCorner>
        		<gml:upperCorner>426266.847000 226979.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426266.847000 226979.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 359 291</ms:GML_ID>
        <ms:NAZWA>014 359 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014359291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426244.089000 227643.823000</gml:lowerCorner>
        		<gml:upperCorner>426244.089000 227643.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426244.089000 227643.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 358 623</ms:GML_ID>
        <ms:NAZWA>014 358 623</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014358623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426234.704311 228862.957822</gml:lowerCorner>
        		<gml:upperCorner>426234.704311 228862.957822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426234.704311 228862.957822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 357 407</ms:GML_ID>
        <ms:NAZWA>014 357 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014357407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426230.787058 229366.311559</gml:lowerCorner>
        		<gml:upperCorner>426230.787058 229366.311559</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426230.787058 229366.311559</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 356 903</ms:GML_ID>
        <ms:NAZWA>014 356 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014356903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418482.030000 229460.243000</gml:lowerCorner>
        		<gml:upperCorner>418482.030000 229460.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418482.030000 229460.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 006 517</ms:GML_ID>
        <ms:NAZWA>380 006 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380006517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418657.873703 229703.186911</gml:lowerCorner>
        		<gml:upperCorner>418657.873703 229703.186911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418657.873703 229703.186911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 006 224</ms:GML_ID>
        <ms:NAZWA>380 006 224</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380006224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418634.986000 230661.255000</gml:lowerCorner>
        		<gml:upperCorner>418634.986000 230661.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418634.986000 230661.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 005 202</ms:GML_ID>
        <ms:NAZWA>380 005 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380005202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426622.401000 231405.051000</gml:lowerCorner>
        		<gml:upperCorner>426622.401000 231405.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426622.401000 231405.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 051 396</ms:GML_ID>
        <ms:NAZWA>370 051 396</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370051396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427593.828000 231447.480000</gml:lowerCorner>
        		<gml:upperCorner>427593.828000 231447.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427593.828000 231447.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 050 425</ms:GML_ID>
        <ms:NAZWA>370 050 425</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370050425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428199.427000 231473.525000</gml:lowerCorner>
        		<gml:upperCorner>428199.427000 231473.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428199.427000 231473.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 049 818</ms:GML_ID>
        <ms:NAZWA>370 049 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370049818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428600.701461 231491.534168</gml:lowerCorner>
        		<gml:upperCorner>428600.701461 231491.534168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428600.701461 231491.534168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 049 417</ms:GML_ID>
        <ms:NAZWA>370 049 417</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370049417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426029.799529 231601.097534</gml:lowerCorner>
        		<gml:upperCorner>426029.799529 231601.097534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426029.799529 231601.097534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 052 033</ms:GML_ID>
        <ms:NAZWA>370 052 033</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370052033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425936.824000 231969.326000</gml:lowerCorner>
        		<gml:upperCorner>425936.824000 231969.326000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425936.824000 231969.326000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 052 440</ms:GML_ID>
        <ms:NAZWA>370 052 440</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370052440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418487.530000 233639.432000</gml:lowerCorner>
        		<gml:upperCorner>418487.530000 233639.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418487.530000 233639.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 002 040</ms:GML_ID>
        <ms:NAZWA>380 002 040</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380002040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425268.896000 233757.001000</gml:lowerCorner>
        		<gml:upperCorner>425268.896000 233757.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425268.896000 233757.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 352 315</ms:GML_ID>
        <ms:NAZWA>014 352 315</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014352315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418508.360621 233899.022658</gml:lowerCorner>
        		<gml:upperCorner>418508.360621 233899.022658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418508.360621 233899.022658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 001 776</ms:GML_ID>
        <ms:NAZWA>380 001 776</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380001776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424817.140000 234026.205000</gml:lowerCorner>
        		<gml:upperCorner>424817.140000 234026.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424817.140000 234026.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 100 831</ms:GML_ID>
        <ms:NAZWA>282 100 831</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282100831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425013.891000 234242.693000</gml:lowerCorner>
        		<gml:upperCorner>425013.891000 234242.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425013.891000 234242.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 351 763</ms:GML_ID>
        <ms:NAZWA>014 351 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014351763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421781.479000 234543.798000</gml:lowerCorner>
        		<gml:upperCorner>421781.479000 234543.798000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421781.479000 234543.798000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 097 749</ms:GML_ID>
        <ms:NAZWA>282 097 749</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>282097749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418421.601503 234939.560073</gml:lowerCorner>
        		<gml:upperCorner>418421.601503 234939.560073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418421.601503 234939.560073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.380 000 716</ms:GML_ID>
        <ms:NAZWA>380 000 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>380000716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431228.748110 211937.357165</gml:lowerCorner>
        		<gml:upperCorner>431228.748110 211937.357165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431228.748110 211937.357165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 375 363</ms:GML_ID>
        <ms:NAZWA>014 375 363</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014375363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431208.088218 211973.541585</gml:lowerCorner>
        		<gml:upperCorner>431208.088218 211973.541585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431208.088218 211973.541585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 375 322</ms:GML_ID>
        <ms:NAZWA>014 375 322</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014375322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449036.087000 213621.657000</gml:lowerCorner>
        		<gml:upperCorner>449036.087000 213621.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449036.087000 213621.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 183 092</ms:GML_ID>
        <ms:NAZWA>275 183 092</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275183092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448800.116000 213823.478000</gml:lowerCorner>
        		<gml:upperCorner>448800.116000 213823.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448800.116000 213823.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 182 776</ms:GML_ID>
        <ms:NAZWA>275 182 776</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275182776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430429.496617 214465.903110</gml:lowerCorner>
        		<gml:upperCorner>430429.496617 214465.903110</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430429.496617 214465.903110</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 372 648</ms:GML_ID>
        <ms:NAZWA>014 372 648</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014372648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447788.110000 214689.735000</gml:lowerCorner>
        		<gml:upperCorner>447788.110000 214689.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447788.110000 214689.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 181 447</ms:GML_ID>
        <ms:NAZWA>275 181 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275181447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430399.600008 215141.251907</gml:lowerCorner>
        		<gml:upperCorner>430399.600008 215141.251907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430399.600008 215141.251907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 371 974</ms:GML_ID>
        <ms:NAZWA>014 371 974</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014371974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445722.042000 216986.585000</gml:lowerCorner>
        		<gml:upperCorner>445722.042000 216986.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445722.042000 216986.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 178 350</ms:GML_ID>
        <ms:NAZWA>275 178 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275178350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445249.694000 217576.375000</gml:lowerCorner>
        		<gml:upperCorner>445249.694000 217576.375000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445249.694000 217576.375000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 177 594</ms:GML_ID>
        <ms:NAZWA>275 177 594</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275177594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444782.620000 218160.511000</gml:lowerCorner>
        		<gml:upperCorner>444782.620000 218160.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444782.620000 218160.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 176 845</ms:GML_ID>
        <ms:NAZWA>275 176 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275176845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444564.934000 218432.837000</gml:lowerCorner>
        		<gml:upperCorner>444564.934000 218432.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444564.934000 218432.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 176 499</ms:GML_ID>
        <ms:NAZWA>275 176 499</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275176499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444407.034000 218629.815000</gml:lowerCorner>
        		<gml:upperCorner>444407.034000 218629.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444407.034000 218629.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 176 248</ms:GML_ID>
        <ms:NAZWA>275 176 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275176248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441466.077000 223511.972000</gml:lowerCorner>
        		<gml:upperCorner>441466.077000 223511.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441466.077000 223511.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 170 393</ms:GML_ID>
        <ms:NAZWA>275 170 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275170393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441032.940000 224004.355000</gml:lowerCorner>
        		<gml:upperCorner>441032.940000 224004.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441032.940000 224004.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 169 744</ms:GML_ID>
        <ms:NAZWA>275 169 744</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275169744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>437753.070000 229564.914000</gml:lowerCorner>
        		<gml:upperCorner>437753.070000 229564.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>437753.070000 229564.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 163 141</ms:GML_ID>
        <ms:NAZWA>275 163 141</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275163141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431149.274000 231706.114000</gml:lowerCorner>
        		<gml:upperCorner>431149.274000 231706.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431149.274000 231706.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 046 860</ms:GML_ID>
        <ms:NAZWA>370 046 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370046860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431905.270799 231858.214398</gml:lowerCorner>
        		<gml:upperCorner>431905.270799 231858.214398</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431905.270799 231858.214398</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 046 080</ms:GML_ID>
        <ms:NAZWA>370 046 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370046080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432049.302000 231914.579000</gml:lowerCorner>
        		<gml:upperCorner>432049.302000 231914.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432049.302000 231914.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.370 045 928</ms:GML_ID>
        <ms:NAZWA>370 045 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>370045928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449392.175000 213320.066000</gml:lowerCorner>
        		<gml:upperCorner>449392.175000 213320.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449392.175000 213320.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 183 558</ms:GML_ID>
        <ms:NAZWA>275 183 558</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275183558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449495.500000 213231.367000</gml:lowerCorner>
        		<gml:upperCorner>449495.500000 213231.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449495.500000 213231.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 183 693</ms:GML_ID>
        <ms:NAZWA>275 183 693</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275183693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449564.741000 213171.397000</gml:lowerCorner>
        		<gml:upperCorner>449564.741000 213171.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449564.741000 213171.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 183 782</ms:GML_ID>
        <ms:NAZWA>275 183 782</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275183782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450139.618000 212682.266000</gml:lowerCorner>
        		<gml:upperCorner>450139.618000 212682.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450139.618000 212682.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 184 538</ms:GML_ID>
        <ms:NAZWA>275 184 538</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275184538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450865.714000 212060.181000</gml:lowerCorner>
        		<gml:upperCorner>450865.714000 212060.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450865.714000 212060.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 185 497</ms:GML_ID>
        <ms:NAZWA>275 185 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275185497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451523.015000 211554.700000</gml:lowerCorner>
        		<gml:upperCorner>451523.015000 211554.700000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451523.015000 211554.700000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 186 324</ms:GML_ID>
        <ms:NAZWA>275 186 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275186324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468329.629000 221228.844000</gml:lowerCorner>
        		<gml:upperCorner>468329.629000 221228.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468329.629000 221228.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 077 675</ms:GML_ID>
        <ms:NAZWA>358 077 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358077675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468421.094010 221947.721173</gml:lowerCorner>
        		<gml:upperCorner>468421.094010 221947.721173</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468421.094010 221947.721173</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 076 949</ms:GML_ID>
        <ms:NAZWA>358 076 949</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358076949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468574.866738 223132.116709</gml:lowerCorner>
        		<gml:upperCorner>468574.866738 223132.116709</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468574.866738 223132.116709</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 075 756</ms:GML_ID>
        <ms:NAZWA>358 075 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358075756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468878.708636 224534.438613</gml:lowerCorner>
        		<gml:upperCorner>468878.708636 224534.438613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468878.708636 224534.438613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 074 317</ms:GML_ID>
        <ms:NAZWA>358 074 317</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358074317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469669.905381 234043.522488</gml:lowerCorner>
        		<gml:upperCorner>469669.905381 234043.522488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469669.905381 234043.522488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 064 457</ms:GML_ID>
        <ms:NAZWA>358 064 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358064457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469701.959227 227330.477049</gml:lowerCorner>
        		<gml:upperCorner>469701.959227 227330.477049</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469701.959227 227330.477049</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 071 405</ms:GML_ID>
        <ms:NAZWA>358 071 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358071405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469737.420486 234779.263849</gml:lowerCorner>
        		<gml:upperCorner>469737.420486 234779.263849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469737.420486 234779.263849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 063 712</ms:GML_ID>
        <ms:NAZWA>358 063 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358063712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469779.373618 235196.473978</gml:lowerCorner>
        		<gml:upperCorner>469779.373618 235196.473978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469779.373618 235196.473978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 063 298</ms:GML_ID>
        <ms:NAZWA>358 063 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358063298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469855.316126 232817.719536</gml:lowerCorner>
        		<gml:upperCorner>469855.316126 232817.719536</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469855.316126 232817.719536</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 065 709</ms:GML_ID>
        <ms:NAZWA>358 065 709</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358065709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470047.633557 228504.152663</gml:lowerCorner>
        		<gml:upperCorner>470047.633557 228504.152663</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470047.633557 228504.152663</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 070 182</ms:GML_ID>
        <ms:NAZWA>358 070 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358070182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470111.744473 231954.434412</gml:lowerCorner>
        		<gml:upperCorner>470111.744473 231954.434412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470111.744473 231954.434412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 066 600</ms:GML_ID>
        <ms:NAZWA>358 066 600</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358066600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470276.458000 231435.721000</gml:lowerCorner>
        		<gml:upperCorner>470276.458000 231435.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470276.458000 231435.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 067 149</ms:GML_ID>
        <ms:NAZWA>358 067 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358067149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470451.905781 230854.461924</gml:lowerCorner>
        		<gml:upperCorner>470451.905781 230854.461924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470451.905781 230854.461924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 067 755</ms:GML_ID>
        <ms:NAZWA>358 067 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358067755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470674.563000 238191.473000</gml:lowerCorner>
        		<gml:upperCorner>470674.563000 238191.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470674.563000 238191.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 060 152</ms:GML_ID>
        <ms:NAZWA>358 060 152</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358060152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479768.651381 237962.190883</gml:lowerCorner>
        		<gml:upperCorner>479768.651381 237962.190883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479768.651381 237962.190883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 187 573</ms:GML_ID>
        <ms:NAZWA>273 187 573</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273187573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480624.417577 236849.846752</gml:lowerCorner>
        		<gml:upperCorner>480624.417577 236849.846752</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480624.417577 236849.846752</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 188 976</ms:GML_ID>
        <ms:NAZWA>273 188 976</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273188976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481820.383278 234890.098565</gml:lowerCorner>
        		<gml:upperCorner>481820.383278 234890.098565</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481820.383278 234890.098565</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 191 281</ms:GML_ID>
        <ms:NAZWA>273 191 281</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273191281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483383.207000 232171.513000</gml:lowerCorner>
        		<gml:upperCorner>483383.207000 232171.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483383.207000 232171.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 194 441</ms:GML_ID>
        <ms:NAZWA>273 194 441</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273194441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483978.189240 231742.496598</gml:lowerCorner>
        		<gml:upperCorner>483978.189240 231742.496598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483978.189240 231742.496598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 195 176</ms:GML_ID>
        <ms:NAZWA>273 195 176</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273195176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484456.472000 231418.734000</gml:lowerCorner>
        		<gml:upperCorner>484456.472000 231418.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484456.472000 231418.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 195 751</ms:GML_ID>
        <ms:NAZWA>273 195 751</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273195751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438794.308537 201051.242159</gml:lowerCorner>
        		<gml:upperCorner>438794.308537 201051.242159</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438794.308537 201051.242159</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 388 624</ms:GML_ID>
        <ms:NAZWA>014 388 624</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014388624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451936.732000 211306.266000</gml:lowerCorner>
        		<gml:upperCorner>451936.732000 211306.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451936.732000 211306.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 186 809</ms:GML_ID>
        <ms:NAZWA>275 186 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275186809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452739.355000 210828.241000</gml:lowerCorner>
        		<gml:upperCorner>452739.355000 210828.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452739.355000 210828.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 187 740</ms:GML_ID>
        <ms:NAZWA>275 187 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275187740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454439.569000 209810.780000</gml:lowerCorner>
        		<gml:upperCorner>454439.569000 209810.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454439.569000 209810.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 189 721</ms:GML_ID>
        <ms:NAZWA>275 189 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275189721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455264.673000 209318.322000</gml:lowerCorner>
        		<gml:upperCorner>455264.673000 209318.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455264.673000 209318.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 190 681</ms:GML_ID>
        <ms:NAZWA>275 190 681</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275190681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455549.374000 209147.991000</gml:lowerCorner>
        		<gml:upperCorner>455549.374000 209147.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455549.374000 209147.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 191 012</ms:GML_ID>
        <ms:NAZWA>275 191 012</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275191012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456570.664000 208536.608000</gml:lowerCorner>
        		<gml:upperCorner>456570.664000 208536.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456570.664000 208536.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 192 202</ms:GML_ID>
        <ms:NAZWA>275 192 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275192202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456799.893000 208399.401000</gml:lowerCorner>
        		<gml:upperCorner>456799.893000 208399.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456799.893000 208399.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 192 469</ms:GML_ID>
        <ms:NAZWA>275 192 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275192469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457110.850000 208214.166000</gml:lowerCorner>
        		<gml:upperCorner>457110.850000 208214.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457110.850000 208214.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 192 830</ms:GML_ID>
        <ms:NAZWA>275 192 830</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275192830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458304.001046 207497.185296</gml:lowerCorner>
        		<gml:upperCorner>458304.001046 207497.185296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458304.001046 207497.185296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 194 222</ms:GML_ID>
        <ms:NAZWA>275 194 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275194222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459157.544000 206986.835000</gml:lowerCorner>
        		<gml:upperCorner>459157.544000 206986.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459157.544000 206986.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 195 216</ms:GML_ID>
        <ms:NAZWA>275 195 216</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275195216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459667.425000 206680.285000</gml:lowerCorner>
        		<gml:upperCorner>459667.425000 206680.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459667.425000 206680.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 195 810</ms:GML_ID>
        <ms:NAZWA>275 195 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275195810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460588.333212 206130.301988</gml:lowerCorner>
        		<gml:upperCorner>460588.333212 206130.301988</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460588.333212 206130.301988</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 196 880</ms:GML_ID>
        <ms:NAZWA>275 196 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275196880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461094.617000 205822.624000</gml:lowerCorner>
        		<gml:upperCorner>461094.617000 205822.624000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461094.617000 205822.624000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 197 475</ms:GML_ID>
        <ms:NAZWA>275 197 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>275197475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465551.817428 206226.406035</gml:lowerCorner>
        		<gml:upperCorner>465551.817428 206226.406035</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465551.817428 206226.406035</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 093 149</ms:GML_ID>
        <ms:NAZWA>358 093 149</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358093149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465937.264000 209102.331000</gml:lowerCorner>
        		<gml:upperCorner>465937.264000 209102.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465937.264000 209102.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 090 251</ms:GML_ID>
        <ms:NAZWA>358 090 251</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358090251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465945.239000 211286.435000</gml:lowerCorner>
        		<gml:upperCorner>465945.239000 211286.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465945.239000 211286.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 088 063</ms:GML_ID>
        <ms:NAZWA>358 088 063</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358088063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465978.043000 209437.872000</gml:lowerCorner>
        		<gml:upperCorner>465978.043000 209437.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465978.043000 209437.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 089 917</ms:GML_ID>
        <ms:NAZWA>358 089 917</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358089917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563852.529471 310214.969853</gml:lowerCorner>
        		<gml:upperCorner>563852.529471 310214.969853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563852.529471 310214.969853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 226 650</ms:GML_ID>
        <ms:NAZWA>203 226 650</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203226650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564066.671024 310719.344923</gml:lowerCorner>
        		<gml:upperCorner>564066.671024 310719.344923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564066.671024 310719.344923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 226 107</ms:GML_ID>
        <ms:NAZWA>203 226 107</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203226107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567673.668000 319389.100000</gml:lowerCorner>
        		<gml:upperCorner>567673.668000 319389.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567673.668000 319389.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 216 599</ms:GML_ID>
        <ms:NAZWA>203 216 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203216599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568899.415938 321370.564008</gml:lowerCorner>
        		<gml:upperCorner>568899.415938 321370.564008</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568899.415938 321370.564008</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 214 262</ms:GML_ID>
        <ms:NAZWA>203 214 262</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203214262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569599.924000 322328.530000</gml:lowerCorner>
        		<gml:upperCorner>569599.924000 322328.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569599.924000 322328.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 213 074</ms:GML_ID>
        <ms:NAZWA>203 213 074</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203213074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570458.252000 323505.531000</gml:lowerCorner>
        		<gml:upperCorner>570458.252000 323505.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570458.252000 323505.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 211 616</ms:GML_ID>
        <ms:NAZWA>203 211 616</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203211616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571855.228000 325417.921000</gml:lowerCorner>
        		<gml:upperCorner>571855.228000 325417.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571855.228000 325417.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 209 247</ms:GML_ID>
        <ms:NAZWA>203 209 247</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203209247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573009.816000 326463.279000</gml:lowerCorner>
        		<gml:upperCorner>573009.816000 326463.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573009.816000 326463.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 207 686</ms:GML_ID>
        <ms:NAZWA>203 207 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203207686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573994.902000 327316.256000</gml:lowerCorner>
        		<gml:upperCorner>573994.902000 327316.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573994.902000 327316.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 206 383</ms:GML_ID>
        <ms:NAZWA>203 206 383</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203206383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574920.978254 328119.164415</gml:lowerCorner>
        		<gml:upperCorner>574920.978254 328119.164415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574920.978254 328119.164415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 205 156</ms:GML_ID>
        <ms:NAZWA>203 205 156</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203205156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576641.824082 329624.709538</gml:lowerCorner>
        		<gml:upperCorner>576641.824082 329624.709538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576641.824082 329624.709538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 202 871</ms:GML_ID>
        <ms:NAZWA>203 202 871</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203202871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577415.384000 330284.650000</gml:lowerCorner>
        		<gml:upperCorner>577415.384000 330284.650000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577415.384000 330284.650000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 201 852</ms:GML_ID>
        <ms:NAZWA>203 201 852</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203201852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577745.406000 330570.837000</gml:lowerCorner>
        		<gml:upperCorner>577745.406000 330570.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577745.406000 330570.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 201 416</ms:GML_ID>
        <ms:NAZWA>203 201 416</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203201416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579506.442000 332359.838000</gml:lowerCorner>
        		<gml:upperCorner>579506.442000 332359.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579506.442000 332359.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 198 882</ms:GML_ID>
        <ms:NAZWA>203 198 882</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203198882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560833.698000 333235.873000</gml:lowerCorner>
        		<gml:upperCorner>560833.698000 333235.873000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560833.698000 333235.873000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 004 612</ms:GML_ID>
        <ms:NAZWA>390 004 612</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390004612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580024.885499 333328.510220</gml:lowerCorner>
        		<gml:upperCorner>580024.885499 333328.510220</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580024.885499 333328.510220</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 197 783</ms:GML_ID>
        <ms:NAZWA>203 197 783</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203197783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580632.956000 334465.039000</gml:lowerCorner>
        		<gml:upperCorner>580632.956000 334465.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580632.956000 334465.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 196 494</ms:GML_ID>
        <ms:NAZWA>203 196 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203196494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561353.181000 334551.860000</gml:lowerCorner>
        		<gml:upperCorner>561353.181000 334551.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561353.181000 334551.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 006 032</ms:GML_ID>
        <ms:NAZWA>390 006 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390006032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561534.320435 334888.790638</gml:lowerCorner>
        		<gml:upperCorner>561534.320435 334888.790638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561534.320435 334888.790638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 006 416</ms:GML_ID>
        <ms:NAZWA>390 006 416</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390006416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581164.638000 335207.460000</gml:lowerCorner>
        		<gml:upperCorner>581164.638000 335207.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581164.638000 335207.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 195 582</ms:GML_ID>
        <ms:NAZWA>203 195 582</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203195582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582853.246000 337432.775000</gml:lowerCorner>
        		<gml:upperCorner>582853.246000 337432.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582853.246000 337432.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 192 790</ms:GML_ID>
        <ms:NAZWA>203 192 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203192790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591684.836247 340158.574897</gml:lowerCorner>
        		<gml:upperCorner>591684.836247 340158.574897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591684.836247 340158.574897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 007 749</ms:GML_ID>
        <ms:NAZWA>403 007 749</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403007749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591424.985000 340854.389000</gml:lowerCorner>
        		<gml:upperCorner>591424.985000 340854.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591424.985000 340854.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 006 986</ms:GML_ID>
        <ms:NAZWA>403 006 986</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403006986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585408.604583 341438.702805</gml:lowerCorner>
        		<gml:upperCorner>585408.604583 341438.702805</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585408.604583 341438.702805</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 188 009</ms:GML_ID>
        <ms:NAZWA>203 188 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203188009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589682.711270 341787.629139</gml:lowerCorner>
        		<gml:upperCorner>589682.711270 341787.629139</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589682.711270 341787.629139</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 004 964</ms:GML_ID>
        <ms:NAZWA>403 004 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403004964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589493.824000 342751.953000</gml:lowerCorner>
        		<gml:upperCorner>589493.824000 342751.953000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589493.824000 342751.953000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.403 003 954</ms:GML_ID>
        <ms:NAZWA>403 003 954</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>403003954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586992.335000 344840.411000</gml:lowerCorner>
        		<gml:upperCorner>586992.335000 344840.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586992.335000 344840.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 184 255</ms:GML_ID>
        <ms:NAZWA>203 184 255</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203184255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577417.463870 344978.753859</gml:lowerCorner>
        		<gml:upperCorner>577417.463870 344978.753859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577417.463870 344978.753859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 029 372</ms:GML_ID>
        <ms:NAZWA>374 029 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374029372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577842.337409 345253.676118</gml:lowerCorner>
        		<gml:upperCorner>577842.337409 345253.676118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577842.337409 345253.676118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 029 826</ms:GML_ID>
        <ms:NAZWA>374 029 826</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374029826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590233.653000 345378.586000</gml:lowerCorner>
        		<gml:upperCorner>590233.653000 345378.586000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590233.653000 345378.586000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 005 826</ms:GML_ID>
        <ms:NAZWA>405 005 826</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405005826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588113.029000 346496.819000</gml:lowerCorner>
        		<gml:upperCorner>588113.029000 346496.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588113.029000 346496.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 003 303</ms:GML_ID>
        <ms:NAZWA>405 003 303</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405003303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588199.018000 346563.337000</gml:lowerCorner>
        		<gml:upperCorner>588199.018000 346563.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588199.018000 346563.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.999 002 745</ms:GML_ID>
        <ms:NAZWA>999 002 745</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>999002745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559499.149795 276507.868454</gml:lowerCorner>
        		<gml:upperCorner>559499.149795 276507.868454</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559499.149795 276507.868454</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 261 484</ms:GML_ID>
        <ms:NAZWA>203 261 484</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203261484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559635.439000 277420.756000</gml:lowerCorner>
        		<gml:upperCorner>559635.439000 277420.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559635.439000 277420.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 260 559</ms:GML_ID>
        <ms:NAZWA>203 260 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203260559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559634.826000 278594.369000</gml:lowerCorner>
        		<gml:upperCorner>559634.826000 278594.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559634.826000 278594.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 259 384</ms:GML_ID>
        <ms:NAZWA>203 259 384</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203259384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559624.890000 279212.091000</gml:lowerCorner>
        		<gml:upperCorner>559624.890000 279212.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559624.890000 279212.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 258 767</ms:GML_ID>
        <ms:NAZWA>203 258 767</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203258767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559616.356000 279710.946000</gml:lowerCorner>
        		<gml:upperCorner>559616.356000 279710.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559616.356000 279710.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 258 268</ms:GML_ID>
        <ms:NAZWA>203 258 268</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203258268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559607.435000 280237.935000</gml:lowerCorner>
        		<gml:upperCorner>559607.435000 280237.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559607.435000 280237.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 257 741</ms:GML_ID>
        <ms:NAZWA>203 257 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203257741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559593.725000 281069.979000</gml:lowerCorner>
        		<gml:upperCorner>559593.725000 281069.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559593.725000 281069.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 256 909</ms:GML_ID>
        <ms:NAZWA>203 256 909</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203256909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559571.618000 281612.873000</gml:lowerCorner>
        		<gml:upperCorner>559571.618000 281612.873000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559571.618000 281612.873000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 256 355</ms:GML_ID>
        <ms:NAZWA>203 256 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203256355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559514.169000 281951.925000</gml:lowerCorner>
        		<gml:upperCorner>559514.169000 281951.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559514.169000 281951.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 256 021</ms:GML_ID>
        <ms:NAZWA>203 256 021</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203256021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559333.571000 282594.843000</gml:lowerCorner>
        		<gml:upperCorner>559333.571000 282594.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559333.571000 282594.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 255 354</ms:GML_ID>
        <ms:NAZWA>203 255 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203255354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559107.258000 283567.168000</gml:lowerCorner>
        		<gml:upperCorner>559107.258000 283567.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559107.258000 283567.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 254 354</ms:GML_ID>
        <ms:NAZWA>203 254 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203254354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559042.788000 284676.971000</gml:lowerCorner>
        		<gml:upperCorner>559042.788000 284676.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559042.788000 284676.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 253 241</ms:GML_ID>
        <ms:NAZWA>203 253 241</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203253241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559015.410000 285655.532000</gml:lowerCorner>
        		<gml:upperCorner>559015.410000 285655.532000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559015.410000 285655.532000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 252 262</ms:GML_ID>
        <ms:NAZWA>203 252 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203252262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558991.657543 286588.165280</gml:lowerCorner>
        		<gml:upperCorner>558991.657543 286588.165280</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558991.657543 286588.165280</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 251 324</ms:GML_ID>
        <ms:NAZWA>203 251 324</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203251324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558909.740777 287201.671578</gml:lowerCorner>
        		<gml:upperCorner>558909.740777 287201.671578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558909.740777 287201.671578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 250 708</ms:GML_ID>
        <ms:NAZWA>203 250 708</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203250708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558662.103000 292992.102000</gml:lowerCorner>
        		<gml:upperCorner>558662.103000 292992.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558662.103000 292992.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 244 872</ms:GML_ID>
        <ms:NAZWA>203 244 872</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203244872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559952.647000 296948.752000</gml:lowerCorner>
        		<gml:upperCorner>559952.647000 296948.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559952.647000 296948.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 240 659</ms:GML_ID>
        <ms:NAZWA>203 240 659</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203240659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560416.321000 297935.202000</gml:lowerCorner>
        		<gml:upperCorner>560416.321000 297935.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560416.321000 297935.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 239 568</ms:GML_ID>
        <ms:NAZWA>203 239 568</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203239568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560953.365955 299122.805632</gml:lowerCorner>
        		<gml:upperCorner>560953.365955 299122.805632</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560953.365955 299122.805632</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 238 264</ms:GML_ID>
        <ms:NAZWA>203 238 264</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203238264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561386.376000 300386.821000</gml:lowerCorner>
        		<gml:upperCorner>561386.376000 300386.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561386.376000 300386.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 236 929</ms:GML_ID>
        <ms:NAZWA>203 236 929</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203236929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561167.708897 300701.680193</gml:lowerCorner>
        		<gml:upperCorner>561167.708897 300701.680193</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561167.708897 300701.680193</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 082 435</ms:GML_ID>
        <ms:NAZWA>351 082 435</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351082435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560732.751000 301711.088000</gml:lowerCorner>
        		<gml:upperCorner>560732.751000 301711.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560732.751000 301711.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 081 332</ms:GML_ID>
        <ms:NAZWA>351 081 332</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351081332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561903.554000 301747.053000</gml:lowerCorner>
        		<gml:upperCorner>561903.554000 301747.053000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561903.554000 301747.053000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 235 473</ms:GML_ID>
        <ms:NAZWA>203 235 473</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203235473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562503.346000 303334.759000</gml:lowerCorner>
        		<gml:upperCorner>562503.346000 303334.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562503.346000 303334.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 233 776</ms:GML_ID>
        <ms:NAZWA>203 233 776</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203233776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562800.196132 304118.369964</gml:lowerCorner>
        		<gml:upperCorner>562800.196132 304118.369964</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562800.196132 304118.369964</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 232 936</ms:GML_ID>
        <ms:NAZWA>203 232 936</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203232936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559135.345122 304250.114387</gml:lowerCorner>
        		<gml:upperCorner>559135.345122 304250.114387</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559135.345122 304250.114387</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 078 305</ms:GML_ID>
        <ms:NAZWA>351 078 305</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351078305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558294.318904 304997.160581</gml:lowerCorner>
        		<gml:upperCorner>558294.318904 304997.160581</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558294.318904 304997.160581</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 077 176</ms:GML_ID>
        <ms:NAZWA>351 077 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351077176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557782.810000 305457.100000</gml:lowerCorner>
        		<gml:upperCorner>557782.810000 305457.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557782.810000 305457.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 076 489</ms:GML_ID>
        <ms:NAZWA>351 076 489</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351076489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554836.276000 265903.491000</gml:lowerCorner>
        		<gml:upperCorner>554836.276000 265903.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554836.276000 265903.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 273 319</ms:GML_ID>
        <ms:NAZWA>203 273 319</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203273319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555782.629749 267050.265897</gml:lowerCorner>
        		<gml:upperCorner>555782.629749 267050.265897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555782.629749 267050.265897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 271 832</ms:GML_ID>
        <ms:NAZWA>203 271 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203271832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556307.961273 267687.790549</gml:lowerCorner>
        		<gml:upperCorner>556307.961273 267687.790549</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556307.961273 267687.790549</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 271 006</ms:GML_ID>
        <ms:NAZWA>203 271 006</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203271006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556472.715000 267886.701000</gml:lowerCorner>
        		<gml:upperCorner>556472.715000 267886.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556472.715000 267886.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 270 752</ms:GML_ID>
        <ms:NAZWA>203 270 752</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203270752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556878.861000 268389.653000</gml:lowerCorner>
        		<gml:upperCorner>556878.861000 268389.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556878.861000 268389.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 270 101</ms:GML_ID>
        <ms:NAZWA>203 270 101</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203270101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557302.597000 269093.118000</gml:lowerCorner>
        		<gml:upperCorner>557302.597000 269093.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557302.597000 269093.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 269 280</ms:GML_ID>
        <ms:NAZWA>203 269 280</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203269280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557675.994296 269781.582346</gml:lowerCorner>
        		<gml:upperCorner>557675.994296 269781.582346</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557675.994296 269781.582346</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 268 496</ms:GML_ID>
        <ms:NAZWA>203 268 496</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203268496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557676.644000 269465.787000</gml:lowerCorner>
        		<gml:upperCorner>557676.644000 269465.787000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557676.644000 269465.787000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.426 000 596</ms:GML_ID>
        <ms:NAZWA>426 000 596</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>426000596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557963.358858 270307.378705</gml:lowerCorner>
        		<gml:upperCorner>557963.358858 270307.378705</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557963.358858 270307.378705</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 267 907</ms:GML_ID>
        <ms:NAZWA>203 267 907</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203267907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558209.999000 268769.177000</gml:lowerCorner>
        		<gml:upperCorner>558209.999000 268769.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558209.999000 268769.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.426 001 478</ms:GML_ID>
        <ms:NAZWA>426 001 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>426001478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558576.315000 272105.511000</gml:lowerCorner>
        		<gml:upperCorner>558576.315000 272105.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558576.315000 272105.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 265 990</ms:GML_ID>
        <ms:NAZWA>203 265 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203265990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558644.946000 268233.458000</gml:lowerCorner>
        		<gml:upperCorner>558644.946000 268233.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558644.946000 268233.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.426 002 168</ms:GML_ID>
        <ms:NAZWA>426 002 168</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>426002168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558789.364000 272856.404000</gml:lowerCorner>
        		<gml:upperCorner>558789.364000 272856.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558789.364000 272856.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 265 209</ms:GML_ID>
        <ms:NAZWA>203 265 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203265209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558977.131000 273517.292000</gml:lowerCorner>
        		<gml:upperCorner>558977.131000 273517.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558977.131000 273517.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 264 523</ms:GML_ID>
        <ms:NAZWA>203 264 523</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203264523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559370.015000 275536.493000</gml:lowerCorner>
        		<gml:upperCorner>559370.015000 275536.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559370.015000 275536.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 262 461</ms:GML_ID>
        <ms:NAZWA>203 262 461</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203262461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578404.766275 275931.842482</gml:lowerCorner>
        		<gml:upperCorner>578404.766275 275931.842482</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578404.766275 275931.842482</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 115 323</ms:GML_ID>
        <ms:NAZWA>351 115 323</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351115323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581962.167915 271562.800154</gml:lowerCorner>
        		<gml:upperCorner>581962.167915 271562.800154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581962.167915 271562.800154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 120 988</ms:GML_ID>
        <ms:NAZWA>351 120 988</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351120988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584186.296000 269332.641000</gml:lowerCorner>
        		<gml:upperCorner>584186.296000 269332.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584186.296000 269332.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 124 144</ms:GML_ID>
        <ms:NAZWA>351 124 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351124144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586250.658000 266969.571000</gml:lowerCorner>
        		<gml:upperCorner>586250.658000 266969.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586250.658000 266969.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 127 288</ms:GML_ID>
        <ms:NAZWA>351 127 288</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351127288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588040.996000 265256.987000</gml:lowerCorner>
        		<gml:upperCorner>588040.996000 265256.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588040.996000 265256.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 129 783</ms:GML_ID>
        <ms:NAZWA>351 129 783</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>351129783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593597.796000 266099.209000</gml:lowerCorner>
        		<gml:upperCorner>593597.796000 266099.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593597.796000 266099.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 136 285</ms:GML_ID>
        <ms:NAZWA>410 136 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410136285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593800.490000 266701.496000</gml:lowerCorner>
        		<gml:upperCorner>593800.490000 266701.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593800.490000 266701.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 135 629</ms:GML_ID>
        <ms:NAZWA>410 135 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410135629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594420.222000 269680.429000</gml:lowerCorner>
        		<gml:upperCorner>594420.222000 269680.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594420.222000 269680.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 132 566</ms:GML_ID>
        <ms:NAZWA>410 132 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410132566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594693.967000 271293.860000</gml:lowerCorner>
        		<gml:upperCorner>594693.967000 271293.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594693.967000 271293.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 130 928</ms:GML_ID>
        <ms:NAZWA>410 130 928</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410130928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595156.819000 273415.884000</gml:lowerCorner>
        		<gml:upperCorner>595156.819000 273415.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595156.819000 273415.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 128 740</ms:GML_ID>
        <ms:NAZWA>410 128 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410128740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596133.169193 276238.136343</gml:lowerCorner>
        		<gml:upperCorner>596133.169193 276238.136343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596133.169193 276238.136343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.410 125 695</ms:GML_ID>
        <ms:NAZWA>410 125 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>410125695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.38">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553122.717338 347762.919960</gml:lowerCorner>
        		<gml:upperCorner>553122.717338 347762.919960</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.38.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553122.717338 347762.919960</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>38</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 115 866</ms:GML_ID>
        <ms:NAZWA>236 115 866</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236115866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.37">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552847.760519 348870.459175</gml:lowerCorner>
        		<gml:upperCorner>552847.760519 348870.459175</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.37.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552847.760519 348870.459175</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>37</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 114 715</ms:GML_ID>
        <ms:NAZWA>236 114 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236114715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.36">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552507.143000 349787.373000</gml:lowerCorner>
        		<gml:upperCorner>552507.143000 349787.373000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.36.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552507.143000 349787.373000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>36</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 113 740</ms:GML_ID>
        <ms:NAZWA>236 113 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236113740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.35">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552378.932000 350995.739000</gml:lowerCorner>
        		<gml:upperCorner>552378.932000 350995.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.35.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552378.932000 350995.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>35</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 112 520</ms:GML_ID>
        <ms:NAZWA>236 112 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236112520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.34">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552305.788000 351890.075000</gml:lowerCorner>
        		<gml:upperCorner>552305.788000 351890.075000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.34.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552305.788000 351890.075000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>34</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 111 623</ms:GML_ID>
        <ms:NAZWA>236 111 623</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236111623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.33">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552139.338000 352725.956000</gml:lowerCorner>
        		<gml:upperCorner>552139.338000 352725.956000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.33.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552139.338000 352725.956000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>33</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 110 771</ms:GML_ID>
        <ms:NAZWA>236 110 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236110771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.32">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551685.151000 353563.839000</gml:lowerCorner>
        		<gml:upperCorner>551685.151000 353563.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.32.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551685.151000 353563.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>32</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 109 810</ms:GML_ID>
        <ms:NAZWA>236 109 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236109810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.31">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551398.800000 354004.177000</gml:lowerCorner>
        		<gml:upperCorner>551398.800000 354004.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.31.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551398.800000 354004.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>31</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 109 284</ms:GML_ID>
        <ms:NAZWA>236 109 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236109284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.30">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550063.826000 355423.533000</gml:lowerCorner>
        		<gml:upperCorner>550063.826000 355423.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.30.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550063.826000 355423.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>30</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 107 316</ms:GML_ID>
        <ms:NAZWA>236 107 316</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236107316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.29">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549563.643000 355843.366000</gml:lowerCorner>
        		<gml:upperCorner>549563.643000 355843.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.29.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549563.643000 355843.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>29</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 106 664</ms:GML_ID>
        <ms:NAZWA>236 106 664</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236106664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.28">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548422.727000 356800.798000</gml:lowerCorner>
        		<gml:upperCorner>548422.727000 356800.798000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.28.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548422.727000 356800.798000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>28</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 105 171</ms:GML_ID>
        <ms:NAZWA>236 105 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236105171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.27">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548245.566000 356949.176000</gml:lowerCorner>
        		<gml:upperCorner>548245.566000 356949.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.27.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548245.566000 356949.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>27</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 104 943</ms:GML_ID>
        <ms:NAZWA>236 104 943</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236104943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.26">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547705.103000 357403.666000</gml:lowerCorner>
        		<gml:upperCorner>547705.103000 357403.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.26.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547705.103000 357403.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>26</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 104 236</ms:GML_ID>
        <ms:NAZWA>236 104 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236104236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554355.712000 363264.617000</gml:lowerCorner>
        		<gml:upperCorner>554355.712000 363264.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554355.712000 363264.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 051 793</ms:GML_ID>
        <ms:NAZWA>354 051 793</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354051793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555593.534000 363264.722000</gml:lowerCorner>
        		<gml:upperCorner>555593.534000 363264.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555593.534000 363264.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 053 036</ms:GML_ID>
        <ms:NAZWA>354 053 036</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354053036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560284.683775 363275.529094</gml:lowerCorner>
        		<gml:upperCorner>560284.683775 363275.529094</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560284.683775 363275.529094</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 057 761</ms:GML_ID>
        <ms:NAZWA>354 057 761</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354057761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556244.166000 363328.059000</gml:lowerCorner>
        		<gml:upperCorner>556244.166000 363328.059000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556244.166000 363328.059000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 053 690</ms:GML_ID>
        <ms:NAZWA>354 053 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354053690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559480.206000 363405.764000</gml:lowerCorner>
        		<gml:upperCorner>559480.206000 363405.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559480.206000 363405.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 056 946</ms:GML_ID>
        <ms:NAZWA>354 056 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354056946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551969.738000 363487.329000</gml:lowerCorner>
        		<gml:upperCorner>551969.738000 363487.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551969.738000 363487.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 049 395</ms:GML_ID>
        <ms:NAZWA>354 049 395</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354049395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548719.039000 363514.761000</gml:lowerCorner>
        		<gml:upperCorner>548719.039000 363514.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548719.039000 363514.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 046 139</ms:GML_ID>
        <ms:NAZWA>354 046 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354046139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558601.005000 363535.340000</gml:lowerCorner>
        		<gml:upperCorner>558601.005000 363535.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558601.005000 363535.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 056 055</ms:GML_ID>
        <ms:NAZWA>354 056 055</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354056055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546914.304000 210178.138000</gml:lowerCorner>
        		<gml:upperCorner>546914.304000 210178.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546914.304000 210178.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 225 341</ms:GML_ID>
        <ms:NAZWA>430 225 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430225341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549072.166000 210352.271000</gml:lowerCorner>
        		<gml:upperCorner>549072.166000 210352.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549072.166000 210352.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 223 038</ms:GML_ID>
        <ms:NAZWA>430 223 038</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430223038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550146.498014 210529.349073</gml:lowerCorner>
        		<gml:upperCorner>550146.498014 210529.349073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550146.498014 210529.349073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 221 947</ms:GML_ID>
        <ms:NAZWA>430 221 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430221947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550272.076324 210603.608488</gml:lowerCorner>
        		<gml:upperCorner>550272.076324 210603.608488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550272.076324 210603.608488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 221 802</ms:GML_ID>
        <ms:NAZWA>430 221 802</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430221802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.87">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550534.700001 197654.926561</gml:lowerCorner>
        		<gml:upperCorner>550534.700001 197654.926561</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.87.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550534.700001 197654.926561</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>87</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 274 024</ms:GML_ID>
        <ms:NAZWA>273 274 024</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273274024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550676.779000 210994.151000</gml:lowerCorner>
        		<gml:upperCorner>550676.779000 210994.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550676.779000 210994.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 221 240</ms:GML_ID>
        <ms:NAZWA>430 221 240</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430221240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.88">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551232.894058 197402.181812</gml:lowerCorner>
        		<gml:upperCorner>551232.894058 197402.181812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.88.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551232.894058 197402.181812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>88</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 274 766</ms:GML_ID>
        <ms:NAZWA>273 274 766</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273274766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.89">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552737.953027 196858.667259</gml:lowerCorner>
        		<gml:upperCorner>552737.953027 196858.667259</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.89.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552737.953027 196858.667259</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>89</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 276 365</ms:GML_ID>
        <ms:NAZWA>273 276 365</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273276365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552888.002000 212666.425000</gml:lowerCorner>
        		<gml:upperCorner>552888.002000 212666.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552888.002000 212666.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 218 403</ms:GML_ID>
        <ms:NAZWA>430 218 403</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430218403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553203.643000 212722.421000</gml:lowerCorner>
        		<gml:upperCorner>553203.643000 212722.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553203.643000 212722.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 218 083</ms:GML_ID>
        <ms:NAZWA>430 218 083</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430218083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.90">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555051.807840 195973.576202</gml:lowerCorner>
        		<gml:upperCorner>555051.807840 195973.576202</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.90.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555051.807840 195973.576202</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>90</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 278 839</ms:GML_ID>
        <ms:NAZWA>273 278 839</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273278839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.91">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555586.068263 195762.435573</gml:lowerCorner>
        		<gml:upperCorner>555586.068263 195762.435573</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.91.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555586.068263 195762.435573</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>91</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 279 412</ms:GML_ID>
        <ms:NAZWA>273 279 412</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273279412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.92">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557426.810394 195383.465862</gml:lowerCorner>
        		<gml:upperCorner>557426.810394 195383.465862</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.92.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557426.810394 195383.465862</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>92</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 281 313</ms:GML_ID>
        <ms:NAZWA>273 281 313</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273281313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.93">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560519.840833 194679.093778</gml:lowerCorner>
        		<gml:upperCorner>560519.840833 194679.093778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.93.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560519.840833 194679.093778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>93</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 284 473</ms:GML_ID>
        <ms:NAZWA>273 284 473</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273284473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.94">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561736.483000 194416.030000</gml:lowerCorner>
        		<gml:upperCorner>561736.483000 194416.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.94.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561736.483000 194416.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>94</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 285 715</ms:GML_ID>
        <ms:NAZWA>273 285 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273285715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.95">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563342.015000 193795.170000</gml:lowerCorner>
        		<gml:upperCorner>563342.015000 193795.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.95.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563342.015000 193795.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>95</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 287 457</ms:GML_ID>
        <ms:NAZWA>273 287 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273287457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.96">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565100.230717 193896.071492</gml:lowerCorner>
        		<gml:upperCorner>565100.230717 193896.071492</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.96.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565100.230717 193896.071492</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>96</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 289 308</ms:GML_ID>
        <ms:NAZWA>273 289 308</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273289308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.97">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568895.800920 194725.704196</gml:lowerCorner>
        		<gml:upperCorner>568895.800920 194725.704196</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.97.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568895.800920 194725.704196</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>97</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 293 221</ms:GML_ID>
        <ms:NAZWA>273 293 221</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273293221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.98">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570031.877162 194662.391718</gml:lowerCorner>
        		<gml:upperCorner>570031.877162 194662.391718</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.98.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570031.877162 194662.391718</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>98</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 294 356</ms:GML_ID>
        <ms:NAZWA>273 294 356</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273294356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.99">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572547.084971 194634.027609</gml:lowerCorner>
        		<gml:upperCorner>572547.084971 194634.027609</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.99.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572547.084971 194634.027609</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>99</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 296 875</ms:GML_ID>
        <ms:NAZWA>273 296 875</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273296875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553114.328500 309667.256037</gml:lowerCorner>
        		<gml:upperCorner>553114.328500 309667.256037</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553114.328500 309667.256037</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 070 199</ms:GML_ID>
        <ms:NAZWA>351 070 199</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351070199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552495.182758 310259.502232</gml:lowerCorner>
        		<gml:upperCorner>552495.182758 310259.502232</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552495.182758 310259.502232</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 069 344</ms:GML_ID>
        <ms:NAZWA>351 069 344</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351069344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545683.144023 315509.068078</gml:lowerCorner>
        		<gml:upperCorner>545683.144023 315509.068078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545683.144023 315509.068078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 060 420</ms:GML_ID>
        <ms:NAZWA>351 060 420</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351060420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545261.983058 316204.231477</gml:lowerCorner>
        		<gml:upperCorner>545261.983058 316204.231477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545261.983058 316204.231477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 059 607</ms:GML_ID>
        <ms:NAZWA>351 059 607</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351059607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.56">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557928.074720 330040.085854</gml:lowerCorner>
        		<gml:upperCorner>557928.074720 330040.085854</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.56.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557928.074720 330040.085854</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>56</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 136 072</ms:GML_ID>
        <ms:NAZWA>236 136 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236136072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558489.480000 331061.218000</gml:lowerCorner>
        		<gml:upperCorner>558489.480000 331061.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558489.480000 331061.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 000 735</ms:GML_ID>
        <ms:NAZWA>390 000 735</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390000735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559838.861731 331197.724270</gml:lowerCorner>
        		<gml:upperCorner>559838.861731 331197.724270</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559838.861731 331197.724270</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 002 262</ms:GML_ID>
        <ms:NAZWA>390 002 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390002262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.55">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558034.797515 331567.472938</gml:lowerCorner>
        		<gml:upperCorner>558034.797515 331567.472938</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.55.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558034.797515 331567.472938</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>55</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 134 291</ms:GML_ID>
        <ms:NAZWA>236 134 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236134291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560402.486000 332040.621000</gml:lowerCorner>
        		<gml:upperCorner>560402.486000 332040.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560402.486000 332040.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.390 003 305</ms:GML_ID>
        <ms:NAZWA>390 003 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>390003305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.54">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556961.755000 332394.824000</gml:lowerCorner>
        		<gml:upperCorner>556961.755000 332394.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.54.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556961.755000 332394.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>54</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 132 934</ms:GML_ID>
        <ms:NAZWA>236 132 934</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236132934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.53">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556553.723000 332756.985000</gml:lowerCorner>
        		<gml:upperCorner>556553.723000 332756.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.53.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556553.723000 332756.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>53</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 132 389</ms:GML_ID>
        <ms:NAZWA>236 132 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236132389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.52">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556229.903000 333066.160000</gml:lowerCorner>
        		<gml:upperCorner>556229.903000 333066.160000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.52.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556229.903000 333066.160000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>52</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 131 940</ms:GML_ID>
        <ms:NAZWA>236 131 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236131940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.51">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556149.069000 333468.174000</gml:lowerCorner>
        		<gml:upperCorner>556149.069000 333468.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.51.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556149.069000 333468.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>51</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 131 522</ms:GML_ID>
        <ms:NAZWA>236 131 522</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236131522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.50">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556167.973544 334183.029861</gml:lowerCorner>
        		<gml:upperCorner>556167.973544 334183.029861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.50.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556167.973544 334183.029861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>50</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 130 807</ms:GML_ID>
        <ms:NAZWA>236 130 807</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236130807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.49">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556229.752000 335635.410000</gml:lowerCorner>
        		<gml:upperCorner>556229.752000 335635.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.49.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556229.752000 335635.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>49</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 129 351</ms:GML_ID>
        <ms:NAZWA>236 129 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236129351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.48">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556255.191000 336659.764000</gml:lowerCorner>
        		<gml:upperCorner>556255.191000 336659.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.48.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556255.191000 336659.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>48</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 128 328</ms:GML_ID>
        <ms:NAZWA>236 128 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236128328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.47">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556276.032000 337520.796000</gml:lowerCorner>
        		<gml:upperCorner>556276.032000 337520.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.47.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556276.032000 337520.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>47</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 127 460</ms:GML_ID>
        <ms:NAZWA>236 127 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236127460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.46">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556280.423000 338406.817000</gml:lowerCorner>
        		<gml:upperCorner>556280.423000 338406.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.46.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556280.423000 338406.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>46</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 126 579</ms:GML_ID>
        <ms:NAZWA>236 126 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236126579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.45">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556285.209000 339205.321000</gml:lowerCorner>
        		<gml:upperCorner>556285.209000 339205.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.45.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556285.209000 339205.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>45</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 125 781</ms:GML_ID>
        <ms:NAZWA>236 125 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236125781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.44">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556569.918000 342710.839000</gml:lowerCorner>
        		<gml:upperCorner>556569.918000 342710.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.44.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556569.918000 342710.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>44</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 122 203</ms:GML_ID>
        <ms:NAZWA>236 122 203</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236122203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.43">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555467.339000 343913.511000</gml:lowerCorner>
        		<gml:upperCorner>555467.339000 343913.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.43.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555467.339000 343913.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>43</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 120 568</ms:GML_ID>
        <ms:NAZWA>236 120 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236120568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.42">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555315.703000 344063.061000</gml:lowerCorner>
        		<gml:upperCorner>555315.703000 344063.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.42.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555315.703000 344063.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>42</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 120 357</ms:GML_ID>
        <ms:NAZWA>236 120 357</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236120357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.41">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554854.738625 344519.436978</gml:lowerCorner>
        		<gml:upperCorner>554854.738625 344519.436978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.41.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554854.738625 344519.436978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>41</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 119 709</ms:GML_ID>
        <ms:NAZWA>236 119 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236119709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.40">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553688.427627 345819.454508</gml:lowerCorner>
        		<gml:upperCorner>553688.427627 345819.454508</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.40.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553688.427627 345819.454508</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>40</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 117 961</ms:GML_ID>
        <ms:NAZWA>236 117 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236117961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.39">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553226.323000 346651.407000</gml:lowerCorner>
        		<gml:upperCorner>553226.323000 346651.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.39.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553226.323000 346651.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>39</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 116 982</ms:GML_ID>
        <ms:NAZWA>236 116 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236116982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541607.798817 229760.417967</gml:lowerCorner>
        		<gml:upperCorner>541607.798817 229760.417967</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541607.798817 229760.417967</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 313 882</ms:GML_ID>
        <ms:NAZWA>203 313 882</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203313882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541676.631000 231926.889000</gml:lowerCorner>
        		<gml:upperCorner>541676.631000 231926.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541676.631000 231926.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 311 714</ms:GML_ID>
        <ms:NAZWA>203 311 714</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203311714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541818.292000 232530.578000</gml:lowerCorner>
        		<gml:upperCorner>541818.292000 232530.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541818.292000 232530.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 311 091</ms:GML_ID>
        <ms:NAZWA>203 311 091</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203311091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542197.660000 233243.580000</gml:lowerCorner>
        		<gml:upperCorner>542197.660000 233243.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542197.660000 233243.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 310 283</ms:GML_ID>
        <ms:NAZWA>203 310 283</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203310283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542641.726000 234054.549000</gml:lowerCorner>
        		<gml:upperCorner>542641.726000 234054.549000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542641.726000 234054.549000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 309 358</ms:GML_ID>
        <ms:NAZWA>203 309 358</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203309358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542776.578000 234300.555000</gml:lowerCorner>
        		<gml:upperCorner>542776.578000 234300.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542776.578000 234300.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 309 077</ms:GML_ID>
        <ms:NAZWA>203 309 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203309077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542992.958660 234701.112837</gml:lowerCorner>
        		<gml:upperCorner>542992.958660 234701.112837</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542992.958660 234701.112837</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 308 623</ms:GML_ID>
        <ms:NAZWA>203 308 623</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203308623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543214.806552 235227.421228</gml:lowerCorner>
        		<gml:upperCorner>543214.806552 235227.421228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543214.806552 235227.421228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 308 051</ms:GML_ID>
        <ms:NAZWA>203 308 051</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203308051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543358.175000 235636.020000</gml:lowerCorner>
        		<gml:upperCorner>543358.175000 235636.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543358.175000 235636.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 307 619</ms:GML_ID>
        <ms:NAZWA>203 307 619</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203307619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543443.139000 235867.390000</gml:lowerCorner>
        		<gml:upperCorner>543443.139000 235867.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543443.139000 235867.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 307 373</ms:GML_ID>
        <ms:NAZWA>203 307 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203307373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543613.863000 236331.807000</gml:lowerCorner>
        		<gml:upperCorner>543613.863000 236331.807000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543613.863000 236331.807000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 306 878</ms:GML_ID>
        <ms:NAZWA>203 306 878</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203306878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543837.180000 236937.213000</gml:lowerCorner>
        		<gml:upperCorner>543837.180000 236937.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543837.180000 236937.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 306 232</ms:GML_ID>
        <ms:NAZWA>203 306 232</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203306232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544081.339119 237598.986383</gml:lowerCorner>
        		<gml:upperCorner>544081.339119 237598.986383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544081.339119 237598.986383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 305 527</ms:GML_ID>
        <ms:NAZWA>203 305 527</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203305527</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544255.620759 238072.083818</gml:lowerCorner>
        		<gml:upperCorner>544255.620759 238072.083818</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544255.620759 238072.083818</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 305 025</ms:GML_ID>
        <ms:NAZWA>203 305 025</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203305025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544971.387000 240012.936000</gml:lowerCorner>
        		<gml:upperCorner>544971.387000 240012.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544971.387000 240012.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 302 957</ms:GML_ID>
        <ms:NAZWA>203 302 957</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203302957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545613.141000 241692.732000</gml:lowerCorner>
        		<gml:upperCorner>545613.141000 241692.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545613.141000 241692.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 301 157</ms:GML_ID>
        <ms:NAZWA>203 301 157</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203301157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545913.415000 242103.282000</gml:lowerCorner>
        		<gml:upperCorner>545913.415000 242103.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545913.415000 242103.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 300 646</ms:GML_ID>
        <ms:NAZWA>203 300 646</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203300646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546481.640022 246027.452586</gml:lowerCorner>
        		<gml:upperCorner>546481.640022 246027.452586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546481.640022 246027.452586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 072 945</ms:GML_ID>
        <ms:NAZWA>367 072 945</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367072945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545897.051063 246301.402418</gml:lowerCorner>
        		<gml:upperCorner>545897.051063 246301.402418</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545897.051063 246301.402418</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 072 291</ms:GML_ID>
        <ms:NAZWA>367 072 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367072291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545637.842832 246426.805643</gml:lowerCorner>
        		<gml:upperCorner>545637.842832 246426.805643</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545637.842832 246426.805643</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 072 003</ms:GML_ID>
        <ms:NAZWA>367 072 003</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367072003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545390.850050 246546.421925</gml:lowerCorner>
        		<gml:upperCorner>545390.850050 246546.421925</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545390.850050 246546.421925</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 071 723</ms:GML_ID>
        <ms:NAZWA>367 071 723</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367071723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547304.829000 246936.203000</gml:lowerCorner>
        		<gml:upperCorner>547304.829000 246936.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547304.829000 246936.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 295 552</ms:GML_ID>
        <ms:NAZWA>203 295 552</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203295552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544399.277260 247026.873133</gml:lowerCorner>
        		<gml:upperCorner>544399.277260 247026.873133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544399.277260 247026.873133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 070 626</ms:GML_ID>
        <ms:NAZWA>367 070 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367070626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547358.531117 247118.821469</gml:lowerCorner>
        		<gml:upperCorner>547358.531117 247118.821469</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547358.531117 247118.821469</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 295 362</ms:GML_ID>
        <ms:NAZWA>203 295 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203295362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537977.449261 212589.210417</gml:lowerCorner>
        		<gml:upperCorner>537977.449261 212589.210417</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537977.449261 212589.210417</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 331 961</ms:GML_ID>
        <ms:NAZWA>203 331 961</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203331961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538335.843000 213291.320000</gml:lowerCorner>
        		<gml:upperCorner>538335.843000 213291.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538335.843000 213291.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 331 172</ms:GML_ID>
        <ms:NAZWA>203 331 172</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203331172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538536.543000 213683.785000</gml:lowerCorner>
        		<gml:upperCorner>538536.543000 213683.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538536.543000 213683.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 330 732</ms:GML_ID>
        <ms:NAZWA>203 330 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203330732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538764.196000 214127.829000</gml:lowerCorner>
        		<gml:upperCorner>538764.196000 214127.829000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538764.196000 214127.829000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 330 232</ms:GML_ID>
        <ms:NAZWA>203 330 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203330232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539061.154234 214704.955022</gml:lowerCorner>
        		<gml:upperCorner>539061.154234 214704.955022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539061.154234 214704.955022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 329 586</ms:GML_ID>
        <ms:NAZWA>203 329 586</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203329586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539623.478000 215676.511000</gml:lowerCorner>
        		<gml:upperCorner>539623.478000 215676.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539623.478000 215676.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 328 460</ms:GML_ID>
        <ms:NAZWA>203 328 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203328460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540258.655000 216693.399000</gml:lowerCorner>
        		<gml:upperCorner>540258.655000 216693.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540258.655000 216693.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 327 264</ms:GML_ID>
        <ms:NAZWA>203 327 264</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203327264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540504.837000 217086.703000</gml:lowerCorner>
        		<gml:upperCorner>540504.837000 217086.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540504.837000 217086.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 326 799</ms:GML_ID>
        <ms:NAZWA>203 326 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203326799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540812.024000 217579.285000</gml:lowerCorner>
        		<gml:upperCorner>540812.024000 217579.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540812.024000 217579.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 326 218</ms:GML_ID>
        <ms:NAZWA>203 326 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203326218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540959.352000 217815.081000</gml:lowerCorner>
        		<gml:upperCorner>540959.352000 217815.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540959.352000 217815.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 325 941</ms:GML_ID>
        <ms:NAZWA>203 325 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203325941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541266.770000 218327.273000</gml:lowerCorner>
        		<gml:upperCorner>541266.770000 218327.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541266.770000 218327.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 325 343</ms:GML_ID>
        <ms:NAZWA>203 325 343</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203325343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541446.182000 218952.817000</gml:lowerCorner>
        		<gml:upperCorner>541446.182000 218952.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541446.182000 218952.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 324 690</ms:GML_ID>
        <ms:NAZWA>203 324 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203324690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541456.263000 219361.661000</gml:lowerCorner>
        		<gml:upperCorner>541456.263000 219361.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541456.263000 219361.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 324 281</ms:GML_ID>
        <ms:NAZWA>203 324 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203324281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541448.465093 220180.467119</gml:lowerCorner>
        		<gml:upperCorner>541448.465093 220180.467119</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541448.465093 220180.467119</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 323 464</ms:GML_ID>
        <ms:NAZWA>203 323 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203323464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541439.125939 221187.342911</gml:lowerCorner>
        		<gml:upperCorner>541439.125939 221187.342911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541439.125939 221187.342911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 322 456</ms:GML_ID>
        <ms:NAZWA>203 322 456</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203322456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541419.095017 222258.484891</gml:lowerCorner>
        		<gml:upperCorner>541419.095017 222258.484891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541419.095017 222258.484891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 321 383</ms:GML_ID>
        <ms:NAZWA>203 321 383</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203321383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541414.965652 222871.318468</gml:lowerCorner>
        		<gml:upperCorner>541414.965652 222871.318468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541414.965652 222871.318468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 320 772</ms:GML_ID>
        <ms:NAZWA>203 320 772</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203320772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541414.556000 223745.812000</gml:lowerCorner>
        		<gml:upperCorner>541414.556000 223745.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541414.556000 223745.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 319 899</ms:GML_ID>
        <ms:NAZWA>203 319 899</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203319899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541419.529000 224312.677000</gml:lowerCorner>
        		<gml:upperCorner>541419.529000 224312.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541419.529000 224312.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 319 331</ms:GML_ID>
        <ms:NAZWA>203 319 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203319331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541467.036000 225735.035000</gml:lowerCorner>
        		<gml:upperCorner>541467.036000 225735.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541467.036000 225735.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 317 908</ms:GML_ID>
        <ms:NAZWA>203 317 908</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203317908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541526.754000 227503.514000</gml:lowerCorner>
        		<gml:upperCorner>541526.754000 227503.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541526.754000 227503.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 316 134</ms:GML_ID>
        <ms:NAZWA>203 316 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203316134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543802.940793 247378.570809</gml:lowerCorner>
        		<gml:upperCorner>543802.940793 247378.570809</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543802.940793 247378.570809</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 069 930</ms:GML_ID>
        <ms:NAZWA>367 069 930</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367069930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543418.894016 247750.959978</gml:lowerCorner>
        		<gml:upperCorner>543418.894016 247750.959978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543418.894016 247750.959978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 069 397</ms:GML_ID>
        <ms:NAZWA>367 069 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367069397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547171.997000 249153.766000</gml:lowerCorner>
        		<gml:upperCorner>547171.997000 249153.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547171.997000 249153.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 293 293</ms:GML_ID>
        <ms:NAZWA>203 293 293</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203293293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546987.399604 250005.027382</gml:lowerCorner>
        		<gml:upperCorner>546987.399604 250005.027382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546987.399604 250005.027382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 292 421</ms:GML_ID>
        <ms:NAZWA>203 292 421</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203292421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540282.626306 250475.330051</gml:lowerCorner>
        		<gml:upperCorner>540282.626306 250475.330051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540282.626306 250475.330051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 065 234</ms:GML_ID>
        <ms:NAZWA>367 065 234</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367065234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546681.158000 251379.177000</gml:lowerCorner>
        		<gml:upperCorner>546681.158000 251379.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546681.158000 251379.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 291 013</ms:GML_ID>
        <ms:NAZWA>203 291 013</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203291013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546676.215000 251941.860000</gml:lowerCorner>
        		<gml:upperCorner>546676.215000 251941.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546676.215000 251941.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 290 448</ms:GML_ID>
        <ms:NAZWA>203 290 448</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203290448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538658.626000 252358.651000</gml:lowerCorner>
        		<gml:upperCorner>538658.626000 252358.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538658.626000 252358.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 062 732</ms:GML_ID>
        <ms:NAZWA>367 062 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367062732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546673.772000 252468.429000</gml:lowerCorner>
        		<gml:upperCorner>546673.772000 252468.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546673.772000 252468.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 289 923</ms:GML_ID>
        <ms:NAZWA>203 289 923</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203289923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546570.054000 253994.133000</gml:lowerCorner>
        		<gml:upperCorner>546570.054000 253994.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546570.054000 253994.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 288 393</ms:GML_ID>
        <ms:NAZWA>203 288 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203288393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538350.885000 254025.505000</gml:lowerCorner>
        		<gml:upperCorner>538350.885000 254025.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538350.885000 254025.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 061 035</ms:GML_ID>
        <ms:NAZWA>367 061 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367061035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538026.295000 254583.842000</gml:lowerCorner>
        		<gml:upperCorner>538026.295000 254583.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538026.295000 254583.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 060 388</ms:GML_ID>
        <ms:NAZWA>367 060 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367060388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546647.594000 254991.147000</gml:lowerCorner>
        		<gml:upperCorner>546647.594000 254991.147000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546647.594000 254991.147000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 287 393</ms:GML_ID>
        <ms:NAZWA>203 287 393</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203287393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537760.211000 255075.008000</gml:lowerCorner>
        		<gml:upperCorner>537760.211000 255075.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537760.211000 255075.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 059 830</ms:GML_ID>
        <ms:NAZWA>367 059 830</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367059830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535704.674000 256564.654000</gml:lowerCorner>
        		<gml:upperCorner>535704.674000 256564.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535704.674000 256564.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 057 109</ms:GML_ID>
        <ms:NAZWA>367 057 109</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367057109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548217.547738 258337.513777</gml:lowerCorner>
        		<gml:upperCorner>548217.547738 258337.513777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548217.547738 258337.513777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 283 594</ms:GML_ID>
        <ms:NAZWA>203 283 594</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203283594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548757.634430 258822.959196</gml:lowerCorner>
        		<gml:upperCorner>548757.634430 258822.959196</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548757.634430 258822.959196</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 282 870</ms:GML_ID>
        <ms:NAZWA>203 282 870</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203282870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549339.468988 259231.801321</gml:lowerCorner>
        		<gml:upperCorner>549339.468988 259231.801321</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549339.468988 259231.801321</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 282 155</ms:GML_ID>
        <ms:NAZWA>203 282 155</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203282155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549803.351000 259536.121000</gml:lowerCorner>
        		<gml:upperCorner>549803.351000 259536.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549803.351000 259536.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 281 602</ms:GML_ID>
        <ms:NAZWA>203 281 602</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203281602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550520.557000 260005.453000</gml:lowerCorner>
        		<gml:upperCorner>550520.557000 260005.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550520.557000 260005.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 280 746</ms:GML_ID>
        <ms:NAZWA>203 280 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203280746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552055.388663 261205.032699</gml:lowerCorner>
        		<gml:upperCorner>552055.388663 261205.032699</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552055.388663 261205.032699</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 278 787</ms:GML_ID>
        <ms:NAZWA>203 278 787</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203278787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552707.141000 262244.668000</gml:lowerCorner>
        		<gml:upperCorner>552707.141000 262244.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552707.141000 262244.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 277 559</ms:GML_ID>
        <ms:NAZWA>203 277 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203277559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553174.711184 263116.633412</gml:lowerCorner>
        		<gml:upperCorner>553174.711184 263116.633412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553174.711184 263116.633412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 276 570</ms:GML_ID>
        <ms:NAZWA>203 276 570</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203276570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535369.720077 303774.144662</gml:lowerCorner>
        		<gml:upperCorner>535369.720077 303774.144662</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535369.720077 303774.144662</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 039 380</ms:GML_ID>
        <ms:NAZWA>368 039 380</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368039380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535578.223000 304033.802000</gml:lowerCorner>
        		<gml:upperCorner>535578.223000 304033.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535578.223000 304033.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 039 042</ms:GML_ID>
        <ms:NAZWA>368 039 042</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368039042</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528948.037943 316266.181916</gml:lowerCorner>
        		<gml:upperCorner>528948.037943 316266.181916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528948.037943 316266.181916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 023 801</ms:GML_ID>
        <ms:NAZWA>368 023 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368023801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529121.813950 315889.246645</gml:lowerCorner>
        		<gml:upperCorner>529121.813950 315889.246645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529121.813950 315889.246645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 024 216</ms:GML_ID>
        <ms:NAZWA>368 024 216</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368024216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529310.598146 315479.678816</gml:lowerCorner>
        		<gml:upperCorner>529310.598146 315479.678816</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529310.598146 315479.678816</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 024 668</ms:GML_ID>
        <ms:NAZWA>368 024 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368024668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530290.745011 317999.752606</gml:lowerCorner>
        		<gml:upperCorner>530290.745011 317999.752606</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530290.745011 317999.752606</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 021 222</ms:GML_ID>
        <ms:NAZWA>368 021 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368021222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531135.670605 318439.452348</gml:lowerCorner>
        		<gml:upperCorner>531135.670605 318439.452348</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531135.670605 318439.452348</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 020 269</ms:GML_ID>
        <ms:NAZWA>368 020 269</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368020269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531525.481000 318782.515000</gml:lowerCorner>
        		<gml:upperCorner>531525.481000 318782.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531525.481000 318782.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 019 747</ms:GML_ID>
        <ms:NAZWA>368 019 747</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368019747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531951.812637 313591.427106</gml:lowerCorner>
        		<gml:upperCorner>531951.812637 313591.427106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531951.812637 313591.427106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 028 211</ms:GML_ID>
        <ms:NAZWA>368 028 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368028211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532444.098000 319818.721000</gml:lowerCorner>
        		<gml:upperCorner>532444.098000 319818.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532444.098000 319818.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 018 361</ms:GML_ID>
        <ms:NAZWA>368 018 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368018361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532726.622490 312595.072931</gml:lowerCorner>
        		<gml:upperCorner>532726.622490 312595.072931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532726.622490 312595.072931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 029 469</ms:GML_ID>
        <ms:NAZWA>368 029 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368029469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533061.798513 326505.923098</gml:lowerCorner>
        		<gml:upperCorner>533061.798513 326505.923098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533061.798513 326505.923098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 011 119</ms:GML_ID>
        <ms:NAZWA>368 011 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368011119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533137.046000 321356.583000</gml:lowerCorner>
        		<gml:upperCorner>533137.046000 321356.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533137.046000 321356.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 016 674</ms:GML_ID>
        <ms:NAZWA>368 016 674</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368016674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533343.062990 326048.240475</gml:lowerCorner>
        		<gml:upperCorner>533343.062990 326048.240475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533343.062990 326048.240475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 011 665</ms:GML_ID>
        <ms:NAZWA>368 011 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368011665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533623.921000 311503.583000</gml:lowerCorner>
        		<gml:upperCorner>533623.921000 311503.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533623.921000 311503.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 030 892</ms:GML_ID>
        <ms:NAZWA>368 030 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368030892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533863.344000 322979.944000</gml:lowerCorner>
        		<gml:upperCorner>533863.344000 322979.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533863.344000 322979.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 014 893</ms:GML_ID>
        <ms:NAZWA>368 014 893</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368014893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533936.329000 324335.817000</gml:lowerCorner>
        		<gml:upperCorner>533936.329000 324335.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533936.329000 324335.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 013 507</ms:GML_ID>
        <ms:NAZWA>368 013 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368013507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533993.577775 323818.408959</gml:lowerCorner>
        		<gml:upperCorner>533993.577775 323818.408959</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533993.577775 323818.408959</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 014 027</ms:GML_ID>
        <ms:NAZWA>368 014 027</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368014027</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540476.216000 325293.376000</gml:lowerCorner>
        		<gml:upperCorner>540476.216000 325293.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540476.216000 325293.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 049 199</ms:GML_ID>
        <ms:NAZWA>351 049 199</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351049199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540985.182119 323090.511727</gml:lowerCorner>
        		<gml:upperCorner>540985.182119 323090.511727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540985.182119 323090.511727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 051 464</ms:GML_ID>
        <ms:NAZWA>351 051 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351051464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541591.712130 321740.345150</gml:lowerCorner>
        		<gml:upperCorner>541591.712130 321740.345150</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541591.712130 321740.345150</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 052 956</ms:GML_ID>
        <ms:NAZWA>351 052 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351052956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542102.707461 320881.635896</gml:lowerCorner>
        		<gml:upperCorner>542102.707461 320881.635896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542102.707461 320881.635896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 053 954</ms:GML_ID>
        <ms:NAZWA>351 053 954</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351053954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543223.507000 319231.448000</gml:lowerCorner>
        		<gml:upperCorner>543223.507000 319231.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543223.507000 319231.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 055 952</ms:GML_ID>
        <ms:NAZWA>351 055 952</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351055952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539832.207000 326924.358000</gml:lowerCorner>
        		<gml:upperCorner>539832.207000 326924.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539832.207000 326924.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 047 437</ms:GML_ID>
        <ms:NAZWA>351 047 437</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351047437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532622.291208 327222.180830</gml:lowerCorner>
        		<gml:upperCorner>532622.291208 327222.180830</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532622.291208 327222.180830</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 010 279</ms:GML_ID>
        <ms:NAZWA>368 010 279</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368010279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532341.424263 327780.286520</gml:lowerCorner>
        		<gml:upperCorner>532341.424263 327780.286520</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532341.424263 327780.286520</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 009 652</ms:GML_ID>
        <ms:NAZWA>368 009 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368009652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532175.186542 328145.827259</gml:lowerCorner>
        		<gml:upperCorner>532175.186542 328145.827259</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532175.186542 328145.827259</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 009 249</ms:GML_ID>
        <ms:NAZWA>368 009 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368009249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537759.304000 328794.589000</gml:lowerCorner>
        		<gml:upperCorner>537759.304000 328794.589000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537759.304000 328794.589000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 044 643</ms:GML_ID>
        <ms:NAZWA>351 044 643</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351044643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530971.161299 330125.767074</gml:lowerCorner>
        		<gml:upperCorner>530971.161299 330125.767074</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530971.161299 330125.767074</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 006 866</ms:GML_ID>
        <ms:NAZWA>368 006 866</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368006866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536035.105000 330322.423000</gml:lowerCorner>
        		<gml:upperCorner>536035.105000 330322.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536035.105000 330322.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 042 338</ms:GML_ID>
        <ms:NAZWA>351 042 338</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351042338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530821.137451 330563.129404</gml:lowerCorner>
        		<gml:upperCorner>530821.137451 330563.129404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530821.137451 330563.129404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 006 404</ms:GML_ID>
        <ms:NAZWA>368 006 404</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368006404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530705.817000 330942.168000</gml:lowerCorner>
        		<gml:upperCorner>530705.817000 330942.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530705.817000 330942.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 006 007</ms:GML_ID>
        <ms:NAZWA>368 006 007</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368006007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534378.805000 331790.303000</gml:lowerCorner>
        		<gml:upperCorner>534378.805000 331790.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534378.805000 331790.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 040 125</ms:GML_ID>
        <ms:NAZWA>351 040 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351040125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533278.664000 332765.342000</gml:lowerCorner>
        		<gml:upperCorner>533278.664000 332765.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533278.664000 332765.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 038 654</ms:GML_ID>
        <ms:NAZWA>351 038 654</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351038654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532498.117000 333457.049000</gml:lowerCorner>
        		<gml:upperCorner>532498.117000 333457.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532498.117000 333457.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 037 611</ms:GML_ID>
        <ms:NAZWA>351 037 611</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351037611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530164.862000 333471.322000</gml:lowerCorner>
        		<gml:upperCorner>530164.862000 333471.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530164.862000 333471.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 003 397</ms:GML_ID>
        <ms:NAZWA>368 003 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368003397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530135.422340 334997.600693</gml:lowerCorner>
        		<gml:upperCorner>530135.422340 334997.600693</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530135.422340 334997.600693</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 001 867</ms:GML_ID>
        <ms:NAZWA>368 001 867</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368001867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530452.727000 335269.744000</gml:lowerCorner>
        		<gml:upperCorner>530452.727000 335269.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530452.727000 335269.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 034 878</ms:GML_ID>
        <ms:NAZWA>351 034 878</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351034878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529906.614000 335589.653000</gml:lowerCorner>
        		<gml:upperCorner>529906.614000 335589.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529906.614000 335589.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 001 230</ms:GML_ID>
        <ms:NAZWA>368 001 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368001230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530039.191356 335636.313608</gml:lowerCorner>
        		<gml:upperCorner>530039.191356 335636.313608</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530039.191356 335636.313608</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 034 322</ms:GML_ID>
        <ms:NAZWA>351 034 322</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351034322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529697.070000 335900.761000</gml:lowerCorner>
        		<gml:upperCorner>529697.070000 335900.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529697.070000 335900.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 000 850</ms:GML_ID>
        <ms:NAZWA>368 000 850</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368000850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529435.790565 336213.605309</gml:lowerCorner>
        		<gml:upperCorner>529435.790565 336213.605309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529435.790565 336213.605309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 033 485</ms:GML_ID>
        <ms:NAZWA>351 033 485</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351033485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529293.369991 336361.913861</gml:lowerCorner>
        		<gml:upperCorner>529293.369991 336361.913861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529293.369991 336361.913861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 033 281</ms:GML_ID>
        <ms:NAZWA>351 033 281</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351033281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528967.912093 336654.083329</gml:lowerCorner>
        		<gml:upperCorner>528967.912093 336654.083329</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528967.912093 336654.083329</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 032 857</ms:GML_ID>
        <ms:NAZWA>351 032 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351032857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527746.684879 338090.511383</gml:lowerCorner>
        		<gml:upperCorner>527746.684879 338090.511383</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527746.684879 338090.511383</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 030 966</ms:GML_ID>
        <ms:NAZWA>351 030 966</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351030966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.76">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525410.432038 205038.804924</gml:lowerCorner>
        		<gml:upperCorner>525410.432038 205038.804924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.76.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525410.432038 205038.804924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>76</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 246 862</ms:GML_ID>
        <ms:NAZWA>273 246 862</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273246862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.77">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527234.019000 205116.888000</gml:lowerCorner>
        		<gml:upperCorner>527234.019000 205116.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.77.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527234.019000 205116.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>77</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 248 687</ms:GML_ID>
        <ms:NAZWA>273 248 687</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273248687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.78">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532060.234254 204947.569389</gml:lowerCorner>
        		<gml:upperCorner>532060.234254 204947.569389</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.78.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532060.234254 204947.569389</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>78</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 253 548</ms:GML_ID>
        <ms:NAZWA>273 253 548</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273253548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.79">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532838.890424 204915.607075</gml:lowerCorner>
        		<gml:upperCorner>532838.890424 204915.607075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.79.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532838.890424 204915.607075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>79</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 254 328</ms:GML_ID>
        <ms:NAZWA>273 254 328</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273254328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.80">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533720.426000 205194.360000</gml:lowerCorner>
        		<gml:upperCorner>533720.426000 205194.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.80.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533720.426000 205194.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>80</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 255 262</ms:GML_ID>
        <ms:NAZWA>273 255 262</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273255262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534220.328494 205584.263739</gml:lowerCorner>
        		<gml:upperCorner>534220.328494 205584.263739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534220.328494 205584.263739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.827 001 091</ms:GML_ID>
        <ms:NAZWA>827 001 091</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>827001091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534674.335000 207790.389000</gml:lowerCorner>
        		<gml:upperCorner>534674.335000 207790.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534674.335000 207790.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 337 956</ms:GML_ID>
        <ms:NAZWA>203 337 956</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203337956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535280.531000 207697.184000</gml:lowerCorner>
        		<gml:upperCorner>535280.531000 207697.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535280.531000 207697.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 237 695</ms:GML_ID>
        <ms:NAZWA>430 237 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430237695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.81">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535916.226684 205094.655820</gml:lowerCorner>
        		<gml:upperCorner>535916.226684 205094.655820</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.81.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535916.226684 205094.655820</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>81</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 257 537</ms:GML_ID>
        <ms:NAZWA>273 257 537</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273257537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536068.581000 208918.106000</gml:lowerCorner>
        		<gml:upperCorner>536068.581000 208918.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536068.581000 208918.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 336 140</ms:GML_ID>
        <ms:NAZWA>203 336 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203336140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536384.855000 209347.157000</gml:lowerCorner>
        		<gml:upperCorner>536384.855000 209347.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536384.855000 209347.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 335 606</ms:GML_ID>
        <ms:NAZWA>203 335 606</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203335606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536561.953000 209601.394000</gml:lowerCorner>
        		<gml:upperCorner>536561.953000 209601.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536561.953000 209601.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 335 297</ms:GML_ID>
        <ms:NAZWA>203 335 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203335297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.82">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536697.740000 204628.684000</gml:lowerCorner>
        		<gml:upperCorner>536697.740000 204628.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.82.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536697.740000 204628.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>82</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 258 444</ms:GML_ID>
        <ms:NAZWA>273 258 444</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273258444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537182.674000 210519.236000</gml:lowerCorner>
        		<gml:upperCorner>537182.674000 210519.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537182.674000 210519.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 334 189</ms:GML_ID>
        <ms:NAZWA>203 334 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203334189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537436.192000 211393.788000</gml:lowerCorner>
        		<gml:upperCorner>537436.192000 211393.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537436.192000 211393.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 333 277</ms:GML_ID>
        <ms:NAZWA>203 333 277</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203333277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537686.793000 212023.275000</gml:lowerCorner>
        		<gml:upperCorner>537686.793000 212023.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537686.793000 212023.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 332 596</ms:GML_ID>
        <ms:NAZWA>203 332 596</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203332596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.83">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537689.912000 204108.111000</gml:lowerCorner>
        		<gml:upperCorner>537689.912000 204108.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.83.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537689.912000 204108.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>83</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 259 563</ms:GML_ID>
        <ms:NAZWA>273 259 563</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273259563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538873.721000 209102.623000</gml:lowerCorner>
        		<gml:upperCorner>538873.721000 209102.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538873.721000 209102.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 233 661</ms:GML_ID>
        <ms:NAZWA>430 233 661</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430233661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539928.325000 209209.505000</gml:lowerCorner>
        		<gml:upperCorner>539928.325000 209209.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539928.325000 209209.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 232 595</ms:GML_ID>
        <ms:NAZWA>430 232 595</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430232595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.84">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540751.968000 202336.778000</gml:lowerCorner>
        		<gml:upperCorner>540751.968000 202336.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.84.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540751.968000 202336.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>84</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 263 107</ms:GML_ID>
        <ms:NAZWA>273 263 107</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273263107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540957.294000 209174.972000</gml:lowerCorner>
        		<gml:upperCorner>540957.294000 209174.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540957.294000 209174.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 231 570</ms:GML_ID>
        <ms:NAZWA>430 231 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430231570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.85">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542453.714000 201279.334000</gml:lowerCorner>
        		<gml:upperCorner>542453.714000 201279.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.85.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542453.714000 201279.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>85</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 265 120</ms:GML_ID>
        <ms:NAZWA>273 265 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273265120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.86">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543758.625000 200773.647000</gml:lowerCorner>
        		<gml:upperCorner>543758.625000 200773.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.86.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543758.625000 200773.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>86</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 266 523</ms:GML_ID>
        <ms:NAZWA>273 266 523</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273266523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544290.490000 210414.962000</gml:lowerCorner>
        		<gml:upperCorner>544290.490000 210414.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544290.490000 210414.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 228 013</ms:GML_ID>
        <ms:NAZWA>430 228 013</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430228013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544486.868000 210492.019000</gml:lowerCorner>
        		<gml:upperCorner>544486.868000 210492.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544486.868000 210492.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 227 803</ms:GML_ID>
        <ms:NAZWA>430 227 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430227803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545677.182000 210404.182000</gml:lowerCorner>
        		<gml:upperCorner>545677.182000 210404.182000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545677.182000 210404.182000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.430 226 600</ms:GML_ID>
        <ms:NAZWA>430 226 600</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>430226600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527303.882000 282091.877000</gml:lowerCorner>
        		<gml:upperCorner>527303.882000 282091.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527303.882000 282091.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 071 438</ms:GML_ID>
        <ms:NAZWA>363 071 438</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363071438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527960.527000 282954.905000</gml:lowerCorner>
        		<gml:upperCorner>527960.527000 282954.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527960.527000 282954.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 070 349</ms:GML_ID>
        <ms:NAZWA>363 070 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363070349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528488.207252 283520.735664</gml:lowerCorner>
        		<gml:upperCorner>528488.207252 283520.735664</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528488.207252 283520.735664</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 069 574</ms:GML_ID>
        <ms:NAZWA>363 069 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363069574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530299.962000 286667.662000</gml:lowerCorner>
        		<gml:upperCorner>530299.962000 286667.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530299.962000 286667.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 065 483</ms:GML_ID>
        <ms:NAZWA>363 065 483</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363065483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530015.778000 289747.328000</gml:lowerCorner>
        		<gml:upperCorner>530015.778000 289747.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530015.778000 289747.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 055 126</ms:GML_ID>
        <ms:NAZWA>368 055 126</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368055126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528924.687000 289953.250000</gml:lowerCorner>
        		<gml:upperCorner>528924.687000 289953.250000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528924.687000 289953.250000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 002 092</ms:GML_ID>
        <ms:NAZWA>373 002 092</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373002092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526659.144000 289977.042000</gml:lowerCorner>
        		<gml:upperCorner>526659.144000 289977.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526659.144000 289977.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 004 363</ms:GML_ID>
        <ms:NAZWA>373 004 363</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373004363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527412.052000 290004.291000</gml:lowerCorner>
        		<gml:upperCorner>527412.052000 290004.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527412.052000 290004.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 003 609</ms:GML_ID>
        <ms:NAZWA>373 003 609</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373003609</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528451.398000 290007.122000</gml:lowerCorner>
        		<gml:upperCorner>528451.398000 290007.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528451.398000 290007.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 002 568</ms:GML_ID>
        <ms:NAZWA>373 002 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373002568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530595.257412 290625.189083</gml:lowerCorner>
        		<gml:upperCorner>530595.257412 290625.189083</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530595.257412 290625.189083</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 053 877</ms:GML_ID>
        <ms:NAZWA>368 053 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368053877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531109.940000 290923.114000</gml:lowerCorner>
        		<gml:upperCorner>531109.940000 290923.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531109.940000 290923.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 053 279</ms:GML_ID>
        <ms:NAZWA>368 053 279</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368053279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531220.301657 290988.036961</gml:lowerCorner>
        		<gml:upperCorner>531220.301657 290988.036961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531220.301657 290988.036961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 053 146</ms:GML_ID>
        <ms:NAZWA>368 053 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368053146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531497.897889 291314.552125</gml:lowerCorner>
        		<gml:upperCorner>531497.897889 291314.552125</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531497.897889 291314.552125</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 052 716</ms:GML_ID>
        <ms:NAZWA>368 052 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368052716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524930.084370 291472.538828</gml:lowerCorner>
        		<gml:upperCorner>524930.084370 291472.538828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524930.084370 291472.538828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 006 907</ms:GML_ID>
        <ms:NAZWA>373 006 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373006907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521586.307000 291866.274000</gml:lowerCorner>
        		<gml:upperCorner>521586.307000 291866.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521586.307000 291866.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 010 393</ms:GML_ID>
        <ms:NAZWA>373 010 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373010393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521053.823000 291925.152000</gml:lowerCorner>
        		<gml:upperCorner>521053.823000 291925.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521053.823000 291925.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 010 931</ms:GML_ID>
        <ms:NAZWA>373 010 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373010931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523028.151000 291970.291000</gml:lowerCorner>
        		<gml:upperCorner>523028.151000 291970.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523028.151000 291970.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 008 946</ms:GML_ID>
        <ms:NAZWA>373 008 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373008946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532692.612815 293800.645400</gml:lowerCorner>
        		<gml:upperCorner>532692.612815 293800.645400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532692.612815 293800.645400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 049 946</ms:GML_ID>
        <ms:NAZWA>368 049 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368049946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532950.474000 294289.909000</gml:lowerCorner>
        		<gml:upperCorner>532950.474000 294289.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532950.474000 294289.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 049 387</ms:GML_ID>
        <ms:NAZWA>368 049 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368049387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533144.126000 294980.099000</gml:lowerCorner>
        		<gml:upperCorner>533144.126000 294980.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533144.126000 294980.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 048 671</ms:GML_ID>
        <ms:NAZWA>368 048 671</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368048671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533407.580921 295992.128550</gml:lowerCorner>
        		<gml:upperCorner>533407.580921 295992.128550</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533407.580921 295992.128550</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 047 614</ms:GML_ID>
        <ms:NAZWA>368 047 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368047614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533350.313973 296576.856618</gml:lowerCorner>
        		<gml:upperCorner>533350.313973 296576.856618</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533350.313973 296576.856618</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 047 025</ms:GML_ID>
        <ms:NAZWA>368 047 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368047025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533321.081218 296877.252070</gml:lowerCorner>
        		<gml:upperCorner>533321.081218 296877.252070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533321.081218 296877.252070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 046 725</ms:GML_ID>
        <ms:NAZWA>368 046 725</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368046725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533293.255000 297293.780000</gml:lowerCorner>
        		<gml:upperCorner>533293.255000 297293.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533293.255000 297293.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 046 307</ms:GML_ID>
        <ms:NAZWA>368 046 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368046307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533380.144000 298622.149000</gml:lowerCorner>
        		<gml:upperCorner>533380.144000 298622.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533380.144000 298622.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 044 976</ms:GML_ID>
        <ms:NAZWA>368 044 976</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368044976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533444.425000 299555.649000</gml:lowerCorner>
        		<gml:upperCorner>533444.425000 299555.649000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533444.425000 299555.649000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 044 039</ms:GML_ID>
        <ms:NAZWA>368 044 039</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368044039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533714.621000 300380.493000</gml:lowerCorner>
        		<gml:upperCorner>533714.621000 300380.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533714.621000 300380.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 043 166</ms:GML_ID>
        <ms:NAZWA>368 043 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368043166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534173.283039 301310.522893</gml:lowerCorner>
        		<gml:upperCorner>534173.283039 301310.522893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534173.283039 301310.522893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 042 127</ms:GML_ID>
        <ms:NAZWA>368 042 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368042127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534474.711000 301941.648000</gml:lowerCorner>
        		<gml:upperCorner>534474.711000 301941.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534474.711000 301941.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 041 428</ms:GML_ID>
        <ms:NAZWA>368 041 428</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368041428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534580.030270 302341.117468</gml:lowerCorner>
        		<gml:upperCorner>534580.030270 302341.117468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534580.030270 302341.117468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 041 015</ms:GML_ID>
        <ms:NAZWA>368 041 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>368041015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535214.875000 307349.295000</gml:lowerCorner>
        		<gml:upperCorner>535214.875000 307349.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535214.875000 307349.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.368 035 370</ms:GML_ID>
        <ms:NAZWA>368 035 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>368035370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534726.841000 256868.738000</gml:lowerCorner>
        		<gml:upperCorner>534726.841000 256868.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534726.841000 256868.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 056 086</ms:GML_ID>
        <ms:NAZWA>367 056 086</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367056086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532222.988000 258800.791000</gml:lowerCorner>
        		<gml:upperCorner>532222.988000 258800.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532222.988000 258800.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 052 877</ms:GML_ID>
        <ms:NAZWA>367 052 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367052877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531773.917000 259833.618000</gml:lowerCorner>
        		<gml:upperCorner>531773.917000 259833.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531773.917000 259833.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 051 750</ms:GML_ID>
        <ms:NAZWA>367 051 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367051750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531316.520000 261064.138000</gml:lowerCorner>
        		<gml:upperCorner>531316.520000 261064.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531316.520000 261064.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 050 437</ms:GML_ID>
        <ms:NAZWA>367 050 437</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367050437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531085.756000 261992.696000</gml:lowerCorner>
        		<gml:upperCorner>531085.756000 261992.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531085.756000 261992.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 049 489</ms:GML_ID>
        <ms:NAZWA>367 049 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367049489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531009.422000 262493.645000</gml:lowerCorner>
        		<gml:upperCorner>531009.422000 262493.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531009.422000 262493.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 048 968</ms:GML_ID>
        <ms:NAZWA>367 048 968</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367048968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530825.556472 262805.648166</gml:lowerCorner>
        		<gml:upperCorner>530825.556472 262805.648166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530825.556472 262805.648166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 048 605</ms:GML_ID>
        <ms:NAZWA>367 048 605</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367048605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530362.726194 263500.223141</gml:lowerCorner>
        		<gml:upperCorner>530362.726194 263500.223141</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530362.726194 263500.223141</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 047 771</ms:GML_ID>
        <ms:NAZWA>367 047 771</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367047771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528182.144559 263862.947520</gml:lowerCorner>
        		<gml:upperCorner>528182.144559 263862.947520</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528182.144559 263862.947520</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 045 525</ms:GML_ID>
        <ms:NAZWA>367 045 525</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367045525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527593.781784 263920.794223</gml:lowerCorner>
        		<gml:upperCorner>527593.781784 263920.794223</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527593.781784 263920.794223</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 044 933</ms:GML_ID>
        <ms:NAZWA>367 044 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367044933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524333.319000 264240.542000</gml:lowerCorner>
        		<gml:upperCorner>524333.319000 264240.542000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524333.319000 264240.542000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 041 658</ms:GML_ID>
        <ms:NAZWA>367 041 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367041658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521823.139000 264482.551000</gml:lowerCorner>
        		<gml:upperCorner>521823.139000 264482.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521823.139000 264482.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 039 136</ms:GML_ID>
        <ms:NAZWA>367 039 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367039136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528200.494936 266600.903039</gml:lowerCorner>
        		<gml:upperCorner>528200.494936 266600.903039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528200.494936 266600.903039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 088 031</ms:GML_ID>
        <ms:NAZWA>363 088 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363088031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528664.931000 267289.409000</gml:lowerCorner>
        		<gml:upperCorner>528664.931000 267289.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528664.931000 267289.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 087 159</ms:GML_ID>
        <ms:NAZWA>363 087 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363087159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529105.858000 267679.117000</gml:lowerCorner>
        		<gml:upperCorner>529105.858000 267679.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529105.858000 267679.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 086 573</ms:GML_ID>
        <ms:NAZWA>363 086 573</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363086573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528920.025000 269352.160000</gml:lowerCorner>
        		<gml:upperCorner>528920.025000 269352.160000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528920.025000 269352.160000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 084 849</ms:GML_ID>
        <ms:NAZWA>363 084 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363084849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528754.967000 271996.239000</gml:lowerCorner>
        		<gml:upperCorner>528754.967000 271996.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528754.967000 271996.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 082 178</ms:GML_ID>
        <ms:NAZWA>363 082 178</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363082178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528830.201022 273142.573685</gml:lowerCorner>
        		<gml:upperCorner>528830.201022 273142.573685</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528830.201022 273142.573685</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 081 030</ms:GML_ID>
        <ms:NAZWA>363 081 030</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363081030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529089.658471 274524.315032</gml:lowerCorner>
        		<gml:upperCorner>529089.658471 274524.315032</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529089.658471 274524.315032</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 079 620</ms:GML_ID>
        <ms:NAZWA>363 079 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363079620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529170.415393 275373.960174</gml:lowerCorner>
        		<gml:upperCorner>529170.415393 275373.960174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529170.415393 275373.960174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 078 746</ms:GML_ID>
        <ms:NAZWA>363 078 746</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363078746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528781.621100 276160.174435</gml:lowerCorner>
        		<gml:upperCorner>528781.621100 276160.174435</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528781.621100 276160.174435</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 077 868</ms:GML_ID>
        <ms:NAZWA>363 077 868</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363077868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528258.976778 277359.238188</gml:lowerCorner>
        		<gml:upperCorner>528258.976778 277359.238188</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528258.976778 277359.238188</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 076 560</ms:GML_ID>
        <ms:NAZWA>363 076 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363076560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527824.562569 278861.111863</gml:lowerCorner>
        		<gml:upperCorner>527824.562569 278861.111863</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527824.562569 278861.111863</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 074 991</ms:GML_ID>
        <ms:NAZWA>363 074 991</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363074991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527508.160000 279644.653000</gml:lowerCorner>
        		<gml:upperCorner>527508.160000 279644.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527508.160000 279644.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 074 128</ms:GML_ID>
        <ms:NAZWA>363 074 128</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363074128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523353.352000 280599.446000</gml:lowerCorner>
        		<gml:upperCorner>523353.352000 280599.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523353.352000 280599.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 004 315</ms:GML_ID>
        <ms:NAZWA>364 004 315</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364004315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521969.107000 280682.039000</gml:lowerCorner>
        		<gml:upperCorner>521969.107000 280682.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521969.107000 280682.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 005 705</ms:GML_ID>
        <ms:NAZWA>364 005 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364005705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524763.440000 280860.618000</gml:lowerCorner>
        		<gml:upperCorner>524763.440000 280860.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524763.440000 280860.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 002 869</ms:GML_ID>
        <ms:NAZWA>364 002 869</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364002869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521310.118000 280923.453000</gml:lowerCorner>
        		<gml:upperCorner>521310.118000 280923.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521310.118000 280923.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 006 407</ms:GML_ID>
        <ms:NAZWA>364 006 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364006407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525172.309000 280988.662000</gml:lowerCorner>
        		<gml:upperCorner>525172.309000 280988.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525172.309000 280988.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 002 440</ms:GML_ID>
        <ms:NAZWA>364 002 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364002440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525619.041000 281128.473000</gml:lowerCorner>
        		<gml:upperCorner>525619.041000 281128.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525619.041000 281128.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 001 973</ms:GML_ID>
        <ms:NAZWA>364 001 973</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364001973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520562.987000 281221.306000</gml:lowerCorner>
        		<gml:upperCorner>520562.987000 281221.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520562.987000 281221.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 007 212</ms:GML_ID>
        <ms:NAZWA>364 007 212</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364007212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525930.842000 281225.727000</gml:lowerCorner>
        		<gml:upperCorner>525930.842000 281225.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525930.842000 281225.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 001 646</ms:GML_ID>
        <ms:NAZWA>364 001 646</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364001646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526954.626000 281408.478000</gml:lowerCorner>
        		<gml:upperCorner>526954.626000 281408.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526954.626000 281408.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.363 072 206</ms:GML_ID>
        <ms:NAZWA>363 072 206</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>363072206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526478.453000 339590.411000</gml:lowerCorner>
        		<gml:upperCorner>526478.453000 339590.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526478.453000 339590.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 028 995</ms:GML_ID>
        <ms:NAZWA>351 028 995</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351028995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524100.110798 342307.180942</gml:lowerCorner>
        		<gml:upperCorner>524100.110798 342307.180942</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524100.110798 342307.180942</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 025 382</ms:GML_ID>
        <ms:NAZWA>351 025 382</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351025382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523475.503000 343020.927000</gml:lowerCorner>
        		<gml:upperCorner>523475.503000 343020.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523475.503000 343020.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 024 434</ms:GML_ID>
        <ms:NAZWA>351 024 434</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351024434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521775.687000 344634.337000</gml:lowerCorner>
        		<gml:upperCorner>521775.687000 344634.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521775.687000 344634.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 022 087</ms:GML_ID>
        <ms:NAZWA>351 022 087</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351022087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520163.834000 346156.838000</gml:lowerCorner>
        		<gml:upperCorner>520163.834000 346156.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520163.834000 346156.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 019 871</ms:GML_ID>
        <ms:NAZWA>351 019 871</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351019871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528223.162478 352480.456208</gml:lowerCorner>
        		<gml:upperCorner>528223.162478 352480.456208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528223.162478 352480.456208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 021 141</ms:GML_ID>
        <ms:NAZWA>354 021 141</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354021141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527574.083000 352502.111000</gml:lowerCorner>
        		<gml:upperCorner>527574.083000 352502.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527574.083000 352502.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 020 491</ms:GML_ID>
        <ms:NAZWA>354 020 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354020491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526967.966104 352512.411144</gml:lowerCorner>
        		<gml:upperCorner>526967.966104 352512.411144</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526967.966104 352512.411144</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 019 890</ms:GML_ID>
        <ms:NAZWA>354 019 890</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354019890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533185.230140 352551.770178</gml:lowerCorner>
        		<gml:upperCorner>533185.230140 352551.770178</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533185.230140 352551.770178</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 026 126</ms:GML_ID>
        <ms:NAZWA>354 026 126</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354026126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526069.832000 352553.799000</gml:lowerCorner>
        		<gml:upperCorner>526069.832000 352553.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526069.832000 352553.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 018 986</ms:GML_ID>
        <ms:NAZWA>354 018 986</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354018986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525343.708000 352578.961000</gml:lowerCorner>
        		<gml:upperCorner>525343.708000 352578.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525343.708000 352578.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 018 259</ms:GML_ID>
        <ms:NAZWA>354 018 259</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354018259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523806.985000 352633.194000</gml:lowerCorner>
        		<gml:upperCorner>523806.985000 352633.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523806.985000 352633.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 016 722</ms:GML_ID>
        <ms:NAZWA>354 016 722</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354016722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522392.068000 352680.634000</gml:lowerCorner>
        		<gml:upperCorner>522392.068000 352680.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522392.068000 352680.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 015 305</ms:GML_ID>
        <ms:NAZWA>354 015 305</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354015305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521005.273000 352729.094000</gml:lowerCorner>
        		<gml:upperCorner>521005.273000 352729.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521005.273000 352729.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 013 916</ms:GML_ID>
        <ms:NAZWA>354 013 916</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354013916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519932.995000 352764.786000</gml:lowerCorner>
        		<gml:upperCorner>519932.995000 352764.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519932.995000 352764.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 012 844</ms:GML_ID>
        <ms:NAZWA>354 012 844</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354012844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534156.760333 352773.504561</gml:lowerCorner>
        		<gml:upperCorner>534156.760333 352773.504561</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534156.760333 352773.504561</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 027 127</ms:GML_ID>
        <ms:NAZWA>354 027 127</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354027127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535165.727764 353901.820163</gml:lowerCorner>
        		<gml:upperCorner>535165.727764 353901.820163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535165.727764 353901.820163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 028 630</ms:GML_ID>
        <ms:NAZWA>354 028 630</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354028630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536281.520066 355316.666984</gml:lowerCorner>
        		<gml:upperCorner>536281.520066 355316.666984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536281.520066 355316.666984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 030 453</ms:GML_ID>
        <ms:NAZWA>354 030 453</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354030453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536882.370547 356074.513541</gml:lowerCorner>
        		<gml:upperCorner>536882.370547 356074.513541</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536882.370547 356074.513541</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 031 418</ms:GML_ID>
        <ms:NAZWA>354 031 418</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354031418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537938.029000 357289.555000</gml:lowerCorner>
        		<gml:upperCorner>537938.029000 357289.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537938.029000 357289.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 033 031</ms:GML_ID>
        <ms:NAZWA>354 033 031</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354033031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538551.042000 357705.753000</gml:lowerCorner>
        		<gml:upperCorner>538551.042000 357705.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538551.042000 357705.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 033 777</ms:GML_ID>
        <ms:NAZWA>354 033 777</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354033777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539474.691000 358533.858000</gml:lowerCorner>
        		<gml:upperCorner>539474.691000 358533.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539474.691000 358533.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 035 028</ms:GML_ID>
        <ms:NAZWA>354 035 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354035028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514514.250000 251768.714000</gml:lowerCorner>
        		<gml:upperCorner>514514.250000 251768.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514514.250000 251768.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 040 750</ms:GML_ID>
        <ms:NAZWA>364 040 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364040750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514671.788213 257942.862976</gml:lowerCorner>
        		<gml:upperCorner>514671.788213 257942.862976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514671.788213 257942.862976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 034 273</ms:GML_ID>
        <ms:NAZWA>364 034 273</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364034273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514707.445219 267970.847813</gml:lowerCorner>
        		<gml:upperCorner>514707.445219 267970.847813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514707.445219 267970.847813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 030 601</ms:GML_ID>
        <ms:NAZWA>367 030 601</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367030601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514805.824000 261082.119000</gml:lowerCorner>
        		<gml:upperCorner>514805.824000 261082.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514805.824000 261082.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 030 567</ms:GML_ID>
        <ms:NAZWA>364 030 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364030567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514859.393632 267700.916430</gml:lowerCorner>
        		<gml:upperCorner>514859.393632 267700.916430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514859.393632 267700.916430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 023 894</ms:GML_ID>
        <ms:NAZWA>364 023 894</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364023894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514897.734292 267743.525052</gml:lowerCorner>
        		<gml:upperCorner>514897.734292 267743.525052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514897.734292 267743.525052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 030 894</ms:GML_ID>
        <ms:NAZWA>367 030 894</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367030894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514898.316000 267540.150000</gml:lowerCorner>
        		<gml:upperCorner>514898.316000 267540.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514898.316000 267540.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 024 062</ms:GML_ID>
        <ms:NAZWA>364 024 062</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364024062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515016.311000 263394.458000</gml:lowerCorner>
        		<gml:upperCorner>515016.311000 263394.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515016.311000 263394.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 028 244</ms:GML_ID>
        <ms:NAZWA>364 028 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364028244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515115.996000 266283.677000</gml:lowerCorner>
        		<gml:upperCorner>515115.996000 266283.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515115.996000 266283.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 025 338</ms:GML_ID>
        <ms:NAZWA>364 025 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364025338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515135.833298 264627.175908</gml:lowerCorner>
        		<gml:upperCorner>515135.833298 264627.175908</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515135.833298 264627.175908</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 027 005</ms:GML_ID>
        <ms:NAZWA>364 027 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364027005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515211.016458 265728.858146</gml:lowerCorner>
        		<gml:upperCorner>515211.016458 265728.858146</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515211.016458 265728.858146</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 025 900</ms:GML_ID>
        <ms:NAZWA>364 025 900</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364025900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515327.884000 254454.493000</gml:lowerCorner>
        		<gml:upperCorner>515327.884000 254454.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515327.884000 254454.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 037 864</ms:GML_ID>
        <ms:NAZWA>364 037 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364037864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515388.005042 267527.194104</gml:lowerCorner>
        		<gml:upperCorner>515388.005042 267527.194104</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515388.005042 267527.194104</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 031 435</ms:GML_ID>
        <ms:NAZWA>367 031 435</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367031435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516587.787000 266907.517000</gml:lowerCorner>
        		<gml:upperCorner>516587.787000 266907.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516587.787000 266907.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 032 788</ms:GML_ID>
        <ms:NAZWA>367 032 788</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367032788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517363.645000 266499.662000</gml:lowerCorner>
        		<gml:upperCorner>517363.645000 266499.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517363.645000 266499.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 033 665</ms:GML_ID>
        <ms:NAZWA>367 033 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367033665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518049.055000 266090.907000</gml:lowerCorner>
        		<gml:upperCorner>518049.055000 266090.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518049.055000 266090.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 034 474</ms:GML_ID>
        <ms:NAZWA>367 034 474</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367034474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518070.625000 266057.881000</gml:lowerCorner>
        		<gml:upperCorner>518070.625000 266057.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518070.625000 266057.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 034 515</ms:GML_ID>
        <ms:NAZWA>367 034 515</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367034515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518721.443000 265024.510000</gml:lowerCorner>
        		<gml:upperCorner>518721.443000 265024.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518721.443000 265024.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 035 736</ms:GML_ID>
        <ms:NAZWA>367 035 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367035736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518885.103000 264693.310000</gml:lowerCorner>
        		<gml:upperCorner>518885.103000 264693.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518885.103000 264693.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 036 106</ms:GML_ID>
        <ms:NAZWA>367 036 106</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367036106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510579.383000 353089.686000</gml:lowerCorner>
        		<gml:upperCorner>510579.383000 353089.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510579.383000 353089.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 007 747</ms:GML_ID>
        <ms:NAZWA>351 007 747</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351007747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511261.601000 355963.647000</gml:lowerCorner>
        		<gml:upperCorner>511261.601000 355963.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511261.601000 355963.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 003 391</ms:GML_ID>
        <ms:NAZWA>354 003 391</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354003391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512057.954000 352111.675000</gml:lowerCorner>
        		<gml:upperCorner>512057.954000 352111.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512057.954000 352111.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 009 528</ms:GML_ID>
        <ms:NAZWA>351 009 528</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351009528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512722.211000 355000.997000</gml:lowerCorner>
        		<gml:upperCorner>512722.211000 355000.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512722.211000 355000.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 005 141</ms:GML_ID>
        <ms:NAZWA>354 005 141</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354005141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513057.490000 358644.535000</gml:lowerCorner>
        		<gml:upperCorner>513057.490000 358644.535000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513057.490000 358644.535000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 011 400</ms:GML_ID>
        <ms:NAZWA>395 011 400</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395011400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513125.790000 357427.154000</gml:lowerCorner>
        		<gml:upperCorner>513125.790000 357427.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513125.790000 357427.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 012 640</ms:GML_ID>
        <ms:NAZWA>395 012 640</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395012640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513146.379098 355367.562504</gml:lowerCorner>
        		<gml:upperCorner>513146.379098 355367.562504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513146.379098 355367.562504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 014 712</ms:GML_ID>
        <ms:NAZWA>395 014 712</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395014712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513192.460000 358270.526000</gml:lowerCorner>
        		<gml:upperCorner>513192.460000 358270.526000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513192.460000 358270.526000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 011 783</ms:GML_ID>
        <ms:NAZWA>395 011 783</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395011783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513429.688746 353617.647638</gml:lowerCorner>
        		<gml:upperCorner>513429.688746 353617.647638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513429.688746 353617.647638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 016 490</ms:GML_ID>
        <ms:NAZWA>395 016 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395016490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513984.606000 351702.983000</gml:lowerCorner>
        		<gml:upperCorner>513984.606000 351702.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513984.606000 351702.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 018 488</ms:GML_ID>
        <ms:NAZWA>395 018 488</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395018488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514035.050000 350765.200000</gml:lowerCorner>
        		<gml:upperCorner>514035.050000 350765.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514035.050000 350765.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 011 953</ms:GML_ID>
        <ms:NAZWA>351 011 953</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351011953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514046.698806 354152.530102</gml:lowerCorner>
        		<gml:upperCorner>514046.698806 354152.530102</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514046.698806 354152.530102</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 006 714</ms:GML_ID>
        <ms:NAZWA>354 006 714</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354006714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514105.451075 350763.547144</gml:lowerCorner>
        		<gml:upperCorner>514105.451075 350763.547144</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514105.451075 350763.547144</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 019 440</ms:GML_ID>
        <ms:NAZWA>395 019 440</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395019440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514823.868017 349747.866731</gml:lowerCorner>
        		<gml:upperCorner>514823.868017 349747.866731</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514823.868017 349747.866731</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 013 286</ms:GML_ID>
        <ms:NAZWA>351 013 286</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351013286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515278.952000 353673.820000</gml:lowerCorner>
        		<gml:upperCorner>515278.952000 353673.820000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515278.952000 353673.820000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 008 037</ms:GML_ID>
        <ms:NAZWA>354 008 037</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354008037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515967.576000 349308.813000</gml:lowerCorner>
        		<gml:upperCorner>515967.576000 349308.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515967.576000 349308.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 014 520</ms:GML_ID>
        <ms:NAZWA>351 014 520</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351014520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516098.955796 353356.010878</gml:lowerCorner>
        		<gml:upperCorner>516098.955796 353356.010878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516098.955796 353356.010878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 008 917</ms:GML_ID>
        <ms:NAZWA>354 008 917</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354008917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516905.567945 353034.594649</gml:lowerCorner>
        		<gml:upperCorner>516905.567945 353034.594649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516905.567945 353034.594649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 009 785</ms:GML_ID>
        <ms:NAZWA>354 009 785</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354009785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518684.411000 347562.388000</gml:lowerCorner>
        		<gml:upperCorner>518684.411000 347562.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518684.411000 347562.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 017 835</ms:GML_ID>
        <ms:NAZWA>351 017 835</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351017835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519229.067000 347040.356000</gml:lowerCorner>
        		<gml:upperCorner>519229.067000 347040.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519229.067000 347040.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 018 591</ms:GML_ID>
        <ms:NAZWA>351 018 591</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351018591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505748.004482 199924.297276</gml:lowerCorner>
        		<gml:upperCorner>505748.004482 199924.297276</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505748.004482 199924.297276</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 476 067</ms:GML_ID>
        <ms:NAZWA>003 476 067</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003476067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506233.166793 202887.491592</gml:lowerCorner>
        		<gml:upperCorner>506233.166793 202887.491592</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506233.166793 202887.491592</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 473 000</ms:GML_ID>
        <ms:NAZWA>003 473 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003473000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506270.174865 202896.648061</gml:lowerCorner>
        		<gml:upperCorner>506270.174865 202896.648061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506270.174865 202896.648061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 472 998</ms:GML_ID>
        <ms:NAZWA>003 472 998</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003472998</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506290.696254 204107.139831</gml:lowerCorner>
        		<gml:upperCorner>506290.696254 204107.139831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506290.696254 204107.139831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 471 787</ms:GML_ID>
        <ms:NAZWA>003 471 787</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003471787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506333.251842 206443.102964</gml:lowerCorner>
        		<gml:upperCorner>506333.251842 206443.102964</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506333.251842 206443.102964</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 469 451</ms:GML_ID>
        <ms:NAZWA>003 469 451</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003469451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.75">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522668.327419 206960.835437</gml:lowerCorner>
        		<gml:upperCorner>522668.327419 206960.835437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.75.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522668.327419 206960.835437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>75</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 243 184</ms:GML_ID>
        <ms:NAZWA>273 243 184</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273243184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506356.737539 207510.181449</gml:lowerCorner>
        		<gml:upperCorner>506356.737539 207510.181449</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506356.737539 207510.181449</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 468 384</ms:GML_ID>
        <ms:NAZWA>003 468 384</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003468384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520493.486000 208288.906000</gml:lowerCorner>
        		<gml:upperCorner>520493.486000 208288.906000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520493.486000 208288.906000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 240 546</ms:GML_ID>
        <ms:NAZWA>273 240 546</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273240546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519319.935104 208743.099793</gml:lowerCorner>
        		<gml:upperCorner>519319.935104 208743.099793</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519319.935104 208743.099793</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 239 289</ms:GML_ID>
        <ms:NAZWA>273 239 289</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273239289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518097.541508 209361.630033</gml:lowerCorner>
        		<gml:upperCorner>518097.541508 209361.630033</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518097.541508 209361.630033</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 237 916</ms:GML_ID>
        <ms:NAZWA>273 237 916</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273237916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517253.545724 209986.212892</gml:lowerCorner>
        		<gml:upperCorner>517253.545724 209986.212892</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517253.545724 209986.212892</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 236 871</ms:GML_ID>
        <ms:NAZWA>273 236 871</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273236871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506419.452376 210197.834955</gml:lowerCorner>
        		<gml:upperCorner>506419.452376 210197.834955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506419.452376 210197.834955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 465 693</ms:GML_ID>
        <ms:NAZWA>003 465 693</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003465693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515771.591803 210711.909071</gml:lowerCorner>
        		<gml:upperCorner>515771.591803 210711.909071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515771.591803 210711.909071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 235 191</ms:GML_ID>
        <ms:NAZWA>273 235 191</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273235191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513215.508000 211291.931000</gml:lowerCorner>
        		<gml:upperCorner>513215.508000 211291.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513215.508000 211291.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 232 574</ms:GML_ID>
        <ms:NAZWA>273 232 574</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273232574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512995.140983 211341.426828</gml:lowerCorner>
        		<gml:upperCorner>512995.140983 211341.426828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512995.140983 211341.426828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 232 347</ms:GML_ID>
        <ms:NAZWA>273 232 347</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273232347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512335.684000 211501.424000</gml:lowerCorner>
        		<gml:upperCorner>512335.684000 211501.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512335.684000 211501.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 231 668</ms:GML_ID>
        <ms:NAZWA>273 231 668</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273231668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512139.240000 211575.698000</gml:lowerCorner>
        		<gml:upperCorner>512139.240000 211575.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512139.240000 211575.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 231 454</ms:GML_ID>
        <ms:NAZWA>273 231 454</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>273231454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506454.639000 211723.188000</gml:lowerCorner>
        		<gml:upperCorner>506454.639000 211723.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506454.639000 211723.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 464 174</ms:GML_ID>
        <ms:NAZWA>003 464 174</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003464174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508850.239124 212258.558218</gml:lowerCorner>
        		<gml:upperCorner>508850.239124 212258.558218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508850.239124 212258.558218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 228 079</ms:GML_ID>
        <ms:NAZWA>273 228 079</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273228079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508179.748000 212517.406000</gml:lowerCorner>
        		<gml:upperCorner>508179.748000 212517.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508179.748000 212517.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 227 362</ms:GML_ID>
        <ms:NAZWA>273 227 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>273227362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506450.980955 215316.491707</gml:lowerCorner>
        		<gml:upperCorner>506450.980955 215316.491707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506450.980955 215316.491707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.981 000 171</ms:GML_ID>
        <ms:NAZWA>981 000 171</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>981000171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506420.566000 215338.017000</gml:lowerCorner>
        		<gml:upperCorner>506420.566000 215338.017000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506420.566000 215338.017000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.821 005 280</ms:GML_ID>
        <ms:NAZWA>821 005 280</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>821005280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505943.028000 215772.818000</gml:lowerCorner>
        		<gml:upperCorner>505943.028000 215772.818000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505943.028000 215772.818000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.821 004 604</ms:GML_ID>
        <ms:NAZWA>821 004 604</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>821004604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506554.855503 215781.387816</gml:lowerCorner>
        		<gml:upperCorner>506554.855503 215781.387816</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506554.855503 215781.387816</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 088 317</ms:GML_ID>
        <ms:NAZWA>364 088 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>364088317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506503.049167 215853.601757</gml:lowerCorner>
        		<gml:upperCorner>506503.049167 215853.601757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506503.049167 215853.601757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 460 037</ms:GML_ID>
        <ms:NAZWA>003 460 037</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003460037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506846.807000 216180.668000</gml:lowerCorner>
        		<gml:upperCorner>506846.807000 216180.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506846.807000 216180.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 087 817</ms:GML_ID>
        <ms:NAZWA>364 087 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>364087817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506408.491020 216329.085000</gml:lowerCorner>
        		<gml:upperCorner>506408.491020 216329.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506408.491020 216329.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 459 555</ms:GML_ID>
        <ms:NAZWA>003 459 555</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003459555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508932.764000 216612.198000</gml:lowerCorner>
        		<gml:upperCorner>508932.764000 216612.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508932.764000 216612.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 085 635</ms:GML_ID>
        <ms:NAZWA>364 085 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364085635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509290.013000 216705.098000</gml:lowerCorner>
        		<gml:upperCorner>509290.013000 216705.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509290.013000 216705.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 085 262</ms:GML_ID>
        <ms:NAZWA>364 085 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364085262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509766.893000 216884.012000</gml:lowerCorner>
        		<gml:upperCorner>509766.893000 216884.012000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509766.893000 216884.012000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 084 751</ms:GML_ID>
        <ms:NAZWA>364 084 751</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364084751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510393.492000 217250.263000</gml:lowerCorner>
        		<gml:upperCorner>510393.492000 217250.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510393.492000 217250.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 084 026</ms:GML_ID>
        <ms:NAZWA>364 084 026</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364084026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511583.354000 218024.100000</gml:lowerCorner>
        		<gml:upperCorner>511583.354000 218024.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511583.354000 218024.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 082 598</ms:GML_ID>
        <ms:NAZWA>364 082 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364082598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501587.202000 288808.376000</gml:lowerCorner>
        		<gml:upperCorner>501587.202000 288808.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501587.202000 288808.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 032 989</ms:GML_ID>
        <ms:NAZWA>373 032 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373032989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502401.001000 279069.094000</gml:lowerCorner>
        		<gml:upperCorner>502401.001000 279069.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502401.001000 279069.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 013 245</ms:GML_ID>
        <ms:NAZWA>367 013 245</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367013245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504455.747076 277728.404265</gml:lowerCorner>
        		<gml:upperCorner>504455.747076 277728.404265</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504455.747076 277728.404265</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 015 698</ms:GML_ID>
        <ms:NAZWA>367 015 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367015698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505013.461000 288173.862000</gml:lowerCorner>
        		<gml:upperCorner>505013.461000 288173.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505013.461000 288173.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 029 456</ms:GML_ID>
        <ms:NAZWA>373 029 456</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373029456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506817.689000 289561.181000</gml:lowerCorner>
        		<gml:upperCorner>506817.689000 289561.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506817.689000 289561.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 027 155</ms:GML_ID>
        <ms:NAZWA>373 027 155</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373027155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507215.192000 275990.435000</gml:lowerCorner>
        		<gml:upperCorner>507215.192000 275990.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507215.192000 275990.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 018 996</ms:GML_ID>
        <ms:NAZWA>367 018 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367018996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508049.132000 274924.009000</gml:lowerCorner>
        		<gml:upperCorner>508049.132000 274924.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508049.132000 274924.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 020 351</ms:GML_ID>
        <ms:NAZWA>367 020 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367020351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512385.089000 268561.703000</gml:lowerCorner>
        		<gml:upperCorner>512385.089000 268561.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512385.089000 268561.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 002 647</ms:GML_ID>
        <ms:NAZWA>375 002 647</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375002647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513490.845000 270692.142000</gml:lowerCorner>
        		<gml:upperCorner>513490.845000 270692.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513490.845000 270692.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 027 584</ms:GML_ID>
        <ms:NAZWA>367 027 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367027584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513814.693000 269221.759000</gml:lowerCorner>
        		<gml:upperCorner>513814.693000 269221.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513814.693000 269221.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 000 848</ms:GML_ID>
        <ms:NAZWA>375 000 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375000848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513970.867000 269199.299000</gml:lowerCorner>
        		<gml:upperCorner>513970.867000 269199.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513970.867000 269199.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 029 153</ms:GML_ID>
        <ms:NAZWA>367 029 153</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367029153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514040.886000 269172.958000</gml:lowerCorner>
        		<gml:upperCorner>514040.886000 269172.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514040.886000 269172.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 022 179</ms:GML_ID>
        <ms:NAZWA>364 022 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364022179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514112.625780 268784.942154</gml:lowerCorner>
        		<gml:upperCorner>514112.625780 268784.942154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514112.625780 268784.942154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 029 593</ms:GML_ID>
        <ms:NAZWA>367 029 593</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367029593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514146.004000 270865.224000</gml:lowerCorner>
        		<gml:upperCorner>514146.004000 270865.224000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514146.004000 270865.224000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 020 484</ms:GML_ID>
        <ms:NAZWA>364 020 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364020484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514203.294000 271297.537000</gml:lowerCorner>
        		<gml:upperCorner>514203.294000 271297.537000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514203.294000 271297.537000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 020 047</ms:GML_ID>
        <ms:NAZWA>364 020 047</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364020047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514367.162353 272247.488060</gml:lowerCorner>
        		<gml:upperCorner>514367.162353 272247.488060</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514367.162353 272247.488060</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 019 080</ms:GML_ID>
        <ms:NAZWA>364 019 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364019080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515209.099000 275178.377000</gml:lowerCorner>
        		<gml:upperCorner>515209.099000 275178.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515209.099000 275178.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 016 001</ms:GML_ID>
        <ms:NAZWA>364 016 001</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364016001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515536.470000 275432.088000</gml:lowerCorner>
        		<gml:upperCorner>515536.470000 275432.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515536.470000 275432.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 015 584</ms:GML_ID>
        <ms:NAZWA>364 015 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364015584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515873.318000 275707.655000</gml:lowerCorner>
        		<gml:upperCorner>515873.318000 275707.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515873.318000 275707.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 015 149</ms:GML_ID>
        <ms:NAZWA>364 015 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364015149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517918.858000 279111.117000</gml:lowerCorner>
        		<gml:upperCorner>517918.858000 279111.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517918.858000 279111.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 011 113</ms:GML_ID>
        <ms:NAZWA>364 011 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364011113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518050.579000 279371.140000</gml:lowerCorner>
        		<gml:upperCorner>518050.579000 279371.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518050.579000 279371.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 010 822</ms:GML_ID>
        <ms:NAZWA>364 010 822</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364010822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518197.095703 279825.004719</gml:lowerCorner>
        		<gml:upperCorner>518197.095703 279825.004719</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518197.095703 279825.004719</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 010 343</ms:GML_ID>
        <ms:NAZWA>364 010 343</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364010343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518337.544000 280350.461000</gml:lowerCorner>
        		<gml:upperCorner>518337.544000 280350.461000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518337.544000 280350.461000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 009 792</ms:GML_ID>
        <ms:NAZWA>364 009 792</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364009792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519223.766085 281112.337166</gml:lowerCorner>
        		<gml:upperCorner>519223.766085 281112.337166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519223.766085 281112.337166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 008 604</ms:GML_ID>
        <ms:NAZWA>364 008 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364008604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496900.580331 302213.493586</gml:lowerCorner>
        		<gml:upperCorner>496900.580331 302213.493586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496900.580331 302213.493586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 364 295</ms:GML_ID>
        <ms:NAZWA>003 364 295</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003364295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497002.830155 304265.328136</gml:lowerCorner>
        		<gml:upperCorner>497002.830155 304265.328136</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497002.830155 304265.328136</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 362 224</ms:GML_ID>
        <ms:NAZWA>003 362 224</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003362224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497490.396000 290204.803000</gml:lowerCorner>
        		<gml:upperCorner>497490.396000 290204.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497490.396000 290204.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 037 324</ms:GML_ID>
        <ms:NAZWA>373 037 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373037324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498040.464000 290047.996000</gml:lowerCorner>
        		<gml:upperCorner>498040.464000 290047.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498040.464000 290047.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 036 753</ms:GML_ID>
        <ms:NAZWA>373 036 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373036753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498338.341000 289960.519000</gml:lowerCorner>
        		<gml:upperCorner>498338.341000 289960.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498338.341000 289960.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 036 443</ms:GML_ID>
        <ms:NAZWA>373 036 443</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373036443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498731.616000 289842.345000</gml:lowerCorner>
        		<gml:upperCorner>498731.616000 289842.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498731.616000 289842.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 036 031</ms:GML_ID>
        <ms:NAZWA>373 036 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373036031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499407.953000 289644.999000</gml:lowerCorner>
        		<gml:upperCorner>499407.953000 289644.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499407.953000 289644.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 035 323</ms:GML_ID>
        <ms:NAZWA>373 035 323</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373035323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507187.818000 289877.647000</gml:lowerCorner>
        		<gml:upperCorner>507187.818000 289877.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507187.818000 289877.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 026 652</ms:GML_ID>
        <ms:NAZWA>373 026 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373026652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507502.732000 290156.681000</gml:lowerCorner>
        		<gml:upperCorner>507502.732000 290156.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507502.732000 290156.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 026 249</ms:GML_ID>
        <ms:NAZWA>373 026 249</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373026249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508526.403000 291217.947000</gml:lowerCorner>
        		<gml:upperCorner>508526.403000 291217.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508526.403000 291217.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 024 771</ms:GML_ID>
        <ms:NAZWA>373 024 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373024771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509646.093000 292064.139000</gml:lowerCorner>
        		<gml:upperCorner>509646.093000 292064.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509646.093000 292064.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 023 355</ms:GML_ID>
        <ms:NAZWA>373 023 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373023355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510488.164000 292551.112000</gml:lowerCorner>
        		<gml:upperCorner>510488.164000 292551.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510488.164000 292551.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 022 384</ms:GML_ID>
        <ms:NAZWA>373 022 384</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373022384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512294.774000 293182.709000</gml:lowerCorner>
        		<gml:upperCorner>512294.774000 293182.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512294.774000 293182.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 020 452</ms:GML_ID>
        <ms:NAZWA>373 020 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373020452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513665.368000 293500.628000</gml:lowerCorner>
        		<gml:upperCorner>513665.368000 293500.628000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513665.368000 293500.628000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 019 051</ms:GML_ID>
        <ms:NAZWA>373 019 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373019051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515805.523000 293994.346000</gml:lowerCorner>
        		<gml:upperCorner>515805.523000 293994.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515805.523000 293994.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 016 847</ms:GML_ID>
        <ms:NAZWA>373 016 847</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373016847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516627.988000 294189.458000</gml:lowerCorner>
        		<gml:upperCorner>516627.988000 294189.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516627.988000 294189.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 016 004</ms:GML_ID>
        <ms:NAZWA>373 016 004</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373016004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519191.856000 293146.930000</gml:lowerCorner>
        		<gml:upperCorner>519191.856000 293146.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519191.856000 293146.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 013 163</ms:GML_ID>
        <ms:NAZWA>373 013 163</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373013163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519554.959428 292898.747928</gml:lowerCorner>
        		<gml:upperCorner>519554.959428 292898.747928</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519554.959428 292898.747928</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 012 723</ms:GML_ID>
        <ms:NAZWA>373 012 723</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373012723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520273.294000 292407.989000</gml:lowerCorner>
        		<gml:upperCorner>520273.294000 292407.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520273.294000 292407.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 011 853</ms:GML_ID>
        <ms:NAZWA>373 011 853</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>373011853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517385.124000 233225.055000</gml:lowerCorner>
        		<gml:upperCorner>517385.124000 233225.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517385.124000 233225.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 062 028</ms:GML_ID>
        <ms:NAZWA>364 062 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364062028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517508.562000 233986.996000</gml:lowerCorner>
        		<gml:upperCorner>517508.562000 233986.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517508.562000 233986.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 061 246</ms:GML_ID>
        <ms:NAZWA>364 061 246</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364061246</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516694.964450 235488.109080</gml:lowerCorner>
        		<gml:upperCorner>516694.964450 235488.109080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516694.964450 235488.109080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 059 420</ms:GML_ID>
        <ms:NAZWA>364 059 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364059420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497827.082463 235655.820992</gml:lowerCorner>
        		<gml:upperCorner>497827.082463 235655.820992</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497827.082463 235655.820992</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 437 715</ms:GML_ID>
        <ms:NAZWA>003 437 715</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003437715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516658.703000 235804.173000</gml:lowerCorner>
        		<gml:upperCorner>516658.703000 235804.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516658.703000 235804.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 059 085</ms:GML_ID>
        <ms:NAZWA>364 059 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364059085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517033.868000 236292.418000</gml:lowerCorner>
        		<gml:upperCorner>517033.868000 236292.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517033.868000 236292.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 058 462</ms:GML_ID>
        <ms:NAZWA>364 058 462</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364058462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517668.116000 236466.167000</gml:lowerCorner>
        		<gml:upperCorner>517668.116000 236466.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517668.116000 236466.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 057 809</ms:GML_ID>
        <ms:NAZWA>364 057 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364057809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518025.707985 236952.237765</gml:lowerCorner>
        		<gml:upperCorner>518025.707985 236952.237765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518025.707985 236952.237765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 057 157</ms:GML_ID>
        <ms:NAZWA>364 057 157</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364057157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496994.737484 237248.624286</gml:lowerCorner>
        		<gml:upperCorner>496994.737484 237248.624286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496994.737484 237248.624286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 435 913</ms:GML_ID>
        <ms:NAZWA>003 435 913</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003435913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517911.150000 237264.834000</gml:lowerCorner>
        		<gml:upperCorner>517911.150000 237264.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517911.150000 237264.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 056 817</ms:GML_ID>
        <ms:NAZWA>364 056 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364056817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517323.698715 238018.325931</gml:lowerCorner>
        		<gml:upperCorner>517323.698715 238018.325931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517323.698715 238018.325931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 055 832</ms:GML_ID>
        <ms:NAZWA>364 055 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364055832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496210.863775 238210.149524</gml:lowerCorner>
        		<gml:upperCorner>496210.863775 238210.149524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496210.863775 238210.149524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 434 672</ms:GML_ID>
        <ms:NAZWA>003 434 672</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003434672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495689.454000 238847.649000</gml:lowerCorner>
        		<gml:upperCorner>495689.454000 238847.649000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495689.454000 238847.649000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 433 850</ms:GML_ID>
        <ms:NAZWA>003 433 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003433850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516916.961000 240205.355000</gml:lowerCorner>
        		<gml:upperCorner>516916.961000 240205.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516916.961000 240205.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 053 490</ms:GML_ID>
        <ms:NAZWA>364 053 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364053490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516690.797000 240728.031000</gml:lowerCorner>
        		<gml:upperCorner>516690.797000 240728.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516690.797000 240728.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 052 920</ms:GML_ID>
        <ms:NAZWA>364 052 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364052920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515935.061854 241813.211823</gml:lowerCorner>
        		<gml:upperCorner>515935.061854 241813.211823</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515935.061854 241813.211823</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 051 575</ms:GML_ID>
        <ms:NAZWA>364 051 575</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364051575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514401.760127 245114.022448</gml:lowerCorner>
        		<gml:upperCorner>514401.760127 245114.022448</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514401.760127 245114.022448</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 047 836</ms:GML_ID>
        <ms:NAZWA>364 047 836</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364047836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514157.720000 245528.508000</gml:lowerCorner>
        		<gml:upperCorner>514157.720000 245528.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514157.720000 245528.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 047 354</ms:GML_ID>
        <ms:NAZWA>364 047 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364047354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513917.762000 246020.868000</gml:lowerCorner>
        		<gml:upperCorner>513917.762000 246020.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513917.762000 246020.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 046 804</ms:GML_ID>
        <ms:NAZWA>364 046 804</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364046804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495934.451457 246194.671811</gml:lowerCorner>
        		<gml:upperCorner>495934.451457 246194.671811</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495934.451457 246194.671811</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 040 226</ms:GML_ID>
        <ms:NAZWA>375 040 226</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375040226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513893.153000 246198.114000</gml:lowerCorner>
        		<gml:upperCorner>513893.153000 246198.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513893.153000 246198.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.364 046 625</ms:GML_ID>
        <ms:NAZWA>364 046 625</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>364046625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497226.507406 246600.498526</gml:lowerCorner>
        		<gml:upperCorner>497226.507406 246600.498526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497226.507406 246600.498526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 038 870</ms:GML_ID>
        <ms:NAZWA>375 038 870</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375038870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498400.226000 246768.006000</gml:lowerCorner>
        		<gml:upperCorner>498400.226000 246768.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498400.226000 246768.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 037 677</ms:GML_ID>
        <ms:NAZWA>375 037 677</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375037677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499189.810000 246836.990000</gml:lowerCorner>
        		<gml:upperCorner>499189.810000 246836.990000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499189.810000 246836.990000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 036 889</ms:GML_ID>
        <ms:NAZWA>375 036 889</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375036889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502796.509510 247977.217503</gml:lowerCorner>
        		<gml:upperCorner>502796.509510 247977.217503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502796.509510 247977.217503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 033 080</ms:GML_ID>
        <ms:NAZWA>375 033 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375033080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503770.023000 248582.493000</gml:lowerCorner>
        		<gml:upperCorner>503770.023000 248582.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503770.023000 248582.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 031 872</ms:GML_ID>
        <ms:NAZWA>375 031 872</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375031872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503919.728000 249232.800000</gml:lowerCorner>
        		<gml:upperCorner>503919.728000 249232.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503919.728000 249232.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 031 206</ms:GML_ID>
        <ms:NAZWA>375 031 206</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375031206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504047.600000 249791.753000</gml:lowerCorner>
        		<gml:upperCorner>504047.600000 249791.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504047.600000 249791.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 030 634</ms:GML_ID>
        <ms:NAZWA>375 030 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375030634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504121.370799 250111.216548</gml:lowerCorner>
        		<gml:upperCorner>504121.370799 250111.216548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504121.370799 250111.216548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 030 305</ms:GML_ID>
        <ms:NAZWA>375 030 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375030305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496493.989227 250977.197771</gml:lowerCorner>
        		<gml:upperCorner>496493.989227 250977.197771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496493.989227 250977.197771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 421 149</ms:GML_ID>
        <ms:NAZWA>003 421 149</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003421149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492147.092000 262744.005000</gml:lowerCorner>
        		<gml:upperCorner>492147.092000 262744.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492147.092000 262744.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 408 489</ms:GML_ID>
        <ms:NAZWA>003 408 489</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003408489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492666.783494 261366.666662</gml:lowerCorner>
        		<gml:upperCorner>492666.783494 261366.666662</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492666.783494 261366.666662</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 409 960</ms:GML_ID>
        <ms:NAZWA>003 409 960</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003409960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492878.557004 260894.859516</gml:lowerCorner>
        		<gml:upperCorner>492878.557004 260894.859516</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492878.557004 260894.859516</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 410 480</ms:GML_ID>
        <ms:NAZWA>003 410 480</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003410480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493093.665000 260421.972000</gml:lowerCorner>
        		<gml:upperCorner>493093.665000 260421.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493093.665000 260421.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 410 993</ms:GML_ID>
        <ms:NAZWA>003 410 993</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003410993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493688.108694 259106.296803</gml:lowerCorner>
        		<gml:upperCorner>493688.108694 259106.296803</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493688.108694 259106.296803</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 412 438</ms:GML_ID>
        <ms:NAZWA>003 412 438</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003412438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494760.710000 255261.796000</gml:lowerCorner>
        		<gml:upperCorner>494760.710000 255261.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494760.710000 255261.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 416 467</ms:GML_ID>
        <ms:NAZWA>003 416 467</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003416467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503031.400000 262817.241000</gml:lowerCorner>
        		<gml:upperCorner>503031.400000 262817.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503031.400000 262817.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 017 213</ms:GML_ID>
        <ms:NAZWA>375 017 213</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375017213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503110.950651 261914.879476</gml:lowerCorner>
        		<gml:upperCorner>503110.950651 261914.879476</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503110.950651 261914.879476</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 018 129</ms:GML_ID>
        <ms:NAZWA>375 018 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375018129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503626.241000 265487.489000</gml:lowerCorner>
        		<gml:upperCorner>503626.241000 265487.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503626.241000 265487.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 013 773</ms:GML_ID>
        <ms:NAZWA>375 013 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375013773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503767.924000 259930.930000</gml:lowerCorner>
        		<gml:upperCorner>503767.924000 259930.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503767.924000 259930.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 020 223</ms:GML_ID>
        <ms:NAZWA>375 020 223</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375020223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504321.864000 257993.799000</gml:lowerCorner>
        		<gml:upperCorner>504321.864000 257993.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504321.864000 257993.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 022 242</ms:GML_ID>
        <ms:NAZWA>375 022 242</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375022242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504564.096000 256684.118000</gml:lowerCorner>
        		<gml:upperCorner>504564.096000 256684.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504564.096000 256684.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 023 574</ms:GML_ID>
        <ms:NAZWA>375 023 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375023574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504571.887000 251326.219000</gml:lowerCorner>
        		<gml:upperCorner>504571.887000 251326.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504571.887000 251326.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 028 982</ms:GML_ID>
        <ms:NAZWA>375 028 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375028982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504774.741000 252664.177000</gml:lowerCorner>
        		<gml:upperCorner>504774.741000 252664.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504774.741000 252664.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 027 626</ms:GML_ID>
        <ms:NAZWA>375 027 626</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375027626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504868.074000 253950.546000</gml:lowerCorner>
        		<gml:upperCorner>504868.074000 253950.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504868.074000 253950.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 026 338</ms:GML_ID>
        <ms:NAZWA>375 026 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375026338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504889.822000 254330.034000</gml:lowerCorner>
        		<gml:upperCorner>504889.822000 254330.034000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504889.822000 254330.034000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 025 959</ms:GML_ID>
        <ms:NAZWA>375 025 959</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375025959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505955.362000 264614.287000</gml:lowerCorner>
        		<gml:upperCorner>505955.362000 264614.287000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505955.362000 264614.287000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 011 153</ms:GML_ID>
        <ms:NAZWA>375 011 153</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375011153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509945.759812 264903.776958</gml:lowerCorner>
        		<gml:upperCorner>509945.759812 264903.776958</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509945.759812 264903.776958</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 007 132</ms:GML_ID>
        <ms:NAZWA>375 007 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375007132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511340.623000 267182.451000</gml:lowerCorner>
        		<gml:upperCorner>511340.623000 267182.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511340.623000 267182.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.375 004 377</ms:GML_ID>
        <ms:NAZWA>375 004 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>375004377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493223.990000 268433.406000</gml:lowerCorner>
        		<gml:upperCorner>493223.990000 268433.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493223.990000 268433.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 402 604</ms:GML_ID>
        <ms:NAZWA>003 402 604</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003402604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493331.647287 268990.927366</gml:lowerCorner>
        		<gml:upperCorner>493331.647287 268990.927366</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493331.647287 268990.927366</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 402 036</ms:GML_ID>
        <ms:NAZWA>003 402 036</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003402036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493877.637000 273924.484000</gml:lowerCorner>
        		<gml:upperCorner>493877.637000 273924.484000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493877.637000 273924.484000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 397 026</ms:GML_ID>
        <ms:NAZWA>003 397 026</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003397026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493638.985000 277595.980000</gml:lowerCorner>
        		<gml:upperCorner>493638.985000 277595.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493638.985000 277595.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 393 329</ms:GML_ID>
        <ms:NAZWA>003 393 329</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003393329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492836.006000 278444.753000</gml:lowerCorner>
        		<gml:upperCorner>492836.006000 278444.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492836.006000 278444.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 392 162</ms:GML_ID>
        <ms:NAZWA>003 392 162</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003392162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500255.579000 279516.107000</gml:lowerCorner>
        		<gml:upperCorner>500255.579000 279516.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500255.579000 279516.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 011 041</ms:GML_ID>
        <ms:NAZWA>367 011 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367011041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499421.742000 279653.363000</gml:lowerCorner>
        		<gml:upperCorner>499421.742000 279653.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499421.742000 279653.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 010 196</ms:GML_ID>
        <ms:NAZWA>367 010 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>367010196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498445.180000 279839.791000</gml:lowerCorner>
        		<gml:upperCorner>498445.180000 279839.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498445.180000 279839.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 009 201</ms:GML_ID>
        <ms:NAZWA>367 009 201</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367009201</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496760.061000 280521.310000</gml:lowerCorner>
        		<gml:upperCorner>496760.061000 280521.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496760.061000 280521.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 007 383</ms:GML_ID>
        <ms:NAZWA>367 007 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367007383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495660.327000 281309.595000</gml:lowerCorner>
        		<gml:upperCorner>495660.327000 281309.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495660.327000 281309.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 006 028</ms:GML_ID>
        <ms:NAZWA>367 006 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367006028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495061.315000 281743.476000</gml:lowerCorner>
        		<gml:upperCorner>495061.315000 281743.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495061.315000 281743.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 005 289</ms:GML_ID>
        <ms:NAZWA>367 005 289</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367005289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494761.358000 281961.978000</gml:lowerCorner>
        		<gml:upperCorner>494761.358000 281961.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494761.358000 281961.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 004 918</ms:GML_ID>
        <ms:NAZWA>367 004 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367004918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490197.501048 282239.033745</gml:lowerCorner>
        		<gml:upperCorner>490197.501048 282239.033745</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490197.501048 282239.033745</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.358 000 971</ms:GML_ID>
        <ms:NAZWA>358 000 971</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>358000971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494225.779185 282580.727465</gml:lowerCorner>
        		<gml:upperCorner>494225.779185 282580.727465</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494225.779185 282580.727465</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 004 093</ms:GML_ID>
        <ms:NAZWA>367 004 093</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367004093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490775.462526 282716.234748</gml:lowerCorner>
        		<gml:upperCorner>490775.462526 282716.234748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490775.462526 282716.234748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.982 001 915</ms:GML_ID>
        <ms:NAZWA>982 001 915</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>982001915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494106.949000 282762.251000</gml:lowerCorner>
        		<gml:upperCorner>494106.949000 282762.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494106.949000 282762.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.367 003 877</ms:GML_ID>
        <ms:NAZWA>367 003 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>367003877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491432.026034 283084.430120</gml:lowerCorner>
        		<gml:upperCorner>491432.026034 283084.430120</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491432.026034 283084.430120</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 385 095</ms:GML_ID>
        <ms:NAZWA>003 385 095</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003385095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491252.195699 283280.419283</gml:lowerCorner>
        		<gml:upperCorner>491252.195699 283280.419283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491252.195699 283280.419283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.819 002 315</ms:GML_ID>
        <ms:NAZWA>819 002 315</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>819002315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492817.567341 285711.523035</gml:lowerCorner>
        		<gml:upperCorner>492817.567341 285711.523035</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492817.567341 285711.523035</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 381 770</ms:GML_ID>
        <ms:NAZWA>003 381 770</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003381770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492753.443639 287230.873764</gml:lowerCorner>
        		<gml:upperCorner>492753.443639 287230.873764</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492753.443639 287230.873764</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 380 250</ms:GML_ID>
        <ms:NAZWA>003 380 250</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003380250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492697.078328 288613.534412</gml:lowerCorner>
        		<gml:upperCorner>492697.078328 288613.534412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492697.078328 288613.534412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 378 867</ms:GML_ID>
        <ms:NAZWA>003 378 867</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003378867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495043.710000 288909.387000</gml:lowerCorner>
        		<gml:upperCorner>495043.710000 288909.387000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495043.710000 288909.387000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 040 296</ms:GML_ID>
        <ms:NAZWA>373 040 296</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373040296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501207.674000 288999.071000</gml:lowerCorner>
        		<gml:upperCorner>501207.674000 288999.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501207.674000 288999.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 033 411</ms:GML_ID>
        <ms:NAZWA>373 033 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373033411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494325.923000 289034.861000</gml:lowerCorner>
        		<gml:upperCorner>494325.923000 289034.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494325.923000 289034.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.373 041 025</ms:GML_ID>
        <ms:NAZWA>373 041 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>373041025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

