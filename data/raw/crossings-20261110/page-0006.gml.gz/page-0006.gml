<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:24" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=5000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=7000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>207234.336000 363297.956536</gml:lowerCorner>
      		<gml:upperCorner>770631.729000 518499.663000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471330.038000 514696.694000</gml:lowerCorner>
        		<gml:upperCorner>471330.038000 514696.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471330.038000 514696.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 053 651</ms:GML_ID>
        <ms:NAZWA>016 053 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016053651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461473.370083 515219.309791</gml:lowerCorner>
        		<gml:upperCorner>461473.370083 515219.309791</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461473.370083 515219.309791</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 042 509</ms:GML_ID>
        <ms:NAZWA>016 042 509</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016042509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472185.545131 515283.085052</gml:lowerCorner>
        		<gml:upperCorner>472185.545131 515283.085052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472185.545131 515283.085052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 054 691</ms:GML_ID>
        <ms:NAZWA>016 054 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016054691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461033.296929 515545.612855</gml:lowerCorner>
        		<gml:upperCorner>461033.296929 515545.612855</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461033.296929 515545.612855</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 041 960</ms:GML_ID>
        <ms:NAZWA>016 041 960</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016041960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473255.182541 516015.974318</gml:lowerCorner>
        		<gml:upperCorner>473255.182541 516015.974318</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473255.182541 516015.974318</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 055 988</ms:GML_ID>
        <ms:NAZWA>016 055 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016055988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474060.201392 516620.699251</gml:lowerCorner>
        		<gml:upperCorner>474060.201392 516620.699251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474060.201392 516620.699251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 056 997</ms:GML_ID>
        <ms:NAZWA>016 056 997</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016056997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459716.209644 516734.152990</gml:lowerCorner>
        		<gml:upperCorner>459716.209644 516734.152990</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459716.209644 516734.152990</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 040 183</ms:GML_ID>
        <ms:NAZWA>016 040 183</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016040183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459103.723335 517168.149968</gml:lowerCorner>
        		<gml:upperCorner>459103.723335 517168.149968</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459103.723335 517168.149968</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 039 429</ms:GML_ID>
        <ms:NAZWA>016 039 429</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016039429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474958.423000 517406.412000</gml:lowerCorner>
        		<gml:upperCorner>474958.423000 517406.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474958.423000 517406.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 058 191</ms:GML_ID>
        <ms:NAZWA>016 058 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016058191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457666.937692 517902.714545</gml:lowerCorner>
        		<gml:upperCorner>457666.937692 517902.714545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457666.937692 517902.714545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 037 814</ms:GML_ID>
        <ms:NAZWA>016 037 814</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016037814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475645.806643 518008.326428</gml:lowerCorner>
        		<gml:upperCorner>475645.806643 518008.326428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475645.806643 518008.326428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 059 103</ms:GML_ID>
        <ms:NAZWA>016 059 103</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016059103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455941.226836 518317.001198</gml:lowerCorner>
        		<gml:upperCorner>455941.226836 518317.001198</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455941.226836 518317.001198</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 036 025</ms:GML_ID>
        <ms:NAZWA>016 036 025</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016036025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451407.392548 518340.532088</gml:lowerCorner>
        		<gml:upperCorner>451407.392548 518340.532088</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451407.392548 518340.532088</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 031 444</ms:GML_ID>
        <ms:NAZWA>016 031 444</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016031444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455561.556310 518384.715264</gml:lowerCorner>
        		<gml:upperCorner>455561.556310 518384.715264</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455561.556310 518384.715264</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 035 639</ms:GML_ID>
        <ms:NAZWA>016 035 639</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016035639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455166.156000 518454.838000</gml:lowerCorner>
        		<gml:upperCorner>455166.156000 518454.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455166.156000 518454.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 035 237</ms:GML_ID>
        <ms:NAZWA>016 035 237</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016035237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450425.739172 518463.717403</gml:lowerCorner>
        		<gml:upperCorner>450425.739172 518463.717403</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450425.739172 518463.717403</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 030 451</ms:GML_ID>
        <ms:NAZWA>016 030 451</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016030451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452905.171000 518499.663000</gml:lowerCorner>
        		<gml:upperCorner>452905.171000 518499.663000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452905.171000 518499.663000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 032 953</ms:GML_ID>
        <ms:NAZWA>016 032 953</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016032953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460431.830000 494913.914000</gml:lowerCorner>
        		<gml:upperCorner>460431.830000 494913.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460431.830000 494913.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 218 011</ms:GML_ID>
        <ms:NAZWA>131 218 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131218011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465546.180000 492738.317000</gml:lowerCorner>
        		<gml:upperCorner>465546.180000 492738.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465546.180000 492738.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 223 571</ms:GML_ID>
        <ms:NAZWA>131 223 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131223571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467023.630000 492095.103000</gml:lowerCorner>
        		<gml:upperCorner>467023.630000 492095.103000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467023.630000 492095.103000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 225 185</ms:GML_ID>
        <ms:NAZWA>131 225 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131225185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467434.012000 491796.204000</gml:lowerCorner>
        		<gml:upperCorner>467434.012000 491796.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467434.012000 491796.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 225 691</ms:GML_ID>
        <ms:NAZWA>131 225 691</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131225691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473259.328000 489760.168000</gml:lowerCorner>
        		<gml:upperCorner>473259.328000 489760.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473259.328000 489760.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 231 987</ms:GML_ID>
        <ms:NAZWA>131 231 987</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131231987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473673.865735 489659.838385</gml:lowerCorner>
        		<gml:upperCorner>473673.865735 489659.838385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473673.865735 489659.838385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 232 413</ms:GML_ID>
        <ms:NAZWA>131 232 413</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131232413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474314.998000 489505.244000</gml:lowerCorner>
        		<gml:upperCorner>474314.998000 489505.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474314.998000 489505.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 233 075</ms:GML_ID>
        <ms:NAZWA>131 233 075</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131233075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475497.942000 489218.837000</gml:lowerCorner>
        		<gml:upperCorner>475497.942000 489218.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475497.942000 489218.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 234 293</ms:GML_ID>
        <ms:NAZWA>131 234 293</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131234293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476508.710000 488974.737000</gml:lowerCorner>
        		<gml:upperCorner>476508.710000 488974.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476508.710000 488974.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 235 332</ms:GML_ID>
        <ms:NAZWA>131 235 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131235332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478089.268000 488593.557000</gml:lowerCorner>
        		<gml:upperCorner>478089.268000 488593.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478089.268000 488593.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 236 958</ms:GML_ID>
        <ms:NAZWA>131 236 958</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131236958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478825.638877 488415.929488</gml:lowerCorner>
        		<gml:upperCorner>478825.638877 488415.929488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478825.638877 488415.929488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 237 718</ms:GML_ID>
        <ms:NAZWA>131 237 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131237718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479451.482224 488204.972472</gml:lowerCorner>
        		<gml:upperCorner>479451.482224 488204.972472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479451.482224 488204.972472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 238 380</ms:GML_ID>
        <ms:NAZWA>131 238 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131238380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480402.727793 487608.379780</gml:lowerCorner>
        		<gml:upperCorner>480402.727793 487608.379780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480402.727793 487608.379780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 239 503</ms:GML_ID>
        <ms:NAZWA>131 239 503</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131239503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480908.983543 487286.301732</gml:lowerCorner>
        		<gml:upperCorner>480908.983543 487286.301732</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480908.983543 487286.301732</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 240 105</ms:GML_ID>
        <ms:NAZWA>131 240 105</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131240105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482140.609443 486500.636551</gml:lowerCorner>
        		<gml:upperCorner>482140.609443 486500.636551</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482140.609443 486500.636551</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 241 568</ms:GML_ID>
        <ms:NAZWA>131 241 568</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131241568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483335.331199 484157.312325</gml:lowerCorner>
        		<gml:upperCorner>483335.331199 484157.312325</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483335.331199 484157.312325</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 166 153</ms:GML_ID>
        <ms:NAZWA>003 166 153</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003166153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483371.022000 485379.935000</gml:lowerCorner>
        		<gml:upperCorner>483371.022000 485379.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483371.022000 485379.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.737 002 820</ms:GML_ID>
        <ms:NAZWA>737 002 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>737002820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483499.585000 485102.918000</gml:lowerCorner>
        		<gml:upperCorner>483499.585000 485102.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483499.585000 485102.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.737 003 125</ms:GML_ID>
        <ms:NAZWA>737 003 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>737003125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483598.874945 485760.281384</gml:lowerCorner>
        		<gml:upperCorner>483598.874945 485760.281384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483598.874945 485760.281384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.740 001 950</ms:GML_ID>
        <ms:NAZWA>740 001 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>740001950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483889.208000 485790.583000</gml:lowerCorner>
        		<gml:upperCorner>483889.208000 485790.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483889.208000 485790.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.544 000 620</ms:GML_ID>
        <ms:NAZWA>544 000 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>544000620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484081.608027 486725.399203</gml:lowerCorner>
        		<gml:upperCorner>484081.608027 486725.399203</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484081.608027 486725.399203</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 163 479</ms:GML_ID>
        <ms:NAZWA>003 163 479</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003163479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484451.493124 488580.861440</gml:lowerCorner>
        		<gml:upperCorner>484451.493124 488580.861440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484451.493124 488580.861440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 161 576</ms:GML_ID>
        <ms:NAZWA>003 161 576</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003161576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484535.963159 490832.762186</gml:lowerCorner>
        		<gml:upperCorner>484535.963159 490832.762186</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484535.963159 490832.762186</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 159 320</ms:GML_ID>
        <ms:NAZWA>003 159 320</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003159320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484632.390745 493250.968297</gml:lowerCorner>
        		<gml:upperCorner>484632.390745 493250.968297</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484632.390745 493250.968297</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 156 898</ms:GML_ID>
        <ms:NAZWA>003 156 898</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003156898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544076.961346 494550.944870</gml:lowerCorner>
        		<gml:upperCorner>544076.961346 494550.944870</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544076.961346 494550.944870</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 071 529</ms:GML_ID>
        <ms:NAZWA>018 071 529</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018071529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544972.037429 494098.288140</gml:lowerCorner>
        		<gml:upperCorner>544972.037429 494098.288140</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544972.037429 494098.288140</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 072 548</ms:GML_ID>
        <ms:NAZWA>018 072 548</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018072548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547134.709862 492408.609073</gml:lowerCorner>
        		<gml:upperCorner>547134.709862 492408.609073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547134.709862 492408.609073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 075 297</ms:GML_ID>
        <ms:NAZWA>018 075 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018075297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547867.985325 491836.181777</gml:lowerCorner>
        		<gml:upperCorner>547867.985325 491836.181777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547867.985325 491836.181777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 076 226</ms:GML_ID>
        <ms:NAZWA>018 076 226</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018076226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548222.290039 491548.394431</gml:lowerCorner>
        		<gml:upperCorner>548222.290039 491548.394431</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548222.290039 491548.394431</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 076 682</ms:GML_ID>
        <ms:NAZWA>018 076 682</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018076682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549372.303766 490499.201171</gml:lowerCorner>
        		<gml:upperCorner>549372.303766 490499.201171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549372.303766 490499.201171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 078 254</ms:GML_ID>
        <ms:NAZWA>018 078 254</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018078254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549838.415363 489554.000330</gml:lowerCorner>
        		<gml:upperCorner>549838.415363 489554.000330</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549838.415363 489554.000330</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 079 305</ms:GML_ID>
        <ms:NAZWA>018 079 305</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018079305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550282.872000 488650.927000</gml:lowerCorner>
        		<gml:upperCorner>550282.872000 488650.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550282.872000 488650.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 080 316</ms:GML_ID>
        <ms:NAZWA>018 080 316</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018080316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551078.641646 487034.814918</gml:lowerCorner>
        		<gml:upperCorner>551078.641646 487034.814918</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551078.641646 487034.814918</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 082 118</ms:GML_ID>
        <ms:NAZWA>018 082 118</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018082118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551659.013732 485925.168738</gml:lowerCorner>
        		<gml:upperCorner>551659.013732 485925.168738</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551659.013732 485925.168738</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 083 373</ms:GML_ID>
        <ms:NAZWA>018 083 373</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018083373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552270.181568 484761.540141</gml:lowerCorner>
        		<gml:upperCorner>552270.181568 484761.540141</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552270.181568 484761.540141</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 084 685</ms:GML_ID>
        <ms:NAZWA>018 084 685</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018084685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552637.629000 484061.264000</gml:lowerCorner>
        		<gml:upperCorner>552637.629000 484061.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552637.629000 484061.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 085 481</ms:GML_ID>
        <ms:NAZWA>018 085 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018085481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556753.234000 484553.946000</gml:lowerCorner>
        		<gml:upperCorner>556753.234000 484553.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556753.234000 484553.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 005 479</ms:GML_ID>
        <ms:NAZWA>245 005 479</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245005479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557031.997000 485137.533000</gml:lowerCorner>
        		<gml:upperCorner>557031.997000 485137.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557031.997000 485137.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 006 126</ms:GML_ID>
        <ms:NAZWA>245 006 126</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245006126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562166.679225 499007.476937</gml:lowerCorner>
        		<gml:upperCorner>562166.679225 499007.476937</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562166.679225 499007.476937</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 136 539</ms:GML_ID>
        <ms:NAZWA>027 136 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027136539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562514.635101 498663.629472</gml:lowerCorner>
        		<gml:upperCorner>562514.635101 498663.629472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562514.635101 498663.629472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 137 028</ms:GML_ID>
        <ms:NAZWA>027 137 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027137028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563706.253913 496921.770545</gml:lowerCorner>
        		<gml:upperCorner>563706.253913 496921.770545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563706.253913 496921.770545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 139 208</ms:GML_ID>
        <ms:NAZWA>027 139 208</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027139208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564101.389380 495778.965836</gml:lowerCorner>
        		<gml:upperCorner>564101.389380 495778.965836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564101.389380 495778.965836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 140 419</ms:GML_ID>
        <ms:NAZWA>027 140 419</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027140419</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493176.266000 481624.714000</gml:lowerCorner>
        		<gml:upperCorner>493176.266000 481624.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493176.266000 481624.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 253 766</ms:GML_ID>
        <ms:NAZWA>131 253 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131253766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492078.991646 482336.250004</gml:lowerCorner>
        		<gml:upperCorner>492078.991646 482336.250004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492078.991646 482336.250004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 252 446</ms:GML_ID>
        <ms:NAZWA>131 252 446</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131252446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490826.716145 483149.242093</gml:lowerCorner>
        		<gml:upperCorner>490826.716145 483149.242093</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490826.716145 483149.242093</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 250 963</ms:GML_ID>
        <ms:NAZWA>131 250 963</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131250963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490357.115182 483454.298869</gml:lowerCorner>
        		<gml:upperCorner>490357.115182 483454.298869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490357.115182 483454.298869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 250 401</ms:GML_ID>
        <ms:NAZWA>131 250 401</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131250401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489775.337000 483831.597000</gml:lowerCorner>
        		<gml:upperCorner>489775.337000 483831.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489775.337000 483831.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 249 708</ms:GML_ID>
        <ms:NAZWA>131 249 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131249708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489086.582000 484106.423000</gml:lowerCorner>
        		<gml:upperCorner>489086.582000 484106.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489086.582000 484106.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 248 983</ms:GML_ID>
        <ms:NAZWA>131 248 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131248983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488277.027421 484338.850831</gml:lowerCorner>
        		<gml:upperCorner>488277.027421 484338.850831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488277.027421 484338.850831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 248 122</ms:GML_ID>
        <ms:NAZWA>131 248 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131248122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487929.611467 484438.392713</gml:lowerCorner>
        		<gml:upperCorner>487929.611467 484438.392713</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487929.611467 484438.392713</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 247 757</ms:GML_ID>
        <ms:NAZWA>131 247 757</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131247757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485859.049000 485031.894000</gml:lowerCorner>
        		<gml:upperCorner>485859.049000 485031.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485859.049000 485031.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 245 592</ms:GML_ID>
        <ms:NAZWA>131 245 592</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131245592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484719.248000 495679.542000</gml:lowerCorner>
        		<gml:upperCorner>484719.248000 495679.542000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484719.248000 495679.542000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 154 463</ms:GML_ID>
        <ms:NAZWA>003 154 463</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003154463</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484810.002296 499570.680082</gml:lowerCorner>
        		<gml:upperCorner>484810.002296 499570.680082</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484810.002296 499570.680082</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 150 551</ms:GML_ID>
        <ms:NAZWA>003 150 551</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003150551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484936.843000 501769.596000</gml:lowerCorner>
        		<gml:upperCorner>484936.843000 501769.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484936.843000 501769.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 148 346</ms:GML_ID>
        <ms:NAZWA>003 148 346</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003148346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485004.370909 503619.849027</gml:lowerCorner>
        		<gml:upperCorner>485004.370909 503619.849027</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485004.370909 503619.849027</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 146 493</ms:GML_ID>
        <ms:NAZWA>003 146 493</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003146493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485085.545000 505850.318000</gml:lowerCorner>
        		<gml:upperCorner>485085.545000 505850.318000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485085.545000 505850.318000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 144 260</ms:GML_ID>
        <ms:NAZWA>003 144 260</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003144260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485170.214336 508183.385885</gml:lowerCorner>
        		<gml:upperCorner>485170.214336 508183.385885</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485170.214336 508183.385885</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 141 924</ms:GML_ID>
        <ms:NAZWA>003 141 924</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003141924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502489.683702 509750.121618</gml:lowerCorner>
        		<gml:upperCorner>502489.683702 509750.121618</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502489.683702 509750.121618</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 024 333</ms:GML_ID>
        <ms:NAZWA>018 024 333</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018024333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501948.187323 510022.678075</gml:lowerCorner>
        		<gml:upperCorner>501948.187323 510022.678075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501948.187323 510022.678075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 023 727</ms:GML_ID>
        <ms:NAZWA>018 023 727</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018023727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506204.735000 472683.332000</gml:lowerCorner>
        		<gml:upperCorner>506204.735000 472683.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506204.735000 472683.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 269 885</ms:GML_ID>
        <ms:NAZWA>131 269 885</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131269885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507053.492101 472434.241459</gml:lowerCorner>
        		<gml:upperCorner>507053.492101 472434.241459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507053.492101 472434.241459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 270 770</ms:GML_ID>
        <ms:NAZWA>131 270 770</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131270770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508435.597771 472030.510997</gml:lowerCorner>
        		<gml:upperCorner>508435.597771 472030.510997</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508435.597771 472030.510997</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 272 212</ms:GML_ID>
        <ms:NAZWA>131 272 212</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131272212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509216.607000 471782.553000</gml:lowerCorner>
        		<gml:upperCorner>509216.607000 471782.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509216.607000 471782.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 273 032</ms:GML_ID>
        <ms:NAZWA>131 273 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131273032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509642.376000 471579.159000</gml:lowerCorner>
        		<gml:upperCorner>509642.376000 471579.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509642.376000 471579.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 273 504</ms:GML_ID>
        <ms:NAZWA>131 273 504</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131273504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510020.467000 471399.612000</gml:lowerCorner>
        		<gml:upperCorner>510020.467000 471399.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510020.467000 471399.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 273 922</ms:GML_ID>
        <ms:NAZWA>131 273 922</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131273922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510937.291000 470962.845000</gml:lowerCorner>
        		<gml:upperCorner>510937.291000 470962.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510937.291000 470962.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 274 939</ms:GML_ID>
        <ms:NAZWA>131 274 939</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131274939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511538.452000 470676.048000</gml:lowerCorner>
        		<gml:upperCorner>511538.452000 470676.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511538.452000 470676.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 275 606</ms:GML_ID>
        <ms:NAZWA>131 275 606</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131275606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512379.164000 470274.613000</gml:lowerCorner>
        		<gml:upperCorner>512379.164000 470274.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512379.164000 470274.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 276 538</ms:GML_ID>
        <ms:NAZWA>131 276 538</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131276538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512812.120000 470068.187000</gml:lowerCorner>
        		<gml:upperCorner>512812.120000 470068.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512812.120000 470068.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 277 019</ms:GML_ID>
        <ms:NAZWA>131 277 019</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131277019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514441.206764 469292.203320</gml:lowerCorner>
        		<gml:upperCorner>514441.206764 469292.203320</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514441.206764 469292.203320</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 278 825</ms:GML_ID>
        <ms:NAZWA>131 278 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131278825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515646.931000 468717.081000</gml:lowerCorner>
        		<gml:upperCorner>515646.931000 468717.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515646.931000 468717.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 280 160</ms:GML_ID>
        <ms:NAZWA>131 280 160</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131280160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516435.023000 468340.799000</gml:lowerCorner>
        		<gml:upperCorner>516435.023000 468340.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516435.023000 468340.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 281 033</ms:GML_ID>
        <ms:NAZWA>131 281 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131281033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517063.052000 468108.181000</gml:lowerCorner>
        		<gml:upperCorner>517063.052000 468108.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517063.052000 468108.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 281 706</ms:GML_ID>
        <ms:NAZWA>131 281 706</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131281706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518398.996279 467670.108658</gml:lowerCorner>
        		<gml:upperCorner>518398.996279 467670.108658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518398.996279 467670.108658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 283 113</ms:GML_ID>
        <ms:NAZWA>131 283 113</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131283113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519944.630000 467185.661000</gml:lowerCorner>
        		<gml:upperCorner>519944.630000 467185.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519944.630000 467185.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 284 733</ms:GML_ID>
        <ms:NAZWA>131 284 733</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131284733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520599.529000 466974.777000</gml:lowerCorner>
        		<gml:upperCorner>520599.529000 466974.777000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520599.529000 466974.777000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 285 423</ms:GML_ID>
        <ms:NAZWA>131 285 423</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131285423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522960.025000 466220.149000</gml:lowerCorner>
        		<gml:upperCorner>522960.025000 466220.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522960.025000 466220.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 287 901</ms:GML_ID>
        <ms:NAZWA>131 287 901</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131287901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486587.000000 453165.187000</gml:lowerCorner>
        		<gml:upperCorner>486587.000000 453165.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486587.000000 453165.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 199 678</ms:GML_ID>
        <ms:NAZWA>003 199 678</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003199678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485658.656000 454726.442000</gml:lowerCorner>
        		<gml:upperCorner>485658.656000 454726.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485658.656000 454726.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 197 856</ms:GML_ID>
        <ms:NAZWA>003 197 856</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003197856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485222.715000 455453.068000</gml:lowerCorner>
        		<gml:upperCorner>485222.715000 455453.068000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485222.715000 455453.068000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 197 010</ms:GML_ID>
        <ms:NAZWA>003 197 010</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003197010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485001.708000 456905.530000</gml:lowerCorner>
        		<gml:upperCorner>485001.708000 456905.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485001.708000 456905.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 195 524</ms:GML_ID>
        <ms:NAZWA>003 195 524</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003195524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484960.607000 458457.701000</gml:lowerCorner>
        		<gml:upperCorner>484960.607000 458457.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484960.607000 458457.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 193 969</ms:GML_ID>
        <ms:NAZWA>003 193 969</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003193969</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485125.406000 459545.625000</gml:lowerCorner>
        		<gml:upperCorner>485125.406000 459545.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485125.406000 459545.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 192 855</ms:GML_ID>
        <ms:NAZWA>003 192 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003192855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485978.226000 461460.300000</gml:lowerCorner>
        		<gml:upperCorner>485978.226000 461460.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485978.226000 461460.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 190 758</ms:GML_ID>
        <ms:NAZWA>003 190 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003190758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484852.968702 472942.576546</gml:lowerCorner>
        		<gml:upperCorner>484852.968702 472942.576546</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484852.968702 472942.576546</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 178 446</ms:GML_ID>
        <ms:NAZWA>003 178 446</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003178446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484429.488654 473350.219997</gml:lowerCorner>
        		<gml:upperCorner>484429.488654 473350.219997</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484429.488654 473350.219997</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 177 861</ms:GML_ID>
        <ms:NAZWA>003 177 861</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003177861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503764.192000 474674.054000</gml:lowerCorner>
        		<gml:upperCorner>503764.192000 474674.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503764.192000 474674.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 266 645</ms:GML_ID>
        <ms:NAZWA>131 266 645</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131266645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503135.263979 475239.227950</gml:lowerCorner>
        		<gml:upperCorner>503135.263979 475239.227950</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503135.263979 475239.227950</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 265 802</ms:GML_ID>
        <ms:NAZWA>131 265 802</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131265802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482488.944000 475262.749000</gml:lowerCorner>
        		<gml:upperCorner>482488.944000 475262.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482488.944000 475262.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 175 130</ms:GML_ID>
        <ms:NAZWA>003 175 130</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003175130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482425.193000 475512.529000</gml:lowerCorner>
        		<gml:upperCorner>482425.193000 475512.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482425.193000 475512.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 174 870</ms:GML_ID>
        <ms:NAZWA>003 174 870</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003174870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502024.265000 476237.605000</gml:lowerCorner>
        		<gml:upperCorner>502024.265000 476237.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502024.265000 476237.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 264 306</ms:GML_ID>
        <ms:NAZWA>131 264 306</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131264306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482514.727000 476656.260000</gml:lowerCorner>
        		<gml:upperCorner>482514.727000 476656.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482514.727000 476656.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 173 721</ms:GML_ID>
        <ms:NAZWA>003 173 721</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003173721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501125.056000 476750.121000</gml:lowerCorner>
        		<gml:upperCorner>501125.056000 476750.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501125.056000 476750.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 263 254</ms:GML_ID>
        <ms:NAZWA>131 263 254</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131263254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499474.763255 477293.058135</gml:lowerCorner>
        		<gml:upperCorner>499474.763255 477293.058135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499474.763255 477293.058135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 261 516</ms:GML_ID>
        <ms:NAZWA>131 261 516</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131261516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498087.582000 477751.037000</gml:lowerCorner>
        		<gml:upperCorner>498087.582000 477751.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498087.582000 477751.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 260 052</ms:GML_ID>
        <ms:NAZWA>131 260 052</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131260052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497394.964000 478360.756000</gml:lowerCorner>
        		<gml:upperCorner>497394.964000 478360.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497394.964000 478360.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 259 126</ms:GML_ID>
        <ms:NAZWA>131 259 126</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131259126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496465.942000 479258.106000</gml:lowerCorner>
        		<gml:upperCorner>496465.942000 479258.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496465.942000 479258.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 257 833</ms:GML_ID>
        <ms:NAZWA>131 257 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131257833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495912.632000 479791.067000</gml:lowerCorner>
        		<gml:upperCorner>495912.632000 479791.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495912.632000 479791.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 257 064</ms:GML_ID>
        <ms:NAZWA>131 257 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131257064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495262.357000 480268.673000</gml:lowerCorner>
        		<gml:upperCorner>495262.357000 480268.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495262.357000 480268.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 256 254</ms:GML_ID>
        <ms:NAZWA>131 256 254</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131256254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482921.530000 481595.572000</gml:lowerCorner>
        		<gml:upperCorner>482921.530000 481595.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482921.530000 481595.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 168 761</ms:GML_ID>
        <ms:NAZWA>003 168 761</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003168761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524039.799000 465874.318000</gml:lowerCorner>
        		<gml:upperCorner>524039.799000 465874.318000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524039.799000 465874.318000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 289 039</ms:GML_ID>
        <ms:NAZWA>131 289 039</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131289039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526308.255000 465149.189000</gml:lowerCorner>
        		<gml:upperCorner>526308.255000 465149.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526308.255000 465149.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 291 422</ms:GML_ID>
        <ms:NAZWA>131 291 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131291422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527177.735000 464871.284000</gml:lowerCorner>
        		<gml:upperCorner>527177.735000 464871.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527177.735000 464871.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 292 355</ms:GML_ID>
        <ms:NAZWA>131 292 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131292355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527933.766000 464597.321000</gml:lowerCorner>
        		<gml:upperCorner>527933.766000 464597.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527933.766000 464597.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 293 142</ms:GML_ID>
        <ms:NAZWA>131 293 142</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131293142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528346.156510 464361.040278</gml:lowerCorner>
        		<gml:upperCorner>528346.156510 464361.040278</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528346.156510 464361.040278</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 293 617</ms:GML_ID>
        <ms:NAZWA>131 293 617</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131293617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528778.727000 464110.607000</gml:lowerCorner>
        		<gml:upperCorner>528778.727000 464110.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528778.727000 464110.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 294 116</ms:GML_ID>
        <ms:NAZWA>131 294 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131294116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531266.611000 462671.848000</gml:lowerCorner>
        		<gml:upperCorner>531266.611000 462671.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531266.611000 462671.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 296 992</ms:GML_ID>
        <ms:NAZWA>131 296 992</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131296992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532574.120000 461915.999000</gml:lowerCorner>
        		<gml:upperCorner>532574.120000 461915.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532574.120000 461915.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 298 507</ms:GML_ID>
        <ms:NAZWA>131 298 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131298507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533284.066000 461505.949000</gml:lowerCorner>
        		<gml:upperCorner>533284.066000 461505.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533284.066000 461505.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 299 325</ms:GML_ID>
        <ms:NAZWA>131 299 325</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131299325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533855.447000 461175.646000</gml:lowerCorner>
        		<gml:upperCorner>533855.447000 461175.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533855.447000 461175.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 299 985</ms:GML_ID>
        <ms:NAZWA>131 299 985</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131299985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534319.721039 453719.134103</gml:lowerCorner>
        		<gml:upperCorner>534319.721039 453719.134103</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534319.721039 453719.134103</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 012 365</ms:GML_ID>
        <ms:NAZWA>231 012 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231012365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534650.095000 460717.127000</gml:lowerCorner>
        		<gml:upperCorner>534650.095000 460717.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534650.095000 460717.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 300 904</ms:GML_ID>
        <ms:NAZWA>131 300 904</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131300904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535211.228320 453381.398223</gml:lowerCorner>
        		<gml:upperCorner>535211.228320 453381.398223</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535211.228320 453381.398223</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 011 386</ms:GML_ID>
        <ms:NAZWA>231 011 386</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231011386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535253.697000 460367.660000</gml:lowerCorner>
        		<gml:upperCorner>535253.697000 460367.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535253.697000 460367.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 301 601</ms:GML_ID>
        <ms:NAZWA>131 301 601</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131301601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535805.301000 460049.107000</gml:lowerCorner>
        		<gml:upperCorner>535805.301000 460049.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535805.301000 460049.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 302 240</ms:GML_ID>
        <ms:NAZWA>131 302 240</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131302240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535993.895000 452881.713000</gml:lowerCorner>
        		<gml:upperCorner>535993.895000 452881.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535993.895000 452881.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 010 457</ms:GML_ID>
        <ms:NAZWA>231 010 457</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231010457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536529.398000 459631.058000</gml:lowerCorner>
        		<gml:upperCorner>536529.398000 459631.058000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536529.398000 459631.058000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 303 076</ms:GML_ID>
        <ms:NAZWA>131 303 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131303076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540352.241000 451167.990000</gml:lowerCorner>
        		<gml:upperCorner>540352.241000 451167.990000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540352.241000 451167.990000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 005 709</ms:GML_ID>
        <ms:NAZWA>231 005 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231005709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540201.420000 451198.212000</gml:lowerCorner>
        		<gml:upperCorner>540201.420000 451198.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540201.420000 451198.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 005 868</ms:GML_ID>
        <ms:NAZWA>231 005 868</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231005868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539418.392000 451368.385000</gml:lowerCorner>
        		<gml:upperCorner>539418.392000 451368.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539418.392000 451368.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 006 671</ms:GML_ID>
        <ms:NAZWA>231 006 671</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231006671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551611.454000 451394.521000</gml:lowerCorner>
        		<gml:upperCorner>551611.454000 451394.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551611.454000 451394.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 104 378</ms:GML_ID>
        <ms:NAZWA>353 104 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353104378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544063.690000 451510.008000</gml:lowerCorner>
        		<gml:upperCorner>544063.690000 451510.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544063.690000 451510.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 314 109</ms:GML_ID>
        <ms:NAZWA>131 314 109</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131314109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538729.399000 451538.501000</gml:lowerCorner>
        		<gml:upperCorner>538729.399000 451538.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538729.399000 451538.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 007 380</ms:GML_ID>
        <ms:NAZWA>231 007 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231007380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537737.733000 451828.374000</gml:lowerCorner>
        		<gml:upperCorner>537737.733000 451828.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537737.733000 451828.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 008 414</ms:GML_ID>
        <ms:NAZWA>231 008 414</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231008414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537579.490000 451889.041000</gml:lowerCorner>
        		<gml:upperCorner>537579.490000 451889.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537579.490000 451889.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 008 586</ms:GML_ID>
        <ms:NAZWA>231 008 586</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231008586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552230.093000 452148.802000</gml:lowerCorner>
        		<gml:upperCorner>552230.093000 452148.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552230.093000 452148.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 105 360</ms:GML_ID>
        <ms:NAZWA>353 105 360</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353105360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543230.777000 453047.970000</gml:lowerCorner>
        		<gml:upperCorner>543230.777000 453047.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543230.777000 453047.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 312 357</ms:GML_ID>
        <ms:NAZWA>131 312 357</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131312357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553118.195450 453234.365872</gml:lowerCorner>
        		<gml:upperCorner>553118.195450 453234.365872</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553118.195450 453234.365872</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 106 759</ms:GML_ID>
        <ms:NAZWA>353 106 759</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353106759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542643.941000 453677.721000</gml:lowerCorner>
        		<gml:upperCorner>542643.941000 453677.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542643.941000 453677.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 311 493</ms:GML_ID>
        <ms:NAZWA>131 311 493</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131311493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542129.597000 454227.094000</gml:lowerCorner>
        		<gml:upperCorner>542129.597000 454227.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542129.597000 454227.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 310 740</ms:GML_ID>
        <ms:NAZWA>131 310 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131310740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541734.966000 454649.590000</gml:lowerCorner>
        		<gml:upperCorner>541734.966000 454649.590000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541734.966000 454649.590000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 310 162</ms:GML_ID>
        <ms:NAZWA>131 310 162</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131310162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539275.376000 457283.370000</gml:lowerCorner>
        		<gml:upperCorner>539275.376000 457283.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539275.376000 457283.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 306 727</ms:GML_ID>
        <ms:NAZWA>131 306 727</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131306727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538305.114000 458322.249000</gml:lowerCorner>
        		<gml:upperCorner>538305.114000 458322.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538305.114000 458322.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 305 307</ms:GML_ID>
        <ms:NAZWA>131 305 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131305307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536862.209000 459440.010000</gml:lowerCorner>
        		<gml:upperCorner>536862.209000 459440.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536862.209000 459440.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 303 461</ms:GML_ID>
        <ms:NAZWA>131 303 461</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131303461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553348.743802 482707.893221</gml:lowerCorner>
        		<gml:upperCorner>553348.743802 482707.893221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553348.743802 482707.893221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 087 009</ms:GML_ID>
        <ms:NAZWA>018 087 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018087009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552976.773000 483415.574000</gml:lowerCorner>
        		<gml:upperCorner>552976.773000 483415.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552976.773000 483415.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 086 206</ms:GML_ID>
        <ms:NAZWA>018 086 206</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018086206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542298.044000 449850.324000</gml:lowerCorner>
        		<gml:upperCorner>542298.044000 449850.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542298.044000 449850.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 003 257</ms:GML_ID>
        <ms:NAZWA>231 003 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231003257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542822.924095 449751.253611</gml:lowerCorner>
        		<gml:upperCorner>542822.924095 449751.253611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542822.924095 449751.253611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 002 710</ms:GML_ID>
        <ms:NAZWA>231 002 710</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231002710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543165.080343 449672.990362</gml:lowerCorner>
        		<gml:upperCorner>543165.080343 449672.990362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543165.080343 449672.990362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 002 360</ms:GML_ID>
        <ms:NAZWA>231 002 360</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231002360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544014.014000 449363.442000</gml:lowerCorner>
        		<gml:upperCorner>544014.014000 449363.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544014.014000 449363.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 001 445</ms:GML_ID>
        <ms:NAZWA>231 001 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231001445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544332.751000 450937.829000</gml:lowerCorner>
        		<gml:upperCorner>544332.751000 450937.829000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544332.751000 450937.829000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 314 745</ms:GML_ID>
        <ms:NAZWA>131 314 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131314745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544418.916000 449253.347000</gml:lowerCorner>
        		<gml:upperCorner>544418.916000 449253.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544418.916000 449253.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 001 033</ms:GML_ID>
        <ms:NAZWA>231 001 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231001033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544862.633000 449265.544000</gml:lowerCorner>
        		<gml:upperCorner>544862.633000 449265.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544862.633000 449265.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 000 580</ms:GML_ID>
        <ms:NAZWA>231 000 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231000580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544910.198000 449508.785000</gml:lowerCorner>
        		<gml:upperCorner>544910.198000 449508.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544910.198000 449508.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 316 290</ms:GML_ID>
        <ms:NAZWA>131 316 290</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131316290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545906.230561 447002.085560</gml:lowerCorner>
        		<gml:upperCorner>545906.230561 447002.085560</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545906.230561 447002.085560</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 318 980</ms:GML_ID>
        <ms:NAZWA>131 318 980</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131318980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546561.701984 444973.110812</gml:lowerCorner>
        		<gml:upperCorner>546561.701984 444973.110812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546561.701984 444973.110812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 003 485</ms:GML_ID>
        <ms:NAZWA>206 003 485</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206003485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547347.792774 446731.768023</gml:lowerCorner>
        		<gml:upperCorner>547347.792774 446731.768023</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547347.792774 446731.768023</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 097 900</ms:GML_ID>
        <ms:NAZWA>353 097 900</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353097900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547419.409000 446747.361000</gml:lowerCorner>
        		<gml:upperCorner>547419.409000 446747.361000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547419.409000 446747.361000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 321 925</ms:GML_ID>
        <ms:NAZWA>131 321 925</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131321925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548006.475002 447451.798324</gml:lowerCorner>
        		<gml:upperCorner>548006.475002 447451.798324</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548006.475002 447451.798324</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 322 976</ms:GML_ID>
        <ms:NAZWA>131 322 976</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131322976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548479.191219 448714.148302</gml:lowerCorner>
        		<gml:upperCorner>548479.191219 448714.148302</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548479.191219 448714.148302</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 100 129</ms:GML_ID>
        <ms:NAZWA>353 100 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353100129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548580.374000 446662.284000</gml:lowerCorner>
        		<gml:upperCorner>548580.374000 446662.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548580.374000 446662.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.741 001 580</ms:GML_ID>
        <ms:NAZWA>741 001 580</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>741001580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549217.535000 446710.898000</gml:lowerCorner>
        		<gml:upperCorner>549217.535000 446710.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549217.535000 446710.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.741 002 220</ms:GML_ID>
        <ms:NAZWA>741 002 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>741002220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550117.749000 449777.887000</gml:lowerCorner>
        		<gml:upperCorner>550117.749000 449777.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550117.749000 449777.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 102 165</ms:GML_ID>
        <ms:NAZWA>353 102 165</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353102165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550843.918000 450459.492000</gml:lowerCorner>
        		<gml:upperCorner>550843.918000 450459.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550843.918000 450459.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 103 165</ms:GML_ID>
        <ms:NAZWA>353 103 165</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353103165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551059.127000 446851.557000</gml:lowerCorner>
        		<gml:upperCorner>551059.127000 446851.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551059.127000 446851.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.741 004 066</ms:GML_ID>
        <ms:NAZWA>741 004 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>741004066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551086.479822 450755.242023</gml:lowerCorner>
        		<gml:upperCorner>551086.479822 450755.242023</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551086.479822 450755.242023</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 103 560</ms:GML_ID>
        <ms:NAZWA>353 103 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353103560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552230.592000 447758.765000</gml:lowerCorner>
        		<gml:upperCorner>552230.592000 447758.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552230.592000 447758.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 328 461</ms:GML_ID>
        <ms:NAZWA>131 328 461</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131328461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552452.977000 446958.079000</gml:lowerCorner>
        		<gml:upperCorner>552452.977000 446958.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552452.977000 446958.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.741 005 454</ms:GML_ID>
        <ms:NAZWA>741 005 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>741005454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553332.386000 446987.011000</gml:lowerCorner>
        		<gml:upperCorner>553332.386000 446987.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553332.386000 446987.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.741 006 348</ms:GML_ID>
        <ms:NAZWA>741 006 348</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>741006348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553347.668000 447038.855000</gml:lowerCorner>
        		<gml:upperCorner>553347.668000 447038.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553347.668000 447038.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 329 790</ms:GML_ID>
        <ms:NAZWA>131 329 790</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131329790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552926.633023 430951.107853</gml:lowerCorner>
        		<gml:upperCorner>552926.633023 430951.107853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552926.633023 430951.107853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 020 160</ms:GML_ID>
        <ms:NAZWA>206 020 160</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206020160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552041.617000 433120.587000</gml:lowerCorner>
        		<gml:upperCorner>552041.617000 433120.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552041.617000 433120.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 017 764</ms:GML_ID>
        <ms:NAZWA>206 017 764</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206017764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551296.687000 434386.948000</gml:lowerCorner>
        		<gml:upperCorner>551296.687000 434386.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551296.687000 434386.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 016 267</ms:GML_ID>
        <ms:NAZWA>206 016 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206016267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550811.044000 435135.833000</gml:lowerCorner>
        		<gml:upperCorner>550811.044000 435135.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550811.044000 435135.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 015 386</ms:GML_ID>
        <ms:NAZWA>206 015 386</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206015386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550083.283000 436690.499000</gml:lowerCorner>
        		<gml:upperCorner>550083.283000 436690.499000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550083.283000 436690.499000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 013 639</ms:GML_ID>
        <ms:NAZWA>206 013 639</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206013639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549409.594000 437295.514000</gml:lowerCorner>
        		<gml:upperCorner>549409.594000 437295.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549409.594000 437295.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 012 739</ms:GML_ID>
        <ms:NAZWA>206 012 739</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206012739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549122.240851 437681.927489</gml:lowerCorner>
        		<gml:upperCorner>549122.240851 437681.927489</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549122.240851 437681.927489</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 012 260</ms:GML_ID>
        <ms:NAZWA>206 012 260</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206012260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548836.711000 438350.514000</gml:lowerCorner>
        		<gml:upperCorner>548836.711000 438350.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548836.711000 438350.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 011 526</ms:GML_ID>
        <ms:NAZWA>206 011 526</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206011526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548751.459000 439233.060000</gml:lowerCorner>
        		<gml:upperCorner>548751.459000 439233.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548751.459000 439233.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 010 628</ms:GML_ID>
        <ms:NAZWA>206 010 628</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206010628</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542074.677000 439680.805000</gml:lowerCorner>
        		<gml:upperCorner>542074.677000 439680.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542074.677000 439680.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 088 753</ms:GML_ID>
        <ms:NAZWA>353 088 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353088753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542792.879522 440234.490912</gml:lowerCorner>
        		<gml:upperCorner>542792.879522 440234.490912</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542792.879522 440234.490912</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 089 672</ms:GML_ID>
        <ms:NAZWA>353 089 672</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353089672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544676.889000 441445.094000</gml:lowerCorner>
        		<gml:upperCorner>544676.889000 441445.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544676.889000 441445.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 091 914</ms:GML_ID>
        <ms:NAZWA>353 091 914</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353091914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548426.599085 441456.878765</gml:lowerCorner>
        		<gml:upperCorner>548426.599085 441456.878765</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548426.599085 441456.878765</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 008 379</ms:GML_ID>
        <ms:NAZWA>206 008 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206008379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548376.646000 442434.839000</gml:lowerCorner>
        		<gml:upperCorner>548376.646000 442434.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548376.646000 442434.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 007 395</ms:GML_ID>
        <ms:NAZWA>206 007 395</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206007395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545533.278000 442458.706000</gml:lowerCorner>
        		<gml:upperCorner>545533.278000 442458.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545533.278000 442458.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 093 252</ms:GML_ID>
        <ms:NAZWA>353 093 252</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353093252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548335.898000 443178.455000</gml:lowerCorner>
        		<gml:upperCorner>548335.898000 443178.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548335.898000 443178.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 006 655</ms:GML_ID>
        <ms:NAZWA>206 006 655</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206006655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545870.011000 443231.922000</gml:lowerCorner>
        		<gml:upperCorner>545870.011000 443231.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545870.011000 443231.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 094 098</ms:GML_ID>
        <ms:NAZWA>353 094 098</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353094098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548114.475000 443730.832000</gml:lowerCorner>
        		<gml:upperCorner>548114.475000 443730.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548114.475000 443730.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 006 026</ms:GML_ID>
        <ms:NAZWA>206 006 026</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206006026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547165.308926 444134.474461</gml:lowerCorner>
        		<gml:upperCorner>547165.308926 444134.474461</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547165.308926 444134.474461</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 004 979</ms:GML_ID>
        <ms:NAZWA>206 004 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206004979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546436.981000 444462.719000</gml:lowerCorner>
        		<gml:upperCorner>546436.981000 444462.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546436.981000 444462.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 004 020</ms:GML_ID>
        <ms:NAZWA>206 004 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206004020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546480.664000 444678.921000</gml:lowerCorner>
        		<gml:upperCorner>546480.664000 444678.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546480.664000 444678.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 095 669</ms:GML_ID>
        <ms:NAZWA>353 095 669</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353095669</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554753.523568 428400.848825</gml:lowerCorner>
        		<gml:upperCorner>554753.523568 428400.848825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554753.523568 428400.848825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 023 322</ms:GML_ID>
        <ms:NAZWA>206 023 322</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206023322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555069.099000 427429.862000</gml:lowerCorner>
        		<gml:upperCorner>555069.099000 427429.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555069.099000 427429.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 024 340</ms:GML_ID>
        <ms:NAZWA>206 024 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206024340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555143.000000 445882.743000</gml:lowerCorner>
        		<gml:upperCorner>555143.000000 445882.743000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555143.000000 445882.743000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 331 924</ms:GML_ID>
        <ms:NAZWA>131 331 924</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131331924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557202.105000 444557.104000</gml:lowerCorner>
        		<gml:upperCorner>557202.105000 444557.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557202.105000 444557.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 334 376</ms:GML_ID>
        <ms:NAZWA>131 334 376</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131334376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558817.259000 443517.165000</gml:lowerCorner>
        		<gml:upperCorner>558817.259000 443517.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558817.259000 443517.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 336 301</ms:GML_ID>
        <ms:NAZWA>131 336 301</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131336301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559754.290000 442914.077000</gml:lowerCorner>
        		<gml:upperCorner>559754.290000 442914.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559754.290000 442914.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 337 416</ms:GML_ID>
        <ms:NAZWA>131 337 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131337416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560742.409903 442265.760281</gml:lowerCorner>
        		<gml:upperCorner>560742.409903 442265.760281</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560742.409903 442265.760281</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 338 598</ms:GML_ID>
        <ms:NAZWA>131 338 598</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131338598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561572.990000 441743.538000</gml:lowerCorner>
        		<gml:upperCorner>561572.990000 441743.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561572.990000 441743.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 339 581</ms:GML_ID>
        <ms:NAZWA>131 339 581</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131339581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562390.240000 441217.085000</gml:lowerCorner>
        		<gml:upperCorner>562390.240000 441217.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562390.240000 441217.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 340 552</ms:GML_ID>
        <ms:NAZWA>131 340 552</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131340552</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563290.493000 440637.879000</gml:lowerCorner>
        		<gml:upperCorner>563290.493000 440637.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563290.493000 440637.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 341 626</ms:GML_ID>
        <ms:NAZWA>131 341 626</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131341626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565475.493000 439744.612000</gml:lowerCorner>
        		<gml:upperCorner>565475.493000 439744.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565475.493000 439744.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 344 021</ms:GML_ID>
        <ms:NAZWA>131 344 021</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131344021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567606.006901 439307.622789</gml:lowerCorner>
        		<gml:upperCorner>567606.006901 439307.622789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567606.006901 439307.622789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 346 196</ms:GML_ID>
        <ms:NAZWA>131 346 196</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131346196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568205.031000 438833.631000</gml:lowerCorner>
        		<gml:upperCorner>568205.031000 438833.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568205.031000 438833.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 346 977</ms:GML_ID>
        <ms:NAZWA>131 346 977</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131346977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568449.609128 439140.585294</gml:lowerCorner>
        		<gml:upperCorner>568449.609128 439140.585294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568449.609128 439140.585294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 000 985</ms:GML_ID>
        <ms:NAZWA>201 000 985</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201000985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568514.371000 438442.719000</gml:lowerCorner>
        		<gml:upperCorner>568514.371000 438442.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568514.371000 438442.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 347 481</ms:GML_ID>
        <ms:NAZWA>131 347 481</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131347481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569301.907000 438868.861000</gml:lowerCorner>
        		<gml:upperCorner>569301.907000 438868.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569301.907000 438868.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 001 876</ms:GML_ID>
        <ms:NAZWA>201 001 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201001876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569801.437000 438809.736000</gml:lowerCorner>
        		<gml:upperCorner>569801.437000 438809.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569801.437000 438809.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 002 379</ms:GML_ID>
        <ms:NAZWA>201 002 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201002379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570317.550936 436813.187291</gml:lowerCorner>
        		<gml:upperCorner>570317.550936 436813.187291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570317.550936 436813.187291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 349 938</ms:GML_ID>
        <ms:NAZWA>131 349 938</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131349938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570634.847000 438645.053000</gml:lowerCorner>
        		<gml:upperCorner>570634.847000 438645.053000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570634.847000 438645.053000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 003 229</ms:GML_ID>
        <ms:NAZWA>201 003 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201003229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570892.751492 436425.395458</gml:lowerCorner>
        		<gml:upperCorner>570892.751492 436425.395458</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570892.751492 436425.395458</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 350 632</ms:GML_ID>
        <ms:NAZWA>131 350 632</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131350632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490961.042000 423010.294000</gml:lowerCorner>
        		<gml:upperCorner>490961.042000 423010.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490961.042000 423010.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 231 123</ms:GML_ID>
        <ms:NAZWA>003 231 123</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003231123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490880.301000 424061.721000</gml:lowerCorner>
        		<gml:upperCorner>490880.301000 424061.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490880.301000 424061.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 230 065</ms:GML_ID>
        <ms:NAZWA>003 230 065</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003230065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490261.313000 428349.021000</gml:lowerCorner>
        		<gml:upperCorner>490261.313000 428349.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490261.313000 428349.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 225 723</ms:GML_ID>
        <ms:NAZWA>003 225 723</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003225723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490064.520479 429896.277092</gml:lowerCorner>
        		<gml:upperCorner>490064.520479 429896.277092</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490064.520479 429896.277092</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 224 161</ms:GML_ID>
        <ms:NAZWA>003 224 161</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003224161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489801.966000 432431.155000</gml:lowerCorner>
        		<gml:upperCorner>489801.966000 432431.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489801.966000 432431.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 221 612</ms:GML_ID>
        <ms:NAZWA>003 221 612</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003221612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489593.575000 434437.807000</gml:lowerCorner>
        		<gml:upperCorner>489593.575000 434437.807000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489593.575000 434437.807000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 219 593</ms:GML_ID>
        <ms:NAZWA>003 219 593</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003219593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489133.244000 435694.292000</gml:lowerCorner>
        		<gml:upperCorner>489133.244000 435694.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489133.244000 435694.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 218 247</ms:GML_ID>
        <ms:NAZWA>003 218 247</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003218247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488060.803000 439271.386000</gml:lowerCorner>
        		<gml:upperCorner>488060.803000 439271.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488060.803000 439271.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 214 497</ms:GML_ID>
        <ms:NAZWA>003 214 497</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003214497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487432.313000 442050.381000</gml:lowerCorner>
        		<gml:upperCorner>487432.313000 442050.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487432.313000 442050.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 211 654</ms:GML_ID>
        <ms:NAZWA>003 211 654</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003211654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486767.267000 444438.953000</gml:lowerCorner>
        		<gml:upperCorner>486767.267000 444438.953000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486767.267000 444438.953000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 209 166</ms:GML_ID>
        <ms:NAZWA>003 209 166</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003209166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486400.335000 445742.976000</gml:lowerCorner>
        		<gml:upperCorner>486400.335000 445742.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486400.335000 445742.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 207 808</ms:GML_ID>
        <ms:NAZWA>003 207 808</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003207808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485245.906219 449449.767292</gml:lowerCorner>
        		<gml:upperCorner>485245.906219 449449.767292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485245.906219 449449.767292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 203 895</ms:GML_ID>
        <ms:NAZWA>003 203 895</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003203895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485476.420730 449734.479757</gml:lowerCorner>
        		<gml:upperCorner>485476.420730 449734.479757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485476.420730 449734.479757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 203 531</ms:GML_ID>
        <ms:NAZWA>003 203 531</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003203531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491436.549479 449905.872758</gml:lowerCorner>
        		<gml:upperCorner>491436.549479 449905.872758</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491436.549479 449905.872758</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 197 407</ms:GML_ID>
        <ms:NAZWA>003 197 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003197407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491836.630564 449927.750850</gml:lowerCorner>
        		<gml:upperCorner>491836.630564 449927.750850</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491836.630564 449927.750850</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 197 000</ms:GML_ID>
        <ms:NAZWA>003 197 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003197000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489001.054634 449975.335877</gml:lowerCorner>
        		<gml:upperCorner>489001.054634 449975.335877</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489001.054634 449975.335877</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 199 842</ms:GML_ID>
        <ms:NAZWA>003 199 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003199842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485756.526293 450016.082631</gml:lowerCorner>
        		<gml:upperCorner>485756.526293 450016.082631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485756.526293 450016.082631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 203 132</ms:GML_ID>
        <ms:NAZWA>003 203 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003203132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487789.644969 450116.471952</gml:lowerCorner>
        		<gml:upperCorner>487789.644969 450116.471952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487789.644969 450116.471952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 201 068</ms:GML_ID>
        <ms:NAZWA>003 201 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003201068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486770.403337 450181.450494</gml:lowerCorner>
        		<gml:upperCorner>486770.403337 450181.450494</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486770.403337 450181.450494</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 202 091</ms:GML_ID>
        <ms:NAZWA>003 202 091</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003202091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486619.882000 451880.343000</gml:lowerCorner>
        		<gml:upperCorner>486619.882000 451880.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486619.882000 451880.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 200 988</ms:GML_ID>
        <ms:NAZWA>003 200 988</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003200988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524032.387000 421997.353000</gml:lowerCorner>
        		<gml:upperCorner>524032.387000 421997.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524032.387000 421997.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 062 543</ms:GML_ID>
        <ms:NAZWA>353 062 543</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353062543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524896.869000 423338.871000</gml:lowerCorner>
        		<gml:upperCorner>524896.869000 423338.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524896.869000 423338.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 064 154</ms:GML_ID>
        <ms:NAZWA>353 064 154</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353064154</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524969.381000 423762.433000</gml:lowerCorner>
        		<gml:upperCorner>524969.381000 423762.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524969.381000 423762.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 064 588</ms:GML_ID>
        <ms:NAZWA>353 064 588</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353064588</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527181.001000 425409.126000</gml:lowerCorner>
        		<gml:upperCorner>527181.001000 425409.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527181.001000 425409.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 067 580</ms:GML_ID>
        <ms:NAZWA>353 067 580</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353067580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527814.891945 425799.894914</gml:lowerCorner>
        		<gml:upperCorner>527814.891945 425799.894914</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527814.891945 425799.894914</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 068 325</ms:GML_ID>
        <ms:NAZWA>353 068 325</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353068325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528501.100334 426214.466776</gml:lowerCorner>
        		<gml:upperCorner>528501.100334 426214.466776</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528501.100334 426214.466776</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 069 131</ms:GML_ID>
        <ms:NAZWA>353 069 131</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353069131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529187.900000 426652.702000</gml:lowerCorner>
        		<gml:upperCorner>529187.900000 426652.702000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529187.900000 426652.702000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 069 941</ms:GML_ID>
        <ms:NAZWA>353 069 941</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353069941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529827.997000 427050.107000</gml:lowerCorner>
        		<gml:upperCorner>529827.997000 427050.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529827.997000 427050.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 070 694</ms:GML_ID>
        <ms:NAZWA>353 070 694</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353070694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530606.813000 427533.580000</gml:lowerCorner>
        		<gml:upperCorner>530606.813000 427533.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530606.813000 427533.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 071 613</ms:GML_ID>
        <ms:NAZWA>353 071 613</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353071613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531622.410000 428163.972000</gml:lowerCorner>
        		<gml:upperCorner>531622.410000 428163.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531622.410000 428163.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 072 807</ms:GML_ID>
        <ms:NAZWA>353 072 807</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353072807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533284.545237 428792.904468</gml:lowerCorner>
        		<gml:upperCorner>533284.545237 428792.904468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533284.545237 428792.904468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 074 594</ms:GML_ID>
        <ms:NAZWA>353 074 594</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353074594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534261.970000 429373.278000</gml:lowerCorner>
        		<gml:upperCorner>534261.970000 429373.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534261.970000 429373.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 075 759</ms:GML_ID>
        <ms:NAZWA>353 075 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353075759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534784.844000 429972.851000</gml:lowerCorner>
        		<gml:upperCorner>534784.844000 429972.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534784.844000 429972.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 076 555</ms:GML_ID>
        <ms:NAZWA>353 076 555</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353076555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535371.784000 430645.615000</gml:lowerCorner>
        		<gml:upperCorner>535371.784000 430645.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535371.784000 430645.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 077 446</ms:GML_ID>
        <ms:NAZWA>353 077 446</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353077446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536247.558000 431649.308000</gml:lowerCorner>
        		<gml:upperCorner>536247.558000 431649.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536247.558000 431649.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 078 778</ms:GML_ID>
        <ms:NAZWA>353 078 778</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353078778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537286.461000 432840.682000</gml:lowerCorner>
        		<gml:upperCorner>537286.461000 432840.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537286.461000 432840.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 080 353</ms:GML_ID>
        <ms:NAZWA>353 080 353</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353080353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538712.166000 434476.804000</gml:lowerCorner>
        		<gml:upperCorner>538712.166000 434476.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538712.166000 434476.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 082 532</ms:GML_ID>
        <ms:NAZWA>353 082 532</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353082532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538984.790046 434772.308056</gml:lowerCorner>
        		<gml:upperCorner>538984.790046 434772.308056</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538984.790046 434772.308056</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 082 930</ms:GML_ID>
        <ms:NAZWA>353 082 930</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353082930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541421.091000 438569.428000</gml:lowerCorner>
        		<gml:upperCorner>541421.091000 438569.428000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541421.091000 438569.428000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 087 462</ms:GML_ID>
        <ms:NAZWA>353 087 462</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353087462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541459.247000 450810.860000</gml:lowerCorner>
        		<gml:upperCorner>541459.247000 450810.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541459.247000 450810.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 004 537</ms:GML_ID>
        <ms:NAZWA>231 004 537</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231004537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541787.485000 450454.574000</gml:lowerCorner>
        		<gml:upperCorner>541787.485000 450454.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541787.485000 450454.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.231 004 061</ms:GML_ID>
        <ms:NAZWA>231 004 061</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>231004061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570731.667000 412686.422000</gml:lowerCorner>
        		<gml:upperCorner>570731.667000 412686.422000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570731.667000 412686.422000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 099 699</ms:GML_ID>
        <ms:NAZWA>356 099 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356099699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570743.282000 413893.539000</gml:lowerCorner>
        		<gml:upperCorner>570743.282000 413893.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570743.282000 413893.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 100 906</ms:GML_ID>
        <ms:NAZWA>356 100 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356100906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570751.494000 414753.548000</gml:lowerCorner>
        		<gml:upperCorner>570751.494000 414753.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570751.494000 414753.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 101 766</ms:GML_ID>
        <ms:NAZWA>356 101 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356101766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554384.783000 415019.054000</gml:lowerCorner>
        		<gml:upperCorner>554384.783000 415019.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554384.783000 415019.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 037 558</ms:GML_ID>
        <ms:NAZWA>206 037 558</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206037558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570787.184000 415394.415000</gml:lowerCorner>
        		<gml:upperCorner>570787.184000 415394.415000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570787.184000 415394.415000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 102 412</ms:GML_ID>
        <ms:NAZWA>356 102 412</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356102412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554055.584000 415513.905000</gml:lowerCorner>
        		<gml:upperCorner>554055.584000 415513.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554055.584000 415513.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 036 963</ms:GML_ID>
        <ms:NAZWA>206 036 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206036963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553816.336000 417070.249000</gml:lowerCorner>
        		<gml:upperCorner>553816.336000 417070.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553816.336000 417070.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 035 386</ms:GML_ID>
        <ms:NAZWA>206 035 386</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206035386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553777.225000 418342.352000</gml:lowerCorner>
        		<gml:upperCorner>553777.225000 418342.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553777.225000 418342.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 034 111</ms:GML_ID>
        <ms:NAZWA>206 034 111</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206034111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553775.460000 418691.689000</gml:lowerCorner>
        		<gml:upperCorner>553775.460000 418691.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553775.460000 418691.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 033 761</ms:GML_ID>
        <ms:NAZWA>206 033 761</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206033761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553865.738000 420002.524000</gml:lowerCorner>
        		<gml:upperCorner>553865.738000 420002.524000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553865.738000 420002.524000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 032 441</ms:GML_ID>
        <ms:NAZWA>206 032 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206032441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553976.495000 420540.610000</gml:lowerCorner>
        		<gml:upperCorner>553976.495000 420540.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553976.495000 420540.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 031 894</ms:GML_ID>
        <ms:NAZWA>206 031 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206031894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554029.539000 420797.574000</gml:lowerCorner>
        		<gml:upperCorner>554029.539000 420797.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554029.539000 420797.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 031 629</ms:GML_ID>
        <ms:NAZWA>206 031 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206031629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554221.188000 421490.835000</gml:lowerCorner>
        		<gml:upperCorner>554221.188000 421490.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554221.188000 421490.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 030 908</ms:GML_ID>
        <ms:NAZWA>206 030 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206030908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554454.813000 421999.003000</gml:lowerCorner>
        		<gml:upperCorner>554454.813000 421999.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554454.813000 421999.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 030 347</ms:GML_ID>
        <ms:NAZWA>206 030 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206030347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555626.860000 424084.046000</gml:lowerCorner>
        		<gml:upperCorner>555626.860000 424084.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555626.860000 424084.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 027 935</ms:GML_ID>
        <ms:NAZWA>206 027 935</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206027935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555320.861000 424896.460000</gml:lowerCorner>
        		<gml:upperCorner>555320.861000 424896.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555320.861000 424896.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 027 030</ms:GML_ID>
        <ms:NAZWA>206 027 030</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206027030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555256.128000 426427.568000</gml:lowerCorner>
        		<gml:upperCorner>555256.128000 426427.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555256.128000 426427.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 025 371</ms:GML_ID>
        <ms:NAZWA>206 025 371</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206025371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555145.077000 427103.733000</gml:lowerCorner>
        		<gml:upperCorner>555145.077000 427103.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555145.077000 427103.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.206 024 681</ms:GML_ID>
        <ms:NAZWA>206 024 681</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>206024681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496587.127000 409717.601000</gml:lowerCorner>
        		<gml:upperCorner>496587.127000 409717.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496587.127000 409717.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 246 238</ms:GML_ID>
        <ms:NAZWA>003 246 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003246238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519514.003000 410387.896000</gml:lowerCorner>
        		<gml:upperCorner>519514.003000 410387.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519514.003000 410387.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 049 818</ms:GML_ID>
        <ms:NAZWA>353 049 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353049818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496063.149000 412530.740000</gml:lowerCorner>
        		<gml:upperCorner>496063.149000 412530.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496063.149000 412530.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 243 366</ms:GML_ID>
        <ms:NAZWA>003 243 366</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003243366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519995.108000 413188.925000</gml:lowerCorner>
        		<gml:upperCorner>519995.108000 413188.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519995.108000 413188.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 052 706</ms:GML_ID>
        <ms:NAZWA>353 052 706</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353052706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495974.429000 413420.188000</gml:lowerCorner>
        		<gml:upperCorner>495974.429000 413420.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495974.429000 413420.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 242 472</ms:GML_ID>
        <ms:NAZWA>003 242 472</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003242472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520778.651000 414644.554000</gml:lowerCorner>
        		<gml:upperCorner>520778.651000 414644.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520778.651000 414644.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 054 359</ms:GML_ID>
        <ms:NAZWA>353 054 359</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353054359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495811.406000 415063.506000</gml:lowerCorner>
        		<gml:upperCorner>495811.406000 415063.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495811.406000 415063.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 240 818</ms:GML_ID>
        <ms:NAZWA>003 240 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003240818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521595.567000 415870.113000</gml:lowerCorner>
        		<gml:upperCorner>521595.567000 415870.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521595.567000 415870.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 055 848</ms:GML_ID>
        <ms:NAZWA>353 055 848</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353055848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522091.256000 416290.365000</gml:lowerCorner>
        		<gml:upperCorner>522091.256000 416290.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522091.256000 416290.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 056 496</ms:GML_ID>
        <ms:NAZWA>353 056 496</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353056496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495117.537000 416934.110000</gml:lowerCorner>
        		<gml:upperCorner>495117.537000 416934.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495117.537000 416934.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 238 799</ms:GML_ID>
        <ms:NAZWA>003 238 799</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003238799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522643.278000 417731.623000</gml:lowerCorner>
        		<gml:upperCorner>522643.278000 417731.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522643.278000 417731.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 058 054</ms:GML_ID>
        <ms:NAZWA>353 058 054</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353058054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494332.861662 419161.401325</gml:lowerCorner>
        		<gml:upperCorner>494332.861662 419161.401325</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494332.861662 419161.401325</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 236 436</ms:GML_ID>
        <ms:NAZWA>003 236 436</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003236436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494230.351982 419375.948390</gml:lowerCorner>
        		<gml:upperCorner>494230.351982 419375.948390</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494230.351982 419375.948390</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 236 198</ms:GML_ID>
        <ms:NAZWA>003 236 198</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003236198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523394.273000 420110.356000</gml:lowerCorner>
        		<gml:upperCorner>523394.273000 420110.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523394.273000 420110.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 060 550</ms:GML_ID>
        <ms:NAZWA>353 060 550</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353060550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493418.768369 420503.492210</gml:lowerCorner>
        		<gml:upperCorner>493418.768369 420503.492210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493418.768369 420503.492210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 234 812</ms:GML_ID>
        <ms:NAZWA>003 234 812</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003234812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523543.356000 420583.021000</gml:lowerCorner>
        		<gml:upperCorner>523543.356000 420583.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523543.356000 420583.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 061 046</ms:GML_ID>
        <ms:NAZWA>353 061 046</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353061046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492647.041865 421279.508544</gml:lowerCorner>
        		<gml:upperCorner>492647.041865 421279.508544</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492647.041865 421279.508544</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 233 710</ms:GML_ID>
        <ms:NAZWA>003 233 710</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003233710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523813.408000 421440.729000</gml:lowerCorner>
        		<gml:upperCorner>523813.408000 421440.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523813.408000 421440.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 061 946</ms:GML_ID>
        <ms:NAZWA>353 061 946</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353061946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491113.043000 422332.482000</gml:lowerCorner>
        		<gml:upperCorner>491113.043000 422332.482000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491113.043000 422332.482000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 231 825</ms:GML_ID>
        <ms:NAZWA>003 231 825</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003231825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456989.856000 392812.670000</gml:lowerCorner>
        		<gml:upperCorner>456989.856000 392812.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456989.856000 392812.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 004 361</ms:GML_ID>
        <ms:NAZWA>360 004 361</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360004361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462838.062681 393144.151046</gml:lowerCorner>
        		<gml:upperCorner>462838.062681 393144.151046</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462838.062681 393144.151046</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 140 700</ms:GML_ID>
        <ms:NAZWA>272 140 700</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272140700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462153.295000 393442.522000</gml:lowerCorner>
        		<gml:upperCorner>462153.295000 393442.522000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462153.295000 393442.522000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 139 956</ms:GML_ID>
        <ms:NAZWA>272 139 956</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272139956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457007.312649 393531.665694</gml:lowerCorner>
        		<gml:upperCorner>457007.312649 393531.665694</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457007.312649 393531.665694</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 003 641</ms:GML_ID>
        <ms:NAZWA>360 003 641</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360003641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457168.851705 394253.698779</gml:lowerCorner>
        		<gml:upperCorner>457168.851705 394253.698779</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457168.851705 394253.698779</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 002 900</ms:GML_ID>
        <ms:NAZWA>360 002 900</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360002900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457358.680000 395099.553000</gml:lowerCorner>
        		<gml:upperCorner>457358.680000 395099.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457358.680000 395099.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 002 035</ms:GML_ID>
        <ms:NAZWA>360 002 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360002035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457502.933000 395739.652000</gml:lowerCorner>
        		<gml:upperCorner>457502.933000 395739.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457502.933000 395739.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 001 377</ms:GML_ID>
        <ms:NAZWA>360 001 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360001377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474024.150439 395832.287714</gml:lowerCorner>
        		<gml:upperCorner>474024.150439 395832.287714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474024.150439 395832.287714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 112 170</ms:GML_ID>
        <ms:NAZWA>281 112 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281112170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474458.283081 395837.463741</gml:lowerCorner>
        		<gml:upperCorner>474458.283081 395837.463741</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474458.283081 395837.463741</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 112 603</ms:GML_ID>
        <ms:NAZWA>281 112 603</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281112603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481349.057000 395843.068000</gml:lowerCorner>
        		<gml:upperCorner>481349.057000 395843.068000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481349.057000 395843.068000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 119 500</ms:GML_ID>
        <ms:NAZWA>281 119 500</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281119500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453511.143000 395876.001000</gml:lowerCorner>
        		<gml:upperCorner>453511.143000 395876.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453511.143000 395876.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 090 990</ms:GML_ID>
        <ms:NAZWA>281 090 990</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281090990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485790.398330 396157.222822</gml:lowerCorner>
        		<gml:upperCorner>485790.398330 396157.222822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485790.398330 396157.222822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 123 963</ms:GML_ID>
        <ms:NAZWA>281 123 963</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281123963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457594.622000 396180.429000</gml:lowerCorner>
        		<gml:upperCorner>457594.622000 396180.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457594.622000 396180.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 000 927</ms:GML_ID>
        <ms:NAZWA>360 000 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360000927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454249.061000 396257.668000</gml:lowerCorner>
        		<gml:upperCorner>454249.061000 396257.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454249.061000 396257.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 091 823</ms:GML_ID>
        <ms:NAZWA>281 091 823</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281091823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454559.142000 396418.644000</gml:lowerCorner>
        		<gml:upperCorner>454559.142000 396418.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454559.142000 396418.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 092 172</ms:GML_ID>
        <ms:NAZWA>281 092 172</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281092172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457503.800000 396449.173000</gml:lowerCorner>
        		<gml:upperCorner>457503.800000 396449.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457503.800000 396449.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 000 634</ms:GML_ID>
        <ms:NAZWA>360 000 634</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360000634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469154.334000 397049.284000</gml:lowerCorner>
        		<gml:upperCorner>469154.334000 397049.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469154.334000 397049.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 106 889</ms:GML_ID>
        <ms:NAZWA>281 106 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281106889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468485.622228 397056.411684</gml:lowerCorner>
        		<gml:upperCorner>468485.622228 397056.411684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468485.622228 397056.411684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 106 220</ms:GML_ID>
        <ms:NAZWA>281 106 220</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281106220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463999.160000 397102.952000</gml:lowerCorner>
        		<gml:upperCorner>463999.160000 397102.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463999.160000 397102.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 101 731</ms:GML_ID>
        <ms:NAZWA>281 101 731</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281101731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463289.603000 397109.647000</gml:lowerCorner>
        		<gml:upperCorner>463289.603000 397109.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463289.603000 397109.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 101 019</ms:GML_ID>
        <ms:NAZWA>281 101 019</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281101019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461548.845000 397123.933000</gml:lowerCorner>
        		<gml:upperCorner>461548.845000 397123.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461548.845000 397123.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 099 278</ms:GML_ID>
        <ms:NAZWA>281 099 278</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281099278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461291.339000 397126.036000</gml:lowerCorner>
        		<gml:upperCorner>461291.339000 397126.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461291.339000 397126.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 099 021</ms:GML_ID>
        <ms:NAZWA>281 099 021</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281099021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454795.943000 397212.607000</gml:lowerCorner>
        		<gml:upperCorner>454795.943000 397212.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454795.943000 397212.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 131 172</ms:GML_ID>
        <ms:NAZWA>272 131 172</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272131172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488074.826000 397381.005000</gml:lowerCorner>
        		<gml:upperCorner>488074.826000 397381.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488074.826000 397381.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 126 554</ms:GML_ID>
        <ms:NAZWA>281 126 554</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281126554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453920.824000 398879.724000</gml:lowerCorner>
        		<gml:upperCorner>453920.824000 398879.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453920.824000 398879.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 129 284</ms:GML_ID>
        <ms:NAZWA>272 129 284</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272129284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453566.566000 399992.124000</gml:lowerCorner>
        		<gml:upperCorner>453566.566000 399992.124000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453566.566000 399992.124000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 128 118</ms:GML_ID>
        <ms:NAZWA>272 128 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272128118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488353.887000 437984.561000</gml:lowerCorner>
        		<gml:upperCorner>488353.887000 437984.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488353.887000 437984.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 215 818</ms:GML_ID>
        <ms:NAZWA>003 215 818</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003215818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487035.755000 443486.450000</gml:lowerCorner>
        		<gml:upperCorner>487035.755000 443486.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487035.755000 443486.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 210 155</ms:GML_ID>
        <ms:NAZWA>003 210 155</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003210155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234197.799474 479919.262558</gml:lowerCorner>
        		<gml:upperCorner>234197.799474 479919.262558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234197.799474 479919.262558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.159 022 712</ms:GML_ID>
        <ms:NAZWA>159 022 712</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>159022712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238010.164000 479305.126000</gml:lowerCorner>
        		<gml:upperCorner>238010.164000 479305.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238010.164000 479305.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.159 018 823</ms:GML_ID>
        <ms:NAZWA>159 018 823</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>159018823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240781.932000 486363.405000</gml:lowerCorner>
        		<gml:upperCorner>240781.932000 486363.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240781.932000 486363.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 013 509</ms:GML_ID>
        <ms:NAZWA>148 013 509</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148013509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240909.668000 484811.372000</gml:lowerCorner>
        		<gml:upperCorner>240909.668000 484811.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240909.668000 484811.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 015 067</ms:GML_ID>
        <ms:NAZWA>148 015 067</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148015067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241023.864000 484385.618000</gml:lowerCorner>
        		<gml:upperCorner>241023.864000 484385.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241023.864000 484385.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 015 512</ms:GML_ID>
        <ms:NAZWA>148 015 512</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148015512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241894.143560 483041.789042</gml:lowerCorner>
        		<gml:upperCorner>241894.143560 483041.789042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241894.143560 483041.789042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 017 114</ms:GML_ID>
        <ms:NAZWA>148 017 114</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148017114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241898.919000 479045.013000</gml:lowerCorner>
        		<gml:upperCorner>241898.919000 479045.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241898.919000 479045.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.159 014 850</ms:GML_ID>
        <ms:NAZWA>159 014 850</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>159014850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241932.760000 480502.784000</gml:lowerCorner>
        		<gml:upperCorner>241932.760000 480502.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241932.760000 480502.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 019 705</ms:GML_ID>
        <ms:NAZWA>148 019 705</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148019705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241978.610612 481599.702281</gml:lowerCorner>
        		<gml:upperCorner>241978.610612 481599.702281</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241978.610612 481599.702281</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 018 599</ms:GML_ID>
        <ms:NAZWA>148 018 599</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148018599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242070.658199 482498.386507</gml:lowerCorner>
        		<gml:upperCorner>242070.658199 482498.386507</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242070.658199 482498.386507</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 017 694</ms:GML_ID>
        <ms:NAZWA>148 017 694</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148017694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242130.554000 479670.813000</gml:lowerCorner>
        		<gml:upperCorner>242130.554000 479670.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242130.554000 479670.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 020 570</ms:GML_ID>
        <ms:NAZWA>148 020 570</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148020570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251981.175000 485960.048000</gml:lowerCorner>
        		<gml:upperCorner>251981.175000 485960.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251981.175000 485960.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 012 384</ms:GML_ID>
        <ms:NAZWA>169 012 384</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169012384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252066.623000 485467.714000</gml:lowerCorner>
        		<gml:upperCorner>252066.623000 485467.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252066.623000 485467.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 012 885</ms:GML_ID>
        <ms:NAZWA>169 012 885</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169012885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252235.487000 485034.000000</gml:lowerCorner>
        		<gml:upperCorner>252235.487000 485034.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252235.487000 485034.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 013 351</ms:GML_ID>
        <ms:NAZWA>169 013 351</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169013351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252547.266000 484356.334000</gml:lowerCorner>
        		<gml:upperCorner>252547.266000 484356.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252547.266000 484356.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 014 098</ms:GML_ID>
        <ms:NAZWA>169 014 098</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169014098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252711.136000 478609.199000</gml:lowerCorner>
        		<gml:upperCorner>252711.136000 478609.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252711.136000 478609.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 024 643</ms:GML_ID>
        <ms:NAZWA>140 024 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140024643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252752.178000 480130.285000</gml:lowerCorner>
        		<gml:upperCorner>252752.178000 480130.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252752.178000 480130.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 023 100</ms:GML_ID>
        <ms:NAZWA>140 023 100</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140023100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252791.392000 483826.084000</gml:lowerCorner>
        		<gml:upperCorner>252791.392000 483826.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252791.392000 483826.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 014 682</ms:GML_ID>
        <ms:NAZWA>169 014 682</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169014682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252901.481000 483515.050000</gml:lowerCorner>
        		<gml:upperCorner>252901.481000 483515.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252901.481000 483515.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 015 014</ms:GML_ID>
        <ms:NAZWA>169 015 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169015014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252975.117000 483189.286000</gml:lowerCorner>
        		<gml:upperCorner>252975.117000 483189.286000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252975.117000 483189.286000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.169 015 347</ms:GML_ID>
        <ms:NAZWA>169 015 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>169015347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253125.808000 481786.056000</gml:lowerCorner>
        		<gml:upperCorner>253125.808000 481786.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253125.808000 481786.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 021 396</ms:GML_ID>
        <ms:NAZWA>140 021 396</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140021396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253154.130000 482398.819000</gml:lowerCorner>
        		<gml:upperCorner>253154.130000 482398.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253154.130000 482398.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 020 783</ms:GML_ID>
        <ms:NAZWA>140 020 783</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140020783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253198.602000 483025.054000</gml:lowerCorner>
        		<gml:upperCorner>253198.602000 483025.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253198.602000 483025.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 020 154</ms:GML_ID>
        <ms:NAZWA>140 020 154</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140020154</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253378.731000 483551.616000</gml:lowerCorner>
        		<gml:upperCorner>253378.731000 483551.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253378.731000 483551.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 019 593</ms:GML_ID>
        <ms:NAZWA>140 019 593</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140019593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253650.673208 477430.213570</gml:lowerCorner>
        		<gml:upperCorner>253650.673208 477430.213570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253650.673208 477430.213570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 026 172</ms:GML_ID>
        <ms:NAZWA>140 026 172</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140026172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254574.185000 484381.078000</gml:lowerCorner>
        		<gml:upperCorner>254574.185000 484381.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254574.185000 484381.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 018 128</ms:GML_ID>
        <ms:NAZWA>140 018 128</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140018128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255263.082000 485886.710000</gml:lowerCorner>
        		<gml:upperCorner>255263.082000 485886.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255263.082000 485886.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 016 423</ms:GML_ID>
        <ms:NAZWA>140 016 423</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140016423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259626.428000 482315.996000</gml:lowerCorner>
        		<gml:upperCorner>259626.428000 482315.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259626.428000 482315.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.172 004 103</ms:GML_ID>
        <ms:NAZWA>172 004 103</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>172004103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261086.790775 478756.949596</gml:lowerCorner>
        		<gml:upperCorner>261086.790775 478756.949596</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261086.790775 478756.949596</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 010 869</ms:GML_ID>
        <ms:NAZWA>149 010 869</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149010869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261213.821791 480613.084404</gml:lowerCorner>
        		<gml:upperCorner>261213.821791 480613.084404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261213.821791 480613.084404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 009 009</ms:GML_ID>
        <ms:NAZWA>149 009 009</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149009009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261357.539000 481818.259000</gml:lowerCorner>
        		<gml:upperCorner>261357.539000 481818.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261357.539000 481818.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.172 002 106</ms:GML_ID>
        <ms:NAZWA>172 002 106</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>172002106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262046.413156 481963.023653</gml:lowerCorner>
        		<gml:upperCorner>262046.413156 481963.023653</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262046.413156 481963.023653</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 007 304</ms:GML_ID>
        <ms:NAZWA>149 007 304</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149007304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263339.718000 481256.721000</gml:lowerCorner>
        		<gml:upperCorner>263339.718000 481256.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263339.718000 481256.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 005 797</ms:GML_ID>
        <ms:NAZWA>149 005 797</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149005797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264352.259000 481188.748000</gml:lowerCorner>
        		<gml:upperCorner>264352.259000 481188.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264352.259000 481188.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 004 748</ms:GML_ID>
        <ms:NAZWA>149 004 748</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149004748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264553.580000 481239.416000</gml:lowerCorner>
        		<gml:upperCorner>264553.580000 481239.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264553.580000 481239.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 004 539</ms:GML_ID>
        <ms:NAZWA>149 004 539</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149004539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264727.103714 481278.890650</gml:lowerCorner>
        		<gml:upperCorner>264727.103714 481278.890650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264727.103714 481278.890650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 004 360</ms:GML_ID>
        <ms:NAZWA>149 004 360</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149004360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266071.718000 481746.311000</gml:lowerCorner>
        		<gml:upperCorner>266071.718000 481746.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266071.718000 481746.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 002 864</ms:GML_ID>
        <ms:NAZWA>149 002 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149002864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>266507.468000 482215.543000</gml:lowerCorner>
        		<gml:upperCorner>266507.468000 482215.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>266507.468000 482215.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 002 225</ms:GML_ID>
        <ms:NAZWA>149 002 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149002225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267065.573407 483912.711468</gml:lowerCorner>
        		<gml:upperCorner>267065.573407 483912.711468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267065.573407 483912.711468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.141 016 850</ms:GML_ID>
        <ms:NAZWA>141 016 850</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>141016850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268456.863619 481618.969061</gml:lowerCorner>
        		<gml:upperCorner>268456.863619 481618.969061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268456.863619 481618.969061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.200 005 983</ms:GML_ID>
        <ms:NAZWA>200 005 983</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>200005983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269269.994000 481609.343000</gml:lowerCorner>
        		<gml:upperCorner>269269.994000 481609.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269269.994000 481609.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.200 005 137</ms:GML_ID>
        <ms:NAZWA>200 005 137</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>200005137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269860.049882 481221.636748</gml:lowerCorner>
        		<gml:upperCorner>269860.049882 481221.636748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269860.049882 481221.636748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.200 004 387</ms:GML_ID>
        <ms:NAZWA>200 004 387</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>200004387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270124.202000 479315.686000</gml:lowerCorner>
        		<gml:upperCorner>270124.202000 479315.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270124.202000 479315.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.671 002 820</ms:GML_ID>
        <ms:NAZWA>671 002 820</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>671002820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>270575.729232 479981.260088</gml:lowerCorner>
        		<gml:upperCorner>270575.729232 479981.260088</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>270575.729232 479981.260088</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.671 003 388</ms:GML_ID>
        <ms:NAZWA>671 003 388</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>671003388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212455.008000 471661.888000</gml:lowerCorner>
        		<gml:upperCorner>212455.008000 471661.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212455.008000 471661.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 025 187</ms:GML_ID>
        <ms:NAZWA>090 025 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090025187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211500.588000 472065.392000</gml:lowerCorner>
        		<gml:upperCorner>211500.588000 472065.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211500.588000 472065.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 026 235</ms:GML_ID>
        <ms:NAZWA>090 026 235</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090026235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>211168.783000 472119.201000</gml:lowerCorner>
        		<gml:upperCorner>211168.783000 472119.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>211168.783000 472119.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 026 574</ms:GML_ID>
        <ms:NAZWA>090 026 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090026574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210549.821000 472478.945000</gml:lowerCorner>
        		<gml:upperCorner>210549.821000 472478.945000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210549.821000 472478.945000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 027 310</ms:GML_ID>
        <ms:NAZWA>090 027 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090027310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209726.257000 472592.939000</gml:lowerCorner>
        		<gml:upperCorner>209726.257000 472592.939000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209726.257000 472592.939000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.695 000 472</ms:GML_ID>
        <ms:NAZWA>695 000 472</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>695000472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>210014.601000 472604.743000</gml:lowerCorner>
        		<gml:upperCorner>210014.601000 472604.743000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>210014.601000 472604.743000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 027 870</ms:GML_ID>
        <ms:NAZWA>090 027 870</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090027870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209685.813000 472654.104000</gml:lowerCorner>
        		<gml:upperCorner>209685.813000 472654.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209685.813000 472654.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 039 950</ms:GML_ID>
        <ms:NAZWA>190 039 950</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190039950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209751.289000 472818.468000</gml:lowerCorner>
        		<gml:upperCorner>209751.289000 472818.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209751.289000 472818.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 039 770</ms:GML_ID>
        <ms:NAZWA>190 039 770</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190039770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209729.787610 472949.136052</gml:lowerCorner>
        		<gml:upperCorner>209729.787610 472949.136052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209729.787610 472949.136052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 039 637</ms:GML_ID>
        <ms:NAZWA>190 039 637</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190039637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209488.610000 473240.934000</gml:lowerCorner>
        		<gml:upperCorner>209488.610000 473240.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209488.610000 473240.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 039 257</ms:GML_ID>
        <ms:NAZWA>190 039 257</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190039257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209358.699431 473880.030380</gml:lowerCorner>
        		<gml:upperCorner>209358.699431 473880.030380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209358.699431 473880.030380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 038 608</ms:GML_ID>
        <ms:NAZWA>190 038 608</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190038608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209322.734882 474047.769020</gml:lowerCorner>
        		<gml:upperCorner>209322.734882 474047.769020</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209322.734882 474047.769020</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 038 431</ms:GML_ID>
        <ms:NAZWA>190 038 431</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190038431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209353.368000 474543.827000</gml:lowerCorner>
        		<gml:upperCorner>209353.368000 474543.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209353.368000 474543.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 037 931</ms:GML_ID>
        <ms:NAZWA>190 037 931</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190037931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>209302.544000 474797.416000</gml:lowerCorner>
        		<gml:upperCorner>209302.544000 474797.416000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>209302.544000 474797.416000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 037 671</ms:GML_ID>
        <ms:NAZWA>190 037 671</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190037671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208563.433000 475898.069000</gml:lowerCorner>
        		<gml:upperCorner>208563.433000 475898.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208563.433000 475898.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 036 039</ms:GML_ID>
        <ms:NAZWA>190 036 039</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190036039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208380.342000 476037.596000</gml:lowerCorner>
        		<gml:upperCorner>208380.342000 476037.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208380.342000 476037.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 035 802</ms:GML_ID>
        <ms:NAZWA>190 035 802</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190035802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207788.136000 476589.826000</gml:lowerCorner>
        		<gml:upperCorner>207788.136000 476589.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207788.136000 476589.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 034 958</ms:GML_ID>
        <ms:NAZWA>190 034 958</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190034958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207507.397000 478634.330000</gml:lowerCorner>
        		<gml:upperCorner>207507.397000 478634.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207507.397000 478634.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 032 618</ms:GML_ID>
        <ms:NAZWA>190 032 618</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190032618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207538.054116 478915.416288</gml:lowerCorner>
        		<gml:upperCorner>207538.054116 478915.416288</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207538.054116 478915.416288</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 032 335</ms:GML_ID>
        <ms:NAZWA>190 032 335</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190032335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207234.336000 479811.282000</gml:lowerCorner>
        		<gml:upperCorner>207234.336000 479811.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207234.336000 479811.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 031 182</ms:GML_ID>
        <ms:NAZWA>190 031 182</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190031182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>207810.544000 480846.608000</gml:lowerCorner>
        		<gml:upperCorner>207810.544000 480846.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>207810.544000 480846.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 029 993</ms:GML_ID>
        <ms:NAZWA>190 029 993</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190029993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208293.565000 481441.292000</gml:lowerCorner>
        		<gml:upperCorner>208293.565000 481441.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208293.565000 481441.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.190 029 200</ms:GML_ID>
        <ms:NAZWA>190 029 200</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>190029200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>208419.160000 481690.813000</gml:lowerCorner>
        		<gml:upperCorner>208419.160000 481690.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>208419.160000 481690.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.191 000 533</ms:GML_ID>
        <ms:NAZWA>191 000 533</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>191000533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272430.248321 474673.954414</gml:lowerCorner>
        		<gml:upperCorner>272430.248321 474673.954414</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272430.248321 474673.954414</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.167 003 133</ms:GML_ID>
        <ms:NAZWA>167 003 133</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>167003133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274160.772690 487989.372249</gml:lowerCorner>
        		<gml:upperCorner>274160.772690 487989.372249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274160.772690 487989.372249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 023 581</ms:GML_ID>
        <ms:NAZWA>132 023 581</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132023581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274810.265493 473141.973873</gml:lowerCorner>
        		<gml:upperCorner>274810.265493 473141.973873</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274810.265493 473141.973873</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 032 980</ms:GML_ID>
        <ms:NAZWA>137 032 980</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137032980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274971.416000 484852.776000</gml:lowerCorner>
        		<gml:upperCorner>274971.416000 484852.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274971.416000 484852.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 026 914</ms:GML_ID>
        <ms:NAZWA>132 026 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132026914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275134.137000 484292.836000</gml:lowerCorner>
        		<gml:upperCorner>275134.137000 484292.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275134.137000 484292.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 027 491</ms:GML_ID>
        <ms:NAZWA>132 027 491</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132027491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275638.386000 473053.406000</gml:lowerCorner>
        		<gml:upperCorner>275638.386000 473053.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275638.386000 473053.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.135 000 815</ms:GML_ID>
        <ms:NAZWA>135 000 815</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>135000815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275853.932000 473033.675000</gml:lowerCorner>
        		<gml:upperCorner>275853.932000 473033.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275853.932000 473033.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.135 001 033</ms:GML_ID>
        <ms:NAZWA>135 001 033</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>135001033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276600.556000 473051.307000</gml:lowerCorner>
        		<gml:upperCorner>276600.556000 473051.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276600.556000 473051.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.135 001 853</ms:GML_ID>
        <ms:NAZWA>135 001 853</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>135001853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276619.624000 479862.933000</gml:lowerCorner>
        		<gml:upperCorner>276619.624000 479862.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276619.624000 479862.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 032 173</ms:GML_ID>
        <ms:NAZWA>132 032 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132032173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276676.520000 469361.914000</gml:lowerCorner>
        		<gml:upperCorner>276676.520000 469361.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276676.520000 469361.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 037 265</ms:GML_ID>
        <ms:NAZWA>137 037 265</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137037265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277128.896000 477358.079000</gml:lowerCorner>
        		<gml:upperCorner>277128.896000 477358.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277128.896000 477358.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 034 731</ms:GML_ID>
        <ms:NAZWA>132 034 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132034731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282951.456000 469519.778000</gml:lowerCorner>
        		<gml:upperCorner>282951.456000 469519.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282951.456000 469519.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 044 747</ms:GML_ID>
        <ms:NAZWA>132 044 747</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132044747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283175.669000 468519.632000</gml:lowerCorner>
        		<gml:upperCorner>283175.669000 468519.632000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283175.669000 468519.632000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 005 925</ms:GML_ID>
        <ms:NAZWA>153 005 925</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153005925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286248.123000 467944.578000</gml:lowerCorner>
        		<gml:upperCorner>286248.123000 467944.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286248.123000 467944.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 001 910</ms:GML_ID>
        <ms:NAZWA>153 001 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153001910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286351.224000 468036.575000</gml:lowerCorner>
        		<gml:upperCorner>286351.224000 468036.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286351.224000 468036.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 001 838</ms:GML_ID>
        <ms:NAZWA>153 001 838</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153001838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288140.447000 489016.429000</gml:lowerCorner>
        		<gml:upperCorner>288140.447000 489016.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288140.447000 489016.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 002 390</ms:GML_ID>
        <ms:NAZWA>144 002 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144002390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288803.225000 487499.301000</gml:lowerCorner>
        		<gml:upperCorner>288803.225000 487499.301000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288803.225000 487499.301000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 004 047</ms:GML_ID>
        <ms:NAZWA>144 004 047</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144004047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289208.612000 486570.808000</gml:lowerCorner>
        		<gml:upperCorner>289208.612000 486570.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289208.612000 486570.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 005 060</ms:GML_ID>
        <ms:NAZWA>144 005 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144005060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289389.619307 486157.586803</gml:lowerCorner>
        		<gml:upperCorner>289389.619307 486157.586803</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289389.619307 486157.586803</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 005 510</ms:GML_ID>
        <ms:NAZWA>144 005 510</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144005510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289736.221024 485651.202872</gml:lowerCorner>
        		<gml:upperCorner>289736.221024 485651.202872</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289736.221024 485651.202872</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 006 130</ms:GML_ID>
        <ms:NAZWA>144 006 130</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144006130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289899.124752 485483.775114</gml:lowerCorner>
        		<gml:upperCorner>289899.124752 485483.775114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289899.124752 485483.775114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 006 361</ms:GML_ID>
        <ms:NAZWA>144 006 361</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144006361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290547.917000 484919.118000</gml:lowerCorner>
        		<gml:upperCorner>290547.917000 484919.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290547.917000 484919.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 007 221</ms:GML_ID>
        <ms:NAZWA>144 007 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144007221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290818.639000 484682.771000</gml:lowerCorner>
        		<gml:upperCorner>290818.639000 484682.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290818.639000 484682.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 007 581</ms:GML_ID>
        <ms:NAZWA>144 007 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144007581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292144.676000 468293.941000</gml:lowerCorner>
        		<gml:upperCorner>292144.676000 468293.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292144.676000 468293.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 015 250</ms:GML_ID>
        <ms:NAZWA>152 015 250</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152015250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293853.500000 469024.982000</gml:lowerCorner>
        		<gml:upperCorner>293853.500000 469024.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293853.500000 469024.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 017 115</ms:GML_ID>
        <ms:NAZWA>152 017 115</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152017115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294052.995918 481294.286409</gml:lowerCorner>
        		<gml:upperCorner>294052.995918 481294.286409</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294052.995918 481294.286409</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 012 302</ms:GML_ID>
        <ms:NAZWA>144 012 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144012302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294372.416000 480833.596000</gml:lowerCorner>
        		<gml:upperCorner>294372.416000 480833.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294372.416000 480833.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 012 861</ms:GML_ID>
        <ms:NAZWA>144 012 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144012861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295080.752000 470291.064000</gml:lowerCorner>
        		<gml:upperCorner>295080.752000 470291.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295080.752000 470291.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 018 926</ms:GML_ID>
        <ms:NAZWA>152 018 926</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152018926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295873.017353 479755.703012</gml:lowerCorner>
        		<gml:upperCorner>295873.017353 479755.703012</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295873.017353 479755.703012</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 014 716</ms:GML_ID>
        <ms:NAZWA>144 014 716</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144014716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296087.124000 479626.749000</gml:lowerCorner>
        		<gml:upperCorner>296087.124000 479626.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296087.124000 479626.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 014 970</ms:GML_ID>
        <ms:NAZWA>144 014 970</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144014970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296594.341000 471971.955000</gml:lowerCorner>
        		<gml:upperCorner>296594.341000 471971.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296594.341000 471971.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 021 197</ms:GML_ID>
        <ms:NAZWA>152 021 197</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152021197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297386.190000 472792.879000</gml:lowerCorner>
        		<gml:upperCorner>297386.190000 472792.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297386.190000 472792.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 022 340</ms:GML_ID>
        <ms:NAZWA>152 022 340</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152022340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298059.188000 474185.680000</gml:lowerCorner>
        		<gml:upperCorner>298059.188000 474185.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298059.188000 474185.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 020 809</ms:GML_ID>
        <ms:NAZWA>144 020 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144020809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298699.819000 472144.536000</gml:lowerCorner>
        		<gml:upperCorner>298699.819000 472144.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298699.819000 472144.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 022 949</ms:GML_ID>
        <ms:NAZWA>144 022 949</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144022949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299596.093000 473510.401000</gml:lowerCorner>
        		<gml:upperCorner>299596.093000 473510.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299596.093000 473510.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 024 701</ms:GML_ID>
        <ms:NAZWA>152 024 701</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152024701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299666.518921 469035.251225</gml:lowerCorner>
        		<gml:upperCorner>299666.518921 469035.251225</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299666.518921 469035.251225</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 026 206</ms:GML_ID>
        <ms:NAZWA>144 026 206</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144026206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300078.773000 467752.055000</gml:lowerCorner>
        		<gml:upperCorner>300078.773000 467752.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300078.773000 467752.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 027 557</ms:GML_ID>
        <ms:NAZWA>144 027 557</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144027557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300122.050000 467613.766000</gml:lowerCorner>
        		<gml:upperCorner>300122.050000 467613.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300122.050000 467613.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 027 701</ms:GML_ID>
        <ms:NAZWA>144 027 701</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144027701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300479.144237 473646.562381</gml:lowerCorner>
        		<gml:upperCorner>300479.144237 473646.562381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300479.144237 473646.562381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 025 580</ms:GML_ID>
        <ms:NAZWA>152 025 580</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152025580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239261.763000 462810.935000</gml:lowerCorner>
        		<gml:upperCorner>239261.763000 462810.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239261.763000 462810.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 006 489</ms:GML_ID>
        <ms:NAZWA>158 006 489</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158006489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240347.917000 463407.661000</gml:lowerCorner>
        		<gml:upperCorner>240347.917000 463407.661000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240347.917000 463407.661000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 005 236</ms:GML_ID>
        <ms:NAZWA>158 005 236</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158005236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241574.670500 463891.172627</gml:lowerCorner>
        		<gml:upperCorner>241574.670500 463891.172627</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241574.670500 463891.172627</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 003 825</ms:GML_ID>
        <ms:NAZWA>158 003 825</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158003825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243422.274000 464116.839000</gml:lowerCorner>
        		<gml:upperCorner>243422.274000 464116.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243422.274000 464116.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 001 725</ms:GML_ID>
        <ms:NAZWA>158 001 725</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158001725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244402.898000 463948.257000</gml:lowerCorner>
        		<gml:upperCorner>244402.898000 463948.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244402.898000 463948.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 044 781</ms:GML_ID>
        <ms:NAZWA>140 044 781</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140044781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244869.898000 462560.972000</gml:lowerCorner>
        		<gml:upperCorner>244869.898000 462560.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244869.898000 462560.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 046 318</ms:GML_ID>
        <ms:NAZWA>140 046 318</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140046318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244900.192000 462994.441000</gml:lowerCorner>
        		<gml:upperCorner>244900.192000 462994.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244900.192000 462994.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 045 883</ms:GML_ID>
        <ms:NAZWA>140 045 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140045883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245868.565000 467211.022000</gml:lowerCorner>
        		<gml:upperCorner>245868.565000 467211.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245868.565000 467211.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 040 912</ms:GML_ID>
        <ms:NAZWA>140 040 912</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140040912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245869.274000 476528.900000</gml:lowerCorner>
        		<gml:upperCorner>245869.274000 476528.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245869.274000 476528.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 026 038</ms:GML_ID>
        <ms:NAZWA>148 026 038</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148026038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246167.560000 475793.350000</gml:lowerCorner>
        		<gml:upperCorner>246167.560000 475793.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246167.560000 475793.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 026 836</ms:GML_ID>
        <ms:NAZWA>148 026 836</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148026836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246862.872861 472748.025526</gml:lowerCorner>
        		<gml:upperCorner>246862.872861 472748.025526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246862.872861 472748.025526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 029 975</ms:GML_ID>
        <ms:NAZWA>148 029 975</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148029975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247662.288011 468576.014794</gml:lowerCorner>
        		<gml:upperCorner>247662.288011 468576.014794</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247662.288011 468576.014794</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 038 526</ms:GML_ID>
        <ms:NAZWA>140 038 526</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140038526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247768.289000 470545.965000</gml:lowerCorner>
        		<gml:upperCorner>247768.289000 470545.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247768.289000 470545.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 032 474</ms:GML_ID>
        <ms:NAZWA>148 032 474</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148032474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247852.092000 470055.332000</gml:lowerCorner>
        		<gml:upperCorner>247852.092000 470055.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247852.092000 470055.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 032 974</ms:GML_ID>
        <ms:NAZWA>148 032 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148032974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247960.209000 469335.171000</gml:lowerCorner>
        		<gml:upperCorner>247960.209000 469335.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247960.209000 469335.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.148 033 708</ms:GML_ID>
        <ms:NAZWA>148 033 708</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>148033708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249281.055000 463059.758000</gml:lowerCorner>
        		<gml:upperCorner>249281.055000 463059.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249281.055000 463059.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.173 006 003</ms:GML_ID>
        <ms:NAZWA>173 006 003</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>173006003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250096.125314 470978.660735</gml:lowerCorner>
        		<gml:upperCorner>250096.125314 470978.660735</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250096.125314 470978.660735</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 035 015</ms:GML_ID>
        <ms:NAZWA>140 035 015</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140035015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253607.340000 473509.314000</gml:lowerCorner>
        		<gml:upperCorner>253607.340000 473509.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253607.340000 473509.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 030 590</ms:GML_ID>
        <ms:NAZWA>140 030 590</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140030590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253882.343000 477184.483000</gml:lowerCorner>
        		<gml:upperCorner>253882.343000 477184.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253882.343000 477184.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 026 509</ms:GML_ID>
        <ms:NAZWA>140 026 509</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140026509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254031.550000 473955.419000</gml:lowerCorner>
        		<gml:upperCorner>254031.550000 473955.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254031.550000 473955.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 029 972</ms:GML_ID>
        <ms:NAZWA>140 029 972</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140029972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254452.903000 475422.962000</gml:lowerCorner>
        		<gml:upperCorner>254452.903000 475422.962000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254452.903000 475422.962000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 028 426</ms:GML_ID>
        <ms:NAZWA>140 028 426</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140028426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255243.126000 473418.370000</gml:lowerCorner>
        		<gml:upperCorner>255243.126000 473418.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255243.126000 473418.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.149 020 205</ms:GML_ID>
        <ms:NAZWA>149 020 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>149020205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292260.998200 455914.241850</gml:lowerCorner>
        		<gml:upperCorner>292260.998200 455914.241850</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292260.998200 455914.241850</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 061 342</ms:GML_ID>
        <ms:NAZWA>132 061 342</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132061342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291295.413000 457236.595000</gml:lowerCorner>
        		<gml:upperCorner>291295.413000 457236.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291295.413000 457236.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 059 703</ms:GML_ID>
        <ms:NAZWA>132 059 703</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132059703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290843.190000 457837.471000</gml:lowerCorner>
        		<gml:upperCorner>290843.190000 457837.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290843.190000 457837.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 058 949</ms:GML_ID>
        <ms:NAZWA>132 058 949</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132058949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289235.046000 459978.800000</gml:lowerCorner>
        		<gml:upperCorner>289235.046000 459978.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289235.046000 459978.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 056 271</ms:GML_ID>
        <ms:NAZWA>132 056 271</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132056271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287828.681000 461957.713000</gml:lowerCorner>
        		<gml:upperCorner>287828.681000 461957.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287828.681000 461957.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 053 836</ms:GML_ID>
        <ms:NAZWA>132 053 836</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132053836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277217.876000 462563.677000</gml:lowerCorner>
        		<gml:upperCorner>277217.876000 462563.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277217.876000 462563.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 044 096</ms:GML_ID>
        <ms:NAZWA>137 044 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137044096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287421.034000 462823.708000</gml:lowerCorner>
        		<gml:upperCorner>287421.034000 462823.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287421.034000 462823.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 052 882</ms:GML_ID>
        <ms:NAZWA>132 052 882</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132052882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286976.510000 463767.293000</gml:lowerCorner>
        		<gml:upperCorner>286976.510000 463767.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286976.510000 463767.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 051 835</ms:GML_ID>
        <ms:NAZWA>132 051 835</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132051835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278602.896000 464214.382000</gml:lowerCorner>
        		<gml:upperCorner>278602.896000 464214.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278602.896000 464214.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 012 214</ms:GML_ID>
        <ms:NAZWA>153 012 214</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153012214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276862.503000 465112.838000</gml:lowerCorner>
        		<gml:upperCorner>276862.503000 465112.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276862.503000 465112.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 041 526</ms:GML_ID>
        <ms:NAZWA>137 041 526</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137041526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286288.346000 465227.330000</gml:lowerCorner>
        		<gml:upperCorner>286288.346000 465227.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286288.346000 465227.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 050 220</ms:GML_ID>
        <ms:NAZWA>132 050 220</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132050220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280745.702000 466208.923000</gml:lowerCorner>
        		<gml:upperCorner>280745.702000 466208.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280745.702000 466208.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 009 283</ms:GML_ID>
        <ms:NAZWA>153 009 283</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153009283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285643.925000 466490.773000</gml:lowerCorner>
        		<gml:upperCorner>285643.925000 466490.773000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285643.925000 466490.773000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 048 798</ms:GML_ID>
        <ms:NAZWA>132 048 798</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132048798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300431.802000 466771.062000</gml:lowerCorner>
        		<gml:upperCorner>300431.802000 466771.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300431.802000 466771.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 028 601</ms:GML_ID>
        <ms:NAZWA>144 028 601</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144028601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300275.929000 467126.694000</gml:lowerCorner>
        		<gml:upperCorner>300275.929000 467126.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300275.929000 467126.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 028 211</ms:GML_ID>
        <ms:NAZWA>144 028 211</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144028211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284840.646000 467398.608000</gml:lowerCorner>
        		<gml:upperCorner>284840.646000 467398.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284840.646000 467398.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 047 585</ms:GML_ID>
        <ms:NAZWA>132 047 585</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>132047585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282070.578000 467414.553000</gml:lowerCorner>
        		<gml:upperCorner>282070.578000 467414.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282070.578000 467414.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.153 007 489</ms:GML_ID>
        <ms:NAZWA>153 007 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>153007489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290084.793000 467528.600000</gml:lowerCorner>
        		<gml:upperCorner>290084.793000 467528.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290084.793000 467528.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 013 050</ms:GML_ID>
        <ms:NAZWA>152 013 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152013050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244712.847389 459208.495297</gml:lowerCorner>
        		<gml:upperCorner>244712.847389 459208.495297</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244712.847389 459208.495297</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 049 738</ms:GML_ID>
        <ms:NAZWA>140 049 738</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140049738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244799.668747 461928.022495</gml:lowerCorner>
        		<gml:upperCorner>244799.668747 461928.022495</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244799.668747 461928.022495</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 046 956</ms:GML_ID>
        <ms:NAZWA>140 046 956</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140046956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248220.270000 457769.932000</gml:lowerCorner>
        		<gml:upperCorner>248220.270000 457769.932000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248220.270000 457769.932000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 053 736</ms:GML_ID>
        <ms:NAZWA>140 053 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140053736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249837.238000 457786.029000</gml:lowerCorner>
        		<gml:upperCorner>249837.238000 457786.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249837.238000 457786.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 055 359</ms:GML_ID>
        <ms:NAZWA>140 055 359</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140055359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249937.423000 461702.939000</gml:lowerCorner>
        		<gml:upperCorner>249937.423000 461702.939000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249937.423000 461702.939000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.173 007 512</ms:GML_ID>
        <ms:NAZWA>173 007 512</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>173007512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250597.601000 457869.487000</gml:lowerCorner>
        		<gml:upperCorner>250597.601000 457869.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250597.601000 457869.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 056 125</ms:GML_ID>
        <ms:NAZWA>140 056 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140056125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251177.413000 457819.859000</gml:lowerCorner>
        		<gml:upperCorner>251177.413000 457819.859000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251177.413000 457819.859000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 056 709</ms:GML_ID>
        <ms:NAZWA>140 056 709</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140056709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251850.881000 457892.220000</gml:lowerCorner>
        		<gml:upperCorner>251850.881000 457892.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251850.881000 457892.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.173 011 836</ms:GML_ID>
        <ms:NAZWA>173 011 836</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>173011836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251887.001000 457672.029000</gml:lowerCorner>
        		<gml:upperCorner>251887.001000 457672.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251887.001000 457672.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 057 435</ms:GML_ID>
        <ms:NAZWA>140 057 435</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140057435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252934.891000 456454.113000</gml:lowerCorner>
        		<gml:upperCorner>252934.891000 456454.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252934.891000 456454.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 059 071</ms:GML_ID>
        <ms:NAZWA>140 059 071</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140059071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253061.379000 455902.019000</gml:lowerCorner>
        		<gml:upperCorner>253061.379000 455902.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253061.379000 455902.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 059 639</ms:GML_ID>
        <ms:NAZWA>140 059 639</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140059639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253266.443000 455010.799000</gml:lowerCorner>
        		<gml:upperCorner>253266.443000 455010.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253266.443000 455010.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 060 553</ms:GML_ID>
        <ms:NAZWA>140 060 553</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140060553</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253965.463000 453559.145000</gml:lowerCorner>
        		<gml:upperCorner>253965.463000 453559.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253965.463000 453559.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 062 169</ms:GML_ID>
        <ms:NAZWA>140 062 169</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140062169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234118.167000 454961.376000</gml:lowerCorner>
        		<gml:upperCorner>234118.167000 454961.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234118.167000 454961.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 017 711</ms:GML_ID>
        <ms:NAZWA>158 017 711</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158017711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234145.481000 455564.599000</gml:lowerCorner>
        		<gml:upperCorner>234145.481000 455564.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234145.481000 455564.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 017 083</ms:GML_ID>
        <ms:NAZWA>158 017 083</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158017083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234227.180000 458181.983000</gml:lowerCorner>
        		<gml:upperCorner>234227.180000 458181.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234227.180000 458181.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 014 059</ms:GML_ID>
        <ms:NAZWA>158 014 059</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158014059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234301.368000 458894.009000</gml:lowerCorner>
        		<gml:upperCorner>234301.368000 458894.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234301.368000 458894.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 013 307</ms:GML_ID>
        <ms:NAZWA>158 013 307</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158013307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235261.739000 459602.194000</gml:lowerCorner>
        		<gml:upperCorner>235261.739000 459602.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235261.739000 459602.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 012 092</ms:GML_ID>
        <ms:NAZWA>158 012 092</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158012092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235650.601000 460074.949000</gml:lowerCorner>
        		<gml:upperCorner>235650.601000 460074.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235650.601000 460074.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 011 448</ms:GML_ID>
        <ms:NAZWA>158 011 448</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158011448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236234.330000 460986.205000</gml:lowerCorner>
        		<gml:upperCorner>236234.330000 460986.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236234.330000 460986.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 010 302</ms:GML_ID>
        <ms:NAZWA>158 010 302</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158010302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236741.896000 461314.089000</gml:lowerCorner>
        		<gml:upperCorner>236741.896000 461314.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236741.896000 461314.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 009 691</ms:GML_ID>
        <ms:NAZWA>158 009 691</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158009691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236938.012000 461614.598000</gml:lowerCorner>
        		<gml:upperCorner>236938.012000 461614.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236938.012000 461614.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 009 328</ms:GML_ID>
        <ms:NAZWA>158 009 328</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158009328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238675.075000 453064.994000</gml:lowerCorner>
        		<gml:upperCorner>238675.075000 453064.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238675.075000 453064.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 002 960</ms:GML_ID>
        <ms:NAZWA>192 002 960</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192002960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238683.152000 452772.022000</gml:lowerCorner>
        		<gml:upperCorner>238683.152000 452772.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238683.152000 452772.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 002 668</ms:GML_ID>
        <ms:NAZWA>192 002 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192002668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238784.401000 453492.262000</gml:lowerCorner>
        		<gml:upperCorner>238784.401000 453492.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238784.401000 453492.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 003 401</ms:GML_ID>
        <ms:NAZWA>192 003 401</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192003401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239084.269000 454236.182000</gml:lowerCorner>
        		<gml:upperCorner>239084.269000 454236.182000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239084.269000 454236.182000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 004 204</ms:GML_ID>
        <ms:NAZWA>192 004 204</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192004204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239564.673000 454785.647000</gml:lowerCorner>
        		<gml:upperCorner>239564.673000 454785.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239564.673000 454785.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 004 956</ms:GML_ID>
        <ms:NAZWA>192 004 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192004956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240795.271000 454913.383000</gml:lowerCorner>
        		<gml:upperCorner>240795.271000 454913.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240795.271000 454913.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 006 232</ms:GML_ID>
        <ms:NAZWA>192 006 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192006232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241466.887000 455558.309000</gml:lowerCorner>
        		<gml:upperCorner>241466.887000 455558.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241466.887000 455558.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 007 258</ms:GML_ID>
        <ms:NAZWA>192 007 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192007258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241690.597000 455680.775000</gml:lowerCorner>
        		<gml:upperCorner>241690.597000 455680.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241690.597000 455680.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 007 525</ms:GML_ID>
        <ms:NAZWA>192 007 525</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192007525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244654.882000 460604.156000</gml:lowerCorner>
        		<gml:upperCorner>244654.882000 460604.156000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244654.882000 460604.156000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 048 296</ms:GML_ID>
        <ms:NAZWA>140 048 296</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140048296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244655.579000 460925.503000</gml:lowerCorner>
        		<gml:upperCorner>244655.579000 460925.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244655.579000 460925.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 047 970</ms:GML_ID>
        <ms:NAZWA>140 047 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140047970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232715.561000 452501.078000</gml:lowerCorner>
        		<gml:upperCorner>232715.561000 452501.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232715.561000 452501.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 020 550</ms:GML_ID>
        <ms:NAZWA>158 020 550</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158020550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234027.537000 452722.349000</gml:lowerCorner>
        		<gml:upperCorner>234027.537000 452722.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234027.537000 452722.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 018 008</ms:GML_ID>
        <ms:NAZWA>176 018 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176018008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233335.657000 453055.361000</gml:lowerCorner>
        		<gml:upperCorner>233335.657000 453055.361000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233335.657000 453055.361000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 018 784</ms:GML_ID>
        <ms:NAZWA>176 018 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176018784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233520.013000 454006.284000</gml:lowerCorner>
        		<gml:upperCorner>233520.013000 454006.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233520.013000 454006.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 018 842</ms:GML_ID>
        <ms:NAZWA>158 018 842</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158018842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234038.854000 455694.208000</gml:lowerCorner>
        		<gml:upperCorner>234038.854000 455694.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234038.854000 455694.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 016 916</ms:GML_ID>
        <ms:NAZWA>158 016 916</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158016916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233879.772000 457233.835000</gml:lowerCorner>
        		<gml:upperCorner>233879.772000 457233.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233879.772000 457233.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 015 115</ms:GML_ID>
        <ms:NAZWA>158 015 115</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158015115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>224014.773000 469453.894000</gml:lowerCorner>
        		<gml:upperCorner>224014.773000 469453.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>224014.773000 469453.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 080 281</ms:GML_ID>
        <ms:NAZWA>093 080 281</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093080281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223835.353000 469782.467000</gml:lowerCorner>
        		<gml:upperCorner>223835.353000 469782.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223835.353000 469782.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 079 908</ms:GML_ID>
        <ms:NAZWA>093 079 908</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093079908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215482.283387 471068.022319</gml:lowerCorner>
        		<gml:upperCorner>215482.283387 471068.022319</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215482.283387 471068.022319</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 022 097</ms:GML_ID>
        <ms:NAZWA>090 022 097</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090022097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>215213.450240 471118.055457</gml:lowerCorner>
        		<gml:upperCorner>215213.450240 471118.055457</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>215213.450240 471118.055457</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 022 371</ms:GML_ID>
        <ms:NAZWA>090 022 371</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090022371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>213227.727511 471489.150238</gml:lowerCorner>
        		<gml:upperCorner>213227.727511 471489.150238</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>213227.727511 471489.150238</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 024 393</ms:GML_ID>
        <ms:NAZWA>090 024 393</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090024393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>212760.309000 471570.609000</gml:lowerCorner>
        		<gml:upperCorner>212760.309000 471570.609000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>212760.309000 471570.609000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 024 867</ms:GML_ID>
        <ms:NAZWA>090 024 867</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090024867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>218432.672948 472082.519152</gml:lowerCorner>
        		<gml:upperCorner>218432.672948 472082.519152</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>218432.672948 472082.519152</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 018 591</ms:GML_ID>
        <ms:NAZWA>090 018 591</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090018591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>219080.303000 472547.037000</gml:lowerCorner>
        		<gml:upperCorner>219080.303000 472547.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>219080.303000 472547.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 017 715</ms:GML_ID>
        <ms:NAZWA>090 017 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090017715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222581.475484 473038.454480</gml:lowerCorner>
        		<gml:upperCorner>222581.475484 473038.454480</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222581.475484 473038.454480</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 076 372</ms:GML_ID>
        <ms:NAZWA>093 076 372</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093076372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>220409.400000 473061.080000</gml:lowerCorner>
        		<gml:upperCorner>220409.400000 473061.080000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>220409.400000 473061.080000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.090 016 144</ms:GML_ID>
        <ms:NAZWA>090 016 144</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>090016144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>222571.037000 473916.841000</gml:lowerCorner>
        		<gml:upperCorner>222571.037000 473916.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>222571.037000 473916.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 075 445</ms:GML_ID>
        <ms:NAZWA>093 075 445</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093075445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223781.031000 478974.574000</gml:lowerCorner>
        		<gml:upperCorner>223781.031000 478974.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223781.031000 478974.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 068 391</ms:GML_ID>
        <ms:NAZWA>093 068 391</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093068391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223853.296000 479386.009000</gml:lowerCorner>
        		<gml:upperCorner>223853.296000 479386.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223853.296000 479386.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 067 972</ms:GML_ID>
        <ms:NAZWA>093 067 972</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093067972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>223966.346000 480028.215000</gml:lowerCorner>
        		<gml:upperCorner>223966.346000 480028.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>223966.346000 480028.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.093 067 320</ms:GML_ID>
        <ms:NAZWA>093 067 320</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>093067320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231517.792000 480044.548000</gml:lowerCorner>
        		<gml:upperCorner>231517.792000 480044.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231517.792000 480044.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.159 025 631</ms:GML_ID>
        <ms:NAZWA>159 025 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>159025631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231094.193000 480473.083000</gml:lowerCorner>
        		<gml:upperCorner>231094.193000 480473.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231094.193000 480473.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 001 210</ms:GML_ID>
        <ms:NAZWA>157 001 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157001210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230119.548000 481115.559000</gml:lowerCorner>
        		<gml:upperCorner>230119.548000 481115.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230119.548000 481115.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 002 405</ms:GML_ID>
        <ms:NAZWA>157 002 405</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157002405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229035.010000 481466.267000</gml:lowerCorner>
        		<gml:upperCorner>229035.010000 481466.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229035.010000 481466.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 003 550</ms:GML_ID>
        <ms:NAZWA>157 003 550</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157003550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228164.078000 481888.834000</gml:lowerCorner>
        		<gml:upperCorner>228164.078000 481888.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228164.078000 481888.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 004 532</ms:GML_ID>
        <ms:NAZWA>157 004 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157004532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227484.849000 482119.867000</gml:lowerCorner>
        		<gml:upperCorner>227484.849000 482119.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227484.849000 482119.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 005 255</ms:GML_ID>
        <ms:NAZWA>157 005 255</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157005255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>227236.799000 482252.858000</gml:lowerCorner>
        		<gml:upperCorner>227236.799000 482252.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>227236.799000 482252.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 005 535</ms:GML_ID>
        <ms:NAZWA>157 005 535</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157005535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>225117.269000 483429.091000</gml:lowerCorner>
        		<gml:upperCorner>225117.269000 483429.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>225117.269000 483429.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.157 007 975</ms:GML_ID>
        <ms:NAZWA>157 007 975</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>157007975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>228243.177241 450997.899120</gml:lowerCorner>
        		<gml:upperCorner>228243.177241 450997.899120</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>228243.177241 450997.899120</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 053 346</ms:GML_ID>
        <ms:NAZWA>151 053 346</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151053346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>229276.672016 450395.947493</gml:lowerCorner>
        		<gml:upperCorner>229276.672016 450395.947493</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>229276.672016 450395.947493</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 052 171</ms:GML_ID>
        <ms:NAZWA>151 052 171</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151052171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230046.682487 450113.688365</gml:lowerCorner>
        		<gml:upperCorner>230046.682487 450113.688365</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230046.682487 450113.688365</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 051 338</ms:GML_ID>
        <ms:NAZWA>151 051 338</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151051338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230182.440000 450084.195000</gml:lowerCorner>
        		<gml:upperCorner>230182.440000 450084.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230182.440000 450084.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 051 199</ms:GML_ID>
        <ms:NAZWA>151 051 199</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151051199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230491.062573 450015.574420</gml:lowerCorner>
        		<gml:upperCorner>230491.062573 450015.574420</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230491.062573 450015.574420</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 050 882</ms:GML_ID>
        <ms:NAZWA>151 050 882</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151050882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>230907.593000 449923.738000</gml:lowerCorner>
        		<gml:upperCorner>230907.593000 449923.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>230907.593000 449923.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 050 453</ms:GML_ID>
        <ms:NAZWA>151 050 453</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151050453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231522.072428 450685.336046</gml:lowerCorner>
        		<gml:upperCorner>231522.072428 450685.336046</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231522.072428 450685.336046</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 022 747</ms:GML_ID>
        <ms:NAZWA>158 022 747</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158022747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>231929.768000 451091.229000</gml:lowerCorner>
        		<gml:upperCorner>231929.768000 451091.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>231929.768000 451091.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 022 165</ms:GML_ID>
        <ms:NAZWA>158 022 165</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158022165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232121.543000 449655.220000</gml:lowerCorner>
        		<gml:upperCorner>232121.543000 449655.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232121.543000 449655.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 049 211</ms:GML_ID>
        <ms:NAZWA>151 049 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151049211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232270.624000 451703.544000</gml:lowerCorner>
        		<gml:upperCorner>232270.624000 451703.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232270.624000 451703.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.158 021 464</ms:GML_ID>
        <ms:NAZWA>158 021 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>158021464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>232636.652000 449541.383000</gml:lowerCorner>
        		<gml:upperCorner>232636.652000 449541.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>232636.652000 449541.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 048 682</ms:GML_ID>
        <ms:NAZWA>151 048 682</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151048682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>233336.650000 449386.789000</gml:lowerCorner>
        		<gml:upperCorner>233336.650000 449386.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>233336.650000 449386.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 047 973</ms:GML_ID>
        <ms:NAZWA>151 047 973</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151047973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234215.370000 449172.006000</gml:lowerCorner>
        		<gml:upperCorner>234215.370000 449172.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234215.370000 449172.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 047 058</ms:GML_ID>
        <ms:NAZWA>151 047 058</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151047058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>234586.680000 452392.973000</gml:lowerCorner>
        		<gml:upperCorner>234586.680000 452392.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>234586.680000 452392.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 017 359</ms:GML_ID>
        <ms:NAZWA>176 017 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176017359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235064.096000 452111.468000</gml:lowerCorner>
        		<gml:upperCorner>235064.096000 452111.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235064.096000 452111.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 016 804</ms:GML_ID>
        <ms:NAZWA>176 016 804</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176016804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235898.831000 451743.028000</gml:lowerCorner>
        		<gml:upperCorner>235898.831000 451743.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235898.831000 451743.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 015 886</ms:GML_ID>
        <ms:NAZWA>176 015 886</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176015886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236580.439311 451681.118189</gml:lowerCorner>
        		<gml:upperCorner>236580.439311 451681.118189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236580.439311 451681.118189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 015 205</ms:GML_ID>
        <ms:NAZWA>176 015 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176015205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236820.649000 451643.671000</gml:lowerCorner>
        		<gml:upperCorner>236820.649000 451643.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236820.649000 451643.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 014 957</ms:GML_ID>
        <ms:NAZWA>176 014 957</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176014957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237080.404000 451756.347000</gml:lowerCorner>
        		<gml:upperCorner>237080.404000 451756.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237080.404000 451756.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.192 000 491</ms:GML_ID>
        <ms:NAZWA>192 000 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>192000491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237632.613000 451010.799000</gml:lowerCorner>
        		<gml:upperCorner>237632.613000 451010.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237632.613000 451010.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 013 922</ms:GML_ID>
        <ms:NAZWA>176 013 922</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176013922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238830.226000 450471.362000</gml:lowerCorner>
        		<gml:upperCorner>238830.226000 450471.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238830.226000 450471.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 012 523</ms:GML_ID>
        <ms:NAZWA>176 012 523</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176012523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239262.833000 450546.933000</gml:lowerCorner>
        		<gml:upperCorner>239262.833000 450546.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239262.833000 450546.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 012 082</ms:GML_ID>
        <ms:NAZWA>176 012 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176012082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240358.457000 449524.801000</gml:lowerCorner>
        		<gml:upperCorner>240358.457000 449524.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240358.457000 449524.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 010 520</ms:GML_ID>
        <ms:NAZWA>176 010 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176010520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241497.391000 448993.044000</gml:lowerCorner>
        		<gml:upperCorner>241497.391000 448993.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241497.391000 448993.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 009 263</ms:GML_ID>
        <ms:NAZWA>176 009 263</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176009263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241821.229000 448843.575000</gml:lowerCorner>
        		<gml:upperCorner>241821.229000 448843.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241821.229000 448843.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 008 906</ms:GML_ID>
        <ms:NAZWA>176 008 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176008906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242694.993000 448623.072000</gml:lowerCorner>
        		<gml:upperCorner>242694.993000 448623.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242694.993000 448623.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 008 001</ms:GML_ID>
        <ms:NAZWA>176 008 001</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176008001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244851.700000 437476.297000</gml:lowerCorner>
        		<gml:upperCorner>244851.700000 437476.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244851.700000 437476.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 008 944</ms:GML_ID>
        <ms:NAZWA>177 008 944</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177008944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244191.147977 438272.983872</gml:lowerCorner>
        		<gml:upperCorner>244191.147977 438272.983872</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244191.147977 438272.983872</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 007 893</ms:GML_ID>
        <ms:NAZWA>177 007 893</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177007893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243864.913000 439195.648000</gml:lowerCorner>
        		<gml:upperCorner>243864.913000 439195.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243864.913000 439195.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 006 871</ms:GML_ID>
        <ms:NAZWA>177 006 871</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177006871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243859.140000 439457.317000</gml:lowerCorner>
        		<gml:upperCorner>243859.140000 439457.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243859.140000 439457.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 006 606</ms:GML_ID>
        <ms:NAZWA>177 006 606</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177006606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244689.042047 441708.103307</gml:lowerCorner>
        		<gml:upperCorner>244689.042047 441708.103307</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244689.042047 441708.103307</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 004 104</ms:GML_ID>
        <ms:NAZWA>177 004 104</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177004104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244790.259000 441936.523000</gml:lowerCorner>
        		<gml:upperCorner>244790.259000 441936.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244790.259000 441936.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 003 853</ms:GML_ID>
        <ms:NAZWA>177 003 853</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177003853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244446.185000 443548.448000</gml:lowerCorner>
        		<gml:upperCorner>244446.185000 443548.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244446.185000 443548.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 035 295</ms:GML_ID>
        <ms:NAZWA>151 035 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151035295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243293.905000 443741.567000</gml:lowerCorner>
        		<gml:upperCorner>243293.905000 443741.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243293.905000 443741.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 036 471</ms:GML_ID>
        <ms:NAZWA>151 036 471</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151036471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241410.528000 444828.098000</gml:lowerCorner>
        		<gml:upperCorner>241410.528000 444828.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241410.528000 444828.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 038 645</ms:GML_ID>
        <ms:NAZWA>151 038 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151038645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241076.317922 445031.375007</gml:lowerCorner>
        		<gml:upperCorner>241076.317922 445031.375007</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241076.317922 445031.375007</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 039 038</ms:GML_ID>
        <ms:NAZWA>151 039 038</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151039038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239201.597000 446172.437000</gml:lowerCorner>
        		<gml:upperCorner>239201.597000 446172.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239201.597000 446172.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 041 236</ms:GML_ID>
        <ms:NAZWA>151 041 236</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151041236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238405.345000 446657.282000</gml:lowerCorner>
        		<gml:upperCorner>238405.345000 446657.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238405.345000 446657.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 042 169</ms:GML_ID>
        <ms:NAZWA>151 042 169</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151042169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244889.115000 447203.038000</gml:lowerCorner>
        		<gml:upperCorner>244889.115000 447203.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244889.115000 447203.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 005 347</ms:GML_ID>
        <ms:NAZWA>176 005 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176005347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236803.860000 447632.928000</gml:lowerCorner>
        		<gml:upperCorner>236803.860000 447632.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236803.860000 447632.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 044 044</ms:GML_ID>
        <ms:NAZWA>151 044 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151044044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243854.369000 447678.660000</gml:lowerCorner>
        		<gml:upperCorner>243854.369000 447678.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243854.369000 447678.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 006 491</ms:GML_ID>
        <ms:NAZWA>176 006 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176006491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243674.391000 447833.900000</gml:lowerCorner>
        		<gml:upperCorner>243674.391000 447833.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243674.391000 447833.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 006 732</ms:GML_ID>
        <ms:NAZWA>176 006 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176006732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243504.000000 448036.508000</gml:lowerCorner>
        		<gml:upperCorner>243504.000000 448036.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243504.000000 448036.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 006 996</ms:GML_ID>
        <ms:NAZWA>176 006 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176006996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>235958.219363 448161.105791</gml:lowerCorner>
        		<gml:upperCorner>235958.219363 448161.105791</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>235958.219363 448161.105791</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 045 058</ms:GML_ID>
        <ms:NAZWA>151 045 058</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151045058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245518.852000 435593.115000</gml:lowerCorner>
        		<gml:upperCorner>245518.852000 435593.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245518.852000 435593.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 010 964</ms:GML_ID>
        <ms:NAZWA>177 010 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177010964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245202.365000 436200.163000</gml:lowerCorner>
        		<gml:upperCorner>245202.365000 436200.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245202.365000 436200.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 010 269</ms:GML_ID>
        <ms:NAZWA>177 010 269</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177010269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245137.288000 436437.912000</gml:lowerCorner>
        		<gml:upperCorner>245137.288000 436437.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245137.288000 436437.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 010 022</ms:GML_ID>
        <ms:NAZWA>177 010 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177010022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262213.498000 438211.413000</gml:lowerCorner>
        		<gml:upperCorner>262213.498000 438211.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262213.498000 438211.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 016 855</ms:GML_ID>
        <ms:NAZWA>195 016 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195016855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245040.628000 442503.021000</gml:lowerCorner>
        		<gml:upperCorner>245040.628000 442503.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245040.628000 442503.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 003 232</ms:GML_ID>
        <ms:NAZWA>177 003 232</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177003232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245899.758889 443937.506710</gml:lowerCorner>
        		<gml:upperCorner>245899.758889 443937.506710</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245899.758889 443937.506710</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 033 760</ms:GML_ID>
        <ms:NAZWA>151 033 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151033760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245892.629174 443948.813177</gml:lowerCorner>
        		<gml:upperCorner>245892.629174 443948.813177</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245892.629174 443948.813177</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 033 785</ms:GML_ID>
        <ms:NAZWA>151 033 785</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151033785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245997.419462 444024.645839</gml:lowerCorner>
        		<gml:upperCorner>245997.419462 444024.645839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245997.419462 444024.645839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 033 651</ms:GML_ID>
        <ms:NAZWA>151 033 651</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151033651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246735.126000 446902.016000</gml:lowerCorner>
        		<gml:upperCorner>246735.126000 446902.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246735.126000 446902.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 003 372</ms:GML_ID>
        <ms:NAZWA>176 003 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176003372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245383.744000 446909.047000</gml:lowerCorner>
        		<gml:upperCorner>245383.744000 446909.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245383.744000 446909.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 004 766</ms:GML_ID>
        <ms:NAZWA>176 004 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176004766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246913.038000 446972.279000</gml:lowerCorner>
        		<gml:upperCorner>246913.038000 446972.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246913.038000 446972.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 003 180</ms:GML_ID>
        <ms:NAZWA>176 003 180</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176003180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246956.842000 447001.098000</gml:lowerCorner>
        		<gml:upperCorner>246956.842000 447001.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246956.842000 447001.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 003 129</ms:GML_ID>
        <ms:NAZWA>176 003 129</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176003129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245201.063000 447040.069000</gml:lowerCorner>
        		<gml:upperCorner>245201.063000 447040.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245201.063000 447040.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 004 992</ms:GML_ID>
        <ms:NAZWA>176 004 992</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176004992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249224.474000 447240.587000</gml:lowerCorner>
        		<gml:upperCorner>249224.474000 447240.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249224.474000 447240.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 028 959</ms:GML_ID>
        <ms:NAZWA>151 028 959</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151028959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249249.867000 447556.162000</gml:lowerCorner>
        		<gml:upperCorner>249249.867000 447556.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249249.867000 447556.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 000 674</ms:GML_ID>
        <ms:NAZWA>176 000 674</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176000674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248569.649000 447561.320000</gml:lowerCorner>
        		<gml:upperCorner>248569.649000 447561.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248569.649000 447561.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.176 001 358</ms:GML_ID>
        <ms:NAZWA>176 001 358</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>176001358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249804.768152 447827.126881</gml:lowerCorner>
        		<gml:upperCorner>249804.768152 447827.126881</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249804.768152 447827.126881</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 028 127</ms:GML_ID>
        <ms:NAZWA>151 028 127</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151028127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252803.475000 449196.392000</gml:lowerCorner>
        		<gml:upperCorner>252803.475000 449196.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252803.475000 449196.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 024 818</ms:GML_ID>
        <ms:NAZWA>151 024 818</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151024818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256792.260000 449620.830000</gml:lowerCorner>
        		<gml:upperCorner>256792.260000 449620.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256792.260000 449620.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 020 802</ms:GML_ID>
        <ms:NAZWA>151 020 802</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151020802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255822.907000 449682.218000</gml:lowerCorner>
        		<gml:upperCorner>255822.907000 449682.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255822.907000 449682.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.691 000 995</ms:GML_ID>
        <ms:NAZWA>691 000 995</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>691000995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259050.630000 449877.942000</gml:lowerCorner>
        		<gml:upperCorner>259050.630000 449877.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259050.630000 449877.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 018 525</ms:GML_ID>
        <ms:NAZWA>151 018 525</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151018525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259862.639822 450001.095771</gml:lowerCorner>
        		<gml:upperCorner>259862.639822 450001.095771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259862.639822 450001.095771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 017 704</ms:GML_ID>
        <ms:NAZWA>151 017 704</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151017704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255250.842000 450005.009000</gml:lowerCorner>
        		<gml:upperCorner>255250.842000 450005.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255250.842000 450005.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 066 227</ms:GML_ID>
        <ms:NAZWA>140 066 227</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140066227</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262183.438000 450368.795000</gml:lowerCorner>
        		<gml:upperCorner>262183.438000 450368.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262183.438000 450368.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 015 351</ms:GML_ID>
        <ms:NAZWA>151 015 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151015351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255489.967000 450794.826000</gml:lowerCorner>
        		<gml:upperCorner>255489.967000 450794.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255489.967000 450794.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 065 401</ms:GML_ID>
        <ms:NAZWA>140 065 401</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140065401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255334.185000 451606.304000</gml:lowerCorner>
        		<gml:upperCorner>255334.185000 451606.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255334.185000 451606.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 064 578</ms:GML_ID>
        <ms:NAZWA>140 064 578</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140064578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254855.160000 452278.024000</gml:lowerCorner>
        		<gml:upperCorner>254855.160000 452278.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254855.160000 452278.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.140 063 734</ms:GML_ID>
        <ms:NAZWA>140 063 734</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>140063734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300950.692000 434733.199000</gml:lowerCorner>
        		<gml:upperCorner>300950.692000 434733.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300950.692000 434733.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 084 537</ms:GML_ID>
        <ms:NAZWA>132 084 537</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132084537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300665.458000 435073.868000</gml:lowerCorner>
        		<gml:upperCorner>300665.458000 435073.868000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300665.458000 435073.868000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 084 081</ms:GML_ID>
        <ms:NAZWA>132 084 081</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132084081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299931.533965 435948.524797</gml:lowerCorner>
        		<gml:upperCorner>299931.533965 435948.524797</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299931.533965 435948.524797</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 082 942</ms:GML_ID>
        <ms:NAZWA>132 082 942</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132082942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286618.716000 435959.269000</gml:lowerCorner>
        		<gml:upperCorner>286618.716000 435959.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286618.716000 435959.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 013 406</ms:GML_ID>
        <ms:NAZWA>136 013 406</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136013406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286007.985000 436487.340000</gml:lowerCorner>
        		<gml:upperCorner>286007.985000 436487.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286007.985000 436487.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 012 597</ms:GML_ID>
        <ms:NAZWA>136 012 597</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136012597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285382.385000 437028.056000</gml:lowerCorner>
        		<gml:upperCorner>285382.385000 437028.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285382.385000 437028.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 011 772</ms:GML_ID>
        <ms:NAZWA>136 011 772</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136011772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299022.853764 437040.923820</gml:lowerCorner>
        		<gml:upperCorner>299022.853764 437040.923820</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299022.853764 437040.923820</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 081 521</ms:GML_ID>
        <ms:NAZWA>132 081 521</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132081521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284665.379000 437646.981000</gml:lowerCorner>
        		<gml:upperCorner>284665.379000 437646.981000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284665.379000 437646.981000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 010 822</ms:GML_ID>
        <ms:NAZWA>136 010 822</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136010822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284461.790892 437812.337246</gml:lowerCorner>
        		<gml:upperCorner>284461.790892 437812.337246</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284461.790892 437812.337246</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 010 560</ms:GML_ID>
        <ms:NAZWA>136 010 560</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136010560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298502.636649 438234.423893</gml:lowerCorner>
        		<gml:upperCorner>298502.636649 438234.423893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298502.636649 438234.423893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 080 215</ms:GML_ID>
        <ms:NAZWA>132 080 215</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132080215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298158.137000 439141.035000</gml:lowerCorner>
        		<gml:upperCorner>298158.137000 439141.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298158.137000 439141.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 079 242</ms:GML_ID>
        <ms:NAZWA>132 079 242</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132079242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281754.732000 439532.196000</gml:lowerCorner>
        		<gml:upperCorner>281754.732000 439532.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281754.732000 439532.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 007 350</ms:GML_ID>
        <ms:NAZWA>136 007 350</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136007350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280962.133000 440036.698000</gml:lowerCorner>
        		<gml:upperCorner>280962.133000 440036.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280962.133000 440036.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 006 412</ms:GML_ID>
        <ms:NAZWA>136 006 412</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136006412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280387.303910 440402.050670</gml:lowerCorner>
        		<gml:upperCorner>280387.303910 440402.050670</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280387.303910 440402.050670</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 005 728</ms:GML_ID>
        <ms:NAZWA>136 005 728</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136005728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278893.940000 441351.730000</gml:lowerCorner>
        		<gml:upperCorner>278893.940000 441351.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278893.940000 441351.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 003 956</ms:GML_ID>
        <ms:NAZWA>136 003 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136003956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277498.826276 442239.439650</gml:lowerCorner>
        		<gml:upperCorner>277498.826276 442239.439650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277498.826276 442239.439650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 002 301</ms:GML_ID>
        <ms:NAZWA>136 002 301</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>136002301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296043.665512 444871.887085</gml:lowerCorner>
        		<gml:upperCorner>296043.665512 444871.887085</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296043.665512 444871.887085</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 073 128</ms:GML_ID>
        <ms:NAZWA>132 073 128</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132073128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295782.857382 445577.603650</gml:lowerCorner>
        		<gml:upperCorner>295782.857382 445577.603650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295782.857382 445577.603650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 072 376</ms:GML_ID>
        <ms:NAZWA>132 072 376</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132072376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295650.587000 446110.023000</gml:lowerCorner>
        		<gml:upperCorner>295650.587000 446110.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295650.587000 446110.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 071 821</ms:GML_ID>
        <ms:NAZWA>132 071 821</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132071821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295591.383000 446524.479000</gml:lowerCorner>
        		<gml:upperCorner>295591.383000 446524.479000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295591.383000 446524.479000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 071 406</ms:GML_ID>
        <ms:NAZWA>132 071 406</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132071406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298811.440000 448628.131000</gml:lowerCorner>
        		<gml:upperCorner>298811.440000 448628.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298811.440000 448628.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 035 264</ms:GML_ID>
        <ms:NAZWA>175 035 264</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175035264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299024.431666 448637.360898</gml:lowerCorner>
        		<gml:upperCorner>299024.431666 448637.360898</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299024.431666 448637.360898</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 035 480</ms:GML_ID>
        <ms:NAZWA>175 035 480</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175035480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299859.955745 448797.762251</gml:lowerCorner>
        		<gml:upperCorner>299859.955745 448797.762251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299859.955745 448797.762251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 036 336</ms:GML_ID>
        <ms:NAZWA>175 036 336</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175036336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295209.599000 449203.740000</gml:lowerCorner>
        		<gml:upperCorner>295209.599000 449203.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295209.599000 449203.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 068 697</ms:GML_ID>
        <ms:NAZWA>132 068 697</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132068697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301969.595000 449368.888000</gml:lowerCorner>
        		<gml:upperCorner>301969.595000 449368.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301969.595000 449368.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 038 522</ms:GML_ID>
        <ms:NAZWA>175 038 522</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175038522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295633.415000 449494.310000</gml:lowerCorner>
        		<gml:upperCorner>295633.415000 449494.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295633.415000 449494.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 031 828</ms:GML_ID>
        <ms:NAZWA>175 031 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175031828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293517.781000 453233.977000</gml:lowerCorner>
        		<gml:upperCorner>293517.781000 453233.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293517.781000 453233.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 064 302</ms:GML_ID>
        <ms:NAZWA>132 064 302</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132064302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277108.857130 454223.499171</gml:lowerCorner>
        		<gml:upperCorner>277108.857130 454223.499171</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277108.857130 454223.499171</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 052 597</ms:GML_ID>
        <ms:NAZWA>137 052 597</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137052597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276190.627000 427012.325000</gml:lowerCorner>
        		<gml:upperCorner>276190.627000 427012.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276190.627000 427012.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 081 432</ms:GML_ID>
        <ms:NAZWA>137 081 432</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137081432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276079.120000 428276.989000</gml:lowerCorner>
        		<gml:upperCorner>276079.120000 428276.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276079.120000 428276.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 080 159</ms:GML_ID>
        <ms:NAZWA>137 080 159</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137080159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276044.513863 428658.690375</gml:lowerCorner>
        		<gml:upperCorner>276044.513863 428658.690375</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276044.513863 428658.690375</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 079 777</ms:GML_ID>
        <ms:NAZWA>137 079 777</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137079777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275910.000000 430193.362000</gml:lowerCorner>
        		<gml:upperCorner>275910.000000 430193.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275910.000000 430193.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 078 236</ms:GML_ID>
        <ms:NAZWA>137 078 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137078236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262421.777000 431840.107000</gml:lowerCorner>
        		<gml:upperCorner>262421.777000 431840.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262421.777000 431840.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 028 100</ms:GML_ID>
        <ms:NAZWA>195 028 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195028100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275721.879000 432313.869000</gml:lowerCorner>
        		<gml:upperCorner>275721.879000 432313.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275721.879000 432313.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 076 105</ms:GML_ID>
        <ms:NAZWA>137 076 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137076105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262374.441000 432746.958000</gml:lowerCorner>
        		<gml:upperCorner>262374.441000 432746.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262374.441000 432746.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 027 191</ms:GML_ID>
        <ms:NAZWA>195 027 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195027191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275651.419000 433205.944000</gml:lowerCorner>
        		<gml:upperCorner>275651.419000 433205.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275651.419000 433205.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 075 209</ms:GML_ID>
        <ms:NAZWA>137 075 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137075209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275594.982000 434654.088000</gml:lowerCorner>
        		<gml:upperCorner>275594.982000 434654.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275594.982000 434654.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 073 760</ms:GML_ID>
        <ms:NAZWA>137 073 760</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137073760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275565.095000 435460.321000</gml:lowerCorner>
        		<gml:upperCorner>275565.095000 435460.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275565.095000 435460.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 072 951</ms:GML_ID>
        <ms:NAZWA>137 072 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137072951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275546.179000 435945.086000</gml:lowerCorner>
        		<gml:upperCorner>275546.179000 435945.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275546.179000 435945.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 072 467</ms:GML_ID>
        <ms:NAZWA>137 072 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137072467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275707.437216 437642.808034</gml:lowerCorner>
        		<gml:upperCorner>275707.437216 437642.808034</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275707.437216 437642.808034</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 070 745</ms:GML_ID>
        <ms:NAZWA>137 070 745</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137070745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262255.826000 437758.761000</gml:lowerCorner>
        		<gml:upperCorner>262255.826000 437758.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262255.826000 437758.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 017 317</ms:GML_ID>
        <ms:NAZWA>195 017 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195017317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275127.681638 443890.058440</gml:lowerCorner>
        		<gml:upperCorner>275127.681638 443890.058440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275127.681638 443890.058440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.709 000 600</ms:GML_ID>
        <ms:NAZWA>709 000 600</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>709000600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274718.207695 443940.319991</gml:lowerCorner>
        		<gml:upperCorner>274718.207695 443940.319991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274718.207695 443940.319991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 063 198</ms:GML_ID>
        <ms:NAZWA>137 063 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137063198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274661.574000 444253.710000</gml:lowerCorner>
        		<gml:upperCorner>274661.574000 444253.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274661.574000 444253.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 062 964</ms:GML_ID>
        <ms:NAZWA>137 062 964</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>137062964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273556.911000 444670.267000</gml:lowerCorner>
        		<gml:upperCorner>273556.911000 444670.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273556.911000 444670.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 002 340</ms:GML_ID>
        <ms:NAZWA>151 002 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151002340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269608.701000 447240.285000</gml:lowerCorner>
        		<gml:upperCorner>269608.701000 447240.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269608.701000 447240.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 007 129</ms:GML_ID>
        <ms:NAZWA>151 007 129</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151007129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268526.470000 447866.874000</gml:lowerCorner>
        		<gml:upperCorner>268526.470000 447866.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268526.470000 447866.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 008 382</ms:GML_ID>
        <ms:NAZWA>151 008 382</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151008382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265906.309000 449215.612000</gml:lowerCorner>
        		<gml:upperCorner>265906.309000 449215.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265906.309000 449215.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 011 331</ms:GML_ID>
        <ms:NAZWA>151 011 331</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151011331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>264189.452051 450101.318132</gml:lowerCorner>
        		<gml:upperCorner>264189.452051 450101.318132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>264189.452051 450101.318132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 013 261</ms:GML_ID>
        <ms:NAZWA>151 013 261</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151013261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263870.597000 450265.651000</gml:lowerCorner>
        		<gml:upperCorner>263870.597000 450265.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263870.597000 450265.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 013 621</ms:GML_ID>
        <ms:NAZWA>151 013 621</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151013621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263693.630000 450345.590000</gml:lowerCorner>
        		<gml:upperCorner>263693.630000 450345.590000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263693.630000 450345.590000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.151 013 814</ms:GML_ID>
        <ms:NAZWA>151 013 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>151013814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256453.296000 426345.508000</gml:lowerCorner>
        		<gml:upperCorner>256453.296000 426345.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256453.296000 426345.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 037 110</ms:GML_ID>
        <ms:NAZWA>195 037 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195037110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255291.379848 426546.478628</gml:lowerCorner>
        		<gml:upperCorner>255291.379848 426546.478628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255291.379848 426546.478628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 038 601</ms:GML_ID>
        <ms:NAZWA>195 038 601</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195038601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256740.490000 426799.625000</gml:lowerCorner>
        		<gml:upperCorner>256740.490000 426799.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256740.490000 426799.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 036 570</ms:GML_ID>
        <ms:NAZWA>195 036 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195036570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252653.699000 427344.827000</gml:lowerCorner>
        		<gml:upperCorner>252653.699000 427344.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252653.699000 427344.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 002 448</ms:GML_ID>
        <ms:NAZWA>325 002 448</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325002448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253736.838000 427650.100000</gml:lowerCorner>
        		<gml:upperCorner>253736.838000 427650.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253736.838000 427650.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 001 282</ms:GML_ID>
        <ms:NAZWA>325 001 282</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325001282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>253753.905387 427685.574468</gml:lowerCorner>
        		<gml:upperCorner>253753.905387 427685.574468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>253753.905387 427685.574468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 023 089</ms:GML_ID>
        <ms:NAZWA>177 023 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177023089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252764.941000 428467.507000</gml:lowerCorner>
        		<gml:upperCorner>252764.941000 428467.507000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252764.941000 428467.507000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 021 825</ms:GML_ID>
        <ms:NAZWA>177 021 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177021825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257929.904000 428541.473000</gml:lowerCorner>
        		<gml:upperCorner>257929.904000 428541.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257929.904000 428541.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 034 034</ms:GML_ID>
        <ms:NAZWA>195 034 034</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195034034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>252020.547000 429087.995000</gml:lowerCorner>
        		<gml:upperCorner>252020.547000 429087.995000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>252020.547000 429087.995000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 020 857</ms:GML_ID>
        <ms:NAZWA>177 020 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177020857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258407.141000 429123.032000</gml:lowerCorner>
        		<gml:upperCorner>258407.141000 429123.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258407.141000 429123.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 033 234</ms:GML_ID>
        <ms:NAZWA>195 033 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195033234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>245824.489921 429225.898610</gml:lowerCorner>
        		<gml:upperCorner>245824.489921 429225.898610</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>245824.489921 429225.898610</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 008 362</ms:GML_ID>
        <ms:NAZWA>194 008 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194008362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251777.354000 429385.735000</gml:lowerCorner>
        		<gml:upperCorner>251777.354000 429385.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251777.354000 429385.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 020 469</ms:GML_ID>
        <ms:NAZWA>177 020 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177020469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259218.850000 429472.770000</gml:lowerCorner>
        		<gml:upperCorner>259218.850000 429472.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259218.850000 429472.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 032 348</ms:GML_ID>
        <ms:NAZWA>195 032 348</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195032348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259563.543000 429679.648000</gml:lowerCorner>
        		<gml:upperCorner>259563.543000 429679.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259563.543000 429679.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 031 941</ms:GML_ID>
        <ms:NAZWA>195 031 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195031941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251524.430000 429808.066000</gml:lowerCorner>
        		<gml:upperCorner>251524.430000 429808.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251524.430000 429808.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 019 977</ms:GML_ID>
        <ms:NAZWA>177 019 977</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177019977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259809.179000 429969.184000</gml:lowerCorner>
        		<gml:upperCorner>259809.179000 429969.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259809.179000 429969.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 031 557</ms:GML_ID>
        <ms:NAZWA>195 031 557</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195031557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>251084.253000 430543.712000</gml:lowerCorner>
        		<gml:upperCorner>251084.253000 430543.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>251084.253000 430543.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 019 119</ms:GML_ID>
        <ms:NAZWA>177 019 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177019119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261518.274000 430638.703000</gml:lowerCorner>
        		<gml:upperCorner>261518.274000 430638.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261518.274000 430638.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 029 711</ms:GML_ID>
        <ms:NAZWA>195 029 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195029711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250933.961000 430795.235000</gml:lowerCorner>
        		<gml:upperCorner>250933.961000 430795.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250933.961000 430795.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 018 825</ms:GML_ID>
        <ms:NAZWA>177 018 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177018825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>261866.848000 430857.009000</gml:lowerCorner>
        		<gml:upperCorner>261866.848000 430857.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>261866.848000 430857.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.195 029 299</ms:GML_ID>
        <ms:NAZWA>195 029 299</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>195029299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249977.291000 432247.270000</gml:lowerCorner>
        		<gml:upperCorner>249977.291000 432247.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249977.291000 432247.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 017 085</ms:GML_ID>
        <ms:NAZWA>177 017 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177017085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249809.046000 432541.864000</gml:lowerCorner>
        		<gml:upperCorner>249809.046000 432541.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249809.046000 432541.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 016 746</ms:GML_ID>
        <ms:NAZWA>177 016 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177016746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249621.666000 432872.106000</gml:lowerCorner>
        		<gml:upperCorner>249621.666000 432872.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249621.666000 432872.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 016 365</ms:GML_ID>
        <ms:NAZWA>177 016 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177016365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248795.359000 434397.397000</gml:lowerCorner>
        		<gml:upperCorner>248795.359000 434397.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248795.359000 434397.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 014 620</ms:GML_ID>
        <ms:NAZWA>177 014 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177014620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>248299.017000 434794.626000</gml:lowerCorner>
        		<gml:upperCorner>248299.017000 434794.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>248299.017000 434794.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 013 979</ms:GML_ID>
        <ms:NAZWA>177 013 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177013979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246418.477000 435104.192000</gml:lowerCorner>
        		<gml:upperCorner>246418.477000 435104.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246418.477000 435104.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 012 003</ms:GML_ID>
        <ms:NAZWA>177 012 003</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177012003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246708.722493 435127.287182</gml:lowerCorner>
        		<gml:upperCorner>246708.722493 435127.287182</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246708.722493 435127.287182</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 012 298</ms:GML_ID>
        <ms:NAZWA>177 012 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177012298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244747.593624 421376.202042</gml:lowerCorner>
        		<gml:upperCorner>244747.593624 421376.202042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244747.593624 421376.202042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 013 295</ms:GML_ID>
        <ms:NAZWA>325 013 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325013295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>236756.427000 421801.793000</gml:lowerCorner>
        		<gml:upperCorner>236756.427000 421801.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>236756.427000 421801.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 022 364</ms:GML_ID>
        <ms:NAZWA>325 022 364</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325022364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243661.084000 421921.582000</gml:lowerCorner>
        		<gml:upperCorner>243661.084000 421921.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243661.084000 421921.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 014 508</ms:GML_ID>
        <ms:NAZWA>325 014 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325014508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>237392.708000 422090.703000</gml:lowerCorner>
        		<gml:upperCorner>237392.708000 422090.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>237392.708000 422090.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 021 655</ms:GML_ID>
        <ms:NAZWA>325 021 655</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325021655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238001.010000 422093.100000</gml:lowerCorner>
        		<gml:upperCorner>238001.010000 422093.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238001.010000 422093.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 021 044</ms:GML_ID>
        <ms:NAZWA>325 021 044</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325021044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>238742.046000 422221.342000</gml:lowerCorner>
        		<gml:upperCorner>238742.046000 422221.342000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>238742.046000 422221.342000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 020 282</ms:GML_ID>
        <ms:NAZWA>325 020 282</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325020282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>239533.014000 422241.446000</gml:lowerCorner>
        		<gml:upperCorner>239533.014000 422241.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>239533.014000 422241.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 019 484</ms:GML_ID>
        <ms:NAZWA>325 019 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325019484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>240201.841000 422281.592000</gml:lowerCorner>
        		<gml:upperCorner>240201.841000 422281.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>240201.841000 422281.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 018 824</ms:GML_ID>
        <ms:NAZWA>325 018 824</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325018824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>241059.814805 422781.563907</gml:lowerCorner>
        		<gml:upperCorner>241059.814805 422781.563907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>241059.814805 422781.563907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 017 827</ms:GML_ID>
        <ms:NAZWA>325 017 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325017827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>243076.913000 422819.920000</gml:lowerCorner>
        		<gml:upperCorner>243076.913000 422819.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>243076.913000 422819.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 015 653</ms:GML_ID>
        <ms:NAZWA>325 015 653</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325015653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>242452.385000 423121.765000</gml:lowerCorner>
        		<gml:upperCorner>242452.385000 423121.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>242452.385000 423121.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 016 351</ms:GML_ID>
        <ms:NAZWA>325 016 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325016351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244657.546000 432079.168000</gml:lowerCorner>
        		<gml:upperCorner>244657.546000 432079.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244657.546000 432079.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 005 272</ms:GML_ID>
        <ms:NAZWA>194 005 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194005272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244616.932000 432305.423000</gml:lowerCorner>
        		<gml:upperCorner>244616.932000 432305.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244616.932000 432305.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 005 041</ms:GML_ID>
        <ms:NAZWA>194 005 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194005041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244592.511000 432764.015000</gml:lowerCorner>
        		<gml:upperCorner>244592.511000 432764.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244592.511000 432764.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 004 581</ms:GML_ID>
        <ms:NAZWA>194 004 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194004581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244558.170000 434603.578000</gml:lowerCorner>
        		<gml:upperCorner>244558.170000 434603.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244558.170000 434603.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 002 730</ms:GML_ID>
        <ms:NAZWA>194 002 730</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194002730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244902.855000 435211.046000</gml:lowerCorner>
        		<gml:upperCorner>244902.855000 435211.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244902.855000 435211.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.194 002 031</ms:GML_ID>
        <ms:NAZWA>194 002 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>194002031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>244997.488000 436947.811000</gml:lowerCorner>
        		<gml:upperCorner>244997.488000 436947.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>244997.488000 436947.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 009 494</ms:GML_ID>
        <ms:NAZWA>177 009 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177009494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>258142.518000 416746.679000</gml:lowerCorner>
        		<gml:upperCorner>258142.518000 416746.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>258142.518000 416746.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 036 099</ms:GML_ID>
        <ms:NAZWA>177 036 099</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177036099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257619.692000 417315.574000</gml:lowerCorner>
        		<gml:upperCorner>257619.692000 417315.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257619.692000 417315.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 035 324</ms:GML_ID>
        <ms:NAZWA>177 035 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177035324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>257245.837000 417760.145000</gml:lowerCorner>
        		<gml:upperCorner>257245.837000 417760.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>257245.837000 417760.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 034 742</ms:GML_ID>
        <ms:NAZWA>177 034 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177034742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256833.242000 418250.329000</gml:lowerCorner>
        		<gml:upperCorner>256833.242000 418250.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256833.242000 418250.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 034 099</ms:GML_ID>
        <ms:NAZWA>177 034 099</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177034099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>256055.136000 419302.079000</gml:lowerCorner>
        		<gml:upperCorner>256055.136000 419302.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>256055.136000 419302.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 032 792</ms:GML_ID>
        <ms:NAZWA>177 032 792</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177032792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255304.046000 420658.335000</gml:lowerCorner>
        		<gml:upperCorner>255304.046000 420658.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255304.046000 420658.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 031 231</ms:GML_ID>
        <ms:NAZWA>177 031 231</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177031231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255133.594000 421169.003000</gml:lowerCorner>
        		<gml:upperCorner>255133.594000 421169.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255133.594000 421169.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 030 692</ms:GML_ID>
        <ms:NAZWA>177 030 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177030692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254993.731000 421985.348000</gml:lowerCorner>
        		<gml:upperCorner>254993.731000 421985.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254993.731000 421985.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 029 861</ms:GML_ID>
        <ms:NAZWA>177 029 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177029861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246030.604000 422098.470000</gml:lowerCorner>
        		<gml:upperCorner>246030.604000 422098.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246030.604000 422098.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 011 612</ms:GML_ID>
        <ms:NAZWA>325 011 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325011612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>246242.736000 422574.068000</gml:lowerCorner>
        		<gml:upperCorner>246242.736000 422574.068000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>246242.736000 422574.068000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 011 089</ms:GML_ID>
        <ms:NAZWA>325 011 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325011089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254826.030000 423818.805000</gml:lowerCorner>
        		<gml:upperCorner>254826.030000 423818.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254826.030000 423818.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 028 060</ms:GML_ID>
        <ms:NAZWA>177 028 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177028060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>254989.759718 424267.055221</gml:lowerCorner>
        		<gml:upperCorner>254989.759718 424267.055221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>254989.759718 424267.055221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 027 524</ms:GML_ID>
        <ms:NAZWA>177 027 524</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177027524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247189.485000 424315.513000</gml:lowerCorner>
        		<gml:upperCorner>247189.485000 424315.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247189.485000 424315.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 009 099</ms:GML_ID>
        <ms:NAZWA>325 009 099</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325009099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>247959.349000 424830.607000</gml:lowerCorner>
        		<gml:upperCorner>247959.349000 424830.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>247959.349000 424830.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 008 118</ms:GML_ID>
        <ms:NAZWA>325 008 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325008118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249052.713000 424881.099000</gml:lowerCorner>
        		<gml:upperCorner>249052.713000 424881.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249052.713000 424881.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 007 015</ms:GML_ID>
        <ms:NAZWA>325 007 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325007015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>249533.260000 425005.280000</gml:lowerCorner>
        		<gml:upperCorner>249533.260000 425005.280000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>249533.260000 425005.280000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 006 515</ms:GML_ID>
        <ms:NAZWA>325 006 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325006515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255496.453000 425354.642000</gml:lowerCorner>
        		<gml:upperCorner>255496.453000 425354.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255496.453000 425354.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 026 253</ms:GML_ID>
        <ms:NAZWA>177 026 253</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>177026253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>250527.386000 425604.064000</gml:lowerCorner>
        		<gml:upperCorner>250527.386000 425604.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>250527.386000 425604.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.325 005 342</ms:GML_ID>
        <ms:NAZWA>325 005 342</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>325005342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287572.503599 416484.170158</gml:lowerCorner>
        		<gml:upperCorner>287572.503599 416484.170158</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287572.503599 416484.170158</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 017 482</ms:GML_ID>
        <ms:NAZWA>306 017 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306017482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287723.614000 420523.120000</gml:lowerCorner>
        		<gml:upperCorner>287723.614000 420523.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287723.614000 420523.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 013 244</ms:GML_ID>
        <ms:NAZWA>306 013 244</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306013244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287869.339339 417160.386637</gml:lowerCorner>
        		<gml:upperCorner>287869.339339 417160.386637</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287869.339339 417160.386637</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 016 744</ms:GML_ID>
        <ms:NAZWA>306 016 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306016744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287996.554000 419893.352000</gml:lowerCorner>
        		<gml:upperCorner>287996.554000 419893.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287996.554000 419893.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 013 943</ms:GML_ID>
        <ms:NAZWA>306 013 943</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306013943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288046.276000 423492.007000</gml:lowerCorner>
        		<gml:upperCorner>288046.276000 423492.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288046.276000 423492.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 009 739</ms:GML_ID>
        <ms:NAZWA>306 009 739</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306009739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288067.349595 417618.505757</gml:lowerCorner>
        		<gml:upperCorner>288067.349595 417618.505757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288067.349595 417618.505757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 016 245</ms:GML_ID>
        <ms:NAZWA>306 016 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306016245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288094.466000 419477.772000</gml:lowerCorner>
        		<gml:upperCorner>288094.466000 419477.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288094.466000 419477.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 014 370</ms:GML_ID>
        <ms:NAZWA>306 014 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306014370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288113.498000 418118.557000</gml:lowerCorner>
        		<gml:upperCorner>288113.498000 418118.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288113.498000 418118.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 015 741</ms:GML_ID>
        <ms:NAZWA>306 015 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306015741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288133.376000 418436.952000</gml:lowerCorner>
        		<gml:upperCorner>288133.376000 418436.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288133.376000 418436.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 015 422</ms:GML_ID>
        <ms:NAZWA>306 015 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306015422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288163.181000 418918.010000</gml:lowerCorner>
        		<gml:upperCorner>288163.181000 418918.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288163.181000 418918.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 014 940</ms:GML_ID>
        <ms:NAZWA>306 014 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306014940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288187.994000 423661.191000</gml:lowerCorner>
        		<gml:upperCorner>288187.994000 423661.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288187.994000 423661.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 009 516</ms:GML_ID>
        <ms:NAZWA>306 009 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306009516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288349.705528 434460.533381</gml:lowerCorner>
        		<gml:upperCorner>288349.705528 434460.533381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288349.705528 434460.533381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 015 696</ms:GML_ID>
        <ms:NAZWA>136 015 696</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136015696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288575.730000 423987.303000</gml:lowerCorner>
        		<gml:upperCorner>288575.730000 423987.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288575.730000 423987.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 009 008</ms:GML_ID>
        <ms:NAZWA>306 009 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306009008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288985.113000 433912.076000</gml:lowerCorner>
        		<gml:upperCorner>288985.113000 433912.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288985.113000 433912.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 016 537</ms:GML_ID>
        <ms:NAZWA>136 016 537</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136016537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289850.899506 433056.252824</gml:lowerCorner>
        		<gml:upperCorner>289850.899506 433056.252824</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289850.899506 433056.252824</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 017 758</ms:GML_ID>
        <ms:NAZWA>136 017 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136017758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290329.771000 425252.355000</gml:lowerCorner>
        		<gml:upperCorner>290329.771000 425252.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290329.771000 425252.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 006 843</ms:GML_ID>
        <ms:NAZWA>306 006 843</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306006843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290331.416000 432144.794000</gml:lowerCorner>
        		<gml:upperCorner>290331.416000 432144.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290331.416000 432144.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 018 791</ms:GML_ID>
        <ms:NAZWA>136 018 791</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136018791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290548.455000 425419.961000</gml:lowerCorner>
        		<gml:upperCorner>290548.455000 425419.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290548.455000 425419.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 006 568</ms:GML_ID>
        <ms:NAZWA>306 006 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306006568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290769.181000 431405.350000</gml:lowerCorner>
        		<gml:upperCorner>290769.181000 431405.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290769.181000 431405.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 019 655</ms:GML_ID>
        <ms:NAZWA>136 019 655</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136019655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291113.547359 426034.914284</gml:lowerCorner>
        		<gml:upperCorner>291113.547359 426034.914284</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291113.547359 426034.914284</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 005 723</ms:GML_ID>
        <ms:NAZWA>306 005 723</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306005723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291668.531000 430736.048000</gml:lowerCorner>
        		<gml:upperCorner>291668.531000 430736.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291668.531000 430736.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 020 785</ms:GML_ID>
        <ms:NAZWA>136 020 785</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136020785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292131.487788 430461.367271</gml:lowerCorner>
        		<gml:upperCorner>292131.487788 430461.367271</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292131.487788 430461.367271</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 021 312</ms:GML_ID>
        <ms:NAZWA>136 021 312</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136021312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293414.022237 429863.136579</gml:lowerCorner>
        		<gml:upperCorner>293414.022237 429863.136579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293414.022237 429863.136579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 022 748</ms:GML_ID>
        <ms:NAZWA>136 022 748</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136022748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296273.132000 429381.594000</gml:lowerCorner>
        		<gml:upperCorner>296273.132000 429381.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296273.132000 429381.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 025 649</ms:GML_ID>
        <ms:NAZWA>136 025 649</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136025649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298972.584366 428953.151075</gml:lowerCorner>
        		<gml:upperCorner>298972.584366 428953.151075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298972.584366 428953.151075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 028 383</ms:GML_ID>
        <ms:NAZWA>136 028 383</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136028383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301990.479167 428470.285638</gml:lowerCorner>
        		<gml:upperCorner>301990.479167 428470.285638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301990.479167 428470.285638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 031 443</ms:GML_ID>
        <ms:NAZWA>136 031 443</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136031443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259298.207642 416178.469777</gml:lowerCorner>
        		<gml:upperCorner>259298.207642 416178.469777</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259298.207642 416178.469777</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.177 037 409</ms:GML_ID>
        <ms:NAZWA>177 037 409</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>177037409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>259913.157000 414635.654000</gml:lowerCorner>
        		<gml:upperCorner>259913.157000 414635.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>259913.157000 414635.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.294 001 393</ms:GML_ID>
        <ms:NAZWA>294 001 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>294001393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274063.219000 415793.674000</gml:lowerCorner>
        		<gml:upperCorner>274063.219000 415793.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274063.219000 415793.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 093 378</ms:GML_ID>
        <ms:NAZWA>137 093 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137093378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274242.004000 416214.762000</gml:lowerCorner>
        		<gml:upperCorner>274242.004000 416214.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274242.004000 416214.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 092 919</ms:GML_ID>
        <ms:NAZWA>137 092 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137092919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274502.792000 416823.200000</gml:lowerCorner>
        		<gml:upperCorner>274502.792000 416823.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274502.792000 416823.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 092 257</ms:GML_ID>
        <ms:NAZWA>137 092 257</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137092257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275812.740571 419518.912265</gml:lowerCorner>
        		<gml:upperCorner>275812.740571 419518.912265</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275812.740571 419518.912265</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 089 244</ms:GML_ID>
        <ms:NAZWA>137 089 244</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137089244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276327.318000 425462.018000</gml:lowerCorner>
        		<gml:upperCorner>276327.318000 425462.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276327.318000 425462.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 082 988</ms:GML_ID>
        <ms:NAZWA>137 082 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137082988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276353.520000 420222.500000</gml:lowerCorner>
        		<gml:upperCorner>276353.520000 420222.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276353.520000 420222.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 088 354</ms:GML_ID>
        <ms:NAZWA>137 088 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137088354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276403.261000 424606.443000</gml:lowerCorner>
        		<gml:upperCorner>276403.261000 424606.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276403.261000 424606.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 083 849</ms:GML_ID>
        <ms:NAZWA>137 083 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137083849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276492.284000 420405.077000</gml:lowerCorner>
        		<gml:upperCorner>276492.284000 420405.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276492.284000 420405.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 088 126</ms:GML_ID>
        <ms:NAZWA>137 088 126</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137088126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276549.008000 422973.013000</gml:lowerCorner>
        		<gml:upperCorner>276549.008000 422973.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276549.008000 422973.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 085 489</ms:GML_ID>
        <ms:NAZWA>137 085 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137085489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276582.613000 422610.692000</gml:lowerCorner>
        		<gml:upperCorner>276582.613000 422610.692000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276582.613000 422610.692000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 085 855</ms:GML_ID>
        <ms:NAZWA>137 085 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137085855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276636.077000 422010.268000</gml:lowerCorner>
        		<gml:upperCorner>276636.077000 422010.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276636.077000 422010.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 086 457</ms:GML_ID>
        <ms:NAZWA>137 086 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137086457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276713.533000 420845.131000</gml:lowerCorner>
        		<gml:upperCorner>276713.533000 420845.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276713.533000 420845.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 087 627</ms:GML_ID>
        <ms:NAZWA>137 087 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137087627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286562.910000 415090.015000</gml:lowerCorner>
        		<gml:upperCorner>286562.910000 415090.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286562.910000 415090.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 019 281</ms:GML_ID>
        <ms:NAZWA>306 019 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306019281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286655.834000 415311.014000</gml:lowerCorner>
        		<gml:upperCorner>286655.834000 415311.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286655.834000 415311.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 019 040</ms:GML_ID>
        <ms:NAZWA>306 019 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306019040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286707.798000 415533.250000</gml:lowerCorner>
        		<gml:upperCorner>286707.798000 415533.250000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286707.798000 415533.250000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 018 812</ms:GML_ID>
        <ms:NAZWA>306 018 812</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306018812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287015.062000 415854.951000</gml:lowerCorner>
        		<gml:upperCorner>287015.062000 415854.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287015.062000 415854.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 018 355</ms:GML_ID>
        <ms:NAZWA>306 018 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306018355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287080.314000 421678.088000</gml:lowerCorner>
        		<gml:upperCorner>287080.314000 421678.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287080.314000 421678.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 011 908</ms:GML_ID>
        <ms:NAZWA>306 011 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306011908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287112.607486 421553.972455</gml:lowerCorner>
        		<gml:upperCorner>287112.607486 421553.972455</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287112.607486 421553.972455</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 012 037</ms:GML_ID>
        <ms:NAZWA>306 012 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306012037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287227.970616 422523.203001</gml:lowerCorner>
        		<gml:upperCorner>287227.970616 422523.203001</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287227.970616 422523.203001</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 011 005</ms:GML_ID>
        <ms:NAZWA>306 011 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306011005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287258.299000 415999.232000</gml:lowerCorner>
        		<gml:upperCorner>287258.299000 415999.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287258.299000 415999.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 018 072</ms:GML_ID>
        <ms:NAZWA>306 018 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306018072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287357.135000 421011.349000</gml:lowerCorner>
        		<gml:upperCorner>287357.135000 421011.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287357.135000 421011.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 012 634</ms:GML_ID>
        <ms:NAZWA>306 012 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306012634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287430.042000 416173.359000</gml:lowerCorner>
        		<gml:upperCorner>287430.042000 416173.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287430.042000 416173.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 017 826</ms:GML_ID>
        <ms:NAZWA>306 017 826</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306017826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287490.588588 422834.534209</gml:lowerCorner>
        		<gml:upperCorner>287490.588588 422834.534209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287490.588588 422834.534209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 010 599</ms:GML_ID>
        <ms:NAZWA>306 010 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306010599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279637.928000 405033.112000</gml:lowerCorner>
        		<gml:upperCorner>279637.928000 405033.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279637.928000 405033.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 032 340</ms:GML_ID>
        <ms:NAZWA>306 032 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306032340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279879.027000 405258.718000</gml:lowerCorner>
        		<gml:upperCorner>279879.027000 405258.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279879.027000 405258.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 032 007</ms:GML_ID>
        <ms:NAZWA>306 032 007</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306032007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280269.604000 405423.878000</gml:lowerCorner>
        		<gml:upperCorner>280269.604000 405423.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280269.604000 405423.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 031 579</ms:GML_ID>
        <ms:NAZWA>306 031 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306031579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274470.588352 405831.052718</gml:lowerCorner>
        		<gml:upperCorner>274470.588352 405831.052718</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274470.588352 405831.052718</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 104 162</ms:GML_ID>
        <ms:NAZWA>137 104 162</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137104162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281002.819000 405951.904000</gml:lowerCorner>
        		<gml:upperCorner>281002.819000 405951.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281002.819000 405951.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 030 659</ms:GML_ID>
        <ms:NAZWA>306 030 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306030659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281235.624000 406341.143000</gml:lowerCorner>
        		<gml:upperCorner>281235.624000 406341.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281235.624000 406341.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 030 204</ms:GML_ID>
        <ms:NAZWA>306 030 204</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306030204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281934.163000 407278.412000</gml:lowerCorner>
        		<gml:upperCorner>281934.163000 407278.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281934.163000 407278.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 029 031</ms:GML_ID>
        <ms:NAZWA>306 029 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306029031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282435.464000 407976.409000</gml:lowerCorner>
        		<gml:upperCorner>282435.464000 407976.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282435.464000 407976.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 028 170</ms:GML_ID>
        <ms:NAZWA>306 028 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306028170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282666.426000 408350.890000</gml:lowerCorner>
        		<gml:upperCorner>282666.426000 408350.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282666.426000 408350.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 027 729</ms:GML_ID>
        <ms:NAZWA>306 027 729</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306027729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283121.518000 409030.816000</gml:lowerCorner>
        		<gml:upperCorner>283121.518000 409030.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283121.518000 409030.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 026 904</ms:GML_ID>
        <ms:NAZWA>306 026 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306026904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283701.878302 409510.767168</gml:lowerCorner>
        		<gml:upperCorner>283701.878302 409510.767168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283701.878302 409510.767168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 026 150</ms:GML_ID>
        <ms:NAZWA>306 026 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306026150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283990.064000 409684.126761</gml:lowerCorner>
        		<gml:upperCorner>283990.064000 409684.126761</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283990.064000 409684.126761</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 025 809</ms:GML_ID>
        <ms:NAZWA>306 025 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306025809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284404.541000 409828.004000</gml:lowerCorner>
        		<gml:upperCorner>284404.541000 409828.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284404.541000 409828.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 025 368</ms:GML_ID>
        <ms:NAZWA>306 025 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306025368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284679.154000 410083.637000</gml:lowerCorner>
        		<gml:upperCorner>284679.154000 410083.637000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284679.154000 410083.637000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 024 990</ms:GML_ID>
        <ms:NAZWA>306 024 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306024990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284873.817423 410280.676394</gml:lowerCorner>
        		<gml:upperCorner>284873.817423 410280.676394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284873.817423 410280.676394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 024 713</ms:GML_ID>
        <ms:NAZWA>306 024 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306024713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285102.529000 410511.646000</gml:lowerCorner>
        		<gml:upperCorner>285102.529000 410511.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285102.529000 410511.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 024 388</ms:GML_ID>
        <ms:NAZWA>306 024 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306024388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285350.948914 410771.183394</gml:lowerCorner>
        		<gml:upperCorner>285350.948914 410771.183394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285350.948914 410771.183394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 024 029</ms:GML_ID>
        <ms:NAZWA>306 024 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306024029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285990.590000 411983.013000</gml:lowerCorner>
        		<gml:upperCorner>285990.590000 411983.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285990.590000 411983.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 022 582</ms:GML_ID>
        <ms:NAZWA>306 022 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306022582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285986.404342 412455.543707</gml:lowerCorner>
        		<gml:upperCorner>285986.404342 412455.543707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285986.404342 412455.543707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 022 110</ms:GML_ID>
        <ms:NAZWA>306 022 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306022110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285914.967000 412716.806000</gml:lowerCorner>
        		<gml:upperCorner>285914.967000 412716.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285914.967000 412716.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 021 837</ms:GML_ID>
        <ms:NAZWA>306 021 837</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306021837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272861.628000 413233.517000</gml:lowerCorner>
        		<gml:upperCorner>272861.628000 413233.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272861.628000 413233.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 096 211</ms:GML_ID>
        <ms:NAZWA>137 096 211</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137096211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285988.435901 413802.326590</gml:lowerCorner>
        		<gml:upperCorner>285988.435901 413802.326590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285988.435901 413802.326590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 020 692</ms:GML_ID>
        <ms:NAZWA>306 020 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306020692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273195.042000 386722.667000</gml:lowerCorner>
        		<gml:upperCorner>273195.042000 386722.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273195.042000 386722.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.333 002 420</ms:GML_ID>
        <ms:NAZWA>333 002 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>333002420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278567.706000 386909.211000</gml:lowerCorner>
        		<gml:upperCorner>278567.706000 386909.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278567.706000 386909.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 123 915</ms:GML_ID>
        <ms:NAZWA>137 123 915</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137123915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278373.490000 387308.745000</gml:lowerCorner>
        		<gml:upperCorner>278373.490000 387308.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278373.490000 387308.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 123 472</ms:GML_ID>
        <ms:NAZWA>137 123 472</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137123472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273195.943000 387418.218000</gml:lowerCorner>
        		<gml:upperCorner>273195.943000 387418.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273195.943000 387418.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.333 003 116</ms:GML_ID>
        <ms:NAZWA>333 003 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>333003116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273202.763000 388110.378000</gml:lowerCorner>
        		<gml:upperCorner>273202.763000 388110.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273202.763000 388110.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.333 003 811</ms:GML_ID>
        <ms:NAZWA>333 003 811</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>333003811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277560.701647 389035.096771</gml:lowerCorner>
        		<gml:upperCorner>277560.701647 389035.096771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277560.701647 389035.096771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 121 561</ms:GML_ID>
        <ms:NAZWA>137 121 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137121561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277081.340526 390221.042752</gml:lowerCorner>
        		<gml:upperCorner>277081.340526 390221.042752</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277081.340526 390221.042752</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 120 279</ms:GML_ID>
        <ms:NAZWA>137 120 279</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137120279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276492.975000 391674.945000</gml:lowerCorner>
        		<gml:upperCorner>276492.975000 391674.945000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276492.975000 391674.945000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 118 711</ms:GML_ID>
        <ms:NAZWA>137 118 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137118711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>269563.505000 391743.190000</gml:lowerCorner>
        		<gml:upperCorner>269563.505000 391743.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>269563.505000 391743.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.333 009 137</ms:GML_ID>
        <ms:NAZWA>333 009 137</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>333009137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>268766.258000 392924.098000</gml:lowerCorner>
        		<gml:upperCorner>268766.258000 392924.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>268766.258000 392924.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.333 010 630</ms:GML_ID>
        <ms:NAZWA>333 010 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>333010630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275901.115000 393138.397000</gml:lowerCorner>
        		<gml:upperCorner>275901.115000 393138.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275901.115000 393138.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 117 132</ms:GML_ID>
        <ms:NAZWA>137 117 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137117132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293897.900000 393772.151000</gml:lowerCorner>
        		<gml:upperCorner>293897.900000 393772.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293897.900000 393772.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 035 160</ms:GML_ID>
        <ms:NAZWA>287 035 160</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287035160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275021.772000 395306.121000</gml:lowerCorner>
        		<gml:upperCorner>275021.772000 395306.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275021.772000 395306.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 114 790</ms:GML_ID>
        <ms:NAZWA>137 114 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137114790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274550.242000 399512.622000</gml:lowerCorner>
        		<gml:upperCorner>274550.242000 399512.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274550.242000 399512.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 040 943</ms:GML_ID>
        <ms:NAZWA>306 040 943</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306040943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274792.395000 400183.666000</gml:lowerCorner>
        		<gml:upperCorner>274792.395000 400183.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274792.395000 400183.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 040 225</ms:GML_ID>
        <ms:NAZWA>306 040 225</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306040225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275614.846000 401728.589000</gml:lowerCorner>
        		<gml:upperCorner>275614.846000 401728.589000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275614.846000 401728.589000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 038 474</ms:GML_ID>
        <ms:NAZWA>306 038 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306038474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>275681.483000 401933.155000</gml:lowerCorner>
        		<gml:upperCorner>275681.483000 401933.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>275681.483000 401933.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 038 259</ms:GML_ID>
        <ms:NAZWA>306 038 259</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306038259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274433.794000 403699.205000</gml:lowerCorner>
        		<gml:upperCorner>274433.794000 403699.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274433.794000 403699.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 106 295</ms:GML_ID>
        <ms:NAZWA>137 106 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137106295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276994.451000 404650.167000</gml:lowerCorner>
        		<gml:upperCorner>276994.451000 404650.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276994.451000 404650.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 035 138</ms:GML_ID>
        <ms:NAZWA>306 035 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306035138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278738.496743 404825.838094</gml:lowerCorner>
        		<gml:upperCorner>278738.496743 404825.838094</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278738.496743 404825.838094</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 033 283</ms:GML_ID>
        <ms:NAZWA>306 033 283</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306033283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279142.554393 404933.841677</gml:lowerCorner>
        		<gml:upperCorner>279142.554393 404933.841677</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279142.554393 404933.841677</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 032 855</ms:GML_ID>
        <ms:NAZWA>306 032 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306032855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760942.475000 462034.381000</gml:lowerCorner>
        		<gml:upperCorner>760942.475000 462034.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760942.475000 462034.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 015 410</ms:GML_ID>
        <ms:NAZWA>213 015 410</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213015410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761234.644809 461954.351141</gml:lowerCorner>
        		<gml:upperCorner>761234.644809 461954.351141</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761234.644809 461954.351141</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 015 723</ms:GML_ID>
        <ms:NAZWA>213 015 723</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213015723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761668.749247 461853.557415</gml:lowerCorner>
        		<gml:upperCorner>761668.749247 461853.557415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761668.749247 461853.557415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 016 160</ms:GML_ID>
        <ms:NAZWA>213 016 160</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213016160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761856.149000 461699.727000</gml:lowerCorner>
        		<gml:upperCorner>761856.149000 461699.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761856.149000 461699.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 016 408</ms:GML_ID>
        <ms:NAZWA>213 016 408</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213016408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761857.669000 461161.647000</gml:lowerCorner>
        		<gml:upperCorner>761857.669000 461161.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761857.669000 461161.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 016 951</ms:GML_ID>
        <ms:NAZWA>213 016 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213016951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>762166.926000 460904.129000</gml:lowerCorner>
        		<gml:upperCorner>762166.926000 460904.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>762166.926000 460904.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 017 391</ms:GML_ID>
        <ms:NAZWA>213 017 391</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213017391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763538.001000 460957.553000</gml:lowerCorner>
        		<gml:upperCorner>763538.001000 460957.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763538.001000 460957.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 018 765</ms:GML_ID>
        <ms:NAZWA>213 018 765</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213018765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763945.019000 460860.262000</gml:lowerCorner>
        		<gml:upperCorner>763945.019000 460860.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763945.019000 460860.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 019 190</ms:GML_ID>
        <ms:NAZWA>213 019 190</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213019190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764961.029000 460532.168000</gml:lowerCorner>
        		<gml:upperCorner>764961.029000 460532.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764961.029000 460532.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 020 267</ms:GML_ID>
        <ms:NAZWA>213 020 267</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213020267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>765558.815000 460329.918000</gml:lowerCorner>
        		<gml:upperCorner>765558.815000 460329.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>765558.815000 460329.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 020 910</ms:GML_ID>
        <ms:NAZWA>213 020 910</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213020910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766926.767000 460221.453000</gml:lowerCorner>
        		<gml:upperCorner>766926.767000 460221.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766926.767000 460221.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 022 967</ms:GML_ID>
        <ms:NAZWA>213 022 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213022967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767071.854000 460360.437000</gml:lowerCorner>
        		<gml:upperCorner>767071.854000 460360.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767071.854000 460360.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 023 167</ms:GML_ID>
        <ms:NAZWA>213 023 167</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213023167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767945.624907 460915.919331</gml:lowerCorner>
        		<gml:upperCorner>767945.624907 460915.919331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767945.624907 460915.919331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 024 241</ms:GML_ID>
        <ms:NAZWA>213 024 241</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213024241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>768285.150000 460952.155000</gml:lowerCorner>
        		<gml:upperCorner>768285.150000 460952.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>768285.150000 460952.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 024 583</ms:GML_ID>
        <ms:NAZWA>213 024 583</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213024583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>768458.900000 460978.463000</gml:lowerCorner>
        		<gml:upperCorner>768458.900000 460978.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>768458.900000 460978.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 024 758</ms:GML_ID>
        <ms:NAZWA>213 024 758</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213024758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>769160.058000 461489.268000</gml:lowerCorner>
        		<gml:upperCorner>769160.058000 461489.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>769160.058000 461489.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 025 631</ms:GML_ID>
        <ms:NAZWA>213 025 631</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213025631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>769503.003186 461653.024792</gml:lowerCorner>
        		<gml:upperCorner>769503.003186 461653.024792</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>769503.003186 461653.024792</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 026 021</ms:GML_ID>
        <ms:NAZWA>213 026 021</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213026021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>769845.217264 461606.062647</gml:lowerCorner>
        		<gml:upperCorner>769845.217264 461606.062647</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>769845.217264 461606.062647</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 026 370</ms:GML_ID>
        <ms:NAZWA>213 026 370</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213026370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>770386.988237 461525.735519</gml:lowerCorner>
        		<gml:upperCorner>770386.988237 461525.735519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>770386.988237 461525.735519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 026 910</ms:GML_ID>
        <ms:NAZWA>213 026 910</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213026910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>770498.876000 462115.261000</gml:lowerCorner>
        		<gml:upperCorner>770498.876000 462115.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>770498.876000 462115.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 027 650</ms:GML_ID>
        <ms:NAZWA>213 027 650</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213027650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>770631.729000 461840.467000</gml:lowerCorner>
        		<gml:upperCorner>770631.729000 461840.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>770631.729000 461840.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 027 336</ms:GML_ID>
        <ms:NAZWA>213 027 336</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213027336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>755248.742000 462337.875000</gml:lowerCorner>
        		<gml:upperCorner>755248.742000 462337.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>755248.742000 462337.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 009 650</ms:GML_ID>
        <ms:NAZWA>213 009 650</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213009650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>756775.847000 462375.747000</gml:lowerCorner>
        		<gml:upperCorner>756775.847000 462375.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>756775.847000 462375.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 011 196</ms:GML_ID>
        <ms:NAZWA>213 011 196</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213011196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757001.679767 462322.342753</gml:lowerCorner>
        		<gml:upperCorner>757001.679767 462322.342753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757001.679767 462322.342753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 011 430</ms:GML_ID>
        <ms:NAZWA>213 011 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213011430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>762970.052000 473935.515000</gml:lowerCorner>
        		<gml:upperCorner>762970.052000 473935.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>762970.052000 473935.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 041 776</ms:GML_ID>
        <ms:NAZWA>213 041 776</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213041776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763256.456523 473435.951585</gml:lowerCorner>
        		<gml:upperCorner>763256.456523 473435.951585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763256.456523 473435.951585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 041 199</ms:GML_ID>
        <ms:NAZWA>213 041 199</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213041199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763485.474998 473269.723346</gml:lowerCorner>
        		<gml:upperCorner>763485.474998 473269.723346</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763485.474998 473269.723346</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 040 915</ms:GML_ID>
        <ms:NAZWA>213 040 915</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213040915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763587.293976 473170.929666</gml:lowerCorner>
        		<gml:upperCorner>763587.293976 473170.929666</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763587.293976 473170.929666</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 040 771</ms:GML_ID>
        <ms:NAZWA>213 040 771</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213040771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763646.132274 472997.579248</gml:lowerCorner>
        		<gml:upperCorner>763646.132274 472997.579248</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763646.132274 472997.579248</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 040 587</ms:GML_ID>
        <ms:NAZWA>213 040 587</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213040587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766229.096000 468711.901000</gml:lowerCorner>
        		<gml:upperCorner>766229.096000 468711.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766229.096000 468711.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 035 554</ms:GML_ID>
        <ms:NAZWA>213 035 554</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213035554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766293.482300 468615.234337</gml:lowerCorner>
        		<gml:upperCorner>766293.482300 468615.234337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766293.482300 468615.234337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 035 438</ms:GML_ID>
        <ms:NAZWA>213 035 438</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213035438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766330.186158 468546.858372</gml:lowerCorner>
        		<gml:upperCorner>766330.186158 468546.858372</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766330.186158 468546.858372</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 035 360</ms:GML_ID>
        <ms:NAZWA>213 035 360</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213035360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766370.924000 468448.443000</gml:lowerCorner>
        		<gml:upperCorner>766370.924000 468448.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766370.924000 468448.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 035 255</ms:GML_ID>
        <ms:NAZWA>213 035 255</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213035255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766410.478405 468323.348690</gml:lowerCorner>
        		<gml:upperCorner>766410.478405 468323.348690</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766410.478405 468323.348690</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 035 122</ms:GML_ID>
        <ms:NAZWA>213 035 122</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213035122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766458.888305 468177.065068</gml:lowerCorner>
        		<gml:upperCorner>766458.888305 468177.065068</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766458.888305 468177.065068</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 034 967</ms:GML_ID>
        <ms:NAZWA>213 034 967</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213034967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766665.120118 467805.101420</gml:lowerCorner>
        		<gml:upperCorner>766665.120118 467805.101420</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766665.120118 467805.101420</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 034 544</ms:GML_ID>
        <ms:NAZWA>213 034 544</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213034544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767044.939000 467184.636000</gml:lowerCorner>
        		<gml:upperCorner>767044.939000 467184.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767044.939000 467184.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 033 814</ms:GML_ID>
        <ms:NAZWA>213 033 814</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213033814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767549.555000 466459.781000</gml:lowerCorner>
        		<gml:upperCorner>767549.555000 466459.781000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767549.555000 466459.781000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 032 932</ms:GML_ID>
        <ms:NAZWA>213 032 932</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213032932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767907.306000 465910.510000</gml:lowerCorner>
        		<gml:upperCorner>767907.306000 465910.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767907.306000 465910.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 032 273</ms:GML_ID>
        <ms:NAZWA>213 032 273</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213032273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>768013.260000 465587.693000</gml:lowerCorner>
        		<gml:upperCorner>768013.260000 465587.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>768013.260000 465587.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 031 931</ms:GML_ID>
        <ms:NAZWA>213 031 931</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213031931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>768391.611000 465039.588000</gml:lowerCorner>
        		<gml:upperCorner>768391.611000 465039.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>768391.611000 465039.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 031 263</ms:GML_ID>
        <ms:NAZWA>213 031 263</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213031263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>768839.914000 464368.164000</gml:lowerCorner>
        		<gml:upperCorner>768839.914000 464368.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>768839.914000 464368.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 030 450</ms:GML_ID>
        <ms:NAZWA>213 030 450</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213030450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>769652.090000 463238.902000</gml:lowerCorner>
        		<gml:upperCorner>769652.090000 463238.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>769652.090000 463238.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 029 059</ms:GML_ID>
        <ms:NAZWA>213 029 059</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213029059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>770216.841000 462489.346000</gml:lowerCorner>
        		<gml:upperCorner>770216.841000 462489.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>770216.841000 462489.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 028 119</ms:GML_ID>
        <ms:NAZWA>213 028 119</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213028119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749449.255952 487094.935820</gml:lowerCorner>
        		<gml:upperCorner>749449.255952 487094.935820</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749449.255952 487094.935820</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 061 937</ms:GML_ID>
        <ms:NAZWA>213 061 937</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213061937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749885.809113 487169.812564</gml:lowerCorner>
        		<gml:upperCorner>749885.809113 487169.812564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749885.809113 487169.812564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 061 496</ms:GML_ID>
        <ms:NAZWA>213 061 496</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213061496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750451.340024 487292.671270</gml:lowerCorner>
        		<gml:upperCorner>750451.340024 487292.671270</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750451.340024 487292.671270</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 060 914</ms:GML_ID>
        <ms:NAZWA>213 060 914</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213060914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750498.447180 487301.499498</gml:lowerCorner>
        		<gml:upperCorner>750498.447180 487301.499498</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750498.447180 487301.499498</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 060 866</ms:GML_ID>
        <ms:NAZWA>213 060 866</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213060866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757127.364527 482393.929041</gml:lowerCorner>
        		<gml:upperCorner>757127.364527 482393.929041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757127.364527 482393.929041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 052 182</ms:GML_ID>
        <ms:NAZWA>213 052 182</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213052182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757416.981206 482092.192542</gml:lowerCorner>
        		<gml:upperCorner>757416.981206 482092.192542</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757416.981206 482092.192542</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 051 764</ms:GML_ID>
        <ms:NAZWA>213 051 764</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213051764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757490.284885 482015.429025</gml:lowerCorner>
        		<gml:upperCorner>757490.284885 482015.429025</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757490.284885 482015.429025</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 051 659</ms:GML_ID>
        <ms:NAZWA>213 051 659</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213051659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757653.698051 481845.999578</gml:lowerCorner>
        		<gml:upperCorner>757653.698051 481845.999578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757653.698051 481845.999578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 051 422</ms:GML_ID>
        <ms:NAZWA>213 051 422</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213051422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757819.074136 481673.614211</gml:lowerCorner>
        		<gml:upperCorner>757819.074136 481673.614211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757819.074136 481673.614211</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 051 179</ms:GML_ID>
        <ms:NAZWA>213 051 179</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213051179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>758987.995363 480343.809296</gml:lowerCorner>
        		<gml:upperCorner>758987.995363 480343.809296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>758987.995363 480343.809296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 049 410</ms:GML_ID>
        <ms:NAZWA>213 049 410</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213049410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759240.737000 480034.816000</gml:lowerCorner>
        		<gml:upperCorner>759240.737000 480034.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759240.737000 480034.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 049 011</ms:GML_ID>
        <ms:NAZWA>213 049 011</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213049011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759414.446000 479822.627000</gml:lowerCorner>
        		<gml:upperCorner>759414.446000 479822.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759414.446000 479822.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 048 736</ms:GML_ID>
        <ms:NAZWA>213 048 736</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213048736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759490.698000 479703.273000</gml:lowerCorner>
        		<gml:upperCorner>759490.698000 479703.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759490.698000 479703.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 048 584</ms:GML_ID>
        <ms:NAZWA>213 048 584</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213048584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759536.575586 479524.738989</gml:lowerCorner>
        		<gml:upperCorner>759536.575586 479524.738989</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759536.575586 479524.738989</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 048 390</ms:GML_ID>
        <ms:NAZWA>213 048 390</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213048390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759575.295000 479438.388000</gml:lowerCorner>
        		<gml:upperCorner>759575.295000 479438.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759575.295000 479438.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 048 304</ms:GML_ID>
        <ms:NAZWA>213 048 304</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213048304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759966.826622 479023.250915</gml:lowerCorner>
        		<gml:upperCorner>759966.826622 479023.250915</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759966.826622 479023.250915</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 047 733</ms:GML_ID>
        <ms:NAZWA>213 047 733</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213047733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760050.935301 478915.966072</gml:lowerCorner>
        		<gml:upperCorner>760050.935301 478915.966072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760050.935301 478915.966072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 047 596</ms:GML_ID>
        <ms:NAZWA>213 047 596</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213047596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760111.542078 478829.067829</gml:lowerCorner>
        		<gml:upperCorner>760111.542078 478829.067829</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760111.542078 478829.067829</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 047 491</ms:GML_ID>
        <ms:NAZWA>213 047 491</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213047491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760270.182633 478243.125450</gml:lowerCorner>
        		<gml:upperCorner>760270.182633 478243.125450</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760270.182633 478243.125450</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 046 877</ms:GML_ID>
        <ms:NAZWA>213 046 877</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213046877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760337.528974 478098.550937</gml:lowerCorner>
        		<gml:upperCorner>760337.528974 478098.550937</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760337.528974 478098.550937</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 046 716</ms:GML_ID>
        <ms:NAZWA>213 046 716</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213046716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760568.012000 477739.362000</gml:lowerCorner>
        		<gml:upperCorner>760568.012000 477739.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760568.012000 477739.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 046 287</ms:GML_ID>
        <ms:NAZWA>213 046 287</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213046287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760851.436822 477298.610754</gml:lowerCorner>
        		<gml:upperCorner>760851.436822 477298.610754</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760851.436822 477298.610754</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 045 765</ms:GML_ID>
        <ms:NAZWA>213 045 765</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213045765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761157.163000 476821.539000</gml:lowerCorner>
        		<gml:upperCorner>761157.163000 476821.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761157.163000 476821.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 045 196</ms:GML_ID>
        <ms:NAZWA>213 045 196</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213045196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761392.547000 476499.352000</gml:lowerCorner>
        		<gml:upperCorner>761392.547000 476499.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761392.547000 476499.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 044 797</ms:GML_ID>
        <ms:NAZWA>213 044 797</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213044797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752223.558000 446662.287000</gml:lowerCorner>
        		<gml:upperCorner>752223.558000 446662.287000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752223.558000 446662.287000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 004 756</ms:GML_ID>
        <ms:NAZWA>230 004 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230004756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6933">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749873.213000 447012.859000</gml:lowerCorner>
        		<gml:upperCorner>749873.213000 447012.859000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6933.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749873.213000 447012.859000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6933</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 047 247</ms:GML_ID>
        <ms:NAZWA>202 047 247</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202047247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749874.863000 447326.054000</gml:lowerCorner>
        		<gml:upperCorner>749874.863000 447326.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749874.863000 447326.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 046 932</ms:GML_ID>
        <ms:NAZWA>202 046 932</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202046932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>751586.920000 447578.910000</gml:lowerCorner>
        		<gml:upperCorner>751586.920000 447578.910000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>751586.920000 447578.910000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 003 640</ms:GML_ID>
        <ms:NAZWA>230 003 640</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230003640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>751426.981000 447807.339000</gml:lowerCorner>
        		<gml:upperCorner>751426.981000 447807.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>751426.981000 447807.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 003 361</ms:GML_ID>
        <ms:NAZWA>230 003 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230003361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750586.490000 448758.066000</gml:lowerCorner>
        		<gml:upperCorner>750586.490000 448758.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750586.490000 448758.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 002 080</ms:GML_ID>
        <ms:NAZWA>230 002 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230002080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6931">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749603.117917 449131.200369</gml:lowerCorner>
        		<gml:upperCorner>749603.117917 449131.200369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6931.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749603.117917 449131.200369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6931</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 045 115</ms:GML_ID>
        <ms:NAZWA>202 045 115</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202045115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750057.982000 449459.847000</gml:lowerCorner>
        		<gml:upperCorner>750057.982000 449459.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750057.982000 449459.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 001 158</ms:GML_ID>
        <ms:NAZWA>230 001 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230001158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749328.846031 450621.579324</gml:lowerCorner>
        		<gml:upperCorner>749328.846031 450621.579324</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749328.846031 450621.579324</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 043 586</ms:GML_ID>
        <ms:NAZWA>202 043 586</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202043586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749218.421000 451062.567000</gml:lowerCorner>
        		<gml:upperCorner>749218.421000 451062.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749218.421000 451062.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 043 142</ms:GML_ID>
        <ms:NAZWA>202 043 142</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202043142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749142.123000 457467.406000</gml:lowerCorner>
        		<gml:upperCorner>749142.123000 457467.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749142.123000 457467.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 001 340</ms:GML_ID>
        <ms:NAZWA>213 001 340</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213001340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749887.178000 457594.042000</gml:lowerCorner>
        		<gml:upperCorner>749887.178000 457594.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749887.178000 457594.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 002 101</ms:GML_ID>
        <ms:NAZWA>213 002 101</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213002101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750354.613000 457817.503000</gml:lowerCorner>
        		<gml:upperCorner>750354.613000 457817.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750354.613000 457817.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 002 620</ms:GML_ID>
        <ms:NAZWA>213 002 620</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213002620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750725.034000 457994.408000</gml:lowerCorner>
        		<gml:upperCorner>750725.034000 457994.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750725.034000 457994.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 003 032</ms:GML_ID>
        <ms:NAZWA>213 003 032</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213003032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752125.815000 458870.122000</gml:lowerCorner>
        		<gml:upperCorner>752125.815000 458870.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752125.815000 458870.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 004 692</ms:GML_ID>
        <ms:NAZWA>213 004 692</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213004692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752871.085000 459462.616000</gml:lowerCorner>
        		<gml:upperCorner>752871.085000 459462.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752871.085000 459462.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 005 646</ms:GML_ID>
        <ms:NAZWA>213 005 646</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213005646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>753286.361000 460270.089000</gml:lowerCorner>
        		<gml:upperCorner>753286.361000 460270.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>753286.361000 460270.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 006 563</ms:GML_ID>
        <ms:NAZWA>213 006 563</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213006563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759856.077659 462059.759482</gml:lowerCorner>
        		<gml:upperCorner>759856.077659 462059.759482</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759856.077659 462059.759482</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 014 316</ms:GML_ID>
        <ms:NAZWA>213 014 316</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213014316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>758828.136237 462076.925151</gml:lowerCorner>
        		<gml:upperCorner>758828.136237 462076.925151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>758828.136237 462076.925151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 013 287</ms:GML_ID>
        <ms:NAZWA>213 013 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213013287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>758523.282618 462088.174866</gml:lowerCorner>
        		<gml:upperCorner>758523.282618 462088.174866</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>758523.282618 462088.174866</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 012 981</ms:GML_ID>
        <ms:NAZWA>213 012 981</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213012981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>754419.455340 462099.939045</gml:lowerCorner>
        		<gml:upperCorner>754419.455340 462099.939045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>754419.455340 462099.939045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 008 787</ms:GML_ID>
        <ms:NAZWA>213 008 787</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213008787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757849.850000 462112.420000</gml:lowerCorner>
        		<gml:upperCorner>757849.850000 462112.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757849.850000 462112.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 012 306</ms:GML_ID>
        <ms:NAZWA>213 012 306</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213012306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757441.851000 462203.551000</gml:lowerCorner>
        		<gml:upperCorner>757441.851000 462203.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757441.851000 462203.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.213 011 886</ms:GML_ID>
        <ms:NAZWA>213 011 886</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>213011886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745012.946000 434848.971000</gml:lowerCorner>
        		<gml:upperCorner>745012.946000 434848.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745012.946000 434848.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 061 861</ms:GML_ID>
        <ms:NAZWA>202 061 861</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202061861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745066.350000 434490.024000</gml:lowerCorner>
        		<gml:upperCorner>745066.350000 434490.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745066.350000 434490.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 062 225</ms:GML_ID>
        <ms:NAZWA>202 062 225</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202062225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745204.750000 434093.763000</gml:lowerCorner>
        		<gml:upperCorner>745204.750000 434093.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745204.750000 434093.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 062 643</ms:GML_ID>
        <ms:NAZWA>202 062 643</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202062643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>747052.450090 426670.699211</gml:lowerCorner>
        		<gml:upperCorner>747052.450090 426670.699211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>747052.450090 426670.699211</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 070 497</ms:GML_ID>
        <ms:NAZWA>202 070 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202070497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>755271.819000 422216.429000</gml:lowerCorner>
        		<gml:upperCorner>755271.819000 422216.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>755271.819000 422216.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 052 427</ms:GML_ID>
        <ms:NAZWA>230 052 427</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230052427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757181.043000 423812.770000</gml:lowerCorner>
        		<gml:upperCorner>757181.043000 423812.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757181.043000 423812.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 049 659</ms:GML_ID>
        <ms:NAZWA>230 049 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230049659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>758888.519000 424289.028000</gml:lowerCorner>
        		<gml:upperCorner>758888.519000 424289.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>758888.519000 424289.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 047 768</ms:GML_ID>
        <ms:NAZWA>230 047 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230047768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760157.929897 424026.329079</gml:lowerCorner>
        		<gml:upperCorner>760157.929897 424026.329079</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760157.929897 424026.329079</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 046 475</ms:GML_ID>
        <ms:NAZWA>230 046 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230046475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763186.465000 423859.816000</gml:lowerCorner>
        		<gml:upperCorner>763186.465000 423859.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763186.465000 423859.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 043 305</ms:GML_ID>
        <ms:NAZWA>230 043 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230043305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763692.632000 424536.718000</gml:lowerCorner>
        		<gml:upperCorner>763692.632000 424536.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763692.632000 424536.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 042 456</ms:GML_ID>
        <ms:NAZWA>230 042 456</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230042456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764151.305000 425989.472000</gml:lowerCorner>
        		<gml:upperCorner>764151.305000 425989.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764151.305000 425989.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 040 863</ms:GML_ID>
        <ms:NAZWA>230 040 863</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230040863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764261.233000 426433.984000</gml:lowerCorner>
        		<gml:upperCorner>764261.233000 426433.984000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764261.233000 426433.984000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 040 407</ms:GML_ID>
        <ms:NAZWA>230 040 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230040407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764782.659000 428419.790000</gml:lowerCorner>
        		<gml:upperCorner>764782.659000 428419.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764782.659000 428419.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 038 205</ms:GML_ID>
        <ms:NAZWA>230 038 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230038205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764828.347000 436290.764000</gml:lowerCorner>
        		<gml:upperCorner>764828.347000 436290.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764828.347000 436290.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 027 194</ms:GML_ID>
        <ms:NAZWA>230 027 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230027194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>765054.623642 428682.676160</gml:lowerCorner>
        		<gml:upperCorner>765054.623642 428682.676160</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>765054.623642 428682.676160</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 037 816</ms:GML_ID>
        <ms:NAZWA>230 037 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230037816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766508.710000 434666.721000</gml:lowerCorner>
        		<gml:upperCorner>766508.710000 434666.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766508.710000 434666.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 029 627</ms:GML_ID>
        <ms:NAZWA>230 029 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230029627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767416.151000 430072.947000</gml:lowerCorner>
        		<gml:upperCorner>767416.151000 430072.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767416.151000 430072.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 034 876</ms:GML_ID>
        <ms:NAZWA>230 034 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230034876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767733.712000 432100.172000</gml:lowerCorner>
        		<gml:upperCorner>767733.712000 432100.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767733.712000 432100.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 032 550</ms:GML_ID>
        <ms:NAZWA>230 032 550</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230032550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>767941.643000 430917.882000</gml:lowerCorner>
        		<gml:upperCorner>767941.643000 430917.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>767941.643000 430917.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 033 815</ms:GML_ID>
        <ms:NAZWA>230 033 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230033815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>744746.277150 437506.072264</gml:lowerCorner>
        		<gml:upperCorner>744746.277150 437506.072264</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>744746.277150 437506.072264</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 059 185</ms:GML_ID>
        <ms:NAZWA>202 059 185</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202059185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745214.686728 442098.832065</gml:lowerCorner>
        		<gml:upperCorner>745214.686728 442098.832065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745214.686728 442098.832065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 054 524</ms:GML_ID>
        <ms:NAZWA>202 054 524</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202054524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6935">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748748.642000 445606.318000</gml:lowerCorner>
        		<gml:upperCorner>748748.642000 445606.318000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6935.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748748.642000 445606.318000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6935</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 049 295</ms:GML_ID>
        <ms:NAZWA>202 049 295</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202049295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749519.656267 445924.614372</gml:lowerCorner>
        		<gml:upperCorner>749519.656267 445924.614372</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749519.656267 445924.614372</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 048 457</ms:GML_ID>
        <ms:NAZWA>202 048 457</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202048457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752273.427000 445681.280000</gml:lowerCorner>
        		<gml:upperCorner>752273.427000 445681.280000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752273.427000 445681.280000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 005 748</ms:GML_ID>
        <ms:NAZWA>230 005 748</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230005748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752291.660000 444997.941000</gml:lowerCorner>
        		<gml:upperCorner>752291.660000 444997.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752291.660000 444997.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 006 433</ms:GML_ID>
        <ms:NAZWA>230 006 433</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230006433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752844.557000 444320.823000</gml:lowerCorner>
        		<gml:upperCorner>752844.557000 444320.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752844.557000 444320.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 007 311</ms:GML_ID>
        <ms:NAZWA>230 007 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230007311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>753381.603000 443829.840000</gml:lowerCorner>
        		<gml:upperCorner>753381.603000 443829.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>753381.603000 443829.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 008 045</ms:GML_ID>
        <ms:NAZWA>230 008 045</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230008045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>753986.843000 442905.008000</gml:lowerCorner>
        		<gml:upperCorner>753986.843000 442905.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>753986.843000 442905.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 009 183</ms:GML_ID>
        <ms:NAZWA>230 009 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230009183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>754121.503000 442590.496000</gml:lowerCorner>
        		<gml:upperCorner>754121.503000 442590.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>754121.503000 442590.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 009 526</ms:GML_ID>
        <ms:NAZWA>230 009 526</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230009526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>754734.870000 442027.908000</gml:lowerCorner>
        		<gml:upperCorner>754734.870000 442027.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>754734.870000 442027.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 010 407</ms:GML_ID>
        <ms:NAZWA>230 010 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230010407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>756429.215000 438730.696000</gml:lowerCorner>
        		<gml:upperCorner>756429.215000 438730.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>756429.215000 438730.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 015 748</ms:GML_ID>
        <ms:NAZWA>230 015 748</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230015748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>756452.970000 437787.406000</gml:lowerCorner>
        		<gml:upperCorner>756452.970000 437787.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>756452.970000 437787.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 016 697</ms:GML_ID>
        <ms:NAZWA>230 016 697</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230016697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>756529.273000 439991.561000</gml:lowerCorner>
        		<gml:upperCorner>756529.273000 439991.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>756529.273000 439991.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 014 429</ms:GML_ID>
        <ms:NAZWA>230 014 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230014429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>756901.616000 440974.651000</gml:lowerCorner>
        		<gml:upperCorner>756901.616000 440974.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>756901.616000 440974.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 013 376</ms:GML_ID>
        <ms:NAZWA>230 013 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230013376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757003.386000 441259.029000</gml:lowerCorner>
        		<gml:upperCorner>757003.386000 441259.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757003.386000 441259.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 013 072</ms:GML_ID>
        <ms:NAZWA>230 013 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230013072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757018.790000 441359.090000</gml:lowerCorner>
        		<gml:upperCorner>757018.790000 441359.090000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757018.790000 441359.090000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 012 972</ms:GML_ID>
        <ms:NAZWA>230 012 972</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230012972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757821.589000 437089.573000</gml:lowerCorner>
        		<gml:upperCorner>757821.589000 437089.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757821.589000 437089.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 018 318</ms:GML_ID>
        <ms:NAZWA>230 018 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230018318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759028.476000 438153.337000</gml:lowerCorner>
        		<gml:upperCorner>759028.476000 438153.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759028.476000 438153.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 020 214</ms:GML_ID>
        <ms:NAZWA>230 020 214</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230020214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761754.887000 437746.633000</gml:lowerCorner>
        		<gml:upperCorner>761754.887000 437746.633000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761754.887000 437746.633000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 023 368</ms:GML_ID>
        <ms:NAZWA>230 023 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230023368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>763282.497000 437799.560000</gml:lowerCorner>
        		<gml:upperCorner>763282.497000 437799.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>763282.497000 437799.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 024 914</ms:GML_ID>
        <ms:NAZWA>230 024 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230024914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745700.553245 363297.956536</gml:lowerCorner>
        		<gml:upperCorner>745700.553245 363297.956536</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745700.553245 363297.956536</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 189 171</ms:GML_ID>
        <ms:NAZWA>405 189 171</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405189171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>744638.037000 364555.081000</gml:lowerCorner>
        		<gml:upperCorner>744638.037000 364555.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>744638.037000 364555.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 187 453</ms:GML_ID>
        <ms:NAZWA>405 187 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405187453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766965.315000 406836.514000</gml:lowerCorner>
        		<gml:upperCorner>766965.315000 406836.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766965.315000 406836.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 133 767</ms:GML_ID>
        <ms:NAZWA>229 133 767</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229133767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766456.161000 407087.961000</gml:lowerCorner>
        		<gml:upperCorner>766456.161000 407087.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766456.161000 407087.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 133 198</ms:GML_ID>
        <ms:NAZWA>229 133 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229133198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>766187.573000 407221.180000</gml:lowerCorner>
        		<gml:upperCorner>766187.573000 407221.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>766187.573000 407221.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 132 897</ms:GML_ID>
        <ms:NAZWA>229 132 897</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229132897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>765996.785000 407265.695000</gml:lowerCorner>
        		<gml:upperCorner>765996.785000 407265.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>765996.785000 407265.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 132 700</ms:GML_ID>
        <ms:NAZWA>229 132 700</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229132700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>764552.349000 407373.848000</gml:lowerCorner>
        		<gml:upperCorner>764552.349000 407373.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>764552.349000 407373.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 131 248</ms:GML_ID>
        <ms:NAZWA>229 131 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229131248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>762118.331000 408793.568000</gml:lowerCorner>
        		<gml:upperCorner>762118.331000 408793.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>762118.331000 408793.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 128 306</ms:GML_ID>
        <ms:NAZWA>229 128 306</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229128306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>761548.853000 409802.738000</gml:lowerCorner>
        		<gml:upperCorner>761548.853000 409802.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>761548.853000 409802.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 127 160</ms:GML_ID>
        <ms:NAZWA>229 127 160</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229127160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>760707.137000 411932.516000</gml:lowerCorner>
        		<gml:upperCorner>760707.137000 411932.516000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>760707.137000 411932.516000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 124 845</ms:GML_ID>
        <ms:NAZWA>229 124 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229124845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>759164.924000 413429.946000</gml:lowerCorner>
        		<gml:upperCorner>759164.924000 413429.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>759164.924000 413429.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 122 611</ms:GML_ID>
        <ms:NAZWA>229 122 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229122611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>757774.190000 414138.971000</gml:lowerCorner>
        		<gml:upperCorner>757774.190000 414138.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>757774.190000 414138.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 120 783</ms:GML_ID>
        <ms:NAZWA>229 120 783</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229120783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>754780.746000 414584.122000</gml:lowerCorner>
        		<gml:upperCorner>754780.746000 414584.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>754780.746000 414584.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 117 607</ms:GML_ID>
        <ms:NAZWA>229 117 607</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229117607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>754179.680000 415034.291000</gml:lowerCorner>
        		<gml:upperCorner>754179.680000 415034.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>754179.680000 415034.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 116 855</ms:GML_ID>
        <ms:NAZWA>229 116 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229116855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748229.871000 416226.704000</gml:lowerCorner>
        		<gml:upperCorner>748229.871000 416226.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748229.871000 416226.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 109 597</ms:GML_ID>
        <ms:NAZWA>229 109 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229109597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748469.268000 416342.839000</gml:lowerCorner>
        		<gml:upperCorner>748469.268000 416342.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748469.268000 416342.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 109 873</ms:GML_ID>
        <ms:NAZWA>229 109 873</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229109873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752578.221000 416606.677000</gml:lowerCorner>
        		<gml:upperCorner>752578.221000 416606.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752578.221000 416606.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 114 587</ms:GML_ID>
        <ms:NAZWA>229 114 587</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229114587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>751600.656000 417008.459000</gml:lowerCorner>
        		<gml:upperCorner>751600.656000 417008.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>751600.656000 417008.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 113 488</ms:GML_ID>
        <ms:NAZWA>229 113 488</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229113488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749257.598000 417098.757000</gml:lowerCorner>
        		<gml:upperCorner>749257.598000 417098.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749257.598000 417098.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 111 049</ms:GML_ID>
        <ms:NAZWA>229 111 049</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229111049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745181.878000 417251.437000</gml:lowerCorner>
        		<gml:upperCorner>745181.878000 417251.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745181.878000 417251.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 106 150</ms:GML_ID>
        <ms:NAZWA>229 106 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229106150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745708.902000 417272.385000</gml:lowerCorner>
        		<gml:upperCorner>745708.902000 417272.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745708.902000 417272.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 106 685</ms:GML_ID>
        <ms:NAZWA>229 106 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229106685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749863.853000 417281.291000</gml:lowerCorner>
        		<gml:upperCorner>749863.853000 417281.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749863.853000 417281.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 061 303</ms:GML_ID>
        <ms:NAZWA>230 061 303</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230061303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750259.707000 417292.836000</gml:lowerCorner>
        		<gml:upperCorner>750259.707000 417292.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750259.707000 417292.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 112 080</ms:GML_ID>
        <ms:NAZWA>229 112 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229112080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750554.275000 417320.718000</gml:lowerCorner>
        		<gml:upperCorner>750554.275000 417320.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750554.275000 417320.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 112 378</ms:GML_ID>
        <ms:NAZWA>229 112 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229112378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>744724.948831 417331.786489</gml:lowerCorner>
        		<gml:upperCorner>744724.948831 417331.786489</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>744724.948831 417331.786489</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 105 686</ms:GML_ID>
        <ms:NAZWA>229 105 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229105686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>744335.990616 417445.339105</gml:lowerCorner>
        		<gml:upperCorner>744335.990616 417445.339105</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>744335.990616 417445.339105</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 105 276</ms:GML_ID>
        <ms:NAZWA>229 105 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229105276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>744140.077598 417601.203471</gml:lowerCorner>
        		<gml:upperCorner>744140.077598 417601.203471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>744140.077598 417601.203471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 105 024</ms:GML_ID>
        <ms:NAZWA>229 105 024</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229105024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750349.605000 417991.234000</gml:lowerCorner>
        		<gml:upperCorner>750349.605000 417991.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750349.605000 417991.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 060 377</ms:GML_ID>
        <ms:NAZWA>230 060 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230060377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750381.685000 418664.704000</gml:lowerCorner>
        		<gml:upperCorner>750381.685000 418664.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750381.685000 418664.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 059 687</ms:GML_ID>
        <ms:NAZWA>230 059 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230059687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750303.153000 419549.430000</gml:lowerCorner>
        		<gml:upperCorner>750303.153000 419549.430000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750303.153000 419549.430000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 058 786</ms:GML_ID>
        <ms:NAZWA>230 058 786</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230058786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>750765.874000 420588.539000</gml:lowerCorner>
        		<gml:upperCorner>750765.874000 420588.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>750765.874000 420588.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 057 627</ms:GML_ID>
        <ms:NAZWA>230 057 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230057627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>752945.089000 421549.407000</gml:lowerCorner>
        		<gml:upperCorner>752945.089000 421549.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>752945.089000 421549.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 055 187</ms:GML_ID>
        <ms:NAZWA>230 055 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230055187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>753840.426000 421757.625000</gml:lowerCorner>
        		<gml:upperCorner>753840.426000 421757.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>753840.426000 421757.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.230 054 263</ms:GML_ID>
        <ms:NAZWA>230 054 263</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>230054263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721931.809000 428311.153000</gml:lowerCorner>
        		<gml:upperCorner>721931.809000 428311.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721931.809000 428311.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 067 237</ms:GML_ID>
        <ms:NAZWA>229 067 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229067237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724788.140000 428262.196000</gml:lowerCorner>
        		<gml:upperCorner>724788.140000 428262.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724788.140000 428262.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 070 510</ms:GML_ID>
        <ms:NAZWA>229 070 510</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229070510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725931.967469 428021.950188</gml:lowerCorner>
        		<gml:upperCorner>725931.967469 428021.950188</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725931.967469 428021.950188</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 071 685</ms:GML_ID>
        <ms:NAZWA>229 071 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229071685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>726757.978000 427930.468000</gml:lowerCorner>
        		<gml:upperCorner>726757.978000 427930.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>726757.978000 427930.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 072 516</ms:GML_ID>
        <ms:NAZWA>229 072 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229072516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>727413.744000 427796.491000</gml:lowerCorner>
        		<gml:upperCorner>727413.744000 427796.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>727413.744000 427796.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 073 191</ms:GML_ID>
        <ms:NAZWA>229 073 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229073191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728444.507000 427509.582000</gml:lowerCorner>
        		<gml:upperCorner>728444.507000 427509.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728444.507000 427509.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 074 300</ms:GML_ID>
        <ms:NAZWA>229 074 300</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229074300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729183.477000 427488.965000</gml:lowerCorner>
        		<gml:upperCorner>729183.477000 427488.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729183.477000 427488.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 075 041</ms:GML_ID>
        <ms:NAZWA>229 075 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229075041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729684.950000 427360.826000</gml:lowerCorner>
        		<gml:upperCorner>729684.950000 427360.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729684.950000 427360.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 075 561</ms:GML_ID>
        <ms:NAZWA>229 075 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229075561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730349.447000 427289.263000</gml:lowerCorner>
        		<gml:upperCorner>730349.447000 427289.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730349.447000 427289.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 076 256</ms:GML_ID>
        <ms:NAZWA>229 076 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229076256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730806.502000 427341.317000</gml:lowerCorner>
        		<gml:upperCorner>730806.502000 427341.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730806.502000 427341.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 076 714</ms:GML_ID>
        <ms:NAZWA>229 076 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229076714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731262.610000 427392.983000</gml:lowerCorner>
        		<gml:upperCorner>731262.610000 427392.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731262.610000 427392.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 077 175</ms:GML_ID>
        <ms:NAZWA>229 077 175</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229077175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731639.838000 427625.196000</gml:lowerCorner>
        		<gml:upperCorner>731639.838000 427625.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731639.838000 427625.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 077 629</ms:GML_ID>
        <ms:NAZWA>229 077 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229077629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731801.121000 427989.207000</gml:lowerCorner>
        		<gml:upperCorner>731801.121000 427989.207000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731801.121000 427989.207000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 078 029</ms:GML_ID>
        <ms:NAZWA>229 078 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229078029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741250.073000 423003.213000</gml:lowerCorner>
        		<gml:upperCorner>741250.073000 423003.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741250.073000 423003.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 097 031</ms:GML_ID>
        <ms:NAZWA>229 097 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229097031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741315.919000 421719.724000</gml:lowerCorner>
        		<gml:upperCorner>741315.919000 421719.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741315.919000 421719.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 098 364</ms:GML_ID>
        <ms:NAZWA>229 098 364</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229098364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741514.458000 426169.898000</gml:lowerCorner>
        		<gml:upperCorner>741514.458000 426169.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741514.458000 426169.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 092 718</ms:GML_ID>
        <ms:NAZWA>229 092 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229092718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741937.054000 425801.990000</gml:lowerCorner>
        		<gml:upperCorner>741937.054000 425801.990000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741937.054000 425801.990000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 093 296</ms:GML_ID>
        <ms:NAZWA>229 093 296</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229093296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742281.164000 424348.217000</gml:lowerCorner>
        		<gml:upperCorner>742281.164000 424348.217000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742281.164000 424348.217000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 095 276</ms:GML_ID>
        <ms:NAZWA>229 095 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229095276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743163.527000 421492.945000</gml:lowerCorner>
        		<gml:upperCorner>743163.527000 421492.945000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743163.527000 421492.945000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 077 061</ms:GML_ID>
        <ms:NAZWA>202 077 061</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202077061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743684.372566 422037.895966</gml:lowerCorner>
        		<gml:upperCorner>743684.372566 422037.895966</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743684.372566 422037.895966</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 076 309</ms:GML_ID>
        <ms:NAZWA>202 076 309</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202076309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731969.130000 428445.792000</gml:lowerCorner>
        		<gml:upperCorner>731969.130000 428445.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731969.130000 428445.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 078 516</ms:GML_ID>
        <ms:NAZWA>229 078 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229078516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722220.166000 428529.748000</gml:lowerCorner>
        		<gml:upperCorner>722220.166000 428529.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722220.166000 428529.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 067 599</ms:GML_ID>
        <ms:NAZWA>229 067 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229067599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732133.724000 428855.421000</gml:lowerCorner>
        		<gml:upperCorner>732133.724000 428855.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732133.724000 428855.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 078 958</ms:GML_ID>
        <ms:NAZWA>229 078 958</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229078958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>740728.085000 429120.594000</gml:lowerCorner>
        		<gml:upperCorner>740728.085000 429120.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>740728.085000 429120.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 089 500</ms:GML_ID>
        <ms:NAZWA>229 089 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229089500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732398.054000 429165.330000</gml:lowerCorner>
        		<gml:upperCorner>732398.054000 429165.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732398.054000 429165.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 079 369</ms:GML_ID>
        <ms:NAZWA>229 079 369</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229079369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732858.636000 429448.014000</gml:lowerCorner>
        		<gml:upperCorner>732858.636000 429448.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732858.636000 429448.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 079 914</ms:GML_ID>
        <ms:NAZWA>229 079 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229079914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>733925.191000 429602.680000</gml:lowerCorner>
        		<gml:upperCorner>733925.191000 429602.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>733925.191000 429602.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 080 997</ms:GML_ID>
        <ms:NAZWA>229 080 997</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229080997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>734639.390000 429697.637000</gml:lowerCorner>
        		<gml:upperCorner>734639.390000 429697.637000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>734639.390000 429697.637000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 081 719</ms:GML_ID>
        <ms:NAZWA>229 081 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229081719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

