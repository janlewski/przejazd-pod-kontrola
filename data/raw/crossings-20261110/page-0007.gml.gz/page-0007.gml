<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:26" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=6000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=8000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>553766.119521 357671.057000</gml:lowerCorner>
      		<gml:upperCorner>749100.828000 506031.259000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>736044.233000 430325.092000</gml:lowerCorner>
        		<gml:upperCorner>736044.233000 430325.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>736044.233000 430325.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 083 320</ms:GML_ID>
        <ms:NAZWA>229 083 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229083320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>739158.851000 430542.333000</gml:lowerCorner>
        		<gml:upperCorner>739158.851000 430542.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>739158.851000 430542.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 087 189</ms:GML_ID>
        <ms:NAZWA>229 087 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229087189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>738488.546000 431180.735000</gml:lowerCorner>
        		<gml:upperCorner>738488.546000 431180.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>738488.546000 431180.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 086 258</ms:GML_ID>
        <ms:NAZWA>229 086 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229086258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>737069.105000 431300.638000</gml:lowerCorner>
        		<gml:upperCorner>737069.105000 431300.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>737069.105000 431300.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 084 785</ms:GML_ID>
        <ms:NAZWA>229 084 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229084785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>738155.220000 431316.148000</gml:lowerCorner>
        		<gml:upperCorner>738155.220000 431316.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>738155.220000 431316.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 085 897</ms:GML_ID>
        <ms:NAZWA>229 085 897</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229085897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721869.171000 444298.078000</gml:lowerCorner>
        		<gml:upperCorner>721869.171000 444298.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721869.171000 444298.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 048 624</ms:GML_ID>
        <ms:NAZWA>229 048 624</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229048624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721927.839000 444603.049000</gml:lowerCorner>
        		<gml:upperCorner>721927.839000 444603.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721927.839000 444603.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 048 310</ms:GML_ID>
        <ms:NAZWA>229 048 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229048310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721933.841000 444824.726000</gml:lowerCorner>
        		<gml:upperCorner>721933.841000 444824.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721933.841000 444824.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 048 087</ms:GML_ID>
        <ms:NAZWA>229 048 087</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229048087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722168.691000 445280.259000</gml:lowerCorner>
        		<gml:upperCorner>722168.691000 445280.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722168.691000 445280.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 047 565</ms:GML_ID>
        <ms:NAZWA>229 047 565</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229047565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722516.543000 445659.073000</gml:lowerCorner>
        		<gml:upperCorner>722516.543000 445659.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722516.543000 445659.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 047 033</ms:GML_ID>
        <ms:NAZWA>229 047 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229047033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722504.754000 446211.640000</gml:lowerCorner>
        		<gml:upperCorner>722504.754000 446211.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722504.754000 446211.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 046 476</ms:GML_ID>
        <ms:NAZWA>229 046 476</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229046476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722219.013000 447046.418000</gml:lowerCorner>
        		<gml:upperCorner>722219.013000 447046.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722219.013000 447046.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 045 586</ms:GML_ID>
        <ms:NAZWA>229 045 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229045586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719720.952727 433464.426980</gml:lowerCorner>
        		<gml:upperCorner>719720.952727 433464.426980</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719720.952727 433464.426980</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 060 614</ms:GML_ID>
        <ms:NAZWA>229 060 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229060614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719794.057000 434364.907000</gml:lowerCorner>
        		<gml:upperCorner>719794.057000 434364.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719794.057000 434364.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 059 704</ms:GML_ID>
        <ms:NAZWA>229 059 704</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229059704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719800.639000 434934.071000</gml:lowerCorner>
        		<gml:upperCorner>719800.639000 434934.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719800.639000 434934.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 059 147</ms:GML_ID>
        <ms:NAZWA>229 059 147</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229059147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719913.718000 435475.839000</gml:lowerCorner>
        		<gml:upperCorner>719913.718000 435475.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719913.718000 435475.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 058 578</ms:GML_ID>
        <ms:NAZWA>229 058 578</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229058578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719936.285000 429690.653000</gml:lowerCorner>
        		<gml:upperCorner>719936.285000 429690.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719936.285000 429690.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 064 502</ms:GML_ID>
        <ms:NAZWA>229 064 502</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229064502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719944.249000 435931.038000</gml:lowerCorner>
        		<gml:upperCorner>719944.249000 435931.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719944.249000 435931.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 058 118</ms:GML_ID>
        <ms:NAZWA>229 058 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229058118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720060.092000 439023.322000</gml:lowerCorner>
        		<gml:upperCorner>720060.092000 439023.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720060.092000 439023.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 054 896</ms:GML_ID>
        <ms:NAZWA>229 054 896</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229054896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720081.832000 436133.186000</gml:lowerCorner>
        		<gml:upperCorner>720081.832000 436133.186000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720081.832000 436133.186000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 057 874</ms:GML_ID>
        <ms:NAZWA>229 057 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229057874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720130.838000 438553.579000</gml:lowerCorner>
        		<gml:upperCorner>720130.838000 438553.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720130.838000 438553.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 055 373</ms:GML_ID>
        <ms:NAZWA>229 055 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229055373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720188.344000 436729.445000</gml:lowerCorner>
        		<gml:upperCorner>720188.344000 436729.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720188.344000 436729.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 057 240</ms:GML_ID>
        <ms:NAZWA>229 057 240</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229057240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720206.959000 437982.044000</gml:lowerCorner>
        		<gml:upperCorner>720206.959000 437982.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720206.959000 437982.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 055 967</ms:GML_ID>
        <ms:NAZWA>229 055 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229055967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720208.433000 439580.471000</gml:lowerCorner>
        		<gml:upperCorner>720208.433000 439580.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720208.433000 439580.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 054 298</ms:GML_ID>
        <ms:NAZWA>229 054 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229054298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720607.523000 441718.433000</gml:lowerCorner>
        		<gml:upperCorner>720607.523000 441718.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720607.523000 441718.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 051 900</ms:GML_ID>
        <ms:NAZWA>229 051 900</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229051900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720631.340000 441466.878000</gml:lowerCorner>
        		<gml:upperCorner>720631.340000 441466.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720631.340000 441466.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 052 187</ms:GML_ID>
        <ms:NAZWA>229 052 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229052187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720637.709623 428605.636957</gml:lowerCorner>
        		<gml:upperCorner>720637.709623 428605.636957</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720637.709623 428605.636957</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 065 851</ms:GML_ID>
        <ms:NAZWA>229 065 851</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229065851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720656.065000 439988.729000</gml:lowerCorner>
        		<gml:upperCorner>720656.065000 439988.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720656.065000 439988.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 053 685</ms:GML_ID>
        <ms:NAZWA>229 053 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229053685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720715.548000 443539.988000</gml:lowerCorner>
        		<gml:upperCorner>720715.548000 443539.988000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720715.548000 443539.988000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 050 033</ms:GML_ID>
        <ms:NAZWA>229 050 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229050033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720861.810434 428507.310815</gml:lowerCorner>
        		<gml:upperCorner>720861.810434 428507.310815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720861.810434 428507.310815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 066 096</ms:GML_ID>
        <ms:NAZWA>229 066 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229066096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721386.213000 428277.956000</gml:lowerCorner>
        		<gml:upperCorner>721386.213000 428277.956000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721386.213000 428277.956000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 066 670</ms:GML_ID>
        <ms:NAZWA>229 066 670</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229066670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719623.075265 479599.680936</gml:lowerCorner>
        		<gml:upperCorner>719623.075265 479599.680936</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719623.075265 479599.680936</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 010 605</ms:GML_ID>
        <ms:NAZWA>226 010 605</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226010605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720082.794425 479932.725218</gml:lowerCorner>
        		<gml:upperCorner>720082.794425 479932.725218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720082.794425 479932.725218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 011 176</ms:GML_ID>
        <ms:NAZWA>226 011 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226011176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>722398.013017 478752.491662</gml:lowerCorner>
        		<gml:upperCorner>722398.013017 478752.491662</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>722398.013017 478752.491662</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.965 001 458</ms:GML_ID>
        <ms:NAZWA>965 001 458</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>965001458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723690.508912 478498.174714</gml:lowerCorner>
        		<gml:upperCorner>723690.508912 478498.174714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723690.508912 478498.174714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.965 002 771</ms:GML_ID>
        <ms:NAZWA>965 002 771</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>965002771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723778.032820 478560.098077</gml:lowerCorner>
        		<gml:upperCorner>723778.032820 478560.098077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723778.032820 478560.098077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.965 002 852</ms:GML_ID>
        <ms:NAZWA>965 002 852</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>965002852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723979.452115 478661.203656</gml:lowerCorner>
        		<gml:upperCorner>723979.452115 478661.203656</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723979.452115 478661.203656</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.965 003 087</ms:GML_ID>
        <ms:NAZWA>965 003 087</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>965003087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724043.950895 478732.345978</gml:lowerCorner>
        		<gml:upperCorner>724043.950895 478732.345978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724043.950895 478732.345978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.965 003 184</ms:GML_ID>
        <ms:NAZWA>965 003 184</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>965003184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724104.211536 475792.711045</gml:lowerCorner>
        		<gml:upperCorner>724104.211536 475792.711045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724104.211536 475792.711045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.227 003 109</ms:GML_ID>
        <ms:NAZWA>227 003 109</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>227003109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724463.649654 477306.773689</gml:lowerCorner>
        		<gml:upperCorner>724463.649654 477306.773689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724463.649654 477306.773689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.722 001 830</ms:GML_ID>
        <ms:NAZWA>722 001 830</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>722001830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>724887.349926 479005.708904</gml:lowerCorner>
        		<gml:upperCorner>724887.349926 479005.708904</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>724887.349926 479005.708904</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 000 988</ms:GML_ID>
        <ms:NAZWA>226 000 988</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226000988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725679.570867 479591.665825</gml:lowerCorner>
        		<gml:upperCorner>725679.570867 479591.665825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725679.570867 479591.665825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 001 999</ms:GML_ID>
        <ms:NAZWA>226 001 999</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226001999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>726551.411778 479446.281861</gml:lowerCorner>
        		<gml:upperCorner>726551.411778 479446.281861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>726551.411778 479446.281861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 002 893</ms:GML_ID>
        <ms:NAZWA>226 002 893</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226002893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741023.604877 467915.709070</gml:lowerCorner>
        		<gml:upperCorner>741023.604877 467915.709070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741023.604877 467915.709070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 206 790</ms:GML_ID>
        <ms:NAZWA>201 206 790</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201206790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742089.093316 466772.793724</gml:lowerCorner>
        		<gml:upperCorner>742089.093316 466772.793724</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742089.093316 466772.793724</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.961 000 515</ms:GML_ID>
        <ms:NAZWA>961 000 515</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>961000515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742112.014410 466945.797257</gml:lowerCorner>
        		<gml:upperCorner>742112.014410 466945.797257</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742112.014410 466945.797257</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.961 000 343</ms:GML_ID>
        <ms:NAZWA>961 000 343</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>961000343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742153.801289 469940.217444</gml:lowerCorner>
        		<gml:upperCorner>742153.801289 469940.217444</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742153.801289 469940.217444</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.228 010 738</ms:GML_ID>
        <ms:NAZWA>228 010 738</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>228010738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742171.632401 470645.123285</gml:lowerCorner>
        		<gml:upperCorner>742171.632401 470645.123285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742171.632401 470645.123285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.228 011 442</ms:GML_ID>
        <ms:NAZWA>228 011 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>228011442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742543.429000 469028.192000</gml:lowerCorner>
        		<gml:upperCorner>742543.429000 469028.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742543.429000 469028.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.228 009 862</ms:GML_ID>
        <ms:NAZWA>228 009 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>228009862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718729.349051 459407.950491</gml:lowerCorner>
        		<gml:upperCorner>718729.349051 459407.950491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718729.349051 459407.950491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 027 599</ms:GML_ID>
        <ms:NAZWA>229 027 599</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229027599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718758.017000 458811.191000</gml:lowerCorner>
        		<gml:upperCorner>718758.017000 458811.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718758.017000 458811.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 028 223</ms:GML_ID>
        <ms:NAZWA>229 028 223</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229028223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718768.036000 458363.643000</gml:lowerCorner>
        		<gml:upperCorner>718768.036000 458363.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718768.036000 458363.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 028 697</ms:GML_ID>
        <ms:NAZWA>229 028 697</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229028697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718768.914000 448287.918000</gml:lowerCorner>
        		<gml:upperCorner>718768.914000 448287.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718768.914000 448287.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 040 952</ms:GML_ID>
        <ms:NAZWA>229 040 952</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229040952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718777.361143 448258.417551</gml:lowerCorner>
        		<gml:upperCorner>718777.361143 448258.417551</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718777.361143 448258.417551</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.214 007 141</ms:GML_ID>
        <ms:NAZWA>214 007 141</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>214007141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718826.812583 457533.313099</gml:lowerCorner>
        		<gml:upperCorner>718826.812583 457533.313099</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718826.812583 457533.313099</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 029 804</ms:GML_ID>
        <ms:NAZWA>229 029 804</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229029804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719108.887000 457885.362000</gml:lowerCorner>
        		<gml:upperCorner>719108.887000 457885.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719108.887000 457885.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 029 338</ms:GML_ID>
        <ms:NAZWA>229 029 338</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229029338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>720993.696000 448807.722000</gml:lowerCorner>
        		<gml:upperCorner>720993.696000 448807.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>720993.696000 448807.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 043 328</ms:GML_ID>
        <ms:NAZWA>229 043 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229043328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721344.272000 448324.305000</gml:lowerCorner>
        		<gml:upperCorner>721344.272000 448324.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721344.272000 448324.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 043 926</ms:GML_ID>
        <ms:NAZWA>229 043 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229043926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721513.945000 448143.608000</gml:lowerCorner>
        		<gml:upperCorner>721513.945000 448143.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721513.945000 448143.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 044 176</ms:GML_ID>
        <ms:NAZWA>229 044 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229044176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721813.482000 448030.475000</gml:lowerCorner>
        		<gml:upperCorner>721813.482000 448030.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721813.482000 448030.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 044 498</ms:GML_ID>
        <ms:NAZWA>229 044 498</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229044498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728089.073000 464168.770000</gml:lowerCorner>
        		<gml:upperCorner>728089.073000 464168.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728089.073000 464168.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.235 008 523</ms:GML_ID>
        <ms:NAZWA>235 008 523</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>235008523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6916">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>728390.760228 464246.672630</gml:lowerCorner>
        		<gml:upperCorner>728390.760228 464246.672630</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6916.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>728390.760228 464246.672630</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6916</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 188 163</ms:GML_ID>
        <ms:NAZWA>201 188 163</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201188163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742387.319835 465662.402011</gml:lowerCorner>
        		<gml:upperCorner>742387.319835 465662.402011</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742387.319835 465662.402011</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 025 699</ms:GML_ID>
        <ms:NAZWA>202 025 699</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202025699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742746.503050 464951.647369</gml:lowerCorner>
        		<gml:upperCorner>742746.503050 464951.647369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742746.503050 464951.647369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 026 487</ms:GML_ID>
        <ms:NAZWA>202 026 487</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202026487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742964.305454 464462.011116</gml:lowerCorner>
        		<gml:upperCorner>742964.305454 464462.011116</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742964.305454 464462.011116</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 027 050</ms:GML_ID>
        <ms:NAZWA>202 027 050</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202027050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743169.538842 464504.507941</gml:lowerCorner>
        		<gml:upperCorner>743169.538842 464504.507941</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743169.538842 464504.507941</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.723 000 984</ms:GML_ID>
        <ms:NAZWA>723 000 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>723000984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743521.842886 465383.229438</gml:lowerCorner>
        		<gml:upperCorner>743521.842886 465383.229438</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743521.842886 465383.229438</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 210 388</ms:GML_ID>
        <ms:NAZWA>201 210 388</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201210388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743545.181200 465344.930296</gml:lowerCorner>
        		<gml:upperCorner>743545.181200 465344.930296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743545.181200 465344.930296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 210 429</ms:GML_ID>
        <ms:NAZWA>201 210 429</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201210429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743620.978993 466078.898269</gml:lowerCorner>
        		<gml:upperCorner>743620.978993 466078.898269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743620.978993 466078.898269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.228 006 520</ms:GML_ID>
        <ms:NAZWA>228 006 520</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>228006520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>745936.562148 459527.915064</gml:lowerCorner>
        		<gml:upperCorner>745936.562148 459527.915064</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>745936.562148 459527.915064</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 032 956</ms:GML_ID>
        <ms:NAZWA>202 032 956</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202032956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6924">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>746781.785000 458761.100000</gml:lowerCorner>
        		<gml:upperCorner>746781.785000 458761.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6924.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>746781.785000 458761.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6924</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 034 110</ms:GML_ID>
        <ms:NAZWA>202 034 110</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202034110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6925">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748929.006000 453111.129000</gml:lowerCorner>
        		<gml:upperCorner>748929.006000 453111.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6925.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748929.006000 453111.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6925</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 041 067</ms:GML_ID>
        <ms:NAZWA>202 041 067</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202041067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6926">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>748995.632359 452170.052286</gml:lowerCorner>
        		<gml:upperCorner>748995.632359 452170.052286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6926.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>748995.632359 452170.052286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6926</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 042 019</ms:GML_ID>
        <ms:NAZWA>202 042 019</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202042019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6927">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749007.421186 452111.027495</gml:lowerCorner>
        		<gml:upperCorner>749007.421186 452111.027495</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6927.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749007.421186 452111.027495</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6927</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 042 054</ms:GML_ID>
        <ms:NAZWA>202 042 054</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202042054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6928">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>749100.828000 451650.712000</gml:lowerCorner>
        		<gml:upperCorner>749100.828000 451650.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6928.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>749100.828000 451650.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6928</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 042 550</ms:GML_ID>
        <ms:NAZWA>202 042 550</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>202042550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711214.570000 362549.443000</gml:lowerCorner>
        		<gml:upperCorner>711214.570000 362549.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711214.570000 362549.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 146 826</ms:GML_ID>
        <ms:NAZWA>405 146 826</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405146826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715420.858000 367164.508000</gml:lowerCorner>
        		<gml:upperCorner>715420.858000 367164.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715420.858000 367164.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 064 837</ms:GML_ID>
        <ms:NAZWA>212 064 837</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212064837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715885.027000 366750.891000</gml:lowerCorner>
        		<gml:upperCorner>715885.027000 366750.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715885.027000 366750.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 065 476</ms:GML_ID>
        <ms:NAZWA>212 065 476</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212065476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716411.523829 366667.116024</gml:lowerCorner>
        		<gml:upperCorner>716411.523829 366667.116024</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716411.523829 366667.116024</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 066 009</ms:GML_ID>
        <ms:NAZWA>212 066 009</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212066009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717102.682000 366002.586000</gml:lowerCorner>
        		<gml:upperCorner>717102.682000 366002.586000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717102.682000 366002.586000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 067 054</ms:GML_ID>
        <ms:NAZWA>212 067 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212067054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717192.076000 362577.999000</gml:lowerCorner>
        		<gml:upperCorner>717192.076000 362577.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717192.076000 362577.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 070 539</ms:GML_ID>
        <ms:NAZWA>212 070 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212070539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717251.098000 363621.359000</gml:lowerCorner>
        		<gml:upperCorner>717251.098000 363621.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717251.098000 363621.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 069 492</ms:GML_ID>
        <ms:NAZWA>212 069 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212069492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717298.301000 365449.367000</gml:lowerCorner>
        		<gml:upperCorner>717298.301000 365449.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717298.301000 365449.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 067 642</ms:GML_ID>
        <ms:NAZWA>212 067 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212067642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717330.723000 364148.841000</gml:lowerCorner>
        		<gml:upperCorner>717330.723000 364148.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717330.723000 364148.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 068 956</ms:GML_ID>
        <ms:NAZWA>212 068 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212068956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721335.572000 364032.877000</gml:lowerCorner>
        		<gml:upperCorner>721335.572000 364032.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721335.572000 364032.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 157 993</ms:GML_ID>
        <ms:NAZWA>405 157 993</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405157993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>721860.020000 364630.254000</gml:lowerCorner>
        		<gml:upperCorner>721860.020000 364630.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>721860.020000 364630.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 158 836</ms:GML_ID>
        <ms:NAZWA>405 158 836</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405158836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>723651.304000 364651.973000</gml:lowerCorner>
        		<gml:upperCorner>723651.304000 364651.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>723651.304000 364651.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 160 630</ms:GML_ID>
        <ms:NAZWA>405 160 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405160630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725140.039000 364866.608000</gml:lowerCorner>
        		<gml:upperCorner>725140.039000 364866.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725140.039000 364866.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 162 151</ms:GML_ID>
        <ms:NAZWA>405 162 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405162151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>725976.240000 365186.131000</gml:lowerCorner>
        		<gml:upperCorner>725976.240000 365186.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>725976.240000 365186.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 163 049</ms:GML_ID>
        <ms:NAZWA>405 163 049</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405163049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>726742.633000 365626.139000</gml:lowerCorner>
        		<gml:upperCorner>726742.633000 365626.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>726742.633000 365626.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 163 935</ms:GML_ID>
        <ms:NAZWA>405 163 935</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405163935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>727718.566000 366210.444000</gml:lowerCorner>
        		<gml:upperCorner>727718.566000 366210.444000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>727718.566000 366210.444000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 165 080</ms:GML_ID>
        <ms:NAZWA>405 165 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405165080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>729818.657000 367091.531000</gml:lowerCorner>
        		<gml:upperCorner>729818.657000 367091.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>729818.657000 367091.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 167 359</ms:GML_ID>
        <ms:NAZWA>405 167 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405167359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730341.261000 362553.037000</gml:lowerCorner>
        		<gml:upperCorner>730341.261000 362553.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730341.261000 362553.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 142 282</ms:GML_ID>
        <ms:NAZWA>202 142 282</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202142282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>730724.282000 367502.789000</gml:lowerCorner>
        		<gml:upperCorner>730724.282000 367502.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>730724.282000 367502.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 168 354</ms:GML_ID>
        <ms:NAZWA>405 168 354</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405168354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731276.701000 367824.066000</gml:lowerCorner>
        		<gml:upperCorner>731276.701000 367824.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731276.701000 367824.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 169 005</ms:GML_ID>
        <ms:NAZWA>405 169 005</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405169005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732386.491000 367527.427000</gml:lowerCorner>
        		<gml:upperCorner>732386.491000 367527.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732386.491000 367527.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 136 854</ms:GML_ID>
        <ms:NAZWA>202 136 854</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202136854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>740963.812000 367780.553000</gml:lowerCorner>
        		<gml:upperCorner>740963.812000 367780.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>740963.812000 367780.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 182 316</ms:GML_ID>
        <ms:NAZWA>405 182 316</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405182316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741242.688000 367344.563000</gml:lowerCorner>
        		<gml:upperCorner>741242.688000 367344.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741242.688000 367344.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 182 833</ms:GML_ID>
        <ms:NAZWA>405 182 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405182833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742293.704000 366228.254000</gml:lowerCorner>
        		<gml:upperCorner>742293.704000 366228.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742293.704000 366228.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 184 377</ms:GML_ID>
        <ms:NAZWA>405 184 377</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405184377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742768.068000 365624.115000</gml:lowerCorner>
        		<gml:upperCorner>742768.068000 365624.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742768.068000 365624.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 185 146</ms:GML_ID>
        <ms:NAZWA>405 185 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405185146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743156.675000 365100.218000</gml:lowerCorner>
        		<gml:upperCorner>743156.675000 365100.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743156.675000 365100.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 185 799</ms:GML_ID>
        <ms:NAZWA>405 185 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405185799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743598.703000 364709.634000</gml:lowerCorner>
        		<gml:upperCorner>743598.703000 364709.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743598.703000 364709.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 186 397</ms:GML_ID>
        <ms:NAZWA>405 186 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405186397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6909">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710601.272000 446310.023000</gml:lowerCorner>
        		<gml:upperCorner>710601.272000 446310.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6909.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710601.272000 446310.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6909</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 160 840</ms:GML_ID>
        <ms:NAZWA>201 160 840</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201160840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6910">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710867.751000 446600.657000</gml:lowerCorner>
        		<gml:upperCorner>710867.751000 446600.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6910.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710867.751000 446600.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6910</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 161 246</ms:GML_ID>
        <ms:NAZWA>201 161 246</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201161246</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6911">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711251.725000 447158.320000</gml:lowerCorner>
        		<gml:upperCorner>711251.725000 447158.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6911.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711251.725000 447158.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6911</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 161 926</ms:GML_ID>
        <ms:NAZWA>201 161 926</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201161926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6912">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712410.298212 447538.989126</gml:lowerCorner>
        		<gml:upperCorner>712410.298212 447538.989126</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6912.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712410.298212 447538.989126</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6912</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 163 086</ms:GML_ID>
        <ms:NAZWA>201 163 086</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201163086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713235.361000 447602.624000</gml:lowerCorner>
        		<gml:upperCorner>713235.361000 447602.624000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713235.361000 447602.624000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.214 001 219</ms:GML_ID>
        <ms:NAZWA>214 001 219</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>214001219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715361.890000 447959.389000</gml:lowerCorner>
        		<gml:upperCorner>715361.890000 447959.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715361.890000 447959.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.214 003 565</ms:GML_ID>
        <ms:NAZWA>214 003 565</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>214003565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718143.903217 448087.045097</gml:lowerCorner>
        		<gml:upperCorner>718143.903217 448087.045097</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718143.903217 448087.045097</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.214 006 482</ms:GML_ID>
        <ms:NAZWA>214 006 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>214006482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718396.425187 448544.257688</gml:lowerCorner>
        		<gml:upperCorner>718396.425187 448544.257688</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718396.425187 448544.257688</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 040 492</ms:GML_ID>
        <ms:NAZWA>229 040 492</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229040492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6913">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713933.177000 449889.065000</gml:lowerCorner>
        		<gml:upperCorner>713933.177000 449889.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6913.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713933.177000 449889.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6913</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 166 250</ms:GML_ID>
        <ms:NAZWA>201 166 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201166250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6914">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713976.226000 450238.343000</gml:lowerCorner>
        		<gml:upperCorner>713976.226000 450238.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6914.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713976.226000 450238.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6914</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 166 601</ms:GML_ID>
        <ms:NAZWA>201 166 601</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201166601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717627.787000 451010.154000</gml:lowerCorner>
        		<gml:upperCorner>717627.787000 451010.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717627.787000 451010.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 037 816</ms:GML_ID>
        <ms:NAZWA>229 037 816</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229037816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6915">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713852.254000 451165.476000</gml:lowerCorner>
        		<gml:upperCorner>713852.254000 451165.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6915.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713852.254000 451165.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6915</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 167 541</ms:GML_ID>
        <ms:NAZWA>201 167 541</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201167541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717010.774921 452394.206317</gml:lowerCorner>
        		<gml:upperCorner>717010.774921 452394.206317</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717010.774921 452394.206317</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 036 244</ms:GML_ID>
        <ms:NAZWA>229 036 244</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229036244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716957.742295 452599.201234</gml:lowerCorner>
        		<gml:upperCorner>716957.742295 452599.201234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716957.742295 452599.201234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 036 034</ms:GML_ID>
        <ms:NAZWA>229 036 034</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229036034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716987.189000 453367.155000</gml:lowerCorner>
        		<gml:upperCorner>716987.189000 453367.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716987.189000 453367.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 035 238</ms:GML_ID>
        <ms:NAZWA>229 035 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229035238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716393.247000 454393.638000</gml:lowerCorner>
        		<gml:upperCorner>716393.247000 454393.638000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716393.247000 454393.638000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 034 038</ms:GML_ID>
        <ms:NAZWA>229 034 038</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229034038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717659.176000 456157.933000</gml:lowerCorner>
        		<gml:upperCorner>717659.176000 456157.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717659.176000 456157.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 031 679</ms:GML_ID>
        <ms:NAZWA>229 031 679</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229031679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718010.494567 460679.004649</gml:lowerCorner>
        		<gml:upperCorner>718010.494567 460679.004649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718010.494567 460679.004649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 026 114</ms:GML_ID>
        <ms:NAZWA>229 026 114</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229026114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>740743.558000 368124.670000</gml:lowerCorner>
        		<gml:upperCorner>740743.558000 368124.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>740743.558000 368124.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 181 905</ms:GML_ID>
        <ms:NAZWA>405 181 905</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405181905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>731635.717000 368357.475000</gml:lowerCorner>
        		<gml:upperCorner>731635.717000 368357.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>731635.717000 368357.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 169 639</ms:GML_ID>
        <ms:NAZWA>405 169 639</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405169639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713981.983000 368742.227000</gml:lowerCorner>
        		<gml:upperCorner>713981.983000 368742.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713981.983000 368742.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 062 566</ms:GML_ID>
        <ms:NAZWA>212 062 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212062566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732274.097000 368912.967000</gml:lowerCorner>
        		<gml:upperCorner>732274.097000 368912.967000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732274.097000 368912.967000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 170 506</ms:GML_ID>
        <ms:NAZWA>405 170 506</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405170506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>732824.548758 369505.517618</gml:lowerCorner>
        		<gml:upperCorner>732824.548758 369505.517618</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>732824.548758 369505.517618</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 134 718</ms:GML_ID>
        <ms:NAZWA>202 134 718</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202134718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713185.007000 370044.001000</gml:lowerCorner>
        		<gml:upperCorner>713185.007000 370044.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713185.007000 370044.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 060 965</ms:GML_ID>
        <ms:NAZWA>212 060 965</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212060965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>739280.107000 370157.735000</gml:lowerCorner>
        		<gml:upperCorner>739280.107000 370157.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>739280.107000 370157.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 179 398</ms:GML_ID>
        <ms:NAZWA>405 179 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405179398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>739133.043000 370381.381000</gml:lowerCorner>
        		<gml:upperCorner>739133.043000 370381.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>739133.043000 370381.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 179 127</ms:GML_ID>
        <ms:NAZWA>405 179 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405179127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>733199.617159 370462.877430</gml:lowerCorner>
        		<gml:upperCorner>733199.617159 370462.877430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>733199.617159 370462.877430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 133 784</ms:GML_ID>
        <ms:NAZWA>202 133 784</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202133784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712554.771000 370679.889000</gml:lowerCorner>
        		<gml:upperCorner>712554.771000 370679.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712554.771000 370679.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 060 048</ms:GML_ID>
        <ms:NAZWA>212 060 048</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212060048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711678.401000 371365.814000</gml:lowerCorner>
        		<gml:upperCorner>711678.401000 371365.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711678.401000 371365.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 058 918</ms:GML_ID>
        <ms:NAZWA>212 058 918</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212058918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711151.197000 372444.643000</gml:lowerCorner>
        		<gml:upperCorner>711151.197000 372444.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711151.197000 372444.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 057 705</ms:GML_ID>
        <ms:NAZWA>212 057 705</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212057705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710952.276000 372910.675000</gml:lowerCorner>
        		<gml:upperCorner>710952.276000 372910.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710952.276000 372910.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 057 195</ms:GML_ID>
        <ms:NAZWA>212 057 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212057195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710835.937000 373718.363000</gml:lowerCorner>
        		<gml:upperCorner>710835.937000 373718.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710835.937000 373718.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 056 374</ms:GML_ID>
        <ms:NAZWA>212 056 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212056374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710528.945000 377757.591000</gml:lowerCorner>
        		<gml:upperCorner>710528.945000 377757.591000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710528.945000 377757.591000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 051 980</ms:GML_ID>
        <ms:NAZWA>212 051 980</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212051980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>739416.259909 378731.974184</gml:lowerCorner>
        		<gml:upperCorner>739416.259909 378731.974184</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>739416.259909 378731.974184</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 122 008</ms:GML_ID>
        <ms:NAZWA>202 122 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202122008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>738514.576411 387893.129109</gml:lowerCorner>
        		<gml:upperCorner>738514.576411 387893.129109</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>738514.576411 387893.129109</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 112 816</ms:GML_ID>
        <ms:NAZWA>202 112 816</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202112816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>736759.924933 401838.906313</gml:lowerCorner>
        		<gml:upperCorner>736759.924933 401838.906313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>736759.924933 401838.906313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.202 098 652</ms:GML_ID>
        <ms:NAZWA>202 098 652</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>202098652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741843.487103 418180.815133</gml:lowerCorner>
        		<gml:upperCorner>741843.487103 418180.815133</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741843.487103 418180.815133</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 102 599</ms:GML_ID>
        <ms:NAZWA>229 102 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229102599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>743054.893000 418188.331539</gml:lowerCorner>
        		<gml:upperCorner>743054.893000 418188.331539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>743054.893000 418188.331539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 103 788</ms:GML_ID>
        <ms:NAZWA>229 103 788</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229103788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742339.803120 418191.790774</gml:lowerCorner>
        		<gml:upperCorner>742339.803120 418191.790774</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742339.803120 418191.790774</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 103 072</ms:GML_ID>
        <ms:NAZWA>229 103 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229103072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742667.751525 418199.111055</gml:lowerCorner>
        		<gml:upperCorner>742667.751525 418199.111055</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742667.751525 418199.111055</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 103 405</ms:GML_ID>
        <ms:NAZWA>229 103 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229103405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.57">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742009.159618 419891.607622</gml:lowerCorner>
        		<gml:upperCorner>742009.159618 419891.607622</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.57.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742009.159618 419891.607622</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>57</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 000 788</ms:GML_ID>
        <ms:NAZWA>237 000 788</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237000788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.58">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741880.253000 420032.357000</gml:lowerCorner>
        		<gml:upperCorner>741880.253000 420032.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.58.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741880.253000 420032.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>58</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 000 981</ms:GML_ID>
        <ms:NAZWA>237 000 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237000981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.59">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741256.207000 420169.496000</gml:lowerCorner>
        		<gml:upperCorner>741256.207000 420169.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.59.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741256.207000 420169.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>59</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 001 627</ms:GML_ID>
        <ms:NAZWA>237 001 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237001627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.60">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>740524.784000 420385.947000</gml:lowerCorner>
        		<gml:upperCorner>740524.784000 420385.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.60.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>740524.784000 420385.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>60</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 002 390</ms:GML_ID>
        <ms:NAZWA>237 002 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237002390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742103.772000 420394.686000</gml:lowerCorner>
        		<gml:upperCorner>742103.772000 420394.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742103.772000 420394.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 099 908</ms:GML_ID>
        <ms:NAZWA>229 099 908</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229099908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>742099.323000 420401.775000</gml:lowerCorner>
        		<gml:upperCorner>742099.323000 420401.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>742099.323000 420401.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 099 900</ms:GML_ID>
        <ms:NAZWA>229 099 900</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229099900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.62">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>737589.599444 420459.586437</gml:lowerCorner>
        		<gml:upperCorner>737589.599444 420459.586437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.62.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>737589.599444 420459.586437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>62</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 005 387</ms:GML_ID>
        <ms:NAZWA>237 005 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237005387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.61">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>739492.560256 420598.275153</gml:lowerCorner>
        		<gml:upperCorner>739492.560256 420598.275153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.61.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>739492.560256 420598.275153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>61</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.237 003 447</ms:GML_ID>
        <ms:NAZWA>237 003 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>237003447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>741726.589000 420999.120000</gml:lowerCorner>
        		<gml:upperCorner>741726.589000 420999.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>741726.589000 420999.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 099 199</ms:GML_ID>
        <ms:NAZWA>229 099 199</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229099199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717886.879000 462812.140000</gml:lowerCorner>
        		<gml:upperCorner>717886.879000 462812.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717886.879000 462812.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 023 569</ms:GML_ID>
        <ms:NAZWA>229 023 569</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229023569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717490.748000 463021.796000</gml:lowerCorner>
        		<gml:upperCorner>717490.748000 463021.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717490.748000 463021.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 023 107</ms:GML_ID>
        <ms:NAZWA>229 023 107</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229023107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717114.509000 463580.374000</gml:lowerCorner>
        		<gml:upperCorner>717114.509000 463580.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717114.509000 463580.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 022 420</ms:GML_ID>
        <ms:NAZWA>229 022 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229022420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>716978.121000 463833.403000</gml:lowerCorner>
        		<gml:upperCorner>716978.121000 463833.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>716978.121000 463833.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 022 135</ms:GML_ID>
        <ms:NAZWA>229 022 135</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229022135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>713231.895000 463944.113000</gml:lowerCorner>
        		<gml:upperCorner>713231.895000 463944.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>713231.895000 463944.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 017 833</ms:GML_ID>
        <ms:NAZWA>229 017 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229017833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>712243.203000 465064.963000</gml:lowerCorner>
        		<gml:upperCorner>712243.203000 465064.963000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>712243.203000 465064.963000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 016 299</ms:GML_ID>
        <ms:NAZWA>229 016 299</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229016299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711851.665000 465163.066000</gml:lowerCorner>
        		<gml:upperCorner>711851.665000 465163.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711851.665000 465163.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 015 883</ms:GML_ID>
        <ms:NAZWA>229 015 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229015883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711422.149036 465210.620436</gml:lowerCorner>
        		<gml:upperCorner>711422.149036 465210.620436</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711422.149036 465210.620436</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 015 452</ms:GML_ID>
        <ms:NAZWA>229 015 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229015452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710564.149000 466069.378000</gml:lowerCorner>
        		<gml:upperCorner>710564.149000 466069.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710564.149000 466069.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 014 046</ms:GML_ID>
        <ms:NAZWA>229 014 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229014046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710399.994000 466575.193000</gml:lowerCorner>
        		<gml:upperCorner>710399.994000 466575.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710399.994000 466575.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 013 510</ms:GML_ID>
        <ms:NAZWA>229 013 510</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229013510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710687.773000 467279.555000</gml:lowerCorner>
        		<gml:upperCorner>710687.773000 467279.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710687.773000 467279.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 012 718</ms:GML_ID>
        <ms:NAZWA>229 012 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229012718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711355.310000 467741.778000</gml:lowerCorner>
        		<gml:upperCorner>711355.310000 467741.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711355.310000 467741.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 011 911</ms:GML_ID>
        <ms:NAZWA>229 011 911</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229011911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711575.098000 468653.965000</gml:lowerCorner>
        		<gml:upperCorner>711575.098000 468653.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711575.098000 468653.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 010 885</ms:GML_ID>
        <ms:NAZWA>229 010 885</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229010885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711949.962000 470096.877000</gml:lowerCorner>
        		<gml:upperCorner>711949.962000 470096.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711949.962000 470096.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 009 198</ms:GML_ID>
        <ms:NAZWA>229 009 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229009198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>711751.930841 472306.819740</gml:lowerCorner>
        		<gml:upperCorner>711751.930841 472306.819740</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>711751.930841 472306.819740</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 006 849</ms:GML_ID>
        <ms:NAZWA>229 006 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229006849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710795.918000 473478.896000</gml:lowerCorner>
        		<gml:upperCorner>710795.918000 473478.896000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710795.918000 473478.896000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 005 209</ms:GML_ID>
        <ms:NAZWA>229 005 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229005209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710345.183000 473688.846000</gml:lowerCorner>
        		<gml:upperCorner>710345.183000 473688.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710345.183000 473688.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 004 711</ms:GML_ID>
        <ms:NAZWA>229 004 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229004711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710076.662000 473836.038000</gml:lowerCorner>
        		<gml:upperCorner>710076.662000 473836.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710076.662000 473836.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 004 405</ms:GML_ID>
        <ms:NAZWA>229 004 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229004405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709597.376000 474465.800000</gml:lowerCorner>
        		<gml:upperCorner>709597.376000 474465.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709597.376000 474465.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 003 590</ms:GML_ID>
        <ms:NAZWA>229 003 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229003590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687198.861000 484771.711000</gml:lowerCorner>
        		<gml:upperCorner>687198.861000 484771.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687198.861000 484771.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 492 348</ms:GML_ID>
        <ms:NAZWA>131 492 348</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131492348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687640.961000 479562.609000</gml:lowerCorner>
        		<gml:upperCorner>687640.961000 479562.609000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687640.961000 479562.609000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 009 992</ms:GML_ID>
        <ms:NAZWA>203 009 992</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203009992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689004.075613 499510.198458</gml:lowerCorner>
        		<gml:upperCorner>689004.075613 499510.198458</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689004.075613 499510.198458</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 004 898</ms:GML_ID>
        <ms:NAZWA>256 004 898</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256004898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692179.768000 483720.881000</gml:lowerCorner>
        		<gml:upperCorner>692179.768000 483720.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692179.768000 483720.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 003 820</ms:GML_ID>
        <ms:NAZWA>203 003 820</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203003820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>692711.147000 499805.436000</gml:lowerCorner>
        		<gml:upperCorner>692711.147000 499805.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>692711.147000 499805.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 008 620</ms:GML_ID>
        <ms:NAZWA>256 008 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256008620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693611.935000 485425.343000</gml:lowerCorner>
        		<gml:upperCorner>693611.935000 485425.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693611.935000 485425.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.727 001 402</ms:GML_ID>
        <ms:NAZWA>727 001 402</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>727001402</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694548.734000 500167.894000</gml:lowerCorner>
        		<gml:upperCorner>694548.734000 500167.894000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694548.734000 500167.894000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 010 510</ms:GML_ID>
        <ms:NAZWA>256 010 510</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256010510</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695457.084000 500508.282000</gml:lowerCorner>
        		<gml:upperCorner>695457.084000 500508.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695457.084000 500508.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 011 478</ms:GML_ID>
        <ms:NAZWA>256 011 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256011478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696825.117000 501022.285000</gml:lowerCorner>
        		<gml:upperCorner>696825.117000 501022.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696825.117000 501022.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 012 940</ms:GML_ID>
        <ms:NAZWA>256 012 940</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256012940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697832.798000 502965.411000</gml:lowerCorner>
        		<gml:upperCorner>697832.798000 502965.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697832.798000 502965.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 015 194</ms:GML_ID>
        <ms:NAZWA>256 015 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256015194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698815.113000 504815.014000</gml:lowerCorner>
        		<gml:upperCorner>698815.113000 504815.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698815.113000 504815.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 017 296</ms:GML_ID>
        <ms:NAZWA>256 017 296</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256017296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700000.114000 505543.051000</gml:lowerCorner>
        		<gml:upperCorner>700000.114000 505543.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700000.114000 505543.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 018 695</ms:GML_ID>
        <ms:NAZWA>256 018 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256018695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700820.073000 506031.259000</gml:lowerCorner>
        		<gml:upperCorner>700820.073000 506031.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700820.073000 506031.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 019 644</ms:GML_ID>
        <ms:NAZWA>256 019 644</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256019644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709251.661000 476038.833000</gml:lowerCorner>
        		<gml:upperCorner>709251.661000 476038.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709251.661000 476038.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 001 950</ms:GML_ID>
        <ms:NAZWA>229 001 950</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229001950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709299.966000 475546.198000</gml:lowerCorner>
        		<gml:upperCorner>709299.966000 475546.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709299.966000 475546.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 002 445</ms:GML_ID>
        <ms:NAZWA>229 002 445</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229002445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709348.972000 476630.486000</gml:lowerCorner>
        		<gml:upperCorner>709348.972000 476630.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709348.972000 476630.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 001 335</ms:GML_ID>
        <ms:NAZWA>229 001 335</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229001335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715450.288955 476293.636525</gml:lowerCorner>
        		<gml:upperCorner>715450.288955 476293.636525</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715450.288955 476293.636525</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 322 094</ms:GML_ID>
        <ms:NAZWA>009 322 094</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009322094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>715700.241000 477233.180000</gml:lowerCorner>
        		<gml:upperCorner>715700.241000 477233.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>715700.241000 477233.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 005 568</ms:GML_ID>
        <ms:NAZWA>226 005 568</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226005568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717756.698969 477542.979692</gml:lowerCorner>
        		<gml:upperCorner>717756.698969 477542.979692</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717756.698969 477542.979692</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 007 776</ms:GML_ID>
        <ms:NAZWA>226 007 776</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226007776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717846.976928 477649.247276</gml:lowerCorner>
        		<gml:upperCorner>717846.976928 477649.247276</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717846.976928 477649.247276</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 007 917</ms:GML_ID>
        <ms:NAZWA>226 007 917</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226007917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717851.818950 476235.408751</gml:lowerCorner>
        		<gml:upperCorner>717851.818950 476235.408751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717851.818950 476235.408751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 324 528</ms:GML_ID>
        <ms:NAZWA>009 324 528</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009324528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717903.231000 476649.350000</gml:lowerCorner>
        		<gml:upperCorner>717903.231000 476649.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717903.231000 476649.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.721 001 496</ms:GML_ID>
        <ms:NAZWA>721 001 496</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>721001496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>717976.328669 477811.945182</gml:lowerCorner>
        		<gml:upperCorner>717976.328669 477811.945182</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>717976.328669 477811.945182</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 008 125</ms:GML_ID>
        <ms:NAZWA>226 008 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226008125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718040.920000 476328.845000</gml:lowerCorner>
        		<gml:upperCorner>718040.920000 476328.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718040.920000 476328.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.721 001 130</ms:GML_ID>
        <ms:NAZWA>721 001 130</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>721001130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718109.617492 476303.193226</gml:lowerCorner>
        		<gml:upperCorner>718109.617492 476303.193226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718109.617492 476303.193226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.721 001 057</ms:GML_ID>
        <ms:NAZWA>721 001 057</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>721001057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718688.284971 476424.303349</gml:lowerCorner>
        		<gml:upperCorner>718688.284971 476424.303349</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718688.284971 476424.303349</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 325 385</ms:GML_ID>
        <ms:NAZWA>009 325 385</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009325385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>718712.861567 478281.540678</gml:lowerCorner>
        		<gml:upperCorner>718712.861567 478281.540678</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>718712.861567 478281.540678</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.226 009 001</ms:GML_ID>
        <ms:NAZWA>226 009 001</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>226009001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677784.348865 436048.135252</gml:lowerCorner>
        		<gml:upperCorner>677784.348865 436048.135252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677784.348865 436048.135252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 118 514</ms:GML_ID>
        <ms:NAZWA>201 118 514</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201118514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679467.717000 420043.719000</gml:lowerCorner>
        		<gml:upperCorner>679467.717000 420043.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679467.717000 420043.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 037 708</ms:GML_ID>
        <ms:NAZWA>211 037 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211037708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679765.863498 435963.870524</gml:lowerCorner>
        		<gml:upperCorner>679765.863498 435963.870524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679765.863498 435963.870524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 120 500</ms:GML_ID>
        <ms:NAZWA>201 120 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201120500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684751.125509 420183.766440</gml:lowerCorner>
        		<gml:upperCorner>684751.125509 420183.766440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684751.125509 420183.766440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 043 209</ms:GML_ID>
        <ms:NAZWA>211 043 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211043209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685067.683877 435722.278196</gml:lowerCorner>
        		<gml:upperCorner>685067.683877 435722.278196</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685067.683877 435722.278196</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 125 850</ms:GML_ID>
        <ms:NAZWA>201 125 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201125850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686448.803863 435365.075129</gml:lowerCorner>
        		<gml:upperCorner>686448.803863 435365.075129</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686448.803863 435365.075129</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 127 280</ms:GML_ID>
        <ms:NAZWA>201 127 280</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201127280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686649.105792 435258.789234</gml:lowerCorner>
        		<gml:upperCorner>686649.105792 435258.789234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686649.105792 435258.789234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 127 507</ms:GML_ID>
        <ms:NAZWA>201 127 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201127507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686871.398000 420390.520000</gml:lowerCorner>
        		<gml:upperCorner>686871.398000 420390.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686871.398000 420390.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 045 375</ms:GML_ID>
        <ms:NAZWA>211 045 375</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211045375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687764.363529 420558.799213</gml:lowerCorner>
        		<gml:upperCorner>687764.363529 420558.799213</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687764.363529 420558.799213</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 046 309</ms:GML_ID>
        <ms:NAZWA>211 046 309</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211046309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688371.766299 434657.972444</gml:lowerCorner>
        		<gml:upperCorner>688371.766299 434657.972444</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688371.766299 434657.972444</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 129 381</ms:GML_ID>
        <ms:NAZWA>201 129 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201129381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>689546.349146 434615.288385</gml:lowerCorner>
        		<gml:upperCorner>689546.349146 434615.288385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>689546.349146 434615.288385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 130 559</ms:GML_ID>
        <ms:NAZWA>201 130 559</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201130559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691171.429588 434973.141244</gml:lowerCorner>
        		<gml:upperCorner>691171.429588 434973.141244</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691171.429588 434973.141244</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 132 240</ms:GML_ID>
        <ms:NAZWA>201 132 240</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201132240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691566.917177 419918.371136</gml:lowerCorner>
        		<gml:upperCorner>691566.917177 419918.371136</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691566.917177 419918.371136</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 050 781</ms:GML_ID>
        <ms:NAZWA>211 050 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211050781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691831.419581 435184.276074</gml:lowerCorner>
        		<gml:upperCorner>691831.419581 435184.276074</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691831.419581 435184.276074</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 132 933</ms:GML_ID>
        <ms:NAZWA>201 132 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201132933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693401.437665 435632.124499</gml:lowerCorner>
        		<gml:upperCorner>693401.437665 435632.124499</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693401.437665 435632.124499</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 134 573</ms:GML_ID>
        <ms:NAZWA>201 134 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201134573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693941.159000 420218.762000</gml:lowerCorner>
        		<gml:upperCorner>693941.159000 420218.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693941.159000 420218.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 053 465</ms:GML_ID>
        <ms:NAZWA>211 053 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211053465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694143.850000 421423.490000</gml:lowerCorner>
        		<gml:upperCorner>694143.850000 421423.490000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694143.850000 421423.490000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 054 754</ms:GML_ID>
        <ms:NAZWA>211 054 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211054754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694423.859000 423304.511000</gml:lowerCorner>
        		<gml:upperCorner>694423.859000 423304.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694423.859000 423304.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 056 722</ms:GML_ID>
        <ms:NAZWA>211 056 722</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211056722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695016.382068 434971.542135</gml:lowerCorner>
        		<gml:upperCorner>695016.382068 434971.542135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695016.382068 434971.542135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 136 354</ms:GML_ID>
        <ms:NAZWA>201 136 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201136354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695127.360000 426192.979000</gml:lowerCorner>
        		<gml:upperCorner>695127.360000 426192.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695127.360000 426192.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 059 726</ms:GML_ID>
        <ms:NAZWA>211 059 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211059726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695238.988000 426474.644000</gml:lowerCorner>
        		<gml:upperCorner>695238.988000 426474.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695238.988000 426474.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 060 020</ms:GML_ID>
        <ms:NAZWA>211 060 020</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211060020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695416.117000 427443.426000</gml:lowerCorner>
        		<gml:upperCorner>695416.117000 427443.426000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695416.117000 427443.426000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 061 016</ms:GML_ID>
        <ms:NAZWA>211 061 016</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211061016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696012.997000 428783.472000</gml:lowerCorner>
        		<gml:upperCorner>696012.997000 428783.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696012.997000 428783.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 062 517</ms:GML_ID>
        <ms:NAZWA>211 062 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211062517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702454.818000 433904.672000</gml:lowerCorner>
        		<gml:upperCorner>702454.818000 433904.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702454.818000 433904.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 144 551</ms:GML_ID>
        <ms:NAZWA>201 144 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201144551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705922.525000 437367.804000</gml:lowerCorner>
        		<gml:upperCorner>705922.525000 437367.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705922.525000 437367.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 149 524</ms:GML_ID>
        <ms:NAZWA>201 149 524</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201149524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706700.048000 438501.718000</gml:lowerCorner>
        		<gml:upperCorner>706700.048000 438501.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706700.048000 438501.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 150 909</ms:GML_ID>
        <ms:NAZWA>201 150 909</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201150909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6908">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707967.303000 444236.071000</gml:lowerCorner>
        		<gml:upperCorner>707967.303000 444236.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6908.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707967.303000 444236.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6908</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 157 325</ms:GML_ID>
        <ms:NAZWA>201 157 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201157325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6907">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708133.557387 443348.572724</gml:lowerCorner>
        		<gml:upperCorner>708133.557387 443348.572724</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6907.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708133.557387 443348.572724</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6907</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 156 405</ms:GML_ID>
        <ms:NAZWA>201 156 405</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201156405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6906">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708243.259838 442573.727503</gml:lowerCorner>
        		<gml:upperCorner>708243.259838 442573.727503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6906.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708243.259838 442573.727503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6906</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 155 616</ms:GML_ID>
        <ms:NAZWA>201 155 616</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201155616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6905">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708341.665000 440736.014000</gml:lowerCorner>
        		<gml:upperCorner>708341.665000 440736.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6905.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708341.665000 440736.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6905</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 153 751</ms:GML_ID>
        <ms:NAZWA>201 153 751</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201153751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>719720.824000 430153.837000</gml:lowerCorner>
        		<gml:upperCorner>719720.824000 430153.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>719720.824000 430153.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.229 063 970</ms:GML_ID>
        <ms:NAZWA>229 063 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>229063970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672470.233000 416887.215000</gml:lowerCorner>
        		<gml:upperCorner>672470.233000 416887.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672470.233000 416887.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 029 708</ms:GML_ID>
        <ms:NAZWA>211 029 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211029708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673095.114000 417004.568000</gml:lowerCorner>
        		<gml:upperCorner>673095.114000 417004.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673095.114000 417004.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 030 344</ms:GML_ID>
        <ms:NAZWA>211 030 344</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211030344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673312.387000 417052.679000</gml:lowerCorner>
        		<gml:upperCorner>673312.387000 417052.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673312.387000 417052.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 030 567</ms:GML_ID>
        <ms:NAZWA>211 030 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211030567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673906.754393 417152.149455</gml:lowerCorner>
        		<gml:upperCorner>673906.754393 417152.149455</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673906.754393 417152.149455</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 031 172</ms:GML_ID>
        <ms:NAZWA>211 031 172</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211031172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674220.928000 417167.672000</gml:lowerCorner>
        		<gml:upperCorner>674220.928000 417167.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674220.928000 417167.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 031 485</ms:GML_ID>
        <ms:NAZWA>211 031 485</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211031485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674730.178000 417241.036000</gml:lowerCorner>
        		<gml:upperCorner>674730.178000 417241.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674730.178000 417241.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 032 001</ms:GML_ID>
        <ms:NAZWA>211 032 001</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211032001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675100.319000 417379.471000</gml:lowerCorner>
        		<gml:upperCorner>675100.319000 417379.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675100.319000 417379.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 032 398</ms:GML_ID>
        <ms:NAZWA>211 032 398</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211032398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675842.905000 417692.633000</gml:lowerCorner>
        		<gml:upperCorner>675842.905000 417692.633000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675842.905000 417692.633000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 033 204</ms:GML_ID>
        <ms:NAZWA>211 033 204</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211033204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677517.737000 418399.615000</gml:lowerCorner>
        		<gml:upperCorner>677517.737000 418399.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677517.737000 418399.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 035 023</ms:GML_ID>
        <ms:NAZWA>211 035 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211035023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678071.101000 418914.202000</gml:lowerCorner>
        		<gml:upperCorner>678071.101000 418914.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678071.101000 418914.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 035 798</ms:GML_ID>
        <ms:NAZWA>211 035 798</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211035798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679102.056106 419929.148558</gml:lowerCorner>
        		<gml:upperCorner>679102.056106 419929.148558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679102.056106 419929.148558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 037 323</ms:GML_ID>
        <ms:NAZWA>211 037 323</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211037323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682388.613999 419894.171993</gml:lowerCorner>
        		<gml:upperCorner>682388.613999 419894.171993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682388.613999 419894.171993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 040 680</ms:GML_ID>
        <ms:NAZWA>211 040 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211040680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682799.014000 419765.193000</gml:lowerCorner>
        		<gml:upperCorner>682799.014000 419765.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682799.014000 419765.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 041 110</ms:GML_ID>
        <ms:NAZWA>211 041 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211041110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683482.277000 419660.028000</gml:lowerCorner>
        		<gml:upperCorner>683482.277000 419660.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683482.277000 419660.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 041 817</ms:GML_ID>
        <ms:NAZWA>211 041 817</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211041817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687232.376932 420526.952252</gml:lowerCorner>
        		<gml:upperCorner>687232.376932 420526.952252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687232.376932 420526.952252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 045 768</ms:GML_ID>
        <ms:NAZWA>211 045 768</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211045768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>690041.631613 419383.583930</gml:lowerCorner>
        		<gml:upperCorner>690041.631613 419383.583930</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>690041.631613 419383.583930</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 048 988</ms:GML_ID>
        <ms:NAZWA>211 048 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211048988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693623.336813 420066.813812</gml:lowerCorner>
        		<gml:upperCorner>693623.336813 420066.813812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693623.336813 420066.813812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 053 102</ms:GML_ID>
        <ms:NAZWA>211 053 102</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211053102</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694159.073000 420931.309000</gml:lowerCorner>
        		<gml:upperCorner>694159.073000 420931.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694159.073000 420931.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 054 242</ms:GML_ID>
        <ms:NAZWA>211 054 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211054242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657875.010000 438652.310000</gml:lowerCorner>
        		<gml:upperCorner>657875.010000 438652.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657875.010000 438652.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 048 088</ms:GML_ID>
        <ms:NAZWA>215 048 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215048088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658327.211000 437607.000000</gml:lowerCorner>
        		<gml:upperCorner>658327.211000 437607.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658327.211000 437607.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 049 229</ms:GML_ID>
        <ms:NAZWA>215 049 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215049229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658511.645000 437107.331000</gml:lowerCorner>
        		<gml:upperCorner>658511.645000 437107.331000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658511.645000 437107.331000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 049 763</ms:GML_ID>
        <ms:NAZWA>215 049 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215049763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659013.162000 435836.009000</gml:lowerCorner>
        		<gml:upperCorner>659013.162000 435836.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659013.162000 435836.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 051 133</ms:GML_ID>
        <ms:NAZWA>215 051 133</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215051133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660328.192000 433593.605000</gml:lowerCorner>
        		<gml:upperCorner>660328.192000 433593.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660328.192000 433593.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 053 734</ms:GML_ID>
        <ms:NAZWA>215 053 734</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215053734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660651.221000 430526.952000</gml:lowerCorner>
        		<gml:upperCorner>660651.221000 430526.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660651.221000 430526.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 057 790</ms:GML_ID>
        <ms:NAZWA>215 057 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215057790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661540.062000 430921.695000</gml:lowerCorner>
        		<gml:upperCorner>661540.062000 430921.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661540.062000 430921.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 058 764</ms:GML_ID>
        <ms:NAZWA>215 058 764</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215058764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663231.238000 431672.318000</gml:lowerCorner>
        		<gml:upperCorner>663231.238000 431672.318000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663231.238000 431672.318000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 060 615</ms:GML_ID>
        <ms:NAZWA>215 060 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215060615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665145.873000 438274.007000</gml:lowerCorner>
        		<gml:upperCorner>665145.873000 438274.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665145.873000 438274.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 105 466</ms:GML_ID>
        <ms:NAZWA>201 105 466</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201105466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665366.630142 441163.142900</gml:lowerCorner>
        		<gml:upperCorner>665366.630142 441163.142900</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665366.630142 441163.142900</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 056 383</ms:GML_ID>
        <ms:NAZWA>203 056 383</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203056383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666249.440000 437629.108000</gml:lowerCorner>
        		<gml:upperCorner>666249.440000 437629.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666249.440000 437629.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 106 746</ms:GML_ID>
        <ms:NAZWA>201 106 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201106746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667034.917000 430674.388000</gml:lowerCorner>
        		<gml:upperCorner>667034.917000 430674.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667034.917000 430674.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 064 654</ms:GML_ID>
        <ms:NAZWA>215 064 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215064654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667862.794000 430141.584000</gml:lowerCorner>
        		<gml:upperCorner>667862.794000 430141.584000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667862.794000 430141.584000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 065 639</ms:GML_ID>
        <ms:NAZWA>215 065 639</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215065639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668388.942000 444968.061000</gml:lowerCorner>
        		<gml:upperCorner>668388.942000 444968.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668388.942000 444968.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 051 517</ms:GML_ID>
        <ms:NAZWA>203 051 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203051517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668524.562000 429715.844000</gml:lowerCorner>
        		<gml:upperCorner>668524.562000 429715.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668524.562000 429715.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 066 427</ms:GML_ID>
        <ms:NAZWA>215 066 427</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215066427</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669806.553000 437057.576000</gml:lowerCorner>
        		<gml:upperCorner>669806.553000 437057.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669806.553000 437057.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 110 442</ms:GML_ID>
        <ms:NAZWA>201 110 442</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201110442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670122.636000 436979.858000</gml:lowerCorner>
        		<gml:upperCorner>670122.636000 436979.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670122.636000 436979.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 110 765</ms:GML_ID>
        <ms:NAZWA>201 110 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201110765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670287.567000 429142.709000</gml:lowerCorner>
        		<gml:upperCorner>670287.567000 429142.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670287.567000 429142.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 068 447</ms:GML_ID>
        <ms:NAZWA>215 068 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215068447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670641.414000 436853.051000</gml:lowerCorner>
        		<gml:upperCorner>670641.414000 436853.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670641.414000 436853.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 111 301</ms:GML_ID>
        <ms:NAZWA>201 111 301</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201111301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670895.313000 430022.043000</gml:lowerCorner>
        		<gml:upperCorner>670895.313000 430022.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670895.313000 430022.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 069 517</ms:GML_ID>
        <ms:NAZWA>215 069 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215069517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671268.206000 430571.505000</gml:lowerCorner>
        		<gml:upperCorner>671268.206000 430571.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671268.206000 430571.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 070 181</ms:GML_ID>
        <ms:NAZWA>215 070 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215070181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671729.634000 431251.115000</gml:lowerCorner>
        		<gml:upperCorner>671729.634000 431251.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671729.634000 431251.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 071 003</ms:GML_ID>
        <ms:NAZWA>215 071 003</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215071003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672216.945000 436559.552000</gml:lowerCorner>
        		<gml:upperCorner>672216.945000 436559.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672216.945000 436559.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 112 907</ms:GML_ID>
        <ms:NAZWA>201 112 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201112907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672483.378000 432361.190000</gml:lowerCorner>
        		<gml:upperCorner>672483.378000 432361.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672483.378000 432361.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 072 345</ms:GML_ID>
        <ms:NAZWA>215 072 345</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215072345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672588.434000 432515.935000</gml:lowerCorner>
        		<gml:upperCorner>672588.434000 432515.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672588.434000 432515.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 072 533</ms:GML_ID>
        <ms:NAZWA>215 072 533</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215072533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673034.979000 433174.274000</gml:lowerCorner>
        		<gml:upperCorner>673034.979000 433174.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673034.979000 433174.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 073 328</ms:GML_ID>
        <ms:NAZWA>215 073 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215073328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673095.488000 436423.965000</gml:lowerCorner>
        		<gml:upperCorner>673095.488000 436423.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673095.488000 436423.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 113 797</ms:GML_ID>
        <ms:NAZWA>201 113 797</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201113797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673422.279000 433744.717000</gml:lowerCorner>
        		<gml:upperCorner>673422.279000 433744.717000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673422.279000 433744.717000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 074 018</ms:GML_ID>
        <ms:NAZWA>215 074 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215074018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673870.948000 436304.618000</gml:lowerCorner>
        		<gml:upperCorner>673870.948000 436304.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673870.948000 436304.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 114 582</ms:GML_ID>
        <ms:NAZWA>201 114 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201114582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675327.520579 436152.885575</gml:lowerCorner>
        		<gml:upperCorner>675327.520579 436152.885575</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675327.520579 436152.885575</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 116 052</ms:GML_ID>
        <ms:NAZWA>201 116 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201116052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675566.631603 436142.823331</gml:lowerCorner>
        		<gml:upperCorner>675566.631603 436142.823331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675566.631603 436142.823331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 116 291</ms:GML_ID>
        <ms:NAZWA>201 116 291</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201116291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656372.242000 421185.869000</gml:lowerCorner>
        		<gml:upperCorner>656372.242000 421185.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656372.242000 421185.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 078 593</ms:GML_ID>
        <ms:NAZWA>203 078 593</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203078593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656603.173076 440948.024917</gml:lowerCorner>
        		<gml:upperCorner>656603.173076 440948.024917</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656603.173076 440948.024917</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 096 346</ms:GML_ID>
        <ms:NAZWA>201 096 346</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201096346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656804.772000 440937.337000</gml:lowerCorner>
        		<gml:upperCorner>656804.772000 440937.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656804.772000 440937.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 096 548</ms:GML_ID>
        <ms:NAZWA>201 096 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201096548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656926.334000 423022.774000</gml:lowerCorner>
        		<gml:upperCorner>656926.334000 423022.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656926.334000 423022.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 076 672</ms:GML_ID>
        <ms:NAZWA>203 076 672</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203076672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657303.815000 424140.970000</gml:lowerCorner>
        		<gml:upperCorner>657303.815000 424140.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657303.815000 424140.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 075 497</ms:GML_ID>
        <ms:NAZWA>203 075 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203075497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657975.449000 426115.601000</gml:lowerCorner>
        		<gml:upperCorner>657975.449000 426115.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657975.449000 426115.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 073 406</ms:GML_ID>
        <ms:NAZWA>203 073 406</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203073406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658190.167000 437870.695000</gml:lowerCorner>
        		<gml:upperCorner>658190.167000 437870.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658190.167000 437870.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 048 932</ms:GML_ID>
        <ms:NAZWA>215 048 932</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215048932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658595.533000 427951.531000</gml:lowerCorner>
        		<gml:upperCorner>658595.533000 427951.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658595.533000 427951.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 071 463</ms:GML_ID>
        <ms:NAZWA>203 071 463</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203071463</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658753.266000 436407.471000</gml:lowerCorner>
        		<gml:upperCorner>658753.266000 436407.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658753.266000 436407.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 050 503</ms:GML_ID>
        <ms:NAZWA>215 050 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215050503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659224.303000 429811.566000</gml:lowerCorner>
        		<gml:upperCorner>659224.303000 429811.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659224.303000 429811.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 069 501</ms:GML_ID>
        <ms:NAZWA>203 069 501</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203069501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659281.407000 440801.117000</gml:lowerCorner>
        		<gml:upperCorner>659281.407000 440801.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659281.407000 440801.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 099 032</ms:GML_ID>
        <ms:NAZWA>201 099 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201099032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659445.268000 435047.340000</gml:lowerCorner>
        		<gml:upperCorner>659445.268000 435047.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659445.268000 435047.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 052 032</ms:GML_ID>
        <ms:NAZWA>215 052 032</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215052032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660390.248000 430426.176000</gml:lowerCorner>
        		<gml:upperCorner>660390.248000 430426.176000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660390.248000 430426.176000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 057 508</ms:GML_ID>
        <ms:NAZWA>215 057 508</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215057508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660514.708000 433629.033000</gml:lowerCorner>
        		<gml:upperCorner>660514.708000 433629.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660514.708000 433629.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 065 468</ms:GML_ID>
        <ms:NAZWA>203 065 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203065468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660660.592000 434061.582000</gml:lowerCorner>
        		<gml:upperCorner>660660.592000 434061.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660660.592000 434061.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 065 011</ms:GML_ID>
        <ms:NAZWA>203 065 011</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203065011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660786.188000 434433.381000</gml:lowerCorner>
        		<gml:upperCorner>660786.188000 434433.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660786.188000 434433.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 064 619</ms:GML_ID>
        <ms:NAZWA>203 064 619</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203064619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661062.461622 440239.942683</gml:lowerCorner>
        		<gml:upperCorner>661062.461622 440239.942683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661062.461622 440239.942683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 100 905</ms:GML_ID>
        <ms:NAZWA>201 100 905</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201100905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661283.444000 435833.452000</gml:lowerCorner>
        		<gml:upperCorner>661283.444000 435833.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661283.444000 435833.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 063 129</ms:GML_ID>
        <ms:NAZWA>203 063 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203063129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661579.769000 436258.052000</gml:lowerCorner>
        		<gml:upperCorner>661579.769000 436258.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661579.769000 436258.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 062 611</ms:GML_ID>
        <ms:NAZWA>203 062 611</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203062611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>661951.931812 439947.543812</gml:lowerCorner>
        		<gml:upperCorner>661951.931812 439947.543812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>661951.931812 439947.543812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 101 841</ms:GML_ID>
        <ms:NAZWA>201 101 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201101841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662022.543000 436802.814000</gml:lowerCorner>
        		<gml:upperCorner>662022.543000 436802.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662022.543000 436802.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 061 909</ms:GML_ID>
        <ms:NAZWA>203 061 909</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203061909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662240.452000 431232.152000</gml:lowerCorner>
        		<gml:upperCorner>662240.452000 431232.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662240.452000 431232.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 059 529</ms:GML_ID>
        <ms:NAZWA>215 059 529</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215059529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662363.450000 437223.183000</gml:lowerCorner>
        		<gml:upperCorner>662363.450000 437223.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662363.450000 437223.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 061 367</ms:GML_ID>
        <ms:NAZWA>203 061 367</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203061367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662750.246000 437669.471000</gml:lowerCorner>
        		<gml:upperCorner>662750.246000 437669.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662750.246000 437669.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 060 775</ms:GML_ID>
        <ms:NAZWA>203 060 775</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203060775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662886.041851 439597.536840</gml:lowerCorner>
        		<gml:upperCorner>662886.041851 439597.536840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662886.041851 439597.536840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 102 842</ms:GML_ID>
        <ms:NAZWA>201 102 842</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201102842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663371.177000 438374.861000</gml:lowerCorner>
        		<gml:upperCorner>663371.177000 438374.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663371.177000 438374.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 059 837</ms:GML_ID>
        <ms:NAZWA>203 059 837</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203059837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663739.238000 438808.078000</gml:lowerCorner>
        		<gml:upperCorner>663739.238000 438808.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663739.238000 438808.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 059 266</ms:GML_ID>
        <ms:NAZWA>203 059 266</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203059266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663988.404000 431740.347000</gml:lowerCorner>
        		<gml:upperCorner>663988.404000 431740.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663988.404000 431740.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 061 406</ms:GML_ID>
        <ms:NAZWA>215 061 406</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215061406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664157.452000 439523.839000</gml:lowerCorner>
        		<gml:upperCorner>664157.452000 439523.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664157.452000 439523.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 058 437</ms:GML_ID>
        <ms:NAZWA>203 058 437</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203058437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664287.227000 431654.745000</gml:lowerCorner>
        		<gml:upperCorner>664287.227000 431654.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664287.227000 431654.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 061 717</ms:GML_ID>
        <ms:NAZWA>215 061 717</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215061717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664961.748000 440746.480000</gml:lowerCorner>
        		<gml:upperCorner>664961.748000 440746.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664961.748000 440746.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 056 965</ms:GML_ID>
        <ms:NAZWA>203 056 965</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203056965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655818.229000 407278.786000</gml:lowerCorner>
        		<gml:upperCorner>655818.229000 407278.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655818.229000 407278.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 009 451</ms:GML_ID>
        <ms:NAZWA>211 009 451</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211009451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656281.760000 393662.246000</gml:lowerCorner>
        		<gml:upperCorner>656281.760000 393662.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656281.760000 393662.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 013 166</ms:GML_ID>
        <ms:NAZWA>413 013 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413013166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658022.149000 393049.363000</gml:lowerCorner>
        		<gml:upperCorner>658022.149000 393049.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658022.149000 393049.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 015 114</ms:GML_ID>
        <ms:NAZWA>413 015 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413015114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>659629.193000 392438.593000</gml:lowerCorner>
        		<gml:upperCorner>659629.193000 392438.593000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>659629.193000 392438.593000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 017 152</ms:GML_ID>
        <ms:NAZWA>413 017 152</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413017152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660518.719339 392238.410708</gml:lowerCorner>
        		<gml:upperCorner>660518.719339 392238.410708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660518.719339 392238.410708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 018 080</ms:GML_ID>
        <ms:NAZWA>413 018 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413018080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660524.407818 389391.242510</gml:lowerCorner>
        		<gml:upperCorner>660524.407818 389391.242510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660524.407818 389391.242510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 020 991</ms:GML_ID>
        <ms:NAZWA>413 020 991</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413020991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660597.291780 389885.030539</gml:lowerCorner>
        		<gml:upperCorner>660597.291780 389885.030539</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660597.291780 389885.030539</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 020 491</ms:GML_ID>
        <ms:NAZWA>413 020 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413020491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660639.150000 388335.498000</gml:lowerCorner>
        		<gml:upperCorner>660639.150000 388335.498000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660639.150000 388335.498000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 022 067</ms:GML_ID>
        <ms:NAZWA>413 022 067</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413022067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>660676.791428 390810.260696</gml:lowerCorner>
        		<gml:upperCorner>660676.791428 390810.260696</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>660676.791428 390810.260696</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 019 561</ms:GML_ID>
        <ms:NAZWA>413 019 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413019561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682857.124000 366980.903000</gml:lowerCorner>
        		<gml:upperCorner>682857.124000 366980.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682857.124000 366980.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 115 229</ms:GML_ID>
        <ms:NAZWA>405 115 229</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405115229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>688776.866000 363926.420000</gml:lowerCorner>
        		<gml:upperCorner>688776.866000 363926.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>688776.866000 363926.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 122 054</ms:GML_ID>
        <ms:NAZWA>405 122 054</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405122054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>702536.494000 394753.307000</gml:lowerCorner>
        		<gml:upperCorner>702536.494000 394753.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>702536.494000 394753.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 031 847</ms:GML_ID>
        <ms:NAZWA>212 031 847</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212031847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703054.554000 393826.644000</gml:lowerCorner>
        		<gml:upperCorner>703054.554000 393826.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703054.554000 393826.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 032 930</ms:GML_ID>
        <ms:NAZWA>212 032 930</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212032930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704550.761067 392802.039639</gml:lowerCorner>
        		<gml:upperCorner>704550.761067 392802.039639</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704550.761067 392802.039639</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 034 785</ms:GML_ID>
        <ms:NAZWA>212 034 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212034785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705442.574000 391360.010000</gml:lowerCorner>
        		<gml:upperCorner>705442.574000 391360.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705442.574000 391360.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 036 495</ms:GML_ID>
        <ms:NAZWA>212 036 495</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212036495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705730.511000 391055.514000</gml:lowerCorner>
        		<gml:upperCorner>705730.511000 391055.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705730.511000 391055.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 036 918</ms:GML_ID>
        <ms:NAZWA>212 036 918</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212036918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707091.935000 388654.759000</gml:lowerCorner>
        		<gml:upperCorner>707091.935000 388654.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707091.935000 388654.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 039 782</ms:GML_ID>
        <ms:NAZWA>212 039 782</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212039782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707739.370660 362925.390925</gml:lowerCorner>
        		<gml:upperCorner>707739.370660 362925.390925</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707739.370660 362925.390925</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 143 320</ms:GML_ID>
        <ms:NAZWA>405 143 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405143320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708102.877000 386930.128000</gml:lowerCorner>
        		<gml:upperCorner>708102.877000 386930.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708102.877000 386930.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 041 802</ms:GML_ID>
        <ms:NAZWA>212 041 802</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212041802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708763.650000 386309.680000</gml:lowerCorner>
        		<gml:upperCorner>708763.650000 386309.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708763.650000 386309.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 042 711</ms:GML_ID>
        <ms:NAZWA>212 042 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212042711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708953.790000 362856.662000</gml:lowerCorner>
        		<gml:upperCorner>708953.790000 362856.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708953.790000 362856.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.405 144 543</ms:GML_ID>
        <ms:NAZWA>405 144 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>405144543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709465.159000 385498.620000</gml:lowerCorner>
        		<gml:upperCorner>709465.159000 385498.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709465.159000 385498.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 043 903</ms:GML_ID>
        <ms:NAZWA>212 043 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212043903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709470.288000 383686.299000</gml:lowerCorner>
        		<gml:upperCorner>709470.288000 383686.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709470.288000 383686.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 045 921</ms:GML_ID>
        <ms:NAZWA>212 045 921</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212045921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>709699.628000 382485.438000</gml:lowerCorner>
        		<gml:upperCorner>709699.628000 382485.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>709699.628000 382485.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 047 148</ms:GML_ID>
        <ms:NAZWA>212 047 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212047148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710041.113000 376430.197000</gml:lowerCorner>
        		<gml:upperCorner>710041.113000 376430.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710041.113000 376430.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 053 403</ms:GML_ID>
        <ms:NAZWA>212 053 403</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212053403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710043.498000 381162.511000</gml:lowerCorner>
        		<gml:upperCorner>710043.498000 381162.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710043.498000 381162.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 048 516</ms:GML_ID>
        <ms:NAZWA>212 048 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212048516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710100.199000 375821.582000</gml:lowerCorner>
        		<gml:upperCorner>710100.199000 375821.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710100.199000 375821.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 054 032</ms:GML_ID>
        <ms:NAZWA>212 054 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212054032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>710314.447000 379049.150000</gml:lowerCorner>
        		<gml:upperCorner>710314.447000 379049.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>710314.447000 379049.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.212 050 650</ms:GML_ID>
        <ms:NAZWA>212 050 650</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>212050650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655423.234000 441152.455000</gml:lowerCorner>
        		<gml:upperCorner>655423.234000 441152.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655423.234000 441152.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.743 000 778</ms:GML_ID>
        <ms:NAZWA>743 000 778</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>743000778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655789.638076 441757.889296</gml:lowerCorner>
        		<gml:upperCorner>655789.638076 441757.889296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655789.638076 441757.889296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 044 255</ms:GML_ID>
        <ms:NAZWA>215 044 255</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215044255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669724.250000 446761.771000</gml:lowerCorner>
        		<gml:upperCorner>669724.250000 446761.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669724.250000 446761.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 049 279</ms:GML_ID>
        <ms:NAZWA>203 049 279</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203049279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671454.665306 448707.501561</gml:lowerCorner>
        		<gml:upperCorner>671454.665306 448707.501561</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671454.665306 448707.501561</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 046 660</ms:GML_ID>
        <ms:NAZWA>203 046 660</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203046660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>671802.367000 448983.289000</gml:lowerCorner>
        		<gml:upperCorner>671802.367000 448983.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>671802.367000 448983.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 046 216</ms:GML_ID>
        <ms:NAZWA>203 046 216</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203046216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672736.847000 449926.487000</gml:lowerCorner>
        		<gml:upperCorner>672736.847000 449926.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672736.847000 449926.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 044 886</ms:GML_ID>
        <ms:NAZWA>203 044 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203044886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673594.156000 472407.893000</gml:lowerCorner>
        		<gml:upperCorner>673594.156000 472407.893000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673594.156000 472407.893000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.243 015 742</ms:GML_ID>
        <ms:NAZWA>243 015 742</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>243015742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673822.230000 451047.435000</gml:lowerCorner>
        		<gml:upperCorner>673822.230000 451047.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673822.230000 451047.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 043 324</ms:GML_ID>
        <ms:NAZWA>203 043 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203043324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674385.438000 472307.827000</gml:lowerCorner>
        		<gml:upperCorner>674385.438000 472307.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674385.438000 472307.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.243 016 548</ms:GML_ID>
        <ms:NAZWA>243 016 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>243016548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674391.303000 451913.144000</gml:lowerCorner>
        		<gml:upperCorner>674391.303000 451913.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674391.303000 451913.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 042 270</ms:GML_ID>
        <ms:NAZWA>203 042 270</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203042270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674531.611000 452449.634000</gml:lowerCorner>
        		<gml:upperCorner>674531.611000 452449.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674531.611000 452449.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 041 716</ms:GML_ID>
        <ms:NAZWA>203 041 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203041716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674904.468000 453512.594000</gml:lowerCorner>
        		<gml:upperCorner>674904.468000 453512.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674904.468000 453512.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 040 580</ms:GML_ID>
        <ms:NAZWA>203 040 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203040580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675400.158000 454177.639000</gml:lowerCorner>
        		<gml:upperCorner>675400.158000 454177.639000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675400.158000 454177.639000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 039 752</ms:GML_ID>
        <ms:NAZWA>203 039 752</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203039752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675751.163000 471531.313000</gml:lowerCorner>
        		<gml:upperCorner>675751.163000 471531.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675751.163000 471531.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.243 018 157</ms:GML_ID>
        <ms:NAZWA>243 018 157</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>243018157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675891.972000 454826.970000</gml:lowerCorner>
        		<gml:upperCorner>675891.972000 454826.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675891.972000 454826.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 038 938</ms:GML_ID>
        <ms:NAZWA>203 038 938</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203038938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676509.629000 455644.880000</gml:lowerCorner>
        		<gml:upperCorner>676509.629000 455644.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676509.629000 455644.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 037 911</ms:GML_ID>
        <ms:NAZWA>203 037 911</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203037911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676884.016000 456140.460000</gml:lowerCorner>
        		<gml:upperCorner>676884.016000 456140.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676884.016000 456140.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 037 288</ms:GML_ID>
        <ms:NAZWA>203 037 288</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203037288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677451.363000 456890.164000</gml:lowerCorner>
        		<gml:upperCorner>677451.363000 456890.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677451.363000 456890.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 036 349</ms:GML_ID>
        <ms:NAZWA>203 036 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203036349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677672.275000 457183.456000</gml:lowerCorner>
        		<gml:upperCorner>677672.275000 457183.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677672.275000 457183.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 035 981</ms:GML_ID>
        <ms:NAZWA>203 035 981</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203035981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677912.985000 458227.312000</gml:lowerCorner>
        		<gml:upperCorner>677912.985000 458227.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677912.985000 458227.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 034 889</ms:GML_ID>
        <ms:NAZWA>203 034 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203034889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677935.982000 458762.035000</gml:lowerCorner>
        		<gml:upperCorner>677935.982000 458762.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677935.982000 458762.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 034 353</ms:GML_ID>
        <ms:NAZWA>203 034 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203034353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677954.188281 470438.050267</gml:lowerCorner>
        		<gml:upperCorner>677954.188281 470438.050267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677954.188281 470438.050267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.243 020 770</ms:GML_ID>
        <ms:NAZWA>243 020 770</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>243020770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678009.921000 460445.696000</gml:lowerCorner>
        		<gml:upperCorner>678009.921000 460445.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678009.921000 460445.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 032 665</ms:GML_ID>
        <ms:NAZWA>203 032 665</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203032665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679064.607033 468643.796004</gml:lowerCorner>
        		<gml:upperCorner>679064.607033 468643.796004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679064.607033 468643.796004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 024 303</ms:GML_ID>
        <ms:NAZWA>203 024 303</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203024303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679732.289054 469976.358897</gml:lowerCorner>
        		<gml:upperCorner>679732.289054 469976.358897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679732.289054 469976.358897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.243 022 737</ms:GML_ID>
        <ms:NAZWA>243 022 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>243022737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679988.840000 469697.806000</gml:lowerCorner>
        		<gml:upperCorner>679988.840000 469697.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679988.840000 469697.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 022 894</ms:GML_ID>
        <ms:NAZWA>203 022 894</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203022894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>680464.312000 470113.341000</gml:lowerCorner>
        		<gml:upperCorner>680464.312000 470113.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>680464.312000 470113.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 022 266</ms:GML_ID>
        <ms:NAZWA>203 022 266</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203022266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>683643.323000 475175.998000</gml:lowerCorner>
        		<gml:upperCorner>683643.323000 475175.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>683643.323000 475175.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 016 095</ms:GML_ID>
        <ms:NAZWA>203 016 095</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203016095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654698.709529 416493.178808</gml:lowerCorner>
        		<gml:upperCorner>654698.709529 416493.178808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654698.709529 416493.178808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 083 591</ms:GML_ID>
        <ms:NAZWA>203 083 591</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203083591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655770.841425 419072.664645</gml:lowerCorner>
        		<gml:upperCorner>655770.841425 419072.664645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655770.841425 419072.664645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 080 791</ms:GML_ID>
        <ms:NAZWA>203 080 791</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203080791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>656065.936000 420105.459000</gml:lowerCorner>
        		<gml:upperCorner>656065.936000 420105.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>656065.936000 420105.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 079 717</ms:GML_ID>
        <ms:NAZWA>203 079 717</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203079717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662454.609000 410710.177000</gml:lowerCorner>
        		<gml:upperCorner>662454.609000 410710.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662454.609000 410710.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 017 363</ms:GML_ID>
        <ms:NAZWA>211 017 363</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211017363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>662747.581000 411123.408000</gml:lowerCorner>
        		<gml:upperCorner>662747.581000 411123.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>662747.581000 411123.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 017 869</ms:GML_ID>
        <ms:NAZWA>211 017 869</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211017869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663688.573000 412282.449000</gml:lowerCorner>
        		<gml:upperCorner>663688.573000 412282.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663688.573000 412282.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 019 365</ms:GML_ID>
        <ms:NAZWA>211 019 365</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211019365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666361.781000 415029.269000</gml:lowerCorner>
        		<gml:upperCorner>666361.781000 415029.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666361.781000 415029.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 023 232</ms:GML_ID>
        <ms:NAZWA>211 023 232</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211023232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>666844.990000 415343.780000</gml:lowerCorner>
        		<gml:upperCorner>666844.990000 415343.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>666844.990000 415343.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 023 812</ms:GML_ID>
        <ms:NAZWA>211 023 812</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211023812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667384.007000 415603.058000</gml:lowerCorner>
        		<gml:upperCorner>667384.007000 415603.058000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667384.007000 415603.058000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 024 411</ms:GML_ID>
        <ms:NAZWA>211 024 411</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211024411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668165.108000 415978.984000</gml:lowerCorner>
        		<gml:upperCorner>668165.108000 415978.984000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668165.108000 415978.984000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 025 279</ms:GML_ID>
        <ms:NAZWA>211 025 279</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211025279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668395.734000 416090.407000</gml:lowerCorner>
        		<gml:upperCorner>668395.734000 416090.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668395.734000 416090.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 025 535</ms:GML_ID>
        <ms:NAZWA>211 025 535</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211025535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668874.532106 416285.078343</gml:lowerCorner>
        		<gml:upperCorner>668874.532106 416285.078343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668874.532106 416285.078343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 026 054</ms:GML_ID>
        <ms:NAZWA>211 026 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211026054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669590.442000 416458.855000</gml:lowerCorner>
        		<gml:upperCorner>669590.442000 416458.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669590.442000 416458.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 026 791</ms:GML_ID>
        <ms:NAZWA>211 026 791</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211026791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>669769.371000 416503.320000</gml:lowerCorner>
        		<gml:upperCorner>669769.371000 416503.320000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>669769.371000 416503.320000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 026 975</ms:GML_ID>
        <ms:NAZWA>211 026 975</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211026975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670224.138000 416601.671000</gml:lowerCorner>
        		<gml:upperCorner>670224.138000 416601.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670224.138000 416601.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 027 441</ms:GML_ID>
        <ms:NAZWA>211 027 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211027441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670542.507000 416663.738000</gml:lowerCorner>
        		<gml:upperCorner>670542.507000 416663.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670542.507000 416663.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 027 765</ms:GML_ID>
        <ms:NAZWA>211 027 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211027765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670854.924000 416701.752000</gml:lowerCorner>
        		<gml:upperCorner>670854.924000 416701.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670854.924000 416701.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 028 080</ms:GML_ID>
        <ms:NAZWA>211 028 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211028080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672202.106000 416856.239000</gml:lowerCorner>
        		<gml:upperCorner>672202.106000 416856.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672202.106000 416856.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 029 437</ms:GML_ID>
        <ms:NAZWA>211 029 437</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211029437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646816.305000 441751.364000</gml:lowerCorner>
        		<gml:upperCorner>646816.305000 441751.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646816.305000 441751.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 086 430</ms:GML_ID>
        <ms:NAZWA>201 086 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201086430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647291.562000 446705.494000</gml:lowerCorner>
        		<gml:upperCorner>647291.562000 446705.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647291.562000 446705.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 034 001</ms:GML_ID>
        <ms:NAZWA>215 034 001</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215034001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647625.386000 441645.528000</gml:lowerCorner>
        		<gml:upperCorner>647625.386000 441645.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647625.386000 441645.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 087 248</ms:GML_ID>
        <ms:NAZWA>201 087 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201087248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648588.117519 446402.622724</gml:lowerCorner>
        		<gml:upperCorner>648588.117519 446402.622724</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648588.117519 446402.622724</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 035 335</ms:GML_ID>
        <ms:NAZWA>215 035 335</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215035335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649118.013000 441560.323000</gml:lowerCorner>
        		<gml:upperCorner>649118.013000 441560.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649118.013000 441560.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 088 750</ms:GML_ID>
        <ms:NAZWA>201 088 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201088750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649512.945000 441589.506000</gml:lowerCorner>
        		<gml:upperCorner>649512.945000 441589.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649512.945000 441589.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 089 146</ms:GML_ID>
        <ms:NAZWA>201 089 146</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201089146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649611.443000 446163.380000</gml:lowerCorner>
        		<gml:upperCorner>649611.443000 446163.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649611.443000 446163.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 036 384</ms:GML_ID>
        <ms:NAZWA>215 036 384</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215036384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649970.176000 441623.696000</gml:lowerCorner>
        		<gml:upperCorner>649970.176000 441623.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649970.176000 441623.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 089 605</ms:GML_ID>
        <ms:NAZWA>201 089 605</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201089605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650268.796000 446009.444000</gml:lowerCorner>
        		<gml:upperCorner>650268.796000 446009.444000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650268.796000 446009.444000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 037 060</ms:GML_ID>
        <ms:NAZWA>215 037 060</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215037060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651091.961000 441707.243000</gml:lowerCorner>
        		<gml:upperCorner>651091.961000 441707.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651091.961000 441707.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 090 729</ms:GML_ID>
        <ms:NAZWA>201 090 729</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201090729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651210.446000 445353.271000</gml:lowerCorner>
        		<gml:upperCorner>651210.446000 445353.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651210.446000 445353.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 038 225</ms:GML_ID>
        <ms:NAZWA>215 038 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215038225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651786.763000 444992.691000</gml:lowerCorner>
        		<gml:upperCorner>651786.763000 444992.691000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651786.763000 444992.691000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 038 906</ms:GML_ID>
        <ms:NAZWA>215 038 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215038906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652762.509000 441723.365000</gml:lowerCorner>
        		<gml:upperCorner>652762.509000 441723.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652762.509000 441723.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 092 413</ms:GML_ID>
        <ms:NAZWA>201 092 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201092413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653156.538000 441628.292000</gml:lowerCorner>
        		<gml:upperCorner>653156.538000 441628.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653156.538000 441628.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 092 820</ms:GML_ID>
        <ms:NAZWA>201 092 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201092820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653226.308000 443970.206000</gml:lowerCorner>
        		<gml:upperCorner>653226.308000 443970.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653226.308000 443970.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 040 680</ms:GML_ID>
        <ms:NAZWA>215 040 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215040680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653634.724000 441511.566000</gml:lowerCorner>
        		<gml:upperCorner>653634.724000 441511.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653634.724000 441511.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 093 310</ms:GML_ID>
        <ms:NAZWA>201 093 310</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201093310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653666.885000 443703.460000</gml:lowerCorner>
        		<gml:upperCorner>653666.885000 443703.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653666.885000 443703.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 041 196</ms:GML_ID>
        <ms:NAZWA>215 041 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215041196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654869.514000 443071.110000</gml:lowerCorner>
        		<gml:upperCorner>654869.514000 443071.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654869.514000 443071.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 042 558</ms:GML_ID>
        <ms:NAZWA>215 042 558</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215042558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655397.737000 441090.030000</gml:lowerCorner>
        		<gml:upperCorner>655397.737000 441090.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655397.737000 441090.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 095 127</ms:GML_ID>
        <ms:NAZWA>201 095 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201095127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643621.388000 387738.568000</gml:lowerCorner>
        		<gml:upperCorner>643621.388000 387738.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643621.388000 387738.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 019 907</ms:GML_ID>
        <ms:NAZWA>210 019 907</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210019907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643379.371000 389012.982000</gml:lowerCorner>
        		<gml:upperCorner>643379.371000 389012.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643379.371000 389012.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 018 607</ms:GML_ID>
        <ms:NAZWA>210 018 607</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210018607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643538.983000 390154.669000</gml:lowerCorner>
        		<gml:upperCorner>643538.983000 390154.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643538.983000 390154.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 017 452</ms:GML_ID>
        <ms:NAZWA>210 017 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210017452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644541.463421 392044.235283</gml:lowerCorner>
        		<gml:upperCorner>644541.463421 392044.235283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644541.463421 392044.235283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 015 231</ms:GML_ID>
        <ms:NAZWA>210 015 231</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210015231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645061.618638 392581.626391</gml:lowerCorner>
        		<gml:upperCorner>645061.618638 392581.626391</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645061.618638 392581.626391</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 014 502</ms:GML_ID>
        <ms:NAZWA>210 014 502</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210014502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645228.490738 392716.586327</gml:lowerCorner>
        		<gml:upperCorner>645228.490738 392716.586327</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645228.490738 392716.586327</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 000 464</ms:GML_ID>
        <ms:NAZWA>413 000 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413000464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645902.766166 393112.048491</gml:lowerCorner>
        		<gml:upperCorner>645902.766166 393112.048491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645902.766166 393112.048491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 001 263</ms:GML_ID>
        <ms:NAZWA>413 001 263</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413001263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646946.345741 393351.205494</gml:lowerCorner>
        		<gml:upperCorner>646946.345741 393351.205494</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646946.345741 393351.205494</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 002 336</ms:GML_ID>
        <ms:NAZWA>413 002 336</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413002336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647766.921000 393513.659000</gml:lowerCorner>
        		<gml:upperCorner>647766.921000 393513.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647766.921000 393513.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 003 173</ms:GML_ID>
        <ms:NAZWA>413 003 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413003173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645387.833000 393524.707000</gml:lowerCorner>
        		<gml:upperCorner>645387.833000 393524.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645387.833000 393524.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 013 464</ms:GML_ID>
        <ms:NAZWA>210 013 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210013464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>650516.748000 393727.303000</gml:lowerCorner>
        		<gml:upperCorner>650516.748000 393727.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>650516.748000 393727.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 006 022</ms:GML_ID>
        <ms:NAZWA>413 006 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413006022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651214.892000 393914.838000</gml:lowerCorner>
        		<gml:upperCorner>651214.892000 393914.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651214.892000 393914.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 006 760</ms:GML_ID>
        <ms:NAZWA>413 006 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413006760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645544.352000 394733.328000</gml:lowerCorner>
        		<gml:upperCorner>645544.352000 394733.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645544.352000 394733.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 012 245</ms:GML_ID>
        <ms:NAZWA>210 012 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210012245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655681.817000 394982.030000</gml:lowerCorner>
        		<gml:upperCorner>655681.817000 394982.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655681.817000 394982.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 011 700</ms:GML_ID>
        <ms:NAZWA>413 011 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413011700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654788.041000 395172.405000</gml:lowerCorner>
        		<gml:upperCorner>654788.041000 395172.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654788.041000 395172.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 010 687</ms:GML_ID>
        <ms:NAZWA>413 010 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413010687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655383.499000 395238.438000</gml:lowerCorner>
        		<gml:upperCorner>655383.499000 395238.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655383.499000 395238.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.413 011 293</ms:GML_ID>
        <ms:NAZWA>413 011 293</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>413011293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645611.418000 395250.974000</gml:lowerCorner>
        		<gml:upperCorner>645611.418000 395250.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645611.418000 395250.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 011 723</ms:GML_ID>
        <ms:NAZWA>210 011 723</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210011723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645835.992791 396990.459112</gml:lowerCorner>
        		<gml:upperCorner>645835.992791 396990.459112</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645835.992791 396990.459112</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 009 969</ms:GML_ID>
        <ms:NAZWA>210 009 969</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210009969</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640521.107000 397512.546000</gml:lowerCorner>
        		<gml:upperCorner>640521.107000 397512.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640521.107000 397512.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 107 741</ms:GML_ID>
        <ms:NAZWA>203 107 741</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203107741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645913.995469 397593.156993</gml:lowerCorner>
        		<gml:upperCorner>645913.995469 397593.156993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645913.995469 397593.156993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 009 351</ms:GML_ID>
        <ms:NAZWA>210 009 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210009351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641385.689000 398418.357000</gml:lowerCorner>
        		<gml:upperCorner>641385.689000 398418.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641385.689000 398418.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 106 487</ms:GML_ID>
        <ms:NAZWA>203 106 487</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203106487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646034.012705 398520.689519</gml:lowerCorner>
        		<gml:upperCorner>646034.012705 398520.689519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646034.012705 398520.689519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 008 424</ms:GML_ID>
        <ms:NAZWA>210 008 424</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210008424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641796.756000 398851.322000</gml:lowerCorner>
        		<gml:upperCorner>641796.756000 398851.322000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641796.756000 398851.322000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 105 891</ms:GML_ID>
        <ms:NAZWA>203 105 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203105891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642285.546000 399365.023000</gml:lowerCorner>
        		<gml:upperCorner>642285.546000 399365.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642285.546000 399365.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 105 181</ms:GML_ID>
        <ms:NAZWA>203 105 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203105181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646201.248921 399816.657332</gml:lowerCorner>
        		<gml:upperCorner>646201.248921 399816.657332</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646201.248921 399816.657332</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 007 115</ms:GML_ID>
        <ms:NAZWA>210 007 115</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210007115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642936.353000 400049.429000</gml:lowerCorner>
        		<gml:upperCorner>642936.353000 400049.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642936.353000 400049.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 104 237</ms:GML_ID>
        <ms:NAZWA>203 104 237</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203104237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643300.811000 400432.243000</gml:lowerCorner>
        		<gml:upperCorner>643300.811000 400432.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643300.811000 400432.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 103 707</ms:GML_ID>
        <ms:NAZWA>203 103 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203103707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643527.574000 400670.789000</gml:lowerCorner>
        		<gml:upperCorner>643527.574000 400670.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643527.574000 400670.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 103 378</ms:GML_ID>
        <ms:NAZWA>203 103 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203103378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643839.193000 400997.502000</gml:lowerCorner>
        		<gml:upperCorner>643839.193000 400997.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643839.193000 400997.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 102 926</ms:GML_ID>
        <ms:NAZWA>203 102 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203102926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645521.159000 402861.295000</gml:lowerCorner>
        		<gml:upperCorner>645521.159000 402861.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645521.159000 402861.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 100 407</ms:GML_ID>
        <ms:NAZWA>203 100 407</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203100407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646514.966783 403009.257438</gml:lowerCorner>
        		<gml:upperCorner>646514.966783 403009.257438</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646514.966783 403009.257438</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 003 904</ms:GML_ID>
        <ms:NAZWA>210 003 904</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>210003904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645701.630000 403176.173000</gml:lowerCorner>
        		<gml:upperCorner>645701.630000 403176.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645701.630000 403176.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 100 046</ms:GML_ID>
        <ms:NAZWA>203 100 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203100046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640584.002000 403492.278000</gml:lowerCorner>
        		<gml:upperCorner>640584.002000 403492.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640584.002000 403492.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 302 360</ms:GML_ID>
        <ms:NAZWA>281 302 360</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281302360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636703.879000 422918.619000</gml:lowerCorner>
        		<gml:upperCorner>636703.879000 422918.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636703.879000 422918.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 177 766</ms:GML_ID>
        <ms:NAZWA>208 177 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208177766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636789.016000 403634.333000</gml:lowerCorner>
        		<gml:upperCorner>636789.016000 403634.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636789.016000 403634.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 298 490</ms:GML_ID>
        <ms:NAZWA>281 298 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281298490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636790.893000 423296.405000</gml:lowerCorner>
        		<gml:upperCorner>636790.893000 423296.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636790.893000 423296.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 177 378</ms:GML_ID>
        <ms:NAZWA>208 177 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208177378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636830.034000 419167.008000</gml:lowerCorner>
        		<gml:upperCorner>636830.034000 419167.008000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636830.034000 419167.008000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 181 643</ms:GML_ID>
        <ms:NAZWA>208 181 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208181643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637114.477000 403693.913000</gml:lowerCorner>
        		<gml:upperCorner>637114.477000 403693.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637114.477000 403693.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 298 821</ms:GML_ID>
        <ms:NAZWA>281 298 821</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281298821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639104.881000 403835.879000</gml:lowerCorner>
        		<gml:upperCorner>639104.881000 403835.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639104.881000 403835.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 300 839</ms:GML_ID>
        <ms:NAZWA>281 300 839</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281300839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640381.423000 415973.012000</gml:lowerCorner>
        		<gml:upperCorner>640381.423000 415973.012000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640381.423000 415973.012000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 186 602</ms:GML_ID>
        <ms:NAZWA>208 186 602</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208186602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641829.043000 414219.127000</gml:lowerCorner>
        		<gml:upperCorner>641829.043000 414219.127000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641829.043000 414219.127000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 189 082</ms:GML_ID>
        <ms:NAZWA>208 189 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208189082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642675.156560 413776.401511</gml:lowerCorner>
        		<gml:upperCorner>642675.156560 413776.401511</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642675.156560 413776.401511</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 190 037</ms:GML_ID>
        <ms:NAZWA>208 190 037</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208190037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642939.571000 403592.259000</gml:lowerCorner>
        		<gml:upperCorner>642939.571000 403592.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642939.571000 403592.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 304 721</ms:GML_ID>
        <ms:NAZWA>281 304 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281304721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643918.214000 403949.494000</gml:lowerCorner>
        		<gml:upperCorner>643918.214000 403949.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643918.214000 403949.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 305 765</ms:GML_ID>
        <ms:NAZWA>281 305 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281305765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644233.896000 412582.021000</gml:lowerCorner>
        		<gml:upperCorner>644233.896000 412582.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644233.896000 412582.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 192 022</ms:GML_ID>
        <ms:NAZWA>208 192 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208192022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644310.368000 404106.950000</gml:lowerCorner>
        		<gml:upperCorner>644310.368000 404106.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644310.368000 404106.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 306 189</ms:GML_ID>
        <ms:NAZWA>281 306 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281306189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644784.139000 412048.369000</gml:lowerCorner>
        		<gml:upperCorner>644784.139000 412048.369000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644784.139000 412048.369000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 192 788</ms:GML_ID>
        <ms:NAZWA>208 192 788</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208192788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644975.268000 404374.360000</gml:lowerCorner>
        		<gml:upperCorner>644975.268000 404374.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644975.268000 404374.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 306 906</ms:GML_ID>
        <ms:NAZWA>281 306 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281306906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645288.281000 411469.841000</gml:lowerCorner>
        		<gml:upperCorner>645288.281000 411469.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645288.281000 411469.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 193 563</ms:GML_ID>
        <ms:NAZWA>208 193 563</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208193563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645575.378000 411144.882000</gml:lowerCorner>
        		<gml:upperCorner>645575.378000 411144.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645575.378000 411144.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 194 010</ms:GML_ID>
        <ms:NAZWA>208 194 010</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208194010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646639.410000 405216.897000</gml:lowerCorner>
        		<gml:upperCorner>646639.410000 405216.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646639.410000 405216.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 308 774</ms:GML_ID>
        <ms:NAZWA>281 308 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281308774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646817.510000 410268.917000</gml:lowerCorner>
        		<gml:upperCorner>646817.510000 410268.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646817.510000 410268.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 195 643</ms:GML_ID>
        <ms:NAZWA>208 195 643</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208195643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647181.670000 409873.923000</gml:lowerCorner>
        		<gml:upperCorner>647181.670000 409873.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647181.670000 409873.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 196 203</ms:GML_ID>
        <ms:NAZWA>208 196 203</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208196203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647351.794000 409249.909000</gml:lowerCorner>
        		<gml:upperCorner>647351.794000 409249.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647351.794000 409249.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 196 858</ms:GML_ID>
        <ms:NAZWA>208 196 858</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208196858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647485.473000 408498.044000</gml:lowerCorner>
        		<gml:upperCorner>647485.473000 408498.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647485.473000 408498.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 197 623</ms:GML_ID>
        <ms:NAZWA>208 197 623</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208197623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648205.870000 407673.485000</gml:lowerCorner>
        		<gml:upperCorner>648205.870000 407673.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648205.870000 407673.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 198 743</ms:GML_ID>
        <ms:NAZWA>208 198 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208198743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648519.332000 407394.914000</gml:lowerCorner>
        		<gml:upperCorner>648519.332000 407394.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648519.332000 407394.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 199 162</ms:GML_ID>
        <ms:NAZWA>208 199 162</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208199162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648795.612143 407031.555025</gml:lowerCorner>
        		<gml:upperCorner>648795.612143 407031.555025</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648795.612143 407031.555025</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 199 630</ms:GML_ID>
        <ms:NAZWA>208 199 630</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208199630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649878.191000 408368.102000</gml:lowerCorner>
        		<gml:upperCorner>649878.191000 408368.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649878.191000 408368.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 093 245</ms:GML_ID>
        <ms:NAZWA>203 093 245</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203093245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651318.570000 410206.189000</gml:lowerCorner>
        		<gml:upperCorner>651318.570000 410206.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651318.570000 410206.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 090 879</ms:GML_ID>
        <ms:NAZWA>203 090 879</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203090879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651759.948000 408275.834000</gml:lowerCorner>
        		<gml:upperCorner>651759.948000 408275.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651759.948000 408275.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 005 262</ms:GML_ID>
        <ms:NAZWA>211 005 262</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211005262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652165.666000 408138.541000</gml:lowerCorner>
        		<gml:upperCorner>652165.666000 408138.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652165.666000 408138.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 005 689</ms:GML_ID>
        <ms:NAZWA>211 005 689</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211005689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652611.189766 411400.005306</gml:lowerCorner>
        		<gml:upperCorner>652611.189766 411400.005306</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652611.189766 411400.005306</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 089 117</ms:GML_ID>
        <ms:NAZWA>203 089 117</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203089117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653218.031000 412614.519000</gml:lowerCorner>
        		<gml:upperCorner>653218.031000 412614.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653218.031000 412614.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 087 753</ms:GML_ID>
        <ms:NAZWA>203 087 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203087753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653373.968000 412960.071000</gml:lowerCorner>
        		<gml:upperCorner>653373.968000 412960.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653373.968000 412960.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 087 374</ms:GML_ID>
        <ms:NAZWA>203 087 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203087374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653951.336445 407704.820754</gml:lowerCorner>
        		<gml:upperCorner>653951.336445 407704.820754</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653951.336445 407704.820754</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.211 007 533</ms:GML_ID>
        <ms:NAZWA>211 007 533</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>211007533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636661.922000 456968.529000</gml:lowerCorner>
        		<gml:upperCorner>636661.922000 456968.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636661.922000 456968.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 017 608</ms:GML_ID>
        <ms:NAZWA>215 017 608</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215017608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637245.850000 441035.775000</gml:lowerCorner>
        		<gml:upperCorner>637245.850000 441035.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637245.850000 441035.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 076 803</ms:GML_ID>
        <ms:NAZWA>201 076 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201076803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638340.348000 441076.475000</gml:lowerCorner>
        		<gml:upperCorner>638340.348000 441076.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638340.348000 441076.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 077 902</ms:GML_ID>
        <ms:NAZWA>201 077 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201077902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638940.610000 451888.972000</gml:lowerCorner>
        		<gml:upperCorner>638940.610000 451888.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638940.610000 451888.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 023 357</ms:GML_ID>
        <ms:NAZWA>215 023 357</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215023357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639044.740000 451608.246000</gml:lowerCorner>
        		<gml:upperCorner>639044.740000 451608.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639044.740000 451608.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 023 658</ms:GML_ID>
        <ms:NAZWA>215 023 658</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215023658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639230.367000 451018.189000</gml:lowerCorner>
        		<gml:upperCorner>639230.367000 451018.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639230.367000 451018.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 024 276</ms:GML_ID>
        <ms:NAZWA>215 024 276</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215024276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639515.252000 441166.554000</gml:lowerCorner>
        		<gml:upperCorner>639515.252000 441166.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639515.252000 441166.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 079 081</ms:GML_ID>
        <ms:NAZWA>201 079 081</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201079081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640383.543000 449151.911000</gml:lowerCorner>
        		<gml:upperCorner>640383.543000 449151.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640383.543000 449151.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 026 484</ms:GML_ID>
        <ms:NAZWA>215 026 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215026484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640723.945000 448867.732000</gml:lowerCorner>
        		<gml:upperCorner>640723.945000 448867.732000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640723.945000 448867.732000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 026 931</ms:GML_ID>
        <ms:NAZWA>215 026 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215026931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641352.080000 441481.582000</gml:lowerCorner>
        		<gml:upperCorner>641352.080000 441481.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641352.080000 441481.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 080 948</ms:GML_ID>
        <ms:NAZWA>201 080 948</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201080948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>641845.976000 448186.598000</gml:lowerCorner>
        		<gml:upperCorner>641845.976000 448186.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>641845.976000 448186.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 028 247</ms:GML_ID>
        <ms:NAZWA>215 028 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215028247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642492.601000 441590.456000</gml:lowerCorner>
        		<gml:upperCorner>642492.601000 441590.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642492.601000 441590.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 082 098</ms:GML_ID>
        <ms:NAZWA>201 082 098</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201082098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642601.659000 448008.695000</gml:lowerCorner>
        		<gml:upperCorner>642601.659000 448008.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642601.659000 448008.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 029 025</ms:GML_ID>
        <ms:NAZWA>215 029 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215029025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643654.291000 441645.871000</gml:lowerCorner>
        		<gml:upperCorner>643654.291000 441645.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643654.291000 441645.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 083 261</ms:GML_ID>
        <ms:NAZWA>201 083 261</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201083261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644441.102000 447832.345000</gml:lowerCorner>
        		<gml:upperCorner>644441.102000 447832.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644441.102000 447832.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 030 905</ms:GML_ID>
        <ms:NAZWA>215 030 905</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215030905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644469.677000 441685.037000</gml:lowerCorner>
        		<gml:upperCorner>644469.677000 441685.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644469.677000 441685.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 084 078</ms:GML_ID>
        <ms:NAZWA>201 084 078</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201084078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645814.491000 441748.965000</gml:lowerCorner>
        		<gml:upperCorner>645814.491000 441748.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645814.491000 441748.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 085 426</ms:GML_ID>
        <ms:NAZWA>201 085 426</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201085426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645943.127000 447116.571000</gml:lowerCorner>
        		<gml:upperCorner>645943.127000 447116.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645943.127000 447116.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 032 580</ms:GML_ID>
        <ms:NAZWA>215 032 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215032580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646385.922000 441775.996000</gml:lowerCorner>
        		<gml:upperCorner>646385.922000 441775.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646385.922000 441775.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 085 998</ms:GML_ID>
        <ms:NAZWA>201 085 998</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201085998</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636770.585176 475363.699571</gml:lowerCorner>
        		<gml:upperCorner>636770.585176 475363.699571</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636770.585176 475363.699571</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 439 391</ms:GML_ID>
        <ms:NAZWA>131 439 391</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131439391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638015.897000 475928.184000</gml:lowerCorner>
        		<gml:upperCorner>638015.897000 475928.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638015.897000 475928.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 440 762</ms:GML_ID>
        <ms:NAZWA>131 440 762</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131440762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>640030.592000 476372.656000</gml:lowerCorner>
        		<gml:upperCorner>640030.592000 476372.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>640030.592000 476372.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 442 849</ms:GML_ID>
        <ms:NAZWA>131 442 849</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131442849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>643517.110000 476586.056000</gml:lowerCorner>
        		<gml:upperCorner>643517.110000 476586.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>643517.110000 476586.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 446 365</ms:GML_ID>
        <ms:NAZWA>131 446 365</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131446365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646016.200578 478151.261470</gml:lowerCorner>
        		<gml:upperCorner>646016.200578 478151.261470</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646016.200578 478151.261470</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 449 333</ms:GML_ID>
        <ms:NAZWA>131 449 333</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131449333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647135.909000 478565.777000</gml:lowerCorner>
        		<gml:upperCorner>647135.909000 478565.777000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647135.909000 478565.777000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 450 525</ms:GML_ID>
        <ms:NAZWA>131 450 525</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131450525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644049.728419 491797.722107</gml:lowerCorner>
        		<gml:upperCorner>644049.728419 491797.722107</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644049.728419 491797.722107</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 086 605</ms:GML_ID>
        <ms:NAZWA>207 086 605</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207086605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645064.629187 492376.342035</gml:lowerCorner>
        		<gml:upperCorner>645064.629187 492376.342035</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645064.629187 492376.342035</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 087 810</ms:GML_ID>
        <ms:NAZWA>207 087 810</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207087810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>642751.373000 492661.880000</gml:lowerCorner>
        		<gml:upperCorner>642751.373000 492661.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>642751.373000 492661.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 084 964</ms:GML_ID>
        <ms:NAZWA>207 084 964</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207084964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646718.425000 493381.475000</gml:lowerCorner>
        		<gml:upperCorner>646718.425000 493381.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646718.425000 493381.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 089 758</ms:GML_ID>
        <ms:NAZWA>207 089 758</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207089758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637835.406000 494065.915000</gml:lowerCorner>
        		<gml:upperCorner>637835.406000 494065.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637835.406000 494065.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 079 541</ms:GML_ID>
        <ms:NAZWA>207 079 541</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207079541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631212.178000 494263.926000</gml:lowerCorner>
        		<gml:upperCorner>631212.178000 494263.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631212.178000 494263.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 070 830</ms:GML_ID>
        <ms:NAZWA>207 070 830</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207070830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653469.533000 496226.519000</gml:lowerCorner>
        		<gml:upperCorner>653469.533000 496226.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653469.533000 496226.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 097 529</ms:GML_ID>
        <ms:NAZWA>207 097 529</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207097529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655283.168000 496901.574000</gml:lowerCorner>
        		<gml:upperCorner>655283.168000 496901.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655283.168000 496901.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 099 543</ms:GML_ID>
        <ms:NAZWA>207 099 543</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207099543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>657372.325966 497800.756952</gml:lowerCorner>
        		<gml:upperCorner>657372.325966 497800.756952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>657372.325966 497800.756952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 101 876</ms:GML_ID>
        <ms:NAZWA>207 101 876</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207101876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651865.387807 500105.484046</gml:lowerCorner>
        		<gml:upperCorner>651865.387807 500105.484046</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651865.387807 500105.484046</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.218 047 484</ms:GML_ID>
        <ms:NAZWA>218 047 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>218047484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>651852.569412 501124.536299</gml:lowerCorner>
        		<gml:upperCorner>651852.569412 501124.536299</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>651852.569412 501124.536299</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.218 046 444</ms:GML_ID>
        <ms:NAZWA>218 046 444</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>218046444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>652018.510709 501949.759597</gml:lowerCorner>
        		<gml:upperCorner>652018.510709 501949.759597</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>652018.510709 501949.759597</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.218 045 604</ms:GML_ID>
        <ms:NAZWA>218 045 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>218045604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>653697.798093 504386.572352</gml:lowerCorner>
        		<gml:upperCorner>653697.798093 504386.572352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>653697.798093 504386.572352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.218 042 618</ms:GML_ID>
        <ms:NAZWA>218 042 618</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>218042618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632912.391000 439649.347000</gml:lowerCorner>
        		<gml:upperCorner>632912.391000 439649.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632912.391000 439649.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 159 415</ms:GML_ID>
        <ms:NAZWA>208 159 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208159415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633260.685000 441008.623000</gml:lowerCorner>
        		<gml:upperCorner>633260.685000 441008.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633260.685000 441008.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 072 815</ms:GML_ID>
        <ms:NAZWA>201 072 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201072815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634340.906000 441025.936000</gml:lowerCorner>
        		<gml:upperCorner>634340.906000 441025.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634340.906000 441025.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 073 895</ms:GML_ID>
        <ms:NAZWA>201 073 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201073895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635199.564000 441041.057000</gml:lowerCorner>
        		<gml:upperCorner>635199.564000 441041.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635199.564000 441041.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 074 756</ms:GML_ID>
        <ms:NAZWA>201 074 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201074756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636051.172000 441054.276000</gml:lowerCorner>
        		<gml:upperCorner>636051.172000 441054.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636051.172000 441054.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 075 608</ms:GML_ID>
        <ms:NAZWA>201 075 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201075608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628376.499000 441079.128000</gml:lowerCorner>
        		<gml:upperCorner>628376.499000 441079.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628376.499000 441079.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 067 899</ms:GML_ID>
        <ms:NAZWA>201 067 899</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201067899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629107.219000 441131.926000</gml:lowerCorner>
        		<gml:upperCorner>629107.219000 441131.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629107.219000 441131.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 068 632</ms:GML_ID>
        <ms:NAZWA>201 068 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201068632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629893.012000 441188.509000</gml:lowerCorner>
        		<gml:upperCorner>629893.012000 441188.509000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629893.012000 441188.509000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 069 422</ms:GML_ID>
        <ms:NAZWA>201 069 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201069422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626341.308000 441224.597000</gml:lowerCorner>
        		<gml:upperCorner>626341.308000 441224.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626341.308000 441224.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 065 856</ms:GML_ID>
        <ms:NAZWA>201 065 856</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201065856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631655.462259 441240.694852</gml:lowerCorner>
        		<gml:upperCorner>631655.462259 441240.694852</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631655.462259 441240.694852</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 071 192</ms:GML_ID>
        <ms:NAZWA>201 071 192</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201071192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625794.243000 441266.028000</gml:lowerCorner>
        		<gml:upperCorner>625794.243000 441266.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625794.243000 441266.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 065 307</ms:GML_ID>
        <ms:NAZWA>201 065 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201065307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625052.303000 441276.685000</gml:lowerCorner>
        		<gml:upperCorner>625052.303000 441276.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625052.303000 441276.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 064 565</ms:GML_ID>
        <ms:NAZWA>201 064 565</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201064565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624420.642000 441285.571000</gml:lowerCorner>
        		<gml:upperCorner>624420.642000 441285.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624420.642000 441285.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 063 932</ms:GML_ID>
        <ms:NAZWA>201 063 932</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201063932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631437.811000 441642.845000</gml:lowerCorner>
        		<gml:upperCorner>631437.811000 441642.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631437.811000 441642.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 156 196</ms:GML_ID>
        <ms:NAZWA>208 156 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208156196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631050.821000 443037.973000</gml:lowerCorner>
        		<gml:upperCorner>631050.821000 443037.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631050.821000 443037.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 154 742</ms:GML_ID>
        <ms:NAZWA>208 154 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208154742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630808.555000 443538.777000</gml:lowerCorner>
        		<gml:upperCorner>630808.555000 443538.777000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630808.555000 443538.777000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 154 182</ms:GML_ID>
        <ms:NAZWA>208 154 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208154182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629524.128000 446442.140000</gml:lowerCorner>
        		<gml:upperCorner>629524.128000 446442.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629524.128000 446442.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 150 857</ms:GML_ID>
        <ms:NAZWA>208 150 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208150857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629426.466266 447026.668484</gml:lowerCorner>
        		<gml:upperCorner>629426.466266 447026.668484</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629426.466266 447026.668484</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 150 267</ms:GML_ID>
        <ms:NAZWA>208 150 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208150267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629308.545996 447677.416157</gml:lowerCorner>
        		<gml:upperCorner>629308.545996 447677.416157</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629308.545996 447677.416157</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 149 602</ms:GML_ID>
        <ms:NAZWA>208 149 602</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208149602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629126.580000 448291.799000</gml:lowerCorner>
        		<gml:upperCorner>629126.580000 448291.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629126.580000 448291.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 148 960</ms:GML_ID>
        <ms:NAZWA>208 148 960</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208148960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629037.309000 448568.934000</gml:lowerCorner>
        		<gml:upperCorner>629037.309000 448568.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629037.309000 448568.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 148 668</ms:GML_ID>
        <ms:NAZWA>208 148 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208148668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628910.076000 449008.776000</gml:lowerCorner>
        		<gml:upperCorner>628910.076000 449008.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628910.076000 449008.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 148 207</ms:GML_ID>
        <ms:NAZWA>208 148 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208148207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628562.707000 451429.365000</gml:lowerCorner>
        		<gml:upperCorner>628562.707000 451429.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628562.707000 451429.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 145 760</ms:GML_ID>
        <ms:NAZWA>208 145 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208145760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627010.019000 454308.406000</gml:lowerCorner>
        		<gml:upperCorner>627010.019000 454308.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627010.019000 454308.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 142 429</ms:GML_ID>
        <ms:NAZWA>208 142 429</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208142429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627001.938000 454853.345000</gml:lowerCorner>
        		<gml:upperCorner>627001.938000 454853.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627001.938000 454853.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 141 883</ms:GML_ID>
        <ms:NAZWA>208 141 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208141883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625965.177000 456590.019000</gml:lowerCorner>
        		<gml:upperCorner>625965.177000 456590.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625965.177000 456590.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 139 716</ms:GML_ID>
        <ms:NAZWA>208 139 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208139716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625529.558000 457032.134000</gml:lowerCorner>
        		<gml:upperCorner>625529.558000 457032.134000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625529.558000 457032.134000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 139 032</ms:GML_ID>
        <ms:NAZWA>208 139 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208139032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636501.744000 457596.891000</gml:lowerCorner>
        		<gml:upperCorner>636501.744000 457596.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636501.744000 457596.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 016 956</ms:GML_ID>
        <ms:NAZWA>215 016 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215016956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636038.550000 459448.122000</gml:lowerCorner>
        		<gml:upperCorner>636038.550000 459448.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636038.550000 459448.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 015 041</ms:GML_ID>
        <ms:NAZWA>215 015 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215015041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635984.241000 459861.911000</gml:lowerCorner>
        		<gml:upperCorner>635984.241000 459861.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635984.241000 459861.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 014 623</ms:GML_ID>
        <ms:NAZWA>215 014 623</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215014623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635892.564000 460562.317000</gml:lowerCorner>
        		<gml:upperCorner>635892.564000 460562.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635892.564000 460562.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 013 918</ms:GML_ID>
        <ms:NAZWA>215 013 918</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215013918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635403.491000 461592.343000</gml:lowerCorner>
        		<gml:upperCorner>635403.491000 461592.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635403.491000 461592.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 012 691</ms:GML_ID>
        <ms:NAZWA>215 012 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215012691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624331.410904 463279.588477</gml:lowerCorner>
        		<gml:upperCorner>624331.410904 463279.588477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624331.410904 463279.588477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 421 420</ms:GML_ID>
        <ms:NAZWA>131 421 420</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131421420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632910.242000 463699.336000</gml:lowerCorner>
        		<gml:upperCorner>632910.242000 463699.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632910.242000 463699.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 009 335</ms:GML_ID>
        <ms:NAZWA>215 009 335</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215009335</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632293.709917 464292.037051</gml:lowerCorner>
        		<gml:upperCorner>632293.709917 464292.037051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632293.709917 464292.037051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 008 472</ms:GML_ID>
        <ms:NAZWA>215 008 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215008472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627288.507000 465492.451000</gml:lowerCorner>
        		<gml:upperCorner>627288.507000 465492.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627288.507000 465492.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 425 119</ms:GML_ID>
        <ms:NAZWA>131 425 119</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131425119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629052.444000 466135.935000</gml:lowerCorner>
        		<gml:upperCorner>629052.444000 466135.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629052.444000 466135.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 004 617</ms:GML_ID>
        <ms:NAZWA>215 004 617</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215004617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627066.874000 466181.656000</gml:lowerCorner>
        		<gml:upperCorner>627066.874000 466181.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627066.874000 466181.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 127 306</ms:GML_ID>
        <ms:NAZWA>208 127 306</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208127306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628193.486000 466201.253000</gml:lowerCorner>
        		<gml:upperCorner>628193.486000 466201.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628193.486000 466201.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 426 272</ms:GML_ID>
        <ms:NAZWA>131 426 272</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131426272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>628330.116000 466262.502000</gml:lowerCorner>
        		<gml:upperCorner>628330.116000 466262.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>628330.116000 466262.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.215 003 866</ms:GML_ID>
        <ms:NAZWA>215 003 866</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>215003866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634957.516000 474512.340000</gml:lowerCorner>
        		<gml:upperCorner>634957.516000 474512.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634957.516000 474512.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 437 386</ms:GML_ID>
        <ms:NAZWA>131 437 386</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131437386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648244.991000 362719.412000</gml:lowerCorner>
        		<gml:upperCorner>648244.991000 362719.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648244.991000 362719.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 046 342</ms:GML_ID>
        <ms:NAZWA>210 046 342</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210046342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648188.628846 363198.514336</gml:lowerCorner>
        		<gml:upperCorner>648188.628846 363198.514336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648188.628846 363198.514336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 045 860</ms:GML_ID>
        <ms:NAZWA>210 045 860</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210045860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648169.954279 363369.413889</gml:lowerCorner>
        		<gml:upperCorner>648169.954279 363369.413889</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648169.954279 363369.413889</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 045 689</ms:GML_ID>
        <ms:NAZWA>210 045 689</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210045689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648068.179135 364147.905925</gml:lowerCorner>
        		<gml:upperCorner>648068.179135 364147.905925</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648068.179135 364147.905925</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 044 901</ms:GML_ID>
        <ms:NAZWA>210 044 901</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210044901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648079.226000 364691.649000</gml:lowerCorner>
        		<gml:upperCorner>648079.226000 364691.649000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648079.226000 364691.649000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 044 355</ms:GML_ID>
        <ms:NAZWA>210 044 355</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210044355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648175.717000 365217.007000</gml:lowerCorner>
        		<gml:upperCorner>648175.717000 365217.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648175.717000 365217.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 043 820</ms:GML_ID>
        <ms:NAZWA>210 043 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210043820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648234.025000 365537.245000</gml:lowerCorner>
        		<gml:upperCorner>648234.025000 365537.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648234.025000 365537.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 043 494</ms:GML_ID>
        <ms:NAZWA>210 043 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210043494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648350.276000 366209.166000</gml:lowerCorner>
        		<gml:upperCorner>648350.276000 366209.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648350.276000 366209.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 042 811</ms:GML_ID>
        <ms:NAZWA>210 042 811</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210042811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647828.165000 367969.137000</gml:lowerCorner>
        		<gml:upperCorner>647828.165000 367969.137000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647828.165000 367969.137000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 040 994</ms:GML_ID>
        <ms:NAZWA>210 040 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210040994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647419.842000 368809.043000</gml:lowerCorner>
        		<gml:upperCorner>647419.842000 368809.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647419.842000 368809.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 040 009</ms:GML_ID>
        <ms:NAZWA>210 040 009</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210040009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>646634.094000 370015.997000</gml:lowerCorner>
        		<gml:upperCorner>646634.094000 370015.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>646634.094000 370015.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 038 556</ms:GML_ID>
        <ms:NAZWA>210 038 556</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210038556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615829.542000 373314.619000</gml:lowerCorner>
        		<gml:upperCorner>615829.542000 373314.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615829.542000 373314.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 142 438</ms:GML_ID>
        <ms:NAZWA>203 142 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203142438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645025.563000 373357.561000</gml:lowerCorner>
        		<gml:upperCorner>645025.563000 373357.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645025.563000 373357.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 034 584</ms:GML_ID>
        <ms:NAZWA>210 034 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210034584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645551.553455 376223.556590</gml:lowerCorner>
        		<gml:upperCorner>645551.553455 376223.556590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645551.553455 376223.556590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 031 638</ms:GML_ID>
        <ms:NAZWA>210 031 638</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210031638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618276.758000 376285.530000</gml:lowerCorner>
        		<gml:upperCorner>618276.758000 376285.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618276.758000 376285.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 138 578</ms:GML_ID>
        <ms:NAZWA>203 138 578</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203138578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618986.306000 377140.966000</gml:lowerCorner>
        		<gml:upperCorner>618986.306000 377140.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618986.306000 377140.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 137 475</ms:GML_ID>
        <ms:NAZWA>203 137 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203137475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>645560.714130 378042.102610</gml:lowerCorner>
        		<gml:upperCorner>645560.714130 378042.102610</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>645560.714130 378042.102610</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 029 808</ms:GML_ID>
        <ms:NAZWA>210 029 808</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210029808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621818.567000 380222.889000</gml:lowerCorner>
        		<gml:upperCorner>621818.567000 380222.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621818.567000 380222.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 133 276</ms:GML_ID>
        <ms:NAZWA>203 133 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203133276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622797.700000 381097.481000</gml:lowerCorner>
        		<gml:upperCorner>622797.700000 381097.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622797.700000 381097.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 131 963</ms:GML_ID>
        <ms:NAZWA>203 131 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203131963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644972.179000 381258.926000</gml:lowerCorner>
        		<gml:upperCorner>644972.179000 381258.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644972.179000 381258.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 026 529</ms:GML_ID>
        <ms:NAZWA>210 026 529</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210026529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623497.267000 381681.878000</gml:lowerCorner>
        		<gml:upperCorner>623497.267000 381681.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623497.267000 381681.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 131 051</ms:GML_ID>
        <ms:NAZWA>203 131 051</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203131051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644732.503000 382407.175000</gml:lowerCorner>
        		<gml:upperCorner>644732.503000 382407.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644732.503000 382407.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 025 355</ms:GML_ID>
        <ms:NAZWA>210 025 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210025355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625517.130000 383151.155000</gml:lowerCorner>
        		<gml:upperCorner>625517.130000 383151.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625517.130000 383151.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 128 550</ms:GML_ID>
        <ms:NAZWA>203 128 550</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203128550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626226.231000 383666.226000</gml:lowerCorner>
        		<gml:upperCorner>626226.231000 383666.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626226.231000 383666.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 127 671</ms:GML_ID>
        <ms:NAZWA>203 127 671</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203127671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627006.384000 384240.761000</gml:lowerCorner>
        		<gml:upperCorner>627006.384000 384240.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627006.384000 384240.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 126 704</ms:GML_ID>
        <ms:NAZWA>203 126 704</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203126704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627872.867000 385018.452000</gml:lowerCorner>
        		<gml:upperCorner>627872.867000 385018.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627872.867000 385018.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 125 539</ms:GML_ID>
        <ms:NAZWA>203 125 539</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203125539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>644016.514000 385839.023000</gml:lowerCorner>
        		<gml:upperCorner>644016.514000 385839.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>644016.514000 385839.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.210 021 864</ms:GML_ID>
        <ms:NAZWA>210 021 864</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>210021864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613786.473000 402949.324000</gml:lowerCorner>
        		<gml:upperCorner>613786.473000 402949.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613786.473000 402949.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 274 848</ms:GML_ID>
        <ms:NAZWA>281 274 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281274848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622300.544000 403090.265000</gml:lowerCorner>
        		<gml:upperCorner>622300.544000 403090.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622300.544000 403090.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 283 745</ms:GML_ID>
        <ms:NAZWA>281 283 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281283745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627548.501000 403153.614000</gml:lowerCorner>
        		<gml:upperCorner>627548.501000 403153.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627548.501000 403153.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 289 042</ms:GML_ID>
        <ms:NAZWA>281 289 042</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281289042</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634363.503000 403192.028000</gml:lowerCorner>
        		<gml:upperCorner>634363.503000 403192.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634363.503000 403192.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 296 022</ms:GML_ID>
        <ms:NAZWA>281 296 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281296022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634782.805000 403268.683000</gml:lowerCorner>
        		<gml:upperCorner>634782.805000 403268.683000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634782.805000 403268.683000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 296 449</ms:GML_ID>
        <ms:NAZWA>281 296 449</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281296449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632970.590000 403309.230000</gml:lowerCorner>
        		<gml:upperCorner>632970.590000 403309.230000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632970.590000 403309.230000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 294 614</ms:GML_ID>
        <ms:NAZWA>281 294 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281294614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629851.290000 403369.027000</gml:lowerCorner>
        		<gml:upperCorner>629851.290000 403369.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629851.290000 403369.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 291 359</ms:GML_ID>
        <ms:NAZWA>281 291 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281291359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615201.093000 403543.420000</gml:lowerCorner>
        		<gml:upperCorner>615201.093000 403543.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615201.093000 403543.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 276 585</ms:GML_ID>
        <ms:NAZWA>281 276 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281276585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620128.134000 403556.949000</gml:lowerCorner>
        		<gml:upperCorner>620128.134000 403556.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620128.134000 403556.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 281 516</ms:GML_ID>
        <ms:NAZWA>281 281 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281281516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616365.415000 403557.494000</gml:lowerCorner>
        		<gml:upperCorner>616365.415000 403557.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616365.415000 403557.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 277 749</ms:GML_ID>
        <ms:NAZWA>281 277 749</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281277749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614472.597000 403561.003000</gml:lowerCorner>
        		<gml:upperCorner>614472.597000 403561.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614472.597000 403561.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 275 855</ms:GML_ID>
        <ms:NAZWA>281 275 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281275855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619475.128000 403563.210000</gml:lowerCorner>
        		<gml:upperCorner>619475.128000 403563.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619475.128000 403563.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 280 862</ms:GML_ID>
        <ms:NAZWA>281 280 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281280862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617919.023000 403578.790000</gml:lowerCorner>
        		<gml:upperCorner>617919.023000 403578.790000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617919.023000 403578.790000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 279 304</ms:GML_ID>
        <ms:NAZWA>281 279 304</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281279304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617538.003000 403582.438000</gml:lowerCorner>
        		<gml:upperCorner>617538.003000 403582.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617538.003000 403582.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 278 924</ms:GML_ID>
        <ms:NAZWA>281 278 924</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281278924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617193.402000 403586.112000</gml:lowerCorner>
        		<gml:upperCorner>617193.402000 403586.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617193.402000 403586.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 278 580</ms:GML_ID>
        <ms:NAZWA>281 278 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281278580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.69">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630821.478000 418308.191000</gml:lowerCorner>
        		<gml:upperCorner>630821.478000 418308.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.69.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630821.478000 418308.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>69</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 009 302</ms:GML_ID>
        <ms:NAZWA>241 009 302</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241009302</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.70">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629893.277000 418555.005000</gml:lowerCorner>
        		<gml:upperCorner>629893.277000 418555.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.70.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629893.277000 418555.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>70</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 010 263</ms:GML_ID>
        <ms:NAZWA>241 010 263</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241010263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.71">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629335.616000 418703.327000</gml:lowerCorner>
        		<gml:upperCorner>629335.616000 418703.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.71.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629335.616000 418703.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>71</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 010 839</ms:GML_ID>
        <ms:NAZWA>241 010 839</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241010839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>629774.070000 386726.237000</gml:lowerCorner>
        		<gml:upperCorner>629774.070000 386726.237000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>629774.070000 386726.237000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 122 984</ms:GML_ID>
        <ms:NAZWA>203 122 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203122984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>630937.465000 387771.772000</gml:lowerCorner>
        		<gml:upperCorner>630937.465000 387771.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>630937.465000 387771.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 121 417</ms:GML_ID>
        <ms:NAZWA>203 121 417</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203121417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>631771.741000 388521.348000</gml:lowerCorner>
        		<gml:upperCorner>631771.741000 388521.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>631771.741000 388521.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 120 295</ms:GML_ID>
        <ms:NAZWA>203 120 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203120295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632191.909000 388903.591000</gml:lowerCorner>
        		<gml:upperCorner>632191.909000 388903.591000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632191.909000 388903.591000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 119 727</ms:GML_ID>
        <ms:NAZWA>203 119 727</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203119727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632779.267000 389493.015000</gml:lowerCorner>
        		<gml:upperCorner>632779.267000 389493.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632779.267000 389493.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 118 895</ms:GML_ID>
        <ms:NAZWA>203 118 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203118895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633455.275000 390171.771000</gml:lowerCorner>
        		<gml:upperCorner>633455.275000 390171.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633455.275000 390171.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 117 936</ms:GML_ID>
        <ms:NAZWA>203 117 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203117936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634032.819000 390751.385000</gml:lowerCorner>
        		<gml:upperCorner>634032.819000 390751.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634032.819000 390751.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 117 118</ms:GML_ID>
        <ms:NAZWA>203 117 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203117118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634602.915000 391324.337000</gml:lowerCorner>
        		<gml:upperCorner>634602.915000 391324.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634602.915000 391324.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 116 308</ms:GML_ID>
        <ms:NAZWA>203 116 308</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203116308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635125.096000 391849.360000</gml:lowerCorner>
        		<gml:upperCorner>635125.096000 391849.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635125.096000 391849.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 115 568</ms:GML_ID>
        <ms:NAZWA>203 115 568</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203115568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635646.580000 392390.943000</gml:lowerCorner>
        		<gml:upperCorner>635646.580000 392390.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635646.580000 392390.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 114 815</ms:GML_ID>
        <ms:NAZWA>203 114 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203114815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636746.792000 393542.799000</gml:lowerCorner>
        		<gml:upperCorner>636746.792000 393542.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636746.792000 393542.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 113 221</ms:GML_ID>
        <ms:NAZWA>203 113 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203113221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>638794.783000 395695.436000</gml:lowerCorner>
        		<gml:upperCorner>638794.783000 395695.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>638794.783000 395695.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 110 248</ms:GML_ID>
        <ms:NAZWA>203 110 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203110248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639137.377000 396055.117000</gml:lowerCorner>
        		<gml:upperCorner>639137.377000 396055.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639137.377000 396055.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 109 752</ms:GML_ID>
        <ms:NAZWA>203 109 752</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203109752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639361.078000 396290.761000</gml:lowerCorner>
        		<gml:upperCorner>639361.078000 396290.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639361.078000 396290.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 109 426</ms:GML_ID>
        <ms:NAZWA>203 109 426</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203109426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613601.845000 402454.669000</gml:lowerCorner>
        		<gml:upperCorner>613601.845000 402454.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613601.845000 402454.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 274 320</ms:GML_ID>
        <ms:NAZWA>281 274 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281274320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624440.278000 402835.799000</gml:lowerCorner>
        		<gml:upperCorner>624440.278000 402835.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624440.278000 402835.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 285 910</ms:GML_ID>
        <ms:NAZWA>281 285 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281285910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623683.238000 402853.664000</gml:lowerCorner>
        		<gml:upperCorner>623683.238000 402853.664000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623683.238000 402853.664000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 285 151</ms:GML_ID>
        <ms:NAZWA>281 285 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281285151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623273.621000 402897.871000</gml:lowerCorner>
        		<gml:upperCorner>623273.621000 402897.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623273.621000 402897.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 284 742</ms:GML_ID>
        <ms:NAZWA>281 284 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281284742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606075.273457 444824.188174</gml:lowerCorner>
        		<gml:upperCorner>606075.273457 444824.188174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606075.273457 444824.188174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 394 684</ms:GML_ID>
        <ms:NAZWA>131 394 684</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131394684</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607720.511779 446412.585169</gml:lowerCorner>
        		<gml:upperCorner>607720.511779 446412.585169</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607720.511779 446412.585169</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 396 970</ms:GML_ID>
        <ms:NAZWA>131 396 970</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131396970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608970.908000 447618.036000</gml:lowerCorner>
        		<gml:upperCorner>608970.908000 447618.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608970.908000 447618.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 398 702</ms:GML_ID>
        <ms:NAZWA>131 398 702</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131398702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609384.747000 448017.004000</gml:lowerCorner>
        		<gml:upperCorner>609384.747000 448017.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609384.747000 448017.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 399 285</ms:GML_ID>
        <ms:NAZWA>131 399 285</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131399285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610569.114000 449159.229000</gml:lowerCorner>
        		<gml:upperCorner>610569.114000 449159.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610569.114000 449159.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 400 933</ms:GML_ID>
        <ms:NAZWA>131 400 933</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131400933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611442.793000 450388.404000</gml:lowerCorner>
        		<gml:upperCorner>611442.793000 450388.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611442.793000 450388.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 402 453</ms:GML_ID>
        <ms:NAZWA>131 402 453</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131402453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612059.326945 451568.175907</gml:lowerCorner>
        		<gml:upperCorner>612059.326945 451568.175907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612059.326945 451568.175907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 403 781</ms:GML_ID>
        <ms:NAZWA>131 403 781</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131403781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612748.568000 452851.227000</gml:lowerCorner>
        		<gml:upperCorner>612748.568000 452851.227000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612748.568000 452851.227000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 405 242</ms:GML_ID>
        <ms:NAZWA>131 405 242</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131405242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613037.215000 453396.765000</gml:lowerCorner>
        		<gml:upperCorner>613037.215000 453396.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613037.215000 453396.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 405 859</ms:GML_ID>
        <ms:NAZWA>131 405 859</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131405859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.65">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615435.491000 459295.298000</gml:lowerCorner>
        		<gml:upperCorner>615435.491000 459295.298000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.65.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615435.491000 459295.298000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>65</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.240 003 827</ms:GML_ID>
        <ms:NAZWA>240 003 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>240003827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619396.016000 459575.267000</gml:lowerCorner>
        		<gml:upperCorner>619396.016000 459575.267000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619396.016000 459575.267000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 415 120</ms:GML_ID>
        <ms:NAZWA>131 415 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131415120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.64">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615002.358000 459914.889000</gml:lowerCorner>
        		<gml:upperCorner>615002.358000 459914.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.64.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615002.358000 459914.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>64</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.240 003 070</ms:GML_ID>
        <ms:NAZWA>240 003 070</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>240003070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620236.148000 460285.987000</gml:lowerCorner>
        		<gml:upperCorner>620236.148000 460285.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620236.148000 460285.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 416 239</ms:GML_ID>
        <ms:NAZWA>131 416 239</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131416239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.63">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615062.037092 460399.015748</gml:lowerCorner>
        		<gml:upperCorner>615062.037092 460399.015748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.63.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615062.037092 460399.015748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>63</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.240 002 564</ms:GML_ID>
        <ms:NAZWA>240 002 564</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>240002564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622364.314000 461251.606000</gml:lowerCorner>
        		<gml:upperCorner>622364.314000 461251.606000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622364.314000 461251.606000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 418 577</ms:GML_ID>
        <ms:NAZWA>131 418 577</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131418577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623828.722000 461490.154000</gml:lowerCorner>
        		<gml:upperCorner>623828.722000 461490.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623828.722000 461490.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 133 627</ms:GML_ID>
        <ms:NAZWA>208 133 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208133627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623578.136000 462283.094000</gml:lowerCorner>
        		<gml:upperCorner>623578.136000 462283.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623578.136000 462283.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 132 794</ms:GML_ID>
        <ms:NAZWA>208 132 794</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208132794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623679.066000 462650.425000</gml:lowerCorner>
        		<gml:upperCorner>623679.066000 462650.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623679.066000 462650.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 420 503</ms:GML_ID>
        <ms:NAZWA>131 420 503</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131420503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627152.418000 467815.417000</gml:lowerCorner>
        		<gml:upperCorner>627152.418000 467815.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627152.418000 467815.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 125 666</ms:GML_ID>
        <ms:NAZWA>208 125 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208125666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627094.961000 468638.899000</gml:lowerCorner>
        		<gml:upperCorner>627094.961000 468638.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627094.961000 468638.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 124 840</ms:GML_ID>
        <ms:NAZWA>208 124 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208124840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627059.318000 469151.673000</gml:lowerCorner>
        		<gml:upperCorner>627059.318000 469151.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627059.318000 469151.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 124 326</ms:GML_ID>
        <ms:NAZWA>208 124 326</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208124326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>627181.665000 470636.109000</gml:lowerCorner>
        		<gml:upperCorner>627181.665000 470636.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>627181.665000 470636.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 122 822</ms:GML_ID>
        <ms:NAZWA>208 122 822</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208122822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626631.829000 475215.876000</gml:lowerCorner>
        		<gml:upperCorner>626631.829000 475215.876000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626631.829000 475215.876000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 118 190</ms:GML_ID>
        <ms:NAZWA>208 118 190</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208118190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626518.795216 476507.756986</gml:lowerCorner>
        		<gml:upperCorner>626518.795216 476507.756986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626518.795216 476507.756986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 116 892</ms:GML_ID>
        <ms:NAZWA>208 116 892</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208116892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604295.593000 476882.407000</gml:lowerCorner>
        		<gml:upperCorner>604295.593000 476882.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604295.593000 476882.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 034 521</ms:GML_ID>
        <ms:NAZWA>207 034 521</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207034521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605819.574000 477546.500000</gml:lowerCorner>
        		<gml:upperCorner>605819.574000 477546.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605819.574000 477546.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 036 226</ms:GML_ID>
        <ms:NAZWA>207 036 226</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207036226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606316.218000 478009.354000</gml:lowerCorner>
        		<gml:upperCorner>606316.218000 478009.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606316.218000 478009.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 036 914</ms:GML_ID>
        <ms:NAZWA>207 036 914</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207036914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607860.947000 478707.399000</gml:lowerCorner>
        		<gml:upperCorner>607860.947000 478707.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607860.947000 478707.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 038 619</ms:GML_ID>
        <ms:NAZWA>207 038 619</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207038619</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609771.213608 479658.643041</gml:lowerCorner>
        		<gml:upperCorner>609771.213608 479658.643041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609771.213608 479658.643041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 040 763</ms:GML_ID>
        <ms:NAZWA>207 040 763</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207040763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625148.808000 480908.529000</gml:lowerCorner>
        		<gml:upperCorner>625148.808000 480908.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625148.808000 480908.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 112 263</ms:GML_ID>
        <ms:NAZWA>208 112 263</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208112263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616155.293000 481007.840000</gml:lowerCorner>
        		<gml:upperCorner>616155.293000 481007.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616155.293000 481007.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 048 026</ms:GML_ID>
        <ms:NAZWA>207 048 026</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207048026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615314.513000 481150.527000</gml:lowerCorner>
        		<gml:upperCorner>615314.513000 481150.527000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615314.513000 481150.527000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 047 109</ms:GML_ID>
        <ms:NAZWA>207 047 109</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207047109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615008.649000 481292.281000</gml:lowerCorner>
        		<gml:upperCorner>615008.649000 481292.281000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615008.649000 481292.281000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 046 772</ms:GML_ID>
        <ms:NAZWA>207 046 772</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207046772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617312.381588 481480.509570</gml:lowerCorner>
        		<gml:upperCorner>617312.381588 481480.509570</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617312.381588 481480.509570</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 049 415</ms:GML_ID>
        <ms:NAZWA>207 049 415</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207049415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617079.707504 481522.025735</gml:lowerCorner>
        		<gml:upperCorner>617079.707504 481522.025735</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617079.707504 481522.025735</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 049 180</ms:GML_ID>
        <ms:NAZWA>207 049 180</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207049180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617765.205459 481528.799329</gml:lowerCorner>
        		<gml:upperCorner>617765.205459 481528.799329</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617765.205459 481528.799329</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 049 874</ms:GML_ID>
        <ms:NAZWA>207 049 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207049874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613597.482000 481567.983000</gml:lowerCorner>
        		<gml:upperCorner>613597.482000 481567.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613597.482000 481567.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 045 310</ms:GML_ID>
        <ms:NAZWA>207 045 310</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207045310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613304.276088 481576.821236</gml:lowerCorner>
        		<gml:upperCorner>613304.276088 481576.821236</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613304.276088 481576.821236</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 045 017</ms:GML_ID>
        <ms:NAZWA>207 045 017</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207045017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618096.641000 481607.665000</gml:lowerCorner>
        		<gml:upperCorner>618096.641000 481607.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618096.641000 481607.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 050 217</ms:GML_ID>
        <ms:NAZWA>207 050 217</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207050217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618572.835239 481727.960311</gml:lowerCorner>
        		<gml:upperCorner>618572.835239 481727.960311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618572.835239 481727.960311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 050 710</ms:GML_ID>
        <ms:NAZWA>207 050 710</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207050710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619549.806000 481909.330000</gml:lowerCorner>
        		<gml:upperCorner>619549.806000 481909.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619549.806000 481909.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 051 704</ms:GML_ID>
        <ms:NAZWA>207 051 704</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207051704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620758.454000 482341.368000</gml:lowerCorner>
        		<gml:upperCorner>620758.454000 482341.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620758.454000 482341.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 053 006</ms:GML_ID>
        <ms:NAZWA>207 053 006</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207053006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622103.346000 483116.721000</gml:lowerCorner>
        		<gml:upperCorner>622103.346000 483116.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622103.346000 483116.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 054 561</ms:GML_ID>
        <ms:NAZWA>207 054 561</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207054561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623883.446766 483282.130961</gml:lowerCorner>
        		<gml:upperCorner>623883.446766 483282.130961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623883.446766 483282.130961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 056 374</ms:GML_ID>
        <ms:NAZWA>207 056 374</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207056374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>623368.726530 483346.108770</gml:lowerCorner>
        		<gml:upperCorner>623368.726530 483346.108770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>623368.726530 483346.108770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 055 850</ms:GML_ID>
        <ms:NAZWA>207 055 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207055850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624159.209641 486223.573689</gml:lowerCorner>
        		<gml:upperCorner>624159.209641 486223.573689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624159.209641 486223.573689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 059 449</ms:GML_ID>
        <ms:NAZWA>207 059 449</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207059449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624103.423833 486230.623998</gml:lowerCorner>
        		<gml:upperCorner>624103.423833 486230.623998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624103.423833 486230.623998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 106 738</ms:GML_ID>
        <ms:NAZWA>208 106 738</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208106738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624466.122000 487115.327000</gml:lowerCorner>
        		<gml:upperCorner>624466.122000 487115.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624466.122000 487115.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 060 414</ms:GML_ID>
        <ms:NAZWA>207 060 414</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207060414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>624643.307000 487616.565000</gml:lowerCorner>
        		<gml:upperCorner>624643.307000 487616.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>624643.307000 487616.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 060 946</ms:GML_ID>
        <ms:NAZWA>207 060 946</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207060946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>622574.086000 489314.793000</gml:lowerCorner>
        		<gml:upperCorner>622574.086000 489314.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>622574.086000 489314.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 103 018</ms:GML_ID>
        <ms:NAZWA>208 103 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208103018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>626378.128000 489767.123000</gml:lowerCorner>
        		<gml:upperCorner>626378.128000 489767.123000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>626378.128000 489767.123000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 063 749</ms:GML_ID>
        <ms:NAZWA>207 063 749</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207063749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621634.334000 492097.654000</gml:lowerCorner>
        		<gml:upperCorner>621634.334000 492097.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621634.334000 492097.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 100 064</ms:GML_ID>
        <ms:NAZWA>208 100 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208100064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621290.717000 492695.198000</gml:lowerCorner>
        		<gml:upperCorner>621290.717000 492695.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621290.717000 492695.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 099 367</ms:GML_ID>
        <ms:NAZWA>208 099 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208099367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619736.364000 495084.823000</gml:lowerCorner>
        		<gml:upperCorner>619736.364000 495084.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619736.364000 495084.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 096 486</ms:GML_ID>
        <ms:NAZWA>208 096 486</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208096486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619608.291000 495367.148000</gml:lowerCorner>
        		<gml:upperCorner>619608.291000 495367.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619608.291000 495367.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 096 177</ms:GML_ID>
        <ms:NAZWA>208 096 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208096177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619265.507089 496133.830885</gml:lowerCorner>
        		<gml:upperCorner>619265.507089 496133.830885</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619265.507089 496133.830885</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 095 336</ms:GML_ID>
        <ms:NAZWA>208 095 336</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208095336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618529.730000 497742.390000</gml:lowerCorner>
        		<gml:upperCorner>618529.730000 497742.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618529.730000 497742.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 093 566</ms:GML_ID>
        <ms:NAZWA>208 093 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208093566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>618419.114000 497985.544000</gml:lowerCorner>
        		<gml:upperCorner>618419.114000 497985.544000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>618419.114000 497985.544000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 093 299</ms:GML_ID>
        <ms:NAZWA>208 093 299</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208093299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601948.921000 499933.247000</gml:lowerCorner>
        		<gml:upperCorner>601948.921000 499933.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601948.921000 499933.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 177 283</ms:GML_ID>
        <ms:NAZWA>353 177 283</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353177283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601122.821421 440241.732195</gml:lowerCorner>
        		<gml:upperCorner>601122.821421 440241.732195</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601122.821421 440241.732195</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 387 925</ms:GML_ID>
        <ms:NAZWA>131 387 925</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131387925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602742.644394 441622.562767</gml:lowerCorner>
        		<gml:upperCorner>602742.644394 441622.562767</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602742.644394 441622.562767</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 390 056</ms:GML_ID>
        <ms:NAZWA>131 390 056</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131390056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603972.942185 442796.991845</gml:lowerCorner>
        		<gml:upperCorner>603972.942185 442796.991845</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603972.942185 442796.991845</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 391 760</ms:GML_ID>
        <ms:NAZWA>131 391 760</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131391760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605093.335844 443877.143010</gml:lowerCorner>
        		<gml:upperCorner>605093.335844 443877.143010</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605093.335844 443877.143010</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 393 316</ms:GML_ID>
        <ms:NAZWA>131 393 316</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131393316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605555.332000 438118.346000</gml:lowerCorner>
        		<gml:upperCorner>605555.332000 438118.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605555.332000 438118.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 044 643</ms:GML_ID>
        <ms:NAZWA>201 044 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201044643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606082.081000 438262.797000</gml:lowerCorner>
        		<gml:upperCorner>606082.081000 438262.797000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606082.081000 438262.797000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 045 189</ms:GML_ID>
        <ms:NAZWA>201 045 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201045189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606513.227000 438381.311000</gml:lowerCorner>
        		<gml:upperCorner>606513.227000 438381.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606513.227000 438381.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 045 638</ms:GML_ID>
        <ms:NAZWA>201 045 638</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201045638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606747.917000 438445.167000</gml:lowerCorner>
        		<gml:upperCorner>606747.917000 438445.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606747.917000 438445.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 045 881</ms:GML_ID>
        <ms:NAZWA>201 045 881</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201045881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607091.593000 438540.025000</gml:lowerCorner>
        		<gml:upperCorner>607091.593000 438540.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607091.593000 438540.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 046 237</ms:GML_ID>
        <ms:NAZWA>201 046 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201046237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608030.011000 438798.390000</gml:lowerCorner>
        		<gml:upperCorner>608030.011000 438798.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608030.011000 438798.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 047 211</ms:GML_ID>
        <ms:NAZWA>201 047 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201047211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610121.149000 439280.442000</gml:lowerCorner>
        		<gml:upperCorner>610121.149000 439280.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610121.149000 439280.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 049 363</ms:GML_ID>
        <ms:NAZWA>201 049 363</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201049363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610629.689367 439366.331647</gml:lowerCorner>
        		<gml:upperCorner>610629.689367 439366.331647</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610629.689367 439366.331647</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 049 878</ms:GML_ID>
        <ms:NAZWA>201 049 878</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201049878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611850.639366 439575.792128</gml:lowerCorner>
        		<gml:upperCorner>611850.639366 439575.792128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611850.639366 439575.792128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 051 117</ms:GML_ID>
        <ms:NAZWA>201 051 117</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201051117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613027.924000 439778.161000</gml:lowerCorner>
        		<gml:upperCorner>613027.924000 439778.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613027.924000 439778.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 052 311</ms:GML_ID>
        <ms:NAZWA>201 052 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201052311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614148.701000 439969.312000</gml:lowerCorner>
        		<gml:upperCorner>614148.701000 439969.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614148.701000 439969.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 053 450</ms:GML_ID>
        <ms:NAZWA>201 053 450</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201053450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615689.181000 440232.114000</gml:lowerCorner>
        		<gml:upperCorner>615689.181000 440232.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615689.181000 440232.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 055 015</ms:GML_ID>
        <ms:NAZWA>201 055 015</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201055015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616876.900000 440435.672000</gml:lowerCorner>
        		<gml:upperCorner>616876.900000 440435.672000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616876.900000 440435.672000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 056 218</ms:GML_ID>
        <ms:NAZWA>201 056 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201056218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617279.496000 440551.162000</gml:lowerCorner>
        		<gml:upperCorner>617279.496000 440551.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617279.496000 440551.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 056 640</ms:GML_ID>
        <ms:NAZWA>201 056 640</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201056640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617940.938000 440902.273000</gml:lowerCorner>
        		<gml:upperCorner>617940.938000 440902.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617940.938000 440902.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 057 389</ms:GML_ID>
        <ms:NAZWA>201 057 389</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201057389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>620614.276000 441065.738000</gml:lowerCorner>
        		<gml:upperCorner>620614.276000 441065.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>620614.276000 441065.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 060 111</ms:GML_ID>
        <ms:NAZWA>201 060 111</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201060111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621070.747000 441090.113000</gml:lowerCorner>
        		<gml:upperCorner>621070.747000 441090.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621070.747000 441090.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 060 570</ms:GML_ID>
        <ms:NAZWA>201 060 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201060570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599766.502282 436587.452292</gml:lowerCorner>
        		<gml:upperCorner>599766.502282 436587.452292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599766.502282 436587.452292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 038 645</ms:GML_ID>
        <ms:NAZWA>201 038 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201038645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602343.002903 437211.941137</gml:lowerCorner>
        		<gml:upperCorner>602343.002903 437211.941137</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602343.002903 437211.941137</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 041 299</ms:GML_ID>
        <ms:NAZWA>201 041 299</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201041299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603475.126971 437484.711088</gml:lowerCorner>
        		<gml:upperCorner>603475.126971 437484.711088</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603475.126971 437484.711088</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 042 464</ms:GML_ID>
        <ms:NAZWA>201 042 464</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201042464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604856.938000 437925.530000</gml:lowerCorner>
        		<gml:upperCorner>604856.938000 437925.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604856.938000 437925.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 043 918</ms:GML_ID>
        <ms:NAZWA>201 043 918</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201043918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607697.881000 429366.125000</gml:lowerCorner>
        		<gml:upperCorner>607697.881000 429366.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607697.881000 429366.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 040 686</ms:GML_ID>
        <ms:NAZWA>241 040 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241040686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608695.414000 428214.858000</gml:lowerCorner>
        		<gml:upperCorner>608695.414000 428214.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608695.414000 428214.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 039 165</ms:GML_ID>
        <ms:NAZWA>241 039 165</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241039165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609385.563000 427416.595000</gml:lowerCorner>
        		<gml:upperCorner>609385.563000 427416.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609385.563000 427416.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 038 105</ms:GML_ID>
        <ms:NAZWA>241 038 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241038105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609960.083000 426701.869000</gml:lowerCorner>
        		<gml:upperCorner>609960.083000 426701.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609960.083000 426701.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 037 188</ms:GML_ID>
        <ms:NAZWA>241 037 188</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241037188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610504.613000 425490.834000</gml:lowerCorner>
        		<gml:upperCorner>610504.613000 425490.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610504.613000 425490.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 035 858</ms:GML_ID>
        <ms:NAZWA>241 035 858</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241035858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611524.052000 422978.051000</gml:lowerCorner>
        		<gml:upperCorner>611524.052000 422978.051000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611524.052000 422978.051000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 033 144</ms:GML_ID>
        <ms:NAZWA>241 033 144</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241033144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616022.126000 421462.129000</gml:lowerCorner>
        		<gml:upperCorner>616022.126000 421462.129000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616022.126000 421462.129000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 027 691</ms:GML_ID>
        <ms:NAZWA>241 027 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241027691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617923.431000 421281.669000</gml:lowerCorner>
        		<gml:upperCorner>617923.431000 421281.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617923.431000 421281.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 025 761</ms:GML_ID>
        <ms:NAZWA>241 025 761</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241025761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.74">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>619739.845000 421311.965000</gml:lowerCorner>
        		<gml:upperCorner>619739.845000 421311.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.74.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>619739.845000 421311.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>74</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 023 891</ms:GML_ID>
        <ms:NAZWA>241 023 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241023891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.73">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>621970.744000 422996.902000</gml:lowerCorner>
        		<gml:upperCorner>621970.744000 422996.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.73.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>621970.744000 422996.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>73</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 020 449</ms:GML_ID>
        <ms:NAZWA>241 020 449</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241020449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.72">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>625052.307545 420618.710683</gml:lowerCorner>
        		<gml:upperCorner>625052.307545 420618.710683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.72.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>625052.307545 420618.710683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>72</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 016 357</ms:GML_ID>
        <ms:NAZWA>241 016 357</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241016357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.68">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>632602.980000 419278.598000</gml:lowerCorner>
        		<gml:upperCorner>632602.980000 419278.598000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.68.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>632602.980000 419278.598000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>68</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 007 085</ms:GML_ID>
        <ms:NAZWA>241 007 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241007085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.67">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634115.810000 420501.442000</gml:lowerCorner>
        		<gml:upperCorner>634115.810000 420501.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.67.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634115.810000 420501.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>67</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 005 135</ms:GML_ID>
        <ms:NAZWA>241 005 135</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241005135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634299.231000 436867.256000</gml:lowerCorner>
        		<gml:upperCorner>634299.231000 436867.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634299.231000 436867.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 162 538</ms:GML_ID>
        <ms:NAZWA>208 162 538</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208162538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634575.846000 436394.084000</gml:lowerCorner>
        		<gml:upperCorner>634575.846000 436394.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634575.846000 436394.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 163 086</ms:GML_ID>
        <ms:NAZWA>208 163 086</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208163086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>634897.153247 435869.411290</gml:lowerCorner>
        		<gml:upperCorner>634897.153247 435869.411290</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>634897.153247 435869.411290</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 163 703</ms:GML_ID>
        <ms:NAZWA>208 163 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208163703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635213.823000 426561.003000</gml:lowerCorner>
        		<gml:upperCorner>635213.823000 426561.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635213.823000 426561.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 173 599</ms:GML_ID>
        <ms:NAZWA>208 173 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208173599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635219.374000 435368.404000</gml:lowerCorner>
        		<gml:upperCorner>635219.374000 435368.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635219.374000 435368.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 164 299</ms:GML_ID>
        <ms:NAZWA>208 164 299</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208164299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635379.243000 431800.601000</gml:lowerCorner>
        		<gml:upperCorner>635379.243000 431800.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635379.243000 431800.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 168 179</ms:GML_ID>
        <ms:NAZWA>208 168 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208168179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635387.818000 425730.837000</gml:lowerCorner>
        		<gml:upperCorner>635387.818000 425730.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635387.818000 425730.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 174 449</ms:GML_ID>
        <ms:NAZWA>208 174 449</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208174449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635434.091000 433227.943000</gml:lowerCorner>
        		<gml:upperCorner>635434.091000 433227.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635434.091000 433227.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 166 741</ms:GML_ID>
        <ms:NAZWA>208 166 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208166741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635444.661000 433890.316000</gml:lowerCorner>
        		<gml:upperCorner>635444.661000 433890.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635444.661000 433890.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 166 071</ms:GML_ID>
        <ms:NAZWA>208 166 071</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208166071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635449.244000 432989.534000</gml:lowerCorner>
        		<gml:upperCorner>635449.244000 432989.534000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635449.244000 432989.534000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 166 981</ms:GML_ID>
        <ms:NAZWA>208 166 981</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208166981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635469.644000 432662.744000</gml:lowerCorner>
        		<gml:upperCorner>635469.644000 432662.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635469.644000 432662.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 167 308</ms:GML_ID>
        <ms:NAZWA>208 167 308</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208167308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.66">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635532.269000 421664.753000</gml:lowerCorner>
        		<gml:upperCorner>635532.269000 421664.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.66.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635532.269000 421664.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>66</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.241 003 291</ms:GML_ID>
        <ms:NAZWA>241 003 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>241003291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635572.236000 434875.463000</gml:lowerCorner>
        		<gml:upperCorner>635572.236000 434875.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635572.236000 434875.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 164 908</ms:GML_ID>
        <ms:NAZWA>208 164 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208164908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>635647.781909 425151.621230</gml:lowerCorner>
        		<gml:upperCorner>635647.781909 425151.621230</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>635647.781909 425151.621230</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 175 091</ms:GML_ID>
        <ms:NAZWA>208 175 091</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208175091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636397.405000 421568.927000</gml:lowerCorner>
        		<gml:upperCorner>636397.405000 421568.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636397.405000 421568.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 179 151</ms:GML_ID>
        <ms:NAZWA>208 179 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208179151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636416.411000 420440.240000</gml:lowerCorner>
        		<gml:upperCorner>636416.411000 420440.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636416.411000 420440.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 180 290</ms:GML_ID>
        <ms:NAZWA>208 180 290</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208180290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636502.279000 422040.899000</gml:lowerCorner>
        		<gml:upperCorner>636502.279000 422040.899000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636502.279000 422040.899000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 178 667</ms:GML_ID>
        <ms:NAZWA>208 178 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208178667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596796.384000 357671.057000</gml:lowerCorner>
        		<gml:upperCorner>596796.384000 357671.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596796.384000 357671.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 167 505</ms:GML_ID>
        <ms:NAZWA>203 167 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203167505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597941.443000 358889.792000</gml:lowerCorner>
        		<gml:upperCorner>597941.443000 358889.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597941.443000 358889.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 165 834</ms:GML_ID>
        <ms:NAZWA>203 165 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203165834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601019.836000 362034.349000</gml:lowerCorner>
        		<gml:upperCorner>601019.836000 362034.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601019.836000 362034.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 161 428</ms:GML_ID>
        <ms:NAZWA>203 161 428</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203161428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602544.429000 363917.172000</gml:lowerCorner>
        		<gml:upperCorner>602544.429000 363917.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602544.429000 363917.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 159 002</ms:GML_ID>
        <ms:NAZWA>203 159 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203159002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603698.697000 365244.217000</gml:lowerCorner>
        		<gml:upperCorner>603698.697000 365244.217000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603698.697000 365244.217000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 157 242</ms:GML_ID>
        <ms:NAZWA>203 157 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203157242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604670.322147 366308.708764</gml:lowerCorner>
        		<gml:upperCorner>604670.322147 366308.708764</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604670.322147 366308.708764</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 155 798</ms:GML_ID>
        <ms:NAZWA>203 155 798</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203155798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604993.587000 366638.374000</gml:lowerCorner>
        		<gml:upperCorner>604993.587000 366638.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604993.587000 366638.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 155 336</ms:GML_ID>
        <ms:NAZWA>203 155 336</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203155336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605272.726000 366931.801000</gml:lowerCorner>
        		<gml:upperCorner>605272.726000 366931.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605272.726000 366931.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 154 933</ms:GML_ID>
        <ms:NAZWA>203 154 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203154933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606134.403000 367531.911000</gml:lowerCorner>
        		<gml:upperCorner>606134.403000 367531.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606134.403000 367531.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 153 874</ms:GML_ID>
        <ms:NAZWA>203 153 874</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203153874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607210.985000 368051.494000</gml:lowerCorner>
        		<gml:upperCorner>607210.985000 368051.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607210.985000 368051.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 152 679</ms:GML_ID>
        <ms:NAZWA>203 152 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203152679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608328.702000 368592.554000</gml:lowerCorner>
        		<gml:upperCorner>608328.702000 368592.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608328.702000 368592.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 151 434</ms:GML_ID>
        <ms:NAZWA>203 151 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203151434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607802.082583 395101.896637</gml:lowerCorner>
        		<gml:upperCorner>607802.082583 395101.896637</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607802.082583 395101.896637</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 264 230</ms:GML_ID>
        <ms:NAZWA>281 264 230</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281264230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606721.622895 395280.494557</gml:lowerCorner>
        		<gml:upperCorner>606721.622895 395280.494557</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606721.622895 395280.494557</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 263 104</ms:GML_ID>
        <ms:NAZWA>281 263 104</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281263104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606295.513215 395419.948381</gml:lowerCorner>
        		<gml:upperCorner>606295.513215 395419.948381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606295.513215 395419.948381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 262 656</ms:GML_ID>
        <ms:NAZWA>281 262 656</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281262656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606069.456035 395493.923121</gml:lowerCorner>
        		<gml:upperCorner>606069.456035 395493.923121</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606069.456035 395493.923121</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 262 418</ms:GML_ID>
        <ms:NAZWA>281 262 418</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281262418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608780.382163 395752.943707</gml:lowerCorner>
        		<gml:upperCorner>608780.382163 395752.943707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608780.382163 395752.943707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 265 411</ms:GML_ID>
        <ms:NAZWA>281 265 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281265411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604439.830989 395927.793401</gml:lowerCorner>
        		<gml:upperCorner>604439.830989 395927.793401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604439.830989 395927.793401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 260 725</ms:GML_ID>
        <ms:NAZWA>281 260 725</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281260725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604066.594914 395987.111827</gml:lowerCorner>
        		<gml:upperCorner>604066.594914 395987.111827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604066.594914 395987.111827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 260 347</ms:GML_ID>
        <ms:NAZWA>281 260 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281260347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602801.496959 396214.849927</gml:lowerCorner>
        		<gml:upperCorner>602801.496959 396214.849927</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602801.496959 396214.849927</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 259 060</ms:GML_ID>
        <ms:NAZWA>281 259 060</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281259060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609688.481000 396434.156000</gml:lowerCorner>
        		<gml:upperCorner>609688.481000 396434.156000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609688.481000 396434.156000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 266 546</ms:GML_ID>
        <ms:NAZWA>281 266 546</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281266546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601467.976424 396483.234757</gml:lowerCorner>
        		<gml:upperCorner>601467.976424 396483.234757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601467.976424 396483.234757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 257 706</ms:GML_ID>
        <ms:NAZWA>281 257 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281257706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600821.549611 396670.378969</gml:lowerCorner>
        		<gml:upperCorner>600821.549611 396670.378969</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600821.549611 396670.378969</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 257 025</ms:GML_ID>
        <ms:NAZWA>281 257 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281257025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599704.017997 397052.749489</gml:lowerCorner>
        		<gml:upperCorner>599704.017997 397052.749489</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599704.017997 397052.749489</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 255 846</ms:GML_ID>
        <ms:NAZWA>281 255 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281255846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599399.277992 397156.975010</gml:lowerCorner>
        		<gml:upperCorner>599399.277992 397156.975010</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599399.277992 397156.975010</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 255 520</ms:GML_ID>
        <ms:NAZWA>281 255 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281255520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598549.995000 397800.840000</gml:lowerCorner>
        		<gml:upperCorner>598549.995000 397800.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598549.995000 397800.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 254 389</ms:GML_ID>
        <ms:NAZWA>281 254 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281254389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598200.696000 398582.903000</gml:lowerCorner>
        		<gml:upperCorner>598200.696000 398582.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598200.696000 398582.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 253 532</ms:GML_ID>
        <ms:NAZWA>281 253 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281253532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597901.104000 399258.475000</gml:lowerCorner>
        		<gml:upperCorner>597901.104000 399258.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597901.104000 399258.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 252 793</ms:GML_ID>
        <ms:NAZWA>281 252 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281252793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612213.978000 399562.516000</gml:lowerCorner>
        		<gml:upperCorner>612213.978000 399562.516000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612213.978000 399562.516000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 271 079</ms:GML_ID>
        <ms:NAZWA>281 271 079</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281271079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612407.849000 399733.202000</gml:lowerCorner>
        		<gml:upperCorner>612407.849000 399733.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612407.849000 399733.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 271 340</ms:GML_ID>
        <ms:NAZWA>281 271 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281271340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612577.353000 400032.357000</gml:lowerCorner>
        		<gml:upperCorner>612577.353000 400032.357000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612577.353000 400032.357000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 271 683</ms:GML_ID>
        <ms:NAZWA>281 271 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281271683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597837.272000 400728.563000</gml:lowerCorner>
        		<gml:upperCorner>597837.272000 400728.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597837.272000 400728.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 251 317</ms:GML_ID>
        <ms:NAZWA>281 251 317</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281251317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613162.445000 401279.602000</gml:lowerCorner>
        		<gml:upperCorner>613162.445000 401279.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613162.445000 401279.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 273 064</ms:GML_ID>
        <ms:NAZWA>281 273 064</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281273064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613271.413000 401571.015000</gml:lowerCorner>
        		<gml:upperCorner>613271.413000 401571.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613271.413000 401571.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 273 377</ms:GML_ID>
        <ms:NAZWA>281 273 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281273377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597814.398000 401642.371000</gml:lowerCorner>
        		<gml:upperCorner>597814.398000 401642.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597814.398000 401642.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 250 403</ms:GML_ID>
        <ms:NAZWA>281 250 403</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281250403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597832.325000 402465.836000</gml:lowerCorner>
        		<gml:upperCorner>597832.325000 402465.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597832.325000 402465.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 249 579</ms:GML_ID>
        <ms:NAZWA>281 249 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281249579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597838.934000 402675.102000</gml:lowerCorner>
        		<gml:upperCorner>597838.934000 402675.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597838.934000 402675.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 249 369</ms:GML_ID>
        <ms:NAZWA>281 249 369</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281249369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597912.977000 404868.656000</gml:lowerCorner>
        		<gml:upperCorner>597912.977000 404868.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597912.977000 404868.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 247 155</ms:GML_ID>
        <ms:NAZWA>281 247 155</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281247155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597569.608556 405109.996440</gml:lowerCorner>
        		<gml:upperCorner>597569.608556 405109.996440</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597569.608556 405109.996440</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 246 722</ms:GML_ID>
        <ms:NAZWA>281 246 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281246722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596790.171000 405301.796000</gml:lowerCorner>
        		<gml:upperCorner>596790.171000 405301.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596790.171000 405301.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 245 920</ms:GML_ID>
        <ms:NAZWA>281 245 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281245920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596592.424000 405351.226000</gml:lowerCorner>
        		<gml:upperCorner>596592.424000 405351.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596592.424000 405351.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 245 713</ms:GML_ID>
        <ms:NAZWA>281 245 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281245713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595038.735000 405757.648000</gml:lowerCorner>
        		<gml:upperCorner>595038.735000 405757.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595038.735000 405757.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 244 108</ms:GML_ID>
        <ms:NAZWA>281 244 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281244108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590052.576000 451827.268000</gml:lowerCorner>
        		<gml:upperCorner>590052.576000 451827.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590052.576000 451827.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 093 098</ms:GML_ID>
        <ms:NAZWA>209 093 098</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209093098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590549.563000 452360.231000</gml:lowerCorner>
        		<gml:upperCorner>590549.563000 452360.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590549.563000 452360.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 092 368</ms:GML_ID>
        <ms:NAZWA>209 092 368</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209092368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590869.325000 452762.802000</gml:lowerCorner>
        		<gml:upperCorner>590869.325000 452762.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590869.325000 452762.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 091 852</ms:GML_ID>
        <ms:NAZWA>209 091 852</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209091852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591931.927000 455057.445000</gml:lowerCorner>
        		<gml:upperCorner>591931.927000 455057.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591931.927000 455057.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 089 312</ms:GML_ID>
        <ms:NAZWA>209 089 312</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209089312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592028.516000 455271.812000</gml:lowerCorner>
        		<gml:upperCorner>592028.516000 455271.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592028.516000 455271.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 089 077</ms:GML_ID>
        <ms:NAZWA>209 089 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209089077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592561.363000 456451.133000</gml:lowerCorner>
        		<gml:upperCorner>592561.363000 456451.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592561.363000 456451.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 087 781</ms:GML_ID>
        <ms:NAZWA>209 087 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209087781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593056.973000 457548.922000</gml:lowerCorner>
        		<gml:upperCorner>593056.973000 457548.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593056.973000 457548.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 086 576</ms:GML_ID>
        <ms:NAZWA>209 086 576</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209086576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593418.208000 458351.650000</gml:lowerCorner>
        		<gml:upperCorner>593418.208000 458351.650000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593418.208000 458351.650000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 085 695</ms:GML_ID>
        <ms:NAZWA>209 085 695</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209085695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593820.021000 459222.978272</gml:lowerCorner>
        		<gml:upperCorner>593820.021000 459222.978272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593820.021000 459222.978272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 084 732</ms:GML_ID>
        <ms:NAZWA>209 084 732</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209084732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593962.207000 459862.441000</gml:lowerCorner>
        		<gml:upperCorner>593962.207000 459862.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593962.207000 459862.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 084 073</ms:GML_ID>
        <ms:NAZWA>209 084 073</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209084073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593626.794000 461659.563000</gml:lowerCorner>
        		<gml:upperCorner>593626.794000 461659.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593626.794000 461659.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 082 243</ms:GML_ID>
        <ms:NAZWA>209 082 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209082243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593420.337000 462499.740000</gml:lowerCorner>
        		<gml:upperCorner>593420.337000 462499.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593420.337000 462499.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 081 370</ms:GML_ID>
        <ms:NAZWA>209 081 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209081370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593299.587000 462988.565000</gml:lowerCorner>
        		<gml:upperCorner>593299.587000 462988.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593299.587000 462988.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 080 874</ms:GML_ID>
        <ms:NAZWA>209 080 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209080874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593221.898000 463379.837000</gml:lowerCorner>
        		<gml:upperCorner>593221.898000 463379.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593221.898000 463379.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 080 474</ms:GML_ID>
        <ms:NAZWA>209 080 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209080474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593251.910000 465883.846000</gml:lowerCorner>
        		<gml:upperCorner>593251.910000 465883.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593251.910000 465883.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 077 966</ms:GML_ID>
        <ms:NAZWA>209 077 966</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209077966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593307.790000 467489.180000</gml:lowerCorner>
        		<gml:upperCorner>593307.790000 467489.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593307.790000 467489.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 076 357</ms:GML_ID>
        <ms:NAZWA>209 076 357</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209076357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593303.708000 468276.518000</gml:lowerCorner>
        		<gml:upperCorner>593303.708000 468276.518000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593303.708000 468276.518000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 075 571</ms:GML_ID>
        <ms:NAZWA>209 075 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209075571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593263.398000 468497.844000</gml:lowerCorner>
        		<gml:upperCorner>593263.398000 468497.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593263.398000 468497.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 075 344</ms:GML_ID>
        <ms:NAZWA>209 075 344</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209075344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593133.742000 469209.118000</gml:lowerCorner>
        		<gml:upperCorner>593133.742000 469209.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593133.742000 469209.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 074 620</ms:GML_ID>
        <ms:NAZWA>209 074 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209074620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593049.289000 469671.511000</gml:lowerCorner>
        		<gml:upperCorner>593049.289000 469671.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593049.289000 469671.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 074 150</ms:GML_ID>
        <ms:NAZWA>209 074 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209074150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592740.746000 470885.444000</gml:lowerCorner>
        		<gml:upperCorner>592740.746000 470885.444000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592740.746000 470885.444000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 072 891</ms:GML_ID>
        <ms:NAZWA>209 072 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209072891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592541.878000 471246.191000</gml:lowerCorner>
        		<gml:upperCorner>592541.878000 471246.191000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592541.878000 471246.191000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 072 477</ms:GML_ID>
        <ms:NAZWA>209 072 477</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209072477</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593376.755597 471575.674452</gml:lowerCorner>
        		<gml:upperCorner>593376.755597 471575.674452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593376.755597 471575.674452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 022 192</ms:GML_ID>
        <ms:NAZWA>207 022 192</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207022192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592306.610000 471672.575000</gml:lowerCorner>
        		<gml:upperCorner>592306.610000 471672.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592306.610000 471672.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 071 990</ms:GML_ID>
        <ms:NAZWA>209 071 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209071990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593841.261000 471808.902000</gml:lowerCorner>
        		<gml:upperCorner>593841.261000 471808.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593841.261000 471808.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 022 725</ms:GML_ID>
        <ms:NAZWA>207 022 725</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207022725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592370.308000 471875.719000</gml:lowerCorner>
        		<gml:upperCorner>592370.308000 471875.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592370.308000 471875.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 020 964</ms:GML_ID>
        <ms:NAZWA>207 020 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207020964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591921.667000 472345.103000</gml:lowerCorner>
        		<gml:upperCorner>591921.667000 472345.103000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591921.667000 472345.103000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 071 213</ms:GML_ID>
        <ms:NAZWA>209 071 213</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209071213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591945.531000 472373.550000</gml:lowerCorner>
        		<gml:upperCorner>591945.531000 472373.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591945.531000 472373.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 020 307</ms:GML_ID>
        <ms:NAZWA>207 020 307</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207020307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594932.853000 472878.522000</gml:lowerCorner>
        		<gml:upperCorner>594932.853000 472878.522000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594932.853000 472878.522000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 024 263</ms:GML_ID>
        <ms:NAZWA>207 024 263</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207024263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595553.324485 473203.803400</gml:lowerCorner>
        		<gml:upperCorner>595553.324485 473203.803400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595553.324485 473203.803400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 024 968</ms:GML_ID>
        <ms:NAZWA>207 024 968</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207024968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590958.729000 473356.950000</gml:lowerCorner>
        		<gml:upperCorner>590958.729000 473356.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590958.729000 473356.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 018 914</ms:GML_ID>
        <ms:NAZWA>207 018 914</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207018914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596128.733000 473453.552000</gml:lowerCorner>
        		<gml:upperCorner>596128.733000 473453.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596128.733000 473453.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 025 597</ms:GML_ID>
        <ms:NAZWA>207 025 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207025597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590440.098557 473655.617038</gml:lowerCorner>
        		<gml:upperCorner>590440.098557 473655.617038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590440.098557 473655.617038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 018 307</ms:GML_ID>
        <ms:NAZWA>207 018 307</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207018307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589607.971000 473743.321000</gml:lowerCorner>
        		<gml:upperCorner>589607.971000 473743.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589607.971000 473743.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 017 467</ms:GML_ID>
        <ms:NAZWA>207 017 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207017467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589516.629000 473939.187000</gml:lowerCorner>
        		<gml:upperCorner>589516.629000 473939.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589516.629000 473939.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 068 212</ms:GML_ID>
        <ms:NAZWA>209 068 212</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209068212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588704.680000 474105.823000</gml:lowerCorner>
        		<gml:upperCorner>588704.680000 474105.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588704.680000 474105.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 016 493</ms:GML_ID>
        <ms:NAZWA>207 016 493</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207016493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597732.086486 474148.326334</gml:lowerCorner>
        		<gml:upperCorner>597732.086486 474148.326334</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597732.086486 474148.326334</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 027 345</ms:GML_ID>
        <ms:NAZWA>207 027 345</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207027345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589328.415699 474257.176273</gml:lowerCorner>
        		<gml:upperCorner>589328.415699 474257.176273</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589328.415699 474257.176273</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 067 838</ms:GML_ID>
        <ms:NAZWA>209 067 838</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209067838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587348.115000 474405.648000</gml:lowerCorner>
        		<gml:upperCorner>587348.115000 474405.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587348.115000 474405.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 015 082</ms:GML_ID>
        <ms:NAZWA>207 015 082</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207015082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587720.384000 474414.107000</gml:lowerCorner>
        		<gml:upperCorner>587720.384000 474414.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587720.384000 474414.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 015 457</ms:GML_ID>
        <ms:NAZWA>207 015 457</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207015457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589093.156344 474925.561191</gml:lowerCorner>
        		<gml:upperCorner>589093.156344 474925.561191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589093.156344 474925.561191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 067 129</ms:GML_ID>
        <ms:NAZWA>209 067 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209067129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600492.876000 475274.169000</gml:lowerCorner>
        		<gml:upperCorner>600492.876000 475274.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600492.876000 475274.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 030 336</ms:GML_ID>
        <ms:NAZWA>207 030 336</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207030336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600976.346000 475453.718000</gml:lowerCorner>
        		<gml:upperCorner>600976.346000 475453.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600976.346000 475453.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 030 854</ms:GML_ID>
        <ms:NAZWA>207 030 854</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207030854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602999.125000 476303.520000</gml:lowerCorner>
        		<gml:upperCorner>602999.125000 476303.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602999.125000 476303.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 033 096</ms:GML_ID>
        <ms:NAZWA>207 033 096</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207033096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588922.946539 476323.299772</gml:lowerCorner>
        		<gml:upperCorner>588922.946539 476323.299772</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588922.946539 476323.299772</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 065 710</ms:GML_ID>
        <ms:NAZWA>209 065 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209065710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603858.210165 476656.135224</gml:lowerCorner>
        		<gml:upperCorner>603858.210165 476656.135224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603858.210165 476656.135224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 034 029</ms:GML_ID>
        <ms:NAZWA>207 034 029</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207034029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588465.799000 478484.418000</gml:lowerCorner>
        		<gml:upperCorner>588465.799000 478484.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588465.799000 478484.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 063 473</ms:GML_ID>
        <ms:NAZWA>209 063 473</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209063473</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588064.266077 479265.691051</gml:lowerCorner>
        		<gml:upperCorner>588064.266077 479265.691051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588064.266077 479265.691051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 062 589</ms:GML_ID>
        <ms:NAZWA>209 062 589</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209062589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587458.594000 483131.792000</gml:lowerCorner>
        		<gml:upperCorner>587458.594000 483131.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587458.594000 483131.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 058 424</ms:GML_ID>
        <ms:NAZWA>209 058 424</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209058424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583772.019000 483982.377000</gml:lowerCorner>
        		<gml:upperCorner>583772.019000 483982.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583772.019000 483982.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 152 517</ms:GML_ID>
        <ms:NAZWA>353 152 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353152517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584961.496000 485269.378000</gml:lowerCorner>
        		<gml:upperCorner>584961.496000 485269.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584961.496000 485269.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 154 292</ms:GML_ID>
        <ms:NAZWA>353 154 292</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353154292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585361.058000 485927.998000</gml:lowerCorner>
        		<gml:upperCorner>585361.058000 485927.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585361.058000 485927.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 155 064</ms:GML_ID>
        <ms:NAZWA>353 155 064</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353155064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585731.453745 486538.875577</gml:lowerCorner>
        		<gml:upperCorner>585731.453745 486538.875577</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585731.453745 486538.875577</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 155 778</ms:GML_ID>
        <ms:NAZWA>353 155 778</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353155778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586129.254158 487195.252042</gml:lowerCorner>
        		<gml:upperCorner>586129.254158 487195.252042</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586129.254158 487195.252042</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 156 548</ms:GML_ID>
        <ms:NAZWA>353 156 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353156548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586319.621469 487509.568138</gml:lowerCorner>
        		<gml:upperCorner>586319.621469 487509.568138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586319.621469 487509.568138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 156 914</ms:GML_ID>
        <ms:NAZWA>353 156 914</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353156914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586820.615000 488422.731000</gml:lowerCorner>
        		<gml:upperCorner>586820.615000 488422.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586820.615000 488422.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 157 959</ms:GML_ID>
        <ms:NAZWA>353 157 959</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353157959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587094.984000 488961.988000</gml:lowerCorner>
        		<gml:upperCorner>587094.984000 488961.988000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587094.984000 488961.988000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 158 566</ms:GML_ID>
        <ms:NAZWA>353 158 566</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353158566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587293.439000 485408.218000</gml:lowerCorner>
        		<gml:upperCorner>587293.439000 485408.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587293.439000 485408.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 056 134</ms:GML_ID>
        <ms:NAZWA>209 056 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209056134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587318.243000 486175.155000</gml:lowerCorner>
        		<gml:upperCorner>587318.243000 486175.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587318.243000 486175.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 055 367</ms:GML_ID>
        <ms:NAZWA>209 055 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209055367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587338.284000 486808.920000</gml:lowerCorner>
        		<gml:upperCorner>587338.284000 486808.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587338.284000 486808.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 054 733</ms:GML_ID>
        <ms:NAZWA>209 054 733</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209054733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587348.983000 487134.292000</gml:lowerCorner>
        		<gml:upperCorner>587348.983000 487134.292000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587348.983000 487134.292000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 054 407</ms:GML_ID>
        <ms:NAZWA>209 054 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209054407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587519.422000 489750.773000</gml:lowerCorner>
        		<gml:upperCorner>587519.422000 489750.773000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587519.422000 489750.773000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 159 462</ms:GML_ID>
        <ms:NAZWA>353 159 462</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353159462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589269.261117 491796.251661</gml:lowerCorner>
        		<gml:upperCorner>589269.261117 491796.251661</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589269.261117 491796.251661</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 162 164</ms:GML_ID>
        <ms:NAZWA>353 162 164</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353162164</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589598.461275 492131.623753</gml:lowerCorner>
        		<gml:upperCorner>589598.461275 492131.623753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589598.461275 492131.623753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 162 636</ms:GML_ID>
        <ms:NAZWA>353 162 636</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353162636</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590040.634000 492474.789000</gml:lowerCorner>
        		<gml:upperCorner>590040.634000 492474.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590040.634000 492474.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 163 197</ms:GML_ID>
        <ms:NAZWA>353 163 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353163197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592614.332000 494003.529000</gml:lowerCorner>
        		<gml:upperCorner>592614.332000 494003.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592614.332000 494003.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 166 194</ms:GML_ID>
        <ms:NAZWA>353 166 194</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353166194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593299.592000 494438.958000</gml:lowerCorner>
        		<gml:upperCorner>593299.592000 494438.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593299.592000 494438.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 167 007</ms:GML_ID>
        <ms:NAZWA>353 167 007</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353167007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594265.813000 495154.286000</gml:lowerCorner>
        		<gml:upperCorner>594265.813000 495154.286000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594265.813000 495154.286000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 168 210</ms:GML_ID>
        <ms:NAZWA>353 168 210</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353168210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594694.240000 495472.078000</gml:lowerCorner>
        		<gml:upperCorner>594694.240000 495472.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594694.240000 495472.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 168 744</ms:GML_ID>
        <ms:NAZWA>353 168 744</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353168744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>595469.091000 496048.206000</gml:lowerCorner>
        		<gml:upperCorner>595469.091000 496048.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>595469.091000 496048.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 169 710</ms:GML_ID>
        <ms:NAZWA>353 169 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353169710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596481.834000 496797.933000</gml:lowerCorner>
        		<gml:upperCorner>596481.834000 496797.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596481.834000 496797.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 170 972</ms:GML_ID>
        <ms:NAZWA>353 170 972</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353170972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597038.558000 497159.066000</gml:lowerCorner>
        		<gml:upperCorner>597038.558000 497159.066000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597038.558000 497159.066000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 171 637</ms:GML_ID>
        <ms:NAZWA>353 171 637</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353171637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597308.634000 497309.455000</gml:lowerCorner>
        		<gml:upperCorner>597308.634000 497309.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597308.634000 497309.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 171 937</ms:GML_ID>
        <ms:NAZWA>353 171 937</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353171937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597941.116000 497660.451000</gml:lowerCorner>
        		<gml:upperCorner>597941.116000 497660.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597941.116000 497660.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 172 670</ms:GML_ID>
        <ms:NAZWA>353 172 670</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353172670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574757.025000 480903.938000</gml:lowerCorner>
        		<gml:upperCorner>574757.025000 480903.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574757.025000 480903.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 159 076</ms:GML_ID>
        <ms:NAZWA>027 159 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027159076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574774.316000 473718.560000</gml:lowerCorner>
        		<gml:upperCorner>574774.316000 473718.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574774.316000 473718.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 004 698</ms:GML_ID>
        <ms:NAZWA>246 004 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246004698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574802.773781 476160.121637</gml:lowerCorner>
        		<gml:upperCorner>574802.773781 476160.121637</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574802.773781 476160.121637</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 001 604</ms:GML_ID>
        <ms:NAZWA>207 001 604</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207001604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574849.047000 473975.500000</gml:lowerCorner>
        		<gml:upperCorner>574849.047000 473975.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574849.047000 473975.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 004 429</ms:GML_ID>
        <ms:NAZWA>246 004 429</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246004429</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574918.079000 474092.654000</gml:lowerCorner>
        		<gml:upperCorner>574918.079000 474092.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574918.079000 474092.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 004 292</ms:GML_ID>
        <ms:NAZWA>246 004 292</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246004292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575061.097000 476860.409000</gml:lowerCorner>
        		<gml:upperCorner>575061.097000 476860.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575061.097000 476860.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 141 253</ms:GML_ID>
        <ms:NAZWA>353 141 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353141253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575167.673547 480430.264949</gml:lowerCorner>
        		<gml:upperCorner>575167.673547 480430.264949</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575167.673547 480430.264949</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 159 707</ms:GML_ID>
        <ms:NAZWA>027 159 707</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027159707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575386.223000 479888.228000</gml:lowerCorner>
        		<gml:upperCorner>575386.223000 479888.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575386.223000 479888.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 160 291</ms:GML_ID>
        <ms:NAZWA>027 160 291</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027160291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575462.113000 475645.078000</gml:lowerCorner>
        		<gml:upperCorner>575462.113000 475645.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575462.113000 475645.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 002 464</ms:GML_ID>
        <ms:NAZWA>207 002 464</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207002464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575566.602000 479437.265000</gml:lowerCorner>
        		<gml:upperCorner>575566.602000 479437.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575566.602000 479437.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 160 777</ms:GML_ID>
        <ms:NAZWA>027 160 777</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027160777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575575.264000 474909.572000</gml:lowerCorner>
        		<gml:upperCorner>575575.264000 474909.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575575.264000 474909.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 003 222</ms:GML_ID>
        <ms:NAZWA>246 003 222</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246003222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576299.723000 470401.707000</gml:lowerCorner>
        		<gml:upperCorner>576299.723000 470401.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576299.723000 470401.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 009 123</ms:GML_ID>
        <ms:NAZWA>246 009 123</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246009123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576795.543000 470210.686000</gml:lowerCorner>
        		<gml:upperCorner>576795.543000 470210.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576795.543000 470210.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 009 654</ms:GML_ID>
        <ms:NAZWA>246 009 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246009654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576825.460000 478421.050000</gml:lowerCorner>
        		<gml:upperCorner>576825.460000 478421.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576825.460000 478421.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 143 611</ms:GML_ID>
        <ms:NAZWA>353 143 611</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353143611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577668.549000 469875.620000</gml:lowerCorner>
        		<gml:upperCorner>577668.549000 469875.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577668.549000 469875.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 010 590</ms:GML_ID>
        <ms:NAZWA>246 010 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246010590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578003.188037 479378.213511</gml:lowerCorner>
        		<gml:upperCorner>578003.188037 479378.213511</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578003.188037 479378.213511</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 145 132</ms:GML_ID>
        <ms:NAZWA>353 145 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353145132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578615.091000 474414.107000</gml:lowerCorner>
        		<gml:upperCorner>578615.091000 474414.107000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578615.091000 474414.107000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 006 150</ms:GML_ID>
        <ms:NAZWA>207 006 150</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207006150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579224.246000 480344.188000</gml:lowerCorner>
        		<gml:upperCorner>579224.246000 480344.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579224.246000 480344.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 146 689</ms:GML_ID>
        <ms:NAZWA>353 146 689</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353146689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579948.711000 480923.767000</gml:lowerCorner>
        		<gml:upperCorner>579948.711000 480923.767000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579948.711000 480923.767000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 147 616</ms:GML_ID>
        <ms:NAZWA>353 147 616</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353147616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580138.785000 481075.818000</gml:lowerCorner>
        		<gml:upperCorner>580138.785000 481075.818000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580138.785000 481075.818000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 147 859</ms:GML_ID>
        <ms:NAZWA>353 147 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353147859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580191.022000 474585.980000</gml:lowerCorner>
        		<gml:upperCorner>580191.022000 474585.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580191.022000 474585.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 007 736</ms:GML_ID>
        <ms:NAZWA>207 007 736</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207007736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581074.542836 481824.307974</gml:lowerCorner>
        		<gml:upperCorner>581074.542836 481824.307974</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581074.542836 481824.307974</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 149 063</ms:GML_ID>
        <ms:NAZWA>353 149 063</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353149063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582064.879091 482616.920973</gml:lowerCorner>
        		<gml:upperCorner>582064.879091 482616.920973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582064.879091 482616.920973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 150 329</ms:GML_ID>
        <ms:NAZWA>353 150 329</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353150329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582790.215704 483196.533442</gml:lowerCorner>
        		<gml:upperCorner>582790.215704 483196.533442</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582790.215704 483196.533442</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 151 256</ms:GML_ID>
        <ms:NAZWA>353 151 256</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353151256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582981.644333 475061.027266</gml:lowerCorner>
        		<gml:upperCorner>582981.644333 475061.027266</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582981.644333 475061.027266</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 010 602</ms:GML_ID>
        <ms:NAZWA>207 010 602</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207010602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583198.618442 483523.296504</gml:lowerCorner>
        		<gml:upperCorner>583198.618442 483523.296504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583198.618442 483523.296504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 151 780</ms:GML_ID>
        <ms:NAZWA>353 151 780</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353151780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583521.785000 475071.980000</gml:lowerCorner>
        		<gml:upperCorner>583521.785000 475071.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583521.785000 475071.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 011 145</ms:GML_ID>
        <ms:NAZWA>207 011 145</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207011145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585115.433000 474861.979000</gml:lowerCorner>
        		<gml:upperCorner>585115.433000 474861.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585115.433000 474861.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 012 773</ms:GML_ID>
        <ms:NAZWA>207 012 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207012773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585864.672000 474618.872000</gml:lowerCorner>
        		<gml:upperCorner>585864.672000 474618.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585864.672000 474618.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 013 561</ms:GML_ID>
        <ms:NAZWA>207 013 561</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207013561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586201.152583 474510.106061</gml:lowerCorner>
        		<gml:upperCorner>586201.152583 474510.106061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586201.152583 474510.106061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 013 914</ms:GML_ID>
        <ms:NAZWA>207 013 914</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207013914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587336.322000 480278.941000</gml:lowerCorner>
        		<gml:upperCorner>587336.322000 480278.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587336.322000 480278.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 061 313</ms:GML_ID>
        <ms:NAZWA>209 061 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209061313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571985.852761 435688.670045</gml:lowerCorner>
        		<gml:upperCorner>571985.852761 435688.670045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571985.852761 435688.670045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 351 950</ms:GML_ID>
        <ms:NAZWA>131 351 950</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131351950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572493.679612 435346.362430</gml:lowerCorner>
        		<gml:upperCorner>572493.679612 435346.362430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572493.679612 435346.362430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 352 580</ms:GML_ID>
        <ms:NAZWA>131 352 580</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131352580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574298.312000 434130.240000</gml:lowerCorner>
        		<gml:upperCorner>574298.312000 434130.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574298.312000 434130.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 354 740</ms:GML_ID>
        <ms:NAZWA>131 354 740</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131354740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575033.950000 433634.209000</gml:lowerCorner>
        		<gml:upperCorner>575033.950000 433634.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575033.950000 433634.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 355 632</ms:GML_ID>
        <ms:NAZWA>131 355 632</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131355632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580412.196677 429601.169658</gml:lowerCorner>
        		<gml:upperCorner>580412.196677 429601.169658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580412.196677 429601.169658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 362 422</ms:GML_ID>
        <ms:NAZWA>131 362 422</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131362422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581226.284000 424114.950000</gml:lowerCorner>
        		<gml:upperCorner>581226.284000 424114.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581226.284000 424114.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 117 184</ms:GML_ID>
        <ms:NAZWA>356 117 184</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356117184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581783.582000 424889.604000</gml:lowerCorner>
        		<gml:upperCorner>581783.582000 424889.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581783.582000 424889.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 118 139</ms:GML_ID>
        <ms:NAZWA>356 118 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356118139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581948.798000 425139.382000</gml:lowerCorner>
        		<gml:upperCorner>581948.798000 425139.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581948.798000 425139.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 118 469</ms:GML_ID>
        <ms:NAZWA>356 118 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356118469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583438.022000 429081.674000</gml:lowerCorner>
        		<gml:upperCorner>583438.022000 429081.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583438.022000 429081.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 122 661</ms:GML_ID>
        <ms:NAZWA>356 122 661</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356122661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585579.436143 437051.170812</gml:lowerCorner>
        		<gml:upperCorner>585579.436143 437051.170812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585579.436143 437051.170812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 022 022</ms:GML_ID>
        <ms:NAZWA>201 022 022</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201022022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585580.081275 436819.651852</gml:lowerCorner>
        		<gml:upperCorner>585580.081275 436819.651852</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585580.081275 436819.651852</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 154 400</ms:GML_ID>
        <ms:NAZWA>018 154 400</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018154400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585602.282602 436961.153138</gml:lowerCorner>
        		<gml:upperCorner>585602.282602 436961.153138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585602.282602 436961.153138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 022 114</ms:GML_ID>
        <ms:NAZWA>201 022 114</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201022114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585895.978158 430167.807464</gml:lowerCorner>
        		<gml:upperCorner>585895.978158 430167.807464</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585895.978158 430167.807464</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 162 641</ms:GML_ID>
        <ms:NAZWA>018 162 641</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018162641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586097.871896 429811.546393</gml:lowerCorner>
        		<gml:upperCorner>586097.871896 429811.546393</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586097.871896 429811.546393</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 163 053</ms:GML_ID>
        <ms:NAZWA>018 163 053</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018163053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586382.537272 433167.477119</gml:lowerCorner>
        		<gml:upperCorner>586382.537272 433167.477119</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586382.537272 433167.477119</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 159 310</ms:GML_ID>
        <ms:NAZWA>018 159 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018159310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586941.648692 428334.222181</gml:lowerCorner>
        		<gml:upperCorner>586941.648692 428334.222181</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586941.648692 428334.222181</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 164 766</ms:GML_ID>
        <ms:NAZWA>018 164 766</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018164766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587058.833968 433511.144437</gml:lowerCorner>
        		<gml:upperCorner>587058.833968 433511.144437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587058.833968 433511.144437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 158 607</ms:GML_ID>
        <ms:NAZWA>018 158 607</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018158607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587328.831953 427626.404638</gml:lowerCorner>
        		<gml:upperCorner>587328.831953 427626.404638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587328.831953 427626.404638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 165 580</ms:GML_ID>
        <ms:NAZWA>018 165 580</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018165580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587914.946000 426052.014000</gml:lowerCorner>
        		<gml:upperCorner>587914.946000 426052.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587914.946000 426052.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 167 274</ms:GML_ID>
        <ms:NAZWA>018 167 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018167274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588079.916000 424008.589000</gml:lowerCorner>
        		<gml:upperCorner>588079.916000 424008.589000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588079.916000 424008.589000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 169 338</ms:GML_ID>
        <ms:NAZWA>018 169 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018169338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588100.117000 425113.206000</gml:lowerCorner>
        		<gml:upperCorner>588100.117000 425113.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588100.117000 425113.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 168 233</ms:GML_ID>
        <ms:NAZWA>018 168 233</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018168233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588118.317165 424580.215306</gml:lowerCorner>
        		<gml:upperCorner>588118.317165 424580.215306</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588118.317165 424580.215306</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 168 766</ms:GML_ID>
        <ms:NAZWA>018 168 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018168766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591607.589000 433996.496000</gml:lowerCorner>
        		<gml:upperCorner>591607.589000 433996.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591607.589000 433996.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 376 383</ms:GML_ID>
        <ms:NAZWA>131 376 383</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131376383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592862.761797 434472.059835</gml:lowerCorner>
        		<gml:upperCorner>592862.761797 434472.059835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592862.761797 434472.059835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 377 735</ms:GML_ID>
        <ms:NAZWA>131 377 735</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131377735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597522.285000 436041.090000</gml:lowerCorner>
        		<gml:upperCorner>597522.285000 436041.090000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597522.285000 436041.090000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 036 333</ms:GML_ID>
        <ms:NAZWA>201 036 333</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201036333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571730.579000 438569.603000</gml:lowerCorner>
        		<gml:upperCorner>571730.579000 438569.603000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571730.579000 438569.603000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 004 345</ms:GML_ID>
        <ms:NAZWA>201 004 345</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201004345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578587.864331 450258.779368</gml:lowerCorner>
        		<gml:upperCorner>578587.864331 450258.779368</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578587.864331 450258.779368</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 136 411</ms:GML_ID>
        <ms:NAZWA>018 136 411</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018136411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579133.101000 449099.604000</gml:lowerCorner>
        		<gml:upperCorner>579133.101000 449099.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579133.101000 449099.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 137 700</ms:GML_ID>
        <ms:NAZWA>018 137 700</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018137700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579367.429150 448516.991599</gml:lowerCorner>
        		<gml:upperCorner>579367.429150 448516.991599</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579367.429150 448516.991599</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 138 317</ms:GML_ID>
        <ms:NAZWA>018 138 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018138317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579429.424000 442719.840000</gml:lowerCorner>
        		<gml:upperCorner>579429.424000 442719.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579429.424000 442719.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 144 168</ms:GML_ID>
        <ms:NAZWA>018 144 168</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018144168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579515.202000 445215.319000</gml:lowerCorner>
        		<gml:upperCorner>579515.202000 445215.319000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579515.202000 445215.319000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 141 668</ms:GML_ID>
        <ms:NAZWA>018 141 668</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018141668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579533.663000 445535.772000</gml:lowerCorner>
        		<gml:upperCorner>579533.663000 445535.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579533.663000 445535.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 141 347</ms:GML_ID>
        <ms:NAZWA>018 141 347</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018141347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579585.624233 446417.664132</gml:lowerCorner>
        		<gml:upperCorner>579585.624233 446417.664132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579585.624233 446417.664132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 140 464</ms:GML_ID>
        <ms:NAZWA>018 140 464</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018140464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579637.700195 447316.047814</gml:lowerCorner>
        		<gml:upperCorner>579637.700195 447316.047814</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579637.700195 447316.047814</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 139 560</ms:GML_ID>
        <ms:NAZWA>018 139 560</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018139560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579692.482412 449050.791889</gml:lowerCorner>
        		<gml:upperCorner>579692.482412 449050.791889</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579692.482412 449050.791889</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 138 040</ms:GML_ID>
        <ms:NAZWA>018 138 040</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018138040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580237.580000 441390.060000</gml:lowerCorner>
        		<gml:upperCorner>580237.580000 441390.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580237.580000 441390.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 145 805</ms:GML_ID>
        <ms:NAZWA>018 145 805</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018145805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581218.096175 440858.812697</gml:lowerCorner>
        		<gml:upperCorner>581218.096175 440858.812697</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581218.096175 440858.812697</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 146 934</ms:GML_ID>
        <ms:NAZWA>018 146 934</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018146934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583237.952558 440778.357467</gml:lowerCorner>
        		<gml:upperCorner>583237.952558 440778.357467</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583237.952558 440778.357467</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 149 053</ms:GML_ID>
        <ms:NAZWA>018 149 053</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018149053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583380.371000 439481.935000</gml:lowerCorner>
        		<gml:upperCorner>583380.371000 439481.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583380.371000 439481.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 016 300</ms:GML_ID>
        <ms:NAZWA>201 016 300</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201016300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584349.704000 440732.312000</gml:lowerCorner>
        		<gml:upperCorner>584349.704000 440732.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584349.704000 440732.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 150 207</ms:GML_ID>
        <ms:NAZWA>018 150 207</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018150207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584643.073000 440482.824000</gml:lowerCorner>
        		<gml:upperCorner>584643.073000 440482.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584643.073000 440482.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 150 597</ms:GML_ID>
        <ms:NAZWA>018 150 597</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018150597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585095.476547 439126.867911</gml:lowerCorner>
        		<gml:upperCorner>585095.476547 439126.867911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585095.476547 439126.867911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 152 025</ms:GML_ID>
        <ms:NAZWA>018 152 025</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018152025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585202.304000 438733.442000</gml:lowerCorner>
        		<gml:upperCorner>585202.304000 438733.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585202.304000 438733.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.201 020 279</ms:GML_ID>
        <ms:NAZWA>201 020 279</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>201020279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585424.162000 446364.604000</gml:lowerCorner>
        		<gml:upperCorner>585424.162000 446364.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585424.162000 446364.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 100 376</ms:GML_ID>
        <ms:NAZWA>209 100 376</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209100376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585755.788302 440614.803431</gml:lowerCorner>
        		<gml:upperCorner>585755.788302 440614.803431</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585755.788302 440614.803431</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 107 404</ms:GML_ID>
        <ms:NAZWA>209 107 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209107404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586153.894000 441502.750000</gml:lowerCorner>
        		<gml:upperCorner>586153.894000 441502.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586153.894000 441502.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 106 431</ms:GML_ID>
        <ms:NAZWA>209 106 431</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209106431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586256.538000 441731.007000</gml:lowerCorner>
        		<gml:upperCorner>586256.538000 441731.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586256.538000 441731.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 106 181</ms:GML_ID>
        <ms:NAZWA>209 106 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209106181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586448.719636 442160.336177</gml:lowerCorner>
        		<gml:upperCorner>586448.719636 442160.336177</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586448.719636 442160.336177</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 105 702</ms:GML_ID>
        <ms:NAZWA>209 105 702</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209105702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586570.490718 442432.072585</gml:lowerCorner>
        		<gml:upperCorner>586570.490718 442432.072585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586570.490718 442432.072585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 105 408</ms:GML_ID>
        <ms:NAZWA>209 105 408</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209105408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586804.369000 442953.753000</gml:lowerCorner>
        		<gml:upperCorner>586804.369000 442953.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586804.369000 442953.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 104 840</ms:GML_ID>
        <ms:NAZWA>209 104 840</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209104840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586936.089975 447579.342374</gml:lowerCorner>
        		<gml:upperCorner>586936.089975 447579.342374</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586936.089975 447579.342374</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 098 419</ms:GML_ID>
        <ms:NAZWA>209 098 419</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209098419</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588186.710000 449599.057000</gml:lowerCorner>
        		<gml:upperCorner>588186.710000 449599.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588186.710000 449599.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.209 096 015</ms:GML_ID>
        <ms:NAZWA>209 096 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>209096015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600383.184339 439612.129886</gml:lowerCorner>
        		<gml:upperCorner>600383.184339 439612.129886</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600383.184339 439612.129886</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 386 954</ms:GML_ID>
        <ms:NAZWA>131 386 954</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131386954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601771.073220 440793.511751</gml:lowerCorner>
        		<gml:upperCorner>601771.073220 440793.511751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601771.073220 440793.511751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 388 778</ms:GML_ID>
        <ms:NAZWA>131 388 778</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131388778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571169.199727 415716.801180</gml:lowerCorner>
        		<gml:upperCorner>571169.199727 415716.801180</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571169.199727 415716.801180</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 102 933</ms:GML_ID>
        <ms:NAZWA>356 102 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356102933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571935.224299 415933.896132</gml:lowerCorner>
        		<gml:upperCorner>571935.224299 415933.896132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571935.224299 415933.896132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 103 730</ms:GML_ID>
        <ms:NAZWA>356 103 730</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356103730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572075.100000 415985.723000</gml:lowerCorner>
        		<gml:upperCorner>572075.100000 415985.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572075.100000 415985.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 103 879</ms:GML_ID>
        <ms:NAZWA>356 103 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356103879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572325.440000 416171.784000</gml:lowerCorner>
        		<gml:upperCorner>572325.440000 416171.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572325.440000 416171.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 104 192</ms:GML_ID>
        <ms:NAZWA>356 104 192</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356104192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573606.916000 417370.427000</gml:lowerCorner>
        		<gml:upperCorner>573606.916000 417370.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573606.916000 417370.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 106 080</ms:GML_ID>
        <ms:NAZWA>356 106 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356106080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574442.016000 417934.242000</gml:lowerCorner>
        		<gml:upperCorner>574442.016000 417934.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574442.016000 417934.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 107 089</ms:GML_ID>
        <ms:NAZWA>356 107 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356107089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575019.303000 418345.803000</gml:lowerCorner>
        		<gml:upperCorner>575019.303000 418345.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575019.303000 418345.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 107 799</ms:GML_ID>
        <ms:NAZWA>356 107 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356107799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576729.407000 419035.566000</gml:lowerCorner>
        		<gml:upperCorner>576729.407000 419035.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576729.407000 419035.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 109 668</ms:GML_ID>
        <ms:NAZWA>356 109 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356109668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578157.155000 419408.863000</gml:lowerCorner>
        		<gml:upperCorner>578157.155000 419408.863000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578157.155000 419408.863000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 111 145</ms:GML_ID>
        <ms:NAZWA>356 111 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356111145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579296.105000 420270.471000</gml:lowerCorner>
        		<gml:upperCorner>579296.105000 420270.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579296.105000 420270.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 112 737</ms:GML_ID>
        <ms:NAZWA>356 112 737</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356112737</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579306.165000 421247.092000</gml:lowerCorner>
        		<gml:upperCorner>579306.165000 421247.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579306.165000 421247.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 113 714</ms:GML_ID>
        <ms:NAZWA>356 113 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356113714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579742.668000 422048.770000</gml:lowerCorner>
        		<gml:upperCorner>579742.668000 422048.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579742.668000 422048.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 114 639</ms:GML_ID>
        <ms:NAZWA>356 114 639</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356114639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580378.503000 422933.655000</gml:lowerCorner>
        		<gml:upperCorner>580378.503000 422933.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580378.503000 422933.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 115 729</ms:GML_ID>
        <ms:NAZWA>356 115 729</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356115729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580621.554000 423271.854000</gml:lowerCorner>
        		<gml:upperCorner>580621.554000 423271.854000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580621.554000 423271.854000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 116 113</ms:GML_ID>
        <ms:NAZWA>356 116 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356116113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587957.776954 420101.489585</gml:lowerCorner>
        		<gml:upperCorner>587957.776954 420101.489585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587957.776954 420101.489585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 173 252</ms:GML_ID>
        <ms:NAZWA>018 173 252</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018173252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587966.908000 422066.302000</gml:lowerCorner>
        		<gml:upperCorner>587966.908000 422066.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587966.908000 422066.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 171 287</ms:GML_ID>
        <ms:NAZWA>018 171 287</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018171287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587977.831200 419664.553273</gml:lowerCorner>
        		<gml:upperCorner>587977.831200 419664.553273</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587977.831200 419664.553273</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 173 690</ms:GML_ID>
        <ms:NAZWA>018 173 690</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018173690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588016.597000 423085.781000</gml:lowerCorner>
        		<gml:upperCorner>588016.597000 423085.781000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588016.597000 423085.781000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 170 266</ms:GML_ID>
        <ms:NAZWA>018 170 266</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018170266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588043.710856 423476.424068</gml:lowerCorner>
        		<gml:upperCorner>588043.710856 423476.424068</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588043.710856 423476.424068</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 169 873</ms:GML_ID>
        <ms:NAZWA>018 169 873</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018169873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588383.994000 408864.816000</gml:lowerCorner>
        		<gml:upperCorner>588383.994000 408864.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588383.994000 408864.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 184 562</ms:GML_ID>
        <ms:NAZWA>018 184 562</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018184562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588651.212263 413224.350471</gml:lowerCorner>
        		<gml:upperCorner>588651.212263 413224.350471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588651.212263 413224.350471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 180 178</ms:GML_ID>
        <ms:NAZWA>018 180 178</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018180178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564514.776000 495258.523000</gml:lowerCorner>
        		<gml:upperCorner>564514.776000 495258.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564514.776000 495258.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 141 084</ms:GML_ID>
        <ms:NAZWA>027 141 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027141084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565260.105000 494359.931000</gml:lowerCorner>
        		<gml:upperCorner>565260.105000 494359.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565260.105000 494359.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 142 253</ms:GML_ID>
        <ms:NAZWA>027 142 253</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027142253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565944.509000 493535.311000</gml:lowerCorner>
        		<gml:upperCorner>565944.509000 493535.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565944.509000 493535.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 143 325</ms:GML_ID>
        <ms:NAZWA>027 143 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027143325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566553.849661 492717.060734</gml:lowerCorner>
        		<gml:upperCorner>566553.849661 492717.060734</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566553.849661 492717.060734</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 144 346</ms:GML_ID>
        <ms:NAZWA>027 144 346</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027144346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566740.409000 492465.417000</gml:lowerCorner>
        		<gml:upperCorner>566740.409000 492465.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566740.409000 492465.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 144 659</ms:GML_ID>
        <ms:NAZWA>027 144 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027144659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567239.366000 491789.597000</gml:lowerCorner>
        		<gml:upperCorner>567239.366000 491789.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567239.366000 491789.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 145 505</ms:GML_ID>
        <ms:NAZWA>027 145 505</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027145505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567748.348260 491166.296786</gml:lowerCorner>
        		<gml:upperCorner>567748.348260 491166.296786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567748.348260 491166.296786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 146 305</ms:GML_ID>
        <ms:NAZWA>027 146 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027146305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568191.304649 490650.889789</gml:lowerCorner>
        		<gml:upperCorner>568191.304649 490650.889789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568191.304649 490650.889789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 146 985</ms:GML_ID>
        <ms:NAZWA>027 146 985</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027146985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568663.635000 490102.104000</gml:lowerCorner>
        		<gml:upperCorner>568663.635000 490102.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568663.635000 490102.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 147 710</ms:GML_ID>
        <ms:NAZWA>027 147 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027147710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569128.817000 489533.841000</gml:lowerCorner>
        		<gml:upperCorner>569128.817000 489533.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569128.817000 489533.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 148 445</ms:GML_ID>
        <ms:NAZWA>027 148 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027148445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569545.327000 489018.192000</gml:lowerCorner>
        		<gml:upperCorner>569545.327000 489018.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569545.327000 489018.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 149 108</ms:GML_ID>
        <ms:NAZWA>027 149 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027149108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570017.304000 488494.997000</gml:lowerCorner>
        		<gml:upperCorner>570017.304000 488494.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570017.304000 488494.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 149 814</ms:GML_ID>
        <ms:NAZWA>027 149 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027149814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570280.200000 488212.368000</gml:lowerCorner>
        		<gml:upperCorner>570280.200000 488212.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570280.200000 488212.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 150 200</ms:GML_ID>
        <ms:NAZWA>027 150 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027150200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571091.568000 487340.106000</gml:lowerCorner>
        		<gml:upperCorner>571091.568000 487340.106000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571091.568000 487340.106000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 151 393</ms:GML_ID>
        <ms:NAZWA>027 151 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027151393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571380.458000 487030.195000</gml:lowerCorner>
        		<gml:upperCorner>571380.458000 487030.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571380.458000 487030.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 151 817</ms:GML_ID>
        <ms:NAZWA>027 151 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027151817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571902.416000 486469.930000</gml:lowerCorner>
        		<gml:upperCorner>571902.416000 486469.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571902.416000 486469.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 152 584</ms:GML_ID>
        <ms:NAZWA>027 152 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027152584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572489.336951 485708.385848</gml:lowerCorner>
        		<gml:upperCorner>572489.336951 485708.385848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572489.336951 485708.385848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 153 547</ms:GML_ID>
        <ms:NAZWA>027 153 547</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027153547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572838.244000 485193.442000</gml:lowerCorner>
        		<gml:upperCorner>572838.244000 485193.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572838.244000 485193.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 154 180</ms:GML_ID>
        <ms:NAZWA>027 154 180</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027154180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554570.451000 455000.371000</gml:lowerCorner>
        		<gml:upperCorner>554570.451000 455000.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554570.451000 455000.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 109 050</ms:GML_ID>
        <ms:NAZWA>353 109 050</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353109050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555390.543000 455998.763000</gml:lowerCorner>
        		<gml:upperCorner>555390.543000 455998.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555390.543000 455998.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 110 337</ms:GML_ID>
        <ms:NAZWA>353 110 337</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353110337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556098.379067 456848.255786</gml:lowerCorner>
        		<gml:upperCorner>556098.379067 456848.255786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556098.379067 456848.255786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 111 450</ms:GML_ID>
        <ms:NAZWA>353 111 450</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353111450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3948">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557385.788000 458430.115000</gml:lowerCorner>
        		<gml:upperCorner>557385.788000 458430.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3948.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557385.788000 458430.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3948</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 113 484</ms:GML_ID>
        <ms:NAZWA>353 113 484</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353113484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3949">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557710.767000 458854.493000</gml:lowerCorner>
        		<gml:upperCorner>557710.767000 458854.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3949.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557710.767000 458854.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3949</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 114 025</ms:GML_ID>
        <ms:NAZWA>353 114 025</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353114025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558313.123000 460094.278000</gml:lowerCorner>
        		<gml:upperCorner>558313.123000 460094.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558313.123000 460094.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 115 402</ms:GML_ID>
        <ms:NAZWA>353 115 402</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353115402</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558570.597000 460631.556000</gml:lowerCorner>
        		<gml:upperCorner>558570.597000 460631.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558570.597000 460631.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 115 996</ms:GML_ID>
        <ms:NAZWA>353 115 996</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353115996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558807.864000 461126.608000</gml:lowerCorner>
        		<gml:upperCorner>558807.864000 461126.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558807.864000 461126.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 116 550</ms:GML_ID>
        <ms:NAZWA>353 116 550</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353116550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559817.086000 463510.796000</gml:lowerCorner>
        		<gml:upperCorner>559817.086000 463510.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559817.086000 463510.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 119 138</ms:GML_ID>
        <ms:NAZWA>353 119 138</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353119138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560259.823000 464313.495000</gml:lowerCorner>
        		<gml:upperCorner>560259.823000 464313.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560259.823000 464313.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 120 054</ms:GML_ID>
        <ms:NAZWA>353 120 054</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353120054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560714.512000 465132.768000</gml:lowerCorner>
        		<gml:upperCorner>560714.512000 465132.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560714.512000 465132.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 120 990</ms:GML_ID>
        <ms:NAZWA>353 120 990</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353120990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561606.426000 466700.998000</gml:lowerCorner>
        		<gml:upperCorner>561606.426000 466700.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561606.426000 466700.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 122 779</ms:GML_ID>
        <ms:NAZWA>353 122 779</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353122779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562829.671000 467773.985000</gml:lowerCorner>
        		<gml:upperCorner>562829.671000 467773.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562829.671000 467773.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 124 433</ms:GML_ID>
        <ms:NAZWA>353 124 433</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353124433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568915.628544 468288.652263</gml:lowerCorner>
        		<gml:upperCorner>568915.628544 468288.652263</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568915.628544 468288.652263</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 115 362</ms:GML_ID>
        <ms:NAZWA>018 115 362</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018115362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568978.322000 467731.764000</gml:lowerCorner>
        		<gml:upperCorner>568978.322000 467731.764000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568978.322000 467731.764000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 115 923</ms:GML_ID>
        <ms:NAZWA>018 115 923</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018115923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569039.502000 465732.228000</gml:lowerCorner>
        		<gml:upperCorner>569039.502000 465732.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569039.502000 465732.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 117 951</ms:GML_ID>
        <ms:NAZWA>018 117 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018117951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569058.241000 466689.324000</gml:lowerCorner>
        		<gml:upperCorner>569058.241000 466689.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569058.241000 466689.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 116 972</ms:GML_ID>
        <ms:NAZWA>018 116 972</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018116972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571149.775707 461187.197564</gml:lowerCorner>
        		<gml:upperCorner>571149.775707 461187.197564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571149.775707 461187.197564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 123 112</ms:GML_ID>
        <ms:NAZWA>018 123 112</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018123112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573052.736646 458835.228283</gml:lowerCorner>
        		<gml:upperCorner>573052.736646 458835.228283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573052.736646 458835.228283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 126 142</ms:GML_ID>
        <ms:NAZWA>018 126 142</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018126142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576313.884000 454643.810000</gml:lowerCorner>
        		<gml:upperCorner>576313.884000 454643.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576313.884000 454643.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 131 455</ms:GML_ID>
        <ms:NAZWA>018 131 455</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018131455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553766.119521 481934.806986</gml:lowerCorner>
        		<gml:upperCorner>553766.119521 481934.806986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553766.119521 481934.806986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 087 885</ms:GML_ID>
        <ms:NAZWA>018 087 885</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018087885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554538.583980 481253.332937</gml:lowerCorner>
        		<gml:upperCorner>554538.583980 481253.332937</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554538.583980 481253.332937</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 088 922</ms:GML_ID>
        <ms:NAZWA>018 088 922</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018088922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555761.625335 480308.719522</gml:lowerCorner>
        		<gml:upperCorner>555761.625335 480308.719522</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555761.625335 480308.719522</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 090 472</ms:GML_ID>
        <ms:NAZWA>018 090 472</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018090472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555931.179520 480521.633295</gml:lowerCorner>
        		<gml:upperCorner>555931.179520 480521.633295</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555931.179520 480521.633295</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 001 291</ms:GML_ID>
        <ms:NAZWA>245 001 291</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245001291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555974.799369 481680.881452</gml:lowerCorner>
        		<gml:upperCorner>555974.799369 481680.881452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555974.799369 481680.881452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 002 454</ms:GML_ID>
        <ms:NAZWA>245 002 454</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245002454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556007.028588 482210.122368</gml:lowerCorner>
        		<gml:upperCorner>556007.028588 482210.122368</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556007.028588 482210.122368</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 002 982</ms:GML_ID>
        <ms:NAZWA>245 002 982</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245002982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556068.976246 482996.345021</gml:lowerCorner>
        		<gml:upperCorner>556068.976246 482996.345021</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556068.976246 482996.345021</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 003 771</ms:GML_ID>
        <ms:NAZWA>245 003 771</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245003771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556252.538000 483506.688000</gml:lowerCorner>
        		<gml:upperCorner>556252.538000 483506.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556252.538000 483506.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 004 317</ms:GML_ID>
        <ms:NAZWA>245 004 317</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245004317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556351.026351 483712.367382</gml:lowerCorner>
        		<gml:upperCorner>556351.026351 483712.367382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556351.026351 483712.367382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.245 004 545</ms:GML_ID>
        <ms:NAZWA>245 004 545</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>245004545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556908.628021 479434.153122</gml:lowerCorner>
        		<gml:upperCorner>556908.628021 479434.153122</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556908.628021 479434.153122</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 091 915</ms:GML_ID>
        <ms:NAZWA>018 091 915</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018091915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559532.823009 479153.671369</gml:lowerCorner>
        		<gml:upperCorner>559532.823009 479153.671369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559532.823009 479153.671369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 094 600</ms:GML_ID>
        <ms:NAZWA>018 094 600</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018094600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560556.491369 479276.255438</gml:lowerCorner>
        		<gml:upperCorner>560556.491369 479276.255438</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560556.491369 479276.255438</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 095 633</ms:GML_ID>
        <ms:NAZWA>018 095 633</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018095633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567854.387000 478067.752000</gml:lowerCorner>
        		<gml:upperCorner>567854.387000 478067.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567854.387000 478067.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 103 264</ms:GML_ID>
        <ms:NAZWA>018 103 264</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018103264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567952.068000 470075.778000</gml:lowerCorner>
        		<gml:upperCorner>567952.068000 470075.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567952.068000 470075.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 130 244</ms:GML_ID>
        <ms:NAZWA>353 130 244</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353130244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568706.746000 469829.821000</gml:lowerCorner>
        		<gml:upperCorner>568706.746000 469829.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568706.746000 469829.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 113 787</ms:GML_ID>
        <ms:NAZWA>018 113 787</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018113787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569488.202000 471704.148000</gml:lowerCorner>
        		<gml:upperCorner>569488.202000 471704.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569488.202000 471704.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 111 749</ms:GML_ID>
        <ms:NAZWA>018 111 749</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018111749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570003.935187 472323.269465</gml:lowerCorner>
        		<gml:upperCorner>570003.935187 472323.269465</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570003.935187 472323.269465</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 133 497</ms:GML_ID>
        <ms:NAZWA>353 133 497</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353133497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570303.460222 473432.270023</gml:lowerCorner>
        		<gml:upperCorner>570303.460222 473432.270023</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570303.460222 473432.270023</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 134 663</ms:GML_ID>
        <ms:NAZWA>353 134 663</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353134663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

