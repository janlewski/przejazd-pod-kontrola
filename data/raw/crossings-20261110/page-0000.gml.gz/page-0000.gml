<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:14" numberMatched="unknown" numberReturned="1000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=1000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>291988.100000 656583.543089</gml:lowerCorner>
      		<gml:upperCorner>582831.125509 847263.249119</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404088.373000 691734.714000</gml:lowerCorner>
        		<gml:upperCorner>404088.373000 691734.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404088.373000 691734.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 006 629</ms:GML_ID>
        <ms:NAZWA>082 006 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082006629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408316.141000 701883.278000</gml:lowerCorner>
        		<gml:upperCorner>408316.141000 701883.278000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408316.141000 701883.278000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 113 665</ms:GML_ID>
        <ms:NAZWA>007 113 665</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007113665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410403.523000 691415.845000</gml:lowerCorner>
        		<gml:upperCorner>410403.523000 691415.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410403.523000 691415.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 072 146</ms:GML_ID>
        <ms:NAZWA>026 072 146</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026072146</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410865.778000 692285.082000</gml:lowerCorner>
        		<gml:upperCorner>410865.778000 692285.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410865.778000 692285.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 071 156</ms:GML_ID>
        <ms:NAZWA>026 071 156</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026071156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412022.192207 697462.976449</gml:lowerCorner>
        		<gml:upperCorner>412022.192207 697462.976449</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412022.192207 697462.976449</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 107 851</ms:GML_ID>
        <ms:NAZWA>007 107 851</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007107851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412268.657980 695313.366302</gml:lowerCorner>
        		<gml:upperCorner>412268.657980 695313.366302</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412268.657980 695313.366302</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 066 976</ms:GML_ID>
        <ms:NAZWA>026 066 976</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026066976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413228.324000 696810.858000</gml:lowerCorner>
        		<gml:upperCorner>413228.324000 696810.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413228.324000 696810.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 064 941</ms:GML_ID>
        <ms:NAZWA>026 064 941</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026064941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414654.461113 696973.416877</gml:lowerCorner>
        		<gml:upperCorner>414654.461113 696973.416877</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414654.461113 696973.416877</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 105 190</ms:GML_ID>
        <ms:NAZWA>007 105 190</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007105190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414667.041433 696955.028868</gml:lowerCorner>
        		<gml:upperCorner>414667.041433 696955.028868</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414667.041433 696955.028868</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 105 167</ms:GML_ID>
        <ms:NAZWA>007 105 167</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007105167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415916.853294 696556.945850</gml:lowerCorner>
        		<gml:upperCorner>415916.853294 696556.945850</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415916.853294 696556.945850</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.770 002 317</ms:GML_ID>
        <ms:NAZWA>770 002 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>770002317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415927.471000 696737.426000</gml:lowerCorner>
        		<gml:upperCorner>415927.471000 696737.426000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415927.471000 696737.426000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.579 004 443</ms:GML_ID>
        <ms:NAZWA>579 004 443</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>579004443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415959.896000 697143.084000</gml:lowerCorner>
        		<gml:upperCorner>415959.896000 697143.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415959.896000 697143.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.579 004 031</ms:GML_ID>
        <ms:NAZWA>579 004 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>579004031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415991.352010 696568.916278</gml:lowerCorner>
        		<gml:upperCorner>415991.352010 696568.916278</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415991.352010 696568.916278</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 103 490</ms:GML_ID>
        <ms:NAZWA>007 103 490</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007103490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416552.625000 695823.014000</gml:lowerCorner>
        		<gml:upperCorner>416552.625000 695823.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416552.625000 695823.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.770 001 328</ms:GML_ID>
        <ms:NAZWA>770 001 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>770001328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417464.154000 696319.855000</gml:lowerCorner>
        		<gml:upperCorner>417464.154000 696319.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417464.154000 696319.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 059 573</ms:GML_ID>
        <ms:NAZWA>026 059 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026059573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417568.990000 698319.037000</gml:lowerCorner>
        		<gml:upperCorner>417568.990000 698319.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417568.990000 698319.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.579 002 016</ms:GML_ID>
        <ms:NAZWA>579 002 016</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>579002016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418253.769000 698227.814000</gml:lowerCorner>
        		<gml:upperCorner>418253.769000 698227.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418253.769000 698227.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 057 508</ms:GML_ID>
        <ms:NAZWA>026 057 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026057508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418849.869434 699668.737551</gml:lowerCorner>
        		<gml:upperCorner>418849.869434 699668.737551</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418849.869434 699668.737551</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 055 953</ms:GML_ID>
        <ms:NAZWA>026 055 953</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026055953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419575.486425 702283.813297</gml:lowerCorner>
        		<gml:upperCorner>419575.486425 702283.813297</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419575.486425 702283.813297</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 053 209</ms:GML_ID>
        <ms:NAZWA>026 053 209</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026053209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424085.493000 705764.211000</gml:lowerCorner>
        		<gml:upperCorner>424085.493000 705764.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424085.493000 705764.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 045 896</ms:GML_ID>
        <ms:NAZWA>026 045 896</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026045896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422433.747000 705774.370000</gml:lowerCorner>
        		<gml:upperCorner>422433.747000 705774.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422433.747000 705774.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 047 592</ms:GML_ID>
        <ms:NAZWA>026 047 592</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026047592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423377.860000 705824.457000</gml:lowerCorner>
        		<gml:upperCorner>423377.860000 705824.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423377.860000 705824.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 046 616</ms:GML_ID>
        <ms:NAZWA>026 046 616</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026046616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420866.992000 705860.184000</gml:lowerCorner>
        		<gml:upperCorner>420866.992000 705860.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420866.992000 705860.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 049 267</ms:GML_ID>
        <ms:NAZWA>026 049 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026049267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421734.927000 705895.838000</gml:lowerCorner>
        		<gml:upperCorner>421734.927000 705895.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421734.927000 705895.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 048 326</ms:GML_ID>
        <ms:NAZWA>026 048 326</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026048326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424925.438000 706536.328000</gml:lowerCorner>
        		<gml:upperCorner>424925.438000 706536.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424925.438000 706536.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 044 746</ms:GML_ID>
        <ms:NAZWA>026 044 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026044746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426275.435000 707758.634000</gml:lowerCorner>
        		<gml:upperCorner>426275.435000 707758.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426275.435000 707758.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 042 862</ms:GML_ID>
        <ms:NAZWA>026 042 862</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026042862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427055.382905 708650.123250</gml:lowerCorner>
        		<gml:upperCorner>427055.382905 708650.123250</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427055.382905 708650.123250</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 041 675</ms:GML_ID>
        <ms:NAZWA>026 041 675</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026041675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427580.317359 709371.523441</gml:lowerCorner>
        		<gml:upperCorner>427580.317359 709371.523441</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427580.317359 709371.523441</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 040 785</ms:GML_ID>
        <ms:NAZWA>026 040 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026040785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428236.353600 710274.046311</gml:lowerCorner>
        		<gml:upperCorner>428236.353600 710274.046311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428236.353600 710274.046311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 039 668</ms:GML_ID>
        <ms:NAZWA>026 039 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026039668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429705.229000 712293.442000</gml:lowerCorner>
        		<gml:upperCorner>429705.229000 712293.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429705.229000 712293.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 037 171</ms:GML_ID>
        <ms:NAZWA>026 037 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026037171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430463.078000 713334.738000</gml:lowerCorner>
        		<gml:upperCorner>430463.078000 713334.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430463.078000 713334.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 035 882</ms:GML_ID>
        <ms:NAZWA>026 035 882</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026035882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430989.864000 713959.471000</gml:lowerCorner>
        		<gml:upperCorner>430989.864000 713959.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430989.864000 713959.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 035 063</ms:GML_ID>
        <ms:NAZWA>026 035 063</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026035063</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433163.095797 715704.523375</gml:lowerCorner>
        		<gml:upperCorner>433163.095797 715704.523375</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433163.095797 715704.523375</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 032 276</ms:GML_ID>
        <ms:NAZWA>026 032 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026032276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434454.975187 716739.257542</gml:lowerCorner>
        		<gml:upperCorner>434454.975187 716739.257542</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434454.975187 716739.257542</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 030 620</ms:GML_ID>
        <ms:NAZWA>026 030 620</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>026030620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405936.820000 749907.483000</gml:lowerCorner>
        		<gml:upperCorner>405936.820000 749907.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405936.820000 749907.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 080 843</ms:GML_ID>
        <ms:NAZWA>030 080 843</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030080843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405230.898746 750139.233376</gml:lowerCorner>
        		<gml:upperCorner>405230.898746 750139.233376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405230.898746 750139.233376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 081 587</ms:GML_ID>
        <ms:NAZWA>030 081 587</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030081587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403925.621594 750604.588377</gml:lowerCorner>
        		<gml:upperCorner>403925.621594 750604.588377</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403925.621594 750604.588377</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 082 972</ms:GML_ID>
        <ms:NAZWA>030 082 972</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030082972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407025.790000 750684.463000</gml:lowerCorner>
        		<gml:upperCorner>407025.790000 750684.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407025.790000 750684.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 079 245</ms:GML_ID>
        <ms:NAZWA>030 079 245</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030079245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391611.239618 752320.508973</gml:lowerCorner>
        		<gml:upperCorner>391611.239618 752320.508973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391611.239618 752320.508973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 096 250</ms:GML_ID>
        <ms:NAZWA>030 096 250</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030096250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392427.206000 752802.595000</gml:lowerCorner>
        		<gml:upperCorner>392427.206000 752802.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392427.206000 752802.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 095 293</ms:GML_ID>
        <ms:NAZWA>030 095 293</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030095293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393696.813844 753558.227873</gml:lowerCorner>
        		<gml:upperCorner>393696.813844 753558.227873</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393696.813844 753558.227873</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 093 820</ms:GML_ID>
        <ms:NAZWA>030 093 820</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030093820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394725.771615 753770.612022</gml:lowerCorner>
        		<gml:upperCorner>394725.771615 753770.612022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394725.771615 753770.612022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 092 694</ms:GML_ID>
        <ms:NAZWA>030 092 694</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030092694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396237.754000 753252.557000</gml:lowerCorner>
        		<gml:upperCorner>396237.754000 753252.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396237.754000 753252.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 091 103</ms:GML_ID>
        <ms:NAZWA>030 091 103</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030091103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398746.094000 752388.695000</gml:lowerCorner>
        		<gml:upperCorner>398746.094000 752388.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398746.094000 752388.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 088 450</ms:GML_ID>
        <ms:NAZWA>030 088 450</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030088450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400173.332438 751898.234222</gml:lowerCorner>
        		<gml:upperCorner>400173.332438 751898.234222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400173.332438 751898.234222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 086 940</ms:GML_ID>
        <ms:NAZWA>030 086 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030086940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408227.856000 753160.424000</gml:lowerCorner>
        		<gml:upperCorner>408227.856000 753160.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408227.856000 753160.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 076 404</ms:GML_ID>
        <ms:NAZWA>030 076 404</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030076404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408991.072000 753871.520000</gml:lowerCorner>
        		<gml:upperCorner>408991.072000 753871.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408991.072000 753871.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 075 333</ms:GML_ID>
        <ms:NAZWA>030 075 333</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030075333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410335.571000 754975.597000</gml:lowerCorner>
        		<gml:upperCorner>410335.571000 754975.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410335.571000 754975.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 073 453</ms:GML_ID>
        <ms:NAZWA>030 073 453</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030073453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410788.176000 756770.347000</gml:lowerCorner>
        		<gml:upperCorner>410788.176000 756770.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410788.176000 756770.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 071 396</ms:GML_ID>
        <ms:NAZWA>030 071 396</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030071396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410844.666919 757259.295191</gml:lowerCorner>
        		<gml:upperCorner>410844.666919 757259.295191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410844.666919 757259.295191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 070 893</ms:GML_ID>
        <ms:NAZWA>030 070 893</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030070893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410870.360808 755680.233231</gml:lowerCorner>
        		<gml:upperCorner>410870.360808 755680.233231</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410870.360808 755680.233231</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 072 491</ms:GML_ID>
        <ms:NAZWA>030 072 491</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030072491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>411365.748436 757726.073768</gml:lowerCorner>
        		<gml:upperCorner>411365.748436 757726.073768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>411365.748436 757726.073768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 070 190</ms:GML_ID>
        <ms:NAZWA>030 070 190</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030070190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>411811.668967 758085.208420</gml:lowerCorner>
        		<gml:upperCorner>411811.668967 758085.208420</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>411811.668967 758085.208420</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 069 617</ms:GML_ID>
        <ms:NAZWA>030 069 617</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030069617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413534.311071 759471.196811</gml:lowerCorner>
        		<gml:upperCorner>413534.311071 759471.196811</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413534.311071 759471.196811</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 067 407</ms:GML_ID>
        <ms:NAZWA>030 067 407</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030067407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414382.333000 760154.074000</gml:lowerCorner>
        		<gml:upperCorner>414382.333000 760154.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414382.333000 760154.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 066 318</ms:GML_ID>
        <ms:NAZWA>030 066 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030066318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415218.983891 760828.169396</gml:lowerCorner>
        		<gml:upperCorner>415218.983891 760828.169396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415218.983891 760828.169396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 065 243</ms:GML_ID>
        <ms:NAZWA>030 065 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030065243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416010.257500 761433.073454</gml:lowerCorner>
        		<gml:upperCorner>416010.257500 761433.073454</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416010.257500 761433.073454</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 064 245</ms:GML_ID>
        <ms:NAZWA>030 064 245</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030064245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384295.248000 820176.007000</gml:lowerCorner>
        		<gml:upperCorner>384295.248000 820176.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384295.248000 820176.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 012 789</ms:GML_ID>
        <ms:NAZWA>081 012 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081012789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385263.127000 820701.363000</gml:lowerCorner>
        		<gml:upperCorner>385263.127000 820701.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385263.127000 820701.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 013 889</ms:GML_ID>
        <ms:NAZWA>081 013 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081013889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386250.029000 821219.084000</gml:lowerCorner>
        		<gml:upperCorner>386250.029000 821219.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386250.029000 821219.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 015 004</ms:GML_ID>
        <ms:NAZWA>081 015 004</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081015004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386619.981000 821334.241000</gml:lowerCorner>
        		<gml:upperCorner>386619.981000 821334.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386619.981000 821334.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 015 391</ms:GML_ID>
        <ms:NAZWA>081 015 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081015391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387322.101000 821536.757000</gml:lowerCorner>
        		<gml:upperCorner>387322.101000 821536.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387322.101000 821536.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 016 122</ms:GML_ID>
        <ms:NAZWA>081 016 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081016122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389226.980000 822022.062000</gml:lowerCorner>
        		<gml:upperCorner>389226.980000 822022.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389226.980000 822022.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 018 089</ms:GML_ID>
        <ms:NAZWA>081 018 089</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081018089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390324.037935 821941.545067</gml:lowerCorner>
        		<gml:upperCorner>390324.037935 821941.545067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390324.037935 821941.545067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 019 191</ms:GML_ID>
        <ms:NAZWA>081 019 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081019191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391095.961000 821871.316000</gml:lowerCorner>
        		<gml:upperCorner>391095.961000 821871.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391095.961000 821871.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 019 964</ms:GML_ID>
        <ms:NAZWA>081 019 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081019964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393240.571000 821878.683000</gml:lowerCorner>
        		<gml:upperCorner>393240.571000 821878.683000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393240.571000 821878.683000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 022 114</ms:GML_ID>
        <ms:NAZWA>081 022 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081022114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394110.067094 821625.792792</gml:lowerCorner>
        		<gml:upperCorner>394110.067094 821625.792792</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394110.067094 821625.792792</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 023 017</ms:GML_ID>
        <ms:NAZWA>081 023 017</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081023017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394909.429000 821395.016000</gml:lowerCorner>
        		<gml:upperCorner>394909.429000 821395.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394909.429000 821395.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 023 850</ms:GML_ID>
        <ms:NAZWA>081 023 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081023850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395381.936616 821255.684404</gml:lowerCorner>
        		<gml:upperCorner>395381.936616 821255.684404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395381.936616 821255.684404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 024 342</ms:GML_ID>
        <ms:NAZWA>081 024 342</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081024342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396515.949000 821123.594000</gml:lowerCorner>
        		<gml:upperCorner>396515.949000 821123.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396515.949000 821123.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 025 497</ms:GML_ID>
        <ms:NAZWA>081 025 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081025497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397114.963739 820915.887352</gml:lowerCorner>
        		<gml:upperCorner>397114.963739 820915.887352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397114.963739 820915.887352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 026 136</ms:GML_ID>
        <ms:NAZWA>081 026 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081026136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397918.347083 820895.824667</gml:lowerCorner>
        		<gml:upperCorner>397918.347083 820895.824667</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397918.347083 820895.824667</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 026 940</ms:GML_ID>
        <ms:NAZWA>081 026 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081026940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399996.419000 820843.209000</gml:lowerCorner>
        		<gml:upperCorner>399996.419000 820843.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399996.419000 820843.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 029 145</ms:GML_ID>
        <ms:NAZWA>081 029 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081029145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401589.512000 820427.323000</gml:lowerCorner>
        		<gml:upperCorner>401589.512000 820427.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401589.512000 820427.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 030 665</ms:GML_ID>
        <ms:NAZWA>081 030 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081030665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407443.446021 819313.994080</gml:lowerCorner>
        		<gml:upperCorner>407443.446021 819313.994080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407443.446021 819313.994080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 036 643</ms:GML_ID>
        <ms:NAZWA>081 036 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081036643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412818.855873 818471.229179</gml:lowerCorner>
        		<gml:upperCorner>412818.855873 818471.229179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412818.855873 818471.229179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 042 107</ms:GML_ID>
        <ms:NAZWA>081 042 107</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081042107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415866.183820 818156.349674</gml:lowerCorner>
        		<gml:upperCorner>415866.183820 818156.349674</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415866.183820 818156.349674</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 045 238</ms:GML_ID>
        <ms:NAZWA>081 045 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081045238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388331.863523 752002.269163</gml:lowerCorner>
        		<gml:upperCorner>388331.863523 752002.269163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388331.863523 752002.269163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 100 016</ms:GML_ID>
        <ms:NAZWA>030 100 016</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030100016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387034.361582 752820.492200</gml:lowerCorner>
        		<gml:upperCorner>387034.361582 752820.492200</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387034.361582 752820.492200</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 101 555</ms:GML_ID>
        <ms:NAZWA>030 101 555</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030101555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380719.987943 752926.303720</gml:lowerCorner>
        		<gml:upperCorner>380719.987943 752926.303720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380719.987943 752926.303720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 004 200</ms:GML_ID>
        <ms:NAZWA>067 004 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067004200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380625.194303 752959.853014</gml:lowerCorner>
        		<gml:upperCorner>380625.194303 752959.853014</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380625.194303 752959.853014</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 004 226</ms:GML_ID>
        <ms:NAZWA>067 004 226</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067004226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380586.946878 753122.087979</gml:lowerCorner>
        		<gml:upperCorner>380586.946878 753122.087979</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380586.946878 753122.087979</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 004 374</ms:GML_ID>
        <ms:NAZWA>067 004 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067004374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380628.963920 753357.926696</gml:lowerCorner>
        		<gml:upperCorner>380628.963920 753357.926696</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380628.963920 753357.926696</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 004 625</ms:GML_ID>
        <ms:NAZWA>067 004 625</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067004625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382090.429140 753742.990629</gml:lowerCorner>
        		<gml:upperCorner>382090.429140 753742.990629</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382090.429140 753742.990629</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 180 716</ms:GML_ID>
        <ms:NAZWA>007 180 716</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007180716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381479.642614 754671.526809</gml:lowerCorner>
        		<gml:upperCorner>381479.642614 754671.526809</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381479.642614 754671.526809</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 181 933</ms:GML_ID>
        <ms:NAZWA>007 181 933</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007181933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380778.871467 754746.286555</gml:lowerCorner>
        		<gml:upperCorner>380778.871467 754746.286555</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380778.871467 754746.286555</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.562 000 581</ms:GML_ID>
        <ms:NAZWA>562 000 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>562000581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379555.406013 757570.142866</gml:lowerCorner>
        		<gml:upperCorner>379555.406013 757570.142866</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379555.406013 757570.142866</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 185 733</ms:GML_ID>
        <ms:NAZWA>007 185 733</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007185733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379257.449000 759121.803000</gml:lowerCorner>
        		<gml:upperCorner>379257.449000 759121.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379257.449000 759121.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 187 316</ms:GML_ID>
        <ms:NAZWA>007 187 316</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007187316</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380698.723973 759304.432286</gml:lowerCorner>
        		<gml:upperCorner>380698.723973 759304.432286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380698.723973 759304.432286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.581 003 006</ms:GML_ID>
        <ms:NAZWA>581 003 006</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>581003006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380515.710143 759312.389465</gml:lowerCorner>
        		<gml:upperCorner>380515.710143 759312.389465</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380515.710143 759312.389465</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.581 002 822</ms:GML_ID>
        <ms:NAZWA>581 002 822</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>581002822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379410.605000 761183.446000</gml:lowerCorner>
        		<gml:upperCorner>379410.605000 761183.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379410.605000 761183.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 189 383</ms:GML_ID>
        <ms:NAZWA>007 189 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007189383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379250.829935 762275.659547</gml:lowerCorner>
        		<gml:upperCorner>379250.829935 762275.659547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379250.829935 762275.659547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 190 512</ms:GML_ID>
        <ms:NAZWA>007 190 512</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007190512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378691.616000 763487.124000</gml:lowerCorner>
        		<gml:upperCorner>378691.616000 763487.124000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378691.616000 763487.124000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 191 846</ms:GML_ID>
        <ms:NAZWA>007 191 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007191846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378776.769000 768012.283000</gml:lowerCorner>
        		<gml:upperCorner>378776.769000 768012.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378776.769000 768012.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 196 598</ms:GML_ID>
        <ms:NAZWA>007 196 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007196598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378656.103282 769605.433527</gml:lowerCorner>
        		<gml:upperCorner>378656.103282 769605.433527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378656.103282 769605.433527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 198 196</ms:GML_ID>
        <ms:NAZWA>007 198 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007198196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378605.637197 770269.240249</gml:lowerCorner>
        		<gml:upperCorner>378605.637197 770269.240249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378605.637197 770269.240249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 198 862</ms:GML_ID>
        <ms:NAZWA>007 198 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007198862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374996.049000 816011.245000</gml:lowerCorner>
        		<gml:upperCorner>374996.049000 816011.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374996.049000 816011.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 002 606</ms:GML_ID>
        <ms:NAZWA>081 002 606</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081002606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377815.729260 817281.190911</gml:lowerCorner>
        		<gml:upperCorner>377815.729260 817281.190911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377815.729260 817281.190911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 005 696</ms:GML_ID>
        <ms:NAZWA>081 005 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081005696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378298.052000 817497.402000</gml:lowerCorner>
        		<gml:upperCorner>378298.052000 817497.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378298.052000 817497.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 006 245</ms:GML_ID>
        <ms:NAZWA>081 006 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081006245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378987.711000 817806.211000</gml:lowerCorner>
        		<gml:upperCorner>378987.711000 817806.211000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378987.711000 817806.211000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 006 979</ms:GML_ID>
        <ms:NAZWA>081 006 979</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081006979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380948.487000 818682.508000</gml:lowerCorner>
        		<gml:upperCorner>380948.487000 818682.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380948.487000 818682.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 009 125</ms:GML_ID>
        <ms:NAZWA>081 009 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081009125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382281.005000 819278.875000</gml:lowerCorner>
        		<gml:upperCorner>382281.005000 819278.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382281.005000 819278.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 010 585</ms:GML_ID>
        <ms:NAZWA>081 010 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081010585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382930.329000 819567.874000</gml:lowerCorner>
        		<gml:upperCorner>382930.329000 819567.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382930.329000 819567.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 011 295</ms:GML_ID>
        <ms:NAZWA>081 011 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081011295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374422.434000 820224.974000</gml:lowerCorner>
        		<gml:upperCorner>374422.434000 820224.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374422.434000 820224.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 254 609</ms:GML_ID>
        <ms:NAZWA>007 254 609</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007254609</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374982.229000 821746.364000</gml:lowerCorner>
        		<gml:upperCorner>374982.229000 821746.364000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374982.229000 821746.364000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 256 263</ms:GML_ID>
        <ms:NAZWA>007 256 263</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007256263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375963.496238 823279.323821</gml:lowerCorner>
        		<gml:upperCorner>375963.496238 823279.323821</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375963.496238 823279.323821</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 258 101</ms:GML_ID>
        <ms:NAZWA>007 258 101</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007258101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376640.957000 826166.543000</gml:lowerCorner>
        		<gml:upperCorner>376640.957000 826166.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376640.957000 826166.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 261 058</ms:GML_ID>
        <ms:NAZWA>007 261 058</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007261058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376958.296249 827569.421469</gml:lowerCorner>
        		<gml:upperCorner>376958.296249 827569.421469</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376958.296249 827569.421469</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 262 495</ms:GML_ID>
        <ms:NAZWA>007 262 495</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007262495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377236.018000 828546.459000</gml:lowerCorner>
        		<gml:upperCorner>377236.018000 828546.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377236.018000 828546.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 263 517</ms:GML_ID>
        <ms:NAZWA>007 263 517</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007263517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377630.637088 829914.252600</gml:lowerCorner>
        		<gml:upperCorner>377630.637088 829914.252600</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377630.637088 829914.252600</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 264 932</ms:GML_ID>
        <ms:NAZWA>007 264 932</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007264932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377578.151421 830243.184737</gml:lowerCorner>
        		<gml:upperCorner>377578.151421 830243.184737</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377578.151421 830243.184737</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.788 000 661</ms:GML_ID>
        <ms:NAZWA>788 000 661</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>788000661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377750.152000 830682.582000</gml:lowerCorner>
        		<gml:upperCorner>377750.152000 830682.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377750.152000 830682.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 265 712</ms:GML_ID>
        <ms:NAZWA>007 265 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007265712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377270.738245 830940.607547</gml:lowerCorner>
        		<gml:upperCorner>377270.738245 830940.607547</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377270.738245 830940.607547</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.788 001 421</ms:GML_ID>
        <ms:NAZWA>788 001 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>788001421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377404.683966 831782.915503</gml:lowerCorner>
        		<gml:upperCorner>377404.683966 831782.915503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377404.683966 831782.915503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.789 001 886</ms:GML_ID>
        <ms:NAZWA>789 001 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>789001886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377746.164991 832726.806957</gml:lowerCorner>
        		<gml:upperCorner>377746.164991 832726.806957</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377746.164991 832726.806957</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.789 000 884</ms:GML_ID>
        <ms:NAZWA>789 000 884</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>789000884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377871.572000 832779.155000</gml:lowerCorner>
        		<gml:upperCorner>377871.572000 832779.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377871.572000 832779.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 267 809</ms:GML_ID>
        <ms:NAZWA>007 267 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007267809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377877.869705 832888.556946</gml:lowerCorner>
        		<gml:upperCorner>377877.869705 832888.556946</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377877.869705 832888.556946</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 267 919</ms:GML_ID>
        <ms:NAZWA>007 267 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007267919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378268.350000 834700.329000</gml:lowerCorner>
        		<gml:upperCorner>378268.350000 834700.329000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378268.350000 834700.329000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 269 774</ms:GML_ID>
        <ms:NAZWA>007 269 774</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007269774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370976.408161 741275.261655</gml:lowerCorner>
        		<gml:upperCorner>370976.408161 741275.261655</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370976.408161 741275.261655</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 013 128</ms:GML_ID>
        <ms:NAZWA>068 013 128</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068013128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370873.688389 742414.500331</gml:lowerCorner>
        		<gml:upperCorner>370873.688389 742414.500331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370873.688389 742414.500331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 011 965</ms:GML_ID>
        <ms:NAZWA>068 011 965</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068011965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377568.324242 742522.424352</gml:lowerCorner>
        		<gml:upperCorner>377568.324242 742522.424352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377568.324242 742522.424352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 167 715</ms:GML_ID>
        <ms:NAZWA>007 167 715</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007167715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371036.148571 743019.962625</gml:lowerCorner>
        		<gml:upperCorner>371036.148571 743019.962625</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371036.148571 743019.962625</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 011 331</ms:GML_ID>
        <ms:NAZWA>068 011 331</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068011331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371689.496000 743615.101000</gml:lowerCorner>
        		<gml:upperCorner>371689.496000 743615.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371689.496000 743615.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 010 441</ms:GML_ID>
        <ms:NAZWA>068 010 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068010441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372347.674431 744146.013382</gml:lowerCorner>
        		<gml:upperCorner>372347.674431 744146.013382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372347.674431 744146.013382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 009 596</ms:GML_ID>
        <ms:NAZWA>068 009 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068009596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372759.125054 744525.035620</gml:lowerCorner>
        		<gml:upperCorner>372759.125054 744525.035620</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372759.125054 744525.035620</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 009 035</ms:GML_ID>
        <ms:NAZWA>068 009 035</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068009035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373358.956000 745082.017000</gml:lowerCorner>
        		<gml:upperCorner>373358.956000 745082.017000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373358.956000 745082.017000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 008 216</ms:GML_ID>
        <ms:NAZWA>068 008 216</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068008216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374472.174000 745905.264000</gml:lowerCorner>
        		<gml:upperCorner>374472.174000 745905.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374472.174000 745905.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 006 828</ms:GML_ID>
        <ms:NAZWA>068 006 828</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068006828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375340.891000 746109.109000</gml:lowerCorner>
        		<gml:upperCorner>375340.891000 746109.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375340.891000 746109.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 005 929</ms:GML_ID>
        <ms:NAZWA>068 005 929</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068005929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376153.342660 746166.926485</gml:lowerCorner>
        		<gml:upperCorner>376153.342660 746166.926485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376153.342660 746166.926485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 005 112</ms:GML_ID>
        <ms:NAZWA>068 005 112</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068005112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378432.777810 746855.176660</gml:lowerCorner>
        		<gml:upperCorner>378432.777810 746855.176660</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378432.777810 746855.176660</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 002 660</ms:GML_ID>
        <ms:NAZWA>068 002 660</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068002660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378612.394185 747994.449477</gml:lowerCorner>
        		<gml:upperCorner>378612.394185 747994.449477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378612.394185 747994.449477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 173 267</ms:GML_ID>
        <ms:NAZWA>007 173 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007173267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379054.801134 748218.980321</gml:lowerCorner>
        		<gml:upperCorner>379054.801134 748218.980321</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379054.801134 748218.980321</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 173 679</ms:GML_ID>
        <ms:NAZWA>007 173 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007173679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378965.895183 748228.321344</gml:lowerCorner>
        		<gml:upperCorner>378965.895183 748228.321344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378965.895183 748228.321344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 173 622</ms:GML_ID>
        <ms:NAZWA>007 173 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007173622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380714.717857 750196.175457</gml:lowerCorner>
        		<gml:upperCorner>380714.717857 750196.175457</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380714.717857 750196.175457</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 176 376</ms:GML_ID>
        <ms:NAZWA>007 176 376</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007176376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403338.100152 750806.715222</gml:lowerCorner>
        		<gml:upperCorner>403338.100152 750806.715222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403338.100152 750806.715222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 083 593</ms:GML_ID>
        <ms:NAZWA>030 083 593</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030083593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402668.132000 751037.961000</gml:lowerCorner>
        		<gml:upperCorner>402668.132000 751037.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402668.132000 751037.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 084 301</ms:GML_ID>
        <ms:NAZWA>030 084 301</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030084301</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401577.958000 751414.133000</gml:lowerCorner>
        		<gml:upperCorner>401577.958000 751414.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401577.958000 751414.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 085 455</ms:GML_ID>
        <ms:NAZWA>030 085 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030085455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383952.698014 751448.395657</gml:lowerCorner>
        		<gml:upperCorner>383952.698014 751448.395657</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383952.698014 751448.395657</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 105 120</ms:GML_ID>
        <ms:NAZWA>030 105 120</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030105120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380695.320474 751736.654507</gml:lowerCorner>
        		<gml:upperCorner>380695.320474 751736.654507</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380695.320474 751736.654507</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 003 050</ms:GML_ID>
        <ms:NAZWA>067 003 050</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067003050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380824.744216 751801.296540</gml:lowerCorner>
        		<gml:upperCorner>380824.744216 751801.296540</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380824.744216 751801.296540</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.067 003 039</ms:GML_ID>
        <ms:NAZWA>067 003 039</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>067003039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382924.782000 751818.385000</gml:lowerCorner>
        		<gml:upperCorner>382924.782000 751818.385000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382924.782000 751818.385000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.030 106 210</ms:GML_ID>
        <ms:NAZWA>030 106 210</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>030106210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378461.550150 763986.542191</gml:lowerCorner>
        		<gml:upperCorner>378461.550150 763986.542191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378461.550150 763986.542191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 192 396</ms:GML_ID>
        <ms:NAZWA>007 192 396</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007192396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378255.952506 764437.008138</gml:lowerCorner>
        		<gml:upperCorner>378255.952506 764437.008138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378255.952506 764437.008138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 192 890</ms:GML_ID>
        <ms:NAZWA>007 192 890</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007192890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378188.940890 765356.178928</gml:lowerCorner>
        		<gml:upperCorner>378188.940890 765356.178928</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378188.940890 765356.178928</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 193 817</ms:GML_ID>
        <ms:NAZWA>007 193 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007193817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378560.717000 766496.419000</gml:lowerCorner>
        		<gml:upperCorner>378560.717000 766496.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378560.717000 766496.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 195 029</ms:GML_ID>
        <ms:NAZWA>007 195 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007195029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378545.484380 771057.269855</gml:lowerCorner>
        		<gml:upperCorner>378545.484380 771057.269855</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378545.484380 771057.269855</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 199 652</ms:GML_ID>
        <ms:NAZWA>007 199 652</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007199652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378484.328000 771864.177000</gml:lowerCorner>
        		<gml:upperCorner>378484.328000 771864.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378484.328000 771864.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 200 461</ms:GML_ID>
        <ms:NAZWA>007 200 461</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007200461</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376936.477000 774183.959000</gml:lowerCorner>
        		<gml:upperCorner>376936.477000 774183.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376936.477000 774183.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 203 313</ms:GML_ID>
        <ms:NAZWA>007 203 313</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007203313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376477.817000 774427.343000</gml:lowerCorner>
        		<gml:upperCorner>376477.817000 774427.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376477.817000 774427.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 203 830</ms:GML_ID>
        <ms:NAZWA>007 203 830</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007203830</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375045.545617 775152.144072</gml:lowerCorner>
        		<gml:upperCorner>375045.545617 775152.144072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375045.545617 775152.144072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 205 431</ms:GML_ID>
        <ms:NAZWA>007 205 431</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007205431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372493.641229 776280.677060</gml:lowerCorner>
        		<gml:upperCorner>372493.641229 776280.677060</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372493.641229 776280.677060</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 208 229</ms:GML_ID>
        <ms:NAZWA>007 208 229</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007208229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371958.194304 777049.001862</gml:lowerCorner>
        		<gml:upperCorner>371958.194304 777049.001862</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371958.194304 777049.001862</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 209 171</ms:GML_ID>
        <ms:NAZWA>007 209 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007209171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371219.911000 778673.247000</gml:lowerCorner>
        		<gml:upperCorner>371219.911000 778673.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371219.911000 778673.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 210 960</ms:GML_ID>
        <ms:NAZWA>007 210 960</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007210960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370593.148925 779618.079072</gml:lowerCorner>
        		<gml:upperCorner>370593.148925 779618.079072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370593.148925 779618.079072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 212 095</ms:GML_ID>
        <ms:NAZWA>007 212 095</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007212095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370343.784235 780082.153649</gml:lowerCorner>
        		<gml:upperCorner>370343.784235 780082.153649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370343.784235 780082.153649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 212 624</ms:GML_ID>
        <ms:NAZWA>007 212 624</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007212624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370306.760481 780536.718097</gml:lowerCorner>
        		<gml:upperCorner>370306.760481 780536.718097</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370306.760481 780536.718097</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 213 080</ms:GML_ID>
        <ms:NAZWA>007 213 080</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007213080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370490.541000 782263.277000</gml:lowerCorner>
        		<gml:upperCorner>370490.541000 782263.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370490.541000 782263.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 214 820</ms:GML_ID>
        <ms:NAZWA>007 214 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007214820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370251.353957 784552.046988</gml:lowerCorner>
        		<gml:upperCorner>370251.353957 784552.046988</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370251.353957 784552.046988</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 217 122</ms:GML_ID>
        <ms:NAZWA>007 217 122</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007217122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403286.306000 695416.161000</gml:lowerCorner>
        		<gml:upperCorner>403286.306000 695416.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403286.306000 695416.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 010 540</ms:GML_ID>
        <ms:NAZWA>082 010 540</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082010540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403276.236000 695652.920000</gml:lowerCorner>
        		<gml:upperCorner>403276.236000 695652.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403276.236000 695652.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 010 777</ms:GML_ID>
        <ms:NAZWA>082 010 777</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082010777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403372.628020 696351.413822</gml:lowerCorner>
        		<gml:upperCorner>403372.628020 696351.413822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403372.628020 696351.413822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 011 491</ms:GML_ID>
        <ms:NAZWA>082 011 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082011491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403455.322000 696832.681000</gml:lowerCorner>
        		<gml:upperCorner>403455.322000 696832.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403455.322000 696832.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 011 984</ms:GML_ID>
        <ms:NAZWA>082 011 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082011984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403247.097000 697383.265000</gml:lowerCorner>
        		<gml:upperCorner>403247.097000 697383.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403247.097000 697383.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 012 573</ms:GML_ID>
        <ms:NAZWA>082 012 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082012573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403169.939014 697816.117257</gml:lowerCorner>
        		<gml:upperCorner>403169.939014 697816.117257</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403169.939014 697816.117257</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 013 020</ms:GML_ID>
        <ms:NAZWA>082 013 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082013020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403190.072000 698318.568000</gml:lowerCorner>
        		<gml:upperCorner>403190.072000 698318.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403190.072000 698318.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.082 013 524</ms:GML_ID>
        <ms:NAZWA>082 013 524</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>082013524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403016.811466 705948.753026</gml:lowerCorner>
        		<gml:upperCorner>403016.811466 705948.753026</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403016.811466 705948.753026</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 120 443</ms:GML_ID>
        <ms:NAZWA>007 120 443</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007120443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396834.211000 711976.251000</gml:lowerCorner>
        		<gml:upperCorner>396834.211000 711976.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396834.211000 711976.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 129 625</ms:GML_ID>
        <ms:NAZWA>007 129 625</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007129625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396416.714000 713225.362000</gml:lowerCorner>
        		<gml:upperCorner>396416.714000 713225.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396416.714000 713225.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 130 940</ms:GML_ID>
        <ms:NAZWA>007 130 940</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007130940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392759.856993 716785.691942</gml:lowerCorner>
        		<gml:upperCorner>392759.856993 716785.691942</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392759.856993 716785.691942</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 136 312</ms:GML_ID>
        <ms:NAZWA>007 136 312</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007136312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391931.466139 717659.752603</gml:lowerCorner>
        		<gml:upperCorner>391931.466139 717659.752603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391931.466139 717659.752603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 137 516</ms:GML_ID>
        <ms:NAZWA>007 137 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007137516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389498.018192 719479.074942</gml:lowerCorner>
        		<gml:upperCorner>389498.018192 719479.074942</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389498.018192 719479.074942</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 140 614</ms:GML_ID>
        <ms:NAZWA>007 140 614</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007140614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389184.946013 720315.206634</gml:lowerCorner>
        		<gml:upperCorner>389184.946013 720315.206634</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389184.946013 720315.206634</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 141 509</ms:GML_ID>
        <ms:NAZWA>007 141 509</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007141509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388375.838085 722047.111389</gml:lowerCorner>
        		<gml:upperCorner>388375.838085 722047.111389</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388375.838085 722047.111389</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 143 433</ms:GML_ID>
        <ms:NAZWA>007 143 433</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007143433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385378.822484 728616.656963</gml:lowerCorner>
        		<gml:upperCorner>385378.822484 728616.656963</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385378.822484 728616.656963</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 151 360</ms:GML_ID>
        <ms:NAZWA>007 151 360</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007151360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385159.960333 728853.768802</gml:lowerCorner>
        		<gml:upperCorner>385159.960333 728853.768802</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385159.960333 728853.768802</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 151 683</ms:GML_ID>
        <ms:NAZWA>007 151 683</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007151683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384555.623446 729521.670628</gml:lowerCorner>
        		<gml:upperCorner>384555.623446 729521.670628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384555.623446 729521.670628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 152 582</ms:GML_ID>
        <ms:NAZWA>007 152 582</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007152582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383146.036998 731074.895541</gml:lowerCorner>
        		<gml:upperCorner>383146.036998 731074.895541</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383146.036998 731074.895541</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 154 683</ms:GML_ID>
        <ms:NAZWA>007 154 683</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007154683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380593.555286 734393.377780</gml:lowerCorner>
        		<gml:upperCorner>380593.555286 734393.377780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380593.555286 734393.377780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 158 876</ms:GML_ID>
        <ms:NAZWA>007 158 876</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007158876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379966.132424 735311.152859</gml:lowerCorner>
        		<gml:upperCorner>379966.132424 735311.152859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379966.132424 735311.152859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 159 990</ms:GML_ID>
        <ms:NAZWA>007 159 990</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007159990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366910.470000 736657.881000</gml:lowerCorner>
        		<gml:upperCorner>366910.470000 736657.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366910.470000 736657.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 019 449</ms:GML_ID>
        <ms:NAZWA>068 019 449</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068019449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367591.372675 737128.009176</gml:lowerCorner>
        		<gml:upperCorner>367591.372675 737128.009176</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367591.372675 737128.009176</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 018 622</ms:GML_ID>
        <ms:NAZWA>068 018 622</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068018622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368607.254000 738003.769000</gml:lowerCorner>
        		<gml:upperCorner>368607.254000 738003.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368607.254000 738003.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 017 280</ms:GML_ID>
        <ms:NAZWA>068 017 280</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068017280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369596.637754 738821.542277</gml:lowerCorner>
        		<gml:upperCorner>369596.637754 738821.542277</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369596.637754 738821.542277</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 015 996</ms:GML_ID>
        <ms:NAZWA>068 015 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068015996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378200.973603 739352.350992</gml:lowerCorner>
        		<gml:upperCorner>378200.973603 739352.350992</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378200.973603 739352.350992</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 164 447</ms:GML_ID>
        <ms:NAZWA>007 164 447</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007164447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370134.452000 739488.470000</gml:lowerCorner>
        		<gml:upperCorner>370134.452000 739488.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370134.452000 739488.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 015 132</ms:GML_ID>
        <ms:NAZWA>068 015 132</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068015132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370089.782000 786108.529000</gml:lowerCorner>
        		<gml:upperCorner>370089.782000 786108.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370089.782000 786108.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 218 683</ms:GML_ID>
        <ms:NAZWA>007 218 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007218683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369940.471000 787559.216000</gml:lowerCorner>
        		<gml:upperCorner>369940.471000 787559.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369940.471000 787559.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 220 143</ms:GML_ID>
        <ms:NAZWA>007 220 143</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007220143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369904.599733 789165.721062</gml:lowerCorner>
        		<gml:upperCorner>369904.599733 789165.721062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369904.599733 789165.721062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 221 759</ms:GML_ID>
        <ms:NAZWA>007 221 759</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007221759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369919.583455 791060.512784</gml:lowerCorner>
        		<gml:upperCorner>369919.583455 791060.512784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369919.583455 791060.512784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 223 657</ms:GML_ID>
        <ms:NAZWA>007 223 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007223657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369902.618996 792189.294775</gml:lowerCorner>
        		<gml:upperCorner>369902.618996 792189.294775</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369902.618996 792189.294775</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 224 786</ms:GML_ID>
        <ms:NAZWA>007 224 786</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007224786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363457.916636 792236.531782</gml:lowerCorner>
        		<gml:upperCorner>363457.916636 792236.531782</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363457.916636 792236.531782</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 008 715</ms:GML_ID>
        <ms:NAZWA>069 008 715</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069008715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362524.001220 792464.257534</gml:lowerCorner>
        		<gml:upperCorner>362524.001220 792464.257534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362524.001220 792464.257534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 009 699</ms:GML_ID>
        <ms:NAZWA>069 009 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069009699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361065.186732 793102.533385</gml:lowerCorner>
        		<gml:upperCorner>361065.186732 793102.533385</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361065.186732 793102.533385</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 011 298</ms:GML_ID>
        <ms:NAZWA>069 011 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069011298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364464.564281 793171.100998</gml:lowerCorner>
        		<gml:upperCorner>364464.564281 793171.100998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364464.564281 793171.100998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 007 288</ms:GML_ID>
        <ms:NAZWA>069 007 288</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069007288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359936.531780 793195.190114</gml:lowerCorner>
        		<gml:upperCorner>359936.531780 793195.190114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359936.531780 793195.190114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 012 434</ms:GML_ID>
        <ms:NAZWA>069 012 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069012434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358795.776522 793216.429208</gml:lowerCorner>
        		<gml:upperCorner>358795.776522 793216.429208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358795.776522 793216.429208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 013 576</ms:GML_ID>
        <ms:NAZWA>069 013 576</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069013576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365142.945000 793390.087000</gml:lowerCorner>
        		<gml:upperCorner>365142.945000 793390.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365142.945000 793390.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 006 571</ms:GML_ID>
        <ms:NAZWA>069 006 571</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069006571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354904.083000 793433.438000</gml:lowerCorner>
        		<gml:upperCorner>354904.083000 793433.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354904.083000 793433.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 018 230</ms:GML_ID>
        <ms:NAZWA>069 018 230</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069018230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366216.996000 793504.912000</gml:lowerCorner>
        		<gml:upperCorner>366216.996000 793504.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366216.996000 793504.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 005 464</ms:GML_ID>
        <ms:NAZWA>069 005 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069005464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354688.466000 793509.748000</gml:lowerCorner>
        		<gml:upperCorner>354688.466000 793509.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354688.466000 793509.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 018 458</ms:GML_ID>
        <ms:NAZWA>069 018 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069018458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365784.997000 793575.298000</gml:lowerCorner>
        		<gml:upperCorner>365784.997000 793575.298000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365784.997000 793575.298000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 005 902</ms:GML_ID>
        <ms:NAZWA>069 005 902</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069005902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356793.749026 793783.819127</gml:lowerCorner>
        		<gml:upperCorner>356793.749026 793783.819127</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356793.749026 793783.819127</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 015 817</ms:GML_ID>
        <ms:NAZWA>069 015 817</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069015817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370211.760879 793795.826077</gml:lowerCorner>
        		<gml:upperCorner>370211.760879 793795.826077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370211.760879 793795.826077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 226 420</ms:GML_ID>
        <ms:NAZWA>007 226 420</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007226420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355608.360969 794040.980843</gml:lowerCorner>
        		<gml:upperCorner>355608.360969 794040.980843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355608.360969 794040.980843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 017 160</ms:GML_ID>
        <ms:NAZWA>069 017 160</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069017160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350381.696646 794045.841608</gml:lowerCorner>
        		<gml:upperCorner>350381.696646 794045.841608</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350381.696646 794045.841608</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 022 897</ms:GML_ID>
        <ms:NAZWA>069 022 897</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069022897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355877.452383 794153.240370</gml:lowerCorner>
        		<gml:upperCorner>355877.452383 794153.240370</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355877.452383 794153.240370</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 016 863</ms:GML_ID>
        <ms:NAZWA>069 016 863</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069016863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370292.149000 794158.323000</gml:lowerCorner>
        		<gml:upperCorner>370292.149000 794158.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370292.149000 794158.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 226 791</ms:GML_ID>
        <ms:NAZWA>007 226 791</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007226791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370194.925959 794258.145119</gml:lowerCorner>
        		<gml:upperCorner>370194.925959 794258.145119</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370194.925959 794258.145119</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.563 000 438</ms:GML_ID>
        <ms:NAZWA>563 000 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>563000438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349126.906000 794354.538000</gml:lowerCorner>
        		<gml:upperCorner>349126.906000 794354.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349126.906000 794354.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 024 210</ms:GML_ID>
        <ms:NAZWA>069 024 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069024210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368678.595000 794630.223000</gml:lowerCorner>
        		<gml:upperCorner>368678.595000 794630.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368678.595000 794630.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 002 724</ms:GML_ID>
        <ms:NAZWA>069 002 724</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069002724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369895.686142 794720.402780</gml:lowerCorner>
        		<gml:upperCorner>369895.686142 794720.402780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369895.686142 794720.402780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.563 000 990</ms:GML_ID>
        <ms:NAZWA>563 000 990</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>563000990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370259.214220 794766.609478</gml:lowerCorner>
        		<gml:upperCorner>370259.214220 794766.609478</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370259.214220 794766.609478</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 227 415</ms:GML_ID>
        <ms:NAZWA>007 227 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007227415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369784.039000 795187.338000</gml:lowerCorner>
        		<gml:upperCorner>369784.039000 795187.338000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369784.039000 795187.338000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 001 422</ms:GML_ID>
        <ms:NAZWA>069 001 422</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069001422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369699.603128 797075.962378</gml:lowerCorner>
        		<gml:upperCorner>369699.603128 797075.962378</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369699.603128 797075.962378</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 229 806</ms:GML_ID>
        <ms:NAZWA>007 229 806</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007229806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369602.765000 797867.192000</gml:lowerCorner>
        		<gml:upperCorner>369602.765000 797867.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369602.765000 797867.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 230 603</ms:GML_ID>
        <ms:NAZWA>007 230 603</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007230603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368818.371000 799159.188000</gml:lowerCorner>
        		<gml:upperCorner>368818.371000 799159.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368818.371000 799159.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 232 167</ms:GML_ID>
        <ms:NAZWA>007 232 167</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007232167</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369549.954000 800646.128000</gml:lowerCorner>
        		<gml:upperCorner>369549.954000 800646.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369549.954000 800646.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 233 843</ms:GML_ID>
        <ms:NAZWA>007 233 843</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007233843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370570.024000 802703.675000</gml:lowerCorner>
        		<gml:upperCorner>370570.024000 802703.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370570.024000 802703.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 236 134</ms:GML_ID>
        <ms:NAZWA>007 236 134</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007236134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371002.330000 803559.345000</gml:lowerCorner>
        		<gml:upperCorner>371002.330000 803559.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371002.330000 803559.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 237 096</ms:GML_ID>
        <ms:NAZWA>007 237 096</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007237096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371426.139000 807759.025000</gml:lowerCorner>
        		<gml:upperCorner>371426.139000 807759.025000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371426.139000 807759.025000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 241 546</ms:GML_ID>
        <ms:NAZWA>007 241 546</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007241546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372368.304000 808167.275000</gml:lowerCorner>
        		<gml:upperCorner>372368.304000 808167.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372368.304000 808167.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.063 029 425</ms:GML_ID>
        <ms:NAZWA>063 029 425</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>063029425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371810.727000 808656.268000</gml:lowerCorner>
        		<gml:upperCorner>371810.727000 808656.268000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371810.727000 808656.268000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 242 528</ms:GML_ID>
        <ms:NAZWA>007 242 528</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007242528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372334.230000 808949.759000</gml:lowerCorner>
        		<gml:upperCorner>372334.230000 808949.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372334.230000 808949.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.063 028 639</ms:GML_ID>
        <ms:NAZWA>063 028 639</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>063028639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372255.614000 809500.524000</gml:lowerCorner>
        		<gml:upperCorner>372255.614000 809500.524000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372255.614000 809500.524000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.063 028 084</ms:GML_ID>
        <ms:NAZWA>063 028 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>063028084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372240.028000 809926.986000</gml:lowerCorner>
        		<gml:upperCorner>372240.028000 809926.986000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372240.028000 809926.986000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 243 883</ms:GML_ID>
        <ms:NAZWA>007 243 883</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007243883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372313.756000 810708.614000</gml:lowerCorner>
        		<gml:upperCorner>372313.756000 810708.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372313.756000 810708.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 244 676</ms:GML_ID>
        <ms:NAZWA>007 244 676</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007244676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372984.049000 811841.187000</gml:lowerCorner>
        		<gml:upperCorner>372984.049000 811841.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372984.049000 811841.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 245 981</ms:GML_ID>
        <ms:NAZWA>007 245 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007245981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373308.115000 813279.696000</gml:lowerCorner>
        		<gml:upperCorner>373308.115000 813279.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373308.115000 813279.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 247 478</ms:GML_ID>
        <ms:NAZWA>007 247 478</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007247478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373526.022613 815021.390649</gml:lowerCorner>
        		<gml:upperCorner>373526.022613 815021.390649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373526.022613 815021.390649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 249 226</ms:GML_ID>
        <ms:NAZWA>007 249 226</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007249226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373584.865927 815028.031891</gml:lowerCorner>
        		<gml:upperCorner>373584.865927 815028.031891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373584.865927 815028.031891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.081 000 810</ms:GML_ID>
        <ms:NAZWA>081 000 810</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>081000810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373524.166376 816456.790340</gml:lowerCorner>
        		<gml:upperCorner>373524.166376 816456.790340</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373524.166376 816456.790340</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 250 673</ms:GML_ID>
        <ms:NAZWA>007 250 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007250673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373495.809586 816518.091103</gml:lowerCorner>
        		<gml:upperCorner>373495.809586 816518.091103</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373495.809586 816518.091103</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 250 734</ms:GML_ID>
        <ms:NAZWA>007 250 734</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007250734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373529.944654 817175.975157</gml:lowerCorner>
        		<gml:upperCorner>373529.944654 817175.975157</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373529.944654 817175.975157</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.063 020 145</ms:GML_ID>
        <ms:NAZWA>063 020 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>063020145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373533.231336 817290.982313</gml:lowerCorner>
        		<gml:upperCorner>373533.231336 817290.982313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373533.231336 817290.982313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 251 503</ms:GML_ID>
        <ms:NAZWA>007 251 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007251503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373601.863040 817487.789819</gml:lowerCorner>
        		<gml:upperCorner>373601.863040 817487.789819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373601.863040 817487.789819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 251 704</ms:GML_ID>
        <ms:NAZWA>007 251 704</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007251704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373927.459000 818629.236000</gml:lowerCorner>
        		<gml:upperCorner>373927.459000 818629.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373927.459000 818629.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 252 911</ms:GML_ID>
        <ms:NAZWA>007 252 911</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>007252911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327599.915223 828433.414211</gml:lowerCorner>
        		<gml:upperCorner>327599.915223 828433.414211</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327599.915223 828433.414211</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 040 196</ms:GML_ID>
        <ms:NAZWA>072 040 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072040196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327886.566020 829306.044603</gml:lowerCorner>
        		<gml:upperCorner>327886.566020 829306.044603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327886.566020 829306.044603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 041 132</ms:GML_ID>
        <ms:NAZWA>072 041 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072041132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328061.081000 829638.366000</gml:lowerCorner>
        		<gml:upperCorner>328061.081000 829638.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328061.081000 829638.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 041 503</ms:GML_ID>
        <ms:NAZWA>072 041 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072041503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328465.375000 830407.270000</gml:lowerCorner>
        		<gml:upperCorner>328465.375000 830407.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328465.375000 830407.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 042 374</ms:GML_ID>
        <ms:NAZWA>072 042 374</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072042374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329239.887000 831237.013000</gml:lowerCorner>
        		<gml:upperCorner>329239.887000 831237.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329239.887000 831237.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 043 516</ms:GML_ID>
        <ms:NAZWA>072 043 516</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072043516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329882.959391 832150.218552</gml:lowerCorner>
        		<gml:upperCorner>329882.959391 832150.218552</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329882.959391 832150.218552</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 044 632</ms:GML_ID>
        <ms:NAZWA>072 044 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072044632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329602.761121 833730.555114</gml:lowerCorner>
        		<gml:upperCorner>329602.761121 833730.555114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329602.761121 833730.555114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 046 307</ms:GML_ID>
        <ms:NAZWA>072 046 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072046307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330006.781108 834521.379913</gml:lowerCorner>
        		<gml:upperCorner>330006.781108 834521.379913</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330006.781108 834521.379913</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 047 220</ms:GML_ID>
        <ms:NAZWA>072 047 220</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072047220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330716.759374 835715.896923</gml:lowerCorner>
        		<gml:upperCorner>330716.759374 835715.896923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330716.759374 835715.896923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 048 635</ms:GML_ID>
        <ms:NAZWA>072 048 635</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072048635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330662.775856 836393.320128</gml:lowerCorner>
        		<gml:upperCorner>330662.775856 836393.320128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330662.775856 836393.320128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 049 312</ms:GML_ID>
        <ms:NAZWA>072 049 312</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072049312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330899.016000 837219.473000</gml:lowerCorner>
        		<gml:upperCorner>330899.016000 837219.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330899.016000 837219.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 050 194</ms:GML_ID>
        <ms:NAZWA>072 050 194</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072050194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331681.032025 838344.351744</gml:lowerCorner>
        		<gml:upperCorner>331681.032025 838344.351744</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331681.032025 838344.351744</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 051 659</ms:GML_ID>
        <ms:NAZWA>072 051 659</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072051659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331387.983000 839429.554000</gml:lowerCorner>
        		<gml:upperCorner>331387.983000 839429.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331387.983000 839429.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 052 781</ms:GML_ID>
        <ms:NAZWA>072 052 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072052781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331485.650075 840557.498344</gml:lowerCorner>
        		<gml:upperCorner>331485.650075 840557.498344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331485.650075 840557.498344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 053 929</ms:GML_ID>
        <ms:NAZWA>072 053 929</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072053929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332803.497356 841980.531604</gml:lowerCorner>
        		<gml:upperCorner>332803.497356 841980.531604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332803.497356 841980.531604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 055 875</ms:GML_ID>
        <ms:NAZWA>072 055 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072055875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334532.883000 843661.082000</gml:lowerCorner>
        		<gml:upperCorner>334532.883000 843661.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334532.883000 843661.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 058 294</ms:GML_ID>
        <ms:NAZWA>072 058 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072058294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335054.624000 844455.810000</gml:lowerCorner>
        		<gml:upperCorner>335054.624000 844455.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335054.624000 844455.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 059 260</ms:GML_ID>
        <ms:NAZWA>072 059 260</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072059260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335923.878000 845287.720000</gml:lowerCorner>
        		<gml:upperCorner>335923.878000 845287.720000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335923.878000 845287.720000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 060 453</ms:GML_ID>
        <ms:NAZWA>072 060 453</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072060453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337462.861892 845939.285161</gml:lowerCorner>
        		<gml:upperCorner>337462.861892 845939.285161</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337462.861892 845939.285161</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 062 122</ms:GML_ID>
        <ms:NAZWA>072 062 122</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072062122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337634.657000 846571.469000</gml:lowerCorner>
        		<gml:upperCorner>337634.657000 846571.469000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337634.657000 846571.469000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.931 000 528</ms:GML_ID>
        <ms:NAZWA>931 000 528</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>931000528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336878.493302 847263.249119</gml:lowerCorner>
        		<gml:upperCorner>336878.493302 847263.249119</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336878.493302 847263.249119</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.931 001 800</ms:GML_ID>
        <ms:NAZWA>931 001 800</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>931001800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326696.020762 813228.436258</gml:lowerCorner>
        		<gml:upperCorner>326696.020762 813228.436258</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326696.020762 813228.436258</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 024 327</ms:GML_ID>
        <ms:NAZWA>072 024 327</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072024327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327102.371065 813934.502598</gml:lowerCorner>
        		<gml:upperCorner>327102.371065 813934.502598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327102.371065 813934.502598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 025 141</ms:GML_ID>
        <ms:NAZWA>072 025 141</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072025141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327862.902113 815700.539628</gml:lowerCorner>
        		<gml:upperCorner>327862.902113 815700.539628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327862.902113 815700.539628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 027 149</ms:GML_ID>
        <ms:NAZWA>072 027 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072027149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327687.379520 817327.633222</gml:lowerCorner>
        		<gml:upperCorner>327687.379520 817327.633222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327687.379520 817327.633222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 028 782</ms:GML_ID>
        <ms:NAZWA>072 028 782</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072028782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327809.416024 818537.367155</gml:lowerCorner>
        		<gml:upperCorner>327809.416024 818537.367155</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327809.416024 818537.367155</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 030 018</ms:GML_ID>
        <ms:NAZWA>072 030 018</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072030018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328042.963000 819039.684000</gml:lowerCorner>
        		<gml:upperCorner>328042.963000 819039.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328042.963000 819039.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 030 573</ms:GML_ID>
        <ms:NAZWA>072 030 573</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072030573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328134.806000 819705.754000</gml:lowerCorner>
        		<gml:upperCorner>328134.806000 819705.754000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328134.806000 819705.754000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 031 250</ms:GML_ID>
        <ms:NAZWA>072 031 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072031250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328200.393000 820180.047000</gml:lowerCorner>
        		<gml:upperCorner>328200.393000 820180.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328200.393000 820180.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 031 728</ms:GML_ID>
        <ms:NAZWA>072 031 728</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072031728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328426.547000 821819.489000</gml:lowerCorner>
        		<gml:upperCorner>328426.547000 821819.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328426.547000 821819.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 033 382</ms:GML_ID>
        <ms:NAZWA>072 033 382</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072033382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328294.615193 824559.236857</gml:lowerCorner>
        		<gml:upperCorner>328294.615193 824559.236857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328294.615193 824559.236857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 036 208</ms:GML_ID>
        <ms:NAZWA>072 036 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072036208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327926.876000 825627.566000</gml:lowerCorner>
        		<gml:upperCorner>327926.876000 825627.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327926.876000 825627.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 037 337</ms:GML_ID>
        <ms:NAZWA>072 037 337</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072037337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327700.031000 826285.938000</gml:lowerCorner>
        		<gml:upperCorner>327700.031000 826285.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327700.031000 826285.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 038 032</ms:GML_ID>
        <ms:NAZWA>072 038 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072038032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327590.293000 827894.341000</gml:lowerCorner>
        		<gml:upperCorner>327590.293000 827894.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327590.293000 827894.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 039 658</ms:GML_ID>
        <ms:NAZWA>072 039 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072039658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326182.688000 792515.313000</gml:lowerCorner>
        		<gml:upperCorner>326182.688000 792515.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326182.688000 792515.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.083 002 170</ms:GML_ID>
        <ms:NAZWA>083 002 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>083002170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326679.502040 791502.856246</gml:lowerCorner>
        		<gml:upperCorner>326679.502040 791502.856246</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326679.502040 791502.856246</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 051 440</ms:GML_ID>
        <ms:NAZWA>069 051 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069051440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327807.888000 790701.367000</gml:lowerCorner>
        		<gml:upperCorner>327807.888000 790701.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327807.888000 790701.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 050 050</ms:GML_ID>
        <ms:NAZWA>069 050 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069050050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328502.196000 790154.541000</gml:lowerCorner>
        		<gml:upperCorner>328502.196000 790154.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328502.196000 790154.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 049 151</ms:GML_ID>
        <ms:NAZWA>069 049 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069049151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329450.327909 789684.484822</gml:lowerCorner>
        		<gml:upperCorner>329450.327909 789684.484822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329450.327909 789684.484822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 048 092</ms:GML_ID>
        <ms:NAZWA>069 048 092</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069048092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330393.426000 789083.559000</gml:lowerCorner>
        		<gml:upperCorner>330393.426000 789083.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330393.426000 789083.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 046 977</ms:GML_ID>
        <ms:NAZWA>069 046 977</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069046977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331565.316000 788541.747000</gml:lowerCorner>
        		<gml:upperCorner>331565.316000 788541.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331565.316000 788541.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 045 539</ms:GML_ID>
        <ms:NAZWA>069 045 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069045539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332409.058040 788649.289214</gml:lowerCorner>
        		<gml:upperCorner>332409.058040 788649.289214</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332409.058040 788649.289214</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 044 687</ms:GML_ID>
        <ms:NAZWA>069 044 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069044687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333245.613000 788519.819000</gml:lowerCorner>
        		<gml:upperCorner>333245.613000 788519.819000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333245.613000 788519.819000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 043 837</ms:GML_ID>
        <ms:NAZWA>069 043 837</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069043837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334013.117000 788481.651000</gml:lowerCorner>
        		<gml:upperCorner>334013.117000 788481.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334013.117000 788481.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 043 067</ms:GML_ID>
        <ms:NAZWA>069 043 067</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069043067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335278.160713 788801.727831</gml:lowerCorner>
        		<gml:upperCorner>335278.160713 788801.727831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335278.160713 788801.727831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 041 707</ms:GML_ID>
        <ms:NAZWA>069 041 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069041707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336113.614000 788871.388000</gml:lowerCorner>
        		<gml:upperCorner>336113.614000 788871.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336113.614000 788871.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 040 855</ms:GML_ID>
        <ms:NAZWA>069 040 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069040855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337869.391201 789565.430580</gml:lowerCorner>
        		<gml:upperCorner>337869.391201 789565.430580</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337869.391201 789565.430580</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 038 957</ms:GML_ID>
        <ms:NAZWA>069 038 957</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069038957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338887.571253 790115.494378</gml:lowerCorner>
        		<gml:upperCorner>338887.571253 790115.494378</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338887.571253 790115.494378</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 037 796</ms:GML_ID>
        <ms:NAZWA>069 037 796</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069037796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339854.116397 790054.710522</gml:lowerCorner>
        		<gml:upperCorner>339854.116397 790054.710522</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339854.116397 790054.710522</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 036 804</ms:GML_ID>
        <ms:NAZWA>069 036 804</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069036804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340823.211619 790114.171615</gml:lowerCorner>
        		<gml:upperCorner>340823.211619 790114.171615</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340823.211619 790114.171615</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 035 763</ms:GML_ID>
        <ms:NAZWA>069 035 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069035763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341593.529000 790795.713000</gml:lowerCorner>
        		<gml:upperCorner>341593.529000 790795.713000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341593.529000 790795.713000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 034 618</ms:GML_ID>
        <ms:NAZWA>069 034 618</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069034618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342328.274000 790598.693000</gml:lowerCorner>
        		<gml:upperCorner>342328.274000 790598.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342328.274000 790598.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 033 850</ms:GML_ID>
        <ms:NAZWA>069 033 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069033850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343431.182000 790965.115000</gml:lowerCorner>
        		<gml:upperCorner>343431.182000 790965.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343431.182000 790965.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 032 005</ms:GML_ID>
        <ms:NAZWA>069 032 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069032005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343566.292000 791316.112000</gml:lowerCorner>
        		<gml:upperCorner>343566.292000 791316.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343566.292000 791316.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 031 532</ms:GML_ID>
        <ms:NAZWA>069 031 532</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069031532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344254.838776 792157.098544</gml:lowerCorner>
        		<gml:upperCorner>344254.838776 792157.098544</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344254.838776 792157.098544</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 030 462</ms:GML_ID>
        <ms:NAZWA>069 030 462</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069030462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344540.281000 792109.396000</gml:lowerCorner>
        		<gml:upperCorner>344540.281000 792109.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344540.281000 792109.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 030 161</ms:GML_ID>
        <ms:NAZWA>069 030 161</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069030161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344747.440000 791942.591000</gml:lowerCorner>
        		<gml:upperCorner>344747.440000 791942.591000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344747.440000 791942.591000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 029 895</ms:GML_ID>
        <ms:NAZWA>069 029 895</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069029895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346379.748000 791931.266000</gml:lowerCorner>
        		<gml:upperCorner>346379.748000 791931.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346379.748000 791931.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 028 147</ms:GML_ID>
        <ms:NAZWA>069 028 147</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069028147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347132.178000 792223.970000</gml:lowerCorner>
        		<gml:upperCorner>347132.178000 792223.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347132.178000 792223.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 027 292</ms:GML_ID>
        <ms:NAZWA>069 027 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069027292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348334.579000 793843.097000</gml:lowerCorner>
        		<gml:upperCorner>348334.579000 793843.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348334.579000 793843.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 025 222</ms:GML_ID>
        <ms:NAZWA>069 025 222</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069025222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351149.869395 793939.648873</gml:lowerCorner>
        		<gml:upperCorner>351149.869395 793939.648873</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351149.869395 793939.648873</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 022 109</ms:GML_ID>
        <ms:NAZWA>069 022 109</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069022109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351511.992000 793922.181000</gml:lowerCorner>
        		<gml:upperCorner>351511.992000 793922.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351511.992000 793922.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 021 743</ms:GML_ID>
        <ms:NAZWA>069 021 743</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069021743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353012.942000 793601.392000</gml:lowerCorner>
        		<gml:upperCorner>353012.942000 793601.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353012.942000 793601.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 020 170</ms:GML_ID>
        <ms:NAZWA>069 020 170</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069020170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353983.047210 793606.158134</gml:lowerCorner>
        		<gml:upperCorner>353983.047210 793606.158134</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353983.047210 793606.158134</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 019 189</ms:GML_ID>
        <ms:NAZWA>069 019 189</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069019189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347766.041000 659948.815000</gml:lowerCorner>
        		<gml:upperCorner>347766.041000 659948.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347766.041000 659948.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 180 761</ms:GML_ID>
        <ms:NAZWA>025 180 761</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025180761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347181.311970 660925.745843</gml:lowerCorner>
        		<gml:upperCorner>347181.311970 660925.745843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347181.311970 660925.745843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 181 944</ms:GML_ID>
        <ms:NAZWA>025 181 944</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025181944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345718.915000 662452.033000</gml:lowerCorner>
        		<gml:upperCorner>345718.915000 662452.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345718.915000 662452.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 184 033</ms:GML_ID>
        <ms:NAZWA>025 184 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025184033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344197.177000 665408.255000</gml:lowerCorner>
        		<gml:upperCorner>344197.177000 665408.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344197.177000 665408.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 187 403</ms:GML_ID>
        <ms:NAZWA>025 187 403</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025187403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343868.253000 666104.900000</gml:lowerCorner>
        		<gml:upperCorner>343868.253000 666104.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343868.253000 666104.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 188 175</ms:GML_ID>
        <ms:NAZWA>025 188 175</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025188175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342678.306378 668528.283526</gml:lowerCorner>
        		<gml:upperCorner>342678.306378 668528.283526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342678.306378 668528.283526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 190 869</ms:GML_ID>
        <ms:NAZWA>025 190 869</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025190869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342121.810317 669586.647628</gml:lowerCorner>
        		<gml:upperCorner>342121.810317 669586.647628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342121.810317 669586.647628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 192 074</ms:GML_ID>
        <ms:NAZWA>025 192 074</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025192074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341222.746772 671335.677861</gml:lowerCorner>
        		<gml:upperCorner>341222.746772 671335.677861</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341222.746772 671335.677861</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 194 046</ms:GML_ID>
        <ms:NAZWA>025 194 046</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025194046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340972.382684 671832.093062</gml:lowerCorner>
        		<gml:upperCorner>340972.382684 671832.093062</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340972.382684 671832.093062</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 194 605</ms:GML_ID>
        <ms:NAZWA>025 194 605</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025194605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340070.865106 673832.143063</gml:lowerCorner>
        		<gml:upperCorner>340070.865106 673832.143063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340070.865106 673832.143063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 196 835</ms:GML_ID>
        <ms:NAZWA>025 196 835</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025196835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339502.273276 675159.633957</gml:lowerCorner>
        		<gml:upperCorner>339502.273276 675159.633957</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339502.273276 675159.633957</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 198 280</ms:GML_ID>
        <ms:NAZWA>025 198 280</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025198280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339054.371149 676915.784648</gml:lowerCorner>
        		<gml:upperCorner>339054.371149 676915.784648</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339054.371149 676915.784648</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 200 147</ms:GML_ID>
        <ms:NAZWA>025 200 147</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025200147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338823.593545 677411.449853</gml:lowerCorner>
        		<gml:upperCorner>338823.593545 677411.449853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338823.593545 677411.449853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 200 706</ms:GML_ID>
        <ms:NAZWA>025 200 706</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025200706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338629.326205 678281.916230</gml:lowerCorner>
        		<gml:upperCorner>338629.326205 678281.916230</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338629.326205 678281.916230</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 201 595</ms:GML_ID>
        <ms:NAZWA>025 201 595</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025201595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338566.392774 678656.949038</gml:lowerCorner>
        		<gml:upperCorner>338566.392774 678656.949038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338566.392774 678656.949038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 201 978</ms:GML_ID>
        <ms:NAZWA>025 201 978</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025201978</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338008.273000 679928.276000</gml:lowerCorner>
        		<gml:upperCorner>338008.273000 679928.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338008.273000 679928.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 203 387</ms:GML_ID>
        <ms:NAZWA>025 203 387</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025203387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337565.901225 680857.273635</gml:lowerCorner>
        		<gml:upperCorner>337565.901225 680857.273635</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337565.901225 680857.273635</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 204 425</ms:GML_ID>
        <ms:NAZWA>025 204 425</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025204425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337486.218911 681219.965610</gml:lowerCorner>
        		<gml:upperCorner>337486.218911 681219.965610</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337486.218911 681219.965610</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 204 802</ms:GML_ID>
        <ms:NAZWA>025 204 802</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025204802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336416.953956 683194.941688</gml:lowerCorner>
        		<gml:upperCorner>336416.953956 683194.941688</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336416.953956 683194.941688</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 207 074</ms:GML_ID>
        <ms:NAZWA>025 207 074</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025207074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335475.650235 684481.345317</gml:lowerCorner>
        		<gml:upperCorner>335475.650235 684481.345317</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335475.650235 684481.345317</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 208 684</ms:GML_ID>
        <ms:NAZWA>025 208 684</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025208684</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334461.205000 685379.498000</gml:lowerCorner>
        		<gml:upperCorner>334461.205000 685379.498000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334461.205000 685379.498000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 210 037</ms:GML_ID>
        <ms:NAZWA>025 210 037</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025210037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333919.543000 685858.696000</gml:lowerCorner>
        		<gml:upperCorner>333919.543000 685858.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333919.543000 685858.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 210 759</ms:GML_ID>
        <ms:NAZWA>025 210 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025210759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333009.365000 686434.906000</gml:lowerCorner>
        		<gml:upperCorner>333009.365000 686434.906000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333009.365000 686434.906000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 211 846</ms:GML_ID>
        <ms:NAZWA>025 211 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025211846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330770.215000 687437.909000</gml:lowerCorner>
        		<gml:upperCorner>330770.215000 687437.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330770.215000 687437.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 214 373</ms:GML_ID>
        <ms:NAZWA>025 214 373</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025214373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330017.548999 688078.553574</gml:lowerCorner>
        		<gml:upperCorner>330017.548999 688078.553574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330017.548999 688078.553574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 215 360</ms:GML_ID>
        <ms:NAZWA>025 215 360</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025215360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329867.643000 688299.576000</gml:lowerCorner>
        		<gml:upperCorner>329867.643000 688299.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329867.643000 688299.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 215 632</ms:GML_ID>
        <ms:NAZWA>025 215 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025215632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329102.124012 689992.332114</gml:lowerCorner>
        		<gml:upperCorner>329102.124012 689992.332114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329102.124012 689992.332114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 217 512</ms:GML_ID>
        <ms:NAZWA>025 217 512</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025217512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328185.320000 691012.559000</gml:lowerCorner>
        		<gml:upperCorner>328185.320000 691012.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328185.320000 691012.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 218 880</ms:GML_ID>
        <ms:NAZWA>025 218 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025218880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326899.567000 692270.629000</gml:lowerCorner>
        		<gml:upperCorner>326899.567000 692270.629000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326899.567000 692270.629000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 220 683</ms:GML_ID>
        <ms:NAZWA>025 220 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025220683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326295.406140 692883.725151</gml:lowerCorner>
        		<gml:upperCorner>326295.406140 692883.725151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326295.406140 692883.725151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 221 545</ms:GML_ID>
        <ms:NAZWA>025 221 545</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025221545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325167.832264 694505.505591</gml:lowerCorner>
        		<gml:upperCorner>325167.832264 694505.505591</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325167.832264 694505.505591</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 223 534</ms:GML_ID>
        <ms:NAZWA>025 223 534</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025223534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325096.192892 718353.105362</gml:lowerCorner>
        		<gml:upperCorner>325096.192892 718353.105362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325096.192892 718353.105362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 081 641</ms:GML_ID>
        <ms:NAZWA>068 081 641</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068081641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325683.149836 717881.495729</gml:lowerCorner>
        		<gml:upperCorner>325683.149836 717881.495729</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325683.149836 717881.495729</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 080 877</ms:GML_ID>
        <ms:NAZWA>068 080 877</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068080877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326601.700000 718118.583000</gml:lowerCorner>
        		<gml:upperCorner>326601.700000 718118.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326601.700000 718118.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 079 880</ms:GML_ID>
        <ms:NAZWA>068 079 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068079880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327863.505811 721362.215135</gml:lowerCorner>
        		<gml:upperCorner>327863.505811 721362.215135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327863.505811 721362.215135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 076 318</ms:GML_ID>
        <ms:NAZWA>068 076 318</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068076318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330362.093201 722837.041132</gml:lowerCorner>
        		<gml:upperCorner>330362.093201 722837.041132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330362.093201 722837.041132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 072 390</ms:GML_ID>
        <ms:NAZWA>068 072 390</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068072390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331540.809255 723419.495924</gml:lowerCorner>
        		<gml:upperCorner>331540.809255 723419.495924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331540.809255 723419.495924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 071 050</ms:GML_ID>
        <ms:NAZWA>068 071 050</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068071050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333806.312000 724398.046000</gml:lowerCorner>
        		<gml:upperCorner>333806.312000 724398.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333806.312000 724398.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 068 507</ms:GML_ID>
        <ms:NAZWA>068 068 507</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068068507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334571.382000 732800.381000</gml:lowerCorner>
        		<gml:upperCorner>334571.382000 732800.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334571.382000 732800.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 058 435</ms:GML_ID>
        <ms:NAZWA>068 058 435</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068058435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334839.878646 725437.272579</gml:lowerCorner>
        		<gml:upperCorner>334839.878646 725437.272579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334839.878646 725437.272579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 067 040</ms:GML_ID>
        <ms:NAZWA>068 067 040</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068067040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335563.812000 730019.705000</gml:lowerCorner>
        		<gml:upperCorner>335563.812000 730019.705000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335563.812000 730019.705000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 061 458</ms:GML_ID>
        <ms:NAZWA>068 061 458</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068061458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335978.013756 726476.323753</gml:lowerCorner>
        		<gml:upperCorner>335978.013756 726476.323753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335978.013756 726476.323753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 065 459</ms:GML_ID>
        <ms:NAZWA>068 065 459</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068065459</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336328.492631 734084.431590</gml:lowerCorner>
        		<gml:upperCorner>336328.492631 734084.431590</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336328.492631 734084.431590</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 056 195</ms:GML_ID>
        <ms:NAZWA>068 056 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068056195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336574.516302 727650.209722</gml:lowerCorner>
        		<gml:upperCorner>336574.516302 727650.209722</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336574.516302 727650.209722</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 064 084</ms:GML_ID>
        <ms:NAZWA>068 064 084</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068064084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337743.432000 734686.304000</gml:lowerCorner>
        		<gml:upperCorner>337743.432000 734686.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337743.432000 734686.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 054 655</ms:GML_ID>
        <ms:NAZWA>068 054 655</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068054655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339865.791844 734668.263153</gml:lowerCorner>
        		<gml:upperCorner>339865.791844 734668.263153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339865.791844 734668.263153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 052 345</ms:GML_ID>
        <ms:NAZWA>068 052 345</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068052345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341705.520000 734349.236000</gml:lowerCorner>
        		<gml:upperCorner>341705.520000 734349.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341705.520000 734349.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 050 122</ms:GML_ID>
        <ms:NAZWA>068 050 122</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068050122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342826.995000 734260.042000</gml:lowerCorner>
        		<gml:upperCorner>342826.995000 734260.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342826.995000 734260.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 048 873</ms:GML_ID>
        <ms:NAZWA>068 048 873</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068048873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345816.673663 730036.976646</gml:lowerCorner>
        		<gml:upperCorner>345816.673663 730036.976646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345816.673663 730036.976646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 043 420</ms:GML_ID>
        <ms:NAZWA>068 043 420</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068043420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348819.999000 732175.583000</gml:lowerCorner>
        		<gml:upperCorner>348819.999000 732175.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348819.999000 732175.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 039 284</ms:GML_ID>
        <ms:NAZWA>068 039 284</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068039284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349427.442000 732678.578000</gml:lowerCorner>
        		<gml:upperCorner>349427.442000 732678.578000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349427.442000 732678.578000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 038 495</ms:GML_ID>
        <ms:NAZWA>068 038 495</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068038495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351585.889000 733321.177000</gml:lowerCorner>
        		<gml:upperCorner>351585.889000 733321.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351585.889000 733321.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 036 209</ms:GML_ID>
        <ms:NAZWA>068 036 209</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068036209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354124.356000 733931.043000</gml:lowerCorner>
        		<gml:upperCorner>354124.356000 733931.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354124.356000 733931.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 033 375</ms:GML_ID>
        <ms:NAZWA>068 033 375</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068033375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355380.584630 734249.623633</gml:lowerCorner>
        		<gml:upperCorner>355380.584630 734249.623633</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355380.584630 734249.623633</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 032 078</ms:GML_ID>
        <ms:NAZWA>068 032 078</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068032078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356161.580000 734451.845000</gml:lowerCorner>
        		<gml:upperCorner>356161.580000 734451.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356161.580000 734451.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 031 271</ms:GML_ID>
        <ms:NAZWA>068 031 271</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068031271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356662.546783 734581.317343</gml:lowerCorner>
        		<gml:upperCorner>356662.546783 734581.317343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356662.546783 734581.317343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 030 754</ms:GML_ID>
        <ms:NAZWA>068 030 754</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068030754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359345.009726 735276.970103</gml:lowerCorner>
        		<gml:upperCorner>359345.009726 735276.970103</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359345.009726 735276.970103</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 027 984</ms:GML_ID>
        <ms:NAZWA>068 027 984</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068027984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360472.632853 735324.962718</gml:lowerCorner>
        		<gml:upperCorner>360472.632853 735324.962718</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360472.632853 735324.962718</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 026 855</ms:GML_ID>
        <ms:NAZWA>068 026 855</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068026855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361960.120292 735706.449715</gml:lowerCorner>
        		<gml:upperCorner>361960.120292 735706.449715</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361960.120292 735706.449715</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 025 294</ms:GML_ID>
        <ms:NAZWA>068 025 294</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068025294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362345.668064 735558.798833</gml:lowerCorner>
        		<gml:upperCorner>362345.668064 735558.798833</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362345.668064 735558.798833</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 024 871</ms:GML_ID>
        <ms:NAZWA>068 024 871</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068024871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362982.758087 735112.574415</gml:lowerCorner>
        		<gml:upperCorner>362982.758087 735112.574415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362982.758087 735112.574415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 024 091</ms:GML_ID>
        <ms:NAZWA>068 024 091</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068024091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363367.130000 735024.503000</gml:lowerCorner>
        		<gml:upperCorner>363367.130000 735024.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363367.130000 735024.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 023 695</ms:GML_ID>
        <ms:NAZWA>068 023 695</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068023695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363996.756454 734833.239680</gml:lowerCorner>
        		<gml:upperCorner>363996.756454 734833.239680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363996.756454 734833.239680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 023 030</ms:GML_ID>
        <ms:NAZWA>068 023 030</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068023030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365607.491793 735737.200352</gml:lowerCorner>
        		<gml:upperCorner>365607.491793 735737.200352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365607.491793 735737.200352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 021 055</ms:GML_ID>
        <ms:NAZWA>068 021 055</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068021055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365893.176936 736035.128799</gml:lowerCorner>
        		<gml:upperCorner>365893.176936 736035.128799</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365893.176936 736035.128799</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 020 644</ms:GML_ID>
        <ms:NAZWA>068 020 644</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068020644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323840.342214 789244.384510</gml:lowerCorner>
        		<gml:upperCorner>323840.342214 789244.384510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323840.342214 789244.384510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 055 919</ms:GML_ID>
        <ms:NAZWA>069 055 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069055919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324159.521000 790406.620000</gml:lowerCorner>
        		<gml:upperCorner>324159.521000 790406.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324159.521000 790406.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 054 729</ms:GML_ID>
        <ms:NAZWA>069 054 729</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069054729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325098.896000 791458.799000</gml:lowerCorner>
        		<gml:upperCorner>325098.896000 791458.799000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325098.896000 791458.799000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 053 295</ms:GML_ID>
        <ms:NAZWA>069 053 295</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069053295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324723.463691 793138.882664</gml:lowerCorner>
        		<gml:upperCorner>324723.463691 793138.882664</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324723.463691 793138.882664</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 002 377</ms:GML_ID>
        <ms:NAZWA>072 002 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072002377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324523.739000 793745.455000</gml:lowerCorner>
        		<gml:upperCorner>324523.739000 793745.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324523.739000 793745.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 003 014</ms:GML_ID>
        <ms:NAZWA>072 003 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072003014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324200.150252 794652.384702</gml:lowerCorner>
        		<gml:upperCorner>324200.150252 794652.384702</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324200.150252 794652.384702</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 003 980</ms:GML_ID>
        <ms:NAZWA>072 003 980</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072003980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323719.716801 795192.598052</gml:lowerCorner>
        		<gml:upperCorner>323719.716801 795192.598052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323719.716801 795192.598052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 004 798</ms:GML_ID>
        <ms:NAZWA>072 004 798</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072004798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323799.630000 795495.594000</gml:lowerCorner>
        		<gml:upperCorner>323799.630000 795495.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323799.630000 795495.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 005 112</ms:GML_ID>
        <ms:NAZWA>072 005 112</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072005112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324087.975000 796739.848000</gml:lowerCorner>
        		<gml:upperCorner>324087.975000 796739.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324087.975000 796739.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 006 401</ms:GML_ID>
        <ms:NAZWA>072 006 401</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072006401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324631.487000 798275.525000</gml:lowerCorner>
        		<gml:upperCorner>324631.487000 798275.525000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324631.487000 798275.525000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 008 029</ms:GML_ID>
        <ms:NAZWA>072 008 029</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072008029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324949.599104 799858.669933</gml:lowerCorner>
        		<gml:upperCorner>324949.599104 799858.669933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324949.599104 799858.669933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 009 652</ms:GML_ID>
        <ms:NAZWA>072 009 652</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072009652</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325036.380051 800288.564549</gml:lowerCorner>
        		<gml:upperCorner>325036.380051 800288.564549</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325036.380051 800288.564549</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 010 096</ms:GML_ID>
        <ms:NAZWA>072 010 096</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072010096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325070.104000 800675.659000</gml:lowerCorner>
        		<gml:upperCorner>325070.104000 800675.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325070.104000 800675.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 010 506</ms:GML_ID>
        <ms:NAZWA>072 010 506</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072010506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325996.885599 800954.067160</gml:lowerCorner>
        		<gml:upperCorner>325996.885599 800954.067160</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325996.885599 800954.067160</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 011 500</ms:GML_ID>
        <ms:NAZWA>072 011 500</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072011500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326043.974374 802150.129239</gml:lowerCorner>
        		<gml:upperCorner>326043.974374 802150.129239</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326043.974374 802150.129239</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 012 800</ms:GML_ID>
        <ms:NAZWA>072 012 800</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072012800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325852.799601 803606.389285</gml:lowerCorner>
        		<gml:upperCorner>325852.799601 803606.389285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325852.799601 803606.389285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 014 328</ms:GML_ID>
        <ms:NAZWA>072 014 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072014328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325659.113000 804402.736000</gml:lowerCorner>
        		<gml:upperCorner>325659.113000 804402.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325659.113000 804402.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 015 150</ms:GML_ID>
        <ms:NAZWA>072 015 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072015150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325688.082000 805056.235000</gml:lowerCorner>
        		<gml:upperCorner>325688.082000 805056.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325688.082000 805056.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 015 810</ms:GML_ID>
        <ms:NAZWA>072 015 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072015810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325634.135452 806152.984944</gml:lowerCorner>
        		<gml:upperCorner>325634.135452 806152.984944</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325634.135452 806152.984944</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 016 914</ms:GML_ID>
        <ms:NAZWA>072 016 914</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072016914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325560.177587 806753.081362</gml:lowerCorner>
        		<gml:upperCorner>325560.177587 806753.081362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325560.177587 806753.081362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 017 518</ms:GML_ID>
        <ms:NAZWA>072 017 518</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072017518</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325441.975000 807717.136000</gml:lowerCorner>
        		<gml:upperCorner>325441.975000 807717.136000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325441.975000 807717.136000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 018 475</ms:GML_ID>
        <ms:NAZWA>072 018 475</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072018475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325332.953393 808597.061998</gml:lowerCorner>
        		<gml:upperCorner>325332.953393 808597.061998</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325332.953393 808597.061998</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 019 380</ms:GML_ID>
        <ms:NAZWA>072 019 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072019380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325720.562409 811294.735906</gml:lowerCorner>
        		<gml:upperCorner>325720.562409 811294.735906</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325720.562409 811294.735906</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 022 165</ms:GML_ID>
        <ms:NAZWA>072 022 165</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072022165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326013.044000 811873.511000</gml:lowerCorner>
        		<gml:upperCorner>326013.044000 811873.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326013.044000 811873.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.072 022 810</ms:GML_ID>
        <ms:NAZWA>072 022 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>072022810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316528.840693 698687.399077</gml:lowerCorner>
        		<gml:upperCorner>316528.840693 698687.399077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316528.840693 698687.399077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 236 157</ms:GML_ID>
        <ms:NAZWA>025 236 157</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025236157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307318.287248 699931.757421</gml:lowerCorner>
        		<gml:upperCorner>307318.287248 699931.757421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307318.287248 699931.757421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 006 425</ms:GML_ID>
        <ms:NAZWA>074 006 425</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074006425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307967.217090 700719.632592</gml:lowerCorner>
        		<gml:upperCorner>307967.217090 700719.632592</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307967.217090 700719.632592</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 007 448</ms:GML_ID>
        <ms:NAZWA>074 007 448</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074007448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309388.372038 702397.575185</gml:lowerCorner>
        		<gml:upperCorner>309388.372038 702397.575185</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309388.372038 702397.575185</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 009 646</ms:GML_ID>
        <ms:NAZWA>074 009 646</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074009646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311344.223486 705173.300660</gml:lowerCorner>
        		<gml:upperCorner>311344.223486 705173.300660</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311344.223486 705173.300660</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 013 053</ms:GML_ID>
        <ms:NAZWA>074 013 053</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074013053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311480.422823 705400.695558</gml:lowerCorner>
        		<gml:upperCorner>311480.422823 705400.695558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311480.422823 705400.695558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 013 318</ms:GML_ID>
        <ms:NAZWA>074 013 318</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074013318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311502.002946 706663.761106</gml:lowerCorner>
        		<gml:upperCorner>311502.002946 706663.761106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311502.002946 706663.761106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 014 700</ms:GML_ID>
        <ms:NAZWA>074 014 700</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074014700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311145.913982 707434.061241</gml:lowerCorner>
        		<gml:upperCorner>311145.913982 707434.061241</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311145.913982 707434.061241</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 015 551</ms:GML_ID>
        <ms:NAZWA>074 015 551</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074015551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309814.067000 710304.800000</gml:lowerCorner>
        		<gml:upperCorner>309814.067000 710304.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309814.067000 710304.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 018 714</ms:GML_ID>
        <ms:NAZWA>074 018 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074018714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309643.731158 710674.750847</gml:lowerCorner>
        		<gml:upperCorner>309643.731158 710674.750847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309643.731158 710674.750847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 019 110</ms:GML_ID>
        <ms:NAZWA>074 019 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074019110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309338.088877 711334.934780</gml:lowerCorner>
        		<gml:upperCorner>309338.088877 711334.934780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309338.088877 711334.934780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 019 848</ms:GML_ID>
        <ms:NAZWA>074 019 848</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074019848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308859.633218 712376.646116</gml:lowerCorner>
        		<gml:upperCorner>308859.633218 712376.646116</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308859.633218 712376.646116</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 020 994</ms:GML_ID>
        <ms:NAZWA>074 020 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074020994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308482.216767 713082.980296</gml:lowerCorner>
        		<gml:upperCorner>308482.216767 713082.980296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308482.216767 713082.980296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 022 224</ms:GML_ID>
        <ms:NAZWA>074 022 224</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074022224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308297.925000 713907.205000</gml:lowerCorner>
        		<gml:upperCorner>308297.925000 713907.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308297.925000 713907.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.565 000 714</ms:GML_ID>
        <ms:NAZWA>565 000 714</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>565000714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308117.364621 713966.606071</gml:lowerCorner>
        		<gml:upperCorner>308117.364621 713966.606071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308117.364621 713966.606071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 022 754</ms:GML_ID>
        <ms:NAZWA>074 022 754</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074022754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309815.952203 714059.801674</gml:lowerCorner>
        		<gml:upperCorner>309815.952203 714059.801674</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309815.952203 714059.801674</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 099 575</ms:GML_ID>
        <ms:NAZWA>068 099 575</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068099575</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310465.987000 714061.260000</gml:lowerCorner>
        		<gml:upperCorner>310465.987000 714061.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310465.987000 714061.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 098 924</ms:GML_ID>
        <ms:NAZWA>068 098 924</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068098924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312641.592000 714135.985000</gml:lowerCorner>
        		<gml:upperCorner>312641.592000 714135.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312641.592000 714135.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 096 746</ms:GML_ID>
        <ms:NAZWA>068 096 746</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068096746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308022.264265 714172.332993</gml:lowerCorner>
        		<gml:upperCorner>308022.264265 714172.332993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308022.264265 714172.332993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 022 979</ms:GML_ID>
        <ms:NAZWA>074 022 979</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074022979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308074.047000 714211.406000</gml:lowerCorner>
        		<gml:upperCorner>308074.047000 714211.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308074.047000 714211.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 101 361</ms:GML_ID>
        <ms:NAZWA>068 101 361</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068101361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313423.686000 714239.761000</gml:lowerCorner>
        		<gml:upperCorner>313423.686000 714239.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313423.686000 714239.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 095 956</ms:GML_ID>
        <ms:NAZWA>068 095 956</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068095956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314157.380000 714300.626000</gml:lowerCorner>
        		<gml:upperCorner>314157.380000 714300.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314157.380000 714300.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 095 216</ms:GML_ID>
        <ms:NAZWA>068 095 216</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068095216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306606.644826 715433.409857</gml:lowerCorner>
        		<gml:upperCorner>306606.644826 715433.409857</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306606.644826 715433.409857</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 103 320</ms:GML_ID>
        <ms:NAZWA>068 103 320</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068103320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315569.086449 715450.414485</gml:lowerCorner>
        		<gml:upperCorner>315569.086449 715450.414485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315569.086449 715450.414485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 093 279</ms:GML_ID>
        <ms:NAZWA>068 093 279</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068093279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300911.741000 787370.202000</gml:lowerCorner>
        		<gml:upperCorner>300911.741000 787370.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300911.741000 787370.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 088 000</ms:GML_ID>
        <ms:NAZWA>069 088 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069088000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301532.942000 786539.909000</gml:lowerCorner>
        		<gml:upperCorner>301532.942000 786539.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301532.942000 786539.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 086 929</ms:GML_ID>
        <ms:NAZWA>069 086 929</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069086929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302753.770711 786352.101379</gml:lowerCorner>
        		<gml:upperCorner>302753.770711 786352.101379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302753.770711 786352.101379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 085 604</ms:GML_ID>
        <ms:NAZWA>069 085 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069085604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303971.813000 785981.076000</gml:lowerCorner>
        		<gml:upperCorner>303971.813000 785981.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303971.813000 785981.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 084 325</ms:GML_ID>
        <ms:NAZWA>069 084 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069084325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306753.665000 783779.626000</gml:lowerCorner>
        		<gml:upperCorner>306753.665000 783779.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306753.665000 783779.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 080 387</ms:GML_ID>
        <ms:NAZWA>069 080 387</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069080387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308502.199632 780180.916897</gml:lowerCorner>
        		<gml:upperCorner>308502.199632 780180.916897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308502.199632 780180.916897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 003 540</ms:GML_ID>
        <ms:NAZWA>066 003 540</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066003540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308859.744226 781913.174883</gml:lowerCorner>
        		<gml:upperCorner>308859.744226 781913.174883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308859.744226 781913.174883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 001 662</ms:GML_ID>
        <ms:NAZWA>066 001 662</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066001662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309257.729000 782578.695000</gml:lowerCorner>
        		<gml:upperCorner>309257.729000 782578.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309257.729000 782578.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 077 532</ms:GML_ID>
        <ms:NAZWA>069 077 532</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069077532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310418.165338 782601.918819</gml:lowerCorner>
        		<gml:upperCorner>310418.165338 782601.918819</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310418.165338 782601.918819</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 076 313</ms:GML_ID>
        <ms:NAZWA>069 076 313</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069076313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311857.740271 782260.558294</gml:lowerCorner>
        		<gml:upperCorner>311857.740271 782260.558294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311857.740271 782260.558294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 074 722</ms:GML_ID>
        <ms:NAZWA>069 074 722</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069074722</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312262.878981 781787.927039</gml:lowerCorner>
        		<gml:upperCorner>312262.878981 781787.927039</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312262.878981 781787.927039</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 074 090</ms:GML_ID>
        <ms:NAZWA>069 074 090</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069074090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312750.107000 781472.155000</gml:lowerCorner>
        		<gml:upperCorner>312750.107000 781472.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312750.107000 781472.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 073 508</ms:GML_ID>
        <ms:NAZWA>069 073 508</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069073508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315771.193000 779904.337000</gml:lowerCorner>
        		<gml:upperCorner>315771.193000 779904.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315771.193000 779904.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 070 025</ms:GML_ID>
        <ms:NAZWA>069 070 025</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069070025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317682.265000 780253.570000</gml:lowerCorner>
        		<gml:upperCorner>317682.265000 780253.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317682.265000 780253.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 067 820</ms:GML_ID>
        <ms:NAZWA>069 067 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069067820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318729.491023 780528.319549</gml:lowerCorner>
        		<gml:upperCorner>318729.491023 780528.319549</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318729.491023 780528.319549</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 066 726</ms:GML_ID>
        <ms:NAZWA>069 066 726</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069066726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320273.138000 781669.492000</gml:lowerCorner>
        		<gml:upperCorner>320273.138000 781669.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320273.138000 781669.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 064 692</ms:GML_ID>
        <ms:NAZWA>069 064 692</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069064692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321015.921559 782361.537188</gml:lowerCorner>
        		<gml:upperCorner>321015.921559 782361.537188</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321015.921559 782361.537188</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 063 660</ms:GML_ID>
        <ms:NAZWA>069 063 660</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069063660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321974.735961 783201.840933</gml:lowerCorner>
        		<gml:upperCorner>321974.735961 783201.840933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321974.735961 783201.840933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 062 306</ms:GML_ID>
        <ms:NAZWA>069 062 306</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069062306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322111.226150 783867.620576</gml:lowerCorner>
        		<gml:upperCorner>322111.226150 783867.620576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322111.226150 783867.620576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 061 630</ms:GML_ID>
        <ms:NAZWA>069 061 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069061630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322373.069000 785403.333000</gml:lowerCorner>
        		<gml:upperCorner>322373.069000 785403.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322373.069000 785403.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 060 075</ms:GML_ID>
        <ms:NAZWA>069 060 075</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069060075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322604.679367 786222.763848</gml:lowerCorner>
        		<gml:upperCorner>322604.679367 786222.763848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322604.679367 786222.763848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 059 210</ms:GML_ID>
        <ms:NAZWA>069 059 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069059210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323284.768000 787520.435000</gml:lowerCorner>
        		<gml:upperCorner>323284.768000 787520.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323284.768000 787520.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 057 740</ms:GML_ID>
        <ms:NAZWA>069 057 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069057740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301567.897000 724924.077000</gml:lowerCorner>
        		<gml:upperCorner>301567.897000 724924.077000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301567.897000 724924.077000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 060 445</ms:GML_ID>
        <ms:NAZWA>066 060 445</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066060445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301211.131645 726137.921362</gml:lowerCorner>
        		<gml:upperCorner>301211.131645 726137.921362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301211.131645 726137.921362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 059 180</ms:GML_ID>
        <ms:NAZWA>066 059 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066059180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300993.243000 728504.458000</gml:lowerCorner>
        		<gml:upperCorner>300993.243000 728504.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300993.243000 728504.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 056 803</ms:GML_ID>
        <ms:NAZWA>066 056 803</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066056803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300971.957570 730485.061487</gml:lowerCorner>
        		<gml:upperCorner>300971.957570 730485.061487</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300971.957570 730485.061487</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 054 822</ms:GML_ID>
        <ms:NAZWA>066 054 822</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066054822</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301125.335641 731373.427421</gml:lowerCorner>
        		<gml:upperCorner>301125.335641 731373.427421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301125.335641 731373.427421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 053 919</ms:GML_ID>
        <ms:NAZWA>066 053 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066053919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301622.631000 735571.450000</gml:lowerCorner>
        		<gml:upperCorner>301622.631000 735571.450000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301622.631000 735571.450000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 049 664</ms:GML_ID>
        <ms:NAZWA>066 049 664</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066049664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301294.415000 738634.934000</gml:lowerCorner>
        		<gml:upperCorner>301294.415000 738634.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301294.415000 738634.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 046 583</ms:GML_ID>
        <ms:NAZWA>066 046 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066046583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301235.732000 739185.651000</gml:lowerCorner>
        		<gml:upperCorner>301235.732000 739185.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301235.732000 739185.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 046 029</ms:GML_ID>
        <ms:NAZWA>066 046 029</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066046029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301106.174000 740407.055000</gml:lowerCorner>
        		<gml:upperCorner>301106.174000 740407.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301106.174000 740407.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 044 801</ms:GML_ID>
        <ms:NAZWA>066 044 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066044801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301245.943000 742102.245000</gml:lowerCorner>
        		<gml:upperCorner>301245.943000 742102.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301245.943000 742102.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 043 095</ms:GML_ID>
        <ms:NAZWA>066 043 095</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066043095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301538.205000 744119.317000</gml:lowerCorner>
        		<gml:upperCorner>301538.205000 744119.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301538.205000 744119.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 041 057</ms:GML_ID>
        <ms:NAZWA>066 041 057</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066041057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301818.481000 746057.049000</gml:lowerCorner>
        		<gml:upperCorner>301818.481000 746057.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301818.481000 746057.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 039 100</ms:GML_ID>
        <ms:NAZWA>066 039 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066039100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302816.217353 751278.754939</gml:lowerCorner>
        		<gml:upperCorner>302816.217353 751278.754939</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302816.217353 751278.754939</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 033 755</ms:GML_ID>
        <ms:NAZWA>066 033 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066033755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303050.182000 754389.533000</gml:lowerCorner>
        		<gml:upperCorner>303050.182000 754389.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303050.182000 754389.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 030 611</ms:GML_ID>
        <ms:NAZWA>066 030 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066030611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303424.145000 758089.559000</gml:lowerCorner>
        		<gml:upperCorner>303424.145000 758089.559000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303424.145000 758089.559000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 026 852</ms:GML_ID>
        <ms:NAZWA>066 026 852</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066026852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304086.547000 760557.163000</gml:lowerCorner>
        		<gml:upperCorner>304086.547000 760557.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304086.547000 760557.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 024 297</ms:GML_ID>
        <ms:NAZWA>066 024 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066024297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304490.541000 762336.295000</gml:lowerCorner>
        		<gml:upperCorner>304490.541000 762336.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304490.541000 762336.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 022 472</ms:GML_ID>
        <ms:NAZWA>066 022 472</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066022472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304767.744000 763729.258000</gml:lowerCorner>
        		<gml:upperCorner>304767.744000 763729.258000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304767.744000 763729.258000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 021 045</ms:GML_ID>
        <ms:NAZWA>066 021 045</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066021045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305212.620000 765156.958000</gml:lowerCorner>
        		<gml:upperCorner>305212.620000 765156.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305212.620000 765156.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 019 545</ms:GML_ID>
        <ms:NAZWA>066 019 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066019545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306849.947181 767905.696370</gml:lowerCorner>
        		<gml:upperCorner>306849.947181 767905.696370</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306849.947181 767905.696370</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 016 333</ms:GML_ID>
        <ms:NAZWA>066 016 333</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066016333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307619.174051 771169.971701</gml:lowerCorner>
        		<gml:upperCorner>307619.174051 771169.971701</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307619.174051 771169.971701</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 012 956</ms:GML_ID>
        <ms:NAZWA>066 012 956</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066012956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308605.037147 778581.549044</gml:lowerCorner>
        		<gml:upperCorner>308605.037147 778581.549044</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308605.037147 778581.549044</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.066 005 177</ms:GML_ID>
        <ms:NAZWA>066 005 177</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>066005177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298012.818000 689149.842000</gml:lowerCorner>
        		<gml:upperCorner>298012.818000 689149.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298012.818000 689149.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.933 000 188</ms:GML_ID>
        <ms:NAZWA>933 000 188</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>933000188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298252.478829 689525.857375</gml:lowerCorner>
        		<gml:upperCorner>298252.478829 689525.857375</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298252.478829 689525.857375</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 258 816</ms:GML_ID>
        <ms:NAZWA>025 258 816</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025258816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298972.034985 690310.925452</gml:lowerCorner>
        		<gml:upperCorner>298972.034985 690310.925452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298972.034985 690310.925452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 257 733</ms:GML_ID>
        <ms:NAZWA>025 257 733</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025257733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298687.150000 690321.001000</gml:lowerCorner>
        		<gml:upperCorner>298687.150000 690321.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298687.150000 690321.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 000 491</ms:GML_ID>
        <ms:NAZWA>071 000 491</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071000491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304801.650000 691737.950000</gml:lowerCorner>
        		<gml:upperCorner>304801.650000 691737.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304801.650000 691737.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 251 372</ms:GML_ID>
        <ms:NAZWA>025 251 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025251372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325462.387000 693935.796000</gml:lowerCorner>
        		<gml:upperCorner>325462.387000 693935.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325462.387000 693935.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 222 890</ms:GML_ID>
        <ms:NAZWA>025 222 890</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025222890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308017.010948 694566.453418</gml:lowerCorner>
        		<gml:upperCorner>308017.010948 694566.453418</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308017.010948 694566.453418</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 247 031</ms:GML_ID>
        <ms:NAZWA>025 247 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025247031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307460.746000 694629.511000</gml:lowerCorner>
        		<gml:upperCorner>307460.746000 694629.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307460.746000 694629.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 001 100</ms:GML_ID>
        <ms:NAZWA>074 001 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074001100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308422.916000 694814.616000</gml:lowerCorner>
        		<gml:upperCorner>308422.916000 694814.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308422.916000 694814.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 246 556</ms:GML_ID>
        <ms:NAZWA>025 246 556</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025246556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314181.762839 694822.547167</gml:lowerCorner>
        		<gml:upperCorner>314181.762839 694822.547167</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314181.762839 694822.547167</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 240 585</ms:GML_ID>
        <ms:NAZWA>025 240 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025240585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309437.944000 694991.736000</gml:lowerCorner>
        		<gml:upperCorner>309437.944000 694991.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309437.944000 694991.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 245 517</ms:GML_ID>
        <ms:NAZWA>025 245 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025245517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310154.000000 695047.670000</gml:lowerCorner>
        		<gml:upperCorner>310154.000000 695047.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310154.000000 695047.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 244 798</ms:GML_ID>
        <ms:NAZWA>025 244 798</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025244798</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310773.814000 695095.804000</gml:lowerCorner>
        		<gml:upperCorner>310773.814000 695095.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310773.814000 695095.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 244 176</ms:GML_ID>
        <ms:NAZWA>025 244 176</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025244176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311179.922000 695127.652000</gml:lowerCorner>
        		<gml:upperCorner>311179.922000 695127.652000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311179.922000 695127.652000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 243 769</ms:GML_ID>
        <ms:NAZWA>025 243 769</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025243769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324503.854000 695168.531000</gml:lowerCorner>
        		<gml:upperCorner>324503.854000 695168.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324503.854000 695168.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 224 472</ms:GML_ID>
        <ms:NAZWA>025 224 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025224472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311838.367598 695179.473452</gml:lowerCorner>
        		<gml:upperCorner>311838.367598 695179.473452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311838.367598 695179.473452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 243 109</ms:GML_ID>
        <ms:NAZWA>025 243 109</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025243109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313720.742029 695341.391075</gml:lowerCorner>
        		<gml:upperCorner>313720.742029 695341.391075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313720.742029 695341.391075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 241 218</ms:GML_ID>
        <ms:NAZWA>025 241 218</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025241218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314168.539550 695347.738723</gml:lowerCorner>
        		<gml:upperCorner>314168.539550 695347.738723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314168.539550 695347.738723</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 240 750</ms:GML_ID>
        <ms:NAZWA>025 240 750</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025240750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309610.063103 695366.246099</gml:lowerCorner>
        		<gml:upperCorner>309610.063103 695366.246099</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309610.063103 695366.246099</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.078 004 474</ms:GML_ID>
        <ms:NAZWA>078 004 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>078004474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307445.167000 695406.198000</gml:lowerCorner>
        		<gml:upperCorner>307445.167000 695406.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307445.167000 695406.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 001 879</ms:GML_ID>
        <ms:NAZWA>074 001 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074001879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314419.133253 695429.687865</gml:lowerCorner>
        		<gml:upperCorner>314419.133253 695429.687865</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314419.133253 695429.687865</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 240 514</ms:GML_ID>
        <ms:NAZWA>025 240 514</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025240514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314770.860006 695617.573149</gml:lowerCorner>
        		<gml:upperCorner>314770.860006 695617.573149</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314770.860006 695617.573149</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 240 098</ms:GML_ID>
        <ms:NAZWA>025 240 098</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025240098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307425.334000 695800.091000</gml:lowerCorner>
        		<gml:upperCorner>307425.334000 695800.091000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307425.334000 695800.091000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 002 273</ms:GML_ID>
        <ms:NAZWA>074 002 273</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074002273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314843.805449 695803.645431</gml:lowerCorner>
        		<gml:upperCorner>314843.805449 695803.645431</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314843.805449 695803.645431</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 239 898</ms:GML_ID>
        <ms:NAZWA>025 239 898</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025239898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308352.512146 696544.461961</gml:lowerCorner>
        		<gml:upperCorner>308352.512146 696544.461961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308352.512146 696544.461961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.078 006 198</ms:GML_ID>
        <ms:NAZWA>078 006 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>078006198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305538.760845 715472.630063</gml:lowerCorner>
        		<gml:upperCorner>305538.760845 715472.630063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305538.760845 715472.630063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 104 456</ms:GML_ID>
        <ms:NAZWA>068 104 456</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068104456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305693.138965 715529.175506</gml:lowerCorner>
        		<gml:upperCorner>305693.138965 715529.175506</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305693.138965 715529.175506</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 104 292</ms:GML_ID>
        <ms:NAZWA>068 104 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068104292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305949.616334 715617.418330</gml:lowerCorner>
        		<gml:upperCorner>305949.616334 715617.418330</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305949.616334 715617.418330</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 104 035</ms:GML_ID>
        <ms:NAZWA>068 104 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068104035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305959.584837 715650.938428</gml:lowerCorner>
        		<gml:upperCorner>305959.584837 715650.938428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305959.584837 715650.938428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 103 997</ms:GML_ID>
        <ms:NAZWA>068 103 997</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068103997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304738.021101 716286.707579</gml:lowerCorner>
        		<gml:upperCorner>304738.021101 716286.707579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304738.021101 716286.707579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 105 382</ms:GML_ID>
        <ms:NAZWA>068 105 382</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068105382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316946.017794 716426.880569</gml:lowerCorner>
        		<gml:upperCorner>316946.017794 716426.880569</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316946.017794 716426.880569</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 091 531</ms:GML_ID>
        <ms:NAZWA>068 091 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068091531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304460.074607 716441.021667</gml:lowerCorner>
        		<gml:upperCorner>304460.074607 716441.021667</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304460.074607 716441.021667</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 105 693</ms:GML_ID>
        <ms:NAZWA>068 105 693</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068105693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318444.283071 716623.277459</gml:lowerCorner>
        		<gml:upperCorner>318444.283071 716623.277459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318444.283071 716623.277459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 090 001</ms:GML_ID>
        <ms:NAZWA>068 090 001</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068090001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303879.698000 716755.761000</gml:lowerCorner>
        		<gml:upperCorner>303879.698000 716755.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303879.698000 716755.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 106 362</ms:GML_ID>
        <ms:NAZWA>068 106 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068106362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319919.893974 717064.541335</gml:lowerCorner>
        		<gml:upperCorner>319919.893974 717064.541335</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319919.893974 717064.541335</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 088 373</ms:GML_ID>
        <ms:NAZWA>068 088 373</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068088373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302372.554134 717868.409648</gml:lowerCorner>
        		<gml:upperCorner>302372.554134 717868.409648</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302372.554134 717868.409648</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 108 238</ms:GML_ID>
        <ms:NAZWA>068 108 238</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068108238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325348.381644 718196.429697</gml:lowerCorner>
        		<gml:upperCorner>325348.381644 718196.429697</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325348.381644 718196.429697</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 081 344</ms:GML_ID>
        <ms:NAZWA>068 081 344</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068081344</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301393.378000 718668.206000</gml:lowerCorner>
        		<gml:upperCorner>301393.378000 718668.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301393.378000 718668.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 109 507</ms:GML_ID>
        <ms:NAZWA>068 109 507</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068109507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326943.142000 718737.115000</gml:lowerCorner>
        		<gml:upperCorner>326943.142000 718737.115000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326943.142000 718737.115000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 079 147</ms:GML_ID>
        <ms:NAZWA>068 079 147</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068079147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324039.419912 718948.701526</gml:lowerCorner>
        		<gml:upperCorner>324039.419912 718948.701526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324039.419912 718948.701526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 082 926</ms:GML_ID>
        <ms:NAZWA>068 082 926</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068082926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323310.300112 719545.183138</gml:lowerCorner>
        		<gml:upperCorner>323310.300112 719545.183138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323310.300112 719545.183138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 083 902</ms:GML_ID>
        <ms:NAZWA>068 083 902</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068083902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299891.886474 720238.926632</gml:lowerCorner>
        		<gml:upperCorner>299891.886474 720238.926632</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299891.886474 720238.926632</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 111 687</ms:GML_ID>
        <ms:NAZWA>068 111 687</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068111687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299678.292707 720841.763087</gml:lowerCorner>
        		<gml:upperCorner>299678.292707 720841.763087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299678.292707 720841.763087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 112 326</ms:GML_ID>
        <ms:NAZWA>068 112 326</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068112326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299159.101430 722092.837252</gml:lowerCorner>
        		<gml:upperCorner>299159.101430 722092.837252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299159.101430 722092.837252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 113 688</ms:GML_ID>
        <ms:NAZWA>068 113 688</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068113688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327949.726000 722142.955000</gml:lowerCorner>
        		<gml:upperCorner>327949.726000 722142.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327949.726000 722142.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 075 529</ms:GML_ID>
        <ms:NAZWA>068 075 529</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068075529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298604.081000 722914.530000</gml:lowerCorner>
        		<gml:upperCorner>298604.081000 722914.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298604.081000 722914.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 114 680</ms:GML_ID>
        <ms:NAZWA>068 114 680</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068114680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297610.867000 724103.040000</gml:lowerCorner>
        		<gml:upperCorner>297610.867000 724103.040000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297610.867000 724103.040000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.068 116 228</ms:GML_ID>
        <ms:NAZWA>068 116 228</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>068116228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297580.448687 684790.341221</gml:lowerCorner>
        		<gml:upperCorner>297580.448687 684790.341221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297580.448687 684790.341221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.070 083 260</ms:GML_ID>
        <ms:NAZWA>070 083 260</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>070083260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294305.105755 685966.961538</gml:lowerCorner>
        		<gml:upperCorner>294305.105755 685966.961538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294305.105755 685966.961538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 264 213</ms:GML_ID>
        <ms:NAZWA>025 264 213</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025264213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294673.696000 686250.878000</gml:lowerCorner>
        		<gml:upperCorner>294673.696000 686250.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294673.696000 686250.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 263 748</ms:GML_ID>
        <ms:NAZWA>025 263 748</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025263748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295358.659289 686709.071115</gml:lowerCorner>
        		<gml:upperCorner>295358.659289 686709.071115</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295358.659289 686709.071115</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 262 920</ms:GML_ID>
        <ms:NAZWA>025 262 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025262920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296135.263000 687229.579000</gml:lowerCorner>
        		<gml:upperCorner>296135.263000 687229.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296135.263000 687229.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 261 987</ms:GML_ID>
        <ms:NAZWA>025 261 987</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025261987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296639.724000 687568.151000</gml:lowerCorner>
        		<gml:upperCorner>296639.724000 687568.151000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296639.724000 687568.151000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 261 379</ms:GML_ID>
        <ms:NAZWA>025 261 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025261379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297391.374265 688286.128192</gml:lowerCorner>
        		<gml:upperCorner>297391.374265 688286.128192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297391.374265 688286.128192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 260 328</ms:GML_ID>
        <ms:NAZWA>025 260 328</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025260328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300835.595403 690394.132037</gml:lowerCorner>
        		<gml:upperCorner>300835.595403 690394.132037</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300835.595403 690394.132037</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 255 860</ms:GML_ID>
        <ms:NAZWA>025 255 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025255860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295593.320000 690989.094000</gml:lowerCorner>
        		<gml:upperCorner>295593.320000 690989.094000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295593.320000 690989.094000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 003 953</ms:GML_ID>
        <ms:NAZWA>071 003 953</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071003953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296552.878342 691029.917529</gml:lowerCorner>
        		<gml:upperCorner>296552.878342 691029.917529</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296552.878342 691029.917529</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 002 988</ms:GML_ID>
        <ms:NAZWA>071 002 988</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071002988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294333.854000 691072.737000</gml:lowerCorner>
        		<gml:upperCorner>294333.854000 691072.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294333.854000 691072.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 005 218</ms:GML_ID>
        <ms:NAZWA>071 005 218</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071005218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297509.794021 691137.888927</gml:lowerCorner>
        		<gml:upperCorner>297509.794021 691137.888927</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297509.794021 691137.888927</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.071 002 018</ms:GML_ID>
        <ms:NAZWA>071 002 018</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>071002018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307383.671364 694178.125803</gml:lowerCorner>
        		<gml:upperCorner>307383.671364 694178.125803</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307383.671364 694178.125803</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 247 774</ms:GML_ID>
        <ms:NAZWA>025 247 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025247774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321775.766779 696868.984761</gml:lowerCorner>
        		<gml:upperCorner>321775.766779 696868.984761</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321775.766779 696868.984761</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 230 462</ms:GML_ID>
        <ms:NAZWA>025 230 462</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025230462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322817.389970 696993.137711</gml:lowerCorner>
        		<gml:upperCorner>322817.389970 696993.137711</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322817.389970 696993.137711</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 229 409</ms:GML_ID>
        <ms:NAZWA>025 229 409</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025229409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307365.216093 697004.949801</gml:lowerCorner>
        		<gml:upperCorner>307365.216093 697004.949801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307365.216093 697004.949801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 003 480</ms:GML_ID>
        <ms:NAZWA>074 003 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074003480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320512.327352 697008.403094</gml:lowerCorner>
        		<gml:upperCorner>320512.327352 697008.403094</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320512.327352 697008.403094</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 231 742</ms:GML_ID>
        <ms:NAZWA>025 231 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025231742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307715.532000 697141.180000</gml:lowerCorner>
        		<gml:upperCorner>307715.532000 697141.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307715.532000 697141.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.078 007 071</ms:GML_ID>
        <ms:NAZWA>078 007 071</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>078007071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319445.447990 697245.890558</gml:lowerCorner>
        		<gml:upperCorner>319445.447990 697245.890558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319445.447990 697245.890558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 232 836</ms:GML_ID>
        <ms:NAZWA>025 232 836</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025232836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318846.601273 697475.369574</gml:lowerCorner>
        		<gml:upperCorner>318846.601273 697475.369574</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318846.601273 697475.369574</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 233 476</ms:GML_ID>
        <ms:NAZWA>025 233 476</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025233476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315057.408932 697491.069644</gml:lowerCorner>
        		<gml:upperCorner>315057.408932 697491.069644</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315057.408932 697491.069644</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 238 122</ms:GML_ID>
        <ms:NAZWA>025 238 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025238122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307313.337000 698044.112000</gml:lowerCorner>
        		<gml:upperCorner>307313.337000 698044.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307313.337000 698044.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.074 004 522</ms:GML_ID>
        <ms:NAZWA>074 004 522</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>074004522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315558.263404 698060.724686</gml:lowerCorner>
        		<gml:upperCorner>315558.263404 698060.724686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315558.263404 698060.724686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 237 359</ms:GML_ID>
        <ms:NAZWA>025 237 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025237359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317586.102315 698144.563186</gml:lowerCorner>
        		<gml:upperCorner>317586.102315 698144.563186</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317586.102315 698144.563186</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.025 234 963</ms:GML_ID>
        <ms:NAZWA>025 234 963</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>025234963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323687.382000 788327.841000</gml:lowerCorner>
        		<gml:upperCorner>323687.382000 788327.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323687.382000 788327.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 056 846</ms:GML_ID>
        <ms:NAZWA>069 056 846</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069056846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300332.587000 788409.358000</gml:lowerCorner>
        		<gml:upperCorner>300332.587000 788409.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300332.587000 788409.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 089 225</ms:GML_ID>
        <ms:NAZWA>069 089 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069089225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299712.637000 788986.724000</gml:lowerCorner>
        		<gml:upperCorner>299712.637000 788986.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299712.637000 788986.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 090 097</ms:GML_ID>
        <ms:NAZWA>069 090 097</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069090097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299517.620735 789278.034430</gml:lowerCorner>
        		<gml:upperCorner>299517.620735 789278.034430</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299517.620735 789278.034430</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 090 453</ms:GML_ID>
        <ms:NAZWA>069 090 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069090453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299061.506359 789705.124170</gml:lowerCorner>
        		<gml:upperCorner>299061.506359 789705.124170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299061.506359 789705.124170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 091 082</ms:GML_ID>
        <ms:NAZWA>069 091 082</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069091082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298775.149811 790372.096783</gml:lowerCorner>
        		<gml:upperCorner>298775.149811 790372.096783</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298775.149811 790372.096783</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 091 816</ms:GML_ID>
        <ms:NAZWA>069 091 816</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069091816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298632.073163 790887.792978</gml:lowerCorner>
        		<gml:upperCorner>298632.073163 790887.792978</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298632.073163 790887.792978</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 092 350</ms:GML_ID>
        <ms:NAZWA>069 092 350</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069092350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298526.928946 791257.513718</gml:lowerCorner>
        		<gml:upperCorner>298526.928946 791257.513718</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298526.928946 791257.513718</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 092 736</ms:GML_ID>
        <ms:NAZWA>069 092 736</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069092736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295140.043000 793870.920000</gml:lowerCorner>
        		<gml:upperCorner>295140.043000 793870.920000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295140.043000 793870.920000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 097 863</ms:GML_ID>
        <ms:NAZWA>069 097 863</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069097863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295923.680739 794115.187295</gml:lowerCorner>
        		<gml:upperCorner>295923.680739 794115.187295</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295923.680739 794115.187295</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 096 958</ms:GML_ID>
        <ms:NAZWA>069 096 958</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069096958</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293519.499000 795741.738000</gml:lowerCorner>
        		<gml:upperCorner>293519.499000 795741.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293519.499000 795741.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 100 355</ms:GML_ID>
        <ms:NAZWA>069 100 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069100355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293258.651000 796175.793000</gml:lowerCorner>
        		<gml:upperCorner>293258.651000 796175.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293258.651000 796175.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 100 861</ms:GML_ID>
        <ms:NAZWA>069 100 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069100861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292991.262367 796620.856579</gml:lowerCorner>
        		<gml:upperCorner>292991.262367 796620.856579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292991.262367 796620.856579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 101 379</ms:GML_ID>
        <ms:NAZWA>069 101 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069101379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292827.174072 796894.932409</gml:lowerCorner>
        		<gml:upperCorner>292827.174072 796894.932409</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292827.174072 796894.932409</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 101 700</ms:GML_ID>
        <ms:NAZWA>069 101 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069101700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292552.032531 797355.645638</gml:lowerCorner>
        		<gml:upperCorner>292552.032531 797355.645638</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292552.032531 797355.645638</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 102 236</ms:GML_ID>
        <ms:NAZWA>069 102 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069102236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292340.571000 797709.666000</gml:lowerCorner>
        		<gml:upperCorner>292340.571000 797709.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292340.571000 797709.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 102 648</ms:GML_ID>
        <ms:NAZWA>069 102 648</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069102648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291988.100000 798614.875000</gml:lowerCorner>
        		<gml:upperCorner>291988.100000 798614.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291988.100000 798614.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.069 103 631</ms:GML_ID>
        <ms:NAZWA>069 103 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK LUBLIN</ms:IDDE>
        <ms:SEARCH>069103631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580315.998021 695103.935671</gml:lowerCorner>
        		<gml:upperCorner>580315.998021 695103.935671</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580315.998021 695103.935671</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 020 169</ms:GML_ID>
        <ms:NAZWA>036 020 169</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036020169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579952.950000 696442.895000</gml:lowerCorner>
        		<gml:upperCorner>579952.950000 696442.895000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579952.950000 696442.895000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 021 560</ms:GML_ID>
        <ms:NAZWA>036 021 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036021560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579548.262829 699077.596301</gml:lowerCorner>
        		<gml:upperCorner>579548.262829 699077.596301</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579548.262829 699077.596301</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 024 239</ms:GML_ID>
        <ms:NAZWA>036 024 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036024239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579544.923396 700302.863207</gml:lowerCorner>
        		<gml:upperCorner>579544.923396 700302.863207</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579544.923396 700302.863207</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 025 466</ms:GML_ID>
        <ms:NAZWA>036 025 466</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036025466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579667.965142 701554.976132</gml:lowerCorner>
        		<gml:upperCorner>579667.965142 701554.976132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579667.965142 701554.976132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 026 726</ms:GML_ID>
        <ms:NAZWA>036 026 726</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036026726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581349.469323 701688.809340</gml:lowerCorner>
        		<gml:upperCorner>581349.469323 701688.809340</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581349.469323 701688.809340</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 002 962</ms:GML_ID>
        <ms:NAZWA>049 002 962</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049002962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579894.930882 701733.957494</gml:lowerCorner>
        		<gml:upperCorner>579894.930882 701733.957494</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579894.930882 701733.957494</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.049 001 465</ms:GML_ID>
        <ms:NAZWA>049 001 465</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>049001465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579783.470899 702674.062869</gml:lowerCorner>
        		<gml:upperCorner>579783.470899 702674.062869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579783.470899 702674.062869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 027 853</ms:GML_ID>
        <ms:NAZWA>036 027 853</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036027853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579966.721174 704991.227360</gml:lowerCorner>
        		<gml:upperCorner>579966.721174 704991.227360</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579966.721174 704991.227360</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 030 197</ms:GML_ID>
        <ms:NAZWA>036 030 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036030197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581414.024594 709222.101392</gml:lowerCorner>
        		<gml:upperCorner>581414.024594 709222.101392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581414.024594 709222.101392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 034 854</ms:GML_ID>
        <ms:NAZWA>036 034 854</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036034854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581274.871614 719659.927095</gml:lowerCorner>
        		<gml:upperCorner>581274.871614 719659.927095</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581274.871614 719659.927095</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 045 561</ms:GML_ID>
        <ms:NAZWA>036 045 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036045561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581477.287202 720347.972748</gml:lowerCorner>
        		<gml:upperCorner>581477.287202 720347.972748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581477.287202 720347.972748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 046 271</ms:GML_ID>
        <ms:NAZWA>036 046 271</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036046271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581248.966632 721305.655616</gml:lowerCorner>
        		<gml:upperCorner>581248.966632 721305.655616</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581248.966632 721305.655616</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 047 286</ms:GML_ID>
        <ms:NAZWA>036 047 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036047286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581192.925161 722266.986470</gml:lowerCorner>
        		<gml:upperCorner>581192.925161 722266.986470</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581192.925161 722266.986470</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 048 250</ms:GML_ID>
        <ms:NAZWA>036 048 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036048250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581129.590752 722701.223952</gml:lowerCorner>
        		<gml:upperCorner>581129.590752 722701.223952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581129.590752 722701.223952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 048 687</ms:GML_ID>
        <ms:NAZWA>036 048 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036048687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580948.450646 723872.366384</gml:lowerCorner>
        		<gml:upperCorner>580948.450646 723872.366384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580948.450646 723872.366384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 049 873</ms:GML_ID>
        <ms:NAZWA>036 049 873</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036049873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580860.064493 725802.697447</gml:lowerCorner>
        		<gml:upperCorner>580860.064493 725802.697447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580860.064493 725802.697447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 051 880</ms:GML_ID>
        <ms:NAZWA>036 051 880</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036051880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580364.147674 726975.399735</gml:lowerCorner>
        		<gml:upperCorner>580364.147674 726975.399735</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580364.147674 726975.399735</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 053 221</ms:GML_ID>
        <ms:NAZWA>036 053 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036053221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579797.572979 730093.019674</gml:lowerCorner>
        		<gml:upperCorner>579797.572979 730093.019674</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579797.572979 730093.019674</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 056 390</ms:GML_ID>
        <ms:NAZWA>036 056 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036056390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579703.718000 731787.453000</gml:lowerCorner>
        		<gml:upperCorner>579703.718000 731787.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579703.718000 731787.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 058 080</ms:GML_ID>
        <ms:NAZWA>036 058 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036058080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579567.804883 733567.266231</gml:lowerCorner>
        		<gml:upperCorner>579567.804883 733567.266231</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579567.804883 733567.266231</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 059 871</ms:GML_ID>
        <ms:NAZWA>036 059 871</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036059871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578824.342293 735176.667129</gml:lowerCorner>
        		<gml:upperCorner>578824.342293 735176.667129</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578824.342293 735176.667129</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 061 711</ms:GML_ID>
        <ms:NAZWA>036 061 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036061711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578570.847352 735833.434832</gml:lowerCorner>
        		<gml:upperCorner>578570.847352 735833.434832</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578570.847352 735833.434832</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 062 414</ms:GML_ID>
        <ms:NAZWA>036 062 414</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036062414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578105.690431 737369.941885</gml:lowerCorner>
        		<gml:upperCorner>578105.690431 737369.941885</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578105.690431 737369.941885</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 064 029</ms:GML_ID>
        <ms:NAZWA>036 064 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036064029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577980.099385 738325.168209</gml:lowerCorner>
        		<gml:upperCorner>577980.099385 738325.168209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577980.099385 738325.168209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 065 032</ms:GML_ID>
        <ms:NAZWA>036 065 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036065032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578059.125377 738776.928097</gml:lowerCorner>
        		<gml:upperCorner>578059.125377 738776.928097</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578059.125377 738776.928097</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 065 492</ms:GML_ID>
        <ms:NAZWA>036 065 492</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036065492</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578212.977553 739656.890920</gml:lowerCorner>
        		<gml:upperCorner>578212.977553 739656.890920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578212.977553 739656.890920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 066 381</ms:GML_ID>
        <ms:NAZWA>036 066 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036066381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578430.481711 740900.232702</gml:lowerCorner>
        		<gml:upperCorner>578430.481711 740900.232702</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578430.481711 740900.232702</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 067 645</ms:GML_ID>
        <ms:NAZWA>036 067 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036067645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578465.784752 741440.162458</gml:lowerCorner>
        		<gml:upperCorner>578465.784752 741440.162458</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578465.784752 741440.162458</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 068 190</ms:GML_ID>
        <ms:NAZWA>036 068 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036068190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578372.755088 742552.919066</gml:lowerCorner>
        		<gml:upperCorner>578372.755088 742552.919066</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578372.755088 742552.919066</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 069 308</ms:GML_ID>
        <ms:NAZWA>036 069 308</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036069308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578221.980289 743243.880292</gml:lowerCorner>
        		<gml:upperCorner>578221.980289 743243.880292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578221.980289 743243.880292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 070 014</ms:GML_ID>
        <ms:NAZWA>036 070 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036070014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578016.417452 743709.826423</gml:lowerCorner>
        		<gml:upperCorner>578016.417452 743709.826423</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578016.417452 743709.826423</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 070 526</ms:GML_ID>
        <ms:NAZWA>036 070 526</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036070526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577689.051593 744525.133623</gml:lowerCorner>
        		<gml:upperCorner>577689.051593 744525.133623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577689.051593 744525.133623</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 071 410</ms:GML_ID>
        <ms:NAZWA>036 071 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036071410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577158.960022 747186.320993</gml:lowerCorner>
        		<gml:upperCorner>577158.960022 747186.320993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577158.960022 747186.320993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 074 175</ms:GML_ID>
        <ms:NAZWA>036 074 175</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036074175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577194.991482 747734.426693</gml:lowerCorner>
        		<gml:upperCorner>577194.991482 747734.426693</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577194.991482 747734.426693</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 074 728</ms:GML_ID>
        <ms:NAZWA>036 074 728</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036074728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577286.683444 748180.410604</gml:lowerCorner>
        		<gml:upperCorner>577286.683444 748180.410604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577286.683444 748180.410604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 075 183</ms:GML_ID>
        <ms:NAZWA>036 075 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036075183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576931.881494 749595.309252</gml:lowerCorner>
        		<gml:upperCorner>576931.881494 749595.309252</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576931.881494 749595.309252</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 076 671</ms:GML_ID>
        <ms:NAZWA>036 076 671</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036076671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576943.036653 750034.139273</gml:lowerCorner>
        		<gml:upperCorner>576943.036653 750034.139273</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576943.036653 750034.139273</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 077 108</ms:GML_ID>
        <ms:NAZWA>036 077 108</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036077108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576891.546397 751738.425674</gml:lowerCorner>
        		<gml:upperCorner>576891.546397 751738.425674</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576891.546397 751738.425674</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 078 855</ms:GML_ID>
        <ms:NAZWA>036 078 855</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036078855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576803.284262 752064.293480</gml:lowerCorner>
        		<gml:upperCorner>576803.284262 752064.293480</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576803.284262 752064.293480</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 079 197</ms:GML_ID>
        <ms:NAZWA>036 079 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036079197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582537.389784 656583.543089</gml:lowerCorner>
        		<gml:upperCorner>582537.389784 656583.543089</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582537.389784 656583.543089</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 020 118</ms:GML_ID>
        <ms:NAZWA>035 020 118</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035020118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582831.125509 661092.737041</gml:lowerCorner>
        		<gml:upperCorner>582831.125509 661092.737041</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582831.125509 661092.737041</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 015 336</ms:GML_ID>
        <ms:NAZWA>035 015 336</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035015336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582690.206653 661433.269527</gml:lowerCorner>
        		<gml:upperCorner>582690.206653 661433.269527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582690.206653 661433.269527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 014 971</ms:GML_ID>
        <ms:NAZWA>035 014 971</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035014971</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582325.569589 662405.575280</gml:lowerCorner>
        		<gml:upperCorner>582325.569589 662405.575280</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582325.569589 662405.575280</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 013 928</ms:GML_ID>
        <ms:NAZWA>035 013 928</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035013928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582513.766659 663364.701363</gml:lowerCorner>
        		<gml:upperCorner>582513.766659 663364.701363</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582513.766659 663364.701363</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 012 950</ms:GML_ID>
        <ms:NAZWA>035 012 950</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035012950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582733.169564 664363.913098</gml:lowerCorner>
        		<gml:upperCorner>582733.169564 664363.913098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582733.169564 664363.913098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 011 926</ms:GML_ID>
        <ms:NAZWA>035 011 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035011926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582398.966177 667751.038552</gml:lowerCorner>
        		<gml:upperCorner>582398.966177 667751.038552</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582398.966177 667751.038552</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 008 361</ms:GML_ID>
        <ms:NAZWA>035 008 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035008361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581992.006136 668850.786497</gml:lowerCorner>
        		<gml:upperCorner>581992.006136 668850.786497</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581992.006136 668850.786497</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 007 190</ms:GML_ID>
        <ms:NAZWA>035 007 190</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035007190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581453.833487 669969.819080</gml:lowerCorner>
        		<gml:upperCorner>581453.833487 669969.819080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581453.833487 669969.819080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 005 948</ms:GML_ID>
        <ms:NAZWA>035 005 948</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035005948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580597.722000 671781.284000</gml:lowerCorner>
        		<gml:upperCorner>580597.722000 671781.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580597.722000 671781.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 003 941</ms:GML_ID>
        <ms:NAZWA>035 003 941</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035003941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579903.622394 673241.329848</gml:lowerCorner>
        		<gml:upperCorner>579903.622394 673241.329848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579903.622394 673241.329848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 002 324</ms:GML_ID>
        <ms:NAZWA>035 002 324</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035002324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562269.265000 673444.192000</gml:lowerCorner>
        		<gml:upperCorner>562269.265000 673444.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562269.265000 673444.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 055 530</ms:GML_ID>
        <ms:NAZWA>029 055 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029055530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560959.219000 673478.379000</gml:lowerCorner>
        		<gml:upperCorner>560959.219000 673478.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560959.219000 673478.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 054 219</ms:GML_ID>
        <ms:NAZWA>029 054 219</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029054219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565186.953000 673635.891000</gml:lowerCorner>
        		<gml:upperCorner>565186.953000 673635.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565186.953000 673635.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 058 506</ms:GML_ID>
        <ms:NAZWA>029 058 506</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029058506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579592.208029 673895.690750</gml:lowerCorner>
        		<gml:upperCorner>579592.208029 673895.690750</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579592.208029 673895.690750</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 001 606</ms:GML_ID>
        <ms:NAZWA>035 001 606</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035001606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566297.330000 674001.128000</gml:lowerCorner>
        		<gml:upperCorner>566297.330000 674001.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566297.330000 674001.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 059 675</ms:GML_ID>
        <ms:NAZWA>029 059 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029059675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578315.141000 674014.321000</gml:lowerCorner>
        		<gml:upperCorner>578315.141000 674014.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578315.141000 674014.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 071 931</ms:GML_ID>
        <ms:NAZWA>029 071 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029071931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577740.076659 674087.832396</gml:lowerCorner>
        		<gml:upperCorner>577740.076659 674087.832396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577740.076659 674087.832396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 071 352</ms:GML_ID>
        <ms:NAZWA>029 071 352</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029071352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577283.557789 674146.814646</gml:lowerCorner>
        		<gml:upperCorner>577283.557789 674146.814646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577283.557789 674146.814646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 070 891</ms:GML_ID>
        <ms:NAZWA>029 070 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029070891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577799.241261 674291.887786</gml:lowerCorner>
        		<gml:upperCorner>577799.241261 674291.887786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577799.241261 674291.887786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 002 828</ms:GML_ID>
        <ms:NAZWA>034 002 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034002828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579454.971386 674317.993104</gml:lowerCorner>
        		<gml:upperCorner>579454.971386 674317.993104</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579454.971386 674317.993104</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.035 001 150</ms:GML_ID>
        <ms:NAZWA>035 001 150</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>035001150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575009.966000 674440.056000</gml:lowerCorner>
        		<gml:upperCorner>575009.966000 674440.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575009.966000 674440.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 068 597</ms:GML_ID>
        <ms:NAZWA>029 068 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029068597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567653.849000 674448.178000</gml:lowerCorner>
        		<gml:upperCorner>567653.849000 674448.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567653.849000 674448.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 061 105</ms:GML_ID>
        <ms:NAZWA>029 061 105</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029061105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574032.184000 674565.976000</gml:lowerCorner>
        		<gml:upperCorner>574032.184000 674565.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574032.184000 674565.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 067 613</ms:GML_ID>
        <ms:NAZWA>029 067 613</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029067613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573084.824955 674688.645311</gml:lowerCorner>
        		<gml:upperCorner>573084.824955 674688.645311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573084.824955 674688.645311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 066 656</ms:GML_ID>
        <ms:NAZWA>029 066 656</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029066656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559749.113864 688015.963414</gml:lowerCorner>
        		<gml:upperCorner>559749.113864 688015.963414</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559749.113864 688015.963414</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 026 008</ms:GML_ID>
        <ms:NAZWA>034 026 008</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034026008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560513.932000 686985.827000</gml:lowerCorner>
        		<gml:upperCorner>560513.932000 686985.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560513.932000 686985.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 024 724</ms:GML_ID>
        <ms:NAZWA>034 024 724</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034024724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561972.970000 684994.000000</gml:lowerCorner>
        		<gml:upperCorner>561972.970000 684994.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561972.970000 684994.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 022 252</ms:GML_ID>
        <ms:NAZWA>034 022 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034022252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563428.757344 683869.511181</gml:lowerCorner>
        		<gml:upperCorner>563428.757344 683869.511181</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563428.757344 683869.511181</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 020 379</ms:GML_ID>
        <ms:NAZWA>034 020 379</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034020379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563825.637000 683620.248000</gml:lowerCorner>
        		<gml:upperCorner>563825.637000 683620.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563825.637000 683620.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 019 907</ms:GML_ID>
        <ms:NAZWA>034 019 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034019907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564836.812715 682925.255620</gml:lowerCorner>
        		<gml:upperCorner>564836.812715 682925.255620</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564836.812715 682925.255620</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 018 667</ms:GML_ID>
        <ms:NAZWA>034 018 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034018667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565514.384849 682437.846768</gml:lowerCorner>
        		<gml:upperCorner>565514.384849 682437.846768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565514.384849 682437.846768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 017 833</ms:GML_ID>
        <ms:NAZWA>034 017 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034017833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565967.079000 682015.373000</gml:lowerCorner>
        		<gml:upperCorner>565967.079000 682015.373000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565967.079000 682015.373000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 017 211</ms:GML_ID>
        <ms:NAZWA>034 017 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034017211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566299.197867 681669.223057</gml:lowerCorner>
        		<gml:upperCorner>566299.197867 681669.223057</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566299.197867 681669.223057</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 016 730</ms:GML_ID>
        <ms:NAZWA>034 016 730</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034016730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567070.238000 681147.366000</gml:lowerCorner>
        		<gml:upperCorner>567070.238000 681147.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567070.238000 681147.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 015 800</ms:GML_ID>
        <ms:NAZWA>034 015 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034015800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568956.322848 679445.068950</gml:lowerCorner>
        		<gml:upperCorner>568956.322848 679445.068950</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568956.322848 679445.068950</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 013 247</ms:GML_ID>
        <ms:NAZWA>034 013 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034013247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569718.170000 675070.852000</gml:lowerCorner>
        		<gml:upperCorner>569718.170000 675070.852000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569718.170000 675070.852000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 063 265</ms:GML_ID>
        <ms:NAZWA>029 063 265</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029063265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570401.597050 675033.605564</gml:lowerCorner>
        		<gml:upperCorner>570401.597050 675033.605564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570401.597050 675033.605564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 063 950</ms:GML_ID>
        <ms:NAZWA>029 063 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029063950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570455.837000 679077.175000</gml:lowerCorner>
        		<gml:upperCorner>570455.837000 679077.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570455.837000 679077.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 011 698</ms:GML_ID>
        <ms:NAZWA>034 011 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034011698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571380.831000 674907.389000</gml:lowerCorner>
        		<gml:upperCorner>571380.831000 674907.389000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571380.831000 674907.389000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 064 938</ms:GML_ID>
        <ms:NAZWA>029 064 938</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029064938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572365.440246 678170.761840</gml:lowerCorner>
        		<gml:upperCorner>572365.440246 678170.761840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572365.440246 678170.761840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 009 584</ms:GML_ID>
        <ms:NAZWA>034 009 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034009584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574295.817000 676820.437000</gml:lowerCorner>
        		<gml:upperCorner>574295.817000 676820.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574295.817000 676820.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 007 225</ms:GML_ID>
        <ms:NAZWA>034 007 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034007225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575792.748528 675815.991153</gml:lowerCorner>
        		<gml:upperCorner>575792.748528 675815.991153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575792.748528 675815.991153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 005 418</ms:GML_ID>
        <ms:NAZWA>034 005 418</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034005418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579581.302502 690947.127469</gml:lowerCorner>
        		<gml:upperCorner>579581.302502 690947.127469</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579581.302502 690947.127469</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 015 894</ms:GML_ID>
        <ms:NAZWA>036 015 894</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036015894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579762.182191 689715.593985</gml:lowerCorner>
        		<gml:upperCorner>579762.182191 689715.593985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579762.182191 689715.593985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 014 647</ms:GML_ID>
        <ms:NAZWA>036 014 647</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036014647</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579939.928000 677559.557000</gml:lowerCorner>
        		<gml:upperCorner>579939.928000 677559.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579939.928000 677559.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 002 419</ms:GML_ID>
        <ms:NAZWA>036 002 419</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036002419</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580030.063026 686793.101934</gml:lowerCorner>
        		<gml:upperCorner>580030.063026 686793.101934</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580030.063026 686793.101934</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 011 702</ms:GML_ID>
        <ms:NAZWA>036 011 702</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036011702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580053.312000 678746.179000</gml:lowerCorner>
        		<gml:upperCorner>580053.312000 678746.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580053.312000 678746.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 003 611</ms:GML_ID>
        <ms:NAZWA>036 003 611</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036003611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580163.316000 693006.079000</gml:lowerCorner>
        		<gml:upperCorner>580163.316000 693006.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580163.316000 693006.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 018 038</ms:GML_ID>
        <ms:NAZWA>036 018 038</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036018038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580191.608103 685228.655812</gml:lowerCorner>
        		<gml:upperCorner>580191.608103 685228.655812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580191.608103 685228.655812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 010 129</ms:GML_ID>
        <ms:NAZWA>036 010 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036010129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580276.410039 684407.239691</gml:lowerCorner>
        		<gml:upperCorner>580276.410039 684407.239691</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580276.410039 684407.239691</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 009 300</ms:GML_ID>
        <ms:NAZWA>036 009 300</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036009300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580289.997000 681080.355000</gml:lowerCorner>
        		<gml:upperCorner>580289.997000 681080.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580289.997000 681080.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 005 959</ms:GML_ID>
        <ms:NAZWA>036 005 959</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036005959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580360.379347 675961.907797</gml:lowerCorner>
        		<gml:upperCorner>580360.379347 675961.907797</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580360.379347 675961.907797</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 074 991</ms:GML_ID>
        <ms:NAZWA>029 074 991</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029074991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580377.391000 694187.557000</gml:lowerCorner>
        		<gml:upperCorner>580377.391000 694187.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580377.391000 694187.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 019 239</ms:GML_ID>
        <ms:NAZWA>036 019 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036019239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580381.358000 683386.138000</gml:lowerCorner>
        		<gml:upperCorner>580381.358000 683386.138000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580381.358000 683386.138000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 008 276</ms:GML_ID>
        <ms:NAZWA>036 008 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036008276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580390.298319 676309.801240</gml:lowerCorner>
        		<gml:upperCorner>580390.298319 676309.801240</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580390.298319 676309.801240</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 001 085</ms:GML_ID>
        <ms:NAZWA>036 001 085</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036001085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580416.245260 682333.033452</gml:lowerCorner>
        		<gml:upperCorner>580416.245260 682333.033452</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580416.245260 682333.033452</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 007 219</ms:GML_ID>
        <ms:NAZWA>036 007 219</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036007219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580441.048624 676315.471249</gml:lowerCorner>
        		<gml:upperCorner>580441.048624 676315.471249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580441.048624 676315.471249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 001 093</ms:GML_ID>
        <ms:NAZWA>036 001 093</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036001093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573224.118000 774352.726000</gml:lowerCorner>
        		<gml:upperCorner>573224.118000 774352.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573224.118000 774352.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 054 117</ms:GML_ID>
        <ms:NAZWA>032 054 117</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032054117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572564.615611 774853.240658</gml:lowerCorner>
        		<gml:upperCorner>572564.615611 774853.240658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572564.615611 774853.240658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 053 274</ms:GML_ID>
        <ms:NAZWA>032 053 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032053274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575257.437000 774918.065000</gml:lowerCorner>
        		<gml:upperCorner>575257.437000 774918.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575257.437000 774918.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 056 396</ms:GML_ID>
        <ms:NAZWA>032 056 396</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032056396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576376.363000 775670.031000</gml:lowerCorner>
        		<gml:upperCorner>576376.363000 775670.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576376.363000 775670.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 057 754</ms:GML_ID>
        <ms:NAZWA>032 057 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032057754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570731.067000 776196.165000</gml:lowerCorner>
        		<gml:upperCorner>570731.067000 776196.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570731.067000 776196.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 050 989</ms:GML_ID>
        <ms:NAZWA>032 050 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032050989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569325.468000 776380.561000</gml:lowerCorner>
        		<gml:upperCorner>569325.468000 776380.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569325.468000 776380.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 049 535</ms:GML_ID>
        <ms:NAZWA>032 049 535</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032049535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568057.163000 776428.083000</gml:lowerCorner>
        		<gml:upperCorner>568057.163000 776428.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568057.163000 776428.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 048 263</ms:GML_ID>
        <ms:NAZWA>032 048 263</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032048263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567255.720694 776554.096193</gml:lowerCorner>
        		<gml:upperCorner>567255.720694 776554.096193</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567255.720694 776554.096193</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 047 451</ms:GML_ID>
        <ms:NAZWA>032 047 451</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032047451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565035.051000 777490.567000</gml:lowerCorner>
        		<gml:upperCorner>565035.051000 777490.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565035.051000 777490.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 044 992</ms:GML_ID>
        <ms:NAZWA>032 044 992</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032044992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563204.531000 778435.242000</gml:lowerCorner>
        		<gml:upperCorner>563204.531000 778435.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563204.531000 778435.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 042 932</ms:GML_ID>
        <ms:NAZWA>032 042 932</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032042932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561223.705000 778761.188000</gml:lowerCorner>
        		<gml:upperCorner>561223.705000 778761.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561223.705000 778761.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 040 913</ms:GML_ID>
        <ms:NAZWA>032 040 913</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032040913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560308.820000 778869.088000</gml:lowerCorner>
        		<gml:upperCorner>560308.820000 778869.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560308.820000 778869.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 039 990</ms:GML_ID>
        <ms:NAZWA>032 039 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032039990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559355.902000 779515.866000</gml:lowerCorner>
        		<gml:upperCorner>559355.902000 779515.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559355.902000 779515.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 038 829</ms:GML_ID>
        <ms:NAZWA>032 038 829</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032038829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558348.391463 780036.791882</gml:lowerCorner>
        		<gml:upperCorner>558348.391463 780036.791882</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558348.391463 780036.791882</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 037 689</ms:GML_ID>
        <ms:NAZWA>032 037 689</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032037689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557661.103713 780151.225908</gml:lowerCorner>
        		<gml:upperCorner>557661.103713 780151.225908</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557661.103713 780151.225908</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 036 990</ms:GML_ID>
        <ms:NAZWA>032 036 990</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032036990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555129.363658 781000.449601</gml:lowerCorner>
        		<gml:upperCorner>555129.363658 781000.449601</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555129.363658 781000.449601</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 034 272</ms:GML_ID>
        <ms:NAZWA>032 034 272</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032034272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553958.874000 781469.237000</gml:lowerCorner>
        		<gml:upperCorner>553958.874000 781469.237000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553958.874000 781469.237000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 033 020</ms:GML_ID>
        <ms:NAZWA>032 033 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032033020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552828.887000 782024.617000</gml:lowerCorner>
        		<gml:upperCorner>552828.887000 782024.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552828.887000 782024.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 031 744</ms:GML_ID>
        <ms:NAZWA>032 031 744</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032031744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552429.158130 782303.505023</gml:lowerCorner>
        		<gml:upperCorner>552429.158130 782303.505023</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552429.158130 782303.505023</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 031 254</ms:GML_ID>
        <ms:NAZWA>032 031 254</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032031254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550316.101980 783483.179977</gml:lowerCorner>
        		<gml:upperCorner>550316.101980 783483.179977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550316.101980 783483.179977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 028 834</ms:GML_ID>
        <ms:NAZWA>032 028 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032028834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549655.152162 810259.318931</gml:lowerCorner>
        		<gml:upperCorner>549655.152162 810259.318931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549655.152162 810259.318931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 027 447</ms:GML_ID>
        <ms:NAZWA>052 027 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052027447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549989.359135 809459.424897</gml:lowerCorner>
        		<gml:upperCorner>549989.359135 809459.424897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549989.359135 809459.424897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 026 558</ms:GML_ID>
        <ms:NAZWA>052 026 558</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052026558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550044.731000 809787.207000</gml:lowerCorner>
        		<gml:upperCorner>550044.731000 809787.207000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550044.731000 809787.207000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 119 270</ms:GML_ID>
        <ms:NAZWA>031 119 270</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031119270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551353.343687 809062.511498</gml:lowerCorner>
        		<gml:upperCorner>551353.343687 809062.511498</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551353.343687 809062.511498</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 120 792</ms:GML_ID>
        <ms:NAZWA>031 120 792</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031120792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554593.181387 809084.968025</gml:lowerCorner>
        		<gml:upperCorner>554593.181387 809084.968025</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554593.181387 809084.968025</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 124 151</ms:GML_ID>
        <ms:NAZWA>031 124 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031124151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555362.417237 809257.619828</gml:lowerCorner>
        		<gml:upperCorner>555362.417237 809257.619828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555362.417237 809257.619828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 124 933</ms:GML_ID>
        <ms:NAZWA>031 124 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031124933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555756.300418 809378.796584</gml:lowerCorner>
        		<gml:upperCorner>555756.300418 809378.796584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555756.300418 809378.796584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 125 345</ms:GML_ID>
        <ms:NAZWA>031 125 345</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031125345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557519.380010 810274.836201</gml:lowerCorner>
        		<gml:upperCorner>557519.380010 810274.836201</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557519.380010 810274.836201</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 127 322</ms:GML_ID>
        <ms:NAZWA>031 127 322</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031127322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558620.207186 810873.698654</gml:lowerCorner>
        		<gml:upperCorner>558620.207186 810873.698654</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558620.207186 810873.698654</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 128 581</ms:GML_ID>
        <ms:NAZWA>031 128 581</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031128581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559395.181836 811410.399479</gml:lowerCorner>
        		<gml:upperCorner>559395.181836 811410.399479</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559395.181836 811410.399479</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 129 520</ms:GML_ID>
        <ms:NAZWA>031 129 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031129520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561477.452000 812844.665000</gml:lowerCorner>
        		<gml:upperCorner>561477.452000 812844.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561477.452000 812844.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 132 047</ms:GML_ID>
        <ms:NAZWA>031 132 047</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031132047</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562999.837166 818884.446336</gml:lowerCorner>
        		<gml:upperCorner>562999.837166 818884.446336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562999.837166 818884.446336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 018 545</ms:GML_ID>
        <ms:NAZWA>059 018 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059018545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563041.616123 819165.692830</gml:lowerCorner>
        		<gml:upperCorner>563041.616123 819165.692830</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563041.616123 819165.692830</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 018 441</ms:GML_ID>
        <ms:NAZWA>059 018 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059018441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563651.225030 819860.522548</gml:lowerCorner>
        		<gml:upperCorner>563651.225030 819860.522548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563651.225030 819860.522548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 017 496</ms:GML_ID>
        <ms:NAZWA>059 017 496</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059017496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564035.594586 815461.558883</gml:lowerCorner>
        		<gml:upperCorner>564035.594586 815461.558883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564035.594586 815461.558883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 135 795</ms:GML_ID>
        <ms:NAZWA>031 135 795</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031135795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564275.535725 820669.025029</gml:lowerCorner>
        		<gml:upperCorner>564275.535725 820669.025029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564275.535725 820669.025029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 016 470</ms:GML_ID>
        <ms:NAZWA>059 016 470</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059016470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564572.962376 821090.216813</gml:lowerCorner>
        		<gml:upperCorner>564572.962376 821090.216813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564572.962376 821090.216813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 015 951</ms:GML_ID>
        <ms:NAZWA>059 015 951</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059015951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564701.239005 820866.870326</gml:lowerCorner>
        		<gml:upperCorner>564701.239005 820866.870326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564701.239005 820866.870326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 016 100</ms:GML_ID>
        <ms:NAZWA>059 016 100</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059016100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565184.602182 821744.376989</gml:lowerCorner>
        		<gml:upperCorner>565184.602182 821744.376989</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565184.602182 821744.376989</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 015 060</ms:GML_ID>
        <ms:NAZWA>059 015 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059015060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565404.249981 817588.600282</gml:lowerCorner>
        		<gml:upperCorner>565404.249981 817588.600282</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565404.249981 817588.600282</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 138 322</ms:GML_ID>
        <ms:NAZWA>031 138 322</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031138322</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565773.873661 820488.459138</gml:lowerCorner>
        		<gml:upperCorner>565773.873661 820488.459138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565773.873661 820488.459138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.913 002 045</ms:GML_ID>
        <ms:NAZWA>913 002 045</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>913002045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565824.668460 822664.741492</gml:lowerCorner>
        		<gml:upperCorner>565824.668460 822664.741492</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565824.668460 822664.741492</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 013 931</ms:GML_ID>
        <ms:NAZWA>059 013 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059013931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565900.463262 822808.192309</gml:lowerCorner>
        		<gml:upperCorner>565900.463262 822808.192309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565900.463262 822808.192309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 013 768</ms:GML_ID>
        <ms:NAZWA>059 013 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059013768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566099.274719 818291.007946</gml:lowerCorner>
        		<gml:upperCorner>566099.274719 818291.007946</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566099.274719 818291.007946</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 139 323</ms:GML_ID>
        <ms:NAZWA>031 139 323</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031139323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567030.510000 820168.341000</gml:lowerCorner>
        		<gml:upperCorner>567030.510000 820168.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567030.510000 820168.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.913 000 713</ms:GML_ID>
        <ms:NAZWA>913 000 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>913000713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567543.871535 820233.958759</gml:lowerCorner>
        		<gml:upperCorner>567543.871535 820233.958759</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567543.871535 820233.958759</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 141 742</ms:GML_ID>
        <ms:NAZWA>031 141 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031141742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567564.105750 823665.927977</gml:lowerCorner>
        		<gml:upperCorner>567564.105750 823665.927977</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567564.105750 823665.927977</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 011 883</ms:GML_ID>
        <ms:NAZWA>059 011 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059011883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568811.477727 821913.081745</gml:lowerCorner>
        		<gml:upperCorner>568811.477727 821913.081745</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568811.477727 821913.081745</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 143 845</ms:GML_ID>
        <ms:NAZWA>031 143 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031143845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569184.580000 822653.952000</gml:lowerCorner>
        		<gml:upperCorner>569184.580000 822653.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569184.580000 822653.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 009 739</ms:GML_ID>
        <ms:NAZWA>059 009 739</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059009739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570158.363684 823594.199979</gml:lowerCorner>
        		<gml:upperCorner>570158.363684 823594.199979</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570158.363684 823594.199979</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 146 003</ms:GML_ID>
        <ms:NAZWA>031 146 003</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031146003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570682.158000 824421.662000</gml:lowerCorner>
        		<gml:upperCorner>570682.158000 824421.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570682.158000 824421.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.059 007 392</ms:GML_ID>
        <ms:NAZWA>059 007 392</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>059007392</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570724.753272 824353.549337</gml:lowerCorner>
        		<gml:upperCorner>570724.753272 824353.549337</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570724.753272 824353.549337</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 146 949</ms:GML_ID>
        <ms:NAZWA>031 146 949</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031146949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544626.618000 784395.591000</gml:lowerCorner>
        		<gml:upperCorner>544626.618000 784395.591000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544626.618000 784395.591000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 022 769</ms:GML_ID>
        <ms:NAZWA>032 022 769</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032022769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546227.504000 784399.412000</gml:lowerCorner>
        		<gml:upperCorner>546227.504000 784399.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546227.504000 784399.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 024 391</ms:GML_ID>
        <ms:NAZWA>032 024 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032024391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548456.895000 784425.132000</gml:lowerCorner>
        		<gml:upperCorner>548456.895000 784425.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548456.895000 784425.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 026 743</ms:GML_ID>
        <ms:NAZWA>032 026 743</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032026743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548691.032767 784471.511955</gml:lowerCorner>
        		<gml:upperCorner>548691.032767 784471.511955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548691.032767 784471.511955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 000 274</ms:GML_ID>
        <ms:NAZWA>052 000 274</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052000274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547498.786000 784754.854000</gml:lowerCorner>
        		<gml:upperCorner>547498.786000 784754.854000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547498.786000 784754.854000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 025 730</ms:GML_ID>
        <ms:NAZWA>032 025 730</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032025730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543670.551000 784980.316000</gml:lowerCorner>
        		<gml:upperCorner>543670.551000 784980.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543670.551000 784980.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 021 615</ms:GML_ID>
        <ms:NAZWA>032 021 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032021615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542776.674000 785565.012000</gml:lowerCorner>
        		<gml:upperCorner>542776.674000 785565.012000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542776.674000 785565.012000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 020 577</ms:GML_ID>
        <ms:NAZWA>032 020 577</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032020577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548609.635575 785776.064686</gml:lowerCorner>
        		<gml:upperCorner>548609.635575 785776.064686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548609.635575 785776.064686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 001 583</ms:GML_ID>
        <ms:NAZWA>052 001 583</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052001583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541701.091718 786470.068257</gml:lowerCorner>
        		<gml:upperCorner>541701.091718 786470.068257</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541701.091718 786470.068257</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 019 171</ms:GML_ID>
        <ms:NAZWA>032 019 171</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032019171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548576.705126 786927.638985</gml:lowerCorner>
        		<gml:upperCorner>548576.705126 786927.638985</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548576.705126 786927.638985</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 002 736</ms:GML_ID>
        <ms:NAZWA>052 002 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052002736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548544.433912 788050.034104</gml:lowerCorner>
        		<gml:upperCorner>548544.433912 788050.034104</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548544.433912 788050.034104</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 003 857</ms:GML_ID>
        <ms:NAZWA>052 003 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052003857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548638.447000 789292.386000</gml:lowerCorner>
        		<gml:upperCorner>548638.447000 789292.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548638.447000 789292.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 005 109</ms:GML_ID>
        <ms:NAZWA>052 005 109</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052005109</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548888.554988 791382.795022</gml:lowerCorner>
        		<gml:upperCorner>548888.554988 791382.795022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548888.554988 791382.795022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 007 218</ms:GML_ID>
        <ms:NAZWA>052 007 218</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052007218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548979.693000 793680.788000</gml:lowerCorner>
        		<gml:upperCorner>548979.693000 793680.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548979.693000 793680.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 009 529</ms:GML_ID>
        <ms:NAZWA>052 009 529</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052009529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549597.886000 797277.635000</gml:lowerCorner>
        		<gml:upperCorner>549597.886000 797277.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549597.886000 797277.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 013 455</ms:GML_ID>
        <ms:NAZWA>052 013 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052013455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549661.078000 797799.621000</gml:lowerCorner>
        		<gml:upperCorner>549661.078000 797799.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549661.078000 797799.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 013 982</ms:GML_ID>
        <ms:NAZWA>052 013 982</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052013982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549854.629000 799413.915000</gml:lowerCorner>
        		<gml:upperCorner>549854.629000 799413.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549854.629000 799413.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 015 605</ms:GML_ID>
        <ms:NAZWA>052 015 605</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052015605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550016.371000 800626.144000</gml:lowerCorner>
        		<gml:upperCorner>550016.371000 800626.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550016.371000 800626.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 016 828</ms:GML_ID>
        <ms:NAZWA>052 016 828</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052016828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550289.475523 801423.866833</gml:lowerCorner>
        		<gml:upperCorner>550289.475523 801423.866833</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550289.475523 801423.866833</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 017 672</ms:GML_ID>
        <ms:NAZWA>052 017 672</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052017672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550997.377000 803477.131000</gml:lowerCorner>
        		<gml:upperCorner>550997.377000 803477.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550997.377000 803477.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 019 842</ms:GML_ID>
        <ms:NAZWA>052 019 842</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052019842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541056.798000 804122.257000</gml:lowerCorner>
        		<gml:upperCorner>541056.798000 804122.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541056.798000 804122.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 108 232</ms:GML_ID>
        <ms:NAZWA>031 108 232</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031108232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551051.945711 804552.345151</gml:lowerCorner>
        		<gml:upperCorner>551051.945711 804552.345151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551051.945711 804552.345151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 020 920</ms:GML_ID>
        <ms:NAZWA>052 020 920</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052020920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542302.568097 804965.248691</gml:lowerCorner>
        		<gml:upperCorner>542302.568097 804965.248691</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542302.568097 804965.248691</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 109 742</ms:GML_ID>
        <ms:NAZWA>031 109 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031109742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544713.230000 806289.765000</gml:lowerCorner>
        		<gml:upperCorner>544713.230000 806289.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544713.230000 806289.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 112 503</ms:GML_ID>
        <ms:NAZWA>031 112 503</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031112503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545435.827000 806599.001000</gml:lowerCorner>
        		<gml:upperCorner>545435.827000 806599.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545435.827000 806599.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 113 287</ms:GML_ID>
        <ms:NAZWA>031 113 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031113287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551105.552000 806617.232000</gml:lowerCorner>
        		<gml:upperCorner>551105.552000 806617.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551105.552000 806617.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 022 980</ms:GML_ID>
        <ms:NAZWA>052 022 980</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052022980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546071.192000 807016.167000</gml:lowerCorner>
        		<gml:upperCorner>546071.192000 807016.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546071.192000 807016.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 114 056</ms:GML_ID>
        <ms:NAZWA>031 114 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031114056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546669.295000 807611.380000</gml:lowerCorner>
        		<gml:upperCorner>546669.295000 807611.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546669.295000 807611.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 114 896</ms:GML_ID>
        <ms:NAZWA>031 114 896</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031114896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551133.330262 807693.633831</gml:lowerCorner>
        		<gml:upperCorner>551133.330262 807693.633831</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551133.330262 807693.633831</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 024 061</ms:GML_ID>
        <ms:NAZWA>052 024 061</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052024061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551142.028035 808025.770128</gml:lowerCorner>
        		<gml:upperCorner>551142.028035 808025.770128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551142.028035 808025.770128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 024 393</ms:GML_ID>
        <ms:NAZWA>052 024 393</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052024393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552219.970093 808729.431679</gml:lowerCorner>
        		<gml:upperCorner>552219.970093 808729.431679</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552219.970093 808729.431679</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 121 719</ms:GML_ID>
        <ms:NAZWA>031 121 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031121719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547911.039644 808847.437548</gml:lowerCorner>
        		<gml:upperCorner>547911.039644 808847.437548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547911.039644 808847.437548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 116 649</ms:GML_ID>
        <ms:NAZWA>031 116 649</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031116649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551089.189213 808882.475481</gml:lowerCorner>
        		<gml:upperCorner>551089.189213 808882.475481</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551089.189213 808882.475481</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.052 025 267</ms:GML_ID>
        <ms:NAZWA>052 025 267</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>052025267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553826.499017 808912.391045</gml:lowerCorner>
        		<gml:upperCorner>553826.499017 808912.391045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553826.499017 808912.391045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 123 359</ms:GML_ID>
        <ms:NAZWA>031 123 359</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031123359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551340.830914 809021.991634</gml:lowerCorner>
        		<gml:upperCorner>551340.830914 809021.991634</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551340.830914 809021.991634</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.858 120 833</ms:GML_ID>
        <ms:NAZWA>858 120 833</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>858120833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554003.961235 695789.928400</gml:lowerCorner>
        		<gml:upperCorner>554003.961235 695789.928400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554003.961235 695789.928400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 035 678</ms:GML_ID>
        <ms:NAZWA>034 035 678</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034035678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549233.164548 698738.766714</gml:lowerCorner>
        		<gml:upperCorner>549233.164548 698738.766714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549233.164548 698738.766714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 041 341</ms:GML_ID>
        <ms:NAZWA>034 041 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034041341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547119.016000 701234.097000</gml:lowerCorner>
        		<gml:upperCorner>547119.016000 701234.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547119.016000 701234.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 044 671</ms:GML_ID>
        <ms:NAZWA>034 044 671</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034044671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546573.536572 701929.539107</gml:lowerCorner>
        		<gml:upperCorner>546573.536572 701929.539107</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546573.536572 701929.539107</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 045 555</ms:GML_ID>
        <ms:NAZWA>034 045 555</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034045555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546166.204000 702449.229000</gml:lowerCorner>
        		<gml:upperCorner>546166.204000 702449.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546166.204000 702449.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 046 217</ms:GML_ID>
        <ms:NAZWA>034 046 217</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034046217</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545230.637192 703196.004788</gml:lowerCorner>
        		<gml:upperCorner>545230.637192 703196.004788</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545230.637192 703196.004788</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 047 414</ms:GML_ID>
        <ms:NAZWA>034 047 414</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034047414</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544060.043338 704129.182527</gml:lowerCorner>
        		<gml:upperCorner>544060.043338 704129.182527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544060.043338 704129.182527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 048 912</ms:GML_ID>
        <ms:NAZWA>034 048 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034048912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543137.959082 704939.792555</gml:lowerCorner>
        		<gml:upperCorner>543137.959082 704939.792555</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543137.959082 704939.792555</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 050 140</ms:GML_ID>
        <ms:NAZWA>034 050 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034050140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542198.627000 705789.297000</gml:lowerCorner>
        		<gml:upperCorner>542198.627000 705789.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542198.627000 705789.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 051 405</ms:GML_ID>
        <ms:NAZWA>034 051 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034051405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540873.366186 706027.527695</gml:lowerCorner>
        		<gml:upperCorner>540873.366186 706027.527695</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540873.366186 706027.527695</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 052 880</ms:GML_ID>
        <ms:NAZWA>034 052 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034052880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542253.368530 707246.660412</gml:lowerCorner>
        		<gml:upperCorner>542253.368530 707246.660412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542253.368530 707246.660412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 090 654</ms:GML_ID>
        <ms:NAZWA>006 090 654</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006090654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545213.269075 711993.117302</gml:lowerCorner>
        		<gml:upperCorner>545213.269075 711993.117302</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545213.269075 711993.117302</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 096 249</ms:GML_ID>
        <ms:NAZWA>006 096 249</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006096249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545931.059109 713145.484529</gml:lowerCorner>
        		<gml:upperCorner>545931.059109 713145.484529</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545931.059109 713145.484529</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 097 607</ms:GML_ID>
        <ms:NAZWA>006 097 607</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006097607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546770.972065 714493.200672</gml:lowerCorner>
        		<gml:upperCorner>546770.972065 714493.200672</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546770.972065 714493.200672</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 099 195</ms:GML_ID>
        <ms:NAZWA>006 099 195</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006099195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548767.075773 717697.382660</gml:lowerCorner>
        		<gml:upperCorner>548767.075773 717697.382660</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548767.075773 717697.382660</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 102 968</ms:GML_ID>
        <ms:NAZWA>006 102 968</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006102968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550804.276728 720965.930663</gml:lowerCorner>
        		<gml:upperCorner>550804.276728 720965.930663</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550804.276728 720965.930663</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 106 820</ms:GML_ID>
        <ms:NAZWA>006 106 820</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006106820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576531.021000 752822.726000</gml:lowerCorner>
        		<gml:upperCorner>576531.021000 752822.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576531.021000 752822.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 080 007</ms:GML_ID>
        <ms:NAZWA>036 080 007</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036080007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576327.119990 753612.966883</gml:lowerCorner>
        		<gml:upperCorner>576327.119990 753612.966883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576327.119990 753612.966883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 080 823</ms:GML_ID>
        <ms:NAZWA>036 080 823</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036080823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576130.978920 754421.750242</gml:lowerCorner>
        		<gml:upperCorner>576130.978920 754421.750242</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576130.978920 754421.750242</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 081 657</ms:GML_ID>
        <ms:NAZWA>036 081 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036081657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575962.526725 755744.259205</gml:lowerCorner>
        		<gml:upperCorner>575962.526725 755744.259205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575962.526725 755744.259205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 082 990</ms:GML_ID>
        <ms:NAZWA>036 082 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036082990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575710.283806 756452.316588</gml:lowerCorner>
        		<gml:upperCorner>575710.283806 756452.316588</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575710.283806 756452.316588</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 083 741</ms:GML_ID>
        <ms:NAZWA>036 083 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036083741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575530.662405 757743.310787</gml:lowerCorner>
        		<gml:upperCorner>575530.662405 757743.310787</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575530.662405 757743.310787</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 085 046</ms:GML_ID>
        <ms:NAZWA>036 085 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036085046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575509.675000 758648.791000</gml:lowerCorner>
        		<gml:upperCorner>575509.675000 758648.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575509.675000 758648.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 085 955</ms:GML_ID>
        <ms:NAZWA>036 085 955</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036085955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575555.487464 759078.022138</gml:lowerCorner>
        		<gml:upperCorner>575555.487464 759078.022138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575555.487464 759078.022138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.036 086 388</ms:GML_ID>
        <ms:NAZWA>036 086 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>036086388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533729.593000 697001.695000</gml:lowerCorner>
        		<gml:upperCorner>533729.593000 697001.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533729.593000 697001.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 077 324</ms:GML_ID>
        <ms:NAZWA>006 077 324</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006077324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534117.907000 667051.169000</gml:lowerCorner>
        		<gml:upperCorner>534117.907000 667051.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534117.907000 667051.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 025 885</ms:GML_ID>
        <ms:NAZWA>029 025 885</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029025885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538895.044000 668857.695000</gml:lowerCorner>
        		<gml:upperCorner>538895.044000 668857.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538895.044000 668857.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 030 992</ms:GML_ID>
        <ms:NAZWA>029 030 992</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029030992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541333.731000 669784.152000</gml:lowerCorner>
        		<gml:upperCorner>541333.731000 669784.152000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541333.731000 669784.152000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 033 603</ms:GML_ID>
        <ms:NAZWA>029 033 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029033603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542299.387000 670151.132000</gml:lowerCorner>
        		<gml:upperCorner>542299.387000 670151.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542299.387000 670151.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 034 638</ms:GML_ID>
        <ms:NAZWA>029 034 638</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029034638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543491.144000 670604.300000</gml:lowerCorner>
        		<gml:upperCorner>543491.144000 670604.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543491.144000 670604.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 035 913</ms:GML_ID>
        <ms:NAZWA>029 035 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029035913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544115.771000 670841.454000</gml:lowerCorner>
        		<gml:upperCorner>544115.771000 670841.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544115.771000 670841.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 036 591</ms:GML_ID>
        <ms:NAZWA>029 036 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029036591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544930.893000 671151.495000</gml:lowerCorner>
        		<gml:upperCorner>544930.893000 671151.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544930.893000 671151.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 037 454</ms:GML_ID>
        <ms:NAZWA>029 037 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029037454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547010.917000 671820.532000</gml:lowerCorner>
        		<gml:upperCorner>547010.917000 671820.532000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547010.917000 671820.532000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 039 642</ms:GML_ID>
        <ms:NAZWA>029 039 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029039642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548085.448000 672115.313000</gml:lowerCorner>
        		<gml:upperCorner>548085.448000 672115.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548085.448000 672115.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 040 756</ms:GML_ID>
        <ms:NAZWA>029 040 756</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029040756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549452.300000 672490.680000</gml:lowerCorner>
        		<gml:upperCorner>549452.300000 672490.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549452.300000 672490.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 042 174</ms:GML_ID>
        <ms:NAZWA>029 042 174</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029042174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550732.331000 672843.371000</gml:lowerCorner>
        		<gml:upperCorner>550732.331000 672843.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550732.331000 672843.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 043 509</ms:GML_ID>
        <ms:NAZWA>029 043 509</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029043509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551371.871000 673018.635000</gml:lowerCorner>
        		<gml:upperCorner>551371.871000 673018.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551371.871000 673018.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 044 166</ms:GML_ID>
        <ms:NAZWA>029 044 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029044166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552007.724211 696811.347706</gml:lowerCorner>
        		<gml:upperCorner>552007.724211 696811.347706</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552007.724211 696811.347706</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 037 946</ms:GML_ID>
        <ms:NAZWA>034 037 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034037946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552322.237000 673165.580000</gml:lowerCorner>
        		<gml:upperCorner>552322.237000 673165.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552322.237000 673165.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 045 134</ms:GML_ID>
        <ms:NAZWA>029 045 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029045134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554068.368000 672889.890000</gml:lowerCorner>
        		<gml:upperCorner>554068.368000 672889.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554068.368000 672889.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 046 904</ms:GML_ID>
        <ms:NAZWA>029 046 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029046904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554889.410178 694627.481678</gml:lowerCorner>
        		<gml:upperCorner>554889.410178 694627.481678</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554889.410178 694627.481678</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 034 215</ms:GML_ID>
        <ms:NAZWA>034 034 215</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034034215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555669.469000 693570.174000</gml:lowerCorner>
        		<gml:upperCorner>555669.469000 693570.174000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555669.469000 693570.174000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 032 901</ms:GML_ID>
        <ms:NAZWA>034 032 901</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034032901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556735.834000 692133.396000</gml:lowerCorner>
        		<gml:upperCorner>556735.834000 692133.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556735.834000 692133.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 031 111</ms:GML_ID>
        <ms:NAZWA>034 031 111</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034031111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556803.182418 672439.096525</gml:lowerCorner>
        		<gml:upperCorner>556803.182418 672439.096525</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556803.182418 672439.096525</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 049 676</ms:GML_ID>
        <ms:NAZWA>029 049 676</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029049676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557326.522000 691336.531000</gml:lowerCorner>
        		<gml:upperCorner>557326.522000 691336.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557326.522000 691336.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 030 119</ms:GML_ID>
        <ms:NAZWA>034 030 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034030119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557677.009000 672288.249000</gml:lowerCorner>
        		<gml:upperCorner>557677.009000 672288.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557677.009000 672288.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 050 565</ms:GML_ID>
        <ms:NAZWA>029 050 565</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029050565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558075.312192 690323.717009</gml:lowerCorner>
        		<gml:upperCorner>558075.312192 690323.717009</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558075.312192 690323.717009</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 028 859</ms:GML_ID>
        <ms:NAZWA>034 028 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034028859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558442.803679 689825.197934</gml:lowerCorner>
        		<gml:upperCorner>558442.803679 689825.197934</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558442.803679 689825.197934</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 028 239</ms:GML_ID>
        <ms:NAZWA>034 028 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034028239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559642.139000 673339.995000</gml:lowerCorner>
        		<gml:upperCorner>559642.139000 673339.995000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559642.139000 673339.995000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 052 859</ms:GML_ID>
        <ms:NAZWA>029 052 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029052859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523185.775376 791234.665609</gml:lowerCorner>
        		<gml:upperCorner>523185.775376 791234.665609</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523185.775376 791234.665609</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 084 875</ms:GML_ID>
        <ms:NAZWA>031 084 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031084875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532955.977348 791702.870150</gml:lowerCorner>
        		<gml:upperCorner>532955.977348 791702.870150</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532955.977348 791702.870150</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 008 818</ms:GML_ID>
        <ms:NAZWA>032 008 818</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032008818</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532481.889000 792092.401000</gml:lowerCorner>
        		<gml:upperCorner>532481.889000 792092.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532481.889000 792092.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 008 205</ms:GML_ID>
        <ms:NAZWA>032 008 205</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032008205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531785.335249 792292.701518</gml:lowerCorner>
        		<gml:upperCorner>531785.335249 792292.701518</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531785.335249 792292.701518</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 007 478</ms:GML_ID>
        <ms:NAZWA>032 007 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032007478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530918.223589 792532.333947</gml:lowerCorner>
        		<gml:upperCorner>530918.223589 792532.333947</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530918.223589 792532.333947</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 006 576</ms:GML_ID>
        <ms:NAZWA>032 006 576</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032006576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524285.722862 793901.350274</gml:lowerCorner>
        		<gml:upperCorner>524285.722862 793901.350274</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524285.722862 793901.350274</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 087 768</ms:GML_ID>
        <ms:NAZWA>031 087 768</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031087768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530089.008370 794447.267674</gml:lowerCorner>
        		<gml:upperCorner>530089.008370 794447.267674</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530089.008370 794447.267674</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 004 453</ms:GML_ID>
        <ms:NAZWA>032 004 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032004453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524653.679107 794578.409312</gml:lowerCorner>
        		<gml:upperCorner>524653.679107 794578.409312</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524653.679107 794578.409312</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 088 529</ms:GML_ID>
        <ms:NAZWA>031 088 529</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031088529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527215.645218 794919.337797</gml:lowerCorner>
        		<gml:upperCorner>527215.645218 794919.337797</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527215.645218 794919.337797</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 091 456</ms:GML_ID>
        <ms:NAZWA>031 091 456</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031091456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527221.789641 795002.387854</gml:lowerCorner>
        		<gml:upperCorner>527221.789641 795002.387854</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527221.789641 795002.387854</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 001 282</ms:GML_ID>
        <ms:NAZWA>032 001 282</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032001282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528792.639691 795202.744609</gml:lowerCorner>
        		<gml:upperCorner>528792.639691 795202.744609</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528792.639691 795202.744609</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 002 824</ms:GML_ID>
        <ms:NAZWA>032 002 824</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032002824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527954.085000 795223.682000</gml:lowerCorner>
        		<gml:upperCorner>527954.085000 795223.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527954.085000 795223.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 002 075</ms:GML_ID>
        <ms:NAZWA>032 002 075</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032002075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525327.612785 795250.940878</gml:lowerCorner>
        		<gml:upperCorner>525327.612785 795250.940878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525327.612785 795250.940878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 089 516</ms:GML_ID>
        <ms:NAZWA>031 089 516</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031089516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524714.147701 795278.624858</gml:lowerCorner>
        		<gml:upperCorner>524714.147701 795278.624858</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524714.147701 795278.624858</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.043 001 260</ms:GML_ID>
        <ms:NAZWA>043 001 260</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>043001260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524029.243000 795286.225000</gml:lowerCorner>
        		<gml:upperCorner>524029.243000 795286.225000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524029.243000 795286.225000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.043 001 946</ms:GML_ID>
        <ms:NAZWA>043 001 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>043001946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521461.416382 795400.332723</gml:lowerCorner>
        		<gml:upperCorner>521461.416382 795400.332723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521461.416382 795400.332723</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.043 004 519</ms:GML_ID>
        <ms:NAZWA>043 004 519</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>043004519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528339.040503 795658.819348</gml:lowerCorner>
        		<gml:upperCorner>528339.040503 795658.819348</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528339.040503 795658.819348</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 092 944</ms:GML_ID>
        <ms:NAZWA>031 092 944</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031092944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529911.895609 796957.013040</gml:lowerCorner>
        		<gml:upperCorner>529911.895609 796957.013040</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529911.895609 796957.013040</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 094 993</ms:GML_ID>
        <ms:NAZWA>031 094 993</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031094993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530766.428946 797487.657839</gml:lowerCorner>
        		<gml:upperCorner>530766.428946 797487.657839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530766.428946 797487.657839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 096 000</ms:GML_ID>
        <ms:NAZWA>031 096 000</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031096000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531962.075539 798231.204808</gml:lowerCorner>
        		<gml:upperCorner>531962.075539 798231.204808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531962.075539 798231.204808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 097 407</ms:GML_ID>
        <ms:NAZWA>031 097 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031097407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533145.660450 798967.329803</gml:lowerCorner>
        		<gml:upperCorner>533145.660450 798967.329803</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533145.660450 798967.329803</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 098 799</ms:GML_ID>
        <ms:NAZWA>031 098 799</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031098799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534070.947444 799542.927192</gml:lowerCorner>
        		<gml:upperCorner>534070.947444 799542.927192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534070.947444 799542.927192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 099 888</ms:GML_ID>
        <ms:NAZWA>031 099 888</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031099888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537054.887892 801412.295806</gml:lowerCorner>
        		<gml:upperCorner>537054.887892 801412.295806</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537054.887892 801412.295806</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 103 407</ms:GML_ID>
        <ms:NAZWA>031 103 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031103407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538815.158000 802603.260000</gml:lowerCorner>
        		<gml:upperCorner>538815.158000 802603.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538815.158000 802603.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 105 525</ms:GML_ID>
        <ms:NAZWA>031 105 525</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031105525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539930.053996 803358.109959</gml:lowerCorner>
        		<gml:upperCorner>539930.053996 803358.109959</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539930.053996 803358.109959</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 106 878</ms:GML_ID>
        <ms:NAZWA>031 106 878</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031106878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513115.607000 669808.426000</gml:lowerCorner>
        		<gml:upperCorner>513115.607000 669808.426000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513115.607000 669808.426000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 043 155</ms:GML_ID>
        <ms:NAZWA>006 043 155</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006043155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513211.413000 666196.687000</gml:lowerCorner>
        		<gml:upperCorner>513211.413000 666196.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513211.413000 666196.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 003 621</ms:GML_ID>
        <ms:NAZWA>029 003 621</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029003621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513754.020000 665923.613000</gml:lowerCorner>
        		<gml:upperCorner>513754.020000 665923.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513754.020000 665923.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 004 233</ms:GML_ID>
        <ms:NAZWA>029 004 233</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029004233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515056.318000 665263.394000</gml:lowerCorner>
        		<gml:upperCorner>515056.318000 665263.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515056.318000 665263.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 005 689</ms:GML_ID>
        <ms:NAZWA>029 005 689</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029005689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515228.844000 672739.994000</gml:lowerCorner>
        		<gml:upperCorner>515228.844000 672739.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515228.844000 672739.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 046 771</ms:GML_ID>
        <ms:NAZWA>006 046 771</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006046771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515983.380000 664879.111000</gml:lowerCorner>
        		<gml:upperCorner>515983.380000 664879.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515983.380000 664879.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 006 696</ms:GML_ID>
        <ms:NAZWA>029 006 696</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029006696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517074.937000 664732.554000</gml:lowerCorner>
        		<gml:upperCorner>517074.937000 664732.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517074.937000 664732.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 007 807</ms:GML_ID>
        <ms:NAZWA>029 007 807</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029007807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517539.721000 675948.029000</gml:lowerCorner>
        		<gml:upperCorner>517539.721000 675948.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517539.721000 675948.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 050 725</ms:GML_ID>
        <ms:NAZWA>006 050 725</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006050725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518491.823000 665168.232000</gml:lowerCorner>
        		<gml:upperCorner>518491.823000 665168.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518491.823000 665168.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 009 294</ms:GML_ID>
        <ms:NAZWA>029 009 294</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029009294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518957.501423 677915.206154</gml:lowerCorner>
        		<gml:upperCorner>518957.501423 677915.206154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518957.501423 677915.206154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 053 151</ms:GML_ID>
        <ms:NAZWA>006 053 151</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006053151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519973.247265 665691.436762</gml:lowerCorner>
        		<gml:upperCorner>519973.247265 665691.436762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519973.247265 665691.436762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 010 865</ms:GML_ID>
        <ms:NAZWA>029 010 865</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029010865</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520161.109852 679581.336866</gml:lowerCorner>
        		<gml:upperCorner>520161.109852 679581.336866</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520161.109852 679581.336866</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 055 198</ms:GML_ID>
        <ms:NAZWA>006 055 198</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006055198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520368.595000 665837.565000</gml:lowerCorner>
        		<gml:upperCorner>520368.595000 665837.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520368.595000 665837.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 011 286</ms:GML_ID>
        <ms:NAZWA>029 011 286</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029011286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523761.172000 666698.809000</gml:lowerCorner>
        		<gml:upperCorner>523761.172000 666698.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523761.172000 666698.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 014 791</ms:GML_ID>
        <ms:NAZWA>029 014 791</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029014791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524494.843000 666751.439000</gml:lowerCorner>
        		<gml:upperCorner>524494.843000 666751.439000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524494.843000 666751.439000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 015 526</ms:GML_ID>
        <ms:NAZWA>029 015 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029015526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524592.656000 685705.299000</gml:lowerCorner>
        		<gml:upperCorner>524592.656000 685705.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524592.656000 685705.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 062 765</ms:GML_ID>
        <ms:NAZWA>006 062 765</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006062765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526273.962000 688027.783000</gml:lowerCorner>
        		<gml:upperCorner>526273.962000 688027.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526273.962000 688027.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 065 633</ms:GML_ID>
        <ms:NAZWA>006 065 633</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006065633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526841.363000 666541.507000</gml:lowerCorner>
        		<gml:upperCorner>526841.363000 666541.507000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526841.363000 666541.507000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 017 949</ms:GML_ID>
        <ms:NAZWA>029 017 949</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029017949</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527521.450000 665807.800000</gml:lowerCorner>
        		<gml:upperCorner>527521.450000 665807.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527521.450000 665807.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 018 951</ms:GML_ID>
        <ms:NAZWA>029 018 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029018951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528586.784000 665572.714000</gml:lowerCorner>
        		<gml:upperCorner>528586.784000 665572.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528586.784000 665572.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 020 122</ms:GML_ID>
        <ms:NAZWA>029 020 122</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029020122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529678.423000 692675.860000</gml:lowerCorner>
        		<gml:upperCorner>529678.423000 692675.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529678.423000 692675.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 071 397</ms:GML_ID>
        <ms:NAZWA>006 071 397</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006071397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530506.855879 693561.784838</gml:lowerCorner>
        		<gml:upperCorner>530506.855879 693561.784838</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530506.855879 693561.784838</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 072 611</ms:GML_ID>
        <ms:NAZWA>006 072 611</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006072611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531181.218000 665945.166000</gml:lowerCorner>
        		<gml:upperCorner>531181.218000 665945.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531181.218000 665945.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 022 741</ms:GML_ID>
        <ms:NAZWA>029 022 741</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029022741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531603.345000 694732.482000</gml:lowerCorner>
        		<gml:upperCorner>531603.345000 694732.482000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531603.345000 694732.482000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 074 215</ms:GML_ID>
        <ms:NAZWA>006 074 215</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006074215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536726.074949 700193.612189</gml:lowerCorner>
        		<gml:upperCorner>536726.074949 700193.612189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536726.074949 700193.612189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 081 703</ms:GML_ID>
        <ms:NAZWA>006 081 703</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006081703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540722.991852 705037.433809</gml:lowerCorner>
        		<gml:upperCorner>540722.991852 705037.433809</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540722.991852 705037.433809</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.034 053 939</ms:GML_ID>
        <ms:NAZWA>034 053 939</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>034053939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510316.530787 768447.438241</gml:lowerCorner>
        		<gml:upperCorner>510316.530787 768447.438241</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510316.530787 768447.438241</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 057 280</ms:GML_ID>
        <ms:NAZWA>031 057 280</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031057280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510948.447000 768784.139000</gml:lowerCorner>
        		<gml:upperCorner>510948.447000 768784.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510948.447000 768784.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 057 997</ms:GML_ID>
        <ms:NAZWA>031 057 997</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031057997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512439.491000 769604.036000</gml:lowerCorner>
        		<gml:upperCorner>512439.491000 769604.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512439.491000 769604.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 059 699</ms:GML_ID>
        <ms:NAZWA>031 059 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031059699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513567.144000 770533.125000</gml:lowerCorner>
        		<gml:upperCorner>513567.144000 770533.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513567.144000 770533.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 061 168</ms:GML_ID>
        <ms:NAZWA>031 061 168</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031061168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514305.926000 771302.839000</gml:lowerCorner>
        		<gml:upperCorner>514305.926000 771302.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514305.926000 771302.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 062 232</ms:GML_ID>
        <ms:NAZWA>031 062 232</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031062232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514551.397000 771722.252000</gml:lowerCorner>
        		<gml:upperCorner>514551.397000 771722.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514551.397000 771722.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 062 726</ms:GML_ID>
        <ms:NAZWA>031 062 726</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031062726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515001.920076 772331.228392</gml:lowerCorner>
        		<gml:upperCorner>515001.920076 772331.228392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515001.920076 772331.228392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 063 493</ms:GML_ID>
        <ms:NAZWA>031 063 493</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031063493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515406.570000 772420.605000</gml:lowerCorner>
        		<gml:upperCorner>515406.570000 772420.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515406.570000 772420.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 063 909</ms:GML_ID>
        <ms:NAZWA>031 063 909</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031063909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516177.541764 772876.539863</gml:lowerCorner>
        		<gml:upperCorner>516177.541764 772876.539863</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516177.541764 772876.539863</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 064 856</ms:GML_ID>
        <ms:NAZWA>031 064 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031064856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516693.608210 773489.626362</gml:lowerCorner>
        		<gml:upperCorner>516693.608210 773489.626362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516693.608210 773489.626362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 065 672</ms:GML_ID>
        <ms:NAZWA>031 065 672</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031065672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518028.664000 775013.587000</gml:lowerCorner>
        		<gml:upperCorner>518028.664000 775013.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518028.664000 775013.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 067 738</ms:GML_ID>
        <ms:NAZWA>031 067 738</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031067738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518161.160000 775627.877000</gml:lowerCorner>
        		<gml:upperCorner>518161.160000 775627.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518161.160000 775627.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 068 376</ms:GML_ID>
        <ms:NAZWA>031 068 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031068376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518186.277544 776755.953343</gml:lowerCorner>
        		<gml:upperCorner>518186.277544 776755.953343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518186.277544 776755.953343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 069 506</ms:GML_ID>
        <ms:NAZWA>031 069 506</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031069506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518457.981000 778014.646000</gml:lowerCorner>
        		<gml:upperCorner>518457.981000 778014.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518457.981000 778014.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 070 794</ms:GML_ID>
        <ms:NAZWA>031 070 794</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031070794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519546.175780 781471.533656</gml:lowerCorner>
        		<gml:upperCorner>519546.175780 781471.533656</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519546.175780 781471.533656</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 074 424</ms:GML_ID>
        <ms:NAZWA>031 074 424</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031074424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519803.019000 782312.858000</gml:lowerCorner>
        		<gml:upperCorner>519803.019000 782312.858000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519803.019000 782312.858000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 075 306</ms:GML_ID>
        <ms:NAZWA>031 075 306</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031075306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520082.940000 783641.607000</gml:lowerCorner>
        		<gml:upperCorner>520082.940000 783641.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520082.940000 783641.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 076 663</ms:GML_ID>
        <ms:NAZWA>031 076 663</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031076663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521457.716000 786617.190000</gml:lowerCorner>
        		<gml:upperCorner>521457.716000 786617.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521457.716000 786617.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 079 950</ms:GML_ID>
        <ms:NAZWA>031 079 950</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031079950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540355.464115 787619.322538</gml:lowerCorner>
        		<gml:upperCorner>540355.464115 787619.322538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540355.464115 787619.322538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 017 400</ms:GML_ID>
        <ms:NAZWA>032 017 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032017400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539804.534000 787947.200000</gml:lowerCorner>
        		<gml:upperCorner>539804.534000 787947.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539804.534000 787947.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 016 758</ms:GML_ID>
        <ms:NAZWA>032 016 758</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032016758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537742.080000 789370.325000</gml:lowerCorner>
        		<gml:upperCorner>537742.080000 789370.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537742.080000 789370.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 014 221</ms:GML_ID>
        <ms:NAZWA>032 014 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032014221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536648.364000 789806.830000</gml:lowerCorner>
        		<gml:upperCorner>536648.364000 789806.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536648.364000 789806.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 013 041</ms:GML_ID>
        <ms:NAZWA>032 013 041</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032013041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534865.317267 790825.650050</gml:lowerCorner>
        		<gml:upperCorner>534865.317267 790825.650050</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534865.317267 790825.650050</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.032 010 982</ms:GML_ID>
        <ms:NAZWA>032 010 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>032010982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502004.533000 665651.723000</gml:lowerCorner>
        		<gml:upperCorner>502004.533000 665651.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502004.533000 665651.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 009 889</ms:GML_ID>
        <ms:NAZWA>013 009 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013009889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504302.451000 664567.368000</gml:lowerCorner>
        		<gml:upperCorner>504302.451000 664567.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504302.451000 664567.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 007 343</ms:GML_ID>
        <ms:NAZWA>013 007 343</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013007343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505429.069993 659367.191504</gml:lowerCorner>
        		<gml:upperCorner>505429.069993 659367.191504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505429.069993 659367.191504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 030 186</ms:GML_ID>
        <ms:NAZWA>006 030 186</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006030186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505935.746098 660042.820100</gml:lowerCorner>
        		<gml:upperCorner>505935.746098 660042.820100</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505935.746098 660042.820100</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 031 031</ms:GML_ID>
        <ms:NAZWA>006 031 031</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006031031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506479.177000 663691.085000</gml:lowerCorner>
        		<gml:upperCorner>506479.177000 663691.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506479.177000 663691.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 004 997</ms:GML_ID>
        <ms:NAZWA>013 004 997</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013004997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507094.250000 663443.336000</gml:lowerCorner>
        		<gml:upperCorner>507094.250000 663443.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507094.250000 663443.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 004 323</ms:GML_ID>
        <ms:NAZWA>013 004 323</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013004323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507809.859000 663078.438000</gml:lowerCorner>
        		<gml:upperCorner>507809.859000 663078.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507809.859000 663078.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 003 528</ms:GML_ID>
        <ms:NAZWA>013 003 528</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013003528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507865.436000 662619.103000</gml:lowerCorner>
        		<gml:upperCorner>507865.436000 662619.103000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507865.436000 662619.103000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 034 250</ms:GML_ID>
        <ms:NAZWA>006 034 250</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006034250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508203.431210 663070.663409</gml:lowerCorner>
        		<gml:upperCorner>508203.431210 663070.663409</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508203.431210 663070.663409</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 034 815</ms:GML_ID>
        <ms:NAZWA>006 034 815</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006034815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508644.920234 662671.385799</gml:lowerCorner>
        		<gml:upperCorner>508644.920234 662671.385799</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508644.920234 662671.385799</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.513 000 460</ms:GML_ID>
        <ms:NAZWA>513 000 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>513000460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508646.304000 662451.427000</gml:lowerCorner>
        		<gml:upperCorner>508646.304000 662451.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508646.304000 662451.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 002 481</ms:GML_ID>
        <ms:NAZWA>013 002 481</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013002481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509055.287000 664208.020000</gml:lowerCorner>
        		<gml:upperCorner>509055.287000 664208.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509055.287000 664208.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 036 237</ms:GML_ID>
        <ms:NAZWA>006 036 237</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006036237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509418.788000 660161.178000</gml:lowerCorner>
        		<gml:upperCorner>509418.788000 660161.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509418.788000 660161.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 030 894</ms:GML_ID>
        <ms:NAZWA>010 030 894</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010030894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509441.661886 662636.748839</gml:lowerCorner>
        		<gml:upperCorner>509441.661886 662636.748839</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509441.661886 662636.748839</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 033 358</ms:GML_ID>
        <ms:NAZWA>010 033 358</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010033358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509491.215396 663918.867950</gml:lowerCorner>
        		<gml:upperCorner>509491.215396 663918.867950</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509491.215396 663918.867950</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.010 034 658</ms:GML_ID>
        <ms:NAZWA>010 034 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>010034658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510951.322297 666807.555929</gml:lowerCorner>
        		<gml:upperCorner>510951.322297 666807.555929</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510951.322297 666807.555929</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 039 454</ms:GML_ID>
        <ms:NAZWA>006 039 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006039454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511907.298999 668132.969136</gml:lowerCorner>
        		<gml:upperCorner>511907.298999 668132.969136</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511907.298999 668132.969136</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.006 041 089</ms:GML_ID>
        <ms:NAZWA>006 041 089</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>006041089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512400.497000 666317.993000</gml:lowerCorner>
        		<gml:upperCorner>512400.497000 666317.993000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512400.497000 666317.993000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.029 002 797</ms:GML_ID>
        <ms:NAZWA>029 002 797</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>029002797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486750.843000 660476.698000</gml:lowerCorner>
        		<gml:upperCorner>486750.843000 660476.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486750.843000 660476.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 025 661</ms:GML_ID>
        <ms:NAZWA>002 025 661</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002025661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487146.749000 671338.343000</gml:lowerCorner>
        		<gml:upperCorner>487146.749000 671338.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487146.749000 671338.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 025 900</ms:GML_ID>
        <ms:NAZWA>013 025 900</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013025900</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488328.500000 670983.510000</gml:lowerCorner>
        		<gml:upperCorner>488328.500000 670983.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488328.500000 670983.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 024 620</ms:GML_ID>
        <ms:NAZWA>013 024 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013024620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489379.343000 670667.113000</gml:lowerCorner>
        		<gml:upperCorner>489379.343000 670667.113000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489379.343000 670667.113000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 023 530</ms:GML_ID>
        <ms:NAZWA>013 023 530</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013023530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489708.152000 670568.180000</gml:lowerCorner>
        		<gml:upperCorner>489708.152000 670568.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489708.152000 670568.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 023 190</ms:GML_ID>
        <ms:NAZWA>013 023 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013023190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490441.824000 670347.644000</gml:lowerCorner>
        		<gml:upperCorner>490441.824000 670347.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490441.824000 670347.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 022 420</ms:GML_ID>
        <ms:NAZWA>013 022 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013022420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491655.904000 669982.543000</gml:lowerCorner>
        		<gml:upperCorner>491655.904000 669982.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491655.904000 669982.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 021 150</ms:GML_ID>
        <ms:NAZWA>013 021 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013021150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492572.531000 669706.703000</gml:lowerCorner>
        		<gml:upperCorner>492572.531000 669706.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492572.531000 669706.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 020 190</ms:GML_ID>
        <ms:NAZWA>013 020 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013020190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492832.810000 669628.427000</gml:lowerCorner>
        		<gml:upperCorner>492832.810000 669628.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492832.810000 669628.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 019 921</ms:GML_ID>
        <ms:NAZWA>013 019 921</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013019921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494435.336000 669146.462000</gml:lowerCorner>
        		<gml:upperCorner>494435.336000 669146.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494435.336000 669146.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 018 250</ms:GML_ID>
        <ms:NAZWA>013 018 250</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013018250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496223.294000 668461.502000</gml:lowerCorner>
        		<gml:upperCorner>496223.294000 668461.502000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496223.294000 668461.502000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 016 350</ms:GML_ID>
        <ms:NAZWA>013 016 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013016350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497083.101000 668109.036000</gml:lowerCorner>
        		<gml:upperCorner>497083.101000 668109.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497083.101000 668109.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 015 400</ms:GML_ID>
        <ms:NAZWA>013 015 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013015400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497782.836000 667821.983000</gml:lowerCorner>
        		<gml:upperCorner>497782.836000 667821.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497782.836000 667821.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 014 650</ms:GML_ID>
        <ms:NAZWA>013 014 650</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013014650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498472.801000 667538.777000</gml:lowerCorner>
        		<gml:upperCorner>498472.801000 667538.777000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498472.801000 667538.777000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 013 892</ms:GML_ID>
        <ms:NAZWA>013 013 892</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013013892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499440.604000 667066.044000</gml:lowerCorner>
        		<gml:upperCorner>499440.604000 667066.044000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499440.604000 667066.044000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 012 820</ms:GML_ID>
        <ms:NAZWA>013 012 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013012820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499805.903000 666864.675000</gml:lowerCorner>
        		<gml:upperCorner>499805.903000 666864.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499805.903000 666864.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 012 400</ms:GML_ID>
        <ms:NAZWA>013 012 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013012400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500991.724000 666210.618000</gml:lowerCorner>
        		<gml:upperCorner>500991.724000 666210.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500991.724000 666210.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 011 050</ms:GML_ID>
        <ms:NAZWA>013 011 050</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013011050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482315.389000 704192.685000</gml:lowerCorner>
        		<gml:upperCorner>482315.389000 704192.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482315.389000 704192.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 072 120</ms:GML_ID>
        <ms:NAZWA>002 072 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002072120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482938.263000 700994.802000</gml:lowerCorner>
        		<gml:upperCorner>482938.263000 700994.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482938.263000 700994.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 068 759</ms:GML_ID>
        <ms:NAZWA>002 068 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002068759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482951.014000 708655.019000</gml:lowerCorner>
        		<gml:upperCorner>482951.014000 708655.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482951.014000 708655.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 076 824</ms:GML_ID>
        <ms:NAZWA>002 076 824</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002076824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483335.608000 722144.725000</gml:lowerCorner>
        		<gml:upperCorner>483335.608000 722144.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483335.608000 722144.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 090 862</ms:GML_ID>
        <ms:NAZWA>002 090 862</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002090862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483364.658000 714886.168000</gml:lowerCorner>
        		<gml:upperCorner>483364.658000 714886.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483364.658000 714886.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 083 295</ms:GML_ID>
        <ms:NAZWA>002 083 295</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002083295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483980.157000 718819.083000</gml:lowerCorner>
        		<gml:upperCorner>483980.157000 718819.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483980.157000 718819.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 087 454</ms:GML_ID>
        <ms:NAZWA>002 087 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002087454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484114.383000 722398.951000</gml:lowerCorner>
        		<gml:upperCorner>484114.383000 722398.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484114.383000 722398.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 117 745</ms:GML_ID>
        <ms:NAZWA>055 117 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055117745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486031.996114 723022.756843</gml:lowerCorner>
        		<gml:upperCorner>486031.996114 723022.756843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486031.996114 723022.756843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 115 725</ms:GML_ID>
        <ms:NAZWA>055 115 725</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055115725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492344.473000 723203.719000</gml:lowerCorner>
        		<gml:upperCorner>492344.473000 723203.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492344.473000 723203.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 109 143</ms:GML_ID>
        <ms:NAZWA>055 109 143</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055109143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493049.606666 722823.003808</gml:lowerCorner>
        		<gml:upperCorner>493049.606666 722823.003808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493049.606666 722823.003808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 108 340</ms:GML_ID>
        <ms:NAZWA>055 108 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055108340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493810.151484 722628.083564</gml:lowerCorner>
        		<gml:upperCorner>493810.151484 722628.083564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493810.151484 722628.083564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 107 555</ms:GML_ID>
        <ms:NAZWA>055 107 555</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055107555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494495.808919 722455.452018</gml:lowerCorner>
        		<gml:upperCorner>494495.808919 722455.452018</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494495.808919 722455.452018</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 106 850</ms:GML_ID>
        <ms:NAZWA>055 106 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055106850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495785.324998 722125.776127</gml:lowerCorner>
        		<gml:upperCorner>495785.324998 722125.776127</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495785.324998 722125.776127</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 105 517</ms:GML_ID>
        <ms:NAZWA>055 105 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055105517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497013.645676 721820.183477</gml:lowerCorner>
        		<gml:upperCorner>497013.645676 721820.183477</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497013.645676 721820.183477</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 104 252</ms:GML_ID>
        <ms:NAZWA>055 104 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055104252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499868.793830 721039.351373</gml:lowerCorner>
        		<gml:upperCorner>499868.793830 721039.351373</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499868.793830 721039.351373</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 101 289</ms:GML_ID>
        <ms:NAZWA>055 101 289</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055101289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500830.978189 720680.177562</gml:lowerCorner>
        		<gml:upperCorner>500830.978189 720680.177562</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500830.978189 720680.177562</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 100 262</ms:GML_ID>
        <ms:NAZWA>055 100 262</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055100262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501672.184315 720171.148755</gml:lowerCorner>
        		<gml:upperCorner>501672.184315 720171.148755</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501672.184315 720171.148755</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 099 278</ms:GML_ID>
        <ms:NAZWA>055 099 278</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055099278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502397.021511 719889.830554</gml:lowerCorner>
        		<gml:upperCorner>502397.021511 719889.830554</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502397.021511 719889.830554</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 098 499</ms:GML_ID>
        <ms:NAZWA>055 098 499</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055098499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503226.180682 719591.368639</gml:lowerCorner>
        		<gml:upperCorner>503226.180682 719591.368639</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503226.180682 719591.368639</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 097 620</ms:GML_ID>
        <ms:NAZWA>055 097 620</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055097620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503626.459000 719446.882000</gml:lowerCorner>
        		<gml:upperCorner>503626.459000 719446.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503626.459000 719446.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 097 194</ms:GML_ID>
        <ms:NAZWA>055 097 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055097194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504726.607000 719050.482000</gml:lowerCorner>
        		<gml:upperCorner>504726.607000 719050.482000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504726.607000 719050.482000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 096 025</ms:GML_ID>
        <ms:NAZWA>055 096 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055096025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505812.932000 718881.139000</gml:lowerCorner>
        		<gml:upperCorner>505812.932000 718881.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505812.932000 718881.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 094 907</ms:GML_ID>
        <ms:NAZWA>055 094 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055094907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507296.281000 719050.396000</gml:lowerCorner>
        		<gml:upperCorner>507296.281000 719050.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507296.281000 719050.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 093 412</ms:GML_ID>
        <ms:NAZWA>055 093 412</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055093412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508186.184000 719163.989000</gml:lowerCorner>
        		<gml:upperCorner>508186.184000 719163.989000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508186.184000 719163.989000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 092 515</ms:GML_ID>
        <ms:NAZWA>055 092 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055092515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509483.209139 719354.190763</gml:lowerCorner>
        		<gml:upperCorner>509483.209139 719354.190763</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509483.209139 719354.190763</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 091 204</ms:GML_ID>
        <ms:NAZWA>055 091 204</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055091204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509780.432165 719363.651113</gml:lowerCorner>
        		<gml:upperCorner>509780.432165 719363.651113</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509780.432165 719363.651113</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 090 962</ms:GML_ID>
        <ms:NAZWA>055 090 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055090962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510077.538067 719415.628272</gml:lowerCorner>
        		<gml:upperCorner>510077.538067 719415.628272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510077.538067 719415.628272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 090 613</ms:GML_ID>
        <ms:NAZWA>055 090 613</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055090613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480146.150290 726724.431730</gml:lowerCorner>
        		<gml:upperCorner>480146.150290 726724.431730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480146.150290 726724.431730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 003 953</ms:GML_ID>
        <ms:NAZWA>031 003 953</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031003953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480482.553000 725570.811000</gml:lowerCorner>
        		<gml:upperCorner>480482.553000 725570.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480482.553000 725570.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 095 418</ms:GML_ID>
        <ms:NAZWA>002 095 418</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002095418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480769.157000 728207.154000</gml:lowerCorner>
        		<gml:upperCorner>480769.157000 728207.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480769.157000 728207.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 005 594</ms:GML_ID>
        <ms:NAZWA>031 005 594</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031005594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481301.516000 729136.836000</gml:lowerCorner>
        		<gml:upperCorner>481301.516000 729136.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481301.516000 729136.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 006 665</ms:GML_ID>
        <ms:NAZWA>031 006 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031006665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481869.230000 730127.759000</gml:lowerCorner>
        		<gml:upperCorner>481869.230000 730127.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481869.230000 730127.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 007 808</ms:GML_ID>
        <ms:NAZWA>031 007 808</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031007808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482858.154000 731855.643000</gml:lowerCorner>
        		<gml:upperCorner>482858.154000 731855.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482858.154000 731855.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 009 799</ms:GML_ID>
        <ms:NAZWA>031 009 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031009799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483601.892000 733156.921000</gml:lowerCorner>
        		<gml:upperCorner>483601.892000 733156.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483601.892000 733156.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 011 298</ms:GML_ID>
        <ms:NAZWA>031 011 298</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031011298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484671.876000 735057.205000</gml:lowerCorner>
        		<gml:upperCorner>484671.876000 735057.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484671.876000 735057.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 013 478</ms:GML_ID>
        <ms:NAZWA>031 013 478</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031013478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485828.657000 737084.451000</gml:lowerCorner>
        		<gml:upperCorner>485828.657000 737084.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485828.657000 737084.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 015 814</ms:GML_ID>
        <ms:NAZWA>031 015 814</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031015814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486872.350000 723284.673000</gml:lowerCorner>
        		<gml:upperCorner>486872.350000 723284.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486872.350000 723284.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 114 846</ms:GML_ID>
        <ms:NAZWA>055 114 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055114846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487204.996000 739540.673000</gml:lowerCorner>
        		<gml:upperCorner>487204.996000 739540.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487204.996000 739540.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 018 629</ms:GML_ID>
        <ms:NAZWA>031 018 629</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031018629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487622.996000 740286.650000</gml:lowerCorner>
        		<gml:upperCorner>487622.996000 740286.650000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487622.996000 740286.650000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 019 486</ms:GML_ID>
        <ms:NAZWA>031 019 486</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031019486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488082.528000 723648.384000</gml:lowerCorner>
        		<gml:upperCorner>488082.528000 723648.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488082.528000 723648.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 113 586</ms:GML_ID>
        <ms:NAZWA>055 113 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055113586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488774.886000 742325.400000</gml:lowerCorner>
        		<gml:upperCorner>488774.886000 742325.400000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488774.886000 742325.400000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 021 826</ms:GML_ID>
        <ms:NAZWA>031 021 826</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031021826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489130.197000 742951.708000</gml:lowerCorner>
        		<gml:upperCorner>489130.197000 742951.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489130.197000 742951.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 022 547</ms:GML_ID>
        <ms:NAZWA>031 022 547</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031022547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489908.420000 724023.166000</gml:lowerCorner>
        		<gml:upperCorner>489908.420000 724023.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489908.420000 724023.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.055 111 719</ms:GML_ID>
        <ms:NAZWA>055 111 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>055111719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490010.586000 744505.506000</gml:lowerCorner>
        		<gml:upperCorner>490010.586000 744505.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490010.586000 744505.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 024 332</ms:GML_ID>
        <ms:NAZWA>031 024 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031024332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490530.758000 745423.401000</gml:lowerCorner>
        		<gml:upperCorner>490530.758000 745423.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490530.758000 745423.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 025 388</ms:GML_ID>
        <ms:NAZWA>031 025 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031025388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491213.980000 746627.801000</gml:lowerCorner>
        		<gml:upperCorner>491213.980000 746627.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491213.980000 746627.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 026 773</ms:GML_ID>
        <ms:NAZWA>031 026 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031026773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493821.870397 751224.684835</gml:lowerCorner>
        		<gml:upperCorner>493821.870397 751224.684835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493821.870397 751224.684835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 032 056</ms:GML_ID>
        <ms:NAZWA>031 032 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031032056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494460.946077 752405.587428</gml:lowerCorner>
        		<gml:upperCorner>494460.946077 752405.587428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494460.946077 752405.587428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 033 401</ms:GML_ID>
        <ms:NAZWA>031 033 401</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031033401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494986.257000 753387.610000</gml:lowerCorner>
        		<gml:upperCorner>494986.257000 753387.610000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494986.257000 753387.610000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 034 512</ms:GML_ID>
        <ms:NAZWA>031 034 512</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031034512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>495647.681000 754850.016000</gml:lowerCorner>
        		<gml:upperCorner>495647.681000 754850.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>495647.681000 754850.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 036 118</ms:GML_ID>
        <ms:NAZWA>031 036 118</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031036118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496035.251000 755450.540000</gml:lowerCorner>
        		<gml:upperCorner>496035.251000 755450.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496035.251000 755450.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 036 838</ms:GML_ID>
        <ms:NAZWA>031 036 838</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031036838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497410.465000 757410.650000</gml:lowerCorner>
        		<gml:upperCorner>497410.465000 757410.650000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497410.465000 757410.650000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 039 462</ms:GML_ID>
        <ms:NAZWA>031 039 462</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031039462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498873.536000 758708.352000</gml:lowerCorner>
        		<gml:upperCorner>498873.536000 758708.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498873.536000 758708.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 041 482</ms:GML_ID>
        <ms:NAZWA>031 041 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031041482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499256.702000 759418.983000</gml:lowerCorner>
        		<gml:upperCorner>499256.702000 759418.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499256.702000 759418.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 042 287</ms:GML_ID>
        <ms:NAZWA>031 042 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031042287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499849.547057 760871.354986</gml:lowerCorner>
        		<gml:upperCorner>499849.547057 760871.354986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499849.547057 760871.354986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 043 858</ms:GML_ID>
        <ms:NAZWA>031 043 858</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031043858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500798.531000 761891.972000</gml:lowerCorner>
        		<gml:upperCorner>500798.531000 761891.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500798.531000 761891.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 045 257</ms:GML_ID>
        <ms:NAZWA>031 045 257</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031045257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501431.044000 762630.505000</gml:lowerCorner>
        		<gml:upperCorner>501431.044000 762630.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501431.044000 762630.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 046 229</ms:GML_ID>
        <ms:NAZWA>031 046 229</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031046229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501956.927000 763405.131000</gml:lowerCorner>
        		<gml:upperCorner>501956.927000 763405.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501956.927000 763405.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 047 166</ms:GML_ID>
        <ms:NAZWA>031 047 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031047166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502499.433000 764204.891000</gml:lowerCorner>
        		<gml:upperCorner>502499.433000 764204.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502499.433000 764204.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 048 134</ms:GML_ID>
        <ms:NAZWA>031 048 134</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031048134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502841.482000 764709.056000</gml:lowerCorner>
        		<gml:upperCorner>502841.482000 764709.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502841.482000 764709.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 048 740</ms:GML_ID>
        <ms:NAZWA>031 048 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031048740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8941">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468463.187000 804744.315000</gml:lowerCorner>
        		<gml:upperCorner>468463.187000 804744.315000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8941.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468463.187000 804744.315000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8941</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 194 710</ms:GML_ID>
        <ms:NAZWA>002 194 710</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002194710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8942">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469268.950810 806209.694813</gml:lowerCorner>
        		<gml:upperCorner>469268.950810 806209.694813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8942.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469268.950810 806209.694813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8942</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 196 391</ms:GML_ID>
        <ms:NAZWA>002 196 391</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002196391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469840.027002 807138.155379</gml:lowerCorner>
        		<gml:upperCorner>469840.027002 807138.155379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469840.027002 807138.155379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 197 481</ms:GML_ID>
        <ms:NAZWA>002 197 481</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002197481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8943">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471945.923208 810654.493550</gml:lowerCorner>
        		<gml:upperCorner>471945.923208 810654.493550</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8943.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471945.923208 810654.493550</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8943</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 201 558</ms:GML_ID>
        <ms:NAZWA>002 201 558</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002201558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8944">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473274.167440 812528.711441</gml:lowerCorner>
        		<gml:upperCorner>473274.167440 812528.711441</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8944.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473274.167440 812528.711441</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8944</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 203 902</ms:GML_ID>
        <ms:NAZWA>002 203 902</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002203902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8945">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476322.183280 814975.727313</gml:lowerCorner>
        		<gml:upperCorner>476322.183280 814975.727313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8945.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476322.183280 814975.727313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8945</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 208 062</ms:GML_ID>
        <ms:NAZWA>002 208 062</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002208062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8946">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477014.901075 815070.486920</gml:lowerCorner>
        		<gml:upperCorner>477014.901075 815070.486920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8946.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477014.901075 815070.486920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8946</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 208 789</ms:GML_ID>
        <ms:NAZWA>002 208 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002208789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478729.790566 815711.070716</gml:lowerCorner>
        		<gml:upperCorner>478729.790566 815711.070716</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478729.790566 815711.070716</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.446 210 600</ms:GML_ID>
        <ms:NAZWA>446 210 600</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>446210600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8947">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478539.580000 815881.006000</gml:lowerCorner>
        		<gml:upperCorner>478539.580000 815881.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8947.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478539.580000 815881.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8947</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 210 558</ms:GML_ID>
        <ms:NAZWA>002 210 558</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002210558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504975.195000 766177.078000</gml:lowerCorner>
        		<gml:upperCorner>504975.195000 766177.078000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504975.195000 766177.078000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 051 364</ms:GML_ID>
        <ms:NAZWA>031 051 364</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031051364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506240.714000 767148.266000</gml:lowerCorner>
        		<gml:upperCorner>506240.714000 767148.266000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506240.714000 767148.266000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 052 960</ms:GML_ID>
        <ms:NAZWA>031 052 960</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031052960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506700.008000 767427.791000</gml:lowerCorner>
        		<gml:upperCorner>506700.008000 767427.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506700.008000 767427.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 053 498</ms:GML_ID>
        <ms:NAZWA>031 053 498</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031053498</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509033.409000 767936.339000</gml:lowerCorner>
        		<gml:upperCorner>509033.409000 767936.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509033.409000 767936.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.031 055 887</ms:GML_ID>
        <ms:NAZWA>031 055 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>031055887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8929">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466434.056000 771406.431000</gml:lowerCorner>
        		<gml:upperCorner>466434.056000 771406.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8929.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466434.056000 771406.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8929</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 160 556</ms:GML_ID>
        <ms:NAZWA>002 160 556</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002160556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8930">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467637.580248 775811.880433</gml:lowerCorner>
        		<gml:upperCorner>467637.580248 775811.880433</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8930.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467637.580248 775811.880433</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8930</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 165 123</ms:GML_ID>
        <ms:NAZWA>002 165 123</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002165123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8932">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469552.882766 782862.720853</gml:lowerCorner>
        		<gml:upperCorner>469552.882766 782862.720853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8932.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469552.882766 782862.720853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8932</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 172 425</ms:GML_ID>
        <ms:NAZWA>002 172 425</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002172425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8934">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468376.677000 789330.050000</gml:lowerCorner>
        		<gml:upperCorner>468376.677000 789330.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8934.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468376.677000 789330.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8934</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 179 154</ms:GML_ID>
        <ms:NAZWA>002 179 154</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002179154</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8936">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467744.219000 792177.432000</gml:lowerCorner>
        		<gml:upperCorner>467744.219000 792177.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8936.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467744.219000 792177.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8936</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 182 090</ms:GML_ID>
        <ms:NAZWA>002 182 090</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002182090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8937">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467579.292000 793681.844000</gml:lowerCorner>
        		<gml:upperCorner>467579.292000 793681.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8937.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467579.292000 793681.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8937</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 183 604</ms:GML_ID>
        <ms:NAZWA>002 183 604</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002183604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8938">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467599.395000 795448.905000</gml:lowerCorner>
        		<gml:upperCorner>467599.395000 795448.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8938.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467599.395000 795448.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8938</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 185 377</ms:GML_ID>
        <ms:NAZWA>002 185 377</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002185377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8939">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467887.822662 798584.196417</gml:lowerCorner>
        		<gml:upperCorner>467887.822662 798584.196417</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8939.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467887.822662 798584.196417</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8939</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 188 524</ms:GML_ID>
        <ms:NAZWA>002 188 524</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002188524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8940">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468222.416000 802221.265000</gml:lowerCorner>
        		<gml:upperCorner>468222.416000 802221.265000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8940.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468222.416000 802221.265000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8940</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 192 176</ms:GML_ID>
        <ms:NAZWA>002 192 176</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002192176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460980.548854 659568.598517</gml:lowerCorner>
        		<gml:upperCorner>460980.548854 659568.598517</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460980.548854 659568.598517</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 082 836</ms:GML_ID>
        <ms:NAZWA>012 082 836</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012082836</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472350.850678 660374.353513</gml:lowerCorner>
        		<gml:upperCorner>472350.850678 660374.353513</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472350.850678 660374.353513</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 033 364</ms:GML_ID>
        <ms:NAZWA>007 033 364</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007033364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471301.597886 661567.948577</gml:lowerCorner>
        		<gml:upperCorner>471301.597886 661567.948577</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471301.597886 661567.948577</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 034 955</ms:GML_ID>
        <ms:NAZWA>007 034 955</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007034955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485350.807000 663269.659000</gml:lowerCorner>
        		<gml:upperCorner>485350.807000 663269.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485350.807000 663269.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 028 788</ms:GML_ID>
        <ms:NAZWA>002 028 788</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002028788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469491.711026 663291.396251</gml:lowerCorner>
        		<gml:upperCorner>469491.711026 663291.396251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469491.711026 663291.396251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 037 488</ms:GML_ID>
        <ms:NAZWA>007 037 488</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007037488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468741.997377 663722.410278</gml:lowerCorner>
        		<gml:upperCorner>468741.997377 663722.410278</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468741.997377 663722.410278</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 038 358</ms:GML_ID>
        <ms:NAZWA>007 038 358</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007038358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484219.855548 665526.918362</gml:lowerCorner>
        		<gml:upperCorner>484219.855548 665526.918362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484219.855548 665526.918362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 031 315</ms:GML_ID>
        <ms:NAZWA>002 031 315</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002031315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483618.144000 666727.427000</gml:lowerCorner>
        		<gml:upperCorner>483618.144000 666727.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483618.144000 666727.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 032 658</ms:GML_ID>
        <ms:NAZWA>002 032 658</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002032658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466538.180566 667027.421274</gml:lowerCorner>
        		<gml:upperCorner>466538.180566 667027.421274</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466538.180566 667027.421274</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 042 383</ms:GML_ID>
        <ms:NAZWA>007 042 383</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007042383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465728.129687 667844.106603</gml:lowerCorner>
        		<gml:upperCorner>465728.129687 667844.106603</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465728.129687 667844.106603</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 043 559</ms:GML_ID>
        <ms:NAZWA>007 043 559</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007043559</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463644.380534 669497.521009</gml:lowerCorner>
        		<gml:upperCorner>463644.380534 669497.521009</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463644.380534 669497.521009</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 046 239</ms:GML_ID>
        <ms:NAZWA>007 046 239</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007046239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463013.775559 670312.260557</gml:lowerCorner>
        		<gml:upperCorner>463013.775559 670312.260557</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463013.775559 670312.260557</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 047 268</ms:GML_ID>
        <ms:NAZWA>007 047 268</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007047268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466313.046536 672092.729851</gml:lowerCorner>
        		<gml:upperCorner>466313.046536 672092.729851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466313.046536 672092.729851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 047 823</ms:GML_ID>
        <ms:NAZWA>013 047 823</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013047823</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470105.156000 672143.328000</gml:lowerCorner>
        		<gml:upperCorner>470105.156000 672143.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470105.156000 672143.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 043 933</ms:GML_ID>
        <ms:NAZWA>013 043 933</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013043933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460849.652000 672558.536000</gml:lowerCorner>
        		<gml:upperCorner>460849.652000 672558.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460849.652000 672558.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.007 050 451</ms:GML_ID>
        <ms:NAZWA>007 050 451</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>007050451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463927.467000 672744.805000</gml:lowerCorner>
        		<gml:upperCorner>463927.467000 672744.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463927.467000 672744.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 050 330</ms:GML_ID>
        <ms:NAZWA>013 050 330</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013050330</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473185.713000 673128.925000</gml:lowerCorner>
        		<gml:upperCorner>473185.713000 673128.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473185.713000 673128.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 040 703</ms:GML_ID>
        <ms:NAZWA>013 040 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013040703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460586.036000 673206.423000</gml:lowerCorner>
        		<gml:upperCorner>460586.036000 673206.423000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460586.036000 673206.423000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 053 706</ms:GML_ID>
        <ms:NAZWA>013 053 706</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013053706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474947.989787 673373.836350</gml:lowerCorner>
        		<gml:upperCorner>474947.989787 673373.836350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474947.989787 673373.836350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 038 922</ms:GML_ID>
        <ms:NAZWA>013 038 922</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013038922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484130.616000 673457.546000</gml:lowerCorner>
        		<gml:upperCorner>484130.616000 673457.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484130.616000 673457.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.013 029 570</ms:GML_ID>
        <ms:NAZWA>013 029 570</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>013029570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481926.901000 673564.350000</gml:lowerCorner>
        		<gml:upperCorner>481926.901000 673564.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481926.901000 673564.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.522 000 780</ms:GML_ID>
        <ms:NAZWA>522 000 780</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>522000780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479255.105000 685537.693000</gml:lowerCorner>
        		<gml:upperCorner>479255.105000 685537.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479255.105000 685537.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 052 158</ms:GML_ID>
        <ms:NAZWA>002 052 158</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002052158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458569.833926 686299.917620</gml:lowerCorner>
        		<gml:upperCorner>458569.833926 686299.917620</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458569.833926 686299.917620</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 112 912</ms:GML_ID>
        <ms:NAZWA>012 112 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012112912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479346.761000 687157.890000</gml:lowerCorner>
        		<gml:upperCorner>479346.761000 687157.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479346.761000 687157.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 053 784</ms:GML_ID>
        <ms:NAZWA>002 053 784</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002053784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8917">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457809.550000 737885.885000</gml:lowerCorner>
        		<gml:upperCorner>457809.550000 737885.885000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8917.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457809.550000 737885.885000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8917</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 125 824</ms:GML_ID>
        <ms:NAZWA>002 125 824</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002125824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457949.342000 726721.512000</gml:lowerCorner>
        		<gml:upperCorner>457949.342000 726721.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457949.342000 726721.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 153 813</ms:GML_ID>
        <ms:NAZWA>012 153 813</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012153813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458003.195855 731298.112812</gml:lowerCorner>
        		<gml:upperCorner>458003.195855 731298.112812</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458003.195855 731298.112812</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.026 002 013</ms:GML_ID>
        <ms:NAZWA>026 002 013</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>026002013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458107.633000 728099.256000</gml:lowerCorner>
        		<gml:upperCorner>458107.633000 728099.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458107.633000 728099.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 155 195</ms:GML_ID>
        <ms:NAZWA>012 155 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012155195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8918">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458401.460699 740068.381059</gml:lowerCorner>
        		<gml:upperCorner>458401.460699 740068.381059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8918.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458401.460699 740068.381059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8918</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.002 128 087</ms:GML_ID>
        <ms:NAZWA>002 128 087</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>002128087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458432.453730 730598.807623</gml:lowerCorner>
        		<gml:upperCorner>458432.453730 730598.807623</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458432.453730 730598.807623</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.012 157 714</ms:GML_ID>
        <ms:NAZWA>012 157 714</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>012157714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

