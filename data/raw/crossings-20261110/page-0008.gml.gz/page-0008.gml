<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:27" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=7000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=9000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>345489.536000 317790.234000</gml:lowerCorner>
      		<gml:upperCorner>594821.932000 482201.992000</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570722.861000 476488.904000</gml:lowerCorner>
        		<gml:upperCorner>570722.861000 476488.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570722.861000 476488.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 106 548</ms:GML_ID>
        <ms:NAZWA>018 106 548</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018106548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570883.559000 474701.256000</gml:lowerCorner>
        		<gml:upperCorner>570883.559000 474701.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570883.559000 474701.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 136 080</ms:GML_ID>
        <ms:NAZWA>353 136 080</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353136080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570958.851337 475331.116666</gml:lowerCorner>
        		<gml:upperCorner>570958.851337 475331.116666</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570958.851337 475331.116666</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 107 805</ms:GML_ID>
        <ms:NAZWA>018 107 805</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018107805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571018.627000 475989.765000</gml:lowerCorner>
        		<gml:upperCorner>571018.627000 475989.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571018.627000 475989.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 107 138</ms:GML_ID>
        <ms:NAZWA>018 107 138</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018107138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573870.943000 482201.992000</gml:lowerCorner>
        		<gml:upperCorner>573870.943000 482201.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573870.943000 482201.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 157 472</ms:GML_ID>
        <ms:NAZWA>027 157 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027157472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574377.953000 472293.582000</gml:lowerCorner>
        		<gml:upperCorner>574377.953000 472293.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574377.953000 472293.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 006 188</ms:GML_ID>
        <ms:NAZWA>246 006 188</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246006188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574442.276647 471668.749237</gml:lowerCorner>
        		<gml:upperCorner>574442.276647 471668.749237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574442.276647 471668.749237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 006 829</ms:GML_ID>
        <ms:NAZWA>246 006 829</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246006829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574665.747000 473059.425000</gml:lowerCorner>
        		<gml:upperCorner>574665.747000 473059.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574665.747000 473059.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.246 005 367</ms:GML_ID>
        <ms:NAZWA>246 005 367</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>246005367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585938.884000 398001.135000</gml:lowerCorner>
        		<gml:upperCorner>585938.884000 398001.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585938.884000 398001.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 195 909</ms:GML_ID>
        <ms:NAZWA>018 195 909</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018195909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585951.831000 397468.982000</gml:lowerCorner>
        		<gml:upperCorner>585951.831000 397468.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585951.831000 397468.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 196 440</ms:GML_ID>
        <ms:NAZWA>018 196 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018196440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586020.542000 399449.718000</gml:lowerCorner>
        		<gml:upperCorner>586020.542000 399449.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586020.542000 399449.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 194 453</ms:GML_ID>
        <ms:NAZWA>018 194 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018194453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586170.672000 400670.900000</gml:lowerCorner>
        		<gml:upperCorner>586170.672000 400670.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586170.672000 400670.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 193 222</ms:GML_ID>
        <ms:NAZWA>018 193 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018193222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586289.519000 401630.350000</gml:lowerCorner>
        		<gml:upperCorner>586289.519000 401630.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586289.519000 401630.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 192 255</ms:GML_ID>
        <ms:NAZWA>018 192 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018192255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586377.729537 402344.409500</gml:lowerCorner>
        		<gml:upperCorner>586377.729537 402344.409500</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586377.729537 402344.409500</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 191 535</ms:GML_ID>
        <ms:NAZWA>018 191 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018191535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586416.314000 405408.581000</gml:lowerCorner>
        		<gml:upperCorner>586416.314000 405408.581000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586416.314000 405408.581000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 233 338</ms:GML_ID>
        <ms:NAZWA>281 233 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281233338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586522.189000 403509.018000</gml:lowerCorner>
        		<gml:upperCorner>586522.189000 403509.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586522.189000 403509.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 190 361</ms:GML_ID>
        <ms:NAZWA>018 190 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018190361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586697.408000 404914.685000</gml:lowerCorner>
        		<gml:upperCorner>586697.408000 404914.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586697.408000 404914.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 188 943</ms:GML_ID>
        <ms:NAZWA>018 188 943</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018188943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>586861.571461 405693.503905</gml:lowerCorner>
        		<gml:upperCorner>586861.571461 405693.503905</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>586861.571461 405693.503905</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 188 148</ms:GML_ID>
        <ms:NAZWA>018 188 148</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018188148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587022.239688 406191.423034</gml:lowerCorner>
        		<gml:upperCorner>587022.239688 406191.423034</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587022.239688 406191.423034</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 187 622</ms:GML_ID>
        <ms:NAZWA>018 187 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018187622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587148.127499 406514.901619</gml:lowerCorner>
        		<gml:upperCorner>587148.127499 406514.901619</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587148.127499 406514.901619</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 187 277</ms:GML_ID>
        <ms:NAZWA>018 187 277</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018187277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>588400.132000 409057.408000</gml:lowerCorner>
        		<gml:upperCorner>588400.132000 409057.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>588400.132000 409057.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 184 368</ms:GML_ID>
        <ms:NAZWA>018 184 368</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018184368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590343.135000 407514.343000</gml:lowerCorner>
        		<gml:upperCorner>590343.135000 407514.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590343.135000 407514.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 239 068</ms:GML_ID>
        <ms:NAZWA>281 239 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281239068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591077.797000 407107.199000</gml:lowerCorner>
        		<gml:upperCorner>591077.797000 407107.199000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591077.797000 407107.199000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 239 920</ms:GML_ID>
        <ms:NAZWA>281 239 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281239920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592833.362000 406476.396000</gml:lowerCorner>
        		<gml:upperCorner>592833.362000 406476.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592833.362000 406476.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 241 786</ms:GML_ID>
        <ms:NAZWA>281 241 786</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281241786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593670.743000 406174.642000</gml:lowerCorner>
        		<gml:upperCorner>593670.743000 406174.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593670.743000 406174.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 242 677</ms:GML_ID>
        <ms:NAZWA>281 242 677</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281242677</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>594821.932000 405820.328000</gml:lowerCorner>
        		<gml:upperCorner>594821.932000 405820.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>594821.932000 405820.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 243 887</ms:GML_ID>
        <ms:NAZWA>281 243 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281243887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571089.915000 402515.040000</gml:lowerCorner>
        		<gml:upperCorner>571089.915000 402515.040000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571089.915000 402515.040000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 089 225</ms:GML_ID>
        <ms:NAZWA>356 089 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356089225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571250.778000 401882.141000</gml:lowerCorner>
        		<gml:upperCorner>571250.778000 401882.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571250.778000 401882.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 088 570</ms:GML_ID>
        <ms:NAZWA>356 088 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356088570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571372.046000 401406.049000</gml:lowerCorner>
        		<gml:upperCorner>571372.046000 401406.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571372.046000 401406.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 088 080</ms:GML_ID>
        <ms:NAZWA>356 088 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356088080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571622.321000 399749.178000</gml:lowerCorner>
        		<gml:upperCorner>571622.321000 399749.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571622.321000 399749.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 086 356</ms:GML_ID>
        <ms:NAZWA>356 086 356</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356086356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571640.179000 399725.478000</gml:lowerCorner>
        		<gml:upperCorner>571640.179000 399725.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571640.179000 399725.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 217 138</ms:GML_ID>
        <ms:NAZWA>281 217 138</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281217138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572463.518000 400195.825000</gml:lowerCorner>
        		<gml:upperCorner>572463.518000 400195.825000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572463.518000 400195.825000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 218 086</ms:GML_ID>
        <ms:NAZWA>281 218 086</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281218086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572964.979000 400574.845000</gml:lowerCorner>
        		<gml:upperCorner>572964.979000 400574.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572964.979000 400574.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 218 716</ms:GML_ID>
        <ms:NAZWA>281 218 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281218716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574266.621000 401599.570000</gml:lowerCorner>
        		<gml:upperCorner>574266.621000 401599.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574266.621000 401599.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 220 373</ms:GML_ID>
        <ms:NAZWA>281 220 373</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281220373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575424.459000 402270.324000</gml:lowerCorner>
        		<gml:upperCorner>575424.459000 402270.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575424.459000 402270.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 221 713</ms:GML_ID>
        <ms:NAZWA>281 221 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281221713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577354.490000 403383.275000</gml:lowerCorner>
        		<gml:upperCorner>577354.490000 403383.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577354.490000 403383.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 223 947</ms:GML_ID>
        <ms:NAZWA>281 223 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281223947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579177.276000 404298.836000</gml:lowerCorner>
        		<gml:upperCorner>579177.276000 404298.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579177.276000 404298.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 225 963</ms:GML_ID>
        <ms:NAZWA>281 225 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281225963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579410.686000 404408.481000</gml:lowerCorner>
        		<gml:upperCorner>579410.686000 404408.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579410.686000 404408.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 226 241</ms:GML_ID>
        <ms:NAZWA>281 226 241</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281226241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580997.062885 404709.649529</gml:lowerCorner>
        		<gml:upperCorner>580997.062885 404709.649529</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580997.062885 404709.649529</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 227 859</ms:GML_ID>
        <ms:NAZWA>281 227 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281227859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585725.253000 405438.049000</gml:lowerCorner>
        		<gml:upperCorner>585725.253000 405438.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585725.253000 405438.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 232 645</ms:GML_ID>
        <ms:NAZWA>281 232 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281232645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585867.237486 395469.798038</gml:lowerCorner>
        		<gml:upperCorner>585867.237486 395469.798038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585867.237486 395469.798038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 198 447</ms:GML_ID>
        <ms:NAZWA>018 198 447</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018198447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585925.734311 398508.411808</gml:lowerCorner>
        		<gml:upperCorner>585925.734311 398508.411808</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585925.734311 398508.411808</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 195 395</ms:GML_ID>
        <ms:NAZWA>018 195 395</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018195395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585936.237000 398759.669000</gml:lowerCorner>
        		<gml:upperCorner>585936.237000 398759.669000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585936.237000 398759.669000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 195 149</ms:GML_ID>
        <ms:NAZWA>018 195 149</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018195149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569443.528000 397623.081000</gml:lowerCorner>
        		<gml:upperCorner>569443.528000 397623.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569443.528000 397623.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 083 116</ms:GML_ID>
        <ms:NAZWA>356 083 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356083116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569585.715000 398233.689000</gml:lowerCorner>
        		<gml:upperCorner>569585.715000 398233.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569585.715000 398233.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 083 743</ms:GML_ID>
        <ms:NAZWA>356 083 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356083743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569702.329000 398532.838000</gml:lowerCorner>
        		<gml:upperCorner>569702.329000 398532.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569702.329000 398532.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 084 066</ms:GML_ID>
        <ms:NAZWA>356 084 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356084066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570028.949000 398823.707000</gml:lowerCorner>
        		<gml:upperCorner>570028.949000 398823.707000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570028.949000 398823.707000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 215 296</ms:GML_ID>
        <ms:NAZWA>281 215 296</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281215296</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570098.724000 405788.630000</gml:lowerCorner>
        		<gml:upperCorner>570098.724000 405788.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570098.724000 405788.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 092 720</ms:GML_ID>
        <ms:NAZWA>356 092 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356092720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570138.518843 406713.891145</gml:lowerCorner>
        		<gml:upperCorner>570138.518843 406713.891145</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570138.518843 406713.891145</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 093 642</ms:GML_ID>
        <ms:NAZWA>356 093 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356093642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570179.837000 407655.663000</gml:lowerCorner>
        		<gml:upperCorner>570179.837000 407655.663000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570179.837000 407655.663000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 094 591</ms:GML_ID>
        <ms:NAZWA>356 094 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356094591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570261.823000 408397.606000</gml:lowerCorner>
        		<gml:upperCorner>570261.823000 408397.606000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570261.823000 408397.606000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 095 342</ms:GML_ID>
        <ms:NAZWA>356 095 342</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356095342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570279.368000 404968.126000</gml:lowerCorner>
        		<gml:upperCorner>570279.368000 404968.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570279.368000 404968.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 091 837</ms:GML_ID>
        <ms:NAZWA>356 091 837</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356091837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570287.638000 398969.000000</gml:lowerCorner>
        		<gml:upperCorner>570287.638000 398969.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570287.638000 398969.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 215 584</ms:GML_ID>
        <ms:NAZWA>281 215 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281215584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570450.251000 408967.605000</gml:lowerCorner>
        		<gml:upperCorner>570450.251000 408967.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570450.251000 408967.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 095 943</ms:GML_ID>
        <ms:NAZWA>356 095 943</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356095943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570599.025000 404430.099000</gml:lowerCorner>
        		<gml:upperCorner>570599.025000 404430.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570599.025000 404430.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 091 202</ms:GML_ID>
        <ms:NAZWA>356 091 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356091202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570705.767000 410002.627000</gml:lowerCorner>
        		<gml:upperCorner>570705.767000 410002.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570705.767000 410002.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 097 013</ms:GML_ID>
        <ms:NAZWA>356 097 013</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356097013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570715.166000 410816.328000</gml:lowerCorner>
        		<gml:upperCorner>570715.166000 410816.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570715.166000 410816.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 097 826</ms:GML_ID>
        <ms:NAZWA>356 097 826</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356097826</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570721.591000 411549.093000</gml:lowerCorner>
        		<gml:upperCorner>570721.591000 411549.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570721.591000 411549.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 098 560</ms:GML_ID>
        <ms:NAZWA>356 098 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356098560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570729.686000 412412.347000</gml:lowerCorner>
        		<gml:upperCorner>570729.686000 412412.347000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570729.686000 412412.347000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 099 424</ms:GML_ID>
        <ms:NAZWA>356 099 424</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356099424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570769.678000 403764.241000</gml:lowerCorner>
        		<gml:upperCorner>570769.678000 403764.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570769.678000 403764.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 090 515</ms:GML_ID>
        <ms:NAZWA>356 090 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356090515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>570892.395000 403284.336000</gml:lowerCorner>
        		<gml:upperCorner>570892.395000 403284.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>570892.395000 403284.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 090 019</ms:GML_ID>
        <ms:NAZWA>356 090 019</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356090019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566589.859000 387909.720000</gml:lowerCorner>
        		<gml:upperCorner>566589.859000 387909.720000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566589.859000 387909.720000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 072 699</ms:GML_ID>
        <ms:NAZWA>356 072 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356072699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566918.314000 388453.271000</gml:lowerCorner>
        		<gml:upperCorner>566918.314000 388453.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566918.314000 388453.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 073 237</ms:GML_ID>
        <ms:NAZWA>356 073 237</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356073237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567225.965000 388884.556000</gml:lowerCorner>
        		<gml:upperCorner>567225.965000 388884.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567225.965000 388884.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 073 866</ms:GML_ID>
        <ms:NAZWA>356 073 866</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356073866</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567706.329000 389593.489000</gml:lowerCorner>
        		<gml:upperCorner>567706.329000 389593.489000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567706.329000 389593.489000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 074 725</ms:GML_ID>
        <ms:NAZWA>356 074 725</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356074725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568099.472000 390693.536000</gml:lowerCorner>
        		<gml:upperCorner>568099.472000 390693.536000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568099.472000 390693.536000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 075 895</ms:GML_ID>
        <ms:NAZWA>356 075 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356075895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568317.591143 391336.510687</gml:lowerCorner>
        		<gml:upperCorner>568317.591143 391336.510687</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568317.591143 391336.510687</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 076 574</ms:GML_ID>
        <ms:NAZWA>356 076 574</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356076574</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568697.069000 392434.825000</gml:lowerCorner>
        		<gml:upperCorner>568697.069000 392434.825000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568697.069000 392434.825000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 077 740</ms:GML_ID>
        <ms:NAZWA>356 077 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356077740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569084.378000 395451.980000</gml:lowerCorner>
        		<gml:upperCorner>569084.378000 395451.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569084.378000 395451.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 080 904</ms:GML_ID>
        <ms:NAZWA>356 080 904</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356080904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569114.214000 396053.520000</gml:lowerCorner>
        		<gml:upperCorner>569114.214000 396053.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569114.214000 396053.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 081 511</ms:GML_ID>
        <ms:NAZWA>356 081 511</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356081511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569195.241000 396549.234000</gml:lowerCorner>
        		<gml:upperCorner>569195.241000 396549.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569195.241000 396549.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 082 012</ms:GML_ID>
        <ms:NAZWA>356 082 012</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356082012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569254.237000 394499.674000</gml:lowerCorner>
        		<gml:upperCorner>569254.237000 394499.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569254.237000 394499.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 079 935</ms:GML_ID>
        <ms:NAZWA>356 079 935</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356079935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569330.685000 394028.392000</gml:lowerCorner>
        		<gml:upperCorner>569330.685000 394028.392000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569330.685000 394028.392000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 079 457</ms:GML_ID>
        <ms:NAZWA>356 079 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356079457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582270.746000 370954.728000</gml:lowerCorner>
        		<gml:upperCorner>582270.746000 370954.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582270.746000 370954.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 223 343</ms:GML_ID>
        <ms:NAZWA>018 223 343</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018223343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582293.917136 371891.101445</gml:lowerCorner>
        		<gml:upperCorner>582293.917136 371891.101445</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582293.917136 371891.101445</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 222 405</ms:GML_ID>
        <ms:NAZWA>018 222 405</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018222405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582435.823924 372650.526293</gml:lowerCorner>
        		<gml:upperCorner>582435.823924 372650.526293</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582435.823924 372650.526293</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 221 631</ms:GML_ID>
        <ms:NAZWA>018 221 631</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018221631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582924.871000 374146.684000</gml:lowerCorner>
        		<gml:upperCorner>582924.871000 374146.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582924.871000 374146.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 220 058</ms:GML_ID>
        <ms:NAZWA>018 220 058</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018220058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583142.006965 374823.915097</gml:lowerCorner>
        		<gml:upperCorner>583142.006965 374823.915097</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583142.006965 374823.915097</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 219 346</ms:GML_ID>
        <ms:NAZWA>018 219 346</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018219346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583240.239898 375085.385377</gml:lowerCorner>
        		<gml:upperCorner>583240.239898 375085.385377</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583240.239898 375085.385377</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 219 066</ms:GML_ID>
        <ms:NAZWA>018 219 066</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018219066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583491.730678 375891.418982</gml:lowerCorner>
        		<gml:upperCorner>583491.730678 375891.418982</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583491.730678 375891.418982</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 218 220</ms:GML_ID>
        <ms:NAZWA>018 218 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018218220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583824.724226 378598.629810</gml:lowerCorner>
        		<gml:upperCorner>583824.724226 378598.629810</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583824.724226 378598.629810</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 215 491</ms:GML_ID>
        <ms:NAZWA>018 215 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018215491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583926.317648 379449.499690</gml:lowerCorner>
        		<gml:upperCorner>583926.317648 379449.499690</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583926.317648 379449.499690</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 214 634</ms:GML_ID>
        <ms:NAZWA>018 214 634</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018214634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584012.579000 380152.254000</gml:lowerCorner>
        		<gml:upperCorner>584012.579000 380152.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584012.579000 380152.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 213 927</ms:GML_ID>
        <ms:NAZWA>018 213 927</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018213927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584235.364000 382044.607000</gml:lowerCorner>
        		<gml:upperCorner>584235.364000 382044.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584235.364000 382044.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 212 021</ms:GML_ID>
        <ms:NAZWA>018 212 021</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018212021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584357.678000 382732.198000</gml:lowerCorner>
        		<gml:upperCorner>584357.678000 382732.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584357.678000 382732.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 211 321</ms:GML_ID>
        <ms:NAZWA>018 211 321</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018211321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584454.083000 383063.220000</gml:lowerCorner>
        		<gml:upperCorner>584454.083000 383063.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584454.083000 383063.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 210 976</ms:GML_ID>
        <ms:NAZWA>018 210 976</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018210976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584647.223000 383725.167000</gml:lowerCorner>
        		<gml:upperCorner>584647.223000 383725.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584647.223000 383725.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 210 286</ms:GML_ID>
        <ms:NAZWA>018 210 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018210286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584976.039000 384848.550000</gml:lowerCorner>
        		<gml:upperCorner>584976.039000 384848.550000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584976.039000 384848.550000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 209 115</ms:GML_ID>
        <ms:NAZWA>018 209 115</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018209115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585089.280064 385534.391769</gml:lowerCorner>
        		<gml:upperCorner>585089.280064 385534.391769</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585089.280064 385534.391769</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 208 418</ms:GML_ID>
        <ms:NAZWA>018 208 418</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018208418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585193.497000 386837.963000</gml:lowerCorner>
        		<gml:upperCorner>585193.497000 386837.963000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585193.497000 386837.963000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 207 110</ms:GML_ID>
        <ms:NAZWA>018 207 110</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018207110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585381.551000 389204.187000</gml:lowerCorner>
        		<gml:upperCorner>585381.551000 389204.187000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585381.551000 389204.187000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 204 734</ms:GML_ID>
        <ms:NAZWA>018 204 734</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018204734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585529.990551 391092.496419</gml:lowerCorner>
        		<gml:upperCorner>585529.990551 391092.496419</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585529.990551 391092.496419</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 202 839</ms:GML_ID>
        <ms:NAZWA>018 202 839</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018202839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585620.759000 392231.220000</gml:lowerCorner>
        		<gml:upperCorner>585620.759000 392231.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585620.759000 392231.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 201 696</ms:GML_ID>
        <ms:NAZWA>018 201 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018201696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579326.806000 347397.788000</gml:lowerCorner>
        		<gml:upperCorner>579326.806000 347397.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579326.806000 347397.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 032 740</ms:GML_ID>
        <ms:NAZWA>374 032 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374032740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579938.563000 347754.212000</gml:lowerCorner>
        		<gml:upperCorner>579938.563000 347754.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579938.563000 347754.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 033 448</ms:GML_ID>
        <ms:NAZWA>374 033 448</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374033448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580985.041000 348067.937000</gml:lowerCorner>
        		<gml:upperCorner>580985.041000 348067.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580985.041000 348067.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.374 034 548</ms:GML_ID>
        <ms:NAZWA>374 034 548</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>374034548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>593137.230000 353462.680000</gml:lowerCorner>
        		<gml:upperCorner>593137.230000 353462.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>593137.230000 353462.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 173 085</ms:GML_ID>
        <ms:NAZWA>203 173 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>203173085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3048">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580875.233363 353532.271728</gml:lowerCorner>
        		<gml:upperCorner>580875.233363 353532.271728</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3048.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580875.233363 353532.271728</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3048</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 082 404</ms:GML_ID>
        <ms:NAZWA>354 082 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>354082404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580084.528000 353970.445000</gml:lowerCorner>
        		<gml:upperCorner>580084.528000 353970.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580084.528000 353970.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 081 486</ms:GML_ID>
        <ms:NAZWA>354 081 486</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>354081486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577370.797000 356350.228000</gml:lowerCorner>
        		<gml:upperCorner>577370.797000 356350.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577370.797000 356350.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 077 481</ms:GML_ID>
        <ms:NAZWA>354 077 481</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354077481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3045">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576363.759000 357845.459000</gml:lowerCorner>
        		<gml:upperCorner>576363.759000 357845.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3045.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576363.759000 357845.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3045</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 075 678</ms:GML_ID>
        <ms:NAZWA>354 075 678</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354075678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576126.491000 358198.198000</gml:lowerCorner>
        		<gml:upperCorner>576126.491000 358198.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576126.491000 358198.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 075 259</ms:GML_ID>
        <ms:NAZWA>354 075 259</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354075259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575724.287749 358706.793267</gml:lowerCorner>
        		<gml:upperCorner>575724.287749 358706.793267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575724.287749 358706.793267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 074 605</ms:GML_ID>
        <ms:NAZWA>354 074 605</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354074605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584026.048668 359184.085701</gml:lowerCorner>
        		<gml:upperCorner>584026.048668 359184.085701</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584026.048668 359184.085701</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 235 834</ms:GML_ID>
        <ms:NAZWA>018 235 834</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018235834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>574701.291714 359445.244576</gml:lowerCorner>
        		<gml:upperCorner>574701.291714 359445.244576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>574701.291714 359445.244576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 073 337</ms:GML_ID>
        <ms:NAZWA>354 073 337</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354073337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568071.957000 359488.674000</gml:lowerCorner>
        		<gml:upperCorner>568071.957000 359488.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568071.957000 359488.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 066 572</ms:GML_ID>
        <ms:NAZWA>354 066 572</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354066572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573935.742538 359706.344374</gml:lowerCorner>
        		<gml:upperCorner>573935.742538 359706.344374</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573935.742538 359706.344374</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 072 508</ms:GML_ID>
        <ms:NAZWA>354 072 508</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354072508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>573551.175421 359719.982882</gml:lowerCorner>
        		<gml:upperCorner>573551.175421 359719.982882</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>573551.175421 359719.982882</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 072 120</ms:GML_ID>
        <ms:NAZWA>354 072 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354072120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571442.988293 359749.842848</gml:lowerCorner>
        		<gml:upperCorner>571442.988293 359749.842848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571442.988293 359749.842848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 070 010</ms:GML_ID>
        <ms:NAZWA>354 070 010</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354070010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566977.192000 359849.742000</gml:lowerCorner>
        		<gml:upperCorner>566977.192000 359849.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566977.192000 359849.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 065 411</ms:GML_ID>
        <ms:NAZWA>354 065 411</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354065411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565501.085000 360519.377000</gml:lowerCorner>
        		<gml:upperCorner>565501.085000 360519.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565501.085000 360519.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 063 783</ms:GML_ID>
        <ms:NAZWA>354 063 783</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354063783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>583620.681000 360699.729000</gml:lowerCorner>
        		<gml:upperCorner>583620.681000 360699.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>583620.681000 360699.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 234 255</ms:GML_ID>
        <ms:NAZWA>018 234 255</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018234255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564852.286000 360812.569000</gml:lowerCorner>
        		<gml:upperCorner>564852.286000 360812.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564852.286000 360812.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 063 073</ms:GML_ID>
        <ms:NAZWA>354 063 073</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354063073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563309.431000 361735.850000</gml:lowerCorner>
        		<gml:upperCorner>563309.431000 361735.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563309.431000 361735.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 061 279</ms:GML_ID>
        <ms:NAZWA>354 061 279</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354061279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561987.819000 362814.906000</gml:lowerCorner>
        		<gml:upperCorner>561987.819000 362814.906000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561987.819000 362814.906000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 059 557</ms:GML_ID>
        <ms:NAZWA>354 059 557</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354059557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560957.153837 363171.072878</gml:lowerCorner>
        		<gml:upperCorner>560957.153837 363171.072878</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560957.153837 363171.072878</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 058 444</ms:GML_ID>
        <ms:NAZWA>354 058 444</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354058444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582103.995379 364956.323058</gml:lowerCorner>
        		<gml:upperCorner>582103.995379 364956.323058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582103.995379 364956.323058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 229 457</ms:GML_ID>
        <ms:NAZWA>018 229 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018229457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582612.940697 366488.549102</gml:lowerCorner>
        		<gml:upperCorner>582612.940697 366488.549102</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582612.940697 366488.549102</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 227 845</ms:GML_ID>
        <ms:NAZWA>018 227 845</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018227845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582668.272973 367155.864524</gml:lowerCorner>
        		<gml:upperCorner>582668.272973 367155.864524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582668.272973 367155.864524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 227 172</ms:GML_ID>
        <ms:NAZWA>018 227 172</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018227172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582570.742958 368293.677376</gml:lowerCorner>
        		<gml:upperCorner>582570.742958 368293.677376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582570.742958 368293.677376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 226 029</ms:GML_ID>
        <ms:NAZWA>018 226 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018226029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582305.707621 370439.054690</gml:lowerCorner>
        		<gml:upperCorner>582305.707621 370439.054690</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582305.707621 370439.054690</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 223 862</ms:GML_ID>
        <ms:NAZWA>018 223 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SZCZECIN</ms:IDDE>
        <ms:SEARCH>018223862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554868.893074 398775.508800</gml:lowerCorner>
        		<gml:upperCorner>554868.893074 398775.508800</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554868.893074 398775.508800</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 199 740</ms:GML_ID>
        <ms:NAZWA>281 199 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281199740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555216.859000 398740.167000</gml:lowerCorner>
        		<gml:upperCorner>555216.859000 398740.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555216.859000 398740.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 200 086</ms:GML_ID>
        <ms:NAZWA>281 200 086</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281200086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555914.448000 398678.801000</gml:lowerCorner>
        		<gml:upperCorner>555914.448000 398678.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555914.448000 398678.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 200 785</ms:GML_ID>
        <ms:NAZWA>281 200 785</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281200785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556266.259000 398647.715000</gml:lowerCorner>
        		<gml:upperCorner>556266.259000 398647.715000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556266.259000 398647.715000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 201 138</ms:GML_ID>
        <ms:NAZWA>281 201 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281201138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556692.203000 398609.680000</gml:lowerCorner>
        		<gml:upperCorner>556692.203000 398609.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556692.203000 398609.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 201 566</ms:GML_ID>
        <ms:NAZWA>281 201 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281201566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557825.831000 398496.386000</gml:lowerCorner>
        		<gml:upperCorner>557825.831000 398496.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557825.831000 398496.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 202 707</ms:GML_ID>
        <ms:NAZWA>281 202 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281202707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558364.244000 398382.338000</gml:lowerCorner>
        		<gml:upperCorner>558364.244000 398382.338000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558364.244000 398382.338000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 203 256</ms:GML_ID>
        <ms:NAZWA>281 203 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281203256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559389.021000 398165.882000</gml:lowerCorner>
        		<gml:upperCorner>559389.021000 398165.882000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559389.021000 398165.882000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 204 305</ms:GML_ID>
        <ms:NAZWA>281 204 305</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281204305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559928.754000 398051.948000</gml:lowerCorner>
        		<gml:upperCorner>559928.754000 398051.948000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559928.754000 398051.948000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 204 857</ms:GML_ID>
        <ms:NAZWA>281 204 857</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281204857</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560899.950427 397700.809251</gml:lowerCorner>
        		<gml:upperCorner>560899.950427 397700.809251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560899.950427 397700.809251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 205 891</ms:GML_ID>
        <ms:NAZWA>281 205 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281205891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562850.314000 397980.330000</gml:lowerCorner>
        		<gml:upperCorner>562850.314000 397980.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562850.314000 397980.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 207 927</ms:GML_ID>
        <ms:NAZWA>281 207 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281207927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564740.374000 398548.756000</gml:lowerCorner>
        		<gml:upperCorner>564740.374000 398548.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564740.374000 398548.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 209 901</ms:GML_ID>
        <ms:NAZWA>281 209 901</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281209901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565084.321000 398637.975000</gml:lowerCorner>
        		<gml:upperCorner>565084.321000 398637.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565084.321000 398637.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 210 257</ms:GML_ID>
        <ms:NAZWA>281 210 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281210257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566585.024000 398482.029000</gml:lowerCorner>
        		<gml:upperCorner>566585.024000 398482.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566585.024000 398482.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 211 771</ms:GML_ID>
        <ms:NAZWA>281 211 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281211771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>567018.907000 398430.740000</gml:lowerCorner>
        		<gml:upperCorner>567018.907000 398430.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>567018.907000 398430.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 212 209</ms:GML_ID>
        <ms:NAZWA>281 212 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281212209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568202.145000 398545.733000</gml:lowerCorner>
        		<gml:upperCorner>568202.145000 398545.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568202.145000 398545.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 213 423</ms:GML_ID>
        <ms:NAZWA>281 213 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>281213423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>569281.486000 396928.870000</gml:lowerCorner>
        		<gml:upperCorner>569281.486000 396928.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>569281.486000 396928.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 082 406</ms:GML_ID>
        <ms:NAZWA>356 082 406</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>356082406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550754.333000 377893.314000</gml:lowerCorner>
        		<gml:upperCorner>550754.333000 377893.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550754.333000 377893.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 052 359</ms:GML_ID>
        <ms:NAZWA>356 052 359</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356052359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550807.798000 378622.004000</gml:lowerCorner>
        		<gml:upperCorner>550807.798000 378622.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550807.798000 378622.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 051 605</ms:GML_ID>
        <ms:NAZWA>356 051 605</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356051605</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550856.470000 379469.893000</gml:lowerCorner>
        		<gml:upperCorner>550856.470000 379469.893000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550856.470000 379469.893000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 050 749</ms:GML_ID>
        <ms:NAZWA>356 050 749</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356050749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551521.731000 377770.528000</gml:lowerCorner>
        		<gml:upperCorner>551521.731000 377770.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551521.731000 377770.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 053 180</ms:GML_ID>
        <ms:NAZWA>356 053 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356053180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554659.297349 378211.876866</gml:lowerCorner>
        		<gml:upperCorner>554659.297349 378211.876866</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554659.297349 378211.876866</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 056 356</ms:GML_ID>
        <ms:NAZWA>356 056 356</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356056356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554812.635000 378368.220000</gml:lowerCorner>
        		<gml:upperCorner>554812.635000 378368.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554812.635000 378368.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 056 578</ms:GML_ID>
        <ms:NAZWA>356 056 578</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356056578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555298.012374 379078.029025</gml:lowerCorner>
        		<gml:upperCorner>555298.012374 379078.029025</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555298.012374 379078.029025</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 057 438</ms:GML_ID>
        <ms:NAZWA>356 057 438</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356057438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556259.439924 379657.438579</gml:lowerCorner>
        		<gml:upperCorner>556259.439924 379657.438579</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556259.439924 379657.438579</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 058 579</ms:GML_ID>
        <ms:NAZWA>356 058 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356058579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558233.209000 380551.073000</gml:lowerCorner>
        		<gml:upperCorner>558233.209000 380551.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558233.209000 380551.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 060 746</ms:GML_ID>
        <ms:NAZWA>356 060 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356060746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559782.125000 380805.734000</gml:lowerCorner>
        		<gml:upperCorner>559782.125000 380805.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559782.125000 380805.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 062 345</ms:GML_ID>
        <ms:NAZWA>356 062 345</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356062345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560553.949000 381099.344000</gml:lowerCorner>
        		<gml:upperCorner>560553.949000 381099.344000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560553.949000 381099.344000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 063 187</ms:GML_ID>
        <ms:NAZWA>356 063 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356063187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561918.129000 381992.891000</gml:lowerCorner>
        		<gml:upperCorner>561918.129000 381992.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561918.129000 381992.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 064 819</ms:GML_ID>
        <ms:NAZWA>356 064 819</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356064819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>562806.508000 382575.954000</gml:lowerCorner>
        		<gml:upperCorner>562806.508000 382575.954000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>562806.508000 382575.954000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 065 884</ms:GML_ID>
        <ms:NAZWA>356 065 884</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356065884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>563636.126000 383119.862000</gml:lowerCorner>
        		<gml:upperCorner>563636.126000 383119.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>563636.126000 383119.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 066 876</ms:GML_ID>
        <ms:NAZWA>356 066 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356066876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>564566.013000 383730.084000</gml:lowerCorner>
        		<gml:upperCorner>564566.013000 383730.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>564566.013000 383730.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 067 988</ms:GML_ID>
        <ms:NAZWA>356 067 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356067988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565726.495241 385348.692517</gml:lowerCorner>
        		<gml:upperCorner>565726.495241 385348.692517</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565726.495241 385348.692517</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 070 001</ms:GML_ID>
        <ms:NAZWA>356 070 001</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356070001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565787.549796 385529.441413</gml:lowerCorner>
        		<gml:upperCorner>565787.549796 385529.441413</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565787.549796 385529.441413</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 070 186</ms:GML_ID>
        <ms:NAZWA>356 070 186</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356070186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565909.818604 385890.670941</gml:lowerCorner>
        		<gml:upperCorner>565909.818604 385890.670941</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565909.818604 385890.670941</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 070 566</ms:GML_ID>
        <ms:NAZWA>356 070 566</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356070566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566149.330000 386609.398000</gml:lowerCorner>
        		<gml:upperCorner>566149.330000 386609.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566149.330000 386609.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 071 326</ms:GML_ID>
        <ms:NAZWA>356 071 326</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356071326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>566291.500000 387029.045000</gml:lowerCorner>
        		<gml:upperCorner>566291.500000 387029.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>566291.500000 387029.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 071 768</ms:GML_ID>
        <ms:NAZWA>356 071 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356071768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542378.473000 377146.727000</gml:lowerCorner>
        		<gml:upperCorner>542378.473000 377146.727000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542378.473000 377146.727000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 041 507</ms:GML_ID>
        <ms:NAZWA>356 041 507</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356041507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544414.311000 377450.166000</gml:lowerCorner>
        		<gml:upperCorner>544414.311000 377450.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544414.311000 377450.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 043 562</ms:GML_ID>
        <ms:NAZWA>356 043 562</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356043562</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545294.124000 377534.214000</gml:lowerCorner>
        		<gml:upperCorner>545294.124000 377534.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545294.124000 377534.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 044 451</ms:GML_ID>
        <ms:NAZWA>356 044 451</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356044451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546581.324000 377762.368000</gml:lowerCorner>
        		<gml:upperCorner>546581.324000 377762.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546581.324000 377762.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 045 766</ms:GML_ID>
        <ms:NAZWA>356 045 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356045766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547297.886000 378018.461000</gml:lowerCorner>
        		<gml:upperCorner>547297.886000 378018.461000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547297.886000 378018.461000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 046 527</ms:GML_ID>
        <ms:NAZWA>356 046 527</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356046527</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.16">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548510.880000 365186.162000</gml:lowerCorner>
        		<gml:upperCorner>548510.880000 365186.162000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.16.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548510.880000 365186.162000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>16</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 091 648</ms:GML_ID>
        <ms:NAZWA>236 091 648</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236091648</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.13">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548528.964000 367590.657000</gml:lowerCorner>
        		<gml:upperCorner>548528.964000 367590.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.13.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548528.964000 367590.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>13</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 089 136</ms:GML_ID>
        <ms:NAZWA>236 089 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236089136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.14">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548591.738000 366318.676000</gml:lowerCorner>
        		<gml:upperCorner>548591.738000 366318.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.14.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548591.738000 366318.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>14</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 090 447</ms:GML_ID>
        <ms:NAZWA>236 090 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236090447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548613.452000 378695.030000</gml:lowerCorner>
        		<gml:upperCorner>548613.452000 378695.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548613.452000 378695.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 048 015</ms:GML_ID>
        <ms:NAZWA>356 048 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356048015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.12">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548751.612000 368547.260000</gml:lowerCorner>
        		<gml:upperCorner>548751.612000 368547.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.12.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548751.612000 368547.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>12</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 088 153</ms:GML_ID>
        <ms:NAZWA>236 088 153</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236088153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548925.368000 369296.759000</gml:lowerCorner>
        		<gml:upperCorner>548925.368000 369296.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548925.368000 369296.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 087 382</ms:GML_ID>
        <ms:NAZWA>236 087 382</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236087382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549122.719000 369883.330000</gml:lowerCorner>
        		<gml:upperCorner>549122.719000 369883.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549122.719000 369883.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 086 764</ms:GML_ID>
        <ms:NAZWA>236 086 764</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236086764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549327.829000 370907.483000</gml:lowerCorner>
        		<gml:upperCorner>549327.829000 370907.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549327.829000 370907.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 085 713</ms:GML_ID>
        <ms:NAZWA>236 085 713</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236085713</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549653.647591 373621.957936</gml:lowerCorner>
        		<gml:upperCorner>549653.647591 373621.957936</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549653.647591 373621.957936</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 082 978</ms:GML_ID>
        <ms:NAZWA>236 082 978</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236082978</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549736.612000 379490.352000</gml:lowerCorner>
        		<gml:upperCorner>549736.612000 379490.352000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549736.612000 379490.352000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 049 405</ms:GML_ID>
        <ms:NAZWA>356 049 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356049405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550071.416000 379630.649000</gml:lowerCorner>
        		<gml:upperCorner>550071.416000 379630.649000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550071.416000 379630.649000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 049 763</ms:GML_ID>
        <ms:NAZWA>356 049 763</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356049763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550382.825000 379761.291000</gml:lowerCorner>
        		<gml:upperCorner>550382.825000 379761.291000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550382.825000 379761.291000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 050 101</ms:GML_ID>
        <ms:NAZWA>356 050 101</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356050101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550647.684589 377141.883189</gml:lowerCorner>
        		<gml:upperCorner>550647.684589 377141.883189</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550647.684589 377141.883189</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 079 304</ms:GML_ID>
        <ms:NAZWA>236 079 304</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236079304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550647.974000 379765.251000</gml:lowerCorner>
        		<gml:upperCorner>550647.974000 379765.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550647.974000 379765.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 050 376</ms:GML_ID>
        <ms:NAZWA>356 050 376</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356050376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550727.014000 377942.248000</gml:lowerCorner>
        		<gml:upperCorner>550727.014000 377942.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550727.014000 377942.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 052 303</ms:GML_ID>
        <ms:NAZWA>356 052 303</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356052303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.25">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547231.093000 357803.273000</gml:lowerCorner>
        		<gml:upperCorner>547231.093000 357803.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.25.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547231.093000 357803.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>25</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 103 616</ms:GML_ID>
        <ms:NAZWA>236 103 616</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236103616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.24">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546370.216000 358529.677000</gml:lowerCorner>
        		<gml:upperCorner>546370.216000 358529.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.24.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546370.216000 358529.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>24</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 102 491</ms:GML_ID>
        <ms:NAZWA>236 102 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236102491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.23">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545830.820000 358984.346000</gml:lowerCorner>
        		<gml:upperCorner>545830.820000 358984.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.23.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545830.820000 358984.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>23</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 101 784</ms:GML_ID>
        <ms:NAZWA>236 101 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236101784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.22">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545403.383000 359356.919000</gml:lowerCorner>
        		<gml:upperCorner>545403.383000 359356.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.22.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545403.383000 359356.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>22</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 101 216</ms:GML_ID>
        <ms:NAZWA>236 101 216</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236101216</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.21">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545195.365000 359631.428000</gml:lowerCorner>
        		<gml:upperCorner>545195.365000 359631.428000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.21.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545195.365000 359631.428000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>21</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 100 871</ms:GML_ID>
        <ms:NAZWA>236 100 871</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236100871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.20">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544691.499000 360303.926000</gml:lowerCorner>
        		<gml:upperCorner>544691.499000 360303.926000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.20.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544691.499000 360303.926000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>20</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 100 031</ms:GML_ID>
        <ms:NAZWA>236 100 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236100031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541329.021000 360442.010000</gml:lowerCorner>
        		<gml:upperCorner>541329.021000 360442.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541329.021000 360442.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 037 696</ms:GML_ID>
        <ms:NAZWA>354 037 696</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354037696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.19">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544295.189000 360834.014000</gml:lowerCorner>
        		<gml:upperCorner>544295.189000 360834.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.19.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544295.189000 360834.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>19</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 099 366</ms:GML_ID>
        <ms:NAZWA>236 099 366</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236099366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.18">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543977.444000 361740.586000</gml:lowerCorner>
        		<gml:upperCorner>543977.444000 361740.586000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.18.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543977.444000 361740.586000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>18</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 098 401</ms:GML_ID>
        <ms:NAZWA>236 098 401</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236098401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543035.513000 362238.498000</gml:lowerCorner>
        		<gml:upperCorner>543035.513000 362238.498000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543035.513000 362238.498000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 040 179</ms:GML_ID>
        <ms:NAZWA>354 040 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354040179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543486.661000 362621.889000</gml:lowerCorner>
        		<gml:upperCorner>543486.661000 362621.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543486.661000 362621.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 040 771</ms:GML_ID>
        <ms:NAZWA>354 040 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354040771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.17">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544097.372000 362680.351000</gml:lowerCorner>
        		<gml:upperCorner>544097.372000 362680.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.17.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544097.372000 362680.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>17</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 097 410</ms:GML_ID>
        <ms:NAZWA>236 097 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236097410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544309.819040 362960.558966</gml:lowerCorner>
        		<gml:upperCorner>544309.819040 362960.558966</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544309.819040 362960.558966</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 041 671</ms:GML_ID>
        <ms:NAZWA>354 041 671</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354041671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>545560.314868 363275.278389</gml:lowerCorner>
        		<gml:upperCorner>545560.314868 363275.278389</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>545560.314868 363275.278389</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 042 960</ms:GML_ID>
        <ms:NAZWA>354 042 960</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354042960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>547621.624082 363479.847153</gml:lowerCorner>
        		<gml:upperCorner>547621.624082 363479.847153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>547621.624082 363479.847153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 045 040</ms:GML_ID>
        <ms:NAZWA>354 045 040</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354045040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550490.205000 363556.974000</gml:lowerCorner>
        		<gml:upperCorner>550490.205000 363556.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550490.205000 363556.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 047 909</ms:GML_ID>
        <ms:NAZWA>354 047 909</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354047909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.15">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548733.570000 365812.542000</gml:lowerCorner>
        		<gml:upperCorner>548733.570000 365812.542000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.15.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548733.570000 365812.542000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>15</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.236 090 974</ms:GML_ID>
        <ms:NAZWA>236 090 974</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>236090974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539758.861000 398060.014000</gml:lowerCorner>
        		<gml:upperCorner>539758.861000 398060.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539758.861000 398060.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 184 447</ms:GML_ID>
        <ms:NAZWA>281 184 447</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281184447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540773.764000 398000.384000</gml:lowerCorner>
        		<gml:upperCorner>540773.764000 398000.384000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540773.764000 398000.384000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 185 465</ms:GML_ID>
        <ms:NAZWA>281 185 465</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281185465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541334.699000 397967.915000</gml:lowerCorner>
        		<gml:upperCorner>541334.699000 397967.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541334.699000 397967.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 186 029</ms:GML_ID>
        <ms:NAZWA>281 186 029</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281186029</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542407.845726 397908.489757</gml:lowerCorner>
        		<gml:upperCorner>542407.845726 397908.489757</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542407.845726 397908.489757</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 187 103</ms:GML_ID>
        <ms:NAZWA>281 187 103</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281187103</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542840.196684 397932.159684</gml:lowerCorner>
        		<gml:upperCorner>542840.196684 397932.159684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542840.196684 397932.159684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 187 535</ms:GML_ID>
        <ms:NAZWA>281 187 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281187535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543256.423335 397443.876160</gml:lowerCorner>
        		<gml:upperCorner>543256.423335 397443.876160</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543256.423335 397443.876160</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.385 001 381</ms:GML_ID>
        <ms:NAZWA>385 001 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>385001381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543349.037105 396904.223138</gml:lowerCorner>
        		<gml:upperCorner>543349.037105 396904.223138</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543349.037105 396904.223138</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.385 001 927</ms:GML_ID>
        <ms:NAZWA>385 001 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>385001927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543448.770859 397964.864737</gml:lowerCorner>
        		<gml:upperCorner>543448.770859 397964.864737</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543448.770859 397964.864737</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 188 148</ms:GML_ID>
        <ms:NAZWA>281 188 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281188148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543539.251417 397915.112146</gml:lowerCorner>
        		<gml:upperCorner>543539.251417 397915.112146</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543539.251417 397915.112146</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.385 000 775</ms:GML_ID>
        <ms:NAZWA>385 000 775</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>385000775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>544554.554226 397822.258518</gml:lowerCorner>
        		<gml:upperCorner>544554.554226 397822.258518</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>544554.554226 397822.258518</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 189 262</ms:GML_ID>
        <ms:NAZWA>281 189 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281189262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>546488.370000 397800.464000</gml:lowerCorner>
        		<gml:upperCorner>546488.370000 397800.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>546488.370000 397800.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 191 202</ms:GML_ID>
        <ms:NAZWA>281 191 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281191202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>548385.066000 397969.721000</gml:lowerCorner>
        		<gml:upperCorner>548385.066000 397969.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>548385.066000 397969.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 193 106</ms:GML_ID>
        <ms:NAZWA>281 193 106</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281193106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549276.068000 398023.601000</gml:lowerCorner>
        		<gml:upperCorner>549276.068000 398023.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549276.068000 398023.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 194 000</ms:GML_ID>
        <ms:NAZWA>281 194 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281194000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>549838.718000 398023.944000</gml:lowerCorner>
        		<gml:upperCorner>549838.718000 398023.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>549838.718000 398023.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 194 563</ms:GML_ID>
        <ms:NAZWA>281 194 563</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281194563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550187.827000 398028.038000</gml:lowerCorner>
        		<gml:upperCorner>550187.827000 398028.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550187.827000 398028.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 194 913</ms:GML_ID>
        <ms:NAZWA>281 194 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281194913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>550344.535000 398043.242000</gml:lowerCorner>
        		<gml:upperCorner>550344.535000 398043.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>550344.535000 398043.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 195 070</ms:GML_ID>
        <ms:NAZWA>281 195 070</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281195070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551024.136000 398127.459000</gml:lowerCorner>
        		<gml:upperCorner>551024.136000 398127.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551024.136000 398127.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 195 754</ms:GML_ID>
        <ms:NAZWA>281 195 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281195754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>551592.502000 398196.698000</gml:lowerCorner>
        		<gml:upperCorner>551592.502000 398196.698000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>551592.502000 398196.698000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 196 328</ms:GML_ID>
        <ms:NAZWA>281 196 328</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281196328</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>552552.718000 398317.302000</gml:lowerCorner>
        		<gml:upperCorner>552552.718000 398317.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>552552.718000 398317.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 197 297</ms:GML_ID>
        <ms:NAZWA>281 197 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281197297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553139.245000 398573.248000</gml:lowerCorner>
        		<gml:upperCorner>553139.245000 398573.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553139.245000 398573.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 197 940</ms:GML_ID>
        <ms:NAZWA>281 197 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281197940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>553801.785539 398835.581880</gml:lowerCorner>
        		<gml:upperCorner>553801.785539 398835.581880</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>553801.785539 398835.581880</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 198 665</ms:GML_ID>
        <ms:NAZWA>281 198 665</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281198665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527484.512000 401348.496000</gml:lowerCorner>
        		<gml:upperCorner>527484.512000 401348.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527484.512000 401348.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 171 717</ms:GML_ID>
        <ms:NAZWA>281 171 717</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281171717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527637.180000 382692.675000</gml:lowerCorner>
        		<gml:upperCorner>527637.180000 382692.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527637.180000 382692.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 027 895</ms:GML_ID>
        <ms:NAZWA>377 027 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377027895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528443.745000 383446.523000</gml:lowerCorner>
        		<gml:upperCorner>528443.745000 383446.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528443.745000 383446.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 026 790</ms:GML_ID>
        <ms:NAZWA>377 026 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377026790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528501.536000 387572.060000</gml:lowerCorner>
        		<gml:upperCorner>528501.536000 387572.060000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528501.536000 387572.060000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 022 527</ms:GML_ID>
        <ms:NAZWA>377 022 527</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377022527</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528508.795000 388052.446000</gml:lowerCorner>
        		<gml:upperCorner>528508.795000 388052.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528508.795000 388052.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 022 042</ms:GML_ID>
        <ms:NAZWA>377 022 042</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377022042</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528510.827000 394783.295000</gml:lowerCorner>
        		<gml:upperCorner>528510.827000 394783.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528510.827000 394783.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 013 535</ms:GML_ID>
        <ms:NAZWA>377 013 535</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377013535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528534.411000 387187.643000</gml:lowerCorner>
        		<gml:upperCorner>528534.411000 387187.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528534.411000 387187.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 022 913</ms:GML_ID>
        <ms:NAZWA>377 022 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377022913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528633.268000 386034.136000</gml:lowerCorner>
        		<gml:upperCorner>528633.268000 386034.136000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528633.268000 386034.136000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 024 072</ms:GML_ID>
        <ms:NAZWA>377 024 072</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377024072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528739.080000 388358.750000</gml:lowerCorner>
        		<gml:upperCorner>528739.080000 388358.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528739.080000 388358.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 021 651</ms:GML_ID>
        <ms:NAZWA>377 021 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377021651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528772.543000 384411.448000</gml:lowerCorner>
        		<gml:upperCorner>528772.543000 384411.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528772.543000 384411.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 025 700</ms:GML_ID>
        <ms:NAZWA>377 025 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377025700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529282.417000 400804.480000</gml:lowerCorner>
        		<gml:upperCorner>529282.417000 400804.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529282.417000 400804.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 173 597</ms:GML_ID>
        <ms:NAZWA>281 173 597</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281173597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529644.786000 393827.295000</gml:lowerCorner>
        		<gml:upperCorner>529644.786000 393827.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529644.786000 393827.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 015 022</ms:GML_ID>
        <ms:NAZWA>377 015 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377015022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529843.609000 389571.166000</gml:lowerCorner>
        		<gml:upperCorner>529843.609000 389571.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529843.609000 389571.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 019 961</ms:GML_ID>
        <ms:NAZWA>377 019 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377019961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530218.445000 393431.914000</gml:lowerCorner>
        		<gml:upperCorner>530218.445000 393431.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530218.445000 393431.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 015 718</ms:GML_ID>
        <ms:NAZWA>377 015 718</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377015718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530549.062000 391545.646000</gml:lowerCorner>
        		<gml:upperCorner>530549.062000 391545.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530549.062000 391545.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 017 862</ms:GML_ID>
        <ms:NAZWA>377 017 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377017862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530647.946000 400396.692000</gml:lowerCorner>
        		<gml:upperCorner>530647.946000 400396.692000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530647.946000 400396.692000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 175 023</ms:GML_ID>
        <ms:NAZWA>281 175 023</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281175023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532165.483000 399942.709000</gml:lowerCorner>
        		<gml:upperCorner>532165.483000 399942.709000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532165.483000 399942.709000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 176 608</ms:GML_ID>
        <ms:NAZWA>281 176 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281176608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534371.487000 399282.635000</gml:lowerCorner>
        		<gml:upperCorner>534371.487000 399282.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534371.487000 399282.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 178 913</ms:GML_ID>
        <ms:NAZWA>281 178 913</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281178913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536502.149000 398692.965000</gml:lowerCorner>
        		<gml:upperCorner>536502.149000 398692.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536502.149000 398692.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 181 122</ms:GML_ID>
        <ms:NAZWA>281 181 122</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281181122</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>537971.359000 398361.460000</gml:lowerCorner>
        		<gml:upperCorner>537971.359000 398361.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>537971.359000 398361.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 182 630</ms:GML_ID>
        <ms:NAZWA>281 182 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281182630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538468.429000 398249.720000</gml:lowerCorner>
        		<gml:upperCorner>538468.429000 398249.720000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538468.429000 398249.720000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 183 139</ms:GML_ID>
        <ms:NAZWA>281 183 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281183139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526327.168000 366528.634000</gml:lowerCorner>
        		<gml:upperCorner>526327.168000 366528.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526327.168000 366528.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 020 435</ms:GML_ID>
        <ms:NAZWA>356 020 435</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356020435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527132.842000 367597.097000</gml:lowerCorner>
        		<gml:upperCorner>527132.842000 367597.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527132.842000 367597.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 021 773</ms:GML_ID>
        <ms:NAZWA>356 021 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356021773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>527566.201000 368186.009000</gml:lowerCorner>
        		<gml:upperCorner>527566.201000 368186.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>527566.201000 368186.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 022 503</ms:GML_ID>
        <ms:NAZWA>356 022 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356022503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528053.219000 369428.936000</gml:lowerCorner>
        		<gml:upperCorner>528053.219000 369428.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528053.219000 369428.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 023 851</ms:GML_ID>
        <ms:NAZWA>356 023 851</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356023851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>528795.630421 378302.063851</gml:lowerCorner>
        		<gml:upperCorner>528795.630421 378302.063851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>528795.630421 378302.063851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 033 892</ms:GML_ID>
        <ms:NAZWA>377 033 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377033892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529048.322000 370750.069000</gml:lowerCorner>
        		<gml:upperCorner>529048.322000 370750.069000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529048.322000 370750.069000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 025 516</ms:GML_ID>
        <ms:NAZWA>356 025 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356025516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529405.945000 371345.254000</gml:lowerCorner>
        		<gml:upperCorner>529405.945000 371345.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529405.945000 371345.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 026 211</ms:GML_ID>
        <ms:NAZWA>356 026 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356026211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529487.987000 376861.964000</gml:lowerCorner>
        		<gml:upperCorner>529487.987000 376861.964000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529487.987000 376861.964000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 035 500</ms:GML_ID>
        <ms:NAZWA>377 035 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377035500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529773.809000 371993.841000</gml:lowerCorner>
        		<gml:upperCorner>529773.809000 371993.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529773.809000 371993.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 026 960</ms:GML_ID>
        <ms:NAZWA>356 026 960</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356026960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>529910.155000 375906.418000</gml:lowerCorner>
        		<gml:upperCorner>529910.155000 375906.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>529910.155000 375906.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 036 542</ms:GML_ID>
        <ms:NAZWA>377 036 542</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377036542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>530794.688839 374167.231090</gml:lowerCorner>
        		<gml:upperCorner>530794.688839 374167.231090</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>530794.688839 374167.231090</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 029 360</ms:GML_ID>
        <ms:NAZWA>356 029 360</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356029360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531080.382022 374374.390376</gml:lowerCorner>
        		<gml:upperCorner>531080.382022 374374.390376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531080.382022 374374.390376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 029 729</ms:GML_ID>
        <ms:NAZWA>356 029 729</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356029729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531864.736433 374496.661282</gml:lowerCorner>
        		<gml:upperCorner>531864.736433 374496.661282</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531864.736433 374496.661282</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 030 522</ms:GML_ID>
        <ms:NAZWA>356 030 522</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356030522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533294.084000 374788.294000</gml:lowerCorner>
        		<gml:upperCorner>533294.084000 374788.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533294.084000 374788.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 031 984</ms:GML_ID>
        <ms:NAZWA>356 031 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356031984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533891.613000 374980.884000</gml:lowerCorner>
        		<gml:upperCorner>533891.613000 374980.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533891.613000 374980.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 032 613</ms:GML_ID>
        <ms:NAZWA>356 032 613</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356032613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>534898.040000 375615.402000</gml:lowerCorner>
        		<gml:upperCorner>534898.040000 375615.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>534898.040000 375615.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 033 805</ms:GML_ID>
        <ms:NAZWA>356 033 805</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356033805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535617.806000 375700.915000</gml:lowerCorner>
        		<gml:upperCorner>535617.806000 375700.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535617.806000 375700.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 034 540</ms:GML_ID>
        <ms:NAZWA>356 034 540</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356034540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536193.707421 375865.241063</gml:lowerCorner>
        		<gml:upperCorner>536193.707421 375865.241063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536193.707421 375865.241063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 035 150</ms:GML_ID>
        <ms:NAZWA>356 035 150</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356035150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536549.368337 375968.296993</gml:lowerCorner>
        		<gml:upperCorner>536549.368337 375968.296993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536549.368337 375968.296993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 035 511</ms:GML_ID>
        <ms:NAZWA>356 035 511</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356035511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538488.295000 376626.869000</gml:lowerCorner>
        		<gml:upperCorner>538488.295000 376626.869000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538488.295000 376626.869000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 037 577</ms:GML_ID>
        <ms:NAZWA>356 037 577</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356037577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539414.511000 376794.136000</gml:lowerCorner>
        		<gml:upperCorner>539414.511000 376794.136000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539414.511000 376794.136000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 038 521</ms:GML_ID>
        <ms:NAZWA>356 038 521</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356038521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539967.751508 359082.258096</gml:lowerCorner>
        		<gml:upperCorner>539967.751508 359082.258096</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539967.751508 359082.258096</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.354 035 765</ms:GML_ID>
        <ms:NAZWA>354 035 765</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>354035765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540524.612000 376903.768000</gml:lowerCorner>
        		<gml:upperCorner>540524.612000 376903.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540524.612000 376903.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 039 636</ms:GML_ID>
        <ms:NAZWA>356 039 636</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356039636</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515012.989000 388121.204000</gml:lowerCorner>
        		<gml:upperCorner>515012.989000 388121.204000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515012.989000 388121.204000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 026 982</ms:GML_ID>
        <ms:NAZWA>353 026 982</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353026982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515153.549000 388901.648000</gml:lowerCorner>
        		<gml:upperCorner>515153.549000 388901.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515153.549000 388901.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 027 778</ms:GML_ID>
        <ms:NAZWA>353 027 778</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353027778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515331.917000 389892.167000</gml:lowerCorner>
        		<gml:upperCorner>515331.917000 389892.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515331.917000 389892.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 028 783</ms:GML_ID>
        <ms:NAZWA>353 028 783</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353028783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515517.696000 390924.933000</gml:lowerCorner>
        		<gml:upperCorner>515517.696000 390924.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515517.696000 390924.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 029 834</ms:GML_ID>
        <ms:NAZWA>353 029 834</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353029834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515666.487000 391751.821000</gml:lowerCorner>
        		<gml:upperCorner>515666.487000 391751.821000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515666.487000 391751.821000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 030 673</ms:GML_ID>
        <ms:NAZWA>353 030 673</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353030673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515870.607000 392884.563000</gml:lowerCorner>
        		<gml:upperCorner>515870.607000 392884.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515870.607000 392884.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 031 825</ms:GML_ID>
        <ms:NAZWA>353 031 825</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353031825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516100.993000 394168.841000</gml:lowerCorner>
        		<gml:upperCorner>516100.993000 394168.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516100.993000 394168.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 033 133</ms:GML_ID>
        <ms:NAZWA>353 033 133</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353033133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516314.379000 395354.994000</gml:lowerCorner>
        		<gml:upperCorner>516314.379000 395354.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516314.379000 395354.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 034 337</ms:GML_ID>
        <ms:NAZWA>353 034 337</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353034337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516450.623000 403181.805000</gml:lowerCorner>
        		<gml:upperCorner>516450.623000 403181.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516450.623000 403181.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 156 052</ms:GML_ID>
        <ms:NAZWA>281 156 052</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281156052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516599.520000 396941.881000</gml:lowerCorner>
        		<gml:upperCorner>516599.520000 396941.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516599.520000 396941.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 035 950</ms:GML_ID>
        <ms:NAZWA>353 035 950</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353035950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516791.909000 398009.917000</gml:lowerCorner>
        		<gml:upperCorner>516791.909000 398009.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516791.909000 398009.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 037 036</ms:GML_ID>
        <ms:NAZWA>353 037 036</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353037036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516966.831000 398631.933000</gml:lowerCorner>
        		<gml:upperCorner>516966.831000 398631.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516966.831000 398631.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 037 681</ms:GML_ID>
        <ms:NAZWA>353 037 681</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353037681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517547.943000 400295.517000</gml:lowerCorner>
        		<gml:upperCorner>517547.943000 400295.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517547.943000 400295.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 039 445</ms:GML_ID>
        <ms:NAZWA>353 039 445</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353039445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517984.630000 403333.261000</gml:lowerCorner>
        		<gml:upperCorner>517984.630000 403333.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517984.630000 403333.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 157 596</ms:GML_ID>
        <ms:NAZWA>281 157 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281157596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522646.504000 403521.825000</gml:lowerCorner>
        		<gml:upperCorner>522646.504000 403521.825000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522646.504000 403521.825000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 002 608</ms:GML_ID>
        <ms:NAZWA>377 002 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377002608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522833.450000 402493.710000</gml:lowerCorner>
        		<gml:upperCorner>522833.450000 402493.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522833.450000 402493.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 003 653</ms:GML_ID>
        <ms:NAZWA>377 003 653</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377003653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523080.068000 401149.295000</gml:lowerCorner>
        		<gml:upperCorner>523080.068000 401149.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523080.068000 401149.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 005 033</ms:GML_ID>
        <ms:NAZWA>377 005 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377005033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523300.953000 400657.449000</gml:lowerCorner>
        		<gml:upperCorner>523300.953000 400657.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523300.953000 400657.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 005 572</ms:GML_ID>
        <ms:NAZWA>377 005 572</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377005572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523624.181000 399939.554000</gml:lowerCorner>
        		<gml:upperCorner>523624.181000 399939.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523624.181000 399939.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 006 360</ms:GML_ID>
        <ms:NAZWA>377 006 360</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377006360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524653.136000 403983.625000</gml:lowerCorner>
        		<gml:upperCorner>524653.136000 403983.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524653.136000 403983.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 167 842</ms:GML_ID>
        <ms:NAZWA>281 167 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281167842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525056.561000 403595.925000</gml:lowerCorner>
        		<gml:upperCorner>525056.561000 403595.925000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525056.561000 403595.925000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 168 401</ms:GML_ID>
        <ms:NAZWA>281 168 401</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281168401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525575.181000 397389.889000</gml:lowerCorner>
        		<gml:upperCorner>525575.181000 397389.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525575.181000 397389.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 009 591</ms:GML_ID>
        <ms:NAZWA>377 009 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377009591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525760.344000 402920.365000</gml:lowerCorner>
        		<gml:upperCorner>525760.344000 402920.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525760.344000 402920.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 169 377</ms:GML_ID>
        <ms:NAZWA>281 169 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281169377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526217.514000 402481.027000</gml:lowerCorner>
        		<gml:upperCorner>526217.514000 402481.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526217.514000 402481.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 170 012</ms:GML_ID>
        <ms:NAZWA>281 170 012</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281170012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526367.176000 380673.488000</gml:lowerCorner>
        		<gml:upperCorner>526367.176000 380673.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526367.176000 380673.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 030 489</ms:GML_ID>
        <ms:NAZWA>377 030 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377030489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526574.367000 381698.360000</gml:lowerCorner>
        		<gml:upperCorner>526574.367000 381698.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526574.367000 381698.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 029 351</ms:GML_ID>
        <ms:NAZWA>377 029 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377029351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526703.529000 402014.086000</gml:lowerCorner>
        		<gml:upperCorner>526703.529000 402014.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526703.529000 402014.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 170 685</ms:GML_ID>
        <ms:NAZWA>281 170 685</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281170685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512652.427000 359763.413000</gml:lowerCorner>
        		<gml:upperCorner>512652.427000 359763.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512652.427000 359763.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 010 200</ms:GML_ID>
        <ms:NAZWA>395 010 200</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395010200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512764.093000 359454.814000</gml:lowerCorner>
        		<gml:upperCorner>512764.093000 359454.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512764.093000 359454.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 010 530</ms:GML_ID>
        <ms:NAZWA>395 010 530</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395010530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513111.726000 362826.155000</gml:lowerCorner>
        		<gml:upperCorner>513111.726000 362826.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513111.726000 362826.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 005 583</ms:GML_ID>
        <ms:NAZWA>356 005 583</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356005583</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513886.891524 362740.613123</gml:lowerCorner>
        		<gml:upperCorner>513886.891524 362740.613123</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513886.891524 362740.613123</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 006 370</ms:GML_ID>
        <ms:NAZWA>356 006 370</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356006370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514148.603177 362734.010836</gml:lowerCorner>
        		<gml:upperCorner>514148.603177 362734.010836</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514148.603177 362734.010836</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 006 623</ms:GML_ID>
        <ms:NAZWA>356 006 623</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356006623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514540.779340 362726.952994</gml:lowerCorner>
        		<gml:upperCorner>514540.779340 362726.952994</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514540.779340 362726.952994</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 007 018</ms:GML_ID>
        <ms:NAZWA>356 007 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356007018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515011.640112 362713.771578</gml:lowerCorner>
        		<gml:upperCorner>515011.640112 362713.771578</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515011.640112 362713.771578</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 007 483</ms:GML_ID>
        <ms:NAZWA>356 007 483</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356007483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515286.478000 362710.728000</gml:lowerCorner>
        		<gml:upperCorner>515286.478000 362710.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515286.478000 362710.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 007 765</ms:GML_ID>
        <ms:NAZWA>356 007 765</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356007765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515998.454000 362722.635000</gml:lowerCorner>
        		<gml:upperCorner>515998.454000 362722.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515998.454000 362722.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 008 479</ms:GML_ID>
        <ms:NAZWA>356 008 479</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356008479</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>516540.483000 363059.659000</gml:lowerCorner>
        		<gml:upperCorner>516540.483000 363059.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>516540.483000 363059.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 009 120</ms:GML_ID>
        <ms:NAZWA>356 009 120</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356009120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517835.907000 363512.629000</gml:lowerCorner>
        		<gml:upperCorner>517835.907000 363512.629000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517835.907000 363512.629000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 010 561</ms:GML_ID>
        <ms:NAZWA>356 010 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356010561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518148.753756 363464.673523</gml:lowerCorner>
        		<gml:upperCorner>518148.753756 363464.673523</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518148.753756 363464.673523</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 010 878</ms:GML_ID>
        <ms:NAZWA>356 010 878</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356010878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518746.875000 363372.315000</gml:lowerCorner>
        		<gml:upperCorner>518746.875000 363372.315000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518746.875000 363372.315000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 011 483</ms:GML_ID>
        <ms:NAZWA>356 011 483</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356011483</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520630.370595 363082.061341</gml:lowerCorner>
        		<gml:upperCorner>520630.370595 363082.061341</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520630.370595 363082.061341</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 013 390</ms:GML_ID>
        <ms:NAZWA>356 013 390</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356013390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520667.083492 363076.282991</gml:lowerCorner>
        		<gml:upperCorner>520667.083492 363076.282991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520667.083492 363076.282991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 013 428</ms:GML_ID>
        <ms:NAZWA>356 013 428</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356013428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521483.147627 362943.994880</gml:lowerCorner>
        		<gml:upperCorner>521483.147627 362943.994880</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521483.147627 362943.994880</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 014 256</ms:GML_ID>
        <ms:NAZWA>356 014 256</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356014256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522700.463000 363760.400000</gml:lowerCorner>
        		<gml:upperCorner>522700.463000 363760.400000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522700.463000 363760.400000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 015 753</ms:GML_ID>
        <ms:NAZWA>356 015 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356015753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523055.533781 364235.877309</gml:lowerCorner>
        		<gml:upperCorner>523055.533781 364235.877309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523055.533781 364235.877309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 016 361</ms:GML_ID>
        <ms:NAZWA>356 016 361</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356016361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523065.346000 364259.843000</gml:lowerCorner>
        		<gml:upperCorner>523065.346000 364259.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523065.346000 364259.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 016 387</ms:GML_ID>
        <ms:NAZWA>356 016 387</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356016387</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3103">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523319.986000 364545.867000</gml:lowerCorner>
        		<gml:upperCorner>523319.986000 364545.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3103.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523319.986000 364545.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3103</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 016 776</ms:GML_ID>
        <ms:NAZWA>356 016 776</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356016776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3104">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523618.630000 364792.493000</gml:lowerCorner>
        		<gml:upperCorner>523618.630000 364792.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3104.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523618.630000 364792.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3104</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 017 162</ms:GML_ID>
        <ms:NAZWA>356 017 162</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356017162</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3105">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523963.478000 365035.460000</gml:lowerCorner>
        		<gml:upperCorner>523963.478000 365035.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3105.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523963.478000 365035.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3105</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 017 587</ms:GML_ID>
        <ms:NAZWA>356 017 587</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356017587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3106">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524588.316000 365335.372000</gml:lowerCorner>
        		<gml:upperCorner>524588.316000 365335.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3106.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524588.316000 365335.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3106</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 018 280</ms:GML_ID>
        <ms:NAZWA>356 018 280</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356018280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>525500.782000 365773.181000</gml:lowerCorner>
        		<gml:upperCorner>525500.782000 365773.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>525500.782000 365773.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 019 292</ms:GML_ID>
        <ms:NAZWA>356 019 292</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356019292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502668.263310 363296.428849</gml:lowerCorner>
        		<gml:upperCorner>502668.263310 363296.428849</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502668.263310 363296.428849</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.806 000 060</ms:GML_ID>
        <ms:NAZWA>806 000 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>806000060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502809.016000 357378.971000</gml:lowerCorner>
        		<gml:upperCorner>502809.016000 357378.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502809.016000 357378.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.802 000 726</ms:GML_ID>
        <ms:NAZWA>802 000 726</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>802000726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503168.431000 356730.736000</gml:lowerCorner>
        		<gml:upperCorner>503168.431000 356730.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503168.431000 356730.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.801 001 548</ms:GML_ID>
        <ms:NAZWA>801 001 548</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>801001548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503504.237000 356371.731000</gml:lowerCorner>
        		<gml:upperCorner>503504.237000 356371.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503504.237000 356371.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.801 001 991</ms:GML_ID>
        <ms:NAZWA>801 001 991</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>801001991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504259.976850 364600.965170</gml:lowerCorner>
        		<gml:upperCorner>504259.976850 364600.965170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504259.976850 364600.965170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.352 003 010</ms:GML_ID>
        <ms:NAZWA>352 003 010</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>352003010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504316.964887 364577.936033</gml:lowerCorner>
        		<gml:upperCorner>504316.964887 364577.936033</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504316.964887 364577.936033</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.352 002 970</ms:GML_ID>
        <ms:NAZWA>352 002 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>352002970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504408.526184 364523.859351</gml:lowerCorner>
        		<gml:upperCorner>504408.526184 364523.859351</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504408.526184 364523.859351</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.352 002 864</ms:GML_ID>
        <ms:NAZWA>352 002 864</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>352002864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504534.902944 364437.681024</gml:lowerCorner>
        		<gml:upperCorner>504534.902944 364437.681024</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504534.902944 364437.681024</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.352 002 712</ms:GML_ID>
        <ms:NAZWA>352 002 712</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>352002712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505245.726000 366425.146000</gml:lowerCorner>
        		<gml:upperCorner>505245.726000 366425.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505245.726000 366425.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.394 009 726</ms:GML_ID>
        <ms:NAZWA>394 009 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>394009726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506784.721000 366843.486000</gml:lowerCorner>
        		<gml:upperCorner>506784.721000 366843.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506784.721000 366843.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.394 011 326</ms:GML_ID>
        <ms:NAZWA>394 011 326</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>394011326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507365.893000 366989.349000</gml:lowerCorner>
        		<gml:upperCorner>507365.893000 366989.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507365.893000 366989.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.394 011 928</ms:GML_ID>
        <ms:NAZWA>394 011 928</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>394011928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507512.012991 361687.498077</gml:lowerCorner>
        		<gml:upperCorner>507512.012991 361687.498077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507512.012991 361687.498077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 299 660</ms:GML_ID>
        <ms:NAZWA>003 299 660</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003299660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507749.418325 363170.618650</gml:lowerCorner>
        		<gml:upperCorner>507749.418325 363170.618650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507749.418325 363170.618650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 298 037</ms:GML_ID>
        <ms:NAZWA>003 298 037</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003298037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507870.486185 362424.157768</gml:lowerCorner>
        		<gml:upperCorner>507870.486185 362424.157768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507870.486185 362424.157768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 298 853</ms:GML_ID>
        <ms:NAZWA>003 298 853</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003298853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>507933.757431 362514.703720</gml:lowerCorner>
        		<gml:upperCorner>507933.757431 362514.703720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>507933.757431 362514.703720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 000 252</ms:GML_ID>
        <ms:NAZWA>353 000 252</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353000252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508635.038000 362652.332000</gml:lowerCorner>
        		<gml:upperCorner>508635.038000 362652.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508635.038000 362652.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 001 052</ms:GML_ID>
        <ms:NAZWA>356 001 052</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356001052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508738.094926 362598.382415</gml:lowerCorner>
        		<gml:upperCorner>508738.094926 362598.382415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508738.094926 362598.382415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 001 193</ms:GML_ID>
        <ms:NAZWA>356 001 193</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356001193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508950.950000 364760.245000</gml:lowerCorner>
        		<gml:upperCorner>508950.950000 364760.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508950.950000 364760.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 002 724</ms:GML_ID>
        <ms:NAZWA>353 002 724</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353002724</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509052.938000 365144.717000</gml:lowerCorner>
        		<gml:upperCorner>509052.938000 365144.717000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509052.938000 365144.717000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 003 119</ms:GML_ID>
        <ms:NAZWA>353 003 119</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353003119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509497.417000 366595.758000</gml:lowerCorner>
        		<gml:upperCorner>509497.417000 366595.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509497.417000 366595.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 004 639</ms:GML_ID>
        <ms:NAZWA>353 004 639</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353004639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509587.200000 354009.163000</gml:lowerCorner>
        		<gml:upperCorner>509587.200000 354009.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509587.200000 354009.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.351 006 393</ms:GML_ID>
        <ms:NAZWA>351 006 393</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>351006393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509901.167000 362816.146000</gml:lowerCorner>
        		<gml:upperCorner>509901.167000 362816.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509901.167000 362816.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 002 342</ms:GML_ID>
        <ms:NAZWA>356 002 342</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356002342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511237.139000 363015.735000</gml:lowerCorner>
        		<gml:upperCorner>511237.139000 363015.735000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511237.139000 363015.735000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.356 003 695</ms:GML_ID>
        <ms:NAZWA>356 003 695</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>356003695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512411.645000 360519.042000</gml:lowerCorner>
        		<gml:upperCorner>512411.645000 360519.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512411.645000 360519.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.395 009 409</ms:GML_ID>
        <ms:NAZWA>395 009 409</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>395009409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496257.075000 410977.964000</gml:lowerCorner>
        		<gml:upperCorner>496257.075000 410977.964000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496257.075000 410977.964000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 244 936</ms:GML_ID>
        <ms:NAZWA>003 244 936</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003244936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497136.463000 407619.933000</gml:lowerCorner>
        		<gml:upperCorner>497136.463000 407619.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497136.463000 407619.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 248 407</ms:GML_ID>
        <ms:NAZWA>003 248 407</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003248407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497331.765000 406785.183000</gml:lowerCorner>
        		<gml:upperCorner>497331.765000 406785.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497331.765000 406785.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 249 266</ms:GML_ID>
        <ms:NAZWA>003 249 266</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003249266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497416.040000 406155.256000</gml:lowerCorner>
        		<gml:upperCorner>497416.040000 406155.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497416.040000 406155.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 249 897</ms:GML_ID>
        <ms:NAZWA>003 249 897</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003249897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497625.560000 404588.750000</gml:lowerCorner>
        		<gml:upperCorner>497625.560000 404588.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497625.560000 404588.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 251 485</ms:GML_ID>
        <ms:NAZWA>003 251 485</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003251485</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497744.136000 403698.820000</gml:lowerCorner>
        		<gml:upperCorner>497744.136000 403698.820000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497744.136000 403698.820000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 252 389</ms:GML_ID>
        <ms:NAZWA>003 252 389</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003252389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506243.804000 402367.832000</gml:lowerCorner>
        		<gml:upperCorner>506243.804000 402367.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506243.804000 402367.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 145 810</ms:GML_ID>
        <ms:NAZWA>281 145 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281145810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508029.444000 402512.787000</gml:lowerCorner>
        		<gml:upperCorner>508029.444000 402512.787000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508029.444000 402512.787000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 147 601</ms:GML_ID>
        <ms:NAZWA>281 147 601</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281147601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511302.262000 402778.515000</gml:lowerCorner>
        		<gml:upperCorner>511302.262000 402778.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511302.262000 402778.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 150 888</ms:GML_ID>
        <ms:NAZWA>281 150 888</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281150888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513709.970205 402872.883472</gml:lowerCorner>
        		<gml:upperCorner>513709.970205 402872.883472</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513709.970205 402872.883472</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 153 310</ms:GML_ID>
        <ms:NAZWA>281 153 310</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281153310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515983.224000 403135.540000</gml:lowerCorner>
        		<gml:upperCorner>515983.224000 403135.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515983.224000 403135.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 155 581</ms:GML_ID>
        <ms:NAZWA>281 155 581</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281155581</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518708.307000 403783.237000</gml:lowerCorner>
        		<gml:upperCorner>518708.307000 403783.237000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518708.307000 403783.237000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 158 481</ms:GML_ID>
        <ms:NAZWA>281 158 481</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281158481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518765.682000 403782.039000</gml:lowerCorner>
        		<gml:upperCorner>518765.682000 403782.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518765.682000 403782.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 043 141</ms:GML_ID>
        <ms:NAZWA>353 043 141</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353043141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518990.253462 404832.913442</gml:lowerCorner>
        		<gml:upperCorner>518990.253462 404832.913442</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518990.253462 404832.913442</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 044 225</ms:GML_ID>
        <ms:NAZWA>353 044 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353044225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519452.990000 409334.878000</gml:lowerCorner>
        		<gml:upperCorner>519452.990000 409334.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519452.990000 409334.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 048 762</ms:GML_ID>
        <ms:NAZWA>353 048 762</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353048762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519667.749000 406903.943000</gml:lowerCorner>
        		<gml:upperCorner>519667.749000 406903.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519667.749000 406903.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 161 867</ms:GML_ID>
        <ms:NAZWA>281 161 867</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281161867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>520360.451000 406851.657000</gml:lowerCorner>
        		<gml:upperCorner>520360.451000 406851.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>520360.451000 406851.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 162 564</ms:GML_ID>
        <ms:NAZWA>281 162 564</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281162564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521343.491000 406535.704000</gml:lowerCorner>
        		<gml:upperCorner>521343.491000 406535.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521343.491000 406535.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 163 622</ms:GML_ID>
        <ms:NAZWA>281 163 622</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281163622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522600.581000 405763.600000</gml:lowerCorner>
        		<gml:upperCorner>522600.581000 405763.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522600.581000 405763.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 165 123</ms:GML_ID>
        <ms:NAZWA>281 165 123</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281165123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>522790.975000 404885.842000</gml:lowerCorner>
        		<gml:upperCorner>522790.975000 404885.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>522790.975000 404885.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.377 001 197</ms:GML_ID>
        <ms:NAZWA>377 001 197</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>377001197</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523226.013000 405223.806000</gml:lowerCorner>
        		<gml:upperCorner>523226.013000 405223.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523226.013000 405223.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 165 950</ms:GML_ID>
        <ms:NAZWA>281 165 950</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281165950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>523693.751000 404819.449000</gml:lowerCorner>
        		<gml:upperCorner>523693.751000 404819.449000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>523693.751000 404819.449000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 166 569</ms:GML_ID>
        <ms:NAZWA>281 166 569</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281166569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488469.668000 377162.363000</gml:lowerCorner>
        		<gml:upperCorner>488469.668000 377162.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488469.668000 377162.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 173 208</ms:GML_ID>
        <ms:NAZWA>272 173 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272173208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489449.661000 375524.778000</gml:lowerCorner>
        		<gml:upperCorner>489449.661000 375524.778000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489449.661000 375524.778000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 175 116</ms:GML_ID>
        <ms:NAZWA>272 175 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272175116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489879.697000 374806.569000</gml:lowerCorner>
        		<gml:upperCorner>489879.697000 374806.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489879.697000 374806.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 175 955</ms:GML_ID>
        <ms:NAZWA>272 175 955</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272175955</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490537.282000 373708.726000</gml:lowerCorner>
        		<gml:upperCorner>490537.282000 373708.726000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490537.282000 373708.726000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 177 234</ms:GML_ID>
        <ms:NAZWA>272 177 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272177234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>490944.008000 373029.627000</gml:lowerCorner>
        		<gml:upperCorner>490944.008000 373029.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>490944.008000 373029.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 178 026</ms:GML_ID>
        <ms:NAZWA>272 178 026</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272178026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491767.446000 371654.691000</gml:lowerCorner>
        		<gml:upperCorner>491767.446000 371654.691000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491767.446000 371654.691000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 179 631</ms:GML_ID>
        <ms:NAZWA>272 179 631</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272179631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492297.015000 370769.655000</gml:lowerCorner>
        		<gml:upperCorner>492297.015000 370769.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492297.015000 370769.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 180 661</ms:GML_ID>
        <ms:NAZWA>272 180 661</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272180661</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492531.847000 370377.798000</gml:lowerCorner>
        		<gml:upperCorner>492531.847000 370377.798000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492531.847000 370377.798000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 181 117</ms:GML_ID>
        <ms:NAZWA>272 181 117</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272181117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493223.500000 369223.131000</gml:lowerCorner>
        		<gml:upperCorner>493223.500000 369223.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493223.500000 369223.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 182 466</ms:GML_ID>
        <ms:NAZWA>272 182 466</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272182466</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494023.538000 367885.424000</gml:lowerCorner>
        		<gml:upperCorner>494023.538000 367885.424000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494023.538000 367885.424000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 184 023</ms:GML_ID>
        <ms:NAZWA>272 184 023</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272184023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494312.530769 367412.008604</gml:lowerCorner>
        		<gml:upperCorner>494312.530769 367412.008604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494312.530769 367412.008604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 184 579</ms:GML_ID>
        <ms:NAZWA>272 184 579</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272184579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501589.691000 385399.030000</gml:lowerCorner>
        		<gml:upperCorner>501589.691000 385399.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501589.691000 385399.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 274 390</ms:GML_ID>
        <ms:NAZWA>003 274 390</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003274390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502490.275000 383707.931000</gml:lowerCorner>
        		<gml:upperCorner>502490.275000 383707.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502490.275000 383707.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 276 292</ms:GML_ID>
        <ms:NAZWA>003 276 292</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003276292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503465.984000 382127.133000</gml:lowerCorner>
        		<gml:upperCorner>503465.984000 382127.133000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503465.984000 382127.133000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 278 160</ms:GML_ID>
        <ms:NAZWA>003 278 160</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003278160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504633.756601 378477.973233</gml:lowerCorner>
        		<gml:upperCorner>504633.756601 378477.973233</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504633.756601 378477.973233</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 282 060</ms:GML_ID>
        <ms:NAZWA>003 282 060</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003282060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504775.804000 377139.153000</gml:lowerCorner>
        		<gml:upperCorner>504775.804000 377139.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504775.804000 377139.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 283 404</ms:GML_ID>
        <ms:NAZWA>003 283 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003283404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504820.784979 376098.282928</gml:lowerCorner>
        		<gml:upperCorner>504820.784979 376098.282928</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504820.784979 376098.282928</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 284 454</ms:GML_ID>
        <ms:NAZWA>003 284 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003284454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505041.225000 374777.569000</gml:lowerCorner>
        		<gml:upperCorner>505041.225000 374777.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505041.225000 374777.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 285 790</ms:GML_ID>
        <ms:NAZWA>003 285 790</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003285790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510951.979082 370403.970433</gml:lowerCorner>
        		<gml:upperCorner>510951.979082 370403.970433</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510951.979082 370403.970433</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 008 714</ms:GML_ID>
        <ms:NAZWA>353 008 714</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353008714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511109.420712 370793.987435</gml:lowerCorner>
        		<gml:upperCorner>511109.420712 370793.987435</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511109.420712 370793.987435</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 009 143</ms:GML_ID>
        <ms:NAZWA>353 009 143</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353009143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>511689.200000 372283.840000</gml:lowerCorner>
        		<gml:upperCorner>511689.200000 372283.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>511689.200000 372283.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 010 738</ms:GML_ID>
        <ms:NAZWA>353 010 738</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353010738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512805.092000 375724.585000</gml:lowerCorner>
        		<gml:upperCorner>512805.092000 375724.585000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512805.092000 375724.585000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 014 375</ms:GML_ID>
        <ms:NAZWA>353 014 375</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353014375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512999.465587 377044.465948</gml:lowerCorner>
        		<gml:upperCorner>512999.465587 377044.465948</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512999.465587 377044.465948</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 015 702</ms:GML_ID>
        <ms:NAZWA>353 015 702</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353015702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513239.080469 378682.122265</gml:lowerCorner>
        		<gml:upperCorner>513239.080469 378682.122265</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513239.080469 378682.122265</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 017 364</ms:GML_ID>
        <ms:NAZWA>353 017 364</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353017364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513501.899000 380480.000000</gml:lowerCorner>
        		<gml:upperCorner>513501.899000 380480.000000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513501.899000 380480.000000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 019 185</ms:GML_ID>
        <ms:NAZWA>353 019 185</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353019185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513796.694000 382356.262000</gml:lowerCorner>
        		<gml:upperCorner>513796.694000 382356.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513796.694000 382356.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 021 080</ms:GML_ID>
        <ms:NAZWA>353 021 080</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353021080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514047.313000 383268.665000</gml:lowerCorner>
        		<gml:upperCorner>514047.313000 383268.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514047.313000 383268.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 022 026</ms:GML_ID>
        <ms:NAZWA>353 022 026</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353022026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514097.733000 383451.239000</gml:lowerCorner>
        		<gml:upperCorner>514097.733000 383451.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514097.733000 383451.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 022 219</ms:GML_ID>
        <ms:NAZWA>353 022 219</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353022219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514241.129000 383970.824000</gml:lowerCorner>
        		<gml:upperCorner>514241.129000 383970.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514241.129000 383970.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 022 759</ms:GML_ID>
        <ms:NAZWA>353 022 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353022759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4046">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483320.772000 395934.806321</gml:lowerCorner>
        		<gml:upperCorner>483320.772000 395934.806321</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4046.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483320.772000 395934.806321</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4046</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 121 475</ms:GML_ID>
        <ms:NAZWA>281 121 475</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281121475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4047">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485011.903903 396042.723548</gml:lowerCorner>
        		<gml:upperCorner>485011.903903 396042.723548</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4047.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485011.903903 396042.723548</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4047</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 123 175</ms:GML_ID>
        <ms:NAZWA>281 123 175</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281123175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4049">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486092.362000 396303.473000</gml:lowerCorner>
        		<gml:upperCorner>486092.362000 396303.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4049.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486092.362000 396303.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4049</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 124 299</ms:GML_ID>
        <ms:NAZWA>281 124 299</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281124299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>488390.322000 397552.425000</gml:lowerCorner>
        		<gml:upperCorner>488390.322000 397552.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>488390.322000 397552.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 126 919</ms:GML_ID>
        <ms:NAZWA>281 126 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281126919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>489562.736018 398188.313259</gml:lowerCorner>
        		<gml:upperCorner>489562.736018 398188.313259</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>489562.736018 398188.313259</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 128 252</ms:GML_ID>
        <ms:NAZWA>281 128 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281128252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491314.784681 399139.544994</gml:lowerCorner>
        		<gml:upperCorner>491314.784681 399139.544994</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491314.784681 399139.544994</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 130 247</ms:GML_ID>
        <ms:NAZWA>281 130 247</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281130247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491876.009000 399445.744000</gml:lowerCorner>
        		<gml:upperCorner>491876.009000 399445.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491876.009000 399445.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 130 884</ms:GML_ID>
        <ms:NAZWA>281 130 884</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281130884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496130.562000 399964.996000</gml:lowerCorner>
        		<gml:upperCorner>496130.562000 399964.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496130.562000 399964.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.808 002 359</ms:GML_ID>
        <ms:NAZWA>808 002 359</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>808002359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496629.819000 399125.233000</gml:lowerCorner>
        		<gml:upperCorner>496629.819000 399125.233000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496629.819000 399125.233000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.808 003 346</ms:GML_ID>
        <ms:NAZWA>808 003 346</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>808003346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497595.559995 401722.006739</gml:lowerCorner>
        		<gml:upperCorner>497595.559995 401722.006739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497595.559995 401722.006739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.807 001 541</ms:GML_ID>
        <ms:NAZWA>807 001 541</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>807001541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497651.848567 401656.232410</gml:lowerCorner>
        		<gml:upperCorner>497651.848567 401656.232410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497651.848567 401656.232410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 137 172</ms:GML_ID>
        <ms:NAZWA>281 137 172</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281137172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497916.065000 402174.757000</gml:lowerCorner>
        		<gml:upperCorner>497916.065000 402174.757000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497916.065000 402174.757000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.807 000 969</ms:GML_ID>
        <ms:NAZWA>807 000 969</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>807000969</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498537.832976 396276.923683</gml:lowerCorner>
        		<gml:upperCorner>498537.832976 396276.923683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498537.832976 396276.923683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 262 950</ms:GML_ID>
        <ms:NAZWA>003 262 950</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003262950</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499362.785000 401809.931000</gml:lowerCorner>
        		<gml:upperCorner>499362.785000 401809.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499362.785000 401809.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 138 905</ms:GML_ID>
        <ms:NAZWA>281 138 905</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281138905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499894.854000 391370.519000</gml:lowerCorner>
        		<gml:upperCorner>499894.854000 391370.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499894.854000 391370.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 268 094</ms:GML_ID>
        <ms:NAZWA>003 268 094</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>003268094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500511.187000 401903.783000</gml:lowerCorner>
        		<gml:upperCorner>500511.187000 401903.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500511.187000 401903.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 140 056</ms:GML_ID>
        <ms:NAZWA>281 140 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281140056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>501903.746000 402016.302000</gml:lowerCorner>
        		<gml:upperCorner>501903.746000 402016.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>501903.746000 402016.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 141 451</ms:GML_ID>
        <ms:NAZWA>281 141 451</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281141451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502565.799000 402070.192000</gml:lowerCorner>
        		<gml:upperCorner>502565.799000 402070.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502565.799000 402070.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 142 118</ms:GML_ID>
        <ms:NAZWA>281 142 118</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281142118</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>503221.548000 402123.047000</gml:lowerCorner>
        		<gml:upperCorner>503221.548000 402123.047000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>503221.548000 402123.047000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 142 773</ms:GML_ID>
        <ms:NAZWA>281 142 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281142773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504901.354000 402259.020000</gml:lowerCorner>
        		<gml:upperCorner>504901.354000 402259.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504901.354000 402259.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 144 460</ms:GML_ID>
        <ms:NAZWA>281 144 460</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281144460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>506977.897917 402427.092301</gml:lowerCorner>
        		<gml:upperCorner>506977.897917 402427.092301</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>506977.897917 402427.092301</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 146 542</ms:GML_ID>
        <ms:NAZWA>281 146 542</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281146542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509250.413822 402611.148380</gml:lowerCorner>
        		<gml:upperCorner>509250.413822 402611.148380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509250.413822 402611.148380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 148 828</ms:GML_ID>
        <ms:NAZWA>281 148 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281148828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510618.733474 402722.675187</gml:lowerCorner>
        		<gml:upperCorner>510618.733474 402722.675187</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510618.733474 402722.675187</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 150 188</ms:GML_ID>
        <ms:NAZWA>281 150 188</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281150188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512829.040000 402872.285000</gml:lowerCorner>
        		<gml:upperCorner>512829.040000 402872.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512829.040000 402872.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 152 415</ms:GML_ID>
        <ms:NAZWA>281 152 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281152415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>513813.374886 402923.343751</gml:lowerCorner>
        		<gml:upperCorner>513813.374886 402923.343751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>513813.374886 402923.343751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 153 396</ms:GML_ID>
        <ms:NAZWA>281 153 396</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281153396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514627.990000 385979.440000</gml:lowerCorner>
        		<gml:upperCorner>514627.990000 385979.440000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514627.990000 385979.440000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 024 804</ms:GML_ID>
        <ms:NAZWA>353 024 804</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353024804</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514818.012000 387036.651000</gml:lowerCorner>
        		<gml:upperCorner>514818.012000 387036.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514818.012000 387036.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 025 881</ms:GML_ID>
        <ms:NAZWA>353 025 881</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>353025881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476307.517534 347051.341154</gml:lowerCorner>
        		<gml:upperCorner>476307.517534 347051.341154</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476307.517534 347051.341154</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 132 321</ms:GML_ID>
        <ms:NAZWA>271 132 321</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271132321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480149.241780 348447.253157</gml:lowerCorner>
        		<gml:upperCorner>480149.241780 348447.253157</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480149.241780 348447.253157</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 136 557</ms:GML_ID>
        <ms:NAZWA>271 136 557</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271136557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481341.200312 349191.283188</gml:lowerCorner>
        		<gml:upperCorner>481341.200312 349191.283188</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481341.200312 349191.283188</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 137 965</ms:GML_ID>
        <ms:NAZWA>271 137 965</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271137965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482010.406775 349598.195893</gml:lowerCorner>
        		<gml:upperCorner>482010.406775 349598.195893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482010.406775 349598.195893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 138 750</ms:GML_ID>
        <ms:NAZWA>271 138 750</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271138750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485016.046000 351421.275000</gml:lowerCorner>
        		<gml:upperCorner>485016.046000 351421.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485016.046000 351421.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 142 265</ms:GML_ID>
        <ms:NAZWA>271 142 265</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271142265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486616.394000 352392.906000</gml:lowerCorner>
        		<gml:upperCorner>486616.394000 352392.906000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486616.394000 352392.906000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 144 133</ms:GML_ID>
        <ms:NAZWA>271 144 133</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271144133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471282.822000 364036.018000</gml:lowerCorner>
        		<gml:upperCorner>471282.822000 364036.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471282.822000 364036.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 033 670</ms:GML_ID>
        <ms:NAZWA>369 033 670</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369033670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470423.901000 364332.802000</gml:lowerCorner>
        		<gml:upperCorner>470423.901000 364332.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470423.901000 364332.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 032 740</ms:GML_ID>
        <ms:NAZWA>369 032 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369032740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469847.885000 364864.212000</gml:lowerCorner>
        		<gml:upperCorner>469847.885000 364864.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469847.885000 364864.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 031 947</ms:GML_ID>
        <ms:NAZWA>369 031 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369031947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468440.940000 365498.302000</gml:lowerCorner>
        		<gml:upperCorner>468440.940000 365498.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468440.940000 365498.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 030 394</ms:GML_ID>
        <ms:NAZWA>369 030 394</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369030394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468033.685000 365836.566000</gml:lowerCorner>
        		<gml:upperCorner>468033.685000 365836.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468033.685000 365836.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 029 852</ms:GML_ID>
        <ms:NAZWA>369 029 852</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369029852</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>467525.100000 366520.076000</gml:lowerCorner>
        		<gml:upperCorner>467525.100000 366520.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>467525.100000 366520.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 028 995</ms:GML_ID>
        <ms:NAZWA>369 028 995</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369028995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466536.499609 368466.256029</gml:lowerCorner>
        		<gml:upperCorner>466536.499609 368466.256029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466536.499609 368466.256029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 026 800</ms:GML_ID>
        <ms:NAZWA>369 026 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369026800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466338.879000 369615.529000</gml:lowerCorner>
        		<gml:upperCorner>466338.879000 369615.529000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466338.879000 369615.529000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 025 621</ms:GML_ID>
        <ms:NAZWA>369 025 621</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369025621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465846.057000 374273.711000</gml:lowerCorner>
        		<gml:upperCorner>465846.057000 374273.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465846.057000 374273.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 020 577</ms:GML_ID>
        <ms:NAZWA>369 020 577</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369020577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465955.040000 374650.048000</gml:lowerCorner>
        		<gml:upperCorner>465955.040000 374650.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465955.040000 374650.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 020 185</ms:GML_ID>
        <ms:NAZWA>369 020 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369020185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466048.661000 375942.961000</gml:lowerCorner>
        		<gml:upperCorner>466048.661000 375942.961000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466048.661000 375942.961000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 018 880</ms:GML_ID>
        <ms:NAZWA>369 018 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369018880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466039.456601 377162.350720</gml:lowerCorner>
        		<gml:upperCorner>466039.456601 377162.350720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466039.456601 377162.350720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 017 660</ms:GML_ID>
        <ms:NAZWA>369 017 660</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369017660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466022.202347 377367.875642</gml:lowerCorner>
        		<gml:upperCorner>466022.202347 377367.875642</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466022.202347 377367.875642</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 017 454</ms:GML_ID>
        <ms:NAZWA>369 017 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369017454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466184.457000 378612.866000</gml:lowerCorner>
        		<gml:upperCorner>466184.457000 378612.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466184.457000 378612.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 016 192</ms:GML_ID>
        <ms:NAZWA>369 016 192</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369016192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466252.648000 379833.552000</gml:lowerCorner>
        		<gml:upperCorner>466252.648000 379833.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466252.648000 379833.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 014 970</ms:GML_ID>
        <ms:NAZWA>369 014 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369014970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486475.977000 379965.913000</gml:lowerCorner>
        		<gml:upperCorner>486475.977000 379965.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486475.977000 379965.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 169 750</ms:GML_ID>
        <ms:NAZWA>272 169 750</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272169750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466028.919000 380342.370000</gml:lowerCorner>
        		<gml:upperCorner>466028.919000 380342.370000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466028.919000 380342.370000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 014 405</ms:GML_ID>
        <ms:NAZWA>369 014 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369014405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465668.140000 380806.588000</gml:lowerCorner>
        		<gml:upperCorner>465668.140000 380806.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465668.140000 380806.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 013 877</ms:GML_ID>
        <ms:NAZWA>369 013 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369013877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463758.746000 384651.884000</gml:lowerCorner>
        		<gml:upperCorner>463758.746000 384651.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463758.746000 384651.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 009 505</ms:GML_ID>
        <ms:NAZWA>369 009 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369009505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464132.410000 383811.814000</gml:lowerCorner>
        		<gml:upperCorner>464132.410000 383811.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464132.410000 383811.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 010 424</ms:GML_ID>
        <ms:NAZWA>369 010 424</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369010424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464523.261000 382929.386000</gml:lowerCorner>
        		<gml:upperCorner>464523.261000 382929.386000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464523.261000 382929.386000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 011 393</ms:GML_ID>
        <ms:NAZWA>369 011 393</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369011393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464815.723000 382269.949000</gml:lowerCorner>
        		<gml:upperCorner>464815.723000 382269.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464815.723000 382269.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 012 111</ms:GML_ID>
        <ms:NAZWA>369 012 111</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369012111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465062.628000 381712.838000</gml:lowerCorner>
        		<gml:upperCorner>465062.628000 381712.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465062.628000 381712.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 012 720</ms:GML_ID>
        <ms:NAZWA>369 012 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369012720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468062.292000 387097.503000</gml:lowerCorner>
        		<gml:upperCorner>468062.292000 387097.503000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468062.292000 387097.503000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 148 974</ms:GML_ID>
        <ms:NAZWA>272 148 974</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272148974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469970.952000 385960.140000</gml:lowerCorner>
        		<gml:upperCorner>469970.952000 385960.140000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469970.952000 385960.140000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 151 199</ms:GML_ID>
        <ms:NAZWA>272 151 199</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272151199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470494.544000 385756.275000</gml:lowerCorner>
        		<gml:upperCorner>470494.544000 385756.275000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470494.544000 385756.275000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 151 761</ms:GML_ID>
        <ms:NAZWA>272 151 761</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272151761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470933.264000 385591.833000</gml:lowerCorner>
        		<gml:upperCorner>470933.264000 385591.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470933.264000 385591.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 152 230</ms:GML_ID>
        <ms:NAZWA>272 152 230</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272152230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472081.942000 385159.401000</gml:lowerCorner>
        		<gml:upperCorner>472081.942000 385159.401000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472081.942000 385159.401000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 153 458</ms:GML_ID>
        <ms:NAZWA>272 153 458</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272153458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472845.857000 384961.714000</gml:lowerCorner>
        		<gml:upperCorner>472845.857000 384961.714000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472845.857000 384961.714000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 154 252</ms:GML_ID>
        <ms:NAZWA>272 154 252</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272154252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473986.102000 384724.523000</gml:lowerCorner>
        		<gml:upperCorner>473986.102000 384724.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473986.102000 384724.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 155 413</ms:GML_ID>
        <ms:NAZWA>272 155 413</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272155413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474775.527000 384560.029000</gml:lowerCorner>
        		<gml:upperCorner>474775.527000 384560.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474775.527000 384560.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 156 220</ms:GML_ID>
        <ms:NAZWA>272 156 220</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272156220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475254.400277 384463.202689</gml:lowerCorner>
        		<gml:upperCorner>475254.400277 384463.202689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475254.400277 384463.202689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 156 700</ms:GML_ID>
        <ms:NAZWA>272 156 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272156700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475880.243000 384332.576000</gml:lowerCorner>
        		<gml:upperCorner>475880.243000 384332.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475880.243000 384332.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 157 348</ms:GML_ID>
        <ms:NAZWA>272 157 348</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272157348</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476881.120000 384168.215000</gml:lowerCorner>
        		<gml:upperCorner>476881.120000 384168.215000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476881.120000 384168.215000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 158 365</ms:GML_ID>
        <ms:NAZWA>272 158 365</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272158365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478117.158615 383965.141921</gml:lowerCorner>
        		<gml:upperCorner>478117.158615 383965.141921</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478117.158615 383965.141921</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 159 617</ms:GML_ID>
        <ms:NAZWA>272 159 617</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272159617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478945.840898 383599.572463</gml:lowerCorner>
        		<gml:upperCorner>478945.840898 383599.572463</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478945.840898 383599.572463</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 160 524</ms:GML_ID>
        <ms:NAZWA>272 160 524</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272160524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481584.679000 382948.546000</gml:lowerCorner>
        		<gml:upperCorner>481584.679000 382948.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481584.679000 382948.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 163 320</ms:GML_ID>
        <ms:NAZWA>272 163 320</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272163320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483573.846000 383110.212000</gml:lowerCorner>
        		<gml:upperCorner>483573.846000 383110.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483573.846000 383110.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 165 318</ms:GML_ID>
        <ms:NAZWA>272 165 318</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272165318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484763.394000 382433.144000</gml:lowerCorner>
        		<gml:upperCorner>484763.394000 382433.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484763.394000 382433.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 166 734</ms:GML_ID>
        <ms:NAZWA>272 166 734</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272166734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485383.518055 381620.322983</gml:lowerCorner>
        		<gml:upperCorner>485383.518055 381620.322983</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485383.518055 381620.322983</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 167 758</ms:GML_ID>
        <ms:NAZWA>272 167 758</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272167758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455504.496881 387787.874334</gml:lowerCorner>
        		<gml:upperCorner>455504.496881 387787.874334</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455504.496881 387787.874334</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 009 607</ms:GML_ID>
        <ms:NAZWA>360 009 607</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360009607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455645.265212 388222.291957</gml:lowerCorner>
        		<gml:upperCorner>455645.265212 388222.291957</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455645.265212 388222.291957</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 009 152</ms:GML_ID>
        <ms:NAZWA>360 009 152</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360009152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455902.325000 389035.870000</gml:lowerCorner>
        		<gml:upperCorner>455902.325000 389035.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455902.325000 389035.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 008 291</ms:GML_ID>
        <ms:NAZWA>360 008 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360008291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456085.956811 389604.216379</gml:lowerCorner>
        		<gml:upperCorner>456085.956811 389604.216379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456085.956811 389604.216379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 007 697</ms:GML_ID>
        <ms:NAZWA>360 007 697</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360007697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456478.224000 390826.201000</gml:lowerCorner>
        		<gml:upperCorner>456478.224000 390826.201000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456478.224000 390826.201000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 006 415</ms:GML_ID>
        <ms:NAZWA>360 006 415</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360006415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456539.447000 391059.546000</gml:lowerCorner>
        		<gml:upperCorner>456539.447000 391059.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456539.447000 391059.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 006 173</ms:GML_ID>
        <ms:NAZWA>360 006 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360006173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456646.059000 391465.466000</gml:lowerCorner>
        		<gml:upperCorner>456646.059000 391465.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456646.059000 391465.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 005 754</ms:GML_ID>
        <ms:NAZWA>360 005 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360005754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456798.370000 392045.255000</gml:lowerCorner>
        		<gml:upperCorner>456798.370000 392045.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456798.370000 392045.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 005 153</ms:GML_ID>
        <ms:NAZWA>360 005 153</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360005153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456864.714134 392298.502238</gml:lowerCorner>
        		<gml:upperCorner>456864.714134 392298.502238</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456864.714134 392298.502238</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 004 892</ms:GML_ID>
        <ms:NAZWA>360 004 892</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360004892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461852.416000 389068.979000</gml:lowerCorner>
        		<gml:upperCorner>461852.416000 389068.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461852.416000 389068.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 004 687</ms:GML_ID>
        <ms:NAZWA>369 004 687</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369004687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462043.750000 388517.395000</gml:lowerCorner>
        		<gml:upperCorner>462043.750000 388517.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462043.750000 388517.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 005 271</ms:GML_ID>
        <ms:NAZWA>369 005 271</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369005271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462267.573000 390619.851000</gml:lowerCorner>
        		<gml:upperCorner>462267.573000 390619.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462267.573000 390619.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 003 066</ms:GML_ID>
        <ms:NAZWA>369 003 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369003066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462407.326000 387698.149000</gml:lowerCorner>
        		<gml:upperCorner>462407.326000 387698.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462407.326000 387698.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 006 170</ms:GML_ID>
        <ms:NAZWA>369 006 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369006170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462468.536000 390858.607000</gml:lowerCorner>
        		<gml:upperCorner>462468.536000 390858.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462468.536000 390858.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 002 753</ms:GML_ID>
        <ms:NAZWA>369 002 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369002753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463079.051000 391531.850000</gml:lowerCorner>
        		<gml:upperCorner>463079.051000 391531.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463079.051000 391531.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 001 845</ms:GML_ID>
        <ms:NAZWA>369 001 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369001845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463388.545000 391871.729000</gml:lowerCorner>
        		<gml:upperCorner>463388.545000 391871.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463388.545000 391871.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 001 386</ms:GML_ID>
        <ms:NAZWA>369 001 386</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369001386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463583.706891 392272.351276</gml:lowerCorner>
        		<gml:upperCorner>463583.706891 392272.351276</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463583.706891 392272.351276</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 000 927</ms:GML_ID>
        <ms:NAZWA>369 000 927</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369000927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463691.834000 392375.153000</gml:lowerCorner>
        		<gml:upperCorner>463691.834000 392375.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463691.834000 392375.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 141 861</ms:GML_ID>
        <ms:NAZWA>272 141 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272141861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464215.991000 391814.891000</gml:lowerCorner>
        		<gml:upperCorner>464215.991000 391814.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464215.991000 391814.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 142 632</ms:GML_ID>
        <ms:NAZWA>272 142 632</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272142632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465159.411000 390804.168000</gml:lowerCorner>
        		<gml:upperCorner>465159.411000 390804.168000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465159.411000 390804.168000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 144 017</ms:GML_ID>
        <ms:NAZWA>272 144 017</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272144017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466146.943000 389116.255000</gml:lowerCorner>
        		<gml:upperCorner>466146.943000 389116.255000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466146.943000 389116.255000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 145 999</ms:GML_ID>
        <ms:NAZWA>272 145 999</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272145999</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466548.502000 388044.601000</gml:lowerCorner>
        		<gml:upperCorner>466548.502000 388044.601000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466548.502000 388044.601000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 147 145</ms:GML_ID>
        <ms:NAZWA>272 147 145</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272147145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452541.189000 379419.305000</gml:lowerCorner>
        		<gml:upperCorner>452541.189000 379419.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452541.189000 379419.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 018 543</ms:GML_ID>
        <ms:NAZWA>360 018 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360018543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452745.269475 379766.360974</gml:lowerCorner>
        		<gml:upperCorner>452745.269475 379766.360974</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452745.269475 379766.360974</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 018 140</ms:GML_ID>
        <ms:NAZWA>360 018 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360018140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452944.847000 380105.153000</gml:lowerCorner>
        		<gml:upperCorner>452944.847000 380105.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452944.847000 380105.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 017 746</ms:GML_ID>
        <ms:NAZWA>360 017 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360017746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453638.630000 381295.614000</gml:lowerCorner>
        		<gml:upperCorner>453638.630000 381295.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453638.630000 381295.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 016 368</ms:GML_ID>
        <ms:NAZWA>360 016 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360016368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453713.883246 381469.382504</gml:lowerCorner>
        		<gml:upperCorner>453713.883246 381469.382504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453713.883246 381469.382504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 016 179</ms:GML_ID>
        <ms:NAZWA>360 016 179</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360016179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453821.292000 381823.123000</gml:lowerCorner>
        		<gml:upperCorner>453821.292000 381823.123000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453821.292000 381823.123000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 015 809</ms:GML_ID>
        <ms:NAZWA>360 015 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360015809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453994.880177 382449.350222</gml:lowerCorner>
        		<gml:upperCorner>453994.880177 382449.350222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453994.880177 382449.350222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 015 158</ms:GML_ID>
        <ms:NAZWA>360 015 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360015158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454288.813472 383509.137859</gml:lowerCorner>
        		<gml:upperCorner>454288.813472 383509.137859</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454288.813472 383509.137859</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 014 057</ms:GML_ID>
        <ms:NAZWA>360 014 057</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360014057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454383.881000 383851.157000</gml:lowerCorner>
        		<gml:upperCorner>454383.881000 383851.157000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454383.881000 383851.157000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 013 703</ms:GML_ID>
        <ms:NAZWA>360 013 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360013703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454511.599777 384310.852128</gml:lowerCorner>
        		<gml:upperCorner>454511.599777 384310.852128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454511.599777 384310.852128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 013 226</ms:GML_ID>
        <ms:NAZWA>360 013 226</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360013226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454634.112113 384752.191134</gml:lowerCorner>
        		<gml:upperCorner>454634.112113 384752.191134</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454634.112113 384752.191134</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 012 768</ms:GML_ID>
        <ms:NAZWA>360 012 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360012768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463567.062000 385084.205000</gml:lowerCorner>
        		<gml:upperCorner>463567.062000 385084.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463567.062000 385084.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 009 031</ms:GML_ID>
        <ms:NAZWA>369 009 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369009031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454753.769000 385183.299000</gml:lowerCorner>
        		<gml:upperCorner>454753.769000 385183.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454753.769000 385183.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 012 320</ms:GML_ID>
        <ms:NAZWA>360 012 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360012320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454855.935318 385550.556952</gml:lowerCorner>
        		<gml:upperCorner>454855.935318 385550.556952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454855.935318 385550.556952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 011 938</ms:GML_ID>
        <ms:NAZWA>360 011 938</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360011938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454989.717539 386030.605624</gml:lowerCorner>
        		<gml:upperCorner>454989.717539 386030.605624</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454989.717539 386030.605624</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 011 439</ms:GML_ID>
        <ms:NAZWA>360 011 439</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360011439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463046.516000 386258.159000</gml:lowerCorner>
        		<gml:upperCorner>463046.516000 386258.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463046.516000 386258.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.369 007 746</ms:GML_ID>
        <ms:NAZWA>369 007 746</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>369007746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455115.890000 386482.178000</gml:lowerCorner>
        		<gml:upperCorner>455115.890000 386482.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455115.890000 386482.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 010 970</ms:GML_ID>
        <ms:NAZWA>360 010 970</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360010970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455224.234000 386873.148000</gml:lowerCorner>
        		<gml:upperCorner>455224.234000 386873.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455224.234000 386873.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 010 565</ms:GML_ID>
        <ms:NAZWA>360 010 565</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360010565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446780.064403 347747.405566</gml:lowerCorner>
        		<gml:upperCorner>446780.064403 347747.405566</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446780.064403 347747.405566</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 051 599</ms:GML_ID>
        <ms:NAZWA>360 051 599</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360051599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447116.018572 349233.795056</gml:lowerCorner>
        		<gml:upperCorner>447116.018572 349233.795056</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447116.018572 349233.795056</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 050 066</ms:GML_ID>
        <ms:NAZWA>360 050 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360050066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447478.887000 350354.574000</gml:lowerCorner>
        		<gml:upperCorner>447478.887000 350354.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447478.887000 350354.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 048 887</ms:GML_ID>
        <ms:NAZWA>360 048 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360048887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447522.697000 351116.120000</gml:lowerCorner>
        		<gml:upperCorner>447522.697000 351116.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447522.697000 351116.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 048 124</ms:GML_ID>
        <ms:NAZWA>360 048 124</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360048124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447553.079706 351693.164045</gml:lowerCorner>
        		<gml:upperCorner>447553.079706 351693.164045</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447553.079706 351693.164045</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 047 544</ms:GML_ID>
        <ms:NAZWA>360 047 544</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360047544</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447619.128000 352981.299000</gml:lowerCorner>
        		<gml:upperCorner>447619.128000 352981.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447619.128000 352981.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 046 256</ms:GML_ID>
        <ms:NAZWA>360 046 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360046256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447650.476000 353602.425000</gml:lowerCorner>
        		<gml:upperCorner>447650.476000 353602.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447650.476000 353602.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 045 633</ms:GML_ID>
        <ms:NAZWA>360 045 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360045633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447782.209000 355232.327000</gml:lowerCorner>
        		<gml:upperCorner>447782.209000 355232.327000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447782.209000 355232.327000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 043 996</ms:GML_ID>
        <ms:NAZWA>360 043 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360043996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447877.265000 355819.839000</gml:lowerCorner>
        		<gml:upperCorner>447877.265000 355819.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447877.265000 355819.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 043 400</ms:GML_ID>
        <ms:NAZWA>360 043 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360043400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448186.954364 357742.673170</gml:lowerCorner>
        		<gml:upperCorner>448186.954364 357742.673170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448186.954364 357742.673170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 041 452</ms:GML_ID>
        <ms:NAZWA>360 041 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360041452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448227.486000 358060.405000</gml:lowerCorner>
        		<gml:upperCorner>448227.486000 358060.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448227.486000 358060.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 041 129</ms:GML_ID>
        <ms:NAZWA>360 041 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360041129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448107.476192 359120.513323</gml:lowerCorner>
        		<gml:upperCorner>448107.476192 359120.513323</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448107.476192 359120.513323</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 040 054</ms:GML_ID>
        <ms:NAZWA>360 040 054</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360040054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448198.840603 359579.101220</gml:lowerCorner>
        		<gml:upperCorner>448198.840603 359579.101220</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448198.840603 359579.101220</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 039 586</ms:GML_ID>
        <ms:NAZWA>360 039 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360039586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448345.625526 361908.905059</gml:lowerCorner>
        		<gml:upperCorner>448345.625526 361908.905059</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448345.625526 361908.905059</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 037 228</ms:GML_ID>
        <ms:NAZWA>360 037 228</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360037228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448251.702807 362912.813851</gml:lowerCorner>
        		<gml:upperCorner>448251.702807 362912.813851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448251.702807 362912.813851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 036 196</ms:GML_ID>
        <ms:NAZWA>360 036 196</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360036196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448237.926090 363189.421658</gml:lowerCorner>
        		<gml:upperCorner>448237.926090 363189.421658</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448237.926090 363189.421658</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 035 942</ms:GML_ID>
        <ms:NAZWA>360 035 942</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360035942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448177.190263 363407.254212</gml:lowerCorner>
        		<gml:upperCorner>448177.190263 363407.254212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448177.190263 363407.254212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 035 714</ms:GML_ID>
        <ms:NAZWA>360 035 714</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360035714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448049.575000 363601.628000</gml:lowerCorner>
        		<gml:upperCorner>448049.575000 363601.628000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448049.575000 363601.628000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 035 481</ms:GML_ID>
        <ms:NAZWA>360 035 481</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360035481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447769.926176 364025.998208</gml:lowerCorner>
        		<gml:upperCorner>447769.926176 364025.998208</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447769.926176 364025.998208</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 034 974</ms:GML_ID>
        <ms:NAZWA>360 034 974</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360034974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447781.415000 364491.891000</gml:lowerCorner>
        		<gml:upperCorner>447781.415000 364491.891000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447781.415000 364491.891000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 034 494</ms:GML_ID>
        <ms:NAZWA>360 034 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360034494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447841.738163 364730.944336</gml:lowerCorner>
        		<gml:upperCorner>447841.738163 364730.944336</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447841.738163 364730.944336</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 034 249</ms:GML_ID>
        <ms:NAZWA>360 034 249</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360034249</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447972.033000 365495.701000</gml:lowerCorner>
        		<gml:upperCorner>447972.033000 365495.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447972.033000 365495.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 033 469</ms:GML_ID>
        <ms:NAZWA>360 033 469</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360033469</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447972.205000 366082.971000</gml:lowerCorner>
        		<gml:upperCorner>447972.205000 366082.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447972.205000 366082.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 032 882</ms:GML_ID>
        <ms:NAZWA>360 032 882</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360032882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447943.430000 367057.112000</gml:lowerCorner>
        		<gml:upperCorner>447943.430000 367057.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447943.430000 367057.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 031 907</ms:GML_ID>
        <ms:NAZWA>360 031 907</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360031907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447943.022000 367509.135000</gml:lowerCorner>
        		<gml:upperCorner>447943.022000 367509.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447943.022000 367509.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 031 454</ms:GML_ID>
        <ms:NAZWA>360 031 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360031454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448145.897000 368708.495000</gml:lowerCorner>
        		<gml:upperCorner>448145.897000 368708.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448145.897000 368708.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 030 231</ms:GML_ID>
        <ms:NAZWA>360 030 231</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360030231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448182.958000 369132.083000</gml:lowerCorner>
        		<gml:upperCorner>448182.958000 369132.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448182.958000 369132.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 029 806</ms:GML_ID>
        <ms:NAZWA>360 029 806</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360029806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448200.361346 369328.868497</gml:lowerCorner>
        		<gml:upperCorner>448200.361346 369328.868497</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448200.361346 369328.868497</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 029 608</ms:GML_ID>
        <ms:NAZWA>360 029 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360029608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448276.344000 369716.587000</gml:lowerCorner>
        		<gml:upperCorner>448276.344000 369716.587000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448276.344000 369716.587000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 029 212</ms:GML_ID>
        <ms:NAZWA>360 029 212</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360029212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448356.051000 369949.120000</gml:lowerCorner>
        		<gml:upperCorner>448356.051000 369949.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448356.051000 369949.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 028 967</ms:GML_ID>
        <ms:NAZWA>360 028 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360028967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448721.458812 371019.250727</gml:lowerCorner>
        		<gml:upperCorner>448721.458812 371019.250727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448721.458812 371019.250727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 027 835</ms:GML_ID>
        <ms:NAZWA>360 027 835</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360027835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448793.329736 371358.098827</gml:lowerCorner>
        		<gml:upperCorner>448793.329736 371358.098827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448793.329736 371358.098827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 027 488</ms:GML_ID>
        <ms:NAZWA>360 027 488</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360027488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448884.344500 371794.912871</gml:lowerCorner>
        		<gml:upperCorner>448884.344500 371794.912871</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448884.344500 371794.912871</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 027 042</ms:GML_ID>
        <ms:NAZWA>360 027 042</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360027042</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448991.533000 372310.728000</gml:lowerCorner>
        		<gml:upperCorner>448991.533000 372310.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448991.533000 372310.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 026 515</ms:GML_ID>
        <ms:NAZWA>360 026 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360026515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430929.268000 372360.570000</gml:lowerCorner>
        		<gml:upperCorner>430929.268000 372360.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430929.268000 372360.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 185 445</ms:GML_ID>
        <ms:NAZWA>014 185 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014185445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449153.931000 372872.922000</gml:lowerCorner>
        		<gml:upperCorner>449153.931000 372872.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449153.931000 372872.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 025 926</ms:GML_ID>
        <ms:NAZWA>360 025 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360025926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449417.817000 373449.231000</gml:lowerCorner>
        		<gml:upperCorner>449417.817000 373449.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449417.817000 373449.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 025 292</ms:GML_ID>
        <ms:NAZWA>360 025 292</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360025292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449537.101000 373709.551000</gml:lowerCorner>
        		<gml:upperCorner>449537.101000 373709.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449537.101000 373709.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 025 005</ms:GML_ID>
        <ms:NAZWA>360 025 005</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360025005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449628.608000 373908.903000</gml:lowerCorner>
        		<gml:upperCorner>449628.608000 373908.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449628.608000 373908.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 024 787</ms:GML_ID>
        <ms:NAZWA>360 024 787</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360024787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449899.628000 374501.608000</gml:lowerCorner>
        		<gml:upperCorner>449899.628000 374501.608000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449899.628000 374501.608000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 024 134</ms:GML_ID>
        <ms:NAZWA>360 024 134</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360024134</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450305.725000 375390.035000</gml:lowerCorner>
        		<gml:upperCorner>450305.725000 375390.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450305.725000 375390.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 023 157</ms:GML_ID>
        <ms:NAZWA>360 023 157</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360023157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450726.096000 376309.546000</gml:lowerCorner>
        		<gml:upperCorner>450726.096000 376309.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450726.096000 376309.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 022 145</ms:GML_ID>
        <ms:NAZWA>360 022 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360022145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450950.078000 376714.422000</gml:lowerCorner>
        		<gml:upperCorner>450950.078000 376714.422000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450950.078000 376714.422000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 021 682</ms:GML_ID>
        <ms:NAZWA>360 021 682</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360021682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451159.524322 377070.972564</gml:lowerCorner>
        		<gml:upperCorner>451159.524322 377070.972564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451159.524322 377070.972564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 021 269</ms:GML_ID>
        <ms:NAZWA>360 021 269</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360021269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451496.544620 377644.041790</gml:lowerCorner>
        		<gml:upperCorner>451496.544620 377644.041790</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451496.544620 377644.041790</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 020 603</ms:GML_ID>
        <ms:NAZWA>360 020 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360020603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451927.506429 378376.675571</gml:lowerCorner>
        		<gml:upperCorner>451927.506429 378376.675571</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451927.506429 378376.675571</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 019 753</ms:GML_ID>
        <ms:NAZWA>360 019 753</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360019753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452356.997000 379106.043000</gml:lowerCorner>
        		<gml:upperCorner>452356.997000 379106.043000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452356.997000 379106.043000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 018 906</ms:GML_ID>
        <ms:NAZWA>360 018 906</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360018906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425384.274000 368336.723000</gml:lowerCorner>
        		<gml:upperCorner>425384.274000 368336.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425384.274000 368336.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 011 847</ms:GML_ID>
        <ms:NAZWA>362 011 847</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362011847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425511.579000 368006.737000</gml:lowerCorner>
        		<gml:upperCorner>425511.579000 368006.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425511.579000 368006.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 012 202</ms:GML_ID>
        <ms:NAZWA>362 012 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362012202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425573.067000 367876.271000</gml:lowerCorner>
        		<gml:upperCorner>425573.067000 367876.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425573.067000 367876.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 012 345</ms:GML_ID>
        <ms:NAZWA>362 012 345</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362012345</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425609.222000 366137.827000</gml:lowerCorner>
        		<gml:upperCorner>425609.222000 366137.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425609.222000 366137.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 014 211</ms:GML_ID>
        <ms:NAZWA>362 014 211</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362014211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425631.113000 367761.448000</gml:lowerCorner>
        		<gml:upperCorner>425631.113000 367761.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425631.113000 367761.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 012 474</ms:GML_ID>
        <ms:NAZWA>362 012 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362012474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425906.228000 367018.575000</gml:lowerCorner>
        		<gml:upperCorner>425906.228000 367018.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425906.228000 367018.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 013 274</ms:GML_ID>
        <ms:NAZWA>362 013 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362013274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431716.792000 369862.606000</gml:lowerCorner>
        		<gml:upperCorner>431716.792000 369862.606000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431716.792000 369862.606000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 188 064</ms:GML_ID>
        <ms:NAZWA>014 188 064</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014188064</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431952.428622 369138.506948</gml:lowerCorner>
        		<gml:upperCorner>431952.428622 369138.506948</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431952.428622 369138.506948</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 188 829</ms:GML_ID>
        <ms:NAZWA>014 188 829</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014188829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432227.538000 368249.996000</gml:lowerCorner>
        		<gml:upperCorner>432227.538000 368249.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432227.538000 368249.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 189 758</ms:GML_ID>
        <ms:NAZWA>014 189 758</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014189758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432507.294000 367375.496000</gml:lowerCorner>
        		<gml:upperCorner>432507.294000 367375.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432507.294000 367375.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 190 675</ms:GML_ID>
        <ms:NAZWA>014 190 675</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014190675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433229.480000 365407.177000</gml:lowerCorner>
        		<gml:upperCorner>433229.480000 365407.177000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433229.480000 365407.177000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 192 772</ms:GML_ID>
        <ms:NAZWA>014 192 772</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014192772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433481.552000 364540.750000</gml:lowerCorner>
        		<gml:upperCorner>433481.552000 364540.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433481.552000 364540.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 193 680</ms:GML_ID>
        <ms:NAZWA>014 193 680</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014193680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433694.397000 363712.438000</gml:lowerCorner>
        		<gml:upperCorner>433694.397000 363712.438000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433694.397000 363712.438000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 194 533</ms:GML_ID>
        <ms:NAZWA>014 194 533</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014194533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433904.988000 362879.898000</gml:lowerCorner>
        		<gml:upperCorner>433904.988000 362879.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433904.988000 362879.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 195 389</ms:GML_ID>
        <ms:NAZWA>014 195 389</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014195389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434336.940000 361164.381000</gml:lowerCorner>
        		<gml:upperCorner>434336.940000 361164.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434336.940000 361164.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 197 161</ms:GML_ID>
        <ms:NAZWA>014 197 161</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014197161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434400.145000 360637.565000</gml:lowerCorner>
        		<gml:upperCorner>434400.145000 360637.565000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434400.145000 360637.565000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 197 692</ms:GML_ID>
        <ms:NAZWA>014 197 692</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014197692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434500.738598 359748.853466</gml:lowerCorner>
        		<gml:upperCorner>434500.738598 359748.853466</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434500.738598 359748.853466</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 198 589</ms:GML_ID>
        <ms:NAZWA>014 198 589</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014198589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434540.819345 359055.946359</gml:lowerCorner>
        		<gml:upperCorner>434540.819345 359055.946359</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434540.819345 359055.946359</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 199 279</ms:GML_ID>
        <ms:NAZWA>014 199 279</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014199279</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423652.040000 403001.354000</gml:lowerCorner>
        		<gml:upperCorner>423652.040000 403001.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423652.040000 403001.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 151 727</ms:GML_ID>
        <ms:NAZWA>014 151 727</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014151727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424695.544000 400050.991000</gml:lowerCorner>
        		<gml:upperCorner>424695.544000 400050.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424695.544000 400050.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 154 859</ms:GML_ID>
        <ms:NAZWA>014 154 859</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014154859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424799.923000 399751.889000</gml:lowerCorner>
        		<gml:upperCorner>424799.923000 399751.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424799.923000 399751.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 155 177</ms:GML_ID>
        <ms:NAZWA>014 155 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014155177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425122.550000 398836.558000</gml:lowerCorner>
        		<gml:upperCorner>425122.550000 398836.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425122.550000 398836.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 156 145</ms:GML_ID>
        <ms:NAZWA>014 156 145</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014156145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425639.593000 397378.957000</gml:lowerCorner>
        		<gml:upperCorner>425639.593000 397378.957000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425639.593000 397378.957000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 157 695</ms:GML_ID>
        <ms:NAZWA>014 157 695</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014157695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426107.228000 396639.992000</gml:lowerCorner>
        		<gml:upperCorner>426107.228000 396639.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426107.228000 396639.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 158 576</ms:GML_ID>
        <ms:NAZWA>014 158 576</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014158576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427123.034101 395095.799314</gml:lowerCorner>
        		<gml:upperCorner>427123.034101 395095.799314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427123.034101 395095.799314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 160 421</ms:GML_ID>
        <ms:NAZWA>014 160 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014160421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427485.896151 394179.986136</gml:lowerCorner>
        		<gml:upperCorner>427485.896151 394179.986136</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427485.896151 394179.986136</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 161 416</ms:GML_ID>
        <ms:NAZWA>014 161 416</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014161416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427713.998476 393142.933538</gml:lowerCorner>
        		<gml:upperCorner>427713.998476 393142.933538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427713.998476 393142.933538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 162 471</ms:GML_ID>
        <ms:NAZWA>014 162 471</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014162471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427957.083971 392156.682020</gml:lowerCorner>
        		<gml:upperCorner>427957.083971 392156.682020</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427957.083971 392156.682020</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 163 491</ms:GML_ID>
        <ms:NAZWA>014 163 491</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014163491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.199">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433447.905000 392109.431000</gml:lowerCorner>
        		<gml:upperCorner>433447.905000 392109.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.199.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433447.905000 392109.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>199</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 070 262</ms:GML_ID>
        <ms:NAZWA>281 070 262</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281070262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.200">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434232.786000 392173.729000</gml:lowerCorner>
        		<gml:upperCorner>434232.786000 392173.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.200.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434232.786000 392173.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>200</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 071 049</ms:GML_ID>
        <ms:NAZWA>281 071 049</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281071049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.201">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434954.217000 392233.716000</gml:lowerCorner>
        		<gml:upperCorner>434954.217000 392233.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.201.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434954.217000 392233.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>201</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 071 775</ms:GML_ID>
        <ms:NAZWA>281 071 775</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281071775</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.202">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435902.417000 392312.310000</gml:lowerCorner>
        		<gml:upperCorner>435902.417000 392312.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.202.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435902.417000 392312.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>202</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 072 726</ms:GML_ID>
        <ms:NAZWA>281 072 726</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281072726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.203">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>437558.498000 392448.289000</gml:lowerCorner>
        		<gml:upperCorner>437558.498000 392448.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.203.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>437558.498000 392448.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>203</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 074 389</ms:GML_ID>
        <ms:NAZWA>281 074 389</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281074389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438777.778000 392549.234000</gml:lowerCorner>
        		<gml:upperCorner>438777.778000 392549.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438777.778000 392549.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 075 612</ms:GML_ID>
        <ms:NAZWA>281 075 612</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281075612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440050.581000 392654.513000</gml:lowerCorner>
        		<gml:upperCorner>440050.581000 392654.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440050.581000 392654.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 076 894</ms:GML_ID>
        <ms:NAZWA>281 076 894</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281076894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440943.000000 392728.284000</gml:lowerCorner>
        		<gml:upperCorner>440943.000000 392728.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440943.000000 392728.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 077 784</ms:GML_ID>
        <ms:NAZWA>281 077 784</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281077784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441489.050776 392772.696018</gml:lowerCorner>
        		<gml:upperCorner>441489.050776 392772.696018</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441489.050776 392772.696018</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 078 334</ms:GML_ID>
        <ms:NAZWA>281 078 334</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281078334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442480.651081 392848.939238</gml:lowerCorner>
        		<gml:upperCorner>442480.651081 392848.939238</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442480.651081 392848.939238</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 079 325</ms:GML_ID>
        <ms:NAZWA>281 079 325</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281079325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443666.239000 392954.111000</gml:lowerCorner>
        		<gml:upperCorner>443666.239000 392954.111000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443666.239000 392954.111000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 080 570</ms:GML_ID>
        <ms:NAZWA>281 080 570</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281080570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444746.936000 393043.771000</gml:lowerCorner>
        		<gml:upperCorner>444746.936000 393043.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444746.936000 393043.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 081 606</ms:GML_ID>
        <ms:NAZWA>281 081 606</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281081606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445286.406000 393088.356000</gml:lowerCorner>
        		<gml:upperCorner>445286.406000 393088.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445286.406000 393088.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 082 148</ms:GML_ID>
        <ms:NAZWA>281 082 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281082148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446408.709000 393182.768000</gml:lowerCorner>
        		<gml:upperCorner>446408.709000 393182.768000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446408.709000 393182.768000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 083 274</ms:GML_ID>
        <ms:NAZWA>281 083 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281083274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448044.784000 393318.102000</gml:lowerCorner>
        		<gml:upperCorner>448044.784000 393318.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448044.784000 393318.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 084 916</ms:GML_ID>
        <ms:NAZWA>281 084 916</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281084916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449463.199000 393778.659000</gml:lowerCorner>
        		<gml:upperCorner>449463.199000 393778.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449463.199000 393778.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 086 430</ms:GML_ID>
        <ms:NAZWA>281 086 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281086430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450444.446000 394287.189000</gml:lowerCorner>
        		<gml:upperCorner>450444.446000 394287.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450444.446000 394287.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 087 530</ms:GML_ID>
        <ms:NAZWA>281 087 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281087530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451542.636000 394857.504000</gml:lowerCorner>
        		<gml:upperCorner>451542.636000 394857.504000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451542.636000 394857.504000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 088 773</ms:GML_ID>
        <ms:NAZWA>281 088 773</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281088773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451567.075000 405200.395000</gml:lowerCorner>
        		<gml:upperCorner>451567.075000 405200.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451567.075000 405200.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 122 501</ms:GML_ID>
        <ms:NAZWA>272 122 501</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272122501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452226.661000 404179.269000</gml:lowerCorner>
        		<gml:upperCorner>452226.661000 404179.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452226.661000 404179.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 123 718</ms:GML_ID>
        <ms:NAZWA>272 123 718</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272123718</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452429.217000 403566.188000</gml:lowerCorner>
        		<gml:upperCorner>452429.217000 403566.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452429.217000 403566.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 124 365</ms:GML_ID>
        <ms:NAZWA>272 124 365</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272124365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452433.439000 395318.114000</gml:lowerCorner>
        		<gml:upperCorner>452433.439000 395318.114000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452433.439000 395318.114000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 089 776</ms:GML_ID>
        <ms:NAZWA>281 089 776</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281089776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452877.036000 402159.390000</gml:lowerCorner>
        		<gml:upperCorner>452877.036000 402159.390000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452877.036000 402159.390000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 125 841</ms:GML_ID>
        <ms:NAZWA>272 125 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272125841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453215.066000 401096.326000</gml:lowerCorner>
        		<gml:upperCorner>453215.066000 401096.326000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453215.066000 401096.326000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 126 957</ms:GML_ID>
        <ms:NAZWA>272 126 957</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272126957</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422346.430000 358827.890000</gml:lowerCorner>
        		<gml:upperCorner>422346.430000 358827.890000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422346.430000 358827.890000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 022 267</ms:GML_ID>
        <ms:NAZWA>362 022 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362022267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422558.870000 359219.431000</gml:lowerCorner>
        		<gml:upperCorner>422558.870000 359219.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422558.870000 359219.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 021 828</ms:GML_ID>
        <ms:NAZWA>362 021 828</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362021828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422783.148000 359632.032000</gml:lowerCorner>
        		<gml:upperCorner>422783.148000 359632.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422783.148000 359632.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 021 332</ms:GML_ID>
        <ms:NAZWA>362 021 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362021332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423121.277000 360255.261000</gml:lowerCorner>
        		<gml:upperCorner>423121.277000 360255.261000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423121.277000 360255.261000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 020 641</ms:GML_ID>
        <ms:NAZWA>362 020 641</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362020641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423436.330000 360834.097000</gml:lowerCorner>
        		<gml:upperCorner>423436.330000 360834.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423436.330000 360834.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 019 982</ms:GML_ID>
        <ms:NAZWA>362 019 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362019982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423514.552000 360989.100000</gml:lowerCorner>
        		<gml:upperCorner>423514.552000 360989.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423514.552000 360989.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 019 808</ms:GML_ID>
        <ms:NAZWA>362 019 808</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362019808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423630.392000 361323.382000</gml:lowerCorner>
        		<gml:upperCorner>423630.392000 361323.382000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423630.392000 361323.382000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 019 453</ms:GML_ID>
        <ms:NAZWA>362 019 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362019453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423665.081000 361483.125000</gml:lowerCorner>
        		<gml:upperCorner>423665.081000 361483.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423665.081000 361483.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 019 291</ms:GML_ID>
        <ms:NAZWA>362 019 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362019291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423767.132000 361950.023000</gml:lowerCorner>
        		<gml:upperCorner>423767.132000 361950.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423767.132000 361950.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 018 809</ms:GML_ID>
        <ms:NAZWA>362 018 809</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362018809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423910.561000 362615.986000</gml:lowerCorner>
        		<gml:upperCorner>423910.561000 362615.986000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423910.561000 362615.986000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 018 125</ms:GML_ID>
        <ms:NAZWA>362 018 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362018125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424005.122000 362880.776000</gml:lowerCorner>
        		<gml:upperCorner>424005.122000 362880.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424005.122000 362880.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 017 849</ms:GML_ID>
        <ms:NAZWA>362 017 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362017849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424109.498000 363091.607000</gml:lowerCorner>
        		<gml:upperCorner>424109.498000 363091.607000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424109.498000 363091.607000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 017 612</ms:GML_ID>
        <ms:NAZWA>362 017 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362017612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424408.005000 363697.954000</gml:lowerCorner>
        		<gml:upperCorner>424408.005000 363697.954000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424408.005000 363697.954000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 016 936</ms:GML_ID>
        <ms:NAZWA>362 016 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362016936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424756.073000 370043.372000</gml:lowerCorner>
        		<gml:upperCorner>424756.073000 370043.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424756.073000 370043.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 010 026</ms:GML_ID>
        <ms:NAZWA>362 010 026</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362010026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424873.392000 364642.641000</gml:lowerCorner>
        		<gml:upperCorner>424873.392000 364642.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424873.392000 364642.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 015 883</ms:GML_ID>
        <ms:NAZWA>362 015 883</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362015883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424903.040000 369656.626000</gml:lowerCorner>
        		<gml:upperCorner>424903.040000 369656.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424903.040000 369656.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 010 440</ms:GML_ID>
        <ms:NAZWA>362 010 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362010440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424986.695000 364871.302000</gml:lowerCorner>
        		<gml:upperCorner>424986.695000 364871.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424986.695000 364871.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 015 627</ms:GML_ID>
        <ms:NAZWA>362 015 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362015627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425148.942000 368948.568000</gml:lowerCorner>
        		<gml:upperCorner>425148.942000 368948.568000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425148.942000 368948.568000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 011 191</ms:GML_ID>
        <ms:NAZWA>362 011 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362011191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.184">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419670.591000 386051.599000</gml:lowerCorner>
        		<gml:upperCorner>419670.591000 386051.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.184.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419670.591000 386051.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>184</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 054 734</ms:GML_ID>
        <ms:NAZWA>281 054 734</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281054734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.186">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421546.904000 387166.796000</gml:lowerCorner>
        		<gml:upperCorner>421546.904000 387166.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.186.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421546.904000 387166.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>186</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 056 919</ms:GML_ID>
        <ms:NAZWA>281 056 919</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281056919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.187">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421878.200000 387363.667000</gml:lowerCorner>
        		<gml:upperCorner>421878.200000 387363.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.187.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421878.200000 387363.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>187</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 057 303</ms:GML_ID>
        <ms:NAZWA>281 057 303</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281057303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.188">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422839.016000 388031.538000</gml:lowerCorner>
        		<gml:upperCorner>422839.016000 388031.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.188.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422839.016000 388031.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>188</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 058 480</ms:GML_ID>
        <ms:NAZWA>281 058 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281058480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.189">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423382.009000 388430.293000</gml:lowerCorner>
        		<gml:upperCorner>423382.009000 388430.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.189.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423382.009000 388430.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>189</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 059 148</ms:GML_ID>
        <ms:NAZWA>281 059 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281059148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.190">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424779.823000 389457.716000</gml:lowerCorner>
        		<gml:upperCorner>424779.823000 389457.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.190.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424779.823000 389457.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>190</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 060 886</ms:GML_ID>
        <ms:NAZWA>281 060 886</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281060886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.191">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425158.852000 389736.521000</gml:lowerCorner>
        		<gml:upperCorner>425158.852000 389736.521000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.191.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425158.852000 389736.521000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>191</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 061 356</ms:GML_ID>
        <ms:NAZWA>281 061 356</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281061356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426180.905000 390146.446000</gml:lowerCorner>
        		<gml:upperCorner>426180.905000 390146.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426180.905000 390146.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.816 001 755</ms:GML_ID>
        <ms:NAZWA>816 001 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>816001755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426400.862000 389943.724000</gml:lowerCorner>
        		<gml:upperCorner>426400.862000 389943.724000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426400.862000 389943.724000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.816 002 052</ms:GML_ID>
        <ms:NAZWA>816 002 052</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>816002052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426467.694000 390782.530000</gml:lowerCorner>
        		<gml:upperCorner>426467.694000 390782.530000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426467.694000 390782.530000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.816 000 933</ms:GML_ID>
        <ms:NAZWA>816 000 933</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>816000933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.192">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426493.262000 390717.733000</gml:lowerCorner>
        		<gml:upperCorner>426493.262000 390717.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.192.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426493.262000 390717.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>192</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 063 014</ms:GML_ID>
        <ms:NAZWA>281 063 014</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281063014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426903.359000 389533.240000</gml:lowerCorner>
        		<gml:upperCorner>426903.359000 389533.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426903.359000 389533.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.816 002 701</ms:GML_ID>
        <ms:NAZWA>816 002 701</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>816002701</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427019.206587 390177.106727</gml:lowerCorner>
        		<gml:upperCorner>427019.206587 390177.106727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427019.206587 390177.106727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 166 832</ms:GML_ID>
        <ms:NAZWA>014 166 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014166832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427071.487000 389307.980000</gml:lowerCorner>
        		<gml:upperCorner>427071.487000 389307.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427071.487000 389307.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 167 748</ms:GML_ID>
        <ms:NAZWA>014 167 748</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014167748</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.193">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427281.278593 391199.389131</gml:lowerCorner>
        		<gml:upperCorner>427281.278593 391199.389131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.193.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427281.278593 391199.389131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>193</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 063 945</ms:GML_ID>
        <ms:NAZWA>281 063 945</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281063945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427923.378000 387618.674000</gml:lowerCorner>
        		<gml:upperCorner>427923.378000 387618.674000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427923.378000 387618.674000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 169 642</ms:GML_ID>
        <ms:NAZWA>014 169 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014169642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428080.711000 387306.733000</gml:lowerCorner>
        		<gml:upperCorner>428080.711000 387306.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428080.711000 387306.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 169 991</ms:GML_ID>
        <ms:NAZWA>014 169 991</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014169991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.194">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428190.197000 391675.936000</gml:lowerCorner>
        		<gml:upperCorner>428190.197000 391675.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.194.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428190.197000 391675.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>194</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 064 984</ms:GML_ID>
        <ms:NAZWA>281 064 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281064984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428592.344034 386297.531454</gml:lowerCorner>
        		<gml:upperCorner>428592.344034 386297.531454</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428592.344034 386297.531454</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 171 125</ms:GML_ID>
        <ms:NAZWA>014 171 125</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014171125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.195">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429148.686000 391754.668000</gml:lowerCorner>
        		<gml:upperCorner>429148.686000 391754.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.195.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429148.686000 391754.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>195</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 065 946</ms:GML_ID>
        <ms:NAZWA>281 065 946</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281065946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.196">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430575.729815 391872.873886</gml:lowerCorner>
        		<gml:upperCorner>430575.729815 391872.873886</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.196.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430575.729815 391872.873886</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>196</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 067 379</ms:GML_ID>
        <ms:NAZWA>281 067 379</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281067379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.197">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430821.267000 391892.514000</gml:lowerCorner>
        		<gml:upperCorner>430821.267000 391892.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.197.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430821.267000 391892.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>197</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 067 623</ms:GML_ID>
        <ms:NAZWA>281 067 623</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281067623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.198">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431132.165577 391918.912064</gml:lowerCorner>
        		<gml:upperCorner>431132.165577 391918.912064</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.198.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431132.165577 391918.912064</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>198</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 067 937</ms:GML_ID>
        <ms:NAZWA>281 067 937</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281067937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402107.175687 387074.059495</gml:lowerCorner>
        		<gml:upperCorner>402107.175687 387074.059495</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402107.175687 387074.059495</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 033 127</ms:GML_ID>
        <ms:NAZWA>281 033 127</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281033127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.178">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405882.909000 384622.183000</gml:lowerCorner>
        		<gml:upperCorner>405882.909000 384622.183000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.178.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405882.909000 384622.183000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>178</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 038 000</ms:GML_ID>
        <ms:NAZWA>281 038 000</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281038000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.179">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409566.734000 381299.668000</gml:lowerCorner>
        		<gml:upperCorner>409566.734000 381299.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.179.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409566.734000 381299.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>179</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 043 395</ms:GML_ID>
        <ms:NAZWA>281 043 395</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281043395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.180">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410344.514000 381439.046000</gml:lowerCorner>
        		<gml:upperCorner>410344.514000 381439.046000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.180.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410344.514000 381439.046000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>180</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 044 202</ms:GML_ID>
        <ms:NAZWA>281 044 202</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281044202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.181">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410512.858000 381537.844000</gml:lowerCorner>
        		<gml:upperCorner>410512.858000 381537.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.181.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410512.858000 381537.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>181</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 044 398</ms:GML_ID>
        <ms:NAZWA>281 044 398</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281044398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.182">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418875.048000 385579.101000</gml:lowerCorner>
        		<gml:upperCorner>418875.048000 385579.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.182.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418875.048000 385579.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>182</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 053 807</ms:GML_ID>
        <ms:NAZWA>281 053 807</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281053807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.183">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419269.683000 385813.475000</gml:lowerCorner>
        		<gml:upperCorner>419269.683000 385813.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.183.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419269.683000 385813.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>183</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 054 267</ms:GML_ID>
        <ms:NAZWA>281 054 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281054267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.185">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419989.925000 386241.716000</gml:lowerCorner>
        		<gml:upperCorner>419989.925000 386241.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.185.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419989.925000 386241.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>185</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 055 106</ms:GML_ID>
        <ms:NAZWA>281 055 106</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>281055106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424453.385000 372136.711000</gml:lowerCorner>
        		<gml:upperCorner>424453.385000 372136.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424453.385000 372136.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 007 802</ms:GML_ID>
        <ms:NAZWA>362 007 802</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362007802</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424634.198000 372406.355000</gml:lowerCorner>
        		<gml:upperCorner>424634.198000 372406.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424634.198000 372406.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 007 478</ms:GML_ID>
        <ms:NAZWA>362 007 478</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362007478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424857.507000 372738.662000</gml:lowerCorner>
        		<gml:upperCorner>424857.507000 372738.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424857.507000 372738.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 007 077</ms:GML_ID>
        <ms:NAZWA>362 007 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362007077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425510.763000 373313.410000</gml:lowerCorner>
        		<gml:upperCorner>425510.763000 373313.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425510.763000 373313.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 006 191</ms:GML_ID>
        <ms:NAZWA>362 006 191</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362006191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427313.494000 374330.808000</gml:lowerCorner>
        		<gml:upperCorner>427313.494000 374330.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427313.494000 374330.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 004 114</ms:GML_ID>
        <ms:NAZWA>362 004 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362004114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428409.921000 374950.927000</gml:lowerCorner>
        		<gml:upperCorner>428409.921000 374950.927000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428409.921000 374950.927000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 002 862</ms:GML_ID>
        <ms:NAZWA>362 002 862</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362002862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428866.065000 385749.756000</gml:lowerCorner>
        		<gml:upperCorner>428866.065000 385749.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428866.065000 385749.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 171 738</ms:GML_ID>
        <ms:NAZWA>014 171 738</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014171738</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428924.983000 375460.731000</gml:lowerCorner>
        		<gml:upperCorner>428924.983000 375460.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428924.983000 375460.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 002 129</ms:GML_ID>
        <ms:NAZWA>362 002 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362002129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429401.152000 384463.800000</gml:lowerCorner>
        		<gml:upperCorner>429401.152000 384463.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429401.152000 384463.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 173 144</ms:GML_ID>
        <ms:NAZWA>014 173 144</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014173144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429416.162000 384074.729000</gml:lowerCorner>
        		<gml:upperCorner>429416.162000 384074.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429416.162000 384074.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 173 531</ms:GML_ID>
        <ms:NAZWA>014 173 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014173531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429459.119649 376291.994737</gml:lowerCorner>
        		<gml:upperCorner>429459.119649 376291.994737</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429459.119649 376291.994737</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 001 140</ms:GML_ID>
        <ms:NAZWA>362 001 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362001140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429524.688000 381339.089000</gml:lowerCorner>
        		<gml:upperCorner>429524.688000 381339.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429524.688000 381339.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 176 274</ms:GML_ID>
        <ms:NAZWA>014 176 274</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014176274</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429575.427000 379999.716000</gml:lowerCorner>
        		<gml:upperCorner>429575.427000 379999.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429575.427000 379999.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 177 612</ms:GML_ID>
        <ms:NAZWA>014 177 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014177612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429595.206000 379481.659000</gml:lowerCorner>
        		<gml:upperCorner>429595.206000 379481.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429595.206000 379481.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 178 133</ms:GML_ID>
        <ms:NAZWA>014 178 133</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014178133</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429637.884000 378356.469000</gml:lowerCorner>
        		<gml:upperCorner>429637.884000 378356.469000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429637.884000 378356.469000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 179 258</ms:GML_ID>
        <ms:NAZWA>014 179 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014179258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429657.122057 377628.615291</gml:lowerCorner>
        		<gml:upperCorner>429657.122057 377628.615291</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429657.122057 377628.615291</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 179 981</ms:GML_ID>
        <ms:NAZWA>014 179 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014179981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429661.654514 377467.519439</gml:lowerCorner>
        		<gml:upperCorner>429661.654514 377467.519439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429661.654514 377467.519439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 180 152</ms:GML_ID>
        <ms:NAZWA>014 180 152</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014180152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429699.557853 376734.320038</gml:lowerCorner>
        		<gml:upperCorner>429699.557853 376734.320038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429699.557853 376734.320038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 180 882</ms:GML_ID>
        <ms:NAZWA>014 180 882</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014180882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429942.336000 375472.473000</gml:lowerCorner>
        		<gml:upperCorner>429942.336000 375472.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429942.336000 375472.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 182 177</ms:GML_ID>
        <ms:NAZWA>014 182 177</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014182177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430066.705000 375080.135000</gml:lowerCorner>
        		<gml:upperCorner>430066.705000 375080.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430066.705000 375080.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 182 589</ms:GML_ID>
        <ms:NAZWA>014 182 589</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014182589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430655.589426 373224.352841</gml:lowerCorner>
        		<gml:upperCorner>430655.589426 373224.352841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430655.589426 373224.352841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 184 537</ms:GML_ID>
        <ms:NAZWA>014 184 537</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014184537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404416.206000 421710.803000</gml:lowerCorner>
        		<gml:upperCorner>404416.206000 421710.803000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404416.206000 421710.803000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 068 926</ms:GML_ID>
        <ms:NAZWA>272 068 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272068926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406161.426000 420764.999000</gml:lowerCorner>
        		<gml:upperCorner>406161.426000 420764.999000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406161.426000 420764.999000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 070 904</ms:GML_ID>
        <ms:NAZWA>272 070 904</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272070904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408108.722000 406201.703000</gml:lowerCorner>
        		<gml:upperCorner>408108.722000 406201.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408108.722000 406201.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 018 280</ms:GML_ID>
        <ms:NAZWA>355 018 280</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355018280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408223.509000 420102.849000</gml:lowerCorner>
        		<gml:upperCorner>408223.509000 420102.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408223.509000 420102.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 073 070</ms:GML_ID>
        <ms:NAZWA>272 073 070</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272073070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409195.753000 406337.697000</gml:lowerCorner>
        		<gml:upperCorner>409195.753000 406337.697000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409195.753000 406337.697000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 017 184</ms:GML_ID>
        <ms:NAZWA>355 017 184</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355017184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3063">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410516.719000 406555.617000</gml:lowerCorner>
        		<gml:upperCorner>410516.719000 406555.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3063.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410516.719000 406555.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3063</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 015 849</ms:GML_ID>
        <ms:NAZWA>355 015 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355015849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3062">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>411806.828000 406792.875000</gml:lowerCorner>
        		<gml:upperCorner>411806.828000 406792.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3062.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>411806.828000 406792.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3062</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 014 509</ms:GML_ID>
        <ms:NAZWA>355 014 509</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355014509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3060">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413108.185000 407973.161000</gml:lowerCorner>
        		<gml:upperCorner>413108.185000 407973.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3060.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413108.185000 407973.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3060</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 012 766</ms:GML_ID>
        <ms:NAZWA>355 012 766</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355012766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3058">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414258.900000 410206.947000</gml:lowerCorner>
        		<gml:upperCorner>414258.900000 410206.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3058.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414258.900000 410206.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3058</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 010 247</ms:GML_ID>
        <ms:NAZWA>355 010 247</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355010247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3057">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414721.460000 411162.914000</gml:lowerCorner>
        		<gml:upperCorner>414721.460000 411162.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3057.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414721.460000 411162.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3057</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 009 190</ms:GML_ID>
        <ms:NAZWA>355 009 190</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355009190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3055">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416082.679000 413169.398000</gml:lowerCorner>
        		<gml:upperCorner>416082.679000 413169.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3055.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416082.679000 413169.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3055</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 006 754</ms:GML_ID>
        <ms:NAZWA>355 006 754</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355006754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416630.937000 417571.942000</gml:lowerCorner>
        		<gml:upperCorner>416630.937000 417571.942000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416630.937000 417571.942000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 081 872</ms:GML_ID>
        <ms:NAZWA>272 081 872</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272081872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3054">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417093.517756 414444.803122</gml:lowerCorner>
        		<gml:upperCorner>417093.517756 414444.803122</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3054.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417093.517756 414444.803122</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3054</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 005 124</ms:GML_ID>
        <ms:NAZWA>355 005 124</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355005124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3053">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417713.222000 415335.710000</gml:lowerCorner>
        		<gml:upperCorner>417713.222000 415335.710000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3053.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417713.222000 415335.710000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3053</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 004 039</ms:GML_ID>
        <ms:NAZWA>355 004 039</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355004039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3052">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418344.235000 416035.627000</gml:lowerCorner>
        		<gml:upperCorner>418344.235000 416035.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3052.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418344.235000 416035.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3052</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 003 088</ms:GML_ID>
        <ms:NAZWA>355 003 088</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355003088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3051">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419079.112000 416481.918000</gml:lowerCorner>
        		<gml:upperCorner>419079.112000 416481.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3051.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419079.112000 416481.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3051</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 002 227</ms:GML_ID>
        <ms:NAZWA>355 002 227</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355002227</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420105.121000 416753.397000</gml:lowerCorner>
        		<gml:upperCorner>420105.121000 416753.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420105.121000 416753.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 137 502</ms:GML_ID>
        <ms:NAZWA>014 137 502</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014137502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3050">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420122.508000 417260.328000</gml:lowerCorner>
        		<gml:upperCorner>420122.508000 417260.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3050.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420122.508000 417260.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3050</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 000 905</ms:GML_ID>
        <ms:NAZWA>355 000 905</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355000905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420164.917000 417239.769000</gml:lowerCorner>
        		<gml:upperCorner>420164.917000 417239.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420164.917000 417239.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 136 990</ms:GML_ID>
        <ms:NAZWA>014 136 990</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014136990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420177.113994 416213.033882</gml:lowerCorner>
        		<gml:upperCorner>420177.113994 416213.033882</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420177.113994 416213.033882</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 138 044</ms:GML_ID>
        <ms:NAZWA>014 138 044</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014138044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420251.554379 415699.385602</gml:lowerCorner>
        		<gml:upperCorner>420251.554379 415699.385602</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420251.554379 415699.385602</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 138 564</ms:GML_ID>
        <ms:NAZWA>014 138 564</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014138564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420423.903049 414476.609483</gml:lowerCorner>
        		<gml:upperCorner>420423.903049 414476.609483</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420423.903049 414476.609483</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 139 806</ms:GML_ID>
        <ms:NAZWA>014 139 806</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014139806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420912.228208 412131.260828</gml:lowerCorner>
        		<gml:upperCorner>420912.228208 412131.260828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420912.228208 412131.260828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 142 179</ms:GML_ID>
        <ms:NAZWA>014 142 179</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014142179</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421052.818000 411513.251000</gml:lowerCorner>
        		<gml:upperCorner>421052.818000 411513.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421052.818000 411513.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 142 815</ms:GML_ID>
        <ms:NAZWA>014 142 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014142815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421266.837000 410611.671000</gml:lowerCorner>
        		<gml:upperCorner>421266.837000 410611.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421266.837000 410611.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 143 741</ms:GML_ID>
        <ms:NAZWA>014 143 741</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014143741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421609.141000 409169.324000</gml:lowerCorner>
        		<gml:upperCorner>421609.141000 409169.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421609.141000 409169.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 145 220</ms:GML_ID>
        <ms:NAZWA>014 145 220</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014145220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422114.607000 407580.668000</gml:lowerCorner>
        		<gml:upperCorner>422114.607000 407580.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422114.607000 407580.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 146 898</ms:GML_ID>
        <ms:NAZWA>014 146 898</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014146898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422881.238000 405287.314000</gml:lowerCorner>
        		<gml:upperCorner>422881.238000 405287.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422881.238000 405287.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 149 310</ms:GML_ID>
        <ms:NAZWA>014 149 310</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014149310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423247.018000 404194.244000</gml:lowerCorner>
        		<gml:upperCorner>423247.018000 404194.244000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423247.018000 404194.244000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 150 467</ms:GML_ID>
        <ms:NAZWA>014 150 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014150467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424032.660000 417256.084000</gml:lowerCorner>
        		<gml:upperCorner>424032.660000 417256.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424032.660000 417256.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 089 299</ms:GML_ID>
        <ms:NAZWA>272 089 299</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272089299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424199.852000 401453.599000</gml:lowerCorner>
        		<gml:upperCorner>424199.852000 401453.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424199.852000 401453.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 153 369</ms:GML_ID>
        <ms:NAZWA>014 153 369</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014153369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424246.216000 417754.009000</gml:lowerCorner>
        		<gml:upperCorner>424246.216000 417754.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424246.216000 417754.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.811 000 480</ms:GML_ID>
        <ms:NAZWA>811 000 480</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>811000480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424340.798217 401091.276011</gml:lowerCorner>
        		<gml:upperCorner>424340.798217 401091.276011</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424340.798217 401091.276011</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 153 755</ms:GML_ID>
        <ms:NAZWA>014 153 755</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014153755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424480.289000 417418.623000</gml:lowerCorner>
        		<gml:upperCorner>424480.289000 417418.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424480.289000 417418.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.811 000 894</ms:GML_ID>
        <ms:NAZWA>811 000 894</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>811000894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399504.722000 319029.941000</gml:lowerCorner>
        		<gml:upperCorner>399504.722000 319029.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399504.722000 319029.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 061 896</ms:GML_ID>
        <ms:NAZWA>273 061 896</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273061896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398509.737000 319625.243000</gml:lowerCorner>
        		<gml:upperCorner>398509.737000 319625.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398509.737000 319625.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 060 740</ms:GML_ID>
        <ms:NAZWA>273 060 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273060740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419054.005000 349001.663000</gml:lowerCorner>
        		<gml:upperCorner>419054.005000 349001.663000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419054.005000 349001.663000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 035 189</ms:GML_ID>
        <ms:NAZWA>362 035 189</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362035189</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421073.549000 349260.343000</gml:lowerCorner>
        		<gml:upperCorner>421073.549000 349260.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421073.549000 349260.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 066 359</ms:GML_ID>
        <ms:NAZWA>271 066 359</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271066359</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418992.030135 349303.341299</gml:lowerCorner>
        		<gml:upperCorner>418992.030135 349303.341299</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418992.030135 349303.341299</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 034 891</ms:GML_ID>
        <ms:NAZWA>362 034 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362034891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418913.131943 349691.252604</gml:lowerCorner>
        		<gml:upperCorner>418913.131943 349691.252604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418913.131943 349691.252604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 034 486</ms:GML_ID>
        <ms:NAZWA>362 034 486</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362034486</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418888.847000 349811.164000</gml:lowerCorner>
        		<gml:upperCorner>418888.847000 349811.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418888.847000 349811.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 034 362</ms:GML_ID>
        <ms:NAZWA>362 034 362</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362034362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418837.650220 349982.682974</gml:lowerCorner>
        		<gml:upperCorner>418837.650220 349982.682974</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418837.650220 349982.682974</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 034 185</ms:GML_ID>
        <ms:NAZWA>362 034 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362034185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416976.356000 350876.678000</gml:lowerCorner>
        		<gml:upperCorner>416976.356000 350876.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416976.356000 350876.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 061 952</ms:GML_ID>
        <ms:NAZWA>271 061 952</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271061952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417105.895049 351027.169672</gml:lowerCorner>
        		<gml:upperCorner>417105.895049 351027.169672</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417105.895049 351027.169672</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 032 110</ms:GML_ID>
        <ms:NAZWA>362 032 110</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362032110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416878.499000 351305.048000</gml:lowerCorner>
        		<gml:upperCorner>416878.499000 351305.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416878.499000 351305.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 031 749</ms:GML_ID>
        <ms:NAZWA>362 031 749</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362031749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415316.985000 351403.166000</gml:lowerCorner>
        		<gml:upperCorner>415316.985000 351403.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415316.985000 351403.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 060 209</ms:GML_ID>
        <ms:NAZWA>271 060 209</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271060209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416843.382016 351491.409708</gml:lowerCorner>
        		<gml:upperCorner>416843.382016 351491.409708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416843.382016 351491.409708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 031 556</ms:GML_ID>
        <ms:NAZWA>362 031 556</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362031556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416886.630000 351691.664000</gml:lowerCorner>
        		<gml:upperCorner>416886.630000 351691.664000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416886.630000 351691.664000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 031 350</ms:GML_ID>
        <ms:NAZWA>362 031 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362031350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416923.686000 351760.068000</gml:lowerCorner>
        		<gml:upperCorner>416923.686000 351760.068000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416923.686000 351760.068000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 031 272</ms:GML_ID>
        <ms:NAZWA>362 031 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362031272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417203.838000 351988.853000</gml:lowerCorner>
        		<gml:upperCorner>417203.838000 351988.853000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417203.838000 351988.853000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 030 906</ms:GML_ID>
        <ms:NAZWA>362 030 906</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362030906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412795.132000 352010.095000</gml:lowerCorner>
        		<gml:upperCorner>412795.132000 352010.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412795.132000 352010.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 057 614</ms:GML_ID>
        <ms:NAZWA>271 057 614</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271057614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417455.045046 352143.454649</gml:lowerCorner>
        		<gml:upperCorner>417455.045046 352143.454649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417455.045046 352143.454649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 030 611</ms:GML_ID>
        <ms:NAZWA>362 030 611</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362030611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417965.893017 352506.018378</gml:lowerCorner>
        		<gml:upperCorner>417965.893017 352506.018378</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417965.893017 352506.018378</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 029 981</ms:GML_ID>
        <ms:NAZWA>362 029 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362029981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410687.265313 352547.462374</gml:lowerCorner>
        		<gml:upperCorner>410687.265313 352547.462374</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410687.265313 352547.462374</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 055 435</ms:GML_ID>
        <ms:NAZWA>271 055 435</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271055435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418445.328110 353264.715621</gml:lowerCorner>
        		<gml:upperCorner>418445.328110 353264.715621</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418445.328110 353264.715621</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 029 080</ms:GML_ID>
        <ms:NAZWA>362 029 080</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362029080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407086.740000 353694.411000</gml:lowerCorner>
        		<gml:upperCorner>407086.740000 353694.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407086.740000 353694.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 051 658</ms:GML_ID>
        <ms:NAZWA>271 051 658</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271051658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401853.418536 353768.016922</gml:lowerCorner>
        		<gml:upperCorner>401853.418536 353768.016922</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401853.418536 353768.016922</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 046 069</ms:GML_ID>
        <ms:NAZWA>271 046 069</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271046069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402149.238033 354161.122771</gml:lowerCorner>
        		<gml:upperCorner>402149.238033 354161.122771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402149.238033 354161.122771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 046 569</ms:GML_ID>
        <ms:NAZWA>271 046 569</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271046569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402139.416000 354230.613000</gml:lowerCorner>
        		<gml:upperCorner>402139.416000 354230.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402139.416000 354230.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 046 579</ms:GML_ID>
        <ms:NAZWA>271 046 579</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271046579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402678.330745 354283.203000</gml:lowerCorner>
        		<gml:upperCorner>402678.330745 354283.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402678.330745 354283.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 047 120</ms:GML_ID>
        <ms:NAZWA>271 047 120</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271047120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404529.267000 354456.907000</gml:lowerCorner>
        		<gml:upperCorner>404529.267000 354456.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404529.267000 354456.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 048 986</ms:GML_ID>
        <ms:NAZWA>271 048 986</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271048986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419513.498000 354999.561000</gml:lowerCorner>
        		<gml:upperCorner>419513.498000 354999.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419513.498000 354999.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 027 046</ms:GML_ID>
        <ms:NAZWA>362 027 046</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362027046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419804.718000 355436.271000</gml:lowerCorner>
        		<gml:upperCorner>419804.718000 355436.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419804.718000 355436.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 026 517</ms:GML_ID>
        <ms:NAZWA>362 026 517</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362026517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420015.414000 355692.934000</gml:lowerCorner>
        		<gml:upperCorner>420015.414000 355692.934000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420015.414000 355692.934000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 026 187</ms:GML_ID>
        <ms:NAZWA>362 026 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362026187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420218.258000 355939.810000</gml:lowerCorner>
        		<gml:upperCorner>420218.258000 355939.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420218.258000 355939.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 025 867</ms:GML_ID>
        <ms:NAZWA>362 025 867</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362025867</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420543.710000 356336.408000</gml:lowerCorner>
        		<gml:upperCorner>420543.710000 356336.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420543.710000 356336.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 025 355</ms:GML_ID>
        <ms:NAZWA>362 025 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362025355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420747.889000 356585.171000</gml:lowerCorner>
        		<gml:upperCorner>420747.889000 356585.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420747.889000 356585.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 025 033</ms:GML_ID>
        <ms:NAZWA>362 025 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362025033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420975.297000 356861.870000</gml:lowerCorner>
        		<gml:upperCorner>420975.297000 356861.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420975.297000 356861.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 024 675</ms:GML_ID>
        <ms:NAZWA>362 024 675</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362024675</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376316.650000 386172.425000</gml:lowerCorner>
        		<gml:upperCorner>376316.650000 386172.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376316.650000 386172.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 005 624</ms:GML_ID>
        <ms:NAZWA>281 005 624</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281005624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375228.067000 386209.359000</gml:lowerCorner>
        		<gml:upperCorner>375228.067000 386209.359000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375228.067000 386209.359000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 004 526</ms:GML_ID>
        <ms:NAZWA>281 004 526</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281004526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375560.849000 386270.595000</gml:lowerCorner>
        		<gml:upperCorner>375560.849000 386270.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375560.849000 386270.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 004 856</ms:GML_ID>
        <ms:NAZWA>281 004 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281004856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380268.169577 386295.616319</gml:lowerCorner>
        		<gml:upperCorner>380268.169577 386295.616319</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380268.169577 386295.616319</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 009 792</ms:GML_ID>
        <ms:NAZWA>281 009 792</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281009792</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393637.141645 386570.078240</gml:lowerCorner>
        		<gml:upperCorner>393637.141645 386570.078240</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393637.141645 386570.078240</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 024 392</ms:GML_ID>
        <ms:NAZWA>281 024 392</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281024392</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404186.939000 386626.007000</gml:lowerCorner>
        		<gml:upperCorner>404186.939000 386626.007000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404186.939000 386626.007000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 035 299</ms:GML_ID>
        <ms:NAZWA>281 035 299</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281035299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393161.631000 386627.393000</gml:lowerCorner>
        		<gml:upperCorner>393161.631000 386627.393000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393161.631000 386627.393000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 023 914</ms:GML_ID>
        <ms:NAZWA>281 023 914</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281023914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400353.932000 387159.904000</gml:lowerCorner>
        		<gml:upperCorner>400353.932000 387159.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400353.932000 387159.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 031 371</ms:GML_ID>
        <ms:NAZWA>281 031 371</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281031371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400058.740000 387175.270000</gml:lowerCorner>
        		<gml:upperCorner>400058.740000 387175.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400058.740000 387175.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 031 074</ms:GML_ID>
        <ms:NAZWA>281 031 074</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281031074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399515.964000 387201.156000</gml:lowerCorner>
        		<gml:upperCorner>399515.964000 387201.156000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399515.964000 387201.156000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 030 531</ms:GML_ID>
        <ms:NAZWA>281 030 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281030531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397862.204000 387281.494000</gml:lowerCorner>
        		<gml:upperCorner>397862.204000 387281.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397862.204000 387281.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 028 874</ms:GML_ID>
        <ms:NAZWA>281 028 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281028874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388113.161873 388569.675822</gml:lowerCorner>
        		<gml:upperCorner>388113.161873 388569.675822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388113.161873 388569.675822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 018 306</ms:GML_ID>
        <ms:NAZWA>281 018 306</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281018306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387143.268154 388944.941593</gml:lowerCorner>
        		<gml:upperCorner>387143.268154 388944.941593</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387143.268154 388944.941593</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 017 260</ms:GML_ID>
        <ms:NAZWA>281 017 260</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281017260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389222.392000 390646.018000</gml:lowerCorner>
        		<gml:upperCorner>389222.392000 390646.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389222.392000 390646.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 050 528</ms:GML_ID>
        <ms:NAZWA>355 050 528</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355050528</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389233.970000 392548.022000</gml:lowerCorner>
        		<gml:upperCorner>389233.970000 392548.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389233.970000 392548.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 048 589</ms:GML_ID>
        <ms:NAZWA>355 048 589</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355048589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389309.055000 393585.653000</gml:lowerCorner>
        		<gml:upperCorner>389309.055000 393585.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389309.055000 393585.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 047 549</ms:GML_ID>
        <ms:NAZWA>355 047 549</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355047549</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389622.873000 394218.143000</gml:lowerCorner>
        		<gml:upperCorner>389622.873000 394218.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389622.873000 394218.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 046 851</ms:GML_ID>
        <ms:NAZWA>355 046 851</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355046851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389934.517000 394789.309000</gml:lowerCorner>
        		<gml:upperCorner>389934.517000 394789.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389934.517000 394789.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 046 183</ms:GML_ID>
        <ms:NAZWA>355 046 183</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355046183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390098.723000 395097.967000</gml:lowerCorner>
        		<gml:upperCorner>390098.723000 395097.967000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390098.723000 395097.967000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 045 833</ms:GML_ID>
        <ms:NAZWA>355 045 833</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355045833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391928.668000 400392.682000</gml:lowerCorner>
        		<gml:upperCorner>391928.668000 400392.682000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391928.668000 400392.682000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 040 104</ms:GML_ID>
        <ms:NAZWA>355 040 104</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355040104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392125.841581 401180.030489</gml:lowerCorner>
        		<gml:upperCorner>392125.841581 401180.030489</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392125.841581 401180.030489</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 039 287</ms:GML_ID>
        <ms:NAZWA>355 039 287</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355039287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377018.759000 402748.677000</gml:lowerCorner>
        		<gml:upperCorner>377018.759000 402748.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377018.759000 402748.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 131 903</ms:GML_ID>
        <ms:NAZWA>181 131 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181131903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378209.181210 404631.600140</gml:lowerCorner>
        		<gml:upperCorner>378209.181210 404631.600140</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378209.181210 404631.600140</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 129 672</ms:GML_ID>
        <ms:NAZWA>181 129 672</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181129672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378698.652332 405410.589370</gml:lowerCorner>
        		<gml:upperCorner>378698.652332 405410.589370</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378698.652332 405410.589370</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 128 752</ms:GML_ID>
        <ms:NAZWA>181 128 752</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181128752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393590.648000 405458.164000</gml:lowerCorner>
        		<gml:upperCorner>393590.648000 405458.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393590.648000 405458.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 034 595</ms:GML_ID>
        <ms:NAZWA>355 034 595</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355034595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>401510.449958 405532.040174</gml:lowerCorner>
        		<gml:upperCorner>401510.449958 405532.040174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>401510.449958 405532.040174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 024 918</ms:GML_ID>
        <ms:NAZWA>355 024 918</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355024918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400839.601812 405554.829247</gml:lowerCorner>
        		<gml:upperCorner>400839.601812 405554.829247</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400839.601812 405554.829247</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 025 593</ms:GML_ID>
        <ms:NAZWA>355 025 593</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355025593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378888.792000 405708.483000</gml:lowerCorner>
        		<gml:upperCorner>378888.792000 405708.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378888.792000 405708.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 128 398</ms:GML_ID>
        <ms:NAZWA>181 128 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181128398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371186.939000 327102.973000</gml:lowerCorner>
        		<gml:upperCorner>371186.939000 327102.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371186.939000 327102.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 005 225</ms:GML_ID>
        <ms:NAZWA>302 005 225</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302005225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371555.798000 327020.831000</gml:lowerCorner>
        		<gml:upperCorner>371555.798000 327020.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371555.798000 327020.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 004 848</ms:GML_ID>
        <ms:NAZWA>302 004 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302004848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371900.618000 336980.003000</gml:lowerCorner>
        		<gml:upperCorner>371900.618000 336980.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371900.618000 336980.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 029 607</ms:GML_ID>
        <ms:NAZWA>275 029 607</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275029607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371903.707822 335046.079269</gml:lowerCorner>
        		<gml:upperCorner>371903.707822 335046.079269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371903.707822 335046.079269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 031 542</ms:GML_ID>
        <ms:NAZWA>275 031 542</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275031542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371906.294292 333890.862218</gml:lowerCorner>
        		<gml:upperCorner>371906.294292 333890.862218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371906.294292 333890.862218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 032 698</ms:GML_ID>
        <ms:NAZWA>275 032 698</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275032698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371914.326151 332659.114608</gml:lowerCorner>
        		<gml:upperCorner>371914.326151 332659.114608</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371914.326151 332659.114608</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 033 933</ms:GML_ID>
        <ms:NAZWA>275 033 933</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275033933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372235.575000 326867.454000</gml:lowerCorner>
        		<gml:upperCorner>372235.575000 326867.454000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372235.575000 326867.454000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 004 152</ms:GML_ID>
        <ms:NAZWA>302 004 152</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302004152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372546.002000 326759.186000</gml:lowerCorner>
        		<gml:upperCorner>372546.002000 326759.186000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372546.002000 326759.186000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 003 821</ms:GML_ID>
        <ms:NAZWA>302 003 821</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302003821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373154.129000 326478.871000</gml:lowerCorner>
        		<gml:upperCorner>373154.129000 326478.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373154.129000 326478.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 003 151</ms:GML_ID>
        <ms:NAZWA>302 003 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302003151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373383.162000 326372.218000</gml:lowerCorner>
        		<gml:upperCorner>373383.162000 326372.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373383.162000 326372.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 002 898</ms:GML_ID>
        <ms:NAZWA>302 002 898</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302002898</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373830.628000 326135.952000</gml:lowerCorner>
        		<gml:upperCorner>373830.628000 326135.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373830.628000 326135.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 002 390</ms:GML_ID>
        <ms:NAZWA>302 002 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302002390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375025.410064 325447.506538</gml:lowerCorner>
        		<gml:upperCorner>375025.410064 325447.506538</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375025.410064 325447.506538</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 000 876</ms:GML_ID>
        <ms:NAZWA>302 000 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302000876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375134.513436 324952.912310</gml:lowerCorner>
        		<gml:upperCorner>375134.513436 324952.912310</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375134.513436 324952.912310</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 042 372</ms:GML_ID>
        <ms:NAZWA>275 042 372</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275042372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385614.003419 336677.897476</gml:lowerCorner>
        		<gml:upperCorner>385614.003419 336677.897476</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385614.003419 336677.897476</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 037 653</ms:GML_ID>
        <ms:NAZWA>273 037 653</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273037653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386337.173470 336043.084281</gml:lowerCorner>
        		<gml:upperCorner>386337.173470 336043.084281</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386337.173470 336043.084281</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 038 620</ms:GML_ID>
        <ms:NAZWA>273 038 620</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273038620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387725.455286 335252.219730</gml:lowerCorner>
        		<gml:upperCorner>387725.455286 335252.219730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387725.455286 335252.219730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 040 220</ms:GML_ID>
        <ms:NAZWA>273 040 220</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273040220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388473.089878 334838.010711</gml:lowerCorner>
        		<gml:upperCorner>388473.089878 334838.010711</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388473.089878 334838.010711</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 041 070</ms:GML_ID>
        <ms:NAZWA>273 041 070</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273041070</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390517.895000 333559.121000</gml:lowerCorner>
        		<gml:upperCorner>390517.895000 333559.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390517.895000 333559.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 043 495</ms:GML_ID>
        <ms:NAZWA>273 043 495</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273043495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391320.506000 332784.928000</gml:lowerCorner>
        		<gml:upperCorner>391320.506000 332784.928000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391320.506000 332784.928000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 044 610</ms:GML_ID>
        <ms:NAZWA>273 044 610</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273044610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>391719.314000 332399.807000</gml:lowerCorner>
        		<gml:upperCorner>391719.314000 332399.807000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>391719.314000 332399.807000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 045 161</ms:GML_ID>
        <ms:NAZWA>273 045 161</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273045161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393770.231000 329710.095000</gml:lowerCorner>
        		<gml:upperCorner>393770.231000 329710.095000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393770.231000 329710.095000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 048 557</ms:GML_ID>
        <ms:NAZWA>273 048 557</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273048557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394430.709000 328349.179000</gml:lowerCorner>
        		<gml:upperCorner>394430.709000 328349.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394430.709000 328349.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 050 090</ms:GML_ID>
        <ms:NAZWA>273 050 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273050090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394719.136000 327141.496000</gml:lowerCorner>
        		<gml:upperCorner>394719.136000 327141.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394719.136000 327141.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 051 331</ms:GML_ID>
        <ms:NAZWA>273 051 331</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273051331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394914.052938 326609.712344</gml:lowerCorner>
        		<gml:upperCorner>394914.052938 326609.712344</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394914.052938 326609.712344</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 051 895</ms:GML_ID>
        <ms:NAZWA>273 051 895</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273051895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395071.589000 326293.711000</gml:lowerCorner>
        		<gml:upperCorner>395071.589000 326293.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395071.589000 326293.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 052 256</ms:GML_ID>
        <ms:NAZWA>273 052 256</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273052256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395427.479000 325580.766000</gml:lowerCorner>
        		<gml:upperCorner>395427.479000 325580.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395427.479000 325580.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 053 025</ms:GML_ID>
        <ms:NAZWA>273 053 025</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273053025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396072.970349 324287.691121</gml:lowerCorner>
        		<gml:upperCorner>396072.970349 324287.691121</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396072.970349 324287.691121</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 054 497</ms:GML_ID>
        <ms:NAZWA>273 054 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273054497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396926.670547 320533.858111</gml:lowerCorner>
        		<gml:upperCorner>396926.670547 320533.858111</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396926.670547 320533.858111</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 058 920</ms:GML_ID>
        <ms:NAZWA>273 058 920</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273058920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396953.350194 320578.126026</gml:lowerCorner>
        		<gml:upperCorner>396953.350194 320578.126026</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396953.350194 320578.126026</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 058 911</ms:GML_ID>
        <ms:NAZWA>273 058 911</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273058911</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397389.492000 320293.395000</gml:lowerCorner>
        		<gml:upperCorner>397389.492000 320293.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397389.492000 320293.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 059 434</ms:GML_ID>
        <ms:NAZWA>273 059 434</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273059434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399227.803000 319196.832000</gml:lowerCorner>
        		<gml:upperCorner>399227.803000 319196.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399227.803000 319196.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 061 577</ms:GML_ID>
        <ms:NAZWA>273 061 577</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273061577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384710.643000 337354.445000</gml:lowerCorner>
        		<gml:upperCorner>384710.643000 337354.445000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384710.643000 337354.445000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 036 520</ms:GML_ID>
        <ms:NAZWA>273 036 520</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273036520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383839.594000 337892.622000</gml:lowerCorner>
        		<gml:upperCorner>383839.594000 337892.622000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383839.594000 337892.622000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 035 500</ms:GML_ID>
        <ms:NAZWA>273 035 500</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273035500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382423.851000 338664.100000</gml:lowerCorner>
        		<gml:upperCorner>382423.851000 338664.100000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382423.851000 338664.100000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 033 885</ms:GML_ID>
        <ms:NAZWA>273 033 885</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273033885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371898.997195 338905.835795</gml:lowerCorner>
        		<gml:upperCorner>371898.997195 338905.835795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371898.997195 338905.835795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 027 680</ms:GML_ID>
        <ms:NAZWA>275 027 680</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275027680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381086.576526 340261.616192</gml:lowerCorner>
        		<gml:upperCorner>381086.576526 340261.616192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381086.576526 340261.616192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 031 761</ms:GML_ID>
        <ms:NAZWA>273 031 761</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273031761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379962.781412 341723.751118</gml:lowerCorner>
        		<gml:upperCorner>379962.781412 341723.751118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379962.781412 341723.751118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 029 917</ms:GML_ID>
        <ms:NAZWA>273 029 917</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273029917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371520.840396 341827.071678</gml:lowerCorner>
        		<gml:upperCorner>371520.840396 341827.071678</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371520.840396 341827.071678</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 024 729</ms:GML_ID>
        <ms:NAZWA>275 024 729</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275024729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377436.787000 343961.135000</gml:lowerCorner>
        		<gml:upperCorner>377436.787000 343961.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377436.787000 343961.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 026 138</ms:GML_ID>
        <ms:NAZWA>273 026 138</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273026138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370884.218000 345734.596000</gml:lowerCorner>
        		<gml:upperCorner>370884.218000 345734.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370884.218000 345734.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 020 768</ms:GML_ID>
        <ms:NAZWA>275 020 768</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275020768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375934.619000 346798.109000</gml:lowerCorner>
        		<gml:upperCorner>375934.619000 346798.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375934.619000 346798.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 022 926</ms:GML_ID>
        <ms:NAZWA>273 022 926</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273022926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375158.982287 348241.886526</gml:lowerCorner>
        		<gml:upperCorner>375158.982287 348241.886526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375158.982287 348241.886526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 021 290</ms:GML_ID>
        <ms:NAZWA>273 021 290</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273021290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374712.998000 349108.362000</gml:lowerCorner>
        		<gml:upperCorner>374712.998000 349108.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374712.998000 349108.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 020 312</ms:GML_ID>
        <ms:NAZWA>273 020 312</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273020312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374157.313000 350024.805000</gml:lowerCorner>
        		<gml:upperCorner>374157.313000 350024.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374157.313000 350024.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 019 236</ms:GML_ID>
        <ms:NAZWA>273 019 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273019236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393606.949544 350334.418128</gml:lowerCorner>
        		<gml:upperCorner>393606.949544 350334.418128</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393606.949544 350334.418128</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 037 090</ms:GML_ID>
        <ms:NAZWA>271 037 090</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271037090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373511.146000 350497.511000</gml:lowerCorner>
        		<gml:upperCorner>373511.146000 350497.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373511.146000 350497.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 018 434</ms:GML_ID>
        <ms:NAZWA>273 018 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273018434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392417.902041 350535.182688</gml:lowerCorner>
        		<gml:upperCorner>392417.902041 350535.182688</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392417.902041 350535.182688</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 035 883</ms:GML_ID>
        <ms:NAZWA>271 035 883</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271035883</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>395639.128000 351064.938000</gml:lowerCorner>
        		<gml:upperCorner>395639.128000 351064.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>395639.128000 351064.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 039 308</ms:GML_ID>
        <ms:NAZWA>271 039 308</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271039308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387793.237000 351405.895000</gml:lowerCorner>
        		<gml:upperCorner>387793.237000 351405.895000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387793.237000 351405.895000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 031 176</ms:GML_ID>
        <ms:NAZWA>271 031 176</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271031176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371361.031000 351944.086000</gml:lowerCorner>
        		<gml:upperCorner>371361.031000 351944.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371361.031000 351944.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 015 841</ms:GML_ID>
        <ms:NAZWA>273 015 841</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273015841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398069.792000 352356.600000</gml:lowerCorner>
        		<gml:upperCorner>398069.792000 352356.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398069.792000 352356.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 042 060</ms:GML_ID>
        <ms:NAZWA>271 042 060</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271042060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370657.263713 352417.776668</gml:lowerCorner>
        		<gml:upperCorner>370657.263713 352417.776668</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370657.263713 352417.776668</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 014 994</ms:GML_ID>
        <ms:NAZWA>273 014 994</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273014994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383295.772890 354192.025091</gml:lowerCorner>
        		<gml:upperCorner>383295.772890 354192.025091</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383295.772890 354192.025091</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 025 756</ms:GML_ID>
        <ms:NAZWA>271 025 756</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271025756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381617.278000 354429.719000</gml:lowerCorner>
        		<gml:upperCorner>381617.278000 354429.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381617.278000 354429.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 024 054</ms:GML_ID>
        <ms:NAZWA>271 024 054</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271024054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379940.460000 354674.755000</gml:lowerCorner>
        		<gml:upperCorner>379940.460000 354674.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379940.460000 354674.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 022 358</ms:GML_ID>
        <ms:NAZWA>271 022 358</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271022358</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377645.421300 355375.802061</gml:lowerCorner>
        		<gml:upperCorner>377645.421300 355375.802061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377645.421300 355375.802061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 019 934</ms:GML_ID>
        <ms:NAZWA>271 019 934</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271019934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375941.664000 356243.787000</gml:lowerCorner>
        		<gml:upperCorner>375941.664000 356243.787000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375941.664000 356243.787000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 018 024</ms:GML_ID>
        <ms:NAZWA>271 018 024</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271018024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374146.032118 357158.633987</gml:lowerCorner>
        		<gml:upperCorner>374146.032118 357158.633987</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374146.032118 357158.633987</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 016 000</ms:GML_ID>
        <ms:NAZWA>271 016 000</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271016000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366698.776000 362211.037000</gml:lowerCorner>
        		<gml:upperCorner>366698.776000 362211.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366698.776000 362211.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 025 493</ms:GML_ID>
        <ms:NAZWA>292 025 493</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292025493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366814.567000 361880.611000</gml:lowerCorner>
        		<gml:upperCorner>366814.567000 361880.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366814.567000 361880.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 025 853</ms:GML_ID>
        <ms:NAZWA>292 025 853</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292025853</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366820.273000 363217.839000</gml:lowerCorner>
        		<gml:upperCorner>366820.273000 363217.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366820.273000 363217.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 024 452</ms:GML_ID>
        <ms:NAZWA>292 024 452</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292024452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367236.747000 361465.583000</gml:lowerCorner>
        		<gml:upperCorner>367236.747000 361465.583000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367236.747000 361465.583000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 026 446</ms:GML_ID>
        <ms:NAZWA>292 026 446</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292026446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367409.949477 360630.933914</gml:lowerCorner>
        		<gml:upperCorner>367409.949477 360630.933914</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367409.949477 360630.933914</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 027 355</ms:GML_ID>
        <ms:NAZWA>292 027 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292027355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367412.644000 360999.826000</gml:lowerCorner>
        		<gml:upperCorner>367412.644000 360999.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367412.644000 360999.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 026 977</ms:GML_ID>
        <ms:NAZWA>292 026 977</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292026977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368826.172334 359858.149210</gml:lowerCorner>
        		<gml:upperCorner>368826.172334 359858.149210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368826.172334 359858.149210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 010 036</ms:GML_ID>
        <ms:NAZWA>271 010 036</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271010036</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371386.752000 358564.766000</gml:lowerCorner>
        		<gml:upperCorner>371386.752000 358564.766000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371386.752000 358564.766000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 012 906</ms:GML_ID>
        <ms:NAZWA>271 012 906</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271012906</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372000.361000 358253.004000</gml:lowerCorner>
        		<gml:upperCorner>372000.361000 358253.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372000.361000 358253.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 013 593</ms:GML_ID>
        <ms:NAZWA>271 013 593</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271013593</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372877.908196 357805.065028</gml:lowerCorner>
        		<gml:upperCorner>372877.908196 357805.065028</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372877.908196 357805.065028</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 014 579</ms:GML_ID>
        <ms:NAZWA>271 014 579</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271014579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373034.525523 357725.220272</gml:lowerCorner>
        		<gml:upperCorner>373034.525523 357725.220272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373034.525523 357725.220272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 014 756</ms:GML_ID>
        <ms:NAZWA>271 014 756</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>271014756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5013">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361684.561000 401688.282000</gml:lowerCorner>
        		<gml:upperCorner>361684.561000 401688.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5013.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361684.561000 401688.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5013</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 116 077</ms:GML_ID>
        <ms:NAZWA>143 116 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143116077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5014">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361992.928000 401082.253000</gml:lowerCorner>
        		<gml:upperCorner>361992.928000 401082.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5014.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361992.928000 401082.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5014</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 116 758</ms:GML_ID>
        <ms:NAZWA>143 116 758</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143116758</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5015">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362921.984000 399205.817000</gml:lowerCorner>
        		<gml:upperCorner>362921.984000 399205.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5015.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362921.984000 399205.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5015</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 118 855</ms:GML_ID>
        <ms:NAZWA>143 118 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143118855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5016">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363104.133323 398826.369756</gml:lowerCorner>
        		<gml:upperCorner>363104.133323 398826.369756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5016.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363104.133323 398826.369756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5016</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 119 275</ms:GML_ID>
        <ms:NAZWA>143 119 275</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143119275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5017">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363274.389066 398528.418004</gml:lowerCorner>
        		<gml:upperCorner>363274.389066 398528.418004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5017.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363274.389066 398528.418004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5017</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 119 620</ms:GML_ID>
        <ms:NAZWA>143 119 620</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143119620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5018">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363704.898523 397805.293573</gml:lowerCorner>
        		<gml:upperCorner>363704.898523 397805.293573</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5018.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363704.898523 397805.293573</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5018</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 120 462</ms:GML_ID>
        <ms:NAZWA>143 120 462</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143120462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5019">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363944.842245 397391.834524</gml:lowerCorner>
        		<gml:upperCorner>363944.842245 397391.834524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5019.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363944.842245 397391.834524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5019</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 120 937</ms:GML_ID>
        <ms:NAZWA>143 120 937</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143120937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5020">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364496.046000 396817.197000</gml:lowerCorner>
        		<gml:upperCorner>364496.046000 396817.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5020.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364496.046000 396817.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5020</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 121 735</ms:GML_ID>
        <ms:NAZWA>143 121 735</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143121735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5021">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364966.560000 396382.455000</gml:lowerCorner>
        		<gml:upperCorner>364966.560000 396382.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5021.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364966.560000 396382.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5021</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 122 376</ms:GML_ID>
        <ms:NAZWA>143 122 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143122376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5022">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365818.022114 395524.058917</gml:lowerCorner>
        		<gml:upperCorner>365818.022114 395524.058917</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5022.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365818.022114 395524.058917</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5022</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 123 590</ms:GML_ID>
        <ms:NAZWA>143 123 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143123590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5023">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366676.000000 394119.998000</gml:lowerCorner>
        		<gml:upperCorner>366676.000000 394119.998000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5023.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366676.000000 394119.998000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5023</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 125 239</ms:GML_ID>
        <ms:NAZWA>143 125 239</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143125239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5024">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368199.003000 391631.784000</gml:lowerCorner>
        		<gml:upperCorner>368199.003000 391631.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5024.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368199.003000 391631.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5024</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 128 155</ms:GML_ID>
        <ms:NAZWA>143 128 155</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143128155</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5025">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369330.399000 390349.097000</gml:lowerCorner>
        		<gml:upperCorner>369330.399000 390349.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5025.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369330.399000 390349.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5025</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 129 869</ms:GML_ID>
        <ms:NAZWA>143 129 869</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143129869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5026">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369698.742000 389936.161000</gml:lowerCorner>
        		<gml:upperCorner>369698.742000 389936.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5026.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369698.742000 389936.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5026</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 130 421</ms:GML_ID>
        <ms:NAZWA>143 130 421</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143130421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5027">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370196.031000 389379.755000</gml:lowerCorner>
        		<gml:upperCorner>370196.031000 389379.755000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5027.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370196.031000 389379.755000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5027</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 131 168</ms:GML_ID>
        <ms:NAZWA>143 131 168</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143131168</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371531.222128 389260.672126</gml:lowerCorner>
        		<gml:upperCorner>371531.222128 389260.672126</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371531.222128 389260.672126</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 146 637</ms:GML_ID>
        <ms:NAZWA>181 146 637</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181146637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372001.631000 390393.478000</gml:lowerCorner>
        		<gml:upperCorner>372001.631000 390393.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372001.631000 390393.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 145 413</ms:GML_ID>
        <ms:NAZWA>181 145 413</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181145413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372203.047987 390875.830468</gml:lowerCorner>
        		<gml:upperCorner>372203.047987 390875.830468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372203.047987 390875.830468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 144 889</ms:GML_ID>
        <ms:NAZWA>181 144 889</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181144889</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373274.164000 393457.841000</gml:lowerCorner>
        		<gml:upperCorner>373274.164000 393457.841000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373274.164000 393457.841000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 142 091</ms:GML_ID>
        <ms:NAZWA>181 142 091</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181142091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373584.564580 394902.964602</gml:lowerCorner>
        		<gml:upperCorner>373584.564580 394902.964602</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373584.564580 394902.964602</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 140 610</ms:GML_ID>
        <ms:NAZWA>181 140 610</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181140610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373834.215506 396150.626884</gml:lowerCorner>
        		<gml:upperCorner>373834.215506 396150.626884</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373834.215506 396150.626884</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 139 337</ms:GML_ID>
        <ms:NAZWA>181 139 337</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181139337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374184.707320 397906.128290</gml:lowerCorner>
        		<gml:upperCorner>374184.707320 397906.128290</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374184.707320 397906.128290</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 137 545</ms:GML_ID>
        <ms:NAZWA>181 137 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181137545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374614.211646 398975.784813</gml:lowerCorner>
        		<gml:upperCorner>374614.211646 398975.784813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374614.211646 398975.784813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 136 378</ms:GML_ID>
        <ms:NAZWA>181 136 378</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181136378</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375899.275980 400968.274083</gml:lowerCorner>
        		<gml:upperCorner>375899.275980 400968.274083</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375899.275980 400968.274083</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 134 006</ms:GML_ID>
        <ms:NAZWA>181 134 006</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181134006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360653.394000 357764.365000</gml:lowerCorner>
        		<gml:upperCorner>360653.394000 357764.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360653.394000 357764.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 003 870</ms:GML_ID>
        <ms:NAZWA>274 003 870</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274003870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360855.522206 358274.936919</gml:lowerCorner>
        		<gml:upperCorner>360855.522206 358274.936919</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360855.522206 358274.936919</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 003 318</ms:GML_ID>
        <ms:NAZWA>274 003 318</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274003318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361300.165000 359400.904000</gml:lowerCorner>
        		<gml:upperCorner>361300.165000 359400.904000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361300.165000 359400.904000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 002 108</ms:GML_ID>
        <ms:NAZWA>274 002 108</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274002108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361327.382478 359470.626094</gml:lowerCorner>
        		<gml:upperCorner>361327.382478 359470.626094</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361327.382478 359470.626094</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 002 034</ms:GML_ID>
        <ms:NAZWA>274 002 034</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274002034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361386.908000 359459.796000</gml:lowerCorner>
        		<gml:upperCorner>361386.908000 359459.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361386.908000 359459.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.757 001 980</ms:GML_ID>
        <ms:NAZWA>757 001 980</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>757001980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361447.075000 359477.722000</gml:lowerCorner>
        		<gml:upperCorner>361447.075000 359477.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361447.075000 359477.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 003 263</ms:GML_ID>
        <ms:NAZWA>273 003 263</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273003263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361583.825056 360087.551721</gml:lowerCorner>
        		<gml:upperCorner>361583.825056 360087.551721</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361583.825056 360087.551721</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 001 365</ms:GML_ID>
        <ms:NAZWA>274 001 365</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274001365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4897">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362518.651000 359550.055000</gml:lowerCorner>
        		<gml:upperCorner>362518.651000 359550.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4897.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362518.651000 359550.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4897</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 015 478</ms:GML_ID>
        <ms:NAZWA>349 015 478</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349015478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362548.745000 358188.592000</gml:lowerCorner>
        		<gml:upperCorner>362548.745000 358188.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362548.745000 358188.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 005 032</ms:GML_ID>
        <ms:NAZWA>273 005 032</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273005032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362678.857650 359324.271179</gml:lowerCorner>
        		<gml:upperCorner>362678.857650 359324.271179</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362678.857650 359324.271179</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 015 754</ms:GML_ID>
        <ms:NAZWA>349 015 754</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349015754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363694.834000 357265.636000</gml:lowerCorner>
        		<gml:upperCorner>363694.834000 357265.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363694.834000 357265.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 006 504</ms:GML_ID>
        <ms:NAZWA>273 006 504</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273006504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364382.984000 367392.888000</gml:lowerCorner>
        		<gml:upperCorner>364382.984000 367392.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364382.984000 367392.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 018 983</ms:GML_ID>
        <ms:NAZWA>292 018 983</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292018983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364782.568000 367147.564000</gml:lowerCorner>
        		<gml:upperCorner>364782.568000 367147.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364782.568000 367147.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 019 455</ms:GML_ID>
        <ms:NAZWA>292 019 455</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292019455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5043">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365228.859000 364874.459000</gml:lowerCorner>
        		<gml:upperCorner>365228.859000 364874.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5043.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365228.859000 364874.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5043</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 157 602</ms:GML_ID>
        <ms:NAZWA>143 157 602</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143157602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5042">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365676.332000 365844.226000</gml:lowerCorner>
        		<gml:upperCorner>365676.332000 365844.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5042.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365676.332000 365844.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5042</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 156 536</ms:GML_ID>
        <ms:NAZWA>143 156 536</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143156536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365764.891000 365098.079000</gml:lowerCorner>
        		<gml:upperCorner>365764.891000 365098.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365764.891000 365098.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 022 223</ms:GML_ID>
        <ms:NAZWA>292 022 223</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292022223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366085.950239 362310.195148</gml:lowerCorner>
        		<gml:upperCorner>366085.950239 362310.195148</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366085.950239 362310.195148</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 025 601</ms:GML_ID>
        <ms:NAZWA>292 025 601</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292025601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366607.956131 362930.521622</gml:lowerCorner>
        		<gml:upperCorner>366607.956131 362930.521622</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366607.956131 362930.521622</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 024 806</ms:GML_ID>
        <ms:NAZWA>292 024 806</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292024806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366674.125000 363926.496000</gml:lowerCorner>
        		<gml:upperCorner>366674.125000 363926.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366674.125000 363926.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 023 709</ms:GML_ID>
        <ms:NAZWA>292 023 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292023709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360585.066185 371826.693046</gml:lowerCorner>
        		<gml:upperCorner>360585.066185 371826.693046</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360585.066185 371826.693046</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 012 812</ms:GML_ID>
        <ms:NAZWA>292 012 812</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292012812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360775.169842 371608.828093</gml:lowerCorner>
        		<gml:upperCorner>360775.169842 371608.828093</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360775.169842 371608.828093</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 013 101</ms:GML_ID>
        <ms:NAZWA>292 013 101</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292013101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361019.091000 371328.751000</gml:lowerCorner>
        		<gml:upperCorner>361019.091000 371328.751000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361019.091000 371328.751000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 013 472</ms:GML_ID>
        <ms:NAZWA>292 013 472</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292013472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361227.366000 371090.708000</gml:lowerCorner>
        		<gml:upperCorner>361227.366000 371090.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361227.366000 371090.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 013 788</ms:GML_ID>
        <ms:NAZWA>292 013 788</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292013788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361481.076595 370799.873281</gml:lowerCorner>
        		<gml:upperCorner>361481.076595 370799.873281</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361481.076595 370799.873281</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 014 181</ms:GML_ID>
        <ms:NAZWA>292 014 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292014181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362015.239655 370187.657382</gml:lowerCorner>
        		<gml:upperCorner>362015.239655 370187.657382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362015.239655 370187.657382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 014 992</ms:GML_ID>
        <ms:NAZWA>292 014 992</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292014992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362294.022281 369013.411582</gml:lowerCorner>
        		<gml:upperCorner>362294.022281 369013.411582</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362294.022281 369013.411582</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 016 291</ms:GML_ID>
        <ms:NAZWA>292 016 291</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292016291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362371.524000 369536.282000</gml:lowerCorner>
        		<gml:upperCorner>362371.524000 369536.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362371.524000 369536.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 015 763</ms:GML_ID>
        <ms:NAZWA>292 015 763</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292015763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362436.924000 368720.995000</gml:lowerCorner>
        		<gml:upperCorner>362436.924000 368720.995000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362436.924000 368720.995000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 016 625</ms:GML_ID>
        <ms:NAZWA>292 016 625</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292016625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363208.157890 368208.122991</gml:lowerCorner>
        		<gml:upperCorner>363208.157890 368208.122991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363208.157890 368208.122991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 017 550</ms:GML_ID>
        <ms:NAZWA>292 017 550</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292017550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5041">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366640.294780 368757.390919</gml:lowerCorner>
        		<gml:upperCorner>366640.294780 368757.390919</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5041.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366640.294780 368757.390919</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5041</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 153 465</ms:GML_ID>
        <ms:NAZWA>143 153 465</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143153465</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367225.233000 368809.148000</gml:lowerCorner>
        		<gml:upperCorner>367225.233000 368809.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367225.233000 368809.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.326 000 871</ms:GML_ID>
        <ms:NAZWA>326 000 871</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>326000871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5040">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368082.868078 371710.111314</gml:lowerCorner>
        		<gml:upperCorner>368082.868078 371710.111314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5040.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368082.868078 371710.111314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5040</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 150 170</ms:GML_ID>
        <ms:NAZWA>143 150 170</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143150170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5039">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368989.542798 372944.892234</gml:lowerCorner>
        		<gml:upperCorner>368989.542798 372944.892234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5039.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368989.542798 372944.892234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5039</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 148 636</ms:GML_ID>
        <ms:NAZWA>143 148 636</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143148636</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5038">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369408.185169 373598.725709</gml:lowerCorner>
        		<gml:upperCorner>369408.185169 373598.725709</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5038.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369408.185169 373598.725709</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5038</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 147 860</ms:GML_ID>
        <ms:NAZWA>143 147 860</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143147860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5037">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369712.422382 374273.893427</gml:lowerCorner>
        		<gml:upperCorner>369712.422382 374273.893427</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5037.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369712.422382 374273.893427</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5037</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 147 117</ms:GML_ID>
        <ms:NAZWA>143 147 117</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143147117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5036">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369819.482000 375266.005000</gml:lowerCorner>
        		<gml:upperCorner>369819.482000 375266.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5036.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369819.482000 375266.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5036</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 146 111</ms:GML_ID>
        <ms:NAZWA>143 146 111</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143146111</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5035">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369832.271000 375854.294000</gml:lowerCorner>
        		<gml:upperCorner>369832.271000 375854.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5035.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369832.271000 375854.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5035</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 145 523</ms:GML_ID>
        <ms:NAZWA>143 145 523</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143145523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5034">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369850.521000 376661.546000</gml:lowerCorner>
        		<gml:upperCorner>369850.521000 376661.546000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5034.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369850.521000 376661.546000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5034</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 144 715</ms:GML_ID>
        <ms:NAZWA>143 144 715</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143144715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370043.559965 379831.181628</gml:lowerCorner>
        		<gml:upperCorner>370043.559965 379831.181628</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370043.559965 379831.181628</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 141 533</ms:GML_ID>
        <ms:NAZWA>143 141 533</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143141533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5032">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370166.071838 380627.323646</gml:lowerCorner>
        		<gml:upperCorner>370166.071838 380627.323646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5032.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370166.071838 380627.323646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5032</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 140 728</ms:GML_ID>
        <ms:NAZWA>143 140 728</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143140728</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5031">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370542.579000 382167.173000</gml:lowerCorner>
        		<gml:upperCorner>370542.579000 382167.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5031.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370542.579000 382167.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5031</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 139 139</ms:GML_ID>
        <ms:NAZWA>143 139 139</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143139139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5030">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371147.073673 384149.457868</gml:lowerCorner>
        		<gml:upperCorner>371147.073673 384149.457868</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5030.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371147.073673 384149.457868</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5030</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 137 067</ms:GML_ID>
        <ms:NAZWA>143 137 067</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143137067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5029">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371409.023000 385011.118000</gml:lowerCorner>
        		<gml:upperCorner>371409.023000 385011.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5029.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371409.023000 385011.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5029</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 136 166</ms:GML_ID>
        <ms:NAZWA>143 136 166</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143136166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5028">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371657.496602 385826.397828</gml:lowerCorner>
        		<gml:upperCorner>371657.496602 385826.397828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5028.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371657.496602 385826.397828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5028</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 135 315</ms:GML_ID>
        <ms:NAZWA>143 135 315</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143135315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379191.577000 385755.837000</gml:lowerCorner>
        		<gml:upperCorner>379191.577000 385755.837000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379191.577000 385755.837000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 008 587</ms:GML_ID>
        <ms:NAZWA>281 008 587</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281008587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>405278.460000 385695.219000</gml:lowerCorner>
        		<gml:upperCorner>405278.460000 385695.219000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>405278.460000 385695.219000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.281 036 761</ms:GML_ID>
        <ms:NAZWA>281 036 761</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>281036761</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360175.897871 356559.764880</gml:lowerCorner>
        		<gml:upperCorner>360175.897871 356559.764880</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360175.897871 356559.764880</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 005 160</ms:GML_ID>
        <ms:NAZWA>274 005 160</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274005160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360214.390000 356547.039000</gml:lowerCorner>
        		<gml:upperCorner>360214.390000 356547.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360214.390000 356547.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.751 005 660</ms:GML_ID>
        <ms:NAZWA>751 005 660</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>751005660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360856.402000 356888.446000</gml:lowerCorner>
        		<gml:upperCorner>360856.402000 356888.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360856.402000 356888.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.751 004 842</ms:GML_ID>
        <ms:NAZWA>751 004 842</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>751004842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361322.590000 356757.458000</gml:lowerCorner>
        		<gml:upperCorner>361322.590000 356757.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361322.590000 356757.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.751 004 363</ms:GML_ID>
        <ms:NAZWA>751 004 363</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>751004363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362095.795000 356615.019000</gml:lowerCorner>
        		<gml:upperCorner>362095.795000 356615.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362095.795000 356615.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.751 003 560</ms:GML_ID>
        <ms:NAZWA>751 003 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>751003560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.298">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363606.453000 356317.333000</gml:lowerCorner>
        		<gml:upperCorner>363606.453000 356317.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.298.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363606.453000 356317.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>298</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 007 289</ms:GML_ID>
        <ms:NAZWA>275 007 289</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275007289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.299">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363886.097000 355369.833000</gml:lowerCorner>
        		<gml:upperCorner>363886.097000 355369.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.299.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363886.097000 355369.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>299</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 008 273</ms:GML_ID>
        <ms:NAZWA>275 008 273</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275008273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364215.305459 356877.915025</gml:lowerCorner>
        		<gml:upperCorner>364215.305459 356877.915025</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364215.305459 356877.915025</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 007 159</ms:GML_ID>
        <ms:NAZWA>273 007 159</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273007159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364266.217000 354080.956000</gml:lowerCorner>
        		<gml:upperCorner>364266.217000 354080.956000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364266.217000 354080.956000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 009 622</ms:GML_ID>
        <ms:NAZWA>275 009 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275009622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365082.772158 351681.941598</gml:lowerCorner>
        		<gml:upperCorner>365082.772158 351681.941598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365082.772158 351681.941598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 012 166</ms:GML_ID>
        <ms:NAZWA>275 012 166</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275012166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365637.907000 355793.615000</gml:lowerCorner>
        		<gml:upperCorner>365637.907000 355793.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365637.907000 355793.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 008 938</ms:GML_ID>
        <ms:NAZWA>273 008 938</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273008938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366111.843173 350781.739910</gml:lowerCorner>
        		<gml:upperCorner>366111.843173 350781.739910</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366111.843173 350781.739910</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 013 531</ms:GML_ID>
        <ms:NAZWA>275 013 531</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275013531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366303.625850 350690.845081</gml:lowerCorner>
        		<gml:upperCorner>366303.625850 350690.845081</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366303.625850 350690.845081</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 013 741</ms:GML_ID>
        <ms:NAZWA>275 013 741</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275013741</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366590.365276 350479.377822</gml:lowerCorner>
        		<gml:upperCorner>366590.365276 350479.377822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366590.365276 350479.377822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 014 096</ms:GML_ID>
        <ms:NAZWA>275 014 096</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275014096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367143.767000 350073.404000</gml:lowerCorner>
        		<gml:upperCorner>367143.767000 350073.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367143.767000 350073.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 014 786</ms:GML_ID>
        <ms:NAZWA>275 014 786</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275014786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367804.166000 354337.654000</gml:lowerCorner>
        		<gml:upperCorner>367804.166000 354337.654000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367804.166000 354337.654000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 011 556</ms:GML_ID>
        <ms:NAZWA>273 011 556</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273011556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369223.307494 353385.636226</gml:lowerCorner>
        		<gml:upperCorner>369223.307494 353385.636226</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369223.307494 353385.636226</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 013 261</ms:GML_ID>
        <ms:NAZWA>273 013 261</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273013261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369483.186000 348358.534000</gml:lowerCorner>
        		<gml:upperCorner>369483.186000 348358.534000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369483.186000 348358.534000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 017 686</ms:GML_ID>
        <ms:NAZWA>275 017 686</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275017686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370280.476000 352671.190000</gml:lowerCorner>
        		<gml:upperCorner>370280.476000 352671.190000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370280.476000 352671.190000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 014 537</ms:GML_ID>
        <ms:NAZWA>273 014 537</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273014537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4892">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355923.011350 366506.935474</gml:lowerCorner>
        		<gml:upperCorner>355923.011350 366506.935474</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4892.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355923.011350 366506.935474</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4892</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 003 428</ms:GML_ID>
        <ms:NAZWA>349 003 428</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349003428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4891">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355796.090079 366656.740370</gml:lowerCorner>
        		<gml:upperCorner>355796.090079 366656.740370</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4891.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355796.090079 366656.740370</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4891</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 003 060</ms:GML_ID>
        <ms:NAZWA>349 003 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349003060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4890">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355800.943030 366714.212162</gml:lowerCorner>
        		<gml:upperCorner>355800.943030 366714.212162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4890.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355800.943030 366714.212162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4890</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 003 050</ms:GML_ID>
        <ms:NAZWA>349 003 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349003050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4889">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355643.814851 366776.485910</gml:lowerCorner>
        		<gml:upperCorner>355643.814851 366776.485910</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4889.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355643.814851 366776.485910</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4889</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 002 874</ms:GML_ID>
        <ms:NAZWA>349 002 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349002874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353210.866000 368324.759000</gml:lowerCorner>
        		<gml:upperCorner>353210.866000 368324.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353210.866000 368324.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 171 112</ms:GML_ID>
        <ms:NAZWA>132 171 112</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132171112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351460.046000 370095.481000</gml:lowerCorner>
        		<gml:upperCorner>351460.046000 370095.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351460.046000 370095.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 168 620</ms:GML_ID>
        <ms:NAZWA>132 168 620</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132168620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354029.740953 370110.930410</gml:lowerCorner>
        		<gml:upperCorner>354029.740953 370110.930410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354029.740953 370110.930410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 082 192</ms:GML_ID>
        <ms:NAZWA>277 082 192</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277082192</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354055.730517 370511.287535</gml:lowerCorner>
        		<gml:upperCorner>354055.730517 370511.287535</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354055.730517 370511.287535</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 081 789</ms:GML_ID>
        <ms:NAZWA>277 081 789</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277081789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350479.456255 371096.636237</gml:lowerCorner>
        		<gml:upperCorner>350479.456255 371096.636237</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350479.456255 371096.636237</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 167 219</ms:GML_ID>
        <ms:NAZWA>132 167 219</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132167219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360345.977000 372094.164000</gml:lowerCorner>
        		<gml:upperCorner>360345.977000 372094.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360345.977000 372094.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 012 452</ms:GML_ID>
        <ms:NAZWA>292 012 452</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292012452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349106.282000 372442.360000</gml:lowerCorner>
        		<gml:upperCorner>349106.282000 372442.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349106.282000 372442.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 165 297</ms:GML_ID>
        <ms:NAZWA>132 165 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132165297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359285.756383 372651.971177</gml:lowerCorner>
        		<gml:upperCorner>359285.756383 372651.971177</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359285.756383 372651.971177</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 011 250</ms:GML_ID>
        <ms:NAZWA>292 011 250</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292011250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353714.829000 372967.184000</gml:lowerCorner>
        		<gml:upperCorner>353714.829000 372967.184000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353714.829000 372967.184000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 079 286</ms:GML_ID>
        <ms:NAZWA>277 079 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277079286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358945.121740 373948.508989</gml:lowerCorner>
        		<gml:upperCorner>358945.121740 373948.508989</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358945.121740 373948.508989</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 009 845</ms:GML_ID>
        <ms:NAZWA>292 009 845</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292009845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346564.592000 374672.618000</gml:lowerCorner>
        		<gml:upperCorner>346564.592000 374672.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346564.592000 374672.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 161 914</ms:GML_ID>
        <ms:NAZWA>132 161 914</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132161914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358721.645896 375371.922993</gml:lowerCorner>
        		<gml:upperCorner>358721.645896 375371.922993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358721.645896 375371.922993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 008 405</ms:GML_ID>
        <ms:NAZWA>292 008 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292008405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358583.682853 376252.719257</gml:lowerCorner>
        		<gml:upperCorner>358583.682853 376252.719257</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358583.682853 376252.719257</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 007 514</ms:GML_ID>
        <ms:NAZWA>292 007 514</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292007514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358516.528000 376679.596000</gml:lowerCorner>
        		<gml:upperCorner>358516.528000 376679.596000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358516.528000 376679.596000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 007 080</ms:GML_ID>
        <ms:NAZWA>292 007 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292007080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355123.119222 377249.198174</gml:lowerCorner>
        		<gml:upperCorner>355123.119222 377249.198174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355123.119222 377249.198174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 074 362</ms:GML_ID>
        <ms:NAZWA>277 074 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277074362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358461.454000 377442.719000</gml:lowerCorner>
        		<gml:upperCorner>358461.454000 377442.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358461.454000 377442.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 006 312</ms:GML_ID>
        <ms:NAZWA>292 006 312</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292006312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358495.515422 378627.487665</gml:lowerCorner>
        		<gml:upperCorner>358495.515422 378627.487665</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358495.515422 378627.487665</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 005 127</ms:GML_ID>
        <ms:NAZWA>292 005 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292005127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357660.195076 379291.368437</gml:lowerCorner>
        		<gml:upperCorner>357660.195076 379291.368437</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357660.195076 379291.368437</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 003 990</ms:GML_ID>
        <ms:NAZWA>292 003 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292003990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356764.901909 379683.551673</gml:lowerCorner>
        		<gml:upperCorner>356764.901909 379683.551673</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356764.901909 379683.551673</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 003 010</ms:GML_ID>
        <ms:NAZWA>292 003 010</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292003010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354648.443000 380303.045000</gml:lowerCorner>
        		<gml:upperCorner>354648.443000 380303.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354648.443000 380303.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 071 262</ms:GML_ID>
        <ms:NAZWA>277 071 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277071262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354762.216000 380560.783000</gml:lowerCorner>
        		<gml:upperCorner>354762.216000 380560.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354762.216000 380560.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.292 000 824</ms:GML_ID>
        <ms:NAZWA>292 000 824</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>292000824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353999.516214 383240.456568</gml:lowerCorner>
        		<gml:upperCorner>353999.516214 383240.456568</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353999.516214 383240.456568</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 068 255</ms:GML_ID>
        <ms:NAZWA>277 068 255</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277068255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353122.067000 384731.832000</gml:lowerCorner>
        		<gml:upperCorner>353122.067000 384731.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353122.067000 384731.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 066 520</ms:GML_ID>
        <ms:NAZWA>277 066 520</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277066520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352806.616000 385250.209000</gml:lowerCorner>
        		<gml:upperCorner>352806.616000 385250.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352806.616000 385250.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 065 912</ms:GML_ID>
        <ms:NAZWA>277 065 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277065912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352486.966055 385777.964941</gml:lowerCorner>
        		<gml:upperCorner>352486.966055 385777.964941</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352486.966055 385777.964941</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 065 291</ms:GML_ID>
        <ms:NAZWA>277 065 291</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277065291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346093.129000 362765.395000</gml:lowerCorner>
        		<gml:upperCorner>346093.129000 362765.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346093.129000 362765.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 016 380</ms:GML_ID>
        <ms:NAZWA>276 016 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276016380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347526.131000 363034.617000</gml:lowerCorner>
        		<gml:upperCorner>347526.131000 363034.617000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347526.131000 363034.617000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 014 922</ms:GML_ID>
        <ms:NAZWA>276 014 922</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276014922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348345.094881 363198.758222</gml:lowerCorner>
        		<gml:upperCorner>348345.094881 363198.758222</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348345.094881 363198.758222</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 014 087</ms:GML_ID>
        <ms:NAZWA>276 014 087</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276014087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350040.116935 363513.250815</gml:lowerCorner>
        		<gml:upperCorner>350040.116935 363513.250815</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350040.116935 363513.250815</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 012 367</ms:GML_ID>
        <ms:NAZWA>276 012 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276012367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352006.375000 364149.910000</gml:lowerCorner>
        		<gml:upperCorner>352006.375000 364149.910000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352006.375000 364149.910000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 010 292</ms:GML_ID>
        <ms:NAZWA>276 010 292</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276010292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4335">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352549.021000 357351.586000</gml:lowerCorner>
        		<gml:upperCorner>352549.021000 357351.586000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4335.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352549.021000 357351.586000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4335</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 014 540</ms:GML_ID>
        <ms:NAZWA>285 014 540</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285014540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353203.234521 364422.442764</gml:lowerCorner>
        		<gml:upperCorner>353203.234521 364422.442764</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353203.234521 364422.442764</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 009 060</ms:GML_ID>
        <ms:NAZWA>276 009 060</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276009060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4334">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354283.694000 358185.121000</gml:lowerCorner>
        		<gml:upperCorner>354283.694000 358185.121000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4334.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354283.694000 358185.121000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4334</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 012 601</ms:GML_ID>
        <ms:NAZWA>285 012 601</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285012601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354660.134000 364565.924000</gml:lowerCorner>
        		<gml:upperCorner>354660.134000 364565.924000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354660.134000 364565.924000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 007 596</ms:GML_ID>
        <ms:NAZWA>276 007 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276007596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4333">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354816.934896 358377.391139</gml:lowerCorner>
        		<gml:upperCorner>354816.934896 358377.391139</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4333.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354816.934896 358377.391139</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4333</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 012 033</ms:GML_ID>
        <ms:NAZWA>285 012 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285012033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4893">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356477.516496 366189.006064</gml:lowerCorner>
        		<gml:upperCorner>356477.516496 366189.006064</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4893.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356477.516496 366189.006064</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4893</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 003 915</ms:GML_ID>
        <ms:NAZWA>349 003 915</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349003915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4332">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356529.939081 359016.669065</gml:lowerCorner>
        		<gml:upperCorner>356529.939081 359016.669065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4332.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356529.939081 359016.669065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4332</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 010 204</ms:GML_ID>
        <ms:NAZWA>285 010 204</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285010204</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4894">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356616.247539 366001.483180</gml:lowerCorner>
        		<gml:upperCorner>356616.247539 366001.483180</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4894.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356616.247539 366001.483180</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4894</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 004 130</ms:GML_ID>
        <ms:NAZWA>349 004 130</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349004130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356828.891916 359735.373976</gml:lowerCorner>
        		<gml:upperCorner>356828.891916 359735.373976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356828.891916 359735.373976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 009 418</ms:GML_ID>
        <ms:NAZWA>285 009 418</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285009418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357016.979000 364883.695000</gml:lowerCorner>
        		<gml:upperCorner>357016.979000 364883.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357016.979000 364883.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 005 214</ms:GML_ID>
        <ms:NAZWA>276 005 214</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276005214</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357066.476000 364657.554000</gml:lowerCorner>
        		<gml:upperCorner>357066.476000 364657.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357066.476000 364657.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.765 003 845</ms:GML_ID>
        <ms:NAZWA>765 003 845</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>765003845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357118.239609 360551.155707</gml:lowerCorner>
        		<gml:upperCorner>357118.239609 360551.155707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357118.239609 360551.155707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 008 547</ms:GML_ID>
        <ms:NAZWA>285 008 547</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285008547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4895">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357230.798957 365793.882070</gml:lowerCorner>
        		<gml:upperCorner>357230.798957 365793.882070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4895.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357230.798957 365793.882070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4895</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 004 742</ms:GML_ID>
        <ms:NAZWA>349 004 742</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349004742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357321.574763 361121.809890</gml:lowerCorner>
        		<gml:upperCorner>357321.574763 361121.809890</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357321.574763 361121.809890</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 007 945</ms:GML_ID>
        <ms:NAZWA>285 007 945</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285007945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4896">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357349.321810 365816.003530</gml:lowerCorner>
        		<gml:upperCorner>357349.321810 365816.003530</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4896.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357349.321810 365816.003530</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4896</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.349 004 880</ms:GML_ID>
        <ms:NAZWA>349 004 880</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>349004880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357457.035000 364403.104000</gml:lowerCorner>
        		<gml:upperCorner>357457.035000 364403.104000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357457.035000 364403.104000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.765 003 390</ms:GML_ID>
        <ms:NAZWA>765 003 390</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>765003390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357481.360634 361573.944755</gml:lowerCorner>
        		<gml:upperCorner>357481.360634 361573.944755</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357481.360634 361573.944755</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 007 464</ms:GML_ID>
        <ms:NAZWA>285 007 464</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285007464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357645.693000 362169.716000</gml:lowerCorner>
        		<gml:upperCorner>357645.693000 362169.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357645.693000 362169.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 006 850</ms:GML_ID>
        <ms:NAZWA>285 006 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285006850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357695.661635 362442.397269</gml:lowerCorner>
        		<gml:upperCorner>357695.661635 362442.397269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357695.661635 362442.397269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 006 569</ms:GML_ID>
        <ms:NAZWA>285 006 569</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285006569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357707.447000 365034.197000</gml:lowerCorner>
        		<gml:upperCorner>357707.447000 365034.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357707.447000 365034.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 004 507</ms:GML_ID>
        <ms:NAZWA>276 004 507</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276004507</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357720.449058 362672.870485</gml:lowerCorner>
        		<gml:upperCorner>357720.449058 362672.870485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357720.449058 362672.870485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 006 338</ms:GML_ID>
        <ms:NAZWA>285 006 338</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285006338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357827.041685 363669.949380</gml:lowerCorner>
        		<gml:upperCorner>357827.041685 363669.949380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357827.041685 363669.949380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 005 326</ms:GML_ID>
        <ms:NAZWA>285 005 326</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285005326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.143">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345489.536000 325974.119000</gml:lowerCorner>
        		<gml:upperCorner>345489.536000 325974.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.143.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345489.536000 325974.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>143</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 040 280</ms:GML_ID>
        <ms:NAZWA>274 040 280</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274040280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.141">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346877.630019 330297.932006</gml:lowerCorner>
        		<gml:upperCorner>346877.630019 330297.932006</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.141.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346877.630019 330297.932006</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>141</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 035 579</ms:GML_ID>
        <ms:NAZWA>274 035 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274035579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.139">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349017.208556 335396.478682</gml:lowerCorner>
        		<gml:upperCorner>349017.208556 335396.478682</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.139.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349017.208556 335396.478682</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>139</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 029 770</ms:GML_ID>
        <ms:NAZWA>274 029 770</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274029770</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350233.447000 318893.826000</gml:lowerCorner>
        		<gml:upperCorner>350233.447000 318893.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350233.447000 318893.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 030 703</ms:GML_ID>
        <ms:NAZWA>302 030 703</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302030703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350302.995000 318446.949000</gml:lowerCorner>
        		<gml:upperCorner>350302.995000 318446.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350302.995000 318446.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 031 156</ms:GML_ID>
        <ms:NAZWA>302 031 156</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302031156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350444.986000 317790.234000</gml:lowerCorner>
        		<gml:upperCorner>350444.986000 317790.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350444.986000 317790.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 031 877</ms:GML_ID>
        <ms:NAZWA>302 031 877</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302031877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351205.155000 320063.907000</gml:lowerCorner>
        		<gml:upperCorner>351205.155000 320063.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351205.155000 320063.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 028 688</ms:GML_ID>
        <ms:NAZWA>302 028 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302028688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352553.606942 320579.195645</gml:lowerCorner>
        		<gml:upperCorner>352553.606942 320579.195645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352553.606942 320579.195645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 027 202</ms:GML_ID>
        <ms:NAZWA>302 027 202</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302027202</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352849.997000 320629.039000</gml:lowerCorner>
        		<gml:upperCorner>352849.997000 320629.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352849.997000 320629.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 026 940</ms:GML_ID>
        <ms:NAZWA>302 026 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302026940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353270.650000 320618.462000</gml:lowerCorner>
        		<gml:upperCorner>353270.650000 320618.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353270.650000 320618.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 026 520</ms:GML_ID>
        <ms:NAZWA>302 026 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302026520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353803.189000 320603.222000</gml:lowerCorner>
        		<gml:upperCorner>353803.189000 320603.222000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353803.189000 320603.222000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 025 984</ms:GML_ID>
        <ms:NAZWA>302 025 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302025984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354081.011000 320592.955000</gml:lowerCorner>
        		<gml:upperCorner>354081.011000 320592.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354081.011000 320592.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 025 710</ms:GML_ID>
        <ms:NAZWA>302 025 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302025710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4653">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354784.630000 320574.717000</gml:lowerCorner>
        		<gml:upperCorner>354784.630000 320574.717000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4653.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354784.630000 320574.717000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4653</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 025 010</ms:GML_ID>
        <ms:NAZWA>302 025 010</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302025010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355205.366000 320561.557000</gml:lowerCorner>
        		<gml:upperCorner>355205.366000 320561.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355205.366000 320561.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 024 582</ms:GML_ID>
        <ms:NAZWA>302 024 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302024582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355380.860000 320558.302000</gml:lowerCorner>
        		<gml:upperCorner>355380.860000 320558.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355380.860000 320558.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 024 410</ms:GML_ID>
        <ms:NAZWA>302 024 410</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302024410</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356877.415000 320715.158000</gml:lowerCorner>
        		<gml:upperCorner>356877.415000 320715.158000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356877.415000 320715.158000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 022 896</ms:GML_ID>
        <ms:NAZWA>302 022 896</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302022896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357203.043000 320781.063000</gml:lowerCorner>
        		<gml:upperCorner>357203.043000 320781.063000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357203.043000 320781.063000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 022 564</ms:GML_ID>
        <ms:NAZWA>302 022 564</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302022564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357796.727000 320886.539000</gml:lowerCorner>
        		<gml:upperCorner>357796.727000 320886.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357796.727000 320886.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 021 962</ms:GML_ID>
        <ms:NAZWA>302 021 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302021962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.138">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350985.309705 338123.623780</gml:lowerCorner>
        		<gml:upperCorner>350985.309705 338123.623780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.138.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350985.309705 338123.623780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>138</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 026 380</ms:GML_ID>
        <ms:NAZWA>274 026 380</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274026380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.137">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352035.980000 338661.660000</gml:lowerCorner>
        		<gml:upperCorner>352035.980000 338661.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.137.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352035.980000 338661.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>137</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 025 199</ms:GML_ID>
        <ms:NAZWA>274 025 199</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274025199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.136">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353781.639000 340198.257000</gml:lowerCorner>
        		<gml:upperCorner>353781.639000 340198.257000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.136.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353781.639000 340198.257000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>136</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 022 788</ms:GML_ID>
        <ms:NAZWA>274 022 788</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274022788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.135">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354439.410763 341607.492780</gml:lowerCorner>
        		<gml:upperCorner>354439.410763 341607.492780</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.135.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354439.410763 341607.492780</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>135</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 021 231</ms:GML_ID>
        <ms:NAZWA>274 021 231</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274021231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

