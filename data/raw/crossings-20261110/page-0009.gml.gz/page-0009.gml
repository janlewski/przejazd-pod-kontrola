<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:29" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=8000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=10000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>255223.658385 207136.181000</gml:lowerCorner>
      		<gml:upperCorner>487672.410109 423944.436768</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.134">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354831.160106 342447.367752</gml:lowerCorner>
        		<gml:upperCorner>354831.160106 342447.367752</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.134.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354831.160106 342447.367752</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>134</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 020 305</ms:GML_ID>
        <ms:NAZWA>274 020 305</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274020305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355611.615000 344129.907000</gml:lowerCorner>
        		<gml:upperCorner>355611.615000 344129.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355611.615000 344129.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 018 450</ms:GML_ID>
        <ms:NAZWA>274 018 450</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274018450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355900.643000 344788.720000</gml:lowerCorner>
        		<gml:upperCorner>355900.643000 344788.720000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355900.643000 344788.720000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 017 731</ms:GML_ID>
        <ms:NAZWA>274 017 731</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274017731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356001.459000 345472.323000</gml:lowerCorner>
        		<gml:upperCorner>356001.459000 345472.323000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356001.459000 345472.323000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 017 038</ms:GML_ID>
        <ms:NAZWA>274 017 038</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274017038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356038.713000 345849.433000</gml:lowerCorner>
        		<gml:upperCorner>356038.713000 345849.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356038.713000 345849.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 016 657</ms:GML_ID>
        <ms:NAZWA>274 016 657</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274016657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356650.422000 347698.243000</gml:lowerCorner>
        		<gml:upperCorner>356650.422000 347698.243000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356650.422000 347698.243000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 014 704</ms:GML_ID>
        <ms:NAZWA>274 014 704</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274014704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345085.223000 347797.252000</gml:lowerCorner>
        		<gml:upperCorner>345085.223000 347797.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345085.223000 347797.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 027 806</ms:GML_ID>
        <ms:NAZWA>285 027 806</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285027806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345195.207975 349443.207944</gml:lowerCorner>
        		<gml:upperCorner>345195.207975 349443.207944</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345195.207975 349443.207944</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 026 148</ms:GML_ID>
        <ms:NAZWA>285 026 148</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285026148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357460.809000 349738.794000</gml:lowerCorner>
        		<gml:upperCorner>357460.809000 349738.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357460.809000 349738.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 012 509</ms:GML_ID>
        <ms:NAZWA>274 012 509</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274012509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345708.381000 350766.467000</gml:lowerCorner>
        		<gml:upperCorner>345708.381000 350766.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345708.381000 350766.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 024 714</ms:GML_ID>
        <ms:NAZWA>285 024 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285024714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345928.084116 351183.584228</gml:lowerCorner>
        		<gml:upperCorner>345928.084116 351183.584228</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345928.084116 351183.584228</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 024 241</ms:GML_ID>
        <ms:NAZWA>285 024 241</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285024241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358124.385558 351405.327629</gml:lowerCorner>
        		<gml:upperCorner>358124.385558 351405.327629</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358124.385558 351405.327629</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 010 714</ms:GML_ID>
        <ms:NAZWA>274 010 714</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274010714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358298.740339 351845.928249</gml:lowerCorner>
        		<gml:upperCorner>358298.740339 351845.928249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358298.740339 351845.928249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 010 239</ms:GML_ID>
        <ms:NAZWA>274 010 239</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274010239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346332.825000 352467.131000</gml:lowerCorner>
        		<gml:upperCorner>346332.825000 352467.131000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346332.825000 352467.131000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 022 894</ms:GML_ID>
        <ms:NAZWA>285 022 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285022894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358743.768000 352962.872000</gml:lowerCorner>
        		<gml:upperCorner>358743.768000 352962.872000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358743.768000 352962.872000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 009 031</ms:GML_ID>
        <ms:NAZWA>274 009 031</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274009031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358976.164000 353548.406000</gml:lowerCorner>
        		<gml:upperCorner>358976.164000 353548.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358976.164000 353548.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 008 405</ms:GML_ID>
        <ms:NAZWA>274 008 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274008405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347131.182913 354389.954382</gml:lowerCorner>
        		<gml:upperCorner>347131.182913 354389.954382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347131.182913 354389.954382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 020 763</ms:GML_ID>
        <ms:NAZWA>285 020 763</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285020763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348290.843578 354976.364512</gml:lowerCorner>
        		<gml:upperCorner>348290.843578 354976.364512</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348290.843578 354976.364512</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 019 462</ms:GML_ID>
        <ms:NAZWA>285 019 462</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285019462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4339">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349216.599660 355454.081551</gml:lowerCorner>
        		<gml:upperCorner>349216.599660 355454.081551</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4339.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349216.599660 355454.081551</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4339</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 018 420</ms:GML_ID>
        <ms:NAZWA>285 018 420</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285018420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4338">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350877.651627 356264.772955</gml:lowerCorner>
        		<gml:upperCorner>350877.651627 356264.772955</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4338.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350877.651627 356264.772955</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4338</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 016 571</ms:GML_ID>
        <ms:NAZWA>285 016 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285016571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4337">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351298.864501 356467.783879</gml:lowerCorner>
        		<gml:upperCorner>351298.864501 356467.783879</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4337.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351298.864501 356467.783879</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4337</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 016 102</ms:GML_ID>
        <ms:NAZWA>285 016 102</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285016102</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4336">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351950.931000 356750.627000</gml:lowerCorner>
        		<gml:upperCorner>351950.931000 356750.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4336.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351950.931000 356750.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4336</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 015 386</ms:GML_ID>
        <ms:NAZWA>285 015 386</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285015386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351644.286000 388243.037000</gml:lowerCorner>
        		<gml:upperCorner>351644.286000 388243.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351644.286000 388243.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 062 674</ms:GML_ID>
        <ms:NAZWA>277 062 674</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277062674</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350846.308000 390886.823000</gml:lowerCorner>
        		<gml:upperCorner>350846.308000 390886.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350846.308000 390886.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 059 917</ms:GML_ID>
        <ms:NAZWA>277 059 917</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277059917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348691.261000 395548.473000</gml:lowerCorner>
        		<gml:upperCorner>348691.261000 395548.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348691.261000 395548.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 054 726</ms:GML_ID>
        <ms:NAZWA>277 054 726</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277054726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348119.307781 396541.818723</gml:lowerCorner>
        		<gml:upperCorner>348119.307781 396541.818723</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348119.307781 396541.818723</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 053 576</ms:GML_ID>
        <ms:NAZWA>277 053 576</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277053576</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347117.106000 398717.123000</gml:lowerCorner>
        		<gml:upperCorner>347117.106000 398717.123000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347117.106000 398717.123000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 051 132</ms:GML_ID>
        <ms:NAZWA>277 051 132</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277051132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345546.272791 400707.146784</gml:lowerCorner>
        		<gml:upperCorner>345546.272791 400707.146784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345546.272791 400707.146784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 048 641</ms:GML_ID>
        <ms:NAZWA>277 048 641</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277048641</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5012">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361473.155000 402099.862000</gml:lowerCorner>
        		<gml:upperCorner>361473.155000 402099.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5012.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361473.155000 402099.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5012</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 115 614</ms:GML_ID>
        <ms:NAZWA>143 115 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143115614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344566.345118 402164.240024</gml:lowerCorner>
        		<gml:upperCorner>344566.345118 402164.240024</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344566.345118 402164.240024</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 046 880</ms:GML_ID>
        <ms:NAZWA>277 046 880</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277046880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343970.869000 402814.946000</gml:lowerCorner>
        		<gml:upperCorner>343970.869000 402814.946000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343970.869000 402814.946000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 045 997</ms:GML_ID>
        <ms:NAZWA>277 045 997</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277045997</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5011">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360944.154000 403126.588000</gml:lowerCorner>
        		<gml:upperCorner>360944.154000 403126.588000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5011.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360944.154000 403126.588000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5011</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 114 459</ms:GML_ID>
        <ms:NAZWA>143 114 459</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143114459</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360769.870000 403466.734000</gml:lowerCorner>
        		<gml:upperCorner>360769.870000 403466.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360769.870000 403466.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 114 076</ms:GML_ID>
        <ms:NAZWA>143 114 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143114076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360507.702000 403978.239000</gml:lowerCorner>
        		<gml:upperCorner>360507.702000 403978.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360507.702000 403978.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 113 500</ms:GML_ID>
        <ms:NAZWA>143 113 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143113500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341418.348000 404353.689000</gml:lowerCorner>
        		<gml:upperCorner>341418.348000 404353.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341418.348000 404353.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 043 002</ms:GML_ID>
        <ms:NAZWA>277 043 002</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277043002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360205.121977 404566.684804</gml:lowerCorner>
        		<gml:upperCorner>360205.121977 404566.684804</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360205.121977 404566.684804</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 112 839</ms:GML_ID>
        <ms:NAZWA>143 112 839</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143112839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340134.459654 404813.399970</gml:lowerCorner>
        		<gml:upperCorner>340134.459654 404813.399970</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340134.459654 404813.399970</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 041 628</ms:GML_ID>
        <ms:NAZWA>277 041 628</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277041628</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339335.910000 405340.574000</gml:lowerCorner>
        		<gml:upperCorner>339335.910000 405340.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339335.910000 405340.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 040 672</ms:GML_ID>
        <ms:NAZWA>277 040 672</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277040672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359465.067000 406079.889000</gml:lowerCorner>
        		<gml:upperCorner>359465.067000 406079.889000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359465.067000 406079.889000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 111 152</ms:GML_ID>
        <ms:NAZWA>143 111 152</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143111152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358222.902000 408901.900000</gml:lowerCorner>
        		<gml:upperCorner>358222.902000 408901.900000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358222.902000 408901.900000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 108 065</ms:GML_ID>
        <ms:NAZWA>143 108 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143108065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357606.993061 409509.341135</gml:lowerCorner>
        		<gml:upperCorner>357606.993061 409509.341135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357606.993061 409509.341135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 107 196</ms:GML_ID>
        <ms:NAZWA>143 107 196</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143107196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357465.870000 409655.420000</gml:lowerCorner>
        		<gml:upperCorner>357465.870000 409655.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357465.870000 409655.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 106 993</ms:GML_ID>
        <ms:NAZWA>143 106 993</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143106993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350588.203869 413287.407640</gml:lowerCorner>
        		<gml:upperCorner>350588.203869 413287.407640</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350588.203869 413287.407640</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 052 437</ms:GML_ID>
        <ms:NAZWA>301 052 437</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301052437</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350113.499633 413429.665973</gml:lowerCorner>
        		<gml:upperCorner>350113.499633 413429.665973</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350113.499633 413429.665973</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 051 942</ms:GML_ID>
        <ms:NAZWA>301 051 942</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301051942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349817.475170 413536.431212</gml:lowerCorner>
        		<gml:upperCorner>349817.475170 413536.431212</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349817.475170 413536.431212</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 051 627</ms:GML_ID>
        <ms:NAZWA>301 051 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301051627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349081.877000 413835.897000</gml:lowerCorner>
        		<gml:upperCorner>349081.877000 413835.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349081.877000 413835.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 050 831</ms:GML_ID>
        <ms:NAZWA>301 050 831</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301050831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340825.401000 335563.533000</gml:lowerCorner>
        		<gml:upperCorner>340825.401000 335563.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340825.401000 335563.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 043 385</ms:GML_ID>
        <ms:NAZWA>285 043 385</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285043385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340905.145000 336020.691000</gml:lowerCorner>
        		<gml:upperCorner>340905.145000 336020.691000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340905.145000 336020.691000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 042 922</ms:GML_ID>
        <ms:NAZWA>285 042 922</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285042922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340903.628000 336557.252000</gml:lowerCorner>
        		<gml:upperCorner>340903.628000 336557.252000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340903.628000 336557.252000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 042 375</ms:GML_ID>
        <ms:NAZWA>285 042 375</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285042375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340272.851144 338646.504118</gml:lowerCorner>
        		<gml:upperCorner>340272.851144 338646.504118</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340272.851144 338646.504118</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 040 180</ms:GML_ID>
        <ms:NAZWA>285 040 180</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285040180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340349.671426 339983.830234</gml:lowerCorner>
        		<gml:upperCorner>340349.671426 339983.830234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340349.671426 339983.830234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 038 835</ms:GML_ID>
        <ms:NAZWA>285 038 835</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285038835</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339907.707000 341296.842000</gml:lowerCorner>
        		<gml:upperCorner>339907.707000 341296.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339907.707000 341296.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 037 370</ms:GML_ID>
        <ms:NAZWA>285 037 370</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285037370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341330.555544 341518.941932</gml:lowerCorner>
        		<gml:upperCorner>341330.555544 341518.941932</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341330.555544 341518.941932</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 035 588</ms:GML_ID>
        <ms:NAZWA>285 035 588</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285035588</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341646.791861 341677.741649</gml:lowerCorner>
        		<gml:upperCorner>341646.791861 341677.741649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341646.791861 341677.741649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 035 233</ms:GML_ID>
        <ms:NAZWA>285 035 233</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285035233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341989.767047 341850.536613</gml:lowerCorner>
        		<gml:upperCorner>341989.767047 341850.536613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341989.767047 341850.536613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 034 849</ms:GML_ID>
        <ms:NAZWA>285 034 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285034849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343160.763076 342521.021000</gml:lowerCorner>
        		<gml:upperCorner>343160.763076 342521.021000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343160.763076 342521.021000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 033 488</ms:GML_ID>
        <ms:NAZWA>285 033 488</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285033488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343299.024237 342880.102877</gml:lowerCorner>
        		<gml:upperCorner>343299.024237 342880.102877</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343299.024237 342880.102877</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 033 125</ms:GML_ID>
        <ms:NAZWA>285 033 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285033125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343594.360000 343722.471000</gml:lowerCorner>
        		<gml:upperCorner>343594.360000 343722.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343594.360000 343722.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 032 209</ms:GML_ID>
        <ms:NAZWA>285 032 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285032209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344597.443457 346042.163261</gml:lowerCorner>
        		<gml:upperCorner>344597.443457 346042.163261</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344597.443457 346042.163261</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 029 633</ms:GML_ID>
        <ms:NAZWA>285 029 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285029633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344829.141000 346797.378000</gml:lowerCorner>
        		<gml:upperCorner>344829.141000 346797.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344829.141000 346797.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 028 842</ms:GML_ID>
        <ms:NAZWA>285 028 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285028842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320517.433000 360926.844000</gml:lowerCorner>
        		<gml:upperCorner>320517.433000 360926.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320517.433000 360926.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 043 083</ms:GML_ID>
        <ms:NAZWA>276 043 083</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276043083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320919.438000 361016.543000</gml:lowerCorner>
        		<gml:upperCorner>320919.438000 361016.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320919.438000 361016.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 042 670</ms:GML_ID>
        <ms:NAZWA>276 042 670</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276042670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336298.961817 361046.725846</gml:lowerCorner>
        		<gml:upperCorner>336298.961817 361046.725846</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336298.961817 361046.725846</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 026 338</ms:GML_ID>
        <ms:NAZWA>276 026 338</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276026338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337178.367354 361153.401181</gml:lowerCorner>
        		<gml:upperCorner>337178.367354 361153.401181</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337178.367354 361153.401181</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 025 452</ms:GML_ID>
        <ms:NAZWA>276 025 452</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276025452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5818">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320360.301000 333382.523000</gml:lowerCorner>
        		<gml:upperCorner>320360.301000 333382.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5818.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320360.301000 333382.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5818</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 209 025</ms:GML_ID>
        <ms:NAZWA>137 209 025</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137209025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5819">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320981.602321 332945.234100</gml:lowerCorner>
        		<gml:upperCorner>320981.602321 332945.234100</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5819.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320981.602321 332945.234100</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5819</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 209 787</ms:GML_ID>
        <ms:NAZWA>137 209 787</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137209787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5820">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322354.142000 331979.118000</gml:lowerCorner>
        		<gml:upperCorner>322354.142000 331979.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5820.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322354.142000 331979.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5820</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 211 468</ms:GML_ID>
        <ms:NAZWA>137 211 468</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137211468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322703.169935 331733.729254</gml:lowerCorner>
        		<gml:upperCorner>322703.169935 331733.729254</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322703.169935 331733.729254</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 211 895</ms:GML_ID>
        <ms:NAZWA>137 211 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137211895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323667.921424 331054.862847</gml:lowerCorner>
        		<gml:upperCorner>323667.921424 331054.862847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323667.921424 331054.862847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 213 077</ms:GML_ID>
        <ms:NAZWA>137 213 077</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137213077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324478.053212 330393.208058</gml:lowerCorner>
        		<gml:upperCorner>324478.053212 330393.208058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324478.053212 330393.208058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 214 119</ms:GML_ID>
        <ms:NAZWA>137 214 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137214119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325200.418000 329767.681000</gml:lowerCorner>
        		<gml:upperCorner>325200.418000 329767.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325200.418000 329767.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 215 076</ms:GML_ID>
        <ms:NAZWA>137 215 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137215076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325512.034018 329495.132361</gml:lowerCorner>
        		<gml:upperCorner>325512.034018 329495.132361</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325512.034018 329495.132361</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 215 490</ms:GML_ID>
        <ms:NAZWA>137 215 490</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137215490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326069.075000 329020.658000</gml:lowerCorner>
        		<gml:upperCorner>326069.075000 329020.658000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326069.075000 329020.658000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 216 224</ms:GML_ID>
        <ms:NAZWA>137 216 224</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137216224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326539.281000 328557.761000</gml:lowerCorner>
        		<gml:upperCorner>326539.281000 328557.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326539.281000 328557.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 216 885</ms:GML_ID>
        <ms:NAZWA>137 216 885</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137216885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335895.253000 328080.554000</gml:lowerCorner>
        		<gml:upperCorner>335895.253000 328080.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335895.253000 328080.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 052 468</ms:GML_ID>
        <ms:NAZWA>285 052 468</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285052468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336011.517000 328276.834000</gml:lowerCorner>
        		<gml:upperCorner>336011.517000 328276.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336011.517000 328276.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 052 237</ms:GML_ID>
        <ms:NAZWA>285 052 237</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285052237</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336929.013962 329763.105173</gml:lowerCorner>
        		<gml:upperCorner>336929.013962 329763.105173</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336929.013962 329763.105173</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 050 491</ms:GML_ID>
        <ms:NAZWA>285 050 491</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285050491</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337159.329000 330203.354000</gml:lowerCorner>
        		<gml:upperCorner>337159.329000 330203.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337159.329000 330203.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 049 993</ms:GML_ID>
        <ms:NAZWA>285 049 993</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285049993</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337795.322000 331114.366000</gml:lowerCorner>
        		<gml:upperCorner>337795.322000 331114.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337795.322000 331114.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 048 879</ms:GML_ID>
        <ms:NAZWA>285 048 879</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285048879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338992.312000 332167.580000</gml:lowerCorner>
        		<gml:upperCorner>338992.312000 332167.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338992.312000 332167.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 047 284</ms:GML_ID>
        <ms:NAZWA>285 047 284</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285047284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339450.447000 332915.902000</gml:lowerCorner>
        		<gml:upperCorner>339450.447000 332915.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339450.447000 332915.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 046 425</ms:GML_ID>
        <ms:NAZWA>285 046 425</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285046425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339898.368000 333844.236000</gml:lowerCorner>
        		<gml:upperCorner>339898.368000 333844.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339898.368000 333844.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 045 374</ms:GML_ID>
        <ms:NAZWA>285 045 374</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285045374</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312702.860969 401052.463170</gml:lowerCorner>
        		<gml:upperCorner>312702.860969 401052.463170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312702.860969 401052.463170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 011 073</ms:GML_ID>
        <ms:NAZWA>329 011 073</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329011073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313646.242000 399983.540000</gml:lowerCorner>
        		<gml:upperCorner>313646.242000 399983.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313646.242000 399983.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 012 504</ms:GML_ID>
        <ms:NAZWA>329 012 504</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329012504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313795.459000 399791.520000</gml:lowerCorner>
        		<gml:upperCorner>313795.459000 399791.520000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313795.459000 399791.520000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 012 742</ms:GML_ID>
        <ms:NAZWA>329 012 742</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329012742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314154.920000 399328.621000</gml:lowerCorner>
        		<gml:upperCorner>314154.920000 399328.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314154.920000 399328.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 013 333</ms:GML_ID>
        <ms:NAZWA>329 013 333</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329013333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314439.898000 398950.403000</gml:lowerCorner>
        		<gml:upperCorner>314439.898000 398950.403000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314439.898000 398950.403000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 013 805</ms:GML_ID>
        <ms:NAZWA>329 013 805</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329013805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317308.550000 386087.335000</gml:lowerCorner>
        		<gml:upperCorner>317308.550000 386087.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317308.550000 386087.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 028 543</ms:GML_ID>
        <ms:NAZWA>288 028 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288028543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317423.229000 386208.560000</gml:lowerCorner>
        		<gml:upperCorner>317423.229000 386208.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317423.229000 386208.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 028 709</ms:GML_ID>
        <ms:NAZWA>288 028 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288028709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318693.161000 387560.553000</gml:lowerCorner>
        		<gml:upperCorner>318693.161000 387560.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318693.161000 387560.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 030 567</ms:GML_ID>
        <ms:NAZWA>288 030 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288030567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319031.405000 387920.636000</gml:lowerCorner>
        		<gml:upperCorner>319031.405000 387920.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319031.405000 387920.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 031 061</ms:GML_ID>
        <ms:NAZWA>288 031 061</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288031061</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320036.771732 388991.590673</gml:lowerCorner>
        		<gml:upperCorner>320036.771732 388991.590673</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320036.771732 388991.590673</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 032 531</ms:GML_ID>
        <ms:NAZWA>288 032 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288032531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320824.153000 389830.855000</gml:lowerCorner>
        		<gml:upperCorner>320824.153000 389830.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320824.153000 389830.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 033 683</ms:GML_ID>
        <ms:NAZWA>288 033 683</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288033683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320997.214000 390014.913000</gml:lowerCorner>
        		<gml:upperCorner>320997.214000 390014.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320997.214000 390014.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 033 933</ms:GML_ID>
        <ms:NAZWA>288 033 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288033933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322057.146755 402512.361431</gml:lowerCorner>
        		<gml:upperCorner>322057.146755 402512.361431</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322057.146755 402512.361431</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 124 299</ms:GML_ID>
        <ms:NAZWA>132 124 299</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132124299</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322421.652240 391404.175563</gml:lowerCorner>
        		<gml:upperCorner>322421.652240 391404.175563</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322421.652240 391404.175563</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 035 933</ms:GML_ID>
        <ms:NAZWA>288 035 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288035933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323186.010836 391688.348366</gml:lowerCorner>
        		<gml:upperCorner>323186.010836 391688.348366</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323186.010836 391688.348366</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 036 750</ms:GML_ID>
        <ms:NAZWA>288 036 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288036750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323513.240000 400642.027000</gml:lowerCorner>
        		<gml:upperCorner>323513.240000 400642.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323513.240000 400642.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 126 673</ms:GML_ID>
        <ms:NAZWA>132 126 673</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132126673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324744.547084 392189.265625</gml:lowerCorner>
        		<gml:upperCorner>324744.547084 392189.265625</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324744.547084 392189.265625</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 038 388</ms:GML_ID>
        <ms:NAZWA>288 038 388</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288038388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324864.443461 398921.090648</gml:lowerCorner>
        		<gml:upperCorner>324864.443461 398921.090648</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324864.443461 398921.090648</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 128 864</ms:GML_ID>
        <ms:NAZWA>132 128 864</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132128864</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325882.441302 392555.341307</gml:lowerCorner>
        		<gml:upperCorner>325882.441302 392555.341307</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325882.441302 392555.341307</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 039 584</ms:GML_ID>
        <ms:NAZWA>288 039 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288039584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326507.193000 392756.172000</gml:lowerCorner>
        		<gml:upperCorner>326507.193000 392756.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326507.193000 392756.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 040 240</ms:GML_ID>
        <ms:NAZWA>288 040 240</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288040240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327770.028000 393163.597000</gml:lowerCorner>
        		<gml:upperCorner>327770.028000 393163.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327770.028000 393163.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 041 568</ms:GML_ID>
        <ms:NAZWA>288 041 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288041568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329375.997000 393682.571000</gml:lowerCorner>
        		<gml:upperCorner>329375.997000 393682.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329375.997000 393682.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 043 257</ms:GML_ID>
        <ms:NAZWA>288 043 257</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288043257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330353.646361 394248.785983</gml:lowerCorner>
        		<gml:upperCorner>330353.646361 394248.785983</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330353.646361 394248.785983</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 136 211</ms:GML_ID>
        <ms:NAZWA>132 136 211</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132136211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330589.456482 393930.559465</gml:lowerCorner>
        		<gml:upperCorner>330589.456482 393930.559465</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330589.456482 393930.559465</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 044 505</ms:GML_ID>
        <ms:NAZWA>288 044 505</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288044505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330721.643000 394050.612000</gml:lowerCorner>
        		<gml:upperCorner>330721.643000 394050.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330721.643000 394050.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 136 627</ms:GML_ID>
        <ms:NAZWA>132 136 627</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132136627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332012.532204 386259.274558</gml:lowerCorner>
        		<gml:upperCorner>332012.532204 386259.274558</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332012.532204 386259.274558</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.304 006 582</ms:GML_ID>
        <ms:NAZWA>304 006 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>304006582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332472.603646 387091.154970</gml:lowerCorner>
        		<gml:upperCorner>332472.603646 387091.154970</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332472.603646 387091.154970</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.304 005 632</ms:GML_ID>
        <ms:NAZWA>304 005 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>304005632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332796.635000 387676.303000</gml:lowerCorner>
        		<gml:upperCorner>332796.635000 387676.303000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332796.635000 387676.303000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.304 004 963</ms:GML_ID>
        <ms:NAZWA>304 004 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>304004963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333218.313000 388658.057000</gml:lowerCorner>
        		<gml:upperCorner>333218.313000 388658.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333218.313000 388658.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.304 003 886</ms:GML_ID>
        <ms:NAZWA>304 003 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>304003886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333288.559000 389084.594000</gml:lowerCorner>
        		<gml:upperCorner>333288.559000 389084.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333288.559000 389084.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.304 003 458</ms:GML_ID>
        <ms:NAZWA>304 003 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>304003458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335341.017000 388755.118000</gml:lowerCorner>
        		<gml:upperCorner>335341.017000 388755.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335341.017000 388755.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 143 872</ms:GML_ID>
        <ms:NAZWA>132 143 872</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132143872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4382">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310808.995000 421345.769000</gml:lowerCorner>
        		<gml:upperCorner>310808.995000 421345.769000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4382.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310808.995000 421345.769000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4382</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 000 840</ms:GML_ID>
        <ms:NAZWA>287 000 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287000840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311425.204000 419305.944000</gml:lowerCorner>
        		<gml:upperCorner>311425.204000 419305.944000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311425.204000 419305.944000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 104 230</ms:GML_ID>
        <ms:NAZWA>132 104 230</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132104230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311915.031000 417237.631000</gml:lowerCorner>
        		<gml:upperCorner>311915.031000 417237.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311915.031000 417237.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 106 271</ms:GML_ID>
        <ms:NAZWA>132 106 271</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132106271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312085.096000 401527.845000</gml:lowerCorner>
        		<gml:upperCorner>312085.096000 401527.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312085.096000 401527.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 010 287</ms:GML_ID>
        <ms:NAZWA>329 010 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329010287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312093.859000 416509.059000</gml:lowerCorner>
        		<gml:upperCorner>312093.859000 416509.059000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312093.859000 416509.059000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 107 022</ms:GML_ID>
        <ms:NAZWA>132 107 022</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132107022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312567.066745 423522.171004</gml:lowerCorner>
        		<gml:upperCorner>312567.066745 423522.171004</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312567.066745 423522.171004</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 007 571</ms:GML_ID>
        <ms:NAZWA>277 007 571</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277007571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312590.481040 423944.436768</gml:lowerCorner>
        		<gml:upperCorner>312590.481040 423944.436768</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312590.481040 423944.436768</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 007 143</ms:GML_ID>
        <ms:NAZWA>277 007 143</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277007143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312836.556446 400940.136527</gml:lowerCorner>
        		<gml:upperCorner>312836.556446 400940.136527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312836.556446 400940.136527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 011 247</ms:GML_ID>
        <ms:NAZWA>329 011 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329011247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5679">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313090.407000 414110.655000</gml:lowerCorner>
        		<gml:upperCorner>313090.407000 414110.655000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5679.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313090.407000 414110.655000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5679</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 109 617</ms:GML_ID>
        <ms:NAZWA>132 109 617</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132109617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314139.237466 412576.665292</gml:lowerCorner>
        		<gml:upperCorner>314139.237466 412576.665292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314139.237466 412576.665292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 111 490</ms:GML_ID>
        <ms:NAZWA>132 111 490</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132111490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314678.801000 411890.365000</gml:lowerCorner>
        		<gml:upperCorner>314678.801000 411890.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314678.801000 411890.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 112 363</ms:GML_ID>
        <ms:NAZWA>132 112 363</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132112363</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314802.472000 423666.911000</gml:lowerCorner>
        		<gml:upperCorner>314802.472000 423666.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314802.472000 423666.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 009 033</ms:GML_ID>
        <ms:NAZWA>277 009 033</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277009033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315183.401000 411247.701000</gml:lowerCorner>
        		<gml:upperCorner>315183.401000 411247.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315183.401000 411247.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 113 180</ms:GML_ID>
        <ms:NAZWA>132 113 180</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132113180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5683">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316153.377000 410010.334000</gml:lowerCorner>
        		<gml:upperCorner>316153.377000 410010.334000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5683.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316153.377000 410010.334000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5683</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 114 753</ms:GML_ID>
        <ms:NAZWA>132 114 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132114753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5684">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318030.136000 407621.123000</gml:lowerCorner>
        		<gml:upperCorner>318030.136000 407621.123000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5684.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318030.136000 407621.123000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5684</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 117 793</ms:GML_ID>
        <ms:NAZWA>132 117 793</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132117793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5685">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319293.844000 406012.855000</gml:lowerCorner>
        		<gml:upperCorner>319293.844000 406012.855000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5685.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319293.844000 406012.855000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5685</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 119 840</ms:GML_ID>
        <ms:NAZWA>132 119 840</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132119840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321903.214728 420013.449356</gml:lowerCorner>
        		<gml:upperCorner>321903.214728 420013.449356</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321903.214728 420013.449356</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 017 235</ms:GML_ID>
        <ms:NAZWA>277 017 235</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277017235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324148.855000 418884.912000</gml:lowerCorner>
        		<gml:upperCorner>324148.855000 418884.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324148.855000 418884.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 019 886</ms:GML_ID>
        <ms:NAZWA>277 019 886</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277019886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324751.115000 417957.458000</gml:lowerCorner>
        		<gml:upperCorner>324751.115000 417957.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324751.115000 417957.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 020 996</ms:GML_ID>
        <ms:NAZWA>277 020 996</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277020996</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325369.663000 417009.664000</gml:lowerCorner>
        		<gml:upperCorner>325369.663000 417009.664000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325369.663000 417009.664000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 022 128</ms:GML_ID>
        <ms:NAZWA>277 022 128</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277022128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326495.903131 415965.675505</gml:lowerCorner>
        		<gml:upperCorner>326495.903131 415965.675505</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326495.903131 415965.675505</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 023 667</ms:GML_ID>
        <ms:NAZWA>277 023 667</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277023667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327089.421373 415428.286720</gml:lowerCorner>
        		<gml:upperCorner>327089.421373 415428.286720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327089.421373 415428.286720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 024 470</ms:GML_ID>
        <ms:NAZWA>277 024 470</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277024470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327775.547000 414806.128000</gml:lowerCorner>
        		<gml:upperCorner>327775.547000 414806.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327775.547000 414806.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 025 396</ms:GML_ID>
        <ms:NAZWA>277 025 396</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277025396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328533.474821 414121.575194</gml:lowerCorner>
        		<gml:upperCorner>328533.474821 414121.575194</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328533.474821 414121.575194</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 026 413</ms:GML_ID>
        <ms:NAZWA>277 026 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277026413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330610.214959 412243.656545</gml:lowerCorner>
        		<gml:upperCorner>330610.214959 412243.656545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330610.214959 412243.656545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 029 219</ms:GML_ID>
        <ms:NAZWA>277 029 219</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277029219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332427.130021 410584.806314</gml:lowerCorner>
        		<gml:upperCorner>332427.130021 410584.806314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332427.130021 410584.806314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 031 686</ms:GML_ID>
        <ms:NAZWA>277 031 686</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277031686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334186.107042 408692.121135</gml:lowerCorner>
        		<gml:upperCorner>334186.107042 408692.121135</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334186.107042 408692.121135</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 034 287</ms:GML_ID>
        <ms:NAZWA>277 034 287</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277034287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334741.630684 408603.239778</gml:lowerCorner>
        		<gml:upperCorner>334741.630684 408603.239778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334741.630684 408603.239778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 034 850</ms:GML_ID>
        <ms:NAZWA>277 034 850</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277034850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335872.960000 422026.360000</gml:lowerCorner>
        		<gml:upperCorner>335872.960000 422026.360000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335872.960000 422026.360000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 034 874</ms:GML_ID>
        <ms:NAZWA>301 034 874</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301034874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336227.060000 408152.028000</gml:lowerCorner>
        		<gml:upperCorner>336227.060000 408152.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336227.060000 408152.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 036 455</ms:GML_ID>
        <ms:NAZWA>277 036 455</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277036455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336664.644000 421036.125000</gml:lowerCorner>
        		<gml:upperCorner>336664.644000 421036.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336664.644000 421036.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 036 145</ms:GML_ID>
        <ms:NAZWA>301 036 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301036145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5808">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308579.703000 343897.304000</gml:lowerCorner>
        		<gml:upperCorner>308579.703000 343897.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5808.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308579.703000 343897.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5808</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 190 313</ms:GML_ID>
        <ms:NAZWA>137 190 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137190313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5807">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306934.998000 344690.005000</gml:lowerCorner>
        		<gml:upperCorner>306934.998000 344690.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5807.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306934.998000 344690.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5807</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 188 478</ms:GML_ID>
        <ms:NAZWA>137 188 478</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137188478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5806">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304633.905000 345742.458000</gml:lowerCorner>
        		<gml:upperCorner>304633.905000 345742.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5806.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304633.905000 345742.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5806</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 185 947</ms:GML_ID>
        <ms:NAZWA>137 185 947</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137185947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303953.256000 346324.206000</gml:lowerCorner>
        		<gml:upperCorner>303953.256000 346324.206000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303953.256000 346324.206000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 185 032</ms:GML_ID>
        <ms:NAZWA>137 185 032</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137185032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303770.824000 346607.088000</gml:lowerCorner>
        		<gml:upperCorner>303770.824000 346607.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303770.824000 346607.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 184 696</ms:GML_ID>
        <ms:NAZWA>137 184 696</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137184696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300624.811000 353527.775000</gml:lowerCorner>
        		<gml:upperCorner>300624.811000 353527.775000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300624.811000 353527.775000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 068 388</ms:GML_ID>
        <ms:NAZWA>276 068 388</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276068388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301703.380629 354659.911504</gml:lowerCorner>
        		<gml:upperCorner>301703.380629 354659.911504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301703.380629 354659.911504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 066 793</ms:GML_ID>
        <ms:NAZWA>276 066 793</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276066793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304135.698000 356507.576000</gml:lowerCorner>
        		<gml:upperCorner>304135.698000 356507.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304135.698000 356507.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 063 338</ms:GML_ID>
        <ms:NAZWA>276 063 338</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276063338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304262.385000 356854.178000</gml:lowerCorner>
        		<gml:upperCorner>304262.385000 356854.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304262.385000 356854.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 062 967</ms:GML_ID>
        <ms:NAZWA>276 062 967</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276062967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304706.231000 360105.867000</gml:lowerCorner>
        		<gml:upperCorner>304706.231000 360105.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304706.231000 360105.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 059 536</ms:GML_ID>
        <ms:NAZWA>276 059 536</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276059536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305619.693000 360659.418000</gml:lowerCorner>
        		<gml:upperCorner>305619.693000 360659.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305619.693000 360659.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 058 458</ms:GML_ID>
        <ms:NAZWA>276 058 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276058458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306144.478967 360899.653326</gml:lowerCorner>
        		<gml:upperCorner>306144.478967 360899.653326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306144.478967 360899.653326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 057 879</ms:GML_ID>
        <ms:NAZWA>276 057 879</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276057879</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310504.275000 360922.272000</gml:lowerCorner>
        		<gml:upperCorner>310504.275000 360922.272000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310504.275000 360922.272000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 053 436</ms:GML_ID>
        <ms:NAZWA>276 053 436</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276053436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316573.449000 360938.427000</gml:lowerCorner>
        		<gml:upperCorner>316573.449000 360938.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316573.449000 360938.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 047 148</ms:GML_ID>
        <ms:NAZWA>276 047 148</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276047148</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315557.831169 360970.247834</gml:lowerCorner>
        		<gml:upperCorner>315557.831169 360970.247834</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315557.831169 360970.247834</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 048 174</ms:GML_ID>
        <ms:NAZWA>276 048 174</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276048174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312093.631687 361010.632669</gml:lowerCorner>
        		<gml:upperCorner>312093.631687 361010.632669</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312093.631687 361010.632669</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 051 764</ms:GML_ID>
        <ms:NAZWA>276 051 764</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276051764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315001.487000 361026.623000</gml:lowerCorner>
        		<gml:upperCorner>315001.487000 361026.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315001.487000 361026.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 048 733</ms:GML_ID>
        <ms:NAZWA>276 048 733</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276048733</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319389.017500 361068.471504</gml:lowerCorner>
        		<gml:upperCorner>319389.017500 361068.471504</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319389.017500 361068.471504</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 044 229</ms:GML_ID>
        <ms:NAZWA>276 044 229</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276044229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4380">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299576.926000 322190.409000</gml:lowerCorner>
        		<gml:upperCorner>299576.926000 322190.409000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4380.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299576.926000 322190.409000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4380</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.286 015 579</ms:GML_ID>
        <ms:NAZWA>286 015 579</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>286015579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4381">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307978.094000 323827.154000</gml:lowerCorner>
        		<gml:upperCorner>307978.094000 323827.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4381.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307978.094000 323827.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4381</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.286 027 178</ms:GML_ID>
        <ms:NAZWA>286 027 178</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>286027178</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300946.889000 326467.711000</gml:lowerCorner>
        		<gml:upperCorner>300946.889000 326467.711000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300946.889000 326467.711000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.327 000 049</ms:GML_ID>
        <ms:NAZWA>327 000 049</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>327000049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5817">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319375.899000 334143.791000</gml:lowerCorner>
        		<gml:upperCorner>319375.899000 334143.791000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5817.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319375.899000 334143.791000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5817</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 207 780</ms:GML_ID>
        <ms:NAZWA>137 207 780</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137207780</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5816">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319123.767000 335100.311000</gml:lowerCorner>
        		<gml:upperCorner>319123.767000 335100.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5816.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319123.767000 335100.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5816</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 206 772</ms:GML_ID>
        <ms:NAZWA>137 206 772</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137206772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5815">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319098.676000 335516.825000</gml:lowerCorner>
        		<gml:upperCorner>319098.676000 335516.825000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5815.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319098.676000 335516.825000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5815</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 206 356</ms:GML_ID>
        <ms:NAZWA>137 206 356</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137206356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5814">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319086.480000 335688.143000</gml:lowerCorner>
        		<gml:upperCorner>319086.480000 335688.143000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5814.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319086.480000 335688.143000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5814</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 206 180</ms:GML_ID>
        <ms:NAZWA>137 206 180</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137206180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5809">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311414.393000 342404.163000</gml:lowerCorner>
        		<gml:upperCorner>311414.393000 342404.163000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5809.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311414.393000 342404.163000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5809</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 193 659</ms:GML_ID>
        <ms:NAZWA>137 193 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137193659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5812">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314499.924819 342675.859382</gml:lowerCorner>
        		<gml:upperCorner>314499.924819 342675.859382</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5812.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314499.924819 342675.859382</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5812</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 196 793</ms:GML_ID>
        <ms:NAZWA>137 196 793</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137196793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5811">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314118.674000 342688.573000</gml:lowerCorner>
        		<gml:upperCorner>314118.674000 342688.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5811.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314118.674000 342688.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5811</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 196 411</ms:GML_ID>
        <ms:NAZWA>137 196 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137196411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5813">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314601.965456 342692.495991</gml:lowerCorner>
        		<gml:upperCorner>314601.965456 342692.495991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5813.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314601.965456 342692.495991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5813</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 196 895</ms:GML_ID>
        <ms:NAZWA>137 196 895</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137196895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5810">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313109.088000 342739.813000</gml:lowerCorner>
        		<gml:upperCorner>313109.088000 342739.813000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5810.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313109.088000 342739.813000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5810</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 195 396</ms:GML_ID>
        <ms:NAZWA>137 195 396</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137195396</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296950.303000 382019.716000</gml:lowerCorner>
        		<gml:upperCorner>296950.303000 382019.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296950.303000 382019.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 006 994</ms:GML_ID>
        <ms:NAZWA>288 006 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288006994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297100.595000 382330.458000</gml:lowerCorner>
        		<gml:upperCorner>297100.595000 382330.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297100.595000 382330.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 007 341</ms:GML_ID>
        <ms:NAZWA>288 007 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288007341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298906.169000 383381.800000</gml:lowerCorner>
        		<gml:upperCorner>298906.169000 383381.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298906.169000 383381.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 009 467</ms:GML_ID>
        <ms:NAZWA>288 009 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288009467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299338.084304 383575.779491</gml:lowerCorner>
        		<gml:upperCorner>299338.084304 383575.779491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299338.084304 383575.779491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 009 940</ms:GML_ID>
        <ms:NAZWA>288 009 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288009940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299616.799000 383700.742000</gml:lowerCorner>
        		<gml:upperCorner>299616.799000 383700.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299616.799000 383700.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 010 245</ms:GML_ID>
        <ms:NAZWA>288 010 245</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288010245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303264.292000 384879.611000</gml:lowerCorner>
        		<gml:upperCorner>303264.292000 384879.611000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303264.292000 384879.611000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 014 132</ms:GML_ID>
        <ms:NAZWA>288 014 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288014132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304204.786145 385022.409200</gml:lowerCorner>
        		<gml:upperCorner>304204.786145 385022.409200</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304204.786145 385022.409200</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 015 087</ms:GML_ID>
        <ms:NAZWA>288 015 087</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288015087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305478.667373 385160.649675</gml:lowerCorner>
        		<gml:upperCorner>305478.667373 385160.649675</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305478.667373 385160.649675</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 016 370</ms:GML_ID>
        <ms:NAZWA>288 016 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288016370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306838.991000 385308.099000</gml:lowerCorner>
        		<gml:upperCorner>306838.991000 385308.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306838.991000 385308.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 017 739</ms:GML_ID>
        <ms:NAZWA>288 017 739</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288017739</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307148.773000 385341.716000</gml:lowerCorner>
        		<gml:upperCorner>307148.773000 385341.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307148.773000 385341.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 018 049</ms:GML_ID>
        <ms:NAZWA>288 018 049</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288018049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307506.550590 385380.318745</gml:lowerCorner>
        		<gml:upperCorner>307506.550590 385380.318745</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307506.550590 385380.318745</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 018 409</ms:GML_ID>
        <ms:NAZWA>288 018 409</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288018409</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308211.049000 385456.812000</gml:lowerCorner>
        		<gml:upperCorner>308211.049000 385456.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308211.049000 385456.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 019 119</ms:GML_ID>
        <ms:NAZWA>288 019 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288019119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308921.641000 385533.911000</gml:lowerCorner>
        		<gml:upperCorner>308921.641000 385533.911000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308921.641000 385533.911000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 019 833</ms:GML_ID>
        <ms:NAZWA>288 019 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288019833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309756.471000 385488.350000</gml:lowerCorner>
        		<gml:upperCorner>309756.471000 385488.350000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309756.471000 385488.350000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 020 673</ms:GML_ID>
        <ms:NAZWA>288 020 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288020673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311003.853000 385249.849000</gml:lowerCorner>
        		<gml:upperCorner>311003.853000 385249.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311003.853000 385249.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 021 944</ms:GML_ID>
        <ms:NAZWA>288 021 944</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288021944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311641.359000 385221.627000</gml:lowerCorner>
        		<gml:upperCorner>311641.359000 385221.627000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311641.359000 385221.627000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 022 584</ms:GML_ID>
        <ms:NAZWA>288 022 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288022584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313114.785000 385330.406000</gml:lowerCorner>
        		<gml:upperCorner>313114.785000 385330.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313114.785000 385330.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 024 062</ms:GML_ID>
        <ms:NAZWA>288 024 062</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288024062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313682.475000 385373.511000</gml:lowerCorner>
        		<gml:upperCorner>313682.475000 385373.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313682.475000 385373.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 024 632</ms:GML_ID>
        <ms:NAZWA>288 024 632</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288024632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313970.278000 385394.354000</gml:lowerCorner>
        		<gml:upperCorner>313970.278000 385394.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313970.278000 385394.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 024 920</ms:GML_ID>
        <ms:NAZWA>288 024 920</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288024920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314729.489000 385449.616000</gml:lowerCorner>
        		<gml:upperCorner>314729.489000 385449.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314729.489000 385449.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 025 682</ms:GML_ID>
        <ms:NAZWA>288 025 682</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288025682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315656.438046 385372.477445</gml:lowerCorner>
        		<gml:upperCorner>315656.438046 385372.477445</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315656.438046 385372.477445</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 026 623</ms:GML_ID>
        <ms:NAZWA>288 026 623</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288026623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316827.019000 385587.353000</gml:lowerCorner>
        		<gml:upperCorner>316827.019000 385587.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316827.019000 385587.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 027 849</ms:GML_ID>
        <ms:NAZWA>288 027 849</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288027849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338640.631000 384805.685000</gml:lowerCorner>
        		<gml:upperCorner>338640.631000 384805.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338640.631000 384805.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 149 033</ms:GML_ID>
        <ms:NAZWA>132 149 033</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132149033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339275.259000 383918.860000</gml:lowerCorner>
        		<gml:upperCorner>339275.259000 383918.860000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339275.259000 383918.860000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 150 125</ms:GML_ID>
        <ms:NAZWA>132 150 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132150125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5694">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340146.625000 382698.811000</gml:lowerCorner>
        		<gml:upperCorner>340146.625000 382698.811000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5694.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340146.625000 382698.811000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5694</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 151 626</ms:GML_ID>
        <ms:NAZWA>132 151 626</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132151626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5695">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342394.764000 379691.995000</gml:lowerCorner>
        		<gml:upperCorner>342394.764000 379691.995000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5695.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342394.764000 379691.995000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5695</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 155 382</ms:GML_ID>
        <ms:NAZWA>132 155 382</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132155382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5696">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342971.316000 378991.052000</gml:lowerCorner>
        		<gml:upperCorner>342971.316000 378991.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5696.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342971.316000 378991.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5696</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 156 290</ms:GML_ID>
        <ms:NAZWA>132 156 290</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132156290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344088.940000 377633.038000</gml:lowerCorner>
        		<gml:upperCorner>344088.940000 377633.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344088.940000 377633.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 158 049</ms:GML_ID>
        <ms:NAZWA>132 158 049</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132158049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290956.672000 371090.089000</gml:lowerCorner>
        		<gml:upperCorner>290956.672000 371090.089000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290956.672000 371090.089000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 153 626</ms:GML_ID>
        <ms:NAZWA>137 153 626</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137153626</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291167.970000 370451.830000</gml:lowerCorner>
        		<gml:upperCorner>291167.970000 370451.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291167.970000 370451.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 154 297</ms:GML_ID>
        <ms:NAZWA>137 154 297</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137154297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291236.188571 369783.344851</gml:lowerCorner>
        		<gml:upperCorner>291236.188571 369783.344851</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291236.188571 369783.344851</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 154 976</ms:GML_ID>
        <ms:NAZWA>137 154 976</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137154976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291323.957000 368555.704000</gml:lowerCorner>
        		<gml:upperCorner>291323.957000 368555.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291323.957000 368555.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 156 198</ms:GML_ID>
        <ms:NAZWA>137 156 198</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137156198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291668.130954 367442.820307</gml:lowerCorner>
        		<gml:upperCorner>291668.130954 367442.820307</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291668.130954 367442.820307</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 157 383</ms:GML_ID>
        <ms:NAZWA>137 157 383</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137157383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291965.233000 366775.708000</gml:lowerCorner>
        		<gml:upperCorner>291965.233000 366775.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291965.233000 366775.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 158 113</ms:GML_ID>
        <ms:NAZWA>137 158 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137158113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292235.083000 361490.996000</gml:lowerCorner>
        		<gml:upperCorner>292235.083000 361490.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292235.083000 361490.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 163 522</ms:GML_ID>
        <ms:NAZWA>137 163 522</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137163522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292350.514000 361922.455000</gml:lowerCorner>
        		<gml:upperCorner>292350.514000 361922.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292350.514000 361922.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 163 076</ms:GML_ID>
        <ms:NAZWA>137 163 076</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137163076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317406.837000 361315.558000</gml:lowerCorner>
        		<gml:upperCorner>317406.837000 361315.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317406.837000 361315.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 046 233</ms:GML_ID>
        <ms:NAZWA>276 046 233</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276046233</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318339.077000 361245.845000</gml:lowerCorner>
        		<gml:upperCorner>318339.077000 361245.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318339.077000 361245.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 045 291</ms:GML_ID>
        <ms:NAZWA>276 045 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276045291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318608.594000 361201.787000</gml:lowerCorner>
        		<gml:upperCorner>318608.594000 361201.787000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318608.594000 361201.787000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 045 015</ms:GML_ID>
        <ms:NAZWA>276 045 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276045015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322436.017000 361425.907000</gml:lowerCorner>
        		<gml:upperCorner>322436.017000 361425.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322436.017000 361425.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 041 098</ms:GML_ID>
        <ms:NAZWA>276 041 098</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276041098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323326.662000 361910.802000</gml:lowerCorner>
        		<gml:upperCorner>323326.662000 361910.802000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323326.662000 361910.802000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 040 083</ms:GML_ID>
        <ms:NAZWA>276 040 083</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276040083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323883.772355 362218.774940</gml:lowerCorner>
        		<gml:upperCorner>323883.772355 362218.774940</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323883.772355 362218.774940</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 039 445</ms:GML_ID>
        <ms:NAZWA>276 039 445</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276039445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324472.346074 362723.007580</gml:lowerCorner>
        		<gml:upperCorner>324472.346074 362723.007580</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324472.346074 362723.007580</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 038 668</ms:GML_ID>
        <ms:NAZWA>276 038 668</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276038668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324722.094935 362949.375576</gml:lowerCorner>
        		<gml:upperCorner>324722.094935 362949.375576</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324722.094935 362949.375576</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 038 334</ms:GML_ID>
        <ms:NAZWA>276 038 334</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276038334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329286.927123 362901.116343</gml:lowerCorner>
        		<gml:upperCorner>329286.927123 362901.116343</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329286.927123 362901.116343</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 033 607</ms:GML_ID>
        <ms:NAZWA>276 033 607</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276033607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330794.158000 362502.396000</gml:lowerCorner>
        		<gml:upperCorner>330794.158000 362502.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330794.158000 362502.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 032 045</ms:GML_ID>
        <ms:NAZWA>276 032 045</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276032045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331717.867000 362260.024000</gml:lowerCorner>
        		<gml:upperCorner>331717.867000 362260.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331717.867000 362260.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 031 096</ms:GML_ID>
        <ms:NAZWA>276 031 096</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276031096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334082.503000 361625.873000</gml:lowerCorner>
        		<gml:upperCorner>334082.503000 361625.873000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334082.503000 361625.873000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 028 640</ms:GML_ID>
        <ms:NAZWA>276 028 640</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276028640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334747.063648 361421.360429</gml:lowerCorner>
        		<gml:upperCorner>334747.063648 361421.360429</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334747.063648 361421.360429</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 027 947</ms:GML_ID>
        <ms:NAZWA>276 027 947</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276027947</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335124.120000 361305.987000</gml:lowerCorner>
        		<gml:upperCorner>335124.120000 361305.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335124.120000 361305.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 027 548</ms:GML_ID>
        <ms:NAZWA>276 027 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276027548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340516.242730 361582.744162</gml:lowerCorner>
        		<gml:upperCorner>340516.242730 361582.744162</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340516.242730 361582.744162</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 022 085</ms:GML_ID>
        <ms:NAZWA>276 022 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276022085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341825.631018 361811.786288</gml:lowerCorner>
        		<gml:upperCorner>341825.631018 361811.786288</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341825.631018 361811.786288</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 020 753</ms:GML_ID>
        <ms:NAZWA>276 020 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276020753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342848.569000 362041.703000</gml:lowerCorner>
        		<gml:upperCorner>342848.569000 362041.703000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342848.569000 362041.703000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 019 709</ms:GML_ID>
        <ms:NAZWA>276 019 709</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276019709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343260.714000 362133.901000</gml:lowerCorner>
        		<gml:upperCorner>343260.714000 362133.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343260.714000 362133.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 019 284</ms:GML_ID>
        <ms:NAZWA>276 019 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276019284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343896.918000 362276.313000</gml:lowerCorner>
        		<gml:upperCorner>343896.918000 362276.313000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343896.918000 362276.313000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 018 631</ms:GML_ID>
        <ms:NAZWA>276 018 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276018631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344888.362418 362496.766023</gml:lowerCorner>
        		<gml:upperCorner>344888.362418 362496.766023</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344888.362418 362496.766023</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 017 615</ms:GML_ID>
        <ms:NAZWA>276 017 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276017615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286157.952691 414203.847234</gml:lowerCorner>
        		<gml:upperCorner>286157.952691 414203.847234</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286157.952691 414203.847234</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 020 256</ms:GML_ID>
        <ms:NAZWA>306 020 256</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306020256</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286213.332000 414333.738000</gml:lowerCorner>
        		<gml:upperCorner>286213.332000 414333.738000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286213.332000 414333.738000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 020 114</ms:GML_ID>
        <ms:NAZWA>306 020 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306020114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286260.683827 414443.311380</gml:lowerCorner>
        		<gml:upperCorner>286260.683827 414443.311380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286260.683827 414443.311380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.306 019 995</ms:GML_ID>
        <ms:NAZWA>306 019 995</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>306019995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4406">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303434.315015 403589.534415</gml:lowerCorner>
        		<gml:upperCorner>303434.315015 403589.534415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4406.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303434.315015 403589.534415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4406</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 020 952</ms:GML_ID>
        <ms:NAZWA>287 020 952</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287020952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4405">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303950.790850 404021.070031</gml:lowerCorner>
        		<gml:upperCorner>303950.790850 404021.070031</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4405.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303950.790850 404021.070031</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4405</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 020 277</ms:GML_ID>
        <ms:NAZWA>287 020 277</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287020277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4404">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304173.058449 404267.598251</gml:lowerCorner>
        		<gml:upperCorner>304173.058449 404267.598251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4404.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304173.058449 404267.598251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4404</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 019 945</ms:GML_ID>
        <ms:NAZWA>287 019 945</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287019945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4403">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304373.841543 404491.980305</gml:lowerCorner>
        		<gml:upperCorner>304373.841543 404491.980305</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4403.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304373.841543 404491.980305</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4403</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 019 644</ms:GML_ID>
        <ms:NAZWA>287 019 644</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287019644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4402">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304801.089000 405198.615000</gml:lowerCorner>
        		<gml:upperCorner>304801.089000 405198.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4402.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304801.089000 405198.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4402</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 018 817</ms:GML_ID>
        <ms:NAZWA>287 018 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287018817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4401">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304873.524000 405515.992000</gml:lowerCorner>
        		<gml:upperCorner>304873.524000 405515.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4401.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304873.524000 405515.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4401</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 018 490</ms:GML_ID>
        <ms:NAZWA>287 018 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287018490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4400">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304958.926000 406312.918000</gml:lowerCorner>
        		<gml:upperCorner>304958.926000 406312.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4400.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304958.926000 406312.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4400</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 017 688</ms:GML_ID>
        <ms:NAZWA>287 017 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287017688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4399">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304982.351034 406525.003354</gml:lowerCorner>
        		<gml:upperCorner>304982.351034 406525.003354</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4399.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304982.351034 406525.003354</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4399</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 017 474</ms:GML_ID>
        <ms:NAZWA>287 017 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287017474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4397">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305051.604000 409390.861000</gml:lowerCorner>
        		<gml:upperCorner>305051.604000 409390.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4397.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305051.604000 409390.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4397</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 014 448</ms:GML_ID>
        <ms:NAZWA>287 014 448</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287014448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4398">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305065.942895 407618.439846</gml:lowerCorner>
        		<gml:upperCorner>305065.942895 407618.439846</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4398.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305065.942895 407618.439846</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4398</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 016 320</ms:GML_ID>
        <ms:NAZWA>287 016 320</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287016320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4396">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305190.556000 409916.676000</gml:lowerCorner>
        		<gml:upperCorner>305190.556000 409916.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4396.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305190.556000 409916.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4396</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 013 902</ms:GML_ID>
        <ms:NAZWA>287 013 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287013902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306060.798000 406803.203000</gml:lowerCorner>
        		<gml:upperCorner>306060.798000 406803.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306060.798000 406803.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 001 962</ms:GML_ID>
        <ms:NAZWA>329 001 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329001962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306363.640000 405950.780000</gml:lowerCorner>
        		<gml:upperCorner>306363.640000 405950.780000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306363.640000 405950.780000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 002 890</ms:GML_ID>
        <ms:NAZWA>329 002 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329002890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307293.604000 405362.340000</gml:lowerCorner>
        		<gml:upperCorner>307293.604000 405362.340000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307293.604000 405362.340000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 004 025</ms:GML_ID>
        <ms:NAZWA>329 004 025</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329004025</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307661.885000 405256.763000</gml:lowerCorner>
        		<gml:upperCorner>307661.885000 405256.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307661.885000 405256.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 004 411</ms:GML_ID>
        <ms:NAZWA>329 004 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329004411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308124.366000 404695.558000</gml:lowerCorner>
        		<gml:upperCorner>308124.366000 404695.558000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308124.366000 404695.558000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 005 160</ms:GML_ID>
        <ms:NAZWA>329 005 160</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329005160</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308463.566000 404378.102000</gml:lowerCorner>
        		<gml:upperCorner>308463.566000 404378.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308463.566000 404378.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 005 625</ms:GML_ID>
        <ms:NAZWA>329 005 625</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329005625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309077.811000 403842.349000</gml:lowerCorner>
        		<gml:upperCorner>309077.811000 403842.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309077.811000 403842.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 006 441</ms:GML_ID>
        <ms:NAZWA>329 006 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329006441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309369.283000 403661.269000</gml:lowerCorner>
        		<gml:upperCorner>309369.283000 403661.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309369.283000 403661.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 006 785</ms:GML_ID>
        <ms:NAZWA>329 006 785</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329006785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310229.475000 403237.379000</gml:lowerCorner>
        		<gml:upperCorner>310229.475000 403237.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310229.475000 403237.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.329 007 767</ms:GML_ID>
        <ms:NAZWA>329 007 767</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>329007767</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4791">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>282737.158000 332507.259000</gml:lowerCorner>
        		<gml:upperCorner>282737.158000 332507.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4791.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>282737.158000 332507.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4791</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 000 902</ms:GML_ID>
        <ms:NAZWA>322 000 902</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322000902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285723.429000 333075.930000</gml:lowerCorner>
        		<gml:upperCorner>285723.429000 333075.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285723.429000 333075.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 097 694</ms:GML_ID>
        <ms:NAZWA>276 097 694</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276097694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285768.342610 333036.338626</gml:lowerCorner>
        		<gml:upperCorner>285768.342610 333036.338626</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285768.342610 333036.338626</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 000 188</ms:GML_ID>
        <ms:NAZWA>309 000 188</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309000188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285867.647238 332350.733055</gml:lowerCorner>
        		<gml:upperCorner>285867.647238 332350.733055</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285867.647238 332350.733055</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 000 922</ms:GML_ID>
        <ms:NAZWA>309 000 922</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309000922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286276.039000 333256.110000</gml:lowerCorner>
        		<gml:upperCorner>286276.039000 333256.110000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286276.039000 333256.110000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 097 110</ms:GML_ID>
        <ms:NAZWA>276 097 110</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276097110</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289382.541686 333758.040227</gml:lowerCorner>
        		<gml:upperCorner>289382.541686 333758.040227</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289382.541686 333758.040227</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.286 000 390</ms:GML_ID>
        <ms:NAZWA>286 000 390</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>286000390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291227.845427 334243.806689</gml:lowerCorner>
        		<gml:upperCorner>291227.845427 334243.806689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291227.845427 334243.806689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 091 896</ms:GML_ID>
        <ms:NAZWA>276 091 896</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276091896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291491.889000 332292.595000</gml:lowerCorner>
        		<gml:upperCorner>291491.889000 332292.595000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291491.889000 332292.595000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.286 002 283</ms:GML_ID>
        <ms:NAZWA>286 002 283</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>286002283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292057.909000 360136.554000</gml:lowerCorner>
        		<gml:upperCorner>292057.909000 360136.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292057.909000 360136.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 164 899</ms:GML_ID>
        <ms:NAZWA>137 164 899</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137164899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292157.542000 358130.496000</gml:lowerCorner>
        		<gml:upperCorner>292157.542000 358130.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292157.542000 358130.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 166 926</ms:GML_ID>
        <ms:NAZWA>137 166 926</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137166926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293337.634000 356361.368000</gml:lowerCorner>
        		<gml:upperCorner>293337.634000 356361.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293337.634000 356361.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 169 056</ms:GML_ID>
        <ms:NAZWA>137 169 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137169056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294251.603000 354995.740000</gml:lowerCorner>
        		<gml:upperCorner>294251.603000 354995.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294251.603000 354995.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 170 700</ms:GML_ID>
        <ms:NAZWA>137 170 700</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137170700</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294664.177000 354484.615000</gml:lowerCorner>
        		<gml:upperCorner>294664.177000 354484.615000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294664.177000 354484.615000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 171 362</ms:GML_ID>
        <ms:NAZWA>137 171 362</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137171362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295468.997254 354137.818554</gml:lowerCorner>
        		<gml:upperCorner>295468.997254 354137.818554</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295468.997254 354137.818554</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 172 242</ms:GML_ID>
        <ms:NAZWA>137 172 242</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137172242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296011.827000 353953.028000</gml:lowerCorner>
        		<gml:upperCorner>296011.827000 353953.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296011.827000 353953.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 172 815</ms:GML_ID>
        <ms:NAZWA>137 172 815</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137172815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296417.174000 353722.473000</gml:lowerCorner>
        		<gml:upperCorner>296417.174000 353722.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296417.174000 353722.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 173 283</ms:GML_ID>
        <ms:NAZWA>137 173 283</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137173283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296820.748687 342373.537003</gml:lowerCorner>
        		<gml:upperCorner>296820.748687 342373.537003</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296820.748687 342373.537003</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 081 037</ms:GML_ID>
        <ms:NAZWA>276 081 037</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276081037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296863.686000 342565.117000</gml:lowerCorner>
        		<gml:upperCorner>296863.686000 342565.117000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296863.686000 342565.117000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 080 842</ms:GML_ID>
        <ms:NAZWA>276 080 842</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276080842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297071.758669 343512.596645</gml:lowerCorner>
        		<gml:upperCorner>297071.758669 343512.596645</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297071.758669 343512.596645</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 079 869</ms:GML_ID>
        <ms:NAZWA>276 079 869</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276079869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298301.174331 347314.790170</gml:lowerCorner>
        		<gml:upperCorner>298301.174331 347314.790170</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298301.174331 347314.790170</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 075 781</ms:GML_ID>
        <ms:NAZWA>276 075 781</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276075781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298805.912330 349222.589315</gml:lowerCorner>
        		<gml:upperCorner>298805.912330 349222.589315</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298805.912330 349222.589315</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 073 755</ms:GML_ID>
        <ms:NAZWA>276 073 755</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276073755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290061.961148 385903.691294</gml:lowerCorner>
        		<gml:upperCorner>290061.961148 385903.691294</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290061.961148 385903.691294</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 044 372</ms:GML_ID>
        <ms:NAZWA>287 044 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287044372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290090.950000 386290.597000</gml:lowerCorner>
        		<gml:upperCorner>290090.950000 386290.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290090.950000 386290.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 043 984</ms:GML_ID>
        <ms:NAZWA>287 043 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287043984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278802.166000 386426.676000</gml:lowerCorner>
        		<gml:upperCorner>278802.166000 386426.676000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278802.166000 386426.676000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 124 452</ms:GML_ID>
        <ms:NAZWA>137 124 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137124452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290359.360647 387838.541393</gml:lowerCorner>
        		<gml:upperCorner>290359.360647 387838.541393</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290359.360647 387838.541393</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 042 408</ms:GML_ID>
        <ms:NAZWA>287 042 408</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287042408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290639.596000 388632.480000</gml:lowerCorner>
        		<gml:upperCorner>290639.596000 388632.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290639.596000 388632.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 041 560</ms:GML_ID>
        <ms:NAZWA>287 041 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287041560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290742.618174 388858.024519</gml:lowerCorner>
        		<gml:upperCorner>290742.618174 388858.024519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290742.618174 388858.024519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 041 311</ms:GML_ID>
        <ms:NAZWA>287 041 311</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287041311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290958.202999 389376.639825</gml:lowerCorner>
        		<gml:upperCorner>290958.202999 389376.639825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290958.202999 389376.639825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 040 749</ms:GML_ID>
        <ms:NAZWA>287 040 749</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287040749</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291277.546126 390536.432789</gml:lowerCorner>
        		<gml:upperCorner>291277.546126 390536.432789</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291277.546126 390536.432789</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 039 541</ms:GML_ID>
        <ms:NAZWA>287 039 541</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287039541</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292430.088000 391941.517000</gml:lowerCorner>
        		<gml:upperCorner>292430.088000 391941.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292430.088000 391941.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 037 714</ms:GML_ID>
        <ms:NAZWA>287 037 714</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287037714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292641.917000 392875.659000</gml:lowerCorner>
        		<gml:upperCorner>292641.917000 392875.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292641.917000 392875.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 036 755</ms:GML_ID>
        <ms:NAZWA>287 036 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287036755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294125.467000 393990.314000</gml:lowerCorner>
        		<gml:upperCorner>294125.467000 393990.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294125.467000 393990.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 034 844</ms:GML_ID>
        <ms:NAZWA>287 034 844</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287034844</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4415">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>295386.888000 395234.716000</gml:lowerCorner>
        		<gml:upperCorner>295386.888000 395234.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4415.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>295386.888000 395234.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4415</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 033 071</ms:GML_ID>
        <ms:NAZWA>287 033 071</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287033071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4414">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296149.917000 396117.381000</gml:lowerCorner>
        		<gml:upperCorner>296149.917000 396117.381000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4414.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296149.917000 396117.381000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4414</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 031 903</ms:GML_ID>
        <ms:NAZWA>287 031 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287031903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4413">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297018.741000 397082.467000</gml:lowerCorner>
        		<gml:upperCorner>297018.741000 397082.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4413.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297018.741000 397082.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4413</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 030 601</ms:GML_ID>
        <ms:NAZWA>287 030 601</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287030601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4412">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297541.011000 397983.828000</gml:lowerCorner>
        		<gml:upperCorner>297541.011000 397983.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4412.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297541.011000 397983.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4412</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 029 554</ms:GML_ID>
        <ms:NAZWA>287 029 554</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287029554</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4411">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>297652.312969 398219.367801</gml:lowerCorner>
        		<gml:upperCorner>297652.312969 398219.367801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4411.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>297652.312969 398219.367801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4411</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 029 290</ms:GML_ID>
        <ms:NAZWA>287 029 290</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287029290</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4410">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299591.279000 401472.747000</gml:lowerCorner>
        		<gml:upperCorner>299591.279000 401472.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4410.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299591.279000 401472.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4410</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 025 352</ms:GML_ID>
        <ms:NAZWA>287 025 352</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287025352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4409">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299974.179391 401665.145464</gml:lowerCorner>
        		<gml:upperCorner>299974.179391 401665.145464</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4409.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299974.179391 401665.145464</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4409</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 024 924</ms:GML_ID>
        <ms:NAZWA>287 024 924</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287024924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4408">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301516.883773 402439.779672</gml:lowerCorner>
        		<gml:upperCorner>301516.883773 402439.779672</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4408.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301516.883773 402439.779672</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4408</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 023 196</ms:GML_ID>
        <ms:NAZWA>287 023 196</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287023196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4407">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302878.103000 403181.978000</gml:lowerCorner>
        		<gml:upperCorner>302878.103000 403181.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4407.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302878.103000 403181.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4407</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 021 642</ms:GML_ID>
        <ms:NAZWA>287 021 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287021642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272373.447000 384746.950000</gml:lowerCorner>
        		<gml:upperCorner>272373.447000 384746.950000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272373.447000 384746.950000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 002 984</ms:GML_ID>
        <ms:NAZWA>343 002 984</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343002984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272388.974153 384813.762255</gml:lowerCorner>
        		<gml:upperCorner>272388.974153 384813.762255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272388.974153 384813.762255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 002 914</ms:GML_ID>
        <ms:NAZWA>343 002 914</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343002914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4884">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272430.069481 382803.724379</gml:lowerCorner>
        		<gml:upperCorner>272430.069481 382803.724379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4884.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272430.069481 382803.724379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4884</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 005 637</ms:GML_ID>
        <ms:NAZWA>343 005 637</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343005637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272771.734000 385247.433000</gml:lowerCorner>
        		<gml:upperCorner>272771.734000 385247.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272771.734000 385247.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 002 317</ms:GML_ID>
        <ms:NAZWA>343 002 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343002317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>272848.340000 385325.647000</gml:lowerCorner>
        		<gml:upperCorner>272848.340000 385325.647000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>272848.340000 385325.647000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 002 211</ms:GML_ID>
        <ms:NAZWA>343 002 211</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343002211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273089.062000 385412.742000</gml:lowerCorner>
        		<gml:upperCorner>273089.062000 385412.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273089.062000 385412.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 001 943</ms:GML_ID>
        <ms:NAZWA>343 001 943</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343001943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273236.244714 385410.868151</gml:lowerCorner>
        		<gml:upperCorner>273236.244714 385410.868151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273236.244714 385410.868151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.343 001 795</ms:GML_ID>
        <ms:NAZWA>343 001 795</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>343001795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273453.046000 385421.839000</gml:lowerCorner>
        		<gml:upperCorner>273453.046000 385421.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273453.046000 385421.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 007 527</ms:GML_ID>
        <ms:NAZWA>297 007 527</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297007527</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>274037.170318 385631.544631</gml:lowerCorner>
        		<gml:upperCorner>274037.170318 385631.544631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>274037.170318 385631.544631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 006 845</ms:GML_ID>
        <ms:NAZWA>297 006 845</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297006845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>276905.446945 385803.249867</gml:lowerCorner>
        		<gml:upperCorner>276905.446945 385803.249867</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>276905.446945 385803.249867</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 003 946</ms:GML_ID>
        <ms:NAZWA>297 003 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297003946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>277428.413000 385711.570000</gml:lowerCorner>
        		<gml:upperCorner>277428.413000 385711.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>277428.413000 385711.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 003 415</ms:GML_ID>
        <ms:NAZWA>297 003 415</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297003415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278176.571000 385582.483000</gml:lowerCorner>
        		<gml:upperCorner>278176.571000 385582.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278176.571000 385582.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 002 655</ms:GML_ID>
        <ms:NAZWA>297 002 655</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297002655</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279738.747582 384628.066352</gml:lowerCorner>
        		<gml:upperCorner>279738.747582 384628.066352</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279738.747582 384628.066352</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.297 000 747</ms:GML_ID>
        <ms:NAZWA>297 000 747</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>297000747</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279768.036000 384654.042000</gml:lowerCorner>
        		<gml:upperCorner>279768.036000 384654.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279768.036000 384654.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 126 481</ms:GML_ID>
        <ms:NAZWA>137 126 481</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137126481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284427.987576 382167.569714</gml:lowerCorner>
        		<gml:upperCorner>284427.987576 382167.569714</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284427.987576 382167.569714</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 131 987</ms:GML_ID>
        <ms:NAZWA>137 131 987</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137131987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286244.254000 382467.142000</gml:lowerCorner>
        		<gml:upperCorner>286244.254000 382467.142000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286244.254000 382467.142000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 133 869</ms:GML_ID>
        <ms:NAZWA>137 133 869</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137133869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289002.726000 382638.396000</gml:lowerCorner>
        		<gml:upperCorner>289002.726000 382638.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289002.726000 382638.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 136 642</ms:GML_ID>
        <ms:NAZWA>137 136 642</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137136642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289665.343685 382651.263847</gml:lowerCorner>
        		<gml:upperCorner>289665.343685 382651.263847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289665.343685 382651.263847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 137 341</ms:GML_ID>
        <ms:NAZWA>137 137 341</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137137341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290056.090000 383478.372000</gml:lowerCorner>
        		<gml:upperCorner>290056.090000 383478.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290056.090000 383478.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 046 811</ms:GML_ID>
        <ms:NAZWA>287 046 811</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287046811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290171.995000 382979.207000</gml:lowerCorner>
        		<gml:upperCorner>290171.995000 382979.207000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290171.995000 382979.207000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 047 324</ms:GML_ID>
        <ms:NAZWA>287 047 324</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287047324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291725.071000 382285.004000</gml:lowerCorner>
        		<gml:upperCorner>291725.071000 382285.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291725.071000 382285.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 139 420</ms:GML_ID>
        <ms:NAZWA>137 139 420</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137139420</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291772.919384 376587.169848</gml:lowerCorner>
        		<gml:upperCorner>291772.919384 376587.169848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291772.919384 376587.169848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 147 681</ms:GML_ID>
        <ms:NAZWA>137 147 681</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137147681</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>292137.567000 382240.239000</gml:lowerCorner>
        		<gml:upperCorner>292137.567000 382240.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>292137.567000 382240.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 139 841</ms:GML_ID>
        <ms:NAZWA>137 139 841</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137139841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>293681.635000 378641.311000</gml:lowerCorner>
        		<gml:upperCorner>293681.635000 378641.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>293681.635000 378641.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 144 876</ms:GML_ID>
        <ms:NAZWA>137 144 876</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137144876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294061.108000 379495.876000</gml:lowerCorner>
        		<gml:upperCorner>294061.108000 379495.876000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294061.108000 379495.876000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 143 924</ms:GML_ID>
        <ms:NAZWA>137 143 924</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137143924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>294194.793000 380050.602000</gml:lowerCorner>
        		<gml:upperCorner>294194.793000 380050.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>294194.793000 380050.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 143 353</ms:GML_ID>
        <ms:NAZWA>137 143 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137143353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296415.267425 381003.487061</gml:lowerCorner>
        		<gml:upperCorner>296415.267425 381003.487061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296415.267425 381003.487061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 005 842</ms:GML_ID>
        <ms:NAZWA>288 005 842</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288005842</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296753.828000 381602.216000</gml:lowerCorner>
        		<gml:upperCorner>296753.828000 381602.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296753.828000 381602.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 006 534</ms:GML_ID>
        <ms:NAZWA>288 006 534</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288006534</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>296860.660000 381828.992000</gml:lowerCorner>
        		<gml:upperCorner>296860.660000 381828.992000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>296860.660000 381828.992000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.288 006 784</ms:GML_ID>
        <ms:NAZWA>288 006 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>288006784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>255223.658385 332469.224129</gml:lowerCorner>
        		<gml:upperCorner>255223.658385 332469.224129</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>255223.658385 332469.224129</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 130 289</ms:GML_ID>
        <ms:NAZWA>276 130 289</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276130289</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>262978.789000 332832.296000</gml:lowerCorner>
        		<gml:upperCorner>262978.789000 332832.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>262978.789000 332832.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 122 010</ms:GML_ID>
        <ms:NAZWA>276 122 010</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276122010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263128.313288 332801.011613</gml:lowerCorner>
        		<gml:upperCorner>263128.313288 332801.011613</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263128.313288 332801.011613</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 121 859</ms:GML_ID>
        <ms:NAZWA>276 121 859</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276121859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>263972.273023 332584.797240</gml:lowerCorner>
        		<gml:upperCorner>263972.273023 332584.797240</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>263972.273023 332584.797240</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 120 987</ms:GML_ID>
        <ms:NAZWA>276 120 987</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276120987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>273737.551140 333049.594559</gml:lowerCorner>
        		<gml:upperCorner>273737.551140 333049.594559</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>273737.551140 333049.594559</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 110 140</ms:GML_ID>
        <ms:NAZWA>276 110 140</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276110140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4805">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278208.735000 339020.016000</gml:lowerCorner>
        		<gml:upperCorner>278208.735000 339020.016000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4805.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278208.735000 339020.016000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4805</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 009 201</ms:GML_ID>
        <ms:NAZWA>322 009 201</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322009201</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4804">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278394.331000 338776.701000</gml:lowerCorner>
        		<gml:upperCorner>278394.331000 338776.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4804.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278394.331000 338776.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4804</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 008 895</ms:GML_ID>
        <ms:NAZWA>322 008 895</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322008895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4803">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278929.233000 338013.485000</gml:lowerCorner>
        		<gml:upperCorner>278929.233000 338013.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4803.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278929.233000 338013.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4803</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 007 912</ms:GML_ID>
        <ms:NAZWA>322 007 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322007912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4802">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279172.514000 337677.693000</gml:lowerCorner>
        		<gml:upperCorner>279172.514000 337677.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4802.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279172.514000 337677.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4802</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 007 489</ms:GML_ID>
        <ms:NAZWA>322 007 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322007489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4801">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279353.316000 337442.233000</gml:lowerCorner>
        		<gml:upperCorner>279353.316000 337442.233000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4801.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279353.316000 337442.233000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4801</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 007 199</ms:GML_ID>
        <ms:NAZWA>322 007 199</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322007199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279354.668400 332313.641686</gml:lowerCorner>
        		<gml:upperCorner>279354.668400 332313.641686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279354.668400 332313.641686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 104 403</ms:GML_ID>
        <ms:NAZWA>276 104 403</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276104403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4800">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279357.839000 336746.505000</gml:lowerCorner>
        		<gml:upperCorner>279357.839000 336746.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4800.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279357.839000 336746.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4800</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 006 490</ms:GML_ID>
        <ms:NAZWA>322 006 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322006490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4799">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279466.833000 336515.510000</gml:lowerCorner>
        		<gml:upperCorner>279466.833000 336515.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4799.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279466.833000 336515.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4799</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 006 234</ms:GML_ID>
        <ms:NAZWA>322 006 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322006234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4798">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279545.090000 336357.983000</gml:lowerCorner>
        		<gml:upperCorner>279545.090000 336357.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4798.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279545.090000 336357.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4798</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 006 058</ms:GML_ID>
        <ms:NAZWA>322 006 058</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322006058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4797">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279720.765000 336007.903000</gml:lowerCorner>
        		<gml:upperCorner>279720.765000 336007.903000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4797.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279720.765000 336007.903000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4797</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 005 666</ms:GML_ID>
        <ms:NAZWA>322 005 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322005666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4796">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>279915.168000 335565.020000</gml:lowerCorner>
        		<gml:upperCorner>279915.168000 335565.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4796.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>279915.168000 335565.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4796</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 005 181</ms:GML_ID>
        <ms:NAZWA>322 005 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322005181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4795">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280446.107000 334576.221000</gml:lowerCorner>
        		<gml:upperCorner>280446.107000 334576.221000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4795.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280446.107000 334576.221000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4795</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 004 043</ms:GML_ID>
        <ms:NAZWA>322 004 043</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322004043</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4794">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280623.842000 334393.893000</gml:lowerCorner>
        		<gml:upperCorner>280623.842000 334393.893000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4794.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280623.842000 334393.893000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4794</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 003 789</ms:GML_ID>
        <ms:NAZWA>322 003 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322003789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4793">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>280927.304000 334087.226000</gml:lowerCorner>
        		<gml:upperCorner>280927.304000 334087.226000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4793.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>280927.304000 334087.226000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4793</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 003 357</ms:GML_ID>
        <ms:NAZWA>322 003 357</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322003357</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4792">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>281848.632000 333259.630000</gml:lowerCorner>
        		<gml:upperCorner>281848.632000 333259.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4792.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>281848.632000 333259.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4792</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 002 117</ms:GML_ID>
        <ms:NAZWA>322 002 117</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322002117</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358663.740776 321035.530800</gml:lowerCorner>
        		<gml:upperCorner>358663.740776 321035.530800</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358663.740776 321035.530800</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 021 080</ms:GML_ID>
        <ms:NAZWA>302 021 080</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302021080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4646">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359910.752000 321842.193000</gml:lowerCorner>
        		<gml:upperCorner>359910.752000 321842.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4646.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359910.752000 321842.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4646</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 019 525</ms:GML_ID>
        <ms:NAZWA>302 019 525</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302019525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4645">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360064.032000 322084.003000</gml:lowerCorner>
        		<gml:upperCorner>360064.032000 322084.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4645.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360064.032000 322084.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4645</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 019 242</ms:GML_ID>
        <ms:NAZWA>302 019 242</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302019242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4644">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360290.740000 323488.758000</gml:lowerCorner>
        		<gml:upperCorner>360290.740000 323488.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4644.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360290.740000 323488.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4644</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 017 810</ms:GML_ID>
        <ms:NAZWA>302 017 810</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302017810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4643">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360476.236913 324576.626144</gml:lowerCorner>
        		<gml:upperCorner>360476.236913 324576.626144</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4643.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360476.236913 324576.626144</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4643</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 016 691</ms:GML_ID>
        <ms:NAZWA>302 016 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302016691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360717.454000 324789.062000</gml:lowerCorner>
        		<gml:upperCorner>360717.454000 324789.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360717.454000 324789.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 016 366</ms:GML_ID>
        <ms:NAZWA>302 016 366</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302016366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361339.874000 325123.612000</gml:lowerCorner>
        		<gml:upperCorner>361339.874000 325123.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361339.874000 325123.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 015 658</ms:GML_ID>
        <ms:NAZWA>302 015 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302015658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361635.207000 325376.378000</gml:lowerCorner>
        		<gml:upperCorner>361635.207000 325376.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361635.207000 325376.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 015 267</ms:GML_ID>
        <ms:NAZWA>302 015 267</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302015267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361795.647000 325568.964000</gml:lowerCorner>
        		<gml:upperCorner>361795.647000 325568.964000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361795.647000 325568.964000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 015 015</ms:GML_ID>
        <ms:NAZWA>302 015 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302015015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362675.418000 325979.210000</gml:lowerCorner>
        		<gml:upperCorner>362675.418000 325979.210000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362675.418000 325979.210000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 014 000</ms:GML_ID>
        <ms:NAZWA>302 014 000</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302014000</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363291.825000 326084.668000</gml:lowerCorner>
        		<gml:upperCorner>363291.825000 326084.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363291.825000 326084.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 013 337</ms:GML_ID>
        <ms:NAZWA>302 013 337</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302013337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364534.467000 326296.435000</gml:lowerCorner>
        		<gml:upperCorner>364534.467000 326296.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364534.467000 326296.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 012 116</ms:GML_ID>
        <ms:NAZWA>302 012 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302012116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365191.703000 326514.097000</gml:lowerCorner>
        		<gml:upperCorner>365191.703000 326514.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365191.703000 326514.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 011 421</ms:GML_ID>
        <ms:NAZWA>302 011 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302011421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366072.724000 326883.029000</gml:lowerCorner>
        		<gml:upperCorner>366072.724000 326883.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366072.724000 326883.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 010 467</ms:GML_ID>
        <ms:NAZWA>302 010 467</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302010467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366876.444000 327198.159000</gml:lowerCorner>
        		<gml:upperCorner>366876.444000 327198.159000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366876.444000 327198.159000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 009 602</ms:GML_ID>
        <ms:NAZWA>302 009 602</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302009602</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368654.210000 326956.739000</gml:lowerCorner>
        		<gml:upperCorner>368654.210000 326956.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368654.210000 326956.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 007 800</ms:GML_ID>
        <ms:NAZWA>302 007 800</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302007800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369238.729000 326907.256000</gml:lowerCorner>
        		<gml:upperCorner>369238.729000 326907.256000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369238.729000 326907.256000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 007 209</ms:GML_ID>
        <ms:NAZWA>302 007 209</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302007209</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369655.864800 326983.829841</gml:lowerCorner>
        		<gml:upperCorner>369655.864800 326983.829841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369655.864800 326983.829841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 006 784</ms:GML_ID>
        <ms:NAZWA>302 006 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302006784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370443.353000 327128.543000</gml:lowerCorner>
        		<gml:upperCorner>370443.353000 327128.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370443.353000 327128.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 005 982</ms:GML_ID>
        <ms:NAZWA>302 005 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302005982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332291.671704 323649.437817</gml:lowerCorner>
        		<gml:upperCorner>332291.671704 323649.437817</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332291.671704 323649.437817</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 058 813</ms:GML_ID>
        <ms:NAZWA>285 058 813</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285058813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332577.822000 323995.419000</gml:lowerCorner>
        		<gml:upperCorner>332577.822000 323995.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332577.822000 323995.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 058 354</ms:GML_ID>
        <ms:NAZWA>285 058 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285058354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332695.408000 324202.815000</gml:lowerCorner>
        		<gml:upperCorner>332695.408000 324202.815000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332695.408000 324202.815000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 058 116</ms:GML_ID>
        <ms:NAZWA>285 058 116</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285058116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333198.547801 325176.698405</gml:lowerCorner>
        		<gml:upperCorner>333198.547801 325176.698405</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333198.547801 325176.698405</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 057 038</ms:GML_ID>
        <ms:NAZWA>285 057 038</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285057038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333227.868585 325120.925258</gml:lowerCorner>
        		<gml:upperCorner>333227.868585 325120.925258</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333227.868585 325120.925258</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 057 056</ms:GML_ID>
        <ms:NAZWA>285 057 056</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285057056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333279.694054 322730.078209</gml:lowerCorner>
        		<gml:upperCorner>333279.694054 322730.078209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333279.694054 322730.078209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 226 587</ms:GML_ID>
        <ms:NAZWA>137 226 587</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137226587</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333954.865231 322797.050143</gml:lowerCorner>
        		<gml:upperCorner>333954.865231 322797.050143</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333954.865231 322797.050143</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 227 275</ms:GML_ID>
        <ms:NAZWA>137 227 275</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137227275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334915.136000 326190.933000</gml:lowerCorner>
        		<gml:upperCorner>334915.136000 326190.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334915.136000 326190.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 055 030</ms:GML_ID>
        <ms:NAZWA>285 055 030</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285055030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335496.057755 322673.790771</gml:lowerCorner>
        		<gml:upperCorner>335496.057755 322673.790771</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335496.057755 322673.790771</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 228 816</ms:GML_ID>
        <ms:NAZWA>137 228 816</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137228816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335667.319834 326609.668022</gml:lowerCorner>
        		<gml:upperCorner>335667.319834 326609.668022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335667.319834 326609.668022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 054 153</ms:GML_ID>
        <ms:NAZWA>285 054 153</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285054153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338245.447640 321873.341601</gml:lowerCorner>
        		<gml:upperCorner>338245.447640 321873.341601</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338245.447640 321873.341601</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 231 685</ms:GML_ID>
        <ms:NAZWA>137 231 685</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137231685</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339882.556609 317547.272267</gml:lowerCorner>
        		<gml:upperCorner>339882.556609 317547.272267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339882.556609 317547.272267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 050 578</ms:GML_ID>
        <ms:NAZWA>274 050 578</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274050578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341134.011000 317681.804000</gml:lowerCorner>
        		<gml:upperCorner>341134.011000 317681.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341134.011000 317681.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 238 634</ms:GML_ID>
        <ms:NAZWA>137 238 634</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137238634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341375.496167 320882.477216</gml:lowerCorner>
        		<gml:upperCorner>341375.496167 320882.477216</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341375.496167 320882.477216</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 234 966</ms:GML_ID>
        <ms:NAZWA>137 234 966</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137234966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343420.523000 321784.056000</gml:lowerCorner>
        		<gml:upperCorner>343420.523000 321784.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343420.523000 321784.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 045 039</ms:GML_ID>
        <ms:NAZWA>274 045 039</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274045039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343661.844000 322099.311000</gml:lowerCorner>
        		<gml:upperCorner>343661.844000 322099.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343661.844000 322099.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 044 640</ms:GML_ID>
        <ms:NAZWA>274 044 640</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274044640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.146">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344331.595892 323600.937278</gml:lowerCorner>
        		<gml:upperCorner>344331.595892 323600.937278</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.146.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344331.595892 323600.937278</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>146</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 042 974</ms:GML_ID>
        <ms:NAZWA>274 042 974</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274042974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.145">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344440.116000 324064.645000</gml:lowerCorner>
        		<gml:upperCorner>344440.116000 324064.645000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.145.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344440.116000 324064.645000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>145</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 042 495</ms:GML_ID>
        <ms:NAZWA>274 042 495</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274042495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.144">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344526.725839 324441.401143</gml:lowerCorner>
        		<gml:upperCorner>344526.725839 324441.401143</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.144.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344526.725839 324441.401143</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>144</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 042 115</ms:GML_ID>
        <ms:NAZWA>274 042 115</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274042115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.142">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346815.493022 329756.745217</gml:lowerCorner>
        		<gml:upperCorner>346815.493022 329756.745217</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.142.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346815.493022 329756.745217</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>142</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 036 182</ms:GML_ID>
        <ms:NAZWA>274 036 182</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274036182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.140">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346955.138036 330683.610979</gml:lowerCorner>
        		<gml:upperCorner>346955.138036 330683.610979</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.140.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346955.138036 330683.610979</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>140</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 035 244</ms:GML_ID>
        <ms:NAZWA>274 035 244</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274035244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321885.025317 317064.605778</gml:lowerCorner>
        		<gml:upperCorner>321885.025317 317064.605778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321885.025317 317064.605778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 073 518</ms:GML_ID>
        <ms:NAZWA>266 073 518</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266073518</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322263.062614 317242.603303</gml:lowerCorner>
        		<gml:upperCorner>322263.062614 317242.603303</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322263.062614 317242.603303</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 073 094</ms:GML_ID>
        <ms:NAZWA>266 073 094</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266073094</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322638.937428 317116.770145</gml:lowerCorner>
        		<gml:upperCorner>322638.937428 317116.770145</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322638.937428 317116.770145</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 072 688</ms:GML_ID>
        <ms:NAZWA>266 072 688</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266072688</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323862.771728 316872.700964</gml:lowerCorner>
        		<gml:upperCorner>323862.771728 316872.700964</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323862.771728 316872.700964</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 071 394</ms:GML_ID>
        <ms:NAZWA>266 071 394</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266071394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324201.089226 317009.409079</gml:lowerCorner>
        		<gml:upperCorner>324201.089226 317009.409079</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324201.089226 317009.409079</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 071 028</ms:GML_ID>
        <ms:NAZWA>266 071 028</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266071028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324264.572442 317937.542970</gml:lowerCorner>
        		<gml:upperCorner>324264.572442 317937.542970</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324264.572442 317937.542970</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 070 048</ms:GML_ID>
        <ms:NAZWA>266 070 048</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266070048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326209.456402 319238.822686</gml:lowerCorner>
        		<gml:upperCorner>326209.456402 319238.822686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326209.456402 319238.822686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 067 297</ms:GML_ID>
        <ms:NAZWA>266 067 297</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266067297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326729.127831 320287.606946</gml:lowerCorner>
        		<gml:upperCorner>326729.127831 320287.606946</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326729.127831 320287.606946</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 066 062</ms:GML_ID>
        <ms:NAZWA>266 066 062</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266066062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326792.090100 320407.298251</gml:lowerCorner>
        		<gml:upperCorner>326792.090100 320407.298251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326792.090100 320407.298251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 065 923</ms:GML_ID>
        <ms:NAZWA>266 065 923</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266065923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326853.318157 320546.562900</gml:lowerCorner>
        		<gml:upperCorner>326853.318157 320546.562900</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326853.318157 320546.562900</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 065 769</ms:GML_ID>
        <ms:NAZWA>266 065 769</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266065769</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327323.820570 321606.925194</gml:lowerCorner>
        		<gml:upperCorner>327323.820570 321606.925194</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327323.820570 321606.925194</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 064 556</ms:GML_ID>
        <ms:NAZWA>266 064 556</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266064556</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327418.882000 327361.491000</gml:lowerCorner>
        		<gml:upperCorner>327418.882000 327361.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327418.882000 327361.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 218 369</ms:GML_ID>
        <ms:NAZWA>137 218 369</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137218369</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328282.126766 321996.895858</gml:lowerCorner>
        		<gml:upperCorner>328282.126766 321996.895858</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328282.126766 321996.895858</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 063 493</ms:GML_ID>
        <ms:NAZWA>266 063 493</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266063493</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329632.646502 322775.009606</gml:lowerCorner>
        		<gml:upperCorner>329632.646502 322775.009606</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329632.646502 322775.009606</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 061 891</ms:GML_ID>
        <ms:NAZWA>266 061 891</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266061891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331313.645000 323112.772000</gml:lowerCorner>
        		<gml:upperCorner>331313.645000 323112.772000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331313.645000 323112.772000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 224 558</ms:GML_ID>
        <ms:NAZWA>137 224 558</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137224558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331476.297662 323246.442080</gml:lowerCorner>
        		<gml:upperCorner>331476.297662 323246.442080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331476.297662 323246.442080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.285 059 725</ms:GML_ID>
        <ms:NAZWA>285 059 725</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>285059725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>265915.366000 331755.460000</gml:lowerCorner>
        		<gml:upperCorner>265915.366000 331755.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>265915.366000 331755.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 118 703</ms:GML_ID>
        <ms:NAZWA>276 118 703</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276118703</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>267719.890000 331915.090000</gml:lowerCorner>
        		<gml:upperCorner>267719.890000 331915.090000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>267719.890000 331915.090000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 116 601</ms:GML_ID>
        <ms:NAZWA>276 116 601</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276116601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>278874.865260 332235.938031</gml:lowerCorner>
        		<gml:upperCorner>278874.865260 332235.938031</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>278874.865260 332235.938031</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.276 104 892</ms:GML_ID>
        <ms:NAZWA>276 104 892</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>276104892</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4790">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>283125.057000 332132.202000</gml:lowerCorner>
        		<gml:upperCorner>283125.057000 332132.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4790.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>283125.057000 332132.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4790</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.322 000 361</ms:GML_ID>
        <ms:NAZWA>322 000 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>322000361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284177.026000 322994.328000</gml:lowerCorner>
        		<gml:upperCorner>284177.026000 322994.328000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284177.026000 322994.328000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 010 699</ms:GML_ID>
        <ms:NAZWA>309 010 699</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309010699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284206.950000 323811.973000</gml:lowerCorner>
        		<gml:upperCorner>284206.950000 323811.973000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284206.950000 323811.973000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 009 858</ms:GML_ID>
        <ms:NAZWA>309 009 858</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309009858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4745">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284286.637000 325119.832000</gml:lowerCorner>
        		<gml:upperCorner>284286.637000 325119.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4745.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284286.637000 325119.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4745</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 008 488</ms:GML_ID>
        <ms:NAZWA>309 008 488</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309008488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4744">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284432.145000 325813.010000</gml:lowerCorner>
        		<gml:upperCorner>284432.145000 325813.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4744.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284432.145000 325813.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4744</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 007 766</ms:GML_ID>
        <ms:NAZWA>309 007 766</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309007766</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284541.577000 326114.455000</gml:lowerCorner>
        		<gml:upperCorner>284541.577000 326114.455000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284541.577000 326114.455000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 007 445</ms:GML_ID>
        <ms:NAZWA>309 007 445</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309007445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4742">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284633.040799 326565.870587</gml:lowerCorner>
        		<gml:upperCorner>284633.040799 326565.870587</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4742.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284633.040799 326565.870587</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4742</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 006 994</ms:GML_ID>
        <ms:NAZWA>309 006 994</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309006994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4741">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284637.478000 326642.784000</gml:lowerCorner>
        		<gml:upperCorner>284637.478000 326642.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4741.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284637.478000 326642.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4741</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 006 916</ms:GML_ID>
        <ms:NAZWA>309 006 916</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309006916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4740">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284719.502000 327127.636000</gml:lowerCorner>
        		<gml:upperCorner>284719.502000 327127.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4740.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284719.502000 327127.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4740</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 006 423</ms:GML_ID>
        <ms:NAZWA>309 006 423</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309006423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284735.577000 319436.839000</gml:lowerCorner>
        		<gml:upperCorner>284735.577000 319436.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284735.577000 319436.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 015 020</ms:GML_ID>
        <ms:NAZWA>309 015 020</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309015020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284760.118000 327530.099000</gml:lowerCorner>
        		<gml:upperCorner>284760.118000 327530.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284760.118000 327530.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 006 023</ms:GML_ID>
        <ms:NAZWA>309 006 023</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309006023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284804.996000 327791.795000</gml:lowerCorner>
        		<gml:upperCorner>284804.996000 327791.795000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284804.996000 327791.795000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 005 752</ms:GML_ID>
        <ms:NAZWA>309 005 752</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309005752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284814.904000 320303.076000</gml:lowerCorner>
        		<gml:upperCorner>284814.904000 320303.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284814.904000 320303.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 014 129</ms:GML_ID>
        <ms:NAZWA>309 014 129</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309014129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284823.562000 319786.912000</gml:lowerCorner>
        		<gml:upperCorner>284823.562000 319786.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284823.562000 319786.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 014 653</ms:GML_ID>
        <ms:NAZWA>309 014 653</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309014653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284850.078491 321248.193554</gml:lowerCorner>
        		<gml:upperCorner>284850.078491 321248.193554</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284850.078491 321248.193554</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 013 100</ms:GML_ID>
        <ms:NAZWA>309 013 100</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309013100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284902.773000 328159.228000</gml:lowerCorner>
        		<gml:upperCorner>284902.773000 328159.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284902.773000 328159.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 005 373</ms:GML_ID>
        <ms:NAZWA>309 005 373</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309005373</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>284989.965000 319221.139000</gml:lowerCorner>
        		<gml:upperCorner>284989.965000 319221.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>284989.965000 319221.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 015 365</ms:GML_ID>
        <ms:NAZWA>309 015 365</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309015365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285249.078000 315435.835000</gml:lowerCorner>
        		<gml:upperCorner>285249.078000 315435.835000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285249.078000 315435.835000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 020 936</ms:GML_ID>
        <ms:NAZWA>309 020 936</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309020936</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285493.553107 315762.598791</gml:lowerCorner>
        		<gml:upperCorner>285493.553107 315762.598791</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285493.553107 315762.598791</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 020 496</ms:GML_ID>
        <ms:NAZWA>309 020 496</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309020496</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285559.017724 318780.807061</gml:lowerCorner>
        		<gml:upperCorner>285559.017724 318780.807061</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285559.017724 318780.807061</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 016 091</ms:GML_ID>
        <ms:NAZWA>309 016 091</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309016091</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285567.700000 329578.666000</gml:lowerCorner>
        		<gml:upperCorner>285567.700000 329578.666000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285567.700000 329578.666000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 003 796</ms:GML_ID>
        <ms:NAZWA>309 003 796</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309003796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285786.358000 330207.979000</gml:lowerCorner>
        		<gml:upperCorner>285786.358000 330207.979000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285786.358000 330207.979000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 003 128</ms:GML_ID>
        <ms:NAZWA>309 003 128</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309003128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285803.102000 314092.209000</gml:lowerCorner>
        		<gml:upperCorner>285803.102000 314092.209000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285803.102000 314092.209000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 022 408</ms:GML_ID>
        <ms:NAZWA>309 022 408</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309022408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285893.406198 316299.436132</gml:lowerCorner>
        		<gml:upperCorner>285893.406198 316299.436132</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285893.406198 316299.436132</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 019 817</ms:GML_ID>
        <ms:NAZWA>309 019 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309019817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>285983.624967 313949.654267</gml:lowerCorner>
        		<gml:upperCorner>285983.624967 313949.654267</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>285983.624967 313949.654267</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 022 642</ms:GML_ID>
        <ms:NAZWA>309 022 642</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309022642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286011.193790 331542.045564</gml:lowerCorner>
        		<gml:upperCorner>286011.193790 331542.045564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286011.193790 331542.045564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 001 760</ms:GML_ID>
        <ms:NAZWA>309 001 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309001760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286536.466794 316406.353264</gml:lowerCorner>
        		<gml:upperCorner>286536.466794 316406.353264</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286536.466794 316406.353264</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 019 149</ms:GML_ID>
        <ms:NAZWA>309 019 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309019149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4379">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298314.259759 323330.334241</gml:lowerCorner>
        		<gml:upperCorner>298314.259759 323330.334241</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4379.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298314.259759 323330.334241</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4379</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.286 013 870</ms:GML_ID>
        <ms:NAZWA>286 013 870</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>286013870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>298666.132000 324062.120000</gml:lowerCorner>
        		<gml:upperCorner>298666.132000 324062.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>298666.132000 324062.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.327 003 482</ms:GML_ID>
        <ms:NAZWA>327 003 482</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>327003482</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336544.730783 312433.062595</gml:lowerCorner>
        		<gml:upperCorner>336544.730783 312433.062595</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336544.730783 312433.062595</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 056 787</ms:GML_ID>
        <ms:NAZWA>274 056 787</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274056787</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336976.439000 313509.238000</gml:lowerCorner>
        		<gml:upperCorner>336976.439000 313509.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336976.439000 313509.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 055 628</ms:GML_ID>
        <ms:NAZWA>274 055 628</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274055628</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337263.162000 314160.867000</gml:lowerCorner>
        		<gml:upperCorner>337263.162000 314160.867000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337263.162000 314160.867000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 054 914</ms:GML_ID>
        <ms:NAZWA>274 054 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274054914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337550.036438 314810.242727</gml:lowerCorner>
        		<gml:upperCorner>337550.036438 314810.242727</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337550.036438 314810.242727</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 054 203</ms:GML_ID>
        <ms:NAZWA>274 054 203</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274054203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337754.325044 315257.759704</gml:lowerCorner>
        		<gml:upperCorner>337754.325044 315257.759704</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337754.325044 315257.759704</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 053 715</ms:GML_ID>
        <ms:NAZWA>274 053 715</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274053715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338228.962962 315852.672434</gml:lowerCorner>
        		<gml:upperCorner>338228.962962 315852.672434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338228.962962 315852.672434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 052 942</ms:GML_ID>
        <ms:NAZWA>274 052 942</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274052942</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343691.583000 315528.524000</gml:lowerCorner>
        		<gml:upperCorner>343691.583000 315528.524000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343691.583000 315528.524000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 242 183</ms:GML_ID>
        <ms:NAZWA>137 242 183</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137242183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346147.127000 314928.571000</gml:lowerCorner>
        		<gml:upperCorner>346147.127000 314928.571000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346147.127000 314928.571000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 244 742</ms:GML_ID>
        <ms:NAZWA>137 244 742</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137244742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346254.300037 312257.953013</gml:lowerCorner>
        		<gml:upperCorner>346254.300037 312257.953013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346254.300037 312257.953013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 040 158</ms:GML_ID>
        <ms:NAZWA>302 040 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302040158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346430.005000 312673.758000</gml:lowerCorner>
        		<gml:upperCorner>346430.005000 312673.758000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346430.005000 312673.758000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 039 716</ms:GML_ID>
        <ms:NAZWA>302 039 716</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302039716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346700.380000 313284.573000</gml:lowerCorner>
        		<gml:upperCorner>346700.380000 313284.573000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346700.380000 313284.573000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 039 050</ms:GML_ID>
        <ms:NAZWA>302 039 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302039050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347651.205000 314738.940000</gml:lowerCorner>
        		<gml:upperCorner>347651.205000 314738.940000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347651.205000 314738.940000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 246 258</ms:GML_ID>
        <ms:NAZWA>137 246 258</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137246258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348490.817000 314652.970000</gml:lowerCorner>
        		<gml:upperCorner>348490.817000 314652.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348490.817000 314652.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 247 101</ms:GML_ID>
        <ms:NAZWA>137 247 101</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137247101</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349531.299243 306585.739801</gml:lowerCorner>
        		<gml:upperCorner>349531.299243 306585.739801</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349531.299243 306585.739801</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 251 608</ms:GML_ID>
        <ms:NAZWA>137 251 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137251608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349761.028000 315767.994000</gml:lowerCorner>
        		<gml:upperCorner>349761.028000 315767.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349761.028000 315767.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 034 130</ms:GML_ID>
        <ms:NAZWA>302 034 130</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302034130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349972.515844 306206.926394</gml:lowerCorner>
        		<gml:upperCorner>349972.515844 306206.926394</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349972.515844 306206.926394</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 252 194</ms:GML_ID>
        <ms:NAZWA>137 252 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137252194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350379.574000 316588.635000</gml:lowerCorner>
        		<gml:upperCorner>350379.574000 316588.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350379.574000 316588.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.302 033 093</ms:GML_ID>
        <ms:NAZWA>302 033 093</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>302033093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350412.778216 305829.049078</gml:lowerCorner>
        		<gml:upperCorner>350412.778216 305829.049078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350412.778216 305829.049078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 252 779</ms:GML_ID>
        <ms:NAZWA>137 252 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137252779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350651.182000 314063.683000</gml:lowerCorner>
        		<gml:upperCorner>350651.182000 314063.683000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350651.182000 314063.683000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 249 383</ms:GML_ID>
        <ms:NAZWA>137 249 383</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137249383</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351541.153351 305282.801848</gml:lowerCorner>
        		<gml:upperCorner>351541.153351 305282.801848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351541.153351 305282.801848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 254 062</ms:GML_ID>
        <ms:NAZWA>137 254 062</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137254062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352098.845804 312801.445246</gml:lowerCorner>
        		<gml:upperCorner>352098.845804 312801.445246</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352098.845804 312801.445246</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 251 314</ms:GML_ID>
        <ms:NAZWA>137 251 314</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137251314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352393.645695 312507.247662</gml:lowerCorner>
        		<gml:upperCorner>352393.645695 312507.247662</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352393.645695 312507.247662</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 251 794</ms:GML_ID>
        <ms:NAZWA>137 251 794</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137251794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352567.486631 312333.157853</gml:lowerCorner>
        		<gml:upperCorner>352567.486631 312333.157853</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352567.486631 312333.157853</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 251 974</ms:GML_ID>
        <ms:NAZWA>137 251 974</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137251974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352831.489524 305542.047150</gml:lowerCorner>
        		<gml:upperCorner>352831.489524 305542.047150</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352831.489524 305542.047150</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 255 520</ms:GML_ID>
        <ms:NAZWA>137 255 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137255520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353292.262840 310595.290329</gml:lowerCorner>
        		<gml:upperCorner>353292.262840 310595.290329</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353292.262840 310595.290329</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 253 872</ms:GML_ID>
        <ms:NAZWA>137 253 872</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137253872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353544.474000 309961.792000</gml:lowerCorner>
        		<gml:upperCorner>353544.474000 309961.792000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353544.474000 309961.792000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 254 555</ms:GML_ID>
        <ms:NAZWA>137 254 555</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137254555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354015.304000 309302.457000</gml:lowerCorner>
        		<gml:upperCorner>354015.304000 309302.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354015.304000 309302.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 255 367</ms:GML_ID>
        <ms:NAZWA>137 255 367</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137255367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354274.896948 306314.894453</gml:lowerCorner>
        		<gml:upperCorner>354274.896948 306314.894453</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354274.896948 306314.894453</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 257 185</ms:GML_ID>
        <ms:NAZWA>137 257 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137257185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354580.269688 306353.059141</gml:lowerCorner>
        		<gml:upperCorner>354580.269688 306353.059141</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354580.269688 306353.059141</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 257 502</ms:GML_ID>
        <ms:NAZWA>137 257 502</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137257502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354699.970000 308385.678000</gml:lowerCorner>
        		<gml:upperCorner>354699.970000 308385.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354699.970000 308385.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 256 512</ms:GML_ID>
        <ms:NAZWA>137 256 512</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137256512</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354877.364629 306327.705206</gml:lowerCorner>
        		<gml:upperCorner>354877.364629 306327.705206</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354877.364629 306327.705206</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 257 799</ms:GML_ID>
        <ms:NAZWA>137 257 799</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137257799</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354967.592000 308025.238000</gml:lowerCorner>
        		<gml:upperCorner>354967.592000 308025.238000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354967.592000 308025.238000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 256 961</ms:GML_ID>
        <ms:NAZWA>137 256 961</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137256961</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355133.568304 306306.210192</gml:lowerCorner>
        		<gml:upperCorner>355133.568304 306306.210192</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355133.568304 306306.210192</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 258 055</ms:GML_ID>
        <ms:NAZWA>137 258 055</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137258055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355408.934372 307435.387475</gml:lowerCorner>
        		<gml:upperCorner>355408.934372 307435.387475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355408.934372 307435.387475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 257 699</ms:GML_ID>
        <ms:NAZWA>137 257 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137257699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355480.420038 306275.239606</gml:lowerCorner>
        		<gml:upperCorner>355480.420038 306275.239606</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355480.420038 306275.239606</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 258 407</ms:GML_ID>
        <ms:NAZWA>137 258 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137258407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355899.384094 306239.408893</gml:lowerCorner>
        		<gml:upperCorner>355899.384094 306239.408893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355899.384094 306239.408893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 258 831</ms:GML_ID>
        <ms:NAZWA>137 258 831</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137258831</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356537.611962 305905.168040</gml:lowerCorner>
        		<gml:upperCorner>356537.611962 305905.168040</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356537.611962 305905.168040</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 259 596</ms:GML_ID>
        <ms:NAZWA>137 259 596</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137259596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356701.184086 305684.633895</gml:lowerCorner>
        		<gml:upperCorner>356701.184086 305684.633895</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356701.184086 305684.633895</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 259 887</ms:GML_ID>
        <ms:NAZWA>137 259 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137259887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356889.151134 305431.986302</gml:lowerCorner>
        		<gml:upperCorner>356889.151134 305431.986302</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356889.151134 305431.986302</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 260 190</ms:GML_ID>
        <ms:NAZWA>137 260 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137260190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357101.621189 305146.106507</gml:lowerCorner>
        		<gml:upperCorner>357101.621189 305146.106507</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357101.621189 305146.106507</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 260 546</ms:GML_ID>
        <ms:NAZWA>137 260 546</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137260546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286183.174995 305915.797475</gml:lowerCorner>
        		<gml:upperCorner>286183.174995 305915.797475</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286183.174995 305915.797475</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 037 088</ms:GML_ID>
        <ms:NAZWA>309 037 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309037088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286960.051785 305440.420051</gml:lowerCorner>
        		<gml:upperCorner>286960.051785 305440.420051</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286960.051785 305440.420051</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 038 054</ms:GML_ID>
        <ms:NAZWA>309 038 054</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309038054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>286965.850000 310269.526000</gml:lowerCorner>
        		<gml:upperCorner>286965.850000 310269.526000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>286965.850000 310269.526000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 027 254</ms:GML_ID>
        <ms:NAZWA>309 027 254</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309027254</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287607.046000 304754.487000</gml:lowerCorner>
        		<gml:upperCorner>287607.046000 304754.487000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287607.046000 304754.487000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 039 021</ms:GML_ID>
        <ms:NAZWA>309 039 021</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309039021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288168.486228 304632.177840</gml:lowerCorner>
        		<gml:upperCorner>288168.486228 304632.177840</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288168.486228 304632.177840</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.309 039 628</ms:GML_ID>
        <ms:NAZWA>309 039 628</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>309039628</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311982.813000 303139.045000</gml:lowerCorner>
        		<gml:upperCorner>311982.813000 303139.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311982.813000 303139.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 031 850</ms:GML_ID>
        <ms:NAZWA>291 031 850</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291031850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311999.420000 303130.918000</gml:lowerCorner>
        		<gml:upperCorner>311999.420000 303130.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311999.420000 303130.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 031 838</ms:GML_ID>
        <ms:NAZWA>291 031 838</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291031838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315348.852000 301761.426000</gml:lowerCorner>
        		<gml:upperCorner>315348.852000 301761.426000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315348.852000 301761.426000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 027 812</ms:GML_ID>
        <ms:NAZWA>291 027 812</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291027812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315869.871000 302145.689000</gml:lowerCorner>
        		<gml:upperCorner>315869.871000 302145.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315869.871000 302145.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 027 152</ms:GML_ID>
        <ms:NAZWA>291 027 152</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291027152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320546.891228 314914.981956</gml:lowerCorner>
        		<gml:upperCorner>320546.891228 314914.981956</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320546.891228 314914.981956</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 076 386</ms:GML_ID>
        <ms:NAZWA>266 076 386</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266076386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320788.159771 312157.171285</gml:lowerCorner>
        		<gml:upperCorner>320788.159771 312157.171285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320788.159771 312157.171285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 079 762</ms:GML_ID>
        <ms:NAZWA>266 079 762</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266079762</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320853.796101 315457.087473</gml:lowerCorner>
        		<gml:upperCorner>320853.796101 315457.087473</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320853.796101 315457.087473</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 075 751</ms:GML_ID>
        <ms:NAZWA>266 075 751</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266075751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320936.240055 311715.586891</gml:lowerCorner>
        		<gml:upperCorner>320936.240055 311715.586891</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320936.240055 311715.586891</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 080 261</ms:GML_ID>
        <ms:NAZWA>266 080 261</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266080261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320964.479422 311890.420329</gml:lowerCorner>
        		<gml:upperCorner>320964.479422 311890.420329</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320964.479422 311890.420329</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.266 080 079</ms:GML_ID>
        <ms:NAZWA>266 080 079</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>266080079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321592.193000 303647.634000</gml:lowerCorner>
        		<gml:upperCorner>321592.193000 303647.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321592.193000 303647.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 020 557</ms:GML_ID>
        <ms:NAZWA>291 020 557</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291020557</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322179.480282 303903.739434</gml:lowerCorner>
        		<gml:upperCorner>322179.480282 303903.739434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322179.480282 303903.739434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 019 774</ms:GML_ID>
        <ms:NAZWA>291 019 774</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291019774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322767.594732 304229.463673</gml:lowerCorner>
        		<gml:upperCorner>322767.594732 304229.463673</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322767.594732 304229.463673</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.291 018 962</ms:GML_ID>
        <ms:NAZWA>291 018 962</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>291018962</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323515.964675 303618.722884</gml:lowerCorner>
        		<gml:upperCorner>323515.964675 303618.722884</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323515.964675 303618.722884</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 084 411</ms:GML_ID>
        <ms:NAZWA>274 084 411</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274084411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326089.239150 306605.959606</gml:lowerCorner>
        		<gml:upperCorner>326089.239150 306605.959606</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326089.239150 306605.959606</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 072 616</ms:GML_ID>
        <ms:NAZWA>274 072 616</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274072616</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326686.082647 307616.471087</gml:lowerCorner>
        		<gml:upperCorner>326686.082647 307616.471087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326686.082647 307616.471087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 071 269</ms:GML_ID>
        <ms:NAZWA>274 071 269</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274071269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326966.568000 307847.150000</gml:lowerCorner>
        		<gml:upperCorner>326966.568000 307847.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326966.568000 307847.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 070 905</ms:GML_ID>
        <ms:NAZWA>274 070 905</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274070905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327138.176754 308272.475067</gml:lowerCorner>
        		<gml:upperCorner>327138.176754 308272.475067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327138.176754 308272.475067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 070 500</ms:GML_ID>
        <ms:NAZWA>274 070 500</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274070500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327684.188919 308592.783333</gml:lowerCorner>
        		<gml:upperCorner>327684.188919 308592.783333</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327684.188919 308592.783333</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 069 846</ms:GML_ID>
        <ms:NAZWA>274 069 846</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274069846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328717.531000 297715.722518</gml:lowerCorner>
        		<gml:upperCorner>328717.531000 297715.722518</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328717.531000 297715.722518</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 092 531</ms:GML_ID>
        <ms:NAZWA>274 092 531</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274092531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329215.785167 297609.099855</gml:lowerCorner>
        		<gml:upperCorner>329215.785167 297609.099855</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329215.785167 297609.099855</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 093 040</ms:GML_ID>
        <ms:NAZWA>274 093 040</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274093040</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330009.103000 297441.600000</gml:lowerCorner>
        		<gml:upperCorner>330009.103000 297441.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330009.103000 297441.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 093 851</ms:GML_ID>
        <ms:NAZWA>274 093 851</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274093851</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330764.580790 297283.061209</gml:lowerCorner>
        		<gml:upperCorner>330764.580790 297283.061209</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330764.580790 297283.061209</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 094 624</ms:GML_ID>
        <ms:NAZWA>274 094 624</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274094624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331105.406062 297170.045339</gml:lowerCorner>
        		<gml:upperCorner>331105.406062 297170.045339</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331105.406062 297170.045339</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 094 985</ms:GML_ID>
        <ms:NAZWA>274 094 985</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274094985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332710.686000 311474.913000</gml:lowerCorner>
        		<gml:upperCorner>332710.686000 311474.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332710.686000 311474.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 063 715</ms:GML_ID>
        <ms:NAZWA>274 063 715</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274063715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333029.393415 312918.889717</gml:lowerCorner>
        		<gml:upperCorner>333029.393415 312918.889717</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333029.393415 312918.889717</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 062 163</ms:GML_ID>
        <ms:NAZWA>274 062 163</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274062163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333404.002520 312927.424080</gml:lowerCorner>
        		<gml:upperCorner>333404.002520 312927.424080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333404.002520 312927.424080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 061 754</ms:GML_ID>
        <ms:NAZWA>274 061 754</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274061754</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335938.071875 312858.611612</gml:lowerCorner>
        		<gml:upperCorner>335938.071875 312858.611612</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335938.071875 312858.611612</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 058 048</ms:GML_ID>
        <ms:NAZWA>274 058 048</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274058048</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4306">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372171.632148 295891.227122</gml:lowerCorner>
        		<gml:upperCorner>372171.632148 295891.227122</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4306.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372171.632148 295891.227122</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4306</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 007 595</ms:GML_ID>
        <ms:NAZWA>284 007 595</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284007595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4305">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372798.599000 297250.885000</gml:lowerCorner>
        		<gml:upperCorner>372798.599000 297250.885000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4305.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372798.599000 297250.885000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4305</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 006 093</ms:GML_ID>
        <ms:NAZWA>284 006 093</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284006093</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378339.598725 297445.228093</gml:lowerCorner>
        		<gml:upperCorner>378339.598725 297445.228093</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378339.598725 297445.228093</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 070 778</ms:GML_ID>
        <ms:NAZWA>275 070 778</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275070778</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4304">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373166.042000 297922.367000</gml:lowerCorner>
        		<gml:upperCorner>373166.042000 297922.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4304.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373166.042000 297922.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4304</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 005 330</ms:GML_ID>
        <ms:NAZWA>284 005 330</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284005330</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377504.348000 298646.274000</gml:lowerCorner>
        		<gml:upperCorner>377504.348000 298646.274000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377504.348000 298646.274000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 069 319</ms:GML_ID>
        <ms:NAZWA>275 069 319</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275069319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4303">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374016.331000 299047.011000</gml:lowerCorner>
        		<gml:upperCorner>374016.331000 299047.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4303.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374016.331000 299047.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4303</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 003 907</ms:GML_ID>
        <ms:NAZWA>284 003 907</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284003907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4302">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374750.387000 299897.010000</gml:lowerCorner>
        		<gml:upperCorner>374750.387000 299897.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4302.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374750.387000 299897.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4302</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 002 781</ms:GML_ID>
        <ms:NAZWA>284 002 781</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284002781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376435.321097 300183.654828</gml:lowerCorner>
        		<gml:upperCorner>376435.321097 300183.654828</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376435.321097 300183.654828</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 067 443</ms:GML_ID>
        <ms:NAZWA>275 067 443</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275067443</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4301">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375064.809000 300206.569000</gml:lowerCorner>
        		<gml:upperCorner>375064.809000 300206.569000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4301.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375064.809000 300206.569000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4301</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 002 338</ms:GML_ID>
        <ms:NAZWA>284 002 338</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284002338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4300">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375494.608000 300629.508000</gml:lowerCorner>
        		<gml:upperCorner>375494.608000 300629.508000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4300.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375494.608000 300629.508000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4300</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 001 735</ms:GML_ID>
        <ms:NAZWA>284 001 735</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284001735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377139.499000 301500.198000</gml:lowerCorner>
        		<gml:upperCorner>377139.499000 301500.198000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377139.499000 301500.198000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 003 026</ms:GML_ID>
        <ms:NAZWA>289 003 026</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289003026</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379271.038416 302165.533848</gml:lowerCorner>
        		<gml:upperCorner>379271.038416 302165.533848</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379271.038416 302165.533848</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 005 269</ms:GML_ID>
        <ms:NAZWA>289 005 269</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289005269</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379795.231595 302305.135845</gml:lowerCorner>
        		<gml:upperCorner>379795.231595 302305.135845</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379795.231595 302305.135845</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 005 810</ms:GML_ID>
        <ms:NAZWA>289 005 810</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289005810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376650.383000 302340.564000</gml:lowerCorner>
        		<gml:upperCorner>376650.383000 302340.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376650.383000 302340.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.382 112 218</ms:GML_ID>
        <ms:NAZWA>382 112 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>382112218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376807.416000 302380.665000</gml:lowerCorner>
        		<gml:upperCorner>376807.416000 302380.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376807.416000 302380.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.382 112 068</ms:GML_ID>
        <ms:NAZWA>382 112 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>382112068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375845.779985 302564.678230</gml:lowerCorner>
        		<gml:upperCorner>375845.779985 302564.678230</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375845.779985 302564.678230</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.382 113 092</ms:GML_ID>
        <ms:NAZWA>382 113 092</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>382113092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377359.466000 303037.338000</gml:lowerCorner>
        		<gml:upperCorner>377359.466000 303037.338000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377359.466000 303037.338000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.382 111 096</ms:GML_ID>
        <ms:NAZWA>382 111 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>382111096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370799.992210 303416.683762</gml:lowerCorner>
        		<gml:upperCorner>370799.992210 303416.683762</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370799.992210 303416.683762</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 276 951</ms:GML_ID>
        <ms:NAZWA>137 276 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137276951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370957.999000 303457.305000</gml:lowerCorner>
        		<gml:upperCorner>370957.999000 303457.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370957.999000 303457.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 277 114</ms:GML_ID>
        <ms:NAZWA>137 277 114</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137277114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384897.774004 303570.023917</gml:lowerCorner>
        		<gml:upperCorner>384897.774004 303570.023917</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384897.774004 303570.023917</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 011 072</ms:GML_ID>
        <ms:NAZWA>289 011 072</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289011072</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371377.627328 303571.249043</gml:lowerCorner>
        		<gml:upperCorner>371377.627328 303571.249043</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371377.627328 303571.249043</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 277 550</ms:GML_ID>
        <ms:NAZWA>137 277 550</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137277550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385634.034069 303602.391076</gml:lowerCorner>
        		<gml:upperCorner>385634.034069 303602.391076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385634.034069 303602.391076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 011 810</ms:GML_ID>
        <ms:NAZWA>289 011 810</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289011810</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374139.629000 304280.600000</gml:lowerCorner>
        		<gml:upperCorner>374139.629000 304280.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374139.629000 304280.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 280 400</ms:GML_ID>
        <ms:NAZWA>137 280 400</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137280400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374654.285000 304412.467000</gml:lowerCorner>
        		<gml:upperCorner>374654.285000 304412.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374654.285000 304412.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 280 939</ms:GML_ID>
        <ms:NAZWA>137 280 939</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137280939</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375617.385906 308254.571897</gml:lowerCorner>
        		<gml:upperCorner>375617.385906 308254.571897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375617.385906 308254.571897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 059 090</ms:GML_ID>
        <ms:NAZWA>275 059 090</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275059090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375476.400000 312355.465000</gml:lowerCorner>
        		<gml:upperCorner>375476.400000 312355.465000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375476.400000 312355.465000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 054 986</ms:GML_ID>
        <ms:NAZWA>275 054 986</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275054986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375380.069000 315163.515000</gml:lowerCorner>
        		<gml:upperCorner>375380.069000 315163.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375380.069000 315163.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 052 175</ms:GML_ID>
        <ms:NAZWA>275 052 175</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275052175</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317753.150000 287199.618000</gml:lowerCorner>
        		<gml:upperCorner>317753.150000 287199.618000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317753.150000 287199.618000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 012 585</ms:GML_ID>
        <ms:NAZWA>299 012 585</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299012585</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318433.822000 287748.270000</gml:lowerCorner>
        		<gml:upperCorner>318433.822000 287748.270000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318433.822000 287748.270000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 011 710</ms:GML_ID>
        <ms:NAZWA>299 011 710</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299011710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318646.020000 287922.728000</gml:lowerCorner>
        		<gml:upperCorner>318646.020000 287922.728000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318646.020000 287922.728000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 011 436</ms:GML_ID>
        <ms:NAZWA>299 011 436</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299011436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318952.823000 288175.033000</gml:lowerCorner>
        		<gml:upperCorner>318952.823000 288175.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318952.823000 288175.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 011 038</ms:GML_ID>
        <ms:NAZWA>299 011 038</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299011038</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319228.160600 288324.769432</gml:lowerCorner>
        		<gml:upperCorner>319228.160600 288324.769432</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319228.160600 288324.769432</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 010 723</ms:GML_ID>
        <ms:NAZWA>299 010 723</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299010723</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320704.327000 288513.284000</gml:lowerCorner>
        		<gml:upperCorner>320704.327000 288513.284000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320704.327000 288513.284000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 009 199</ms:GML_ID>
        <ms:NAZWA>299 009 199</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299009199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321538.968000 288249.443000</gml:lowerCorner>
        		<gml:upperCorner>321538.968000 288249.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321538.968000 288249.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 008 324</ms:GML_ID>
        <ms:NAZWA>299 008 324</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299008324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322403.595000 287876.439000</gml:lowerCorner>
        		<gml:upperCorner>322403.595000 287876.439000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322403.595000 287876.439000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 007 370</ms:GML_ID>
        <ms:NAZWA>299 007 370</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299007370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323921.607000 287650.037000</gml:lowerCorner>
        		<gml:upperCorner>323921.607000 287650.037000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323921.607000 287650.037000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 005 530</ms:GML_ID>
        <ms:NAZWA>299 005 530</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299005530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324759.137000 287841.475000</gml:lowerCorner>
        		<gml:upperCorner>324759.137000 287841.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324759.137000 287841.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 004 631</ms:GML_ID>
        <ms:NAZWA>299 004 631</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299004631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326047.302000 288179.285000</gml:lowerCorner>
        		<gml:upperCorner>326047.302000 288179.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326047.302000 288179.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 003 248</ms:GML_ID>
        <ms:NAZWA>299 003 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299003248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327301.819000 289012.554000</gml:lowerCorner>
        		<gml:upperCorner>327301.819000 289012.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327301.819000 289012.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 001 736</ms:GML_ID>
        <ms:NAZWA>299 001 736</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299001736</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4886">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327349.915564 289005.741874</gml:lowerCorner>
        		<gml:upperCorner>327349.915564 289005.741874</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4886.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327349.915564 289005.741874</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4886</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.345 001 719</ms:GML_ID>
        <ms:NAZWA>345 001 719</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>345001719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327931.265000 289711.597000</gml:lowerCorner>
        		<gml:upperCorner>327931.265000 289711.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327931.265000 289711.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 000 781</ms:GML_ID>
        <ms:NAZWA>299 000 781</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299000781</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328261.628000 289979.635000</gml:lowerCorner>
        		<gml:upperCorner>328261.628000 289979.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328261.628000 289979.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.299 000 354</ms:GML_ID>
        <ms:NAZWA>299 000 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>299000354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328952.466000 290729.597000</gml:lowerCorner>
        		<gml:upperCorner>328952.466000 290729.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328952.466000 290729.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 000 665</ms:GML_ID>
        <ms:NAZWA>298 000 665</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298000665</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329267.506000 290936.706000</gml:lowerCorner>
        		<gml:upperCorner>329267.506000 290936.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329267.506000 290936.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 001 053</ms:GML_ID>
        <ms:NAZWA>298 001 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298001053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330340.588000 290842.164000</gml:lowerCorner>
        		<gml:upperCorner>330340.588000 290842.164000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330340.588000 290842.164000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 002 139</ms:GML_ID>
        <ms:NAZWA>298 002 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298002139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330826.708000 295429.870000</gml:lowerCorner>
        		<gml:upperCorner>330826.708000 295429.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330826.708000 295429.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 096 944</ms:GML_ID>
        <ms:NAZWA>274 096 944</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274096944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330884.066000 295747.064000</gml:lowerCorner>
        		<gml:upperCorner>330884.066000 295747.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330884.066000 295747.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 096 617</ms:GML_ID>
        <ms:NAZWA>274 096 617</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274096617</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330901.674000 294997.602000</gml:lowerCorner>
        		<gml:upperCorner>330901.674000 294997.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330901.674000 294997.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 097 385</ms:GML_ID>
        <ms:NAZWA>274 097 385</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274097385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331031.794000 290942.003000</gml:lowerCorner>
        		<gml:upperCorner>331031.794000 290942.003000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331031.794000 290942.003000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 002 840</ms:GML_ID>
        <ms:NAZWA>298 002 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298002840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331335.558000 296533.186000</gml:lowerCorner>
        		<gml:upperCorner>331335.558000 296533.186000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331335.558000 296533.186000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 095 710</ms:GML_ID>
        <ms:NAZWA>274 095 710</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274095710</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331395.147000 291120.505000</gml:lowerCorner>
        		<gml:upperCorner>331395.147000 291120.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331395.147000 291120.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 003 248</ms:GML_ID>
        <ms:NAZWA>298 003 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298003248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331583.396622 291375.194429</gml:lowerCorner>
        		<gml:upperCorner>331583.396622 291375.194429</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331583.396622 291375.194429</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 003 567</ms:GML_ID>
        <ms:NAZWA>298 003 567</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298003567</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331660.324207 291717.355036</gml:lowerCorner>
        		<gml:upperCorner>331660.324207 291717.355036</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331660.324207 291717.355036</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.298 003 920</ms:GML_ID>
        <ms:NAZWA>298 003 920</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>298003920</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>331782.228000 292951.032000</gml:lowerCorner>
        		<gml:upperCorner>331782.228000 292951.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>331782.228000 292951.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 099 614</ms:GML_ID>
        <ms:NAZWA>274 099 614</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274099614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332015.617000 292490.434000</gml:lowerCorner>
        		<gml:upperCorner>332015.617000 292490.434000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332015.617000 292490.434000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 100 130</ms:GML_ID>
        <ms:NAZWA>274 100 130</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274100130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332381.262000 291881.633000</gml:lowerCorner>
        		<gml:upperCorner>332381.262000 291881.633000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332381.262000 291881.633000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 100 843</ms:GML_ID>
        <ms:NAZWA>274 100 843</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274100843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332816.744000 291587.073000</gml:lowerCorner>
        		<gml:upperCorner>332816.744000 291587.073000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332816.744000 291587.073000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 101 372</ms:GML_ID>
        <ms:NAZWA>274 101 372</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274101372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334418.333000 290676.721000</gml:lowerCorner>
        		<gml:upperCorner>334418.333000 290676.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334418.333000 290676.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 103 263</ms:GML_ID>
        <ms:NAZWA>274 103 263</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274103263</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334678.646000 290318.736000</gml:lowerCorner>
        		<gml:upperCorner>334678.646000 290318.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334678.646000 290318.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 103 706</ms:GML_ID>
        <ms:NAZWA>274 103 706</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274103706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335299.980290 289899.204707</gml:lowerCorner>
        		<gml:upperCorner>335299.980290 289899.204707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335299.980290 289899.204707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 104 456</ms:GML_ID>
        <ms:NAZWA>274 104 456</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274104456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336804.041000 288414.648000</gml:lowerCorner>
        		<gml:upperCorner>336804.041000 288414.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336804.041000 288414.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 106 670</ms:GML_ID>
        <ms:NAZWA>274 106 670</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274106670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367714.873000 285018.297000</gml:lowerCorner>
        		<gml:upperCorner>367714.873000 285018.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367714.873000 285018.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 020 004</ms:GML_ID>
        <ms:NAZWA>284 020 004</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284020004</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367823.657000 287149.471000</gml:lowerCorner>
        		<gml:upperCorner>367823.657000 287149.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367823.657000 287149.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 017 695</ms:GML_ID>
        <ms:NAZWA>284 017 695</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284017695</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367975.436000 287936.580000</gml:lowerCorner>
        		<gml:upperCorner>367975.436000 287936.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367975.436000 287936.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 016 732</ms:GML_ID>
        <ms:NAZWA>284 016 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284016732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368110.697000 285971.908000</gml:lowerCorner>
        		<gml:upperCorner>368110.697000 285971.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368110.697000 285971.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 018 963</ms:GML_ID>
        <ms:NAZWA>284 018 963</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284018963</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368371.667853 288342.084071</gml:lowerCorner>
        		<gml:upperCorner>368371.667853 288342.084071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368371.667853 288342.084071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 016 143</ms:GML_ID>
        <ms:NAZWA>284 016 143</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284016143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368857.454289 289206.540421</gml:lowerCorner>
        		<gml:upperCorner>368857.454289 289206.540421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368857.454289 289206.540421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 015 161</ms:GML_ID>
        <ms:NAZWA>284 015 161</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284015161</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369422.749942 290017.494936</gml:lowerCorner>
        		<gml:upperCorner>369422.749942 290017.494936</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369422.749942 290017.494936</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 014 172</ms:GML_ID>
        <ms:NAZWA>284 014 172</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284014172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369782.956919 290670.823875</gml:lowerCorner>
        		<gml:upperCorner>369782.956919 290670.823875</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369782.956919 290670.823875</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 013 426</ms:GML_ID>
        <ms:NAZWA>284 013 426</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284013426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370018.514893 291274.323349</gml:lowerCorner>
        		<gml:upperCorner>370018.514893 291274.323349</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370018.514893 291274.323349</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 012 772</ms:GML_ID>
        <ms:NAZWA>284 012 772</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284012772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370519.637463 292401.681721</gml:lowerCorner>
        		<gml:upperCorner>370519.637463 292401.681721</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370519.637463 292401.681721</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 011 526</ms:GML_ID>
        <ms:NAZWA>284 011 526</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284011526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4309">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371172.062212 293289.878286</gml:lowerCorner>
        		<gml:upperCorner>371172.062212 293289.878286</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4309.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371172.062212 293289.878286</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4309</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 010 403</ms:GML_ID>
        <ms:NAZWA>284 010 403</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284010403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4308">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371444.839934 293675.708820</gml:lowerCorner>
        		<gml:upperCorner>371444.839934 293675.708820</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4308.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371444.839934 293675.708820</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4308</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 009 967</ms:GML_ID>
        <ms:NAZWA>284 009 967</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284009967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4307">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371766.737366 294703.574173</gml:lowerCorner>
        		<gml:upperCorner>371766.737366 294703.574173</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4307.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371766.737366 294703.574173</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4307</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 008 850</ms:GML_ID>
        <ms:NAZWA>284 008 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284008850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4204">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380718.769000 294428.845000</gml:lowerCorner>
        		<gml:upperCorner>380718.769000 294428.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4204.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380718.769000 294428.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4204</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 000 052</ms:GML_ID>
        <ms:NAZWA>282 000 052</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282000052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380748.623464 294453.436959</gml:lowerCorner>
        		<gml:upperCorner>380748.623464 294453.436959</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380748.623464 294453.436959</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 074 623</ms:GML_ID>
        <ms:NAZWA>275 074 623</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275074623</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4207">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380882.881000 291504.531000</gml:lowerCorner>
        		<gml:upperCorner>380882.881000 291504.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4207.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380882.881000 291504.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4207</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 003 011</ms:GML_ID>
        <ms:NAZWA>282 003 011</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282003011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4206">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380894.299000 292636.885000</gml:lowerCorner>
        		<gml:upperCorner>380894.299000 292636.885000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4206.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380894.299000 292636.885000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4206</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 001 877</ms:GML_ID>
        <ms:NAZWA>282 001 877</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282001877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337515.776476 287545.660245</gml:lowerCorner>
        		<gml:upperCorner>337515.776476 287545.660245</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337515.776476 287545.660245</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 107 876</ms:GML_ID>
        <ms:NAZWA>274 107 876</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274107876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337594.450000 287261.312000</gml:lowerCorner>
        		<gml:upperCorner>337594.450000 287261.312000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337594.450000 287261.312000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 108 176</ms:GML_ID>
        <ms:NAZWA>274 108 176</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274108176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337788.965000 289785.771000</gml:lowerCorner>
        		<gml:upperCorner>337788.965000 289785.771000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337788.965000 289785.771000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 002 571</ms:GML_ID>
        <ms:NAZWA>776 002 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776002571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338323.043000 286923.437000</gml:lowerCorner>
        		<gml:upperCorner>338323.043000 286923.437000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338323.043000 286923.437000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 109 003</ms:GML_ID>
        <ms:NAZWA>274 109 003</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274109003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338408.842000 286743.923000</gml:lowerCorner>
        		<gml:upperCorner>338408.842000 286743.923000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338408.842000 286743.923000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 109 203</ms:GML_ID>
        <ms:NAZWA>274 109 203</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274109203</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338961.308000 289508.052000</gml:lowerCorner>
        		<gml:upperCorner>338961.308000 289508.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338961.308000 289508.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 003 841</ms:GML_ID>
        <ms:NAZWA>776 003 841</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776003841</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339242.979767 283642.809434</gml:lowerCorner>
        		<gml:upperCorner>339242.979767 283642.809434</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339242.979767 283642.809434</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 113 235</ms:GML_ID>
        <ms:NAZWA>274 113 235</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274113235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339469.997000 289274.816000</gml:lowerCorner>
        		<gml:upperCorner>339469.997000 289274.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339469.997000 289274.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 004 400</ms:GML_ID>
        <ms:NAZWA>776 004 400</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776004400</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339796.543000 289185.333000</gml:lowerCorner>
        		<gml:upperCorner>339796.543000 289185.333000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339796.543000 289185.333000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 004 740</ms:GML_ID>
        <ms:NAZWA>776 004 740</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776004740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339836.269000 284558.139000</gml:lowerCorner>
        		<gml:upperCorner>339836.269000 284558.139000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339836.269000 284558.139000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 112 119</ms:GML_ID>
        <ms:NAZWA>274 112 119</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274112119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339837.096000 284907.279000</gml:lowerCorner>
        		<gml:upperCorner>339837.096000 284907.279000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339837.096000 284907.279000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 111 768</ms:GML_ID>
        <ms:NAZWA>274 111 768</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274111768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340112.526000 289181.557000</gml:lowerCorner>
        		<gml:upperCorner>340112.526000 289181.557000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340112.526000 289181.557000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 005 056</ms:GML_ID>
        <ms:NAZWA>776 005 056</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776005056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340461.425000 289195.592000</gml:lowerCorner>
        		<gml:upperCorner>340461.425000 289195.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340461.425000 289195.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 005 406</ms:GML_ID>
        <ms:NAZWA>776 005 406</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776005406</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340866.685000 289065.600000</gml:lowerCorner>
        		<gml:upperCorner>340866.685000 289065.600000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340866.685000 289065.600000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 005 833</ms:GML_ID>
        <ms:NAZWA>776 005 833</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776005833</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341645.140773 288513.143311</gml:lowerCorner>
        		<gml:upperCorner>341645.140773 288513.143311</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341645.140773 288513.143311</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 006 801</ms:GML_ID>
        <ms:NAZWA>776 006 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776006801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341769.661000 288252.358000</gml:lowerCorner>
        		<gml:upperCorner>341769.661000 288252.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341769.661000 288252.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 007 092</ms:GML_ID>
        <ms:NAZWA>776 007 092</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776007092</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342368.011000 286594.733000</gml:lowerCorner>
        		<gml:upperCorner>342368.011000 286594.733000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342368.011000 286594.733000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 009 015</ms:GML_ID>
        <ms:NAZWA>776 009 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776009015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344560.507000 284673.297000</gml:lowerCorner>
        		<gml:upperCorner>344560.507000 284673.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344560.507000 284673.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 012 314</ms:GML_ID>
        <ms:NAZWA>776 012 314</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776012314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345188.653000 284078.109000</gml:lowerCorner>
        		<gml:upperCorner>345188.653000 284078.109000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345188.653000 284078.109000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 013 208</ms:GML_ID>
        <ms:NAZWA>776 013 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776013208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345632.754884 283858.503957</gml:lowerCorner>
        		<gml:upperCorner>345632.754884 283858.503957</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345632.754884 283858.503957</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 013 707</ms:GML_ID>
        <ms:NAZWA>776 013 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776013707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346167.512000 283872.262000</gml:lowerCorner>
        		<gml:upperCorner>346167.512000 283872.262000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346167.512000 283872.262000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.776 014 243</ms:GML_ID>
        <ms:NAZWA>776 014 243</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>776014243</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357626.752692 304424.348708</gml:lowerCorner>
        		<gml:upperCorner>357626.752692 304424.348708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357626.752692 304424.348708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 261 439</ms:GML_ID>
        <ms:NAZWA>137 261 439</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137261439</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358099.804071 303474.992602</gml:lowerCorner>
        		<gml:upperCorner>358099.804071 303474.992602</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358099.804071 303474.992602</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 262 501</ms:GML_ID>
        <ms:NAZWA>137 262 501</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137262501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358352.055000 303177.307000</gml:lowerCorner>
        		<gml:upperCorner>358352.055000 303177.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358352.055000 303177.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 262 893</ms:GML_ID>
        <ms:NAZWA>137 262 893</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137262893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358559.315000 303040.506000</gml:lowerCorner>
        		<gml:upperCorner>358559.315000 303040.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358559.315000 303040.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 263 142</ms:GML_ID>
        <ms:NAZWA>137 263 142</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137263142</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359113.789688 302676.344403</gml:lowerCorner>
        		<gml:upperCorner>359113.789688 302676.344403</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359113.789688 302676.344403</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 263 806</ms:GML_ID>
        <ms:NAZWA>137 263 806</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137263806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359257.514000 302581.966000</gml:lowerCorner>
        		<gml:upperCorner>359257.514000 302581.966000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359257.514000 302581.966000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 263 988</ms:GML_ID>
        <ms:NAZWA>137 263 988</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137263988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359450.330000 302455.704000</gml:lowerCorner>
        		<gml:upperCorner>359450.330000 302455.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359450.330000 302455.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 264 208</ms:GML_ID>
        <ms:NAZWA>137 264 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137264208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359666.191646 302301.099784</gml:lowerCorner>
        		<gml:upperCorner>359666.191646 302301.099784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359666.191646 302301.099784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 264 474</ms:GML_ID>
        <ms:NAZWA>137 264 474</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137264474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360771.103518 301174.220064</gml:lowerCorner>
        		<gml:upperCorner>360771.103518 301174.220064</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360771.103518 301174.220064</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 266 057</ms:GML_ID>
        <ms:NAZWA>137 266 057</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137266057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4788">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362592.719298 281106.183243</gml:lowerCorner>
        		<gml:upperCorner>362592.719298 281106.183243</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4788.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362592.719298 281106.183243</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4788</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.312 033 489</ms:GML_ID>
        <ms:NAZWA>312 033 489</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>312033489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363714.193761 283880.093488</gml:lowerCorner>
        		<gml:upperCorner>363714.193761 283880.093488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363714.193761 283880.093488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 002 480</ms:GML_ID>
        <ms:NAZWA>342 002 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342002480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364045.799390 284677.605326</gml:lowerCorner>
        		<gml:upperCorner>364045.799390 284677.605326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364045.799390 284677.605326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 003 375</ms:GML_ID>
        <ms:NAZWA>342 003 375</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342003375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364056.993807 285855.685333</gml:lowerCorner>
        		<gml:upperCorner>364056.993807 285855.685333</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364056.993807 285855.685333</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 004 577</ms:GML_ID>
        <ms:NAZWA>342 004 577</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342004577</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364587.405000 283054.901000</gml:lowerCorner>
        		<gml:upperCorner>364587.405000 283054.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364587.405000 283054.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 001 027</ms:GML_ID>
        <ms:NAZWA>342 001 027</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342001027</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364938.234000 282577.991000</gml:lowerCorner>
        		<gml:upperCorner>364938.234000 282577.991000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364938.234000 282577.991000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 000 389</ms:GML_ID>
        <ms:NAZWA>342 000 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342000389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365118.723468 282442.790961</gml:lowerCorner>
        		<gml:upperCorner>365118.723468 282442.790961</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365118.723468 282442.790961</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.342 000 144</ms:GML_ID>
        <ms:NAZWA>342 000 144</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>342000144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4789">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365152.638000 282362.924000</gml:lowerCorner>
        		<gml:upperCorner>365152.638000 282362.924000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4789.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365152.638000 282362.924000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4789</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.312 036 542</ms:GML_ID>
        <ms:NAZWA>312 036 542</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>312036542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365718.751779 301186.719800</gml:lowerCorner>
        		<gml:upperCorner>365718.751779 301186.719800</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365718.751779 301186.719800</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.137 271 360</ms:GML_ID>
        <ms:NAZWA>137 271 360</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>137271360</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366925.719000 283736.974000</gml:lowerCorner>
        		<gml:upperCorner>366925.719000 283736.974000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366925.719000 283736.974000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 021 600</ms:GML_ID>
        <ms:NAZWA>284 021 600</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284021600</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366957.349399 283933.399065</gml:lowerCorner>
        		<gml:upperCorner>366957.349399 283933.399065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366957.349399 283933.399065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 021 394</ms:GML_ID>
        <ms:NAZWA>284 021 394</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284021394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367017.875000 283435.185000</gml:lowerCorner>
        		<gml:upperCorner>367017.875000 283435.185000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367017.875000 283435.185000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 021 915</ms:GML_ID>
        <ms:NAZWA>284 021 915</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284021915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367160.141805 284509.210844</gml:lowerCorner>
        		<gml:upperCorner>367160.141805 284509.210844</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367160.141805 284509.210844</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.284 020 773</ms:GML_ID>
        <ms:NAZWA>284 020 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>284020773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4205">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380903.992000 293617.336000</gml:lowerCorner>
        		<gml:upperCorner>380903.992000 293617.336000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4205.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380903.992000 293617.336000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4205</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 000 895</ms:GML_ID>
        <ms:NAZWA>282 000 895</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282000895</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4208">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380918.027000 290709.694000</gml:lowerCorner>
        		<gml:upperCorner>380918.027000 290709.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4208.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380918.027000 290709.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4208</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 003 809</ms:GML_ID>
        <ms:NAZWA>282 003 809</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282003809</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381107.281000 294020.214000</gml:lowerCorner>
        		<gml:upperCorner>381107.281000 294020.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381107.281000 294020.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 075 185</ms:GML_ID>
        <ms:NAZWA>275 075 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275075185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4209">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381326.176000 289875.005000</gml:lowerCorner>
        		<gml:upperCorner>381326.176000 289875.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4209.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381326.176000 289875.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4209</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 004 745</ms:GML_ID>
        <ms:NAZWA>282 004 745</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282004745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4211">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381927.856000 279988.009000</gml:lowerCorner>
        		<gml:upperCorner>381927.856000 279988.009000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4211.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381927.856000 279988.009000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4211</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 015 532</ms:GML_ID>
        <ms:NAZWA>282 015 532</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282015532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382188.763000 292679.033000</gml:lowerCorner>
        		<gml:upperCorner>382188.763000 292679.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382188.763000 292679.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 076 913</ms:GML_ID>
        <ms:NAZWA>275 076 913</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275076913</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4210">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382191.445000 281039.789000</gml:lowerCorner>
        		<gml:upperCorner>382191.445000 281039.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4210.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382191.445000 281039.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4210</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 014 448</ms:GML_ID>
        <ms:NAZWA>282 014 448</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282014448</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382578.490000 292196.306000</gml:lowerCorner>
        		<gml:upperCorner>382578.490000 292196.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382578.490000 292196.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 077 526</ms:GML_ID>
        <ms:NAZWA>275 077 526</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275077526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383284.462000 291321.084000</gml:lowerCorner>
        		<gml:upperCorner>383284.462000 291321.084000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383284.462000 291321.084000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 078 650</ms:GML_ID>
        <ms:NAZWA>275 078 650</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275078650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383894.857000 290563.850000</gml:lowerCorner>
        		<gml:upperCorner>383894.857000 290563.850000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383894.857000 290563.850000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 079 621</ms:GML_ID>
        <ms:NAZWA>275 079 621</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275079621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384174.674000 290215.917000</gml:lowerCorner>
        		<gml:upperCorner>384174.674000 290215.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384174.674000 290215.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 080 071</ms:GML_ID>
        <ms:NAZWA>275 080 071</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275080071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384282.785000 290083.355000</gml:lowerCorner>
        		<gml:upperCorner>384282.785000 290083.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384282.785000 290083.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 080 240</ms:GML_ID>
        <ms:NAZWA>275 080 240</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275080240</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.329">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385919.365000 287897.668000</gml:lowerCorner>
        		<gml:upperCorner>385919.365000 287897.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.329.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385919.365000 287897.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>329</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 082 973</ms:GML_ID>
        <ms:NAZWA>275 082 973</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275082973</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.330">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386166.075000 287524.408000</gml:lowerCorner>
        		<gml:upperCorner>386166.075000 287524.408000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.330.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386166.075000 287524.408000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>330</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 083 423</ms:GML_ID>
        <ms:NAZWA>275 083 423</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275083423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.331">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388259.808255 285364.269338</gml:lowerCorner>
        		<gml:upperCorner>388259.808255 285364.269338</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.331.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388259.808255 285364.269338</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>331</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.275 086 446</ms:GML_ID>
        <ms:NAZWA>275 086 446</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>275086446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339868.731000 279964.522000</gml:lowerCorner>
        		<gml:upperCorner>339868.731000 279964.522000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339868.731000 279964.522000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 117 121</ms:GML_ID>
        <ms:NAZWA>274 117 121</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274117121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339916.473000 277398.378000</gml:lowerCorner>
        		<gml:upperCorner>339916.473000 277398.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339916.473000 277398.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 119 838</ms:GML_ID>
        <ms:NAZWA>274 119 838</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274119838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340012.319377 268024.147078</gml:lowerCorner>
        		<gml:upperCorner>340012.319377 268024.147078</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340012.319377 268024.147078</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 003 782</ms:GML_ID>
        <ms:NAZWA>311 003 782</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311003782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345617.911000 254297.349000</gml:lowerCorner>
        		<gml:upperCorner>345617.911000 254297.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345617.911000 254297.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 146 820</ms:GML_ID>
        <ms:NAZWA>274 146 820</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274146820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345013.304000 255042.460000</gml:lowerCorner>
        		<gml:upperCorner>345013.304000 255042.460000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345013.304000 255042.460000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 145 838</ms:GML_ID>
        <ms:NAZWA>274 145 838</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274145838</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369592.604116 255157.214948</gml:lowerCorner>
        		<gml:upperCorner>369592.604116 255157.214948</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369592.604116 255157.214948</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 041 458</ms:GML_ID>
        <ms:NAZWA>283 041 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283041458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368884.523176 255765.805510</gml:lowerCorner>
        		<gml:upperCorner>368884.523176 255765.805510</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368884.523176 255765.805510</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 040 502</ms:GML_ID>
        <ms:NAZWA>283 040 502</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283040502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367555.351059 257201.031689</gml:lowerCorner>
        		<gml:upperCorner>367555.351059 257201.031689</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367555.351059 257201.031689</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 038 381</ms:GML_ID>
        <ms:NAZWA>283 038 381</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283038381</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344234.158859 258472.343565</gml:lowerCorner>
        		<gml:upperCorner>344234.158859 258472.343565</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344234.158859 258472.343565</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 142 321</ms:GML_ID>
        <ms:NAZWA>274 142 321</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274142321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344100.583949 259335.050912</gml:lowerCorner>
        		<gml:upperCorner>344100.583949 259335.050912</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344100.583949 259335.050912</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 141 440</ms:GML_ID>
        <ms:NAZWA>274 141 440</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274141440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343560.837000 263008.978000</gml:lowerCorner>
        		<gml:upperCorner>343560.837000 263008.978000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343560.837000 263008.978000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 137 606</ms:GML_ID>
        <ms:NAZWA>274 137 606</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274137606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340781.265147 268318.763098</gml:lowerCorner>
        		<gml:upperCorner>340781.265147 268318.763098</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340781.265147 268318.763098</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 002 933</ms:GML_ID>
        <ms:NAZWA>311 002 933</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311002933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341735.840000 269176.887000</gml:lowerCorner>
        		<gml:upperCorner>341735.840000 269176.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341735.840000 269176.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 001 629</ms:GML_ID>
        <ms:NAZWA>311 001 629</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311001629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343239.013919 271091.783899</gml:lowerCorner>
        		<gml:upperCorner>343239.013919 271091.783899</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343239.013919 271091.783899</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 127 205</ms:GML_ID>
        <ms:NAZWA>274 127 205</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274127205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341468.687470 273964.748950</gml:lowerCorner>
        		<gml:upperCorner>341468.687470 273964.748950</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341468.687470 273964.748950</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 123 639</ms:GML_ID>
        <ms:NAZWA>274 123 639</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274123639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340786.505938 275305.415400</gml:lowerCorner>
        		<gml:upperCorner>340786.505938 275305.415400</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340786.505938 275305.415400</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 122 135</ms:GML_ID>
        <ms:NAZWA>274 122 135</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274122135</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340078.129693 276751.343292</gml:lowerCorner>
        		<gml:upperCorner>340078.129693 276751.343292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340078.129693 276751.343292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 120 503</ms:GML_ID>
        <ms:NAZWA>274 120 503</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274120503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372702.099000 250098.810000</gml:lowerCorner>
        		<gml:upperCorner>372702.099000 250098.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372702.099000 250098.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 047 702</ms:GML_ID>
        <ms:NAZWA>283 047 702</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283047702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382433.063000 250134.005000</gml:lowerCorner>
        		<gml:upperCorner>382433.063000 250134.005000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382433.063000 250134.005000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 047 152</ms:GML_ID>
        <ms:NAZWA>282 047 152</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282047152</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386014.500000 250254.689000</gml:lowerCorner>
        		<gml:upperCorner>386014.500000 250254.689000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386014.500000 250254.689000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 066 158</ms:GML_ID>
        <ms:NAZWA>283 066 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283066158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387118.759000 250391.756000</gml:lowerCorner>
        		<gml:upperCorner>387118.759000 250391.756000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387118.759000 250391.756000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 067 432</ms:GML_ID>
        <ms:NAZWA>283 067 432</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283067432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372584.009000 250438.509000</gml:lowerCorner>
        		<gml:upperCorner>372584.009000 250438.509000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372584.009000 250438.509000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 047 336</ms:GML_ID>
        <ms:NAZWA>283 047 336</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283047336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386735.775000 250552.849000</gml:lowerCorner>
        		<gml:upperCorner>386735.775000 250552.849000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386735.775000 250552.849000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 067 016</ms:GML_ID>
        <ms:NAZWA>283 067 016</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283067016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372230.994000 251088.464000</gml:lowerCorner>
        		<gml:upperCorner>372230.994000 251088.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372230.994000 251088.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 046 580</ms:GML_ID>
        <ms:NAZWA>283 046 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283046580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384417.860000 256818.809000</gml:lowerCorner>
        		<gml:upperCorner>384417.860000 256818.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384417.860000 256818.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 040 170</ms:GML_ID>
        <ms:NAZWA>282 040 170</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282040170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383342.368536 261137.848224</gml:lowerCorner>
        		<gml:upperCorner>383342.368536 261137.848224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383342.368536 261137.848224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 035 643</ms:GML_ID>
        <ms:NAZWA>282 035 643</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282035643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383761.554620 261730.959454</gml:lowerCorner>
        		<gml:upperCorner>383761.554620 261730.959454</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383761.554620 261730.959454</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.973 001 182</ms:GML_ID>
        <ms:NAZWA>973 001 182</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>973001182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2690">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384144.140000 261929.943000</gml:lowerCorner>
        		<gml:upperCorner>384144.140000 261929.943000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2690.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384144.140000 261929.943000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2690</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.973 001 615</ms:GML_ID>
        <ms:NAZWA>973 001 615</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>973001615</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2691">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385072.772000 262365.348000</gml:lowerCorner>
        		<gml:upperCorner>385072.772000 262365.348000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2691.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385072.772000 262365.348000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2691</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.973 002 676</ms:GML_ID>
        <ms:NAZWA>973 002 676</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>973002676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2692">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385547.614000 262525.843000</gml:lowerCorner>
        		<gml:upperCorner>385547.614000 262525.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2692.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385547.614000 262525.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2692</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.973 003 163</ms:GML_ID>
        <ms:NAZWA>973 003 163</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>973003163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384910.805373 263682.813303</gml:lowerCorner>
        		<gml:upperCorner>384910.805373 263682.813303</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384910.805373 263682.813303</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 032 603</ms:GML_ID>
        <ms:NAZWA>282 032 603</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282032603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4216">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385170.329000 268569.376000</gml:lowerCorner>
        		<gml:upperCorner>385170.329000 268569.376000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4216.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385170.329000 268569.376000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4216</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 027 708</ms:GML_ID>
        <ms:NAZWA>282 027 708</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282027708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4215">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385071.296000 270279.242000</gml:lowerCorner>
        		<gml:upperCorner>385071.296000 270279.242000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4215.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385071.296000 270279.242000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4215</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 025 980</ms:GML_ID>
        <ms:NAZWA>282 025 980</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282025980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4214">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384691.811000 271338.839000</gml:lowerCorner>
        		<gml:upperCorner>384691.811000 271338.839000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4214.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384691.811000 271338.839000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4214</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 024 863</ms:GML_ID>
        <ms:NAZWA>282 024 863</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282024863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4213">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384129.984000 272837.783000</gml:lowerCorner>
        		<gml:upperCorner>384129.984000 272837.783000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4213.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384129.984000 272837.783000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4213</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 023 247</ms:GML_ID>
        <ms:NAZWA>282 023 247</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282023247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4212">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383134.551696 275495.603210</gml:lowerCorner>
        		<gml:upperCorner>383134.551696 275495.603210</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4212.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383134.551696 275495.603210</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4212</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 020 418</ms:GML_ID>
        <ms:NAZWA>282 020 418</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282020418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4787">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336130.570000 256282.039000</gml:lowerCorner>
        		<gml:upperCorner>336130.570000 256282.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4787.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336130.570000 256282.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4787</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 026 205</ms:GML_ID>
        <ms:NAZWA>311 026 205</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311026205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4786">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337061.737000 257865.314000</gml:lowerCorner>
        		<gml:upperCorner>337061.737000 257865.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4786.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337061.737000 257865.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4786</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 022 635</ms:GML_ID>
        <ms:NAZWA>311 022 635</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311022635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4785">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338261.574000 258297.427000</gml:lowerCorner>
        		<gml:upperCorner>338261.574000 258297.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4785.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338261.574000 258297.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4785</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 017 561</ms:GML_ID>
        <ms:NAZWA>311 017 561</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311017561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4784">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338174.380000 258583.634000</gml:lowerCorner>
        		<gml:upperCorner>338174.380000 258583.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4784.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338174.380000 258583.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4784</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 017 259</ms:GML_ID>
        <ms:NAZWA>311 017 259</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311017259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4783">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338045.238000 259013.681000</gml:lowerCorner>
        		<gml:upperCorner>338045.238000 259013.681000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4783.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338045.238000 259013.681000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4783</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 016 803</ms:GML_ID>
        <ms:NAZWA>311 016 803</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311016803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4782">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337180.417267 260349.764139</gml:lowerCorner>
        		<gml:upperCorner>337180.417267 260349.764139</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4782.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337180.417267 260349.764139</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4782</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 013 137</ms:GML_ID>
        <ms:NAZWA>311 013 137</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311013137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4781">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337150.861000 261275.411000</gml:lowerCorner>
        		<gml:upperCorner>337150.861000 261275.411000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4781.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337150.861000 261275.411000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4781</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 012 210</ms:GML_ID>
        <ms:NAZWA>311 012 210</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311012210</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4780">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337137.130280 261559.562191</gml:lowerCorner>
        		<gml:upperCorner>337137.130280 261559.562191</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4780.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337137.130280 261559.562191</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4780</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 011 927</ms:GML_ID>
        <ms:NAZWA>311 011 927</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311011927</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4779">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336997.438461 261859.334401</gml:lowerCorner>
        		<gml:upperCorner>336997.438461 261859.334401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4779.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336997.438461 261859.334401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4779</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 011 594</ms:GML_ID>
        <ms:NAZWA>311 011 594</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311011594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4778">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336649.322000 263401.679000</gml:lowerCorner>
        		<gml:upperCorner>336649.322000 263401.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4778.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336649.322000 263401.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4778</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 009 987</ms:GML_ID>
        <ms:NAZWA>311 009 987</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311009987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4777">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336787.826000 263755.701000</gml:lowerCorner>
        		<gml:upperCorner>336787.826000 263755.701000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4777.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336787.826000 263755.701000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4777</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 009 589</ms:GML_ID>
        <ms:NAZWA>311 009 589</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311009589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4776">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337225.859842 264128.600782</gml:lowerCorner>
        		<gml:upperCorner>337225.859842 264128.600782</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4776.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337225.859842 264128.600782</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4776</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 009 014</ms:GML_ID>
        <ms:NAZWA>311 009 014</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311009014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4775">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337615.539000 264310.314000</gml:lowerCorner>
        		<gml:upperCorner>337615.539000 264310.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4775.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337615.539000 264310.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4775</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 008 582</ms:GML_ID>
        <ms:NAZWA>311 008 582</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311008582</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338094.275000 264672.280000</gml:lowerCorner>
        		<gml:upperCorner>338094.275000 264672.280000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338094.275000 264672.280000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 007 983</ms:GML_ID>
        <ms:NAZWA>311 007 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311007983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338642.105000 265160.405000</gml:lowerCorner>
        		<gml:upperCorner>338642.105000 265160.405000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338642.105000 265160.405000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 007 242</ms:GML_ID>
        <ms:NAZWA>311 007 242</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311007242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338748.262000 265665.564000</gml:lowerCorner>
        		<gml:upperCorner>338748.262000 265665.564000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338748.262000 265665.564000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 006 726</ms:GML_ID>
        <ms:NAZWA>311 006 726</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311006726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338875.373148 266781.843924</gml:lowerCorner>
        		<gml:upperCorner>338875.373148 266781.843924</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338875.373148 266781.843924</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 005 601</ms:GML_ID>
        <ms:NAZWA>311 005 601</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311005601</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339214.435000 267523.030000</gml:lowerCorner>
        		<gml:upperCorner>339214.435000 267523.030000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339214.435000 267523.030000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 004 726</ms:GML_ID>
        <ms:NAZWA>311 004 726</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311004726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339558.399358 267738.872650</gml:lowerCorner>
        		<gml:upperCorner>339558.399358 267738.872650</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339558.399358 267738.872650</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 004 320</ms:GML_ID>
        <ms:NAZWA>311 004 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311004320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339846.771441 267920.173984</gml:lowerCorner>
        		<gml:upperCorner>339846.771441 267920.173984</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339846.771441 267920.173984</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.311 003 974</ms:GML_ID>
        <ms:NAZWA>311 003 974</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>311003974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360632.470000 249199.885000</gml:lowerCorner>
        		<gml:upperCorner>360632.470000 249199.885000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360632.470000 249199.885000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 166 171</ms:GML_ID>
        <ms:NAZWA>274 166 171</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274166171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360380.092602 249221.535145</gml:lowerCorner>
        		<gml:upperCorner>360380.092602 249221.535145</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360380.092602 249221.535145</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 165 918</ms:GML_ID>
        <ms:NAZWA>274 165 918</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274165918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355641.351000 250491.784000</gml:lowerCorner>
        		<gml:upperCorner>355641.351000 250491.784000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355641.351000 250491.784000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 160 832</ms:GML_ID>
        <ms:NAZWA>274 160 832</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274160832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352902.209000 250981.101000</gml:lowerCorner>
        		<gml:upperCorner>352902.209000 250981.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352902.209000 250981.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 157 318</ms:GML_ID>
        <ms:NAZWA>274 157 318</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274157318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348674.443565 251095.884897</gml:lowerCorner>
        		<gml:upperCorner>348674.443565 251095.884897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348674.443565 251095.884897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 152 151</ms:GML_ID>
        <ms:NAZWA>274 152 151</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274152151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371936.794000 251448.804000</gml:lowerCorner>
        		<gml:upperCorner>371936.794000 251448.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371936.794000 251448.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 046 115</ms:GML_ID>
        <ms:NAZWA>283 046 115</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283046115</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355014.452000 251458.324000</gml:lowerCorner>
        		<gml:upperCorner>355014.452000 251458.324000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355014.452000 251458.324000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 159 670</ms:GML_ID>
        <ms:NAZWA>274 159 670</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274159670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347811.007000 251732.752000</gml:lowerCorner>
        		<gml:upperCorner>347811.007000 251732.752000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347811.007000 251732.752000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 150 995</ms:GML_ID>
        <ms:NAZWA>274 150 995</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274150995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371556.810000 251998.567000</gml:lowerCorner>
        		<gml:upperCorner>371556.810000 251998.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371556.810000 251998.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 045 440</ms:GML_ID>
        <ms:NAZWA>283 045 440</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283045440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347137.522000 254167.353000</gml:lowerCorner>
        		<gml:upperCorner>347137.522000 254167.353000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347137.522000 254167.353000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 148 380</ms:GML_ID>
        <ms:NAZWA>274 148 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274148380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4280">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380324.860000 247755.092000</gml:lowerCorner>
        		<gml:upperCorner>380324.860000 247755.092000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4280.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380324.860000 247755.092000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4280</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 056 729</ms:GML_ID>
        <ms:NAZWA>283 056 729</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283056729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379407.392000 247758.015000</gml:lowerCorner>
        		<gml:upperCorner>379407.392000 247758.015000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379407.392000 247758.015000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 055 806</ms:GML_ID>
        <ms:NAZWA>283 055 806</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283055806</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4281">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380651.322000 247766.830000</gml:lowerCorner>
        		<gml:upperCorner>380651.322000 247766.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4281.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380651.322000 247766.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4281</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 057 053</ms:GML_ID>
        <ms:NAZWA>283 057 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283057053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4279">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379913.010000 247793.817000</gml:lowerCorner>
        		<gml:upperCorner>379913.010000 247793.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4279.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379913.010000 247793.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4279</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 056 314</ms:GML_ID>
        <ms:NAZWA>283 056 314</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283056314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380948.800759 247794.148354</gml:lowerCorner>
        		<gml:upperCorner>380948.800759 247794.148354</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380948.800759 247794.148354</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 057 355</ms:GML_ID>
        <ms:NAZWA>283 057 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283057355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374772.173000 247907.482000</gml:lowerCorner>
        		<gml:upperCorner>374772.173000 247907.482000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374772.173000 247907.482000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 050 732</ms:GML_ID>
        <ms:NAZWA>283 050 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283050732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381203.072000 247965.451000</gml:lowerCorner>
        		<gml:upperCorner>381203.072000 247965.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381203.072000 247965.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 057 666</ms:GML_ID>
        <ms:NAZWA>283 057 666</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283057666</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375664.191565 248137.984063</gml:lowerCorner>
        		<gml:upperCorner>375664.191565 248137.984063</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375664.191565 248137.984063</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 051 832</ms:GML_ID>
        <ms:NAZWA>283 051 832</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283051832</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376094.331000 248178.471000</gml:lowerCorner>
        		<gml:upperCorner>376094.331000 248178.471000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376094.331000 248178.471000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 052 314</ms:GML_ID>
        <ms:NAZWA>283 052 314</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283052314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382625.708091 248245.659841</gml:lowerCorner>
        		<gml:upperCorner>382625.708091 248245.659841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382625.708091 248245.659841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 049 051</ms:GML_ID>
        <ms:NAZWA>282 049 051</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282049051</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381460.885000 248254.002000</gml:lowerCorner>
        		<gml:upperCorner>381460.885000 248254.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381460.885000 248254.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 058 053</ms:GML_ID>
        <ms:NAZWA>283 058 053</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283058053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382609.301000 248388.052000</gml:lowerCorner>
        		<gml:upperCorner>382609.301000 248388.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382609.301000 248388.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 048 907</ms:GML_ID>
        <ms:NAZWA>282 048 907</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282048907</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373814.882000 248830.467000</gml:lowerCorner>
        		<gml:upperCorner>373814.882000 248830.467000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373814.882000 248830.467000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 049 401</ms:GML_ID>
        <ms:NAZWA>283 049 401</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283049401</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382533.219000 249054.345000</gml:lowerCorner>
        		<gml:upperCorner>382533.219000 249054.345000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382533.219000 249054.345000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 048 236</ms:GML_ID>
        <ms:NAZWA>282 048 236</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282048236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373451.715000 249215.259000</gml:lowerCorner>
        		<gml:upperCorner>373451.715000 249215.259000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373451.715000 249215.259000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 048 871</ms:GML_ID>
        <ms:NAZWA>283 048 871</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283048871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372967.298000 249689.321000</gml:lowerCorner>
        		<gml:upperCorner>372967.298000 249689.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372967.298000 249689.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 048 190</ms:GML_ID>
        <ms:NAZWA>283 048 190</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283048190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385556.648000 249693.641000</gml:lowerCorner>
        		<gml:upperCorner>385556.648000 249693.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385556.648000 249693.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 065 434</ms:GML_ID>
        <ms:NAZWA>283 065 434</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283065434</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359827.853000 238360.967000</gml:lowerCorner>
        		<gml:upperCorner>359827.853000 238360.967000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359827.853000 238360.967000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 008 454</ms:GML_ID>
        <ms:NAZWA>337 008 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337008454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359878.368000 238760.014000</gml:lowerCorner>
        		<gml:upperCorner>359878.368000 238760.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359878.368000 238760.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 008 050</ms:GML_ID>
        <ms:NAZWA>337 008 050</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337008050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360166.341000 239171.574000</gml:lowerCorner>
        		<gml:upperCorner>360166.341000 239171.574000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360166.341000 239171.574000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 007 546</ms:GML_ID>
        <ms:NAZWA>337 007 546</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337007546</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360282.183000 239293.980000</gml:lowerCorner>
        		<gml:upperCorner>360282.183000 239293.980000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360282.183000 239293.980000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 007 377</ms:GML_ID>
        <ms:NAZWA>337 007 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337007377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360524.195000 239435.516000</gml:lowerCorner>
        		<gml:upperCorner>360524.195000 239435.516000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360524.195000 239435.516000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 007 096</ms:GML_ID>
        <ms:NAZWA>337 007 096</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337007096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360830.281000 239433.154000</gml:lowerCorner>
        		<gml:upperCorner>360830.281000 239433.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360830.281000 239433.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 006 790</ms:GML_ID>
        <ms:NAZWA>337 006 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337006790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361200.408304 239628.339604</gml:lowerCorner>
        		<gml:upperCorner>361200.408304 239628.339604</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361200.408304 239628.339604</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 006 364</ms:GML_ID>
        <ms:NAZWA>337 006 364</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337006364</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361574.216000 239773.500000</gml:lowerCorner>
        		<gml:upperCorner>361574.216000 239773.500000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361574.216000 239773.500000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 005 964</ms:GML_ID>
        <ms:NAZWA>337 005 964</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337005964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361948.941000 239952.505000</gml:lowerCorner>
        		<gml:upperCorner>361948.941000 239952.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361948.941000 239952.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 005 548</ms:GML_ID>
        <ms:NAZWA>337 005 548</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337005548</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.282">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362106.959646 246749.160366</gml:lowerCorner>
        		<gml:upperCorner>362106.959646 246749.160366</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.282.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362106.959646 246749.160366</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>282</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 169 456</ms:GML_ID>
        <ms:NAZWA>274 169 456</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274169456</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362304.547000 240243.192000</gml:lowerCorner>
        		<gml:upperCorner>362304.547000 240243.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362304.547000 240243.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 005 090</ms:GML_ID>
        <ms:NAZWA>337 005 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337005090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363091.585000 240573.704000</gml:lowerCorner>
        		<gml:upperCorner>363091.585000 240573.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363091.585000 240573.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 004 224</ms:GML_ID>
        <ms:NAZWA>337 004 224</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337004224</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363403.346000 240522.154000</gml:lowerCorner>
        		<gml:upperCorner>363403.346000 240522.154000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363403.346000 240522.154000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 003 909</ms:GML_ID>
        <ms:NAZWA>337 003 909</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337003909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363898.339000 240444.448000</gml:lowerCorner>
        		<gml:upperCorner>363898.339000 240444.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363898.339000 240444.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 003 407</ms:GML_ID>
        <ms:NAZWA>337 003 407</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337003407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364169.960850 240534.770114</gml:lowerCorner>
        		<gml:upperCorner>364169.960850 240534.770114</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364169.960850 240534.770114</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 003 120</ms:GML_ID>
        <ms:NAZWA>337 003 120</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337003120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364563.752012 240700.199392</gml:lowerCorner>
        		<gml:upperCorner>364563.752012 240700.199392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364563.752012 240700.199392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 002 693</ms:GML_ID>
        <ms:NAZWA>337 002 693</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337002693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.283">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365507.163000 241660.749000</gml:lowerCorner>
        		<gml:upperCorner>365507.163000 241660.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.283.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365507.163000 241660.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>283</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 175 863</ms:GML_ID>
        <ms:NAZWA>274 175 863</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274175863</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365728.468405 240639.170298</gml:lowerCorner>
        		<gml:upperCorner>365728.468405 240639.170298</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365728.468405 240639.170298</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 001 452</ms:GML_ID>
        <ms:NAZWA>337 001 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337001452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365825.150095 240767.767100</gml:lowerCorner>
        		<gml:upperCorner>365825.150095 240767.767100</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365825.150095 240767.767100</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 001 285</ms:GML_ID>
        <ms:NAZWA>337 001 285</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337001285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.284">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367178.451378 240604.362827</gml:lowerCorner>
        		<gml:upperCorner>367178.451378 240604.362827</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.284.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367178.451378 240604.362827</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>284</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 177 924</ms:GML_ID>
        <ms:NAZWA>274 177 924</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274177924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367389.861324 240635.771821</gml:lowerCorner>
        		<gml:upperCorner>367389.861324 240635.771821</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367389.861324 240635.771821</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 000 337</ms:GML_ID>
        <ms:NAZWA>279 000 337</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279000337</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367558.393000 240521.861000</gml:lowerCorner>
        		<gml:upperCorner>367558.393000 240521.861000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367558.393000 240521.861000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 178 317</ms:GML_ID>
        <ms:NAZWA>274 178 317</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274178317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367647.310000 240636.170000</gml:lowerCorner>
        		<gml:upperCorner>367647.310000 240636.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367647.310000 240636.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 000 599</ms:GML_ID>
        <ms:NAZWA>279 000 599</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279000599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367759.840000 240648.366000</gml:lowerCorner>
        		<gml:upperCorner>367759.840000 240648.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367759.840000 240648.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 000 711</ms:GML_ID>
        <ms:NAZWA>279 000 711</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279000711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.147">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367909.454000 240671.656000</gml:lowerCorner>
        		<gml:upperCorner>367909.454000 240671.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.147.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367909.454000 240671.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>147</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 000 861</ms:GML_ID>
        <ms:NAZWA>279 000 861</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279000861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.148">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371139.764000 241597.251000</gml:lowerCorner>
        		<gml:upperCorner>371139.764000 241597.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.148.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371139.764000 241597.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>148</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 004 221</ms:GML_ID>
        <ms:NAZWA>279 004 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279004221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358144.436000 238033.302000</gml:lowerCorner>
        		<gml:upperCorner>358144.436000 238033.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358144.436000 238033.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 010 451</ms:GML_ID>
        <ms:NAZWA>337 010 451</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337010451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358288.329110 238069.749013</gml:lowerCorner>
        		<gml:upperCorner>358288.329110 238069.749013</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358288.329110 238069.749013</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 010 297</ms:GML_ID>
        <ms:NAZWA>337 010 297</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337010297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358453.961000 238134.914000</gml:lowerCorner>
        		<gml:upperCorner>358453.961000 238134.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358453.961000 238134.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 010 121</ms:GML_ID>
        <ms:NAZWA>337 010 121</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337010121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358705.551000 238196.448000</gml:lowerCorner>
        		<gml:upperCorner>358705.551000 238196.448000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358705.551000 238196.448000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 009 862</ms:GML_ID>
        <ms:NAZWA>337 009 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337009862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358920.793000 238224.851000</gml:lowerCorner>
        		<gml:upperCorner>358920.793000 238224.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358920.793000 238224.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.337 009 645</ms:GML_ID>
        <ms:NAZWA>337 009 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>337009645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372154.401000 221650.787000</gml:lowerCorner>
        		<gml:upperCorner>372154.401000 221650.787000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372154.401000 221650.787000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 025 132</ms:GML_ID>
        <ms:NAZWA>278 025 132</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278025132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374888.633154 221736.585513</gml:lowerCorner>
        		<gml:upperCorner>374888.633154 221736.585513</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374888.633154 221736.585513</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 022 365</ms:GML_ID>
        <ms:NAZWA>278 022 365</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278022365</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373051.636000 221788.427000</gml:lowerCorner>
        		<gml:upperCorner>373051.636000 221788.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373051.636000 221788.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 024 219</ms:GML_ID>
        <ms:NAZWA>278 024 219</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278024219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379647.433000 222852.231000</gml:lowerCorner>
        		<gml:upperCorner>379647.433000 222852.231000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379647.433000 222852.231000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 017 445</ms:GML_ID>
        <ms:NAZWA>278 017 445</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278017445</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380630.234000 223259.621000</gml:lowerCorner>
        		<gml:upperCorner>380630.234000 223259.621000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380630.234000 223259.621000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 016 382</ms:GML_ID>
        <ms:NAZWA>278 016 382</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278016382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382537.501025 224049.413661</gml:lowerCorner>
        		<gml:upperCorner>382537.501025 224049.413661</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382537.501025 224049.413661</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 014 318</ms:GML_ID>
        <ms:NAZWA>278 014 318</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278014318</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382919.615715 224314.616481</gml:lowerCorner>
        		<gml:upperCorner>382919.615715 224314.616481</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382919.615715 224314.616481</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 013 855</ms:GML_ID>
        <ms:NAZWA>278 013 855</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278013855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383061.023173 224471.586493</gml:lowerCorner>
        		<gml:upperCorner>383061.023173 224471.586493</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383061.023173 224471.586493</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 013 631</ms:GML_ID>
        <ms:NAZWA>278 013 631</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278013631</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383403.692000 226921.794000</gml:lowerCorner>
        		<gml:upperCorner>383403.692000 226921.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383403.692000 226921.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 011 136</ms:GML_ID>
        <ms:NAZWA>278 011 136</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278011136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385602.117000 233658.747000</gml:lowerCorner>
        		<gml:upperCorner>385602.117000 233658.747000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385602.117000 233658.747000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 003 734</ms:GML_ID>
        <ms:NAZWA>278 003 734</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278003734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386312.128000 234444.572000</gml:lowerCorner>
        		<gml:upperCorner>386312.128000 234444.572000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386312.128000 234444.572000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 002 676</ms:GML_ID>
        <ms:NAZWA>278 002 676</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278002676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387126.285000 235442.368000</gml:lowerCorner>
        		<gml:upperCorner>387126.285000 235442.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387126.285000 235442.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 001 384</ms:GML_ID>
        <ms:NAZWA>278 001 384</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278001384</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2693">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387091.379362 237513.944593</gml:lowerCorner>
        		<gml:upperCorner>387091.379362 237513.944593</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2693.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387091.379362 237513.944593</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2693</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.975 001 231</ms:GML_ID>
        <ms:NAZWA>975 001 231</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>975001231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386461.668291 237924.624598</gml:lowerCorner>
        		<gml:upperCorner>386461.668291 237924.624598</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386461.668291 237924.624598</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 020 338</ms:GML_ID>
        <ms:NAZWA>279 020 338</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279020338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386387.970306 238572.242335</gml:lowerCorner>
        		<gml:upperCorner>386387.970306 238572.242335</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386387.970306 238572.242335</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 059 565</ms:GML_ID>
        <ms:NAZWA>282 059 565</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282059565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383560.349000 238889.234000</gml:lowerCorner>
        		<gml:upperCorner>383560.349000 238889.234000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383560.349000 238889.234000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 017 281</ms:GML_ID>
        <ms:NAZWA>279 017 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279017281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383062.878000 239052.937000</gml:lowerCorner>
        		<gml:upperCorner>383062.878000 239052.937000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383062.878000 239052.937000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 016 756</ms:GML_ID>
        <ms:NAZWA>279 016 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279016756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382546.777000 239222.806000</gml:lowerCorner>
        		<gml:upperCorner>382546.777000 239222.806000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382546.777000 239222.806000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 016 213</ms:GML_ID>
        <ms:NAZWA>279 016 213</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279016213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381997.724000 239404.642000</gml:lowerCorner>
        		<gml:upperCorner>381997.724000 239404.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381997.724000 239404.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 015 637</ms:GML_ID>
        <ms:NAZWA>279 015 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279015637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380131.448000 239799.462000</gml:lowerCorner>
        		<gml:upperCorner>380131.448000 239799.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380131.448000 239799.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 013 721</ms:GML_ID>
        <ms:NAZWA>279 013 721</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279013721</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379543.844503 240087.204415</gml:lowerCorner>
        		<gml:upperCorner>379543.844503 240087.204415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379543.844503 240087.204415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 013 058</ms:GML_ID>
        <ms:NAZWA>279 013 058</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279013058</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379153.714719 240453.305421</gml:lowerCorner>
        		<gml:upperCorner>379153.714719 240453.305421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379153.714719 240453.305421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 012 523</ms:GML_ID>
        <ms:NAZWA>279 012 523</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279012523</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385372.601000 240570.128000</gml:lowerCorner>
        		<gml:upperCorner>385372.601000 240570.128000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385372.601000 240570.128000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 057 321</ms:GML_ID>
        <ms:NAZWA>282 057 321</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282057321</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378437.030098 240743.606314</gml:lowerCorner>
        		<gml:upperCorner>378437.030098 240743.606314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378437.030098 240743.606314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 011 744</ms:GML_ID>
        <ms:NAZWA>279 011 744</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279011744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377607.817000 241015.512000</gml:lowerCorner>
        		<gml:upperCorner>377607.817000 241015.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377607.817000 241015.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 010 870</ms:GML_ID>
        <ms:NAZWA>279 010 870</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279010870</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376091.735000 241515.135000</gml:lowerCorner>
        		<gml:upperCorner>376091.735000 241515.135000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376091.735000 241515.135000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 009 275</ms:GML_ID>
        <ms:NAZWA>279 009 275</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279009275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375892.105000 241580.458000</gml:lowerCorner>
        		<gml:upperCorner>375892.105000 241580.458000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375892.105000 241580.458000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.279 009 065</ms:GML_ID>
        <ms:NAZWA>279 009 065</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>279009065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384718.425000 241859.719000</gml:lowerCorner>
        		<gml:upperCorner>384718.425000 241859.719000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384718.425000 241859.719000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 055 869</ms:GML_ID>
        <ms:NAZWA>282 055 869</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282055869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384142.542000 242995.963000</gml:lowerCorner>
        		<gml:upperCorner>384142.542000 242995.963000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384142.542000 242995.963000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 054 597</ms:GML_ID>
        <ms:NAZWA>282 054 597</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282054597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382914.316729 245704.889153</gml:lowerCorner>
        		<gml:upperCorner>382914.316729 245704.889153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382914.316729 245704.889153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.282 051 610</ms:GML_ID>
        <ms:NAZWA>282 051 610</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>282051610</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4285">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382861.907534 247226.002230</gml:lowerCorner>
        		<gml:upperCorner>382861.907534 247226.002230</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4285.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382861.907534 247226.002230</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4285</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 061 423</ms:GML_ID>
        <ms:NAZWA>283 061 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283061423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377302.113000 247641.865000</gml:lowerCorner>
        		<gml:upperCorner>377302.113000 247641.865000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377302.113000 247641.865000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 053 698</ms:GML_ID>
        <ms:NAZWA>283 053 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283053698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376989.610000 247669.947000</gml:lowerCorner>
        		<gml:upperCorner>376989.610000 247669.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376989.610000 247669.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 053 380</ms:GML_ID>
        <ms:NAZWA>283 053 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283053380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378881.799000 247701.160000</gml:lowerCorner>
        		<gml:upperCorner>378881.799000 247701.160000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378881.799000 247701.160000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.283 055 277</ms:GML_ID>
        <ms:NAZWA>283 055 277</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>283055277</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4887">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342363.301000 207312.616000</gml:lowerCorner>
        		<gml:upperCorner>342363.301000 207312.616000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4887.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342363.301000 207312.616000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4887</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.346 022 313</ms:GML_ID>
        <ms:NAZWA>346 022 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>346022313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343643.328000 207136.181000</gml:lowerCorner>
        		<gml:upperCorner>343643.328000 207136.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343643.328000 207136.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.346 023 609</ms:GML_ID>
        <ms:NAZWA>346 023 609</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>346023609</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346424.037000 215890.630000</gml:lowerCorner>
        		<gml:upperCorner>346424.037000 215890.630000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346424.037000 215890.630000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.786 032 744</ms:GML_ID>
        <ms:NAZWA>786 032 744</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>786032744</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346778.341000 215706.064000</gml:lowerCorner>
        		<gml:upperCorner>346778.341000 215706.064000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346778.341000 215706.064000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.786 032 340</ms:GML_ID>
        <ms:NAZWA>786 032 340</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>786032340</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347012.062000 215506.082000</gml:lowerCorner>
        		<gml:upperCorner>347012.062000 215506.082000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347012.062000 215506.082000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.786 032 045</ms:GML_ID>
        <ms:NAZWA>786 032 045</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>786032045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350399.073635 211754.539289</gml:lowerCorner>
        		<gml:upperCorner>350399.073635 211754.539289</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350399.073635 211754.539289</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.786 026 354</ms:GML_ID>
        <ms:NAZWA>786 026 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>786026354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356966.803000 215179.036000</gml:lowerCorner>
        		<gml:upperCorner>356966.803000 215179.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356966.803000 215179.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 018 255</ms:GML_ID>
        <ms:NAZWA>290 018 255</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290018255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357933.042197 215378.500451</gml:lowerCorner>
        		<gml:upperCorner>357933.042197 215378.500451</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357933.042197 215378.500451</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 017 273</ms:GML_ID>
        <ms:NAZWA>290 017 273</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290017273</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4885">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358304.875000 221833.660000</gml:lowerCorner>
        		<gml:upperCorner>358304.875000 221833.660000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4885.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358304.875000 221833.660000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4885</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.344 003 390</ms:GML_ID>
        <ms:NAZWA>344 003 390</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>344003390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361283.529000 221317.346000</gml:lowerCorner>
        		<gml:upperCorner>361283.529000 221317.346000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361283.529000 221317.346000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 008 282</ms:GML_ID>
        <ms:NAZWA>290 008 282</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290008282</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361773.004000 217932.468000</gml:lowerCorner>
        		<gml:upperCorner>361773.004000 217932.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361773.004000 217932.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 012 506</ms:GML_ID>
        <ms:NAZWA>290 012 506</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290012506</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361808.842000 220226.623000</gml:lowerCorner>
        		<gml:upperCorner>361808.842000 220226.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361808.842000 220226.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 009 796</ms:GML_ID>
        <ms:NAZWA>290 009 796</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290009796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362268.136000 222389.805000</gml:lowerCorner>
        		<gml:upperCorner>362268.136000 222389.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362268.136000 222389.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 006 827</ms:GML_ID>
        <ms:NAZWA>290 006 827</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290006827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363673.650000 223660.554000</gml:lowerCorner>
        		<gml:upperCorner>363673.650000 223660.554000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363673.650000 223660.554000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 004 914</ms:GML_ID>
        <ms:NAZWA>290 004 914</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290004914</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364748.694327 225127.434075</gml:lowerCorner>
        		<gml:upperCorner>364748.694327 225127.434075</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364748.694327 225127.434075</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.290 002 934</ms:GML_ID>
        <ms:NAZWA>290 002 934</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>290002934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.291">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365525.241000 233491.880000</gml:lowerCorner>
        		<gml:upperCorner>365525.241000 233491.880000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.291.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365525.241000 233491.880000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>291</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 185 890</ms:GML_ID>
        <ms:NAZWA>274 185 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274185890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.290">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365762.762716 235007.654684</gml:lowerCorner>
        		<gml:upperCorner>365762.762716 235007.654684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.290.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365762.762716 235007.654684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>290</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 184 354</ms:GML_ID>
        <ms:NAZWA>274 184 354</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274184354</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.292">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365769.988213 228199.490166</gml:lowerCorner>
        		<gml:upperCorner>365769.988213 228199.490166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.292.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365769.988213 228199.490166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>292</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 191 258</ms:GML_ID>
        <ms:NAZWA>274 191 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274191258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.293">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365974.841714 227291.341065</gml:lowerCorner>
        		<gml:upperCorner>365974.841714 227291.341065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.293.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365974.841714 227291.341065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>293</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 192 183</ms:GML_ID>
        <ms:NAZWA>274 192 183</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274192183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.289">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366005.996544 236454.555759</gml:lowerCorner>
        		<gml:upperCorner>366005.996544 236454.555759</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.289.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366005.996544 236454.555759</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>289</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 182 890</ms:GML_ID>
        <ms:NAZWA>274 182 890</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274182890</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.288">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366279.461000 237127.716000</gml:lowerCorner>
        		<gml:upperCorner>366279.461000 237127.716000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.288.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366279.461000 237127.716000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>288</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 182 150</ms:GML_ID>
        <ms:NAZWA>274 182 150</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274182150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.287">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366509.787000 237546.074000</gml:lowerCorner>
        		<gml:upperCorner>366509.787000 237546.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.287.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366509.787000 237546.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>287</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 181 682</ms:GML_ID>
        <ms:NAZWA>274 181 682</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274181682</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.286">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366750.855000 238030.491000</gml:lowerCorner>
        		<gml:upperCorner>366750.855000 238030.491000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.286.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366750.855000 238030.491000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>286</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 181 143</ms:GML_ID>
        <ms:NAZWA>274 181 143</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274181143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.294">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369502.957541 224671.284015</gml:lowerCorner>
        		<gml:upperCorner>369502.957541 224671.284015</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.294.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369502.957541 224671.284015</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>294</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 196 672</ms:GML_ID>
        <ms:NAZWA>274 196 672</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274196672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.295">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369969.420727 224179.996540</gml:lowerCorner>
        		<gml:upperCorner>369969.420727 224179.996540</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.295.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369969.420727 224179.996540</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>295</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 197 351</ms:GML_ID>
        <ms:NAZWA>274 197 351</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274197351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.296">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371122.453000 222571.033000</gml:lowerCorner>
        		<gml:upperCorner>371122.453000 222571.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.296.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371122.453000 222571.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>296</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 199 331</ms:GML_ID>
        <ms:NAZWA>274 199 331</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274199331</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.297">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371290.670237 220769.775115</gml:lowerCorner>
        		<gml:upperCorner>371290.670237 220769.775115</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.297.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371290.670237 220769.775115</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>297</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.274 201 253</ms:GML_ID>
        <ms:NAZWA>274 201 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>274201253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371339.643000 220648.527000</gml:lowerCorner>
        		<gml:upperCorner>371339.643000 220648.527000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371339.643000 220648.527000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 026 475</ms:GML_ID>
        <ms:NAZWA>278 026 475</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278026475</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371375.860000 220803.832000</gml:lowerCorner>
        		<gml:upperCorner>371375.860000 220803.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371375.860000 220803.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.278 026 319</ms:GML_ID>
        <ms:NAZWA>278 026 319</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>278026319</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444625.659000 332373.638173</gml:lowerCorner>
        		<gml:upperCorner>444625.659000 332373.638173</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444625.659000 332373.638173</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 095 449</ms:GML_ID>
        <ms:NAZWA>271 095 449</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271095449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447038.041730 332448.517916</gml:lowerCorner>
        		<gml:upperCorner>447038.041730 332448.517916</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447038.041730 332448.517916</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 233 803</ms:GML_ID>
        <ms:NAZWA>014 233 803</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014233803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445572.231791 332543.311683</gml:lowerCorner>
        		<gml:upperCorner>445572.231791 332543.311683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445572.231791 332543.311683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 096 413</ms:GML_ID>
        <ms:NAZWA>271 096 413</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271096413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448470.952398 332547.010205</gml:lowerCorner>
        		<gml:upperCorner>448470.952398 332547.010205</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448470.952398 332547.010205</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 099 306</ms:GML_ID>
        <ms:NAZWA>271 099 306</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271099306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449586.087776 332597.481843</gml:lowerCorner>
        		<gml:upperCorner>449586.087776 332597.481843</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449586.087776 332597.481843</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 100 422</ms:GML_ID>
        <ms:NAZWA>271 100 422</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271100422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443517.751000 332887.116000</gml:lowerCorner>
        		<gml:upperCorner>443517.751000 332887.116000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443517.751000 332887.116000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 094 208</ms:GML_ID>
        <ms:NAZWA>271 094 208</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271094208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452979.818133 332967.146730</gml:lowerCorner>
        		<gml:upperCorner>452979.818133 332967.146730</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452979.818133 332967.146730</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 103 839</ms:GML_ID>
        <ms:NAZWA>271 103 839</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271103839</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443157.924000 333132.208000</gml:lowerCorner>
        		<gml:upperCorner>443157.924000 333132.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443157.924000 333132.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 093 772</ms:GML_ID>
        <ms:NAZWA>271 093 772</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271093772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442954.141000 333270.436000</gml:lowerCorner>
        		<gml:upperCorner>442954.141000 333270.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442954.141000 333270.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 093 525</ms:GML_ID>
        <ms:NAZWA>271 093 525</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271093525</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455380.503000 333314.493000</gml:lowerCorner>
        		<gml:upperCorner>455380.503000 333314.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455380.503000 333314.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 106 267</ms:GML_ID>
        <ms:NAZWA>271 106 267</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271106267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447696.462000 333941.507000</gml:lowerCorner>
        		<gml:upperCorner>447696.462000 333941.507000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447696.462000 333941.507000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 231 350</ms:GML_ID>
        <ms:NAZWA>014 231 350</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014231350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447298.913340 334632.923253</gml:lowerCorner>
        		<gml:upperCorner>447298.913340 334632.923253</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447298.913340 334632.923253</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 230 530</ms:GML_ID>
        <ms:NAZWA>014 230 530</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014230530</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447000.897288 334799.437585</gml:lowerCorner>
        		<gml:upperCorner>447000.897288 334799.437585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447000.897288 334799.437585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 230 188</ms:GML_ID>
        <ms:NAZWA>014 230 188</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014230188</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446480.298000 335519.958000</gml:lowerCorner>
        		<gml:upperCorner>446480.298000 335519.958000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446480.298000 335519.958000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 229 253</ms:GML_ID>
        <ms:NAZWA>014 229 253</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014229253</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446200.119584 338306.962325</gml:lowerCorner>
        		<gml:upperCorner>446200.119584 338306.962325</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446200.119584 338306.962325</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 226 452</ms:GML_ID>
        <ms:NAZWA>014 226 452</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014226452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446029.310311 340985.131855</gml:lowerCorner>
        		<gml:upperCorner>446029.310311 340985.131855</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446029.310311 340985.131855</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 223 765</ms:GML_ID>
        <ms:NAZWA>014 223 765</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014223765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446068.210640 341732.586225</gml:lowerCorner>
        		<gml:upperCorner>446068.210640 341732.586225</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446068.210640 341732.586225</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 057 659</ms:GML_ID>
        <ms:NAZWA>360 057 659</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360057659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446090.234229 342156.145820</gml:lowerCorner>
        		<gml:upperCorner>446090.234229 342156.145820</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446090.234229 342156.145820</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 057 234</ms:GML_ID>
        <ms:NAZWA>360 057 234</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360057234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444570.611843 342982.179313</gml:lowerCorner>
        		<gml:upperCorner>444570.611843 342982.179313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444570.611843 342982.179313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 221 281</ms:GML_ID>
        <ms:NAZWA>014 221 281</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014221281</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446323.036048 343785.210640</gml:lowerCorner>
        		<gml:upperCorner>446323.036048 343785.210640</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446323.036048 343785.210640</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 055 598</ms:GML_ID>
        <ms:NAZWA>360 055 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360055598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443626.195000 344215.883000</gml:lowerCorner>
        		<gml:upperCorner>443626.195000 344215.883000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443626.195000 344215.883000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 219 730</ms:GML_ID>
        <ms:NAZWA>014 219 730</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014219730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443261.045000 344693.533000</gml:lowerCorner>
        		<gml:upperCorner>443261.045000 344693.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443261.045000 344693.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 219 125</ms:GML_ID>
        <ms:NAZWA>014 219 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014219125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443112.725000 344887.641000</gml:lowerCorner>
        		<gml:upperCorner>443112.725000 344887.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443112.725000 344887.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 218 881</ms:GML_ID>
        <ms:NAZWA>014 218 881</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014218881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442730.943206 345163.636080</gml:lowerCorner>
        		<gml:upperCorner>442730.943206 345163.636080</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442730.943206 345163.636080</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 218 402</ms:GML_ID>
        <ms:NAZWA>014 218 402</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014218402</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442261.473000 345356.102000</gml:lowerCorner>
        		<gml:upperCorner>442261.473000 345356.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442261.473000 345356.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 217 897</ms:GML_ID>
        <ms:NAZWA>014 217 897</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014217897</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446720.800981 347202.539456</gml:lowerCorner>
        		<gml:upperCorner>446720.800981 347202.539456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446720.800981 347202.539456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 052 143</ms:GML_ID>
        <ms:NAZWA>360 052 143</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360052143</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446747.989142 347499.535313</gml:lowerCorner>
        		<gml:upperCorner>446747.989142 347499.535313</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446747.989142 347499.535313</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.360 051 846</ms:GML_ID>
        <ms:NAZWA>360 051 846</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>360051846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485570.887050 320485.639432</gml:lowerCorner>
        		<gml:upperCorner>485570.887050 320485.639432</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485570.887050 320485.639432</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 064 332</ms:GML_ID>
        <ms:NAZWA>357 064 332</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357064332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485582.383240 320491.603751</gml:lowerCorner>
        		<gml:upperCorner>485582.383240 320491.603751</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485582.383240 320491.603751</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 064 343</ms:GML_ID>
        <ms:NAZWA>357 064 343</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357064343</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486776.097349 335038.709156</gml:lowerCorner>
        		<gml:upperCorner>486776.097349 335038.709156</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486776.097349 335038.709156</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 084 425</ms:GML_ID>
        <ms:NAZWA>357 084 425</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357084425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486776.690945 335023.488949</gml:lowerCorner>
        		<gml:upperCorner>486776.690945 335023.488949</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486776.690945 335023.488949</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 084 405</ms:GML_ID>
        <ms:NAZWA>357 084 405</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357084405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486836.523000 334539.996000</gml:lowerCorner>
        		<gml:upperCorner>486836.523000 334539.996000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486836.523000 334539.996000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 083 916</ms:GML_ID>
        <ms:NAZWA>357 083 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357083916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>486924.670000 333877.349000</gml:lowerCorner>
        		<gml:upperCorner>486924.670000 333877.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>486924.670000 333877.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 083 248</ms:GML_ID>
        <ms:NAZWA>357 083 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357083248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487031.799000 333074.363000</gml:lowerCorner>
        		<gml:upperCorner>487031.799000 333074.363000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487031.799000 333074.363000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 082 438</ms:GML_ID>
        <ms:NAZWA>357 082 438</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357082438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487063.137000 332840.316000</gml:lowerCorner>
        		<gml:upperCorner>487063.137000 332840.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487063.137000 332840.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 082 206</ms:GML_ID>
        <ms:NAZWA>357 082 206</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357082206</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487070.904287 321177.667884</gml:lowerCorner>
        		<gml:upperCorner>487070.904287 321177.667884</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487070.904287 321177.667884</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 065 998</ms:GML_ID>
        <ms:NAZWA>357 065 998</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357065998</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487119.086000 332421.295000</gml:lowerCorner>
        		<gml:upperCorner>487119.086000 332421.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487119.086000 332421.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 081 779</ms:GML_ID>
        <ms:NAZWA>357 081 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357081779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3258">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487194.534000 331856.072000</gml:lowerCorner>
        		<gml:upperCorner>487194.534000 331856.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3258.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487194.534000 331856.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3258</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 081 208</ms:GML_ID>
        <ms:NAZWA>357 081 208</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357081208</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487272.499533 321171.232734</gml:lowerCorner>
        		<gml:upperCorner>487272.499533 321171.232734</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487272.499533 321171.232734</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 066 193</ms:GML_ID>
        <ms:NAZWA>357 066 193</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357066193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487283.068000 331192.941000</gml:lowerCorner>
        		<gml:upperCorner>487283.068000 331192.941000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487283.068000 331192.941000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 080 539</ms:GML_ID>
        <ms:NAZWA>357 080 539</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357080539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487283.653799 321169.508586</gml:lowerCorner>
        		<gml:upperCorner>487283.653799 321169.508586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487283.653799 321169.508586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 066 205</ms:GML_ID>
        <ms:NAZWA>357 066 205</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357066205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3256">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487495.803000 329594.132000</gml:lowerCorner>
        		<gml:upperCorner>487495.803000 329594.132000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3256.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487495.803000 329594.132000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3256</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 078 925</ms:GML_ID>
        <ms:NAZWA>357 078 925</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357078925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487562.075000 329091.380000</gml:lowerCorner>
        		<gml:upperCorner>487562.075000 329091.380000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487562.075000 329091.380000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 078 417</ms:GML_ID>
        <ms:NAZWA>357 078 417</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357078417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487670.844625 328272.132954</gml:lowerCorner>
        		<gml:upperCorner>487670.844625 328272.132954</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487670.844625 328272.132954</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 077 591</ms:GML_ID>
        <ms:NAZWA>357 077 591</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357077591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>487672.410109 328259.833841</gml:lowerCorner>
        		<gml:upperCorner>487672.410109 328259.833841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>487672.410109 328259.833841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 077 580</ms:GML_ID>
        <ms:NAZWA>357 077 580</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357077580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441679.686822 325904.478519</gml:lowerCorner>
        		<gml:upperCorner>441679.686822 325904.478519</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441679.686822 325904.478519</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 243 668</ms:GML_ID>
        <ms:NAZWA>014 243 668</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014243668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441814.258068 326638.365446</gml:lowerCorner>
        		<gml:upperCorner>441814.258068 326638.365446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441814.258068 326638.365446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 242 912</ms:GML_ID>
        <ms:NAZWA>014 242 912</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014242912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442047.925747 328024.169392</gml:lowerCorner>
        		<gml:upperCorner>442047.925747 328024.169392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442047.925747 328024.169392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 241 503</ms:GML_ID>
        <ms:NAZWA>014 241 503</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014241503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442593.915909 330576.065663</gml:lowerCorner>
        		<gml:upperCorner>442593.915909 330576.065663</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442593.915909 330576.065663</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 238 882</ms:GML_ID>
        <ms:NAZWA>014 238 882</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014238882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443016.522000 331046.158000</gml:lowerCorner>
        		<gml:upperCorner>443016.522000 331046.158000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443016.522000 331046.158000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 238 244</ms:GML_ID>
        <ms:NAZWA>014 238 244</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014238244</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443556.266007 331540.128292</gml:lowerCorner>
        		<gml:upperCorner>443556.266007 331540.128292</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443556.266007 331540.128292</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 237 516</ms:GML_ID>
        <ms:NAZWA>014 237 516</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014237516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444047.912886 331935.117901</gml:lowerCorner>
        		<gml:upperCorner>444047.912886 331935.117901</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444047.912886 331935.117901</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 236 878</ms:GML_ID>
        <ms:NAZWA>014 236 878</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014236878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444671.086928 332209.036646</gml:lowerCorner>
        		<gml:upperCorner>444671.086928 332209.036646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444671.086928 332209.036646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 236 200</ms:GML_ID>
        <ms:NAZWA>014 236 200</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014236200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447826.459000 332063.453000</gml:lowerCorner>
        		<gml:upperCorner>447826.459000 332063.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447826.459000 332063.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 002 948</ms:GML_ID>
        <ms:NAZWA>359 002 948</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359002948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448259.074788 331801.811524</gml:lowerCorner>
        		<gml:upperCorner>448259.074788 331801.811524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448259.074788 331801.811524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 003 453</ms:GML_ID>
        <ms:NAZWA>359 003 453</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359003453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448885.908000 331421.472000</gml:lowerCorner>
        		<gml:upperCorner>448885.908000 331421.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448885.908000 331421.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 004 187</ms:GML_ID>
        <ms:NAZWA>359 004 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359004187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449701.280000 330724.173000</gml:lowerCorner>
        		<gml:upperCorner>449701.280000 330724.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449701.280000 330724.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 005 261</ms:GML_ID>
        <ms:NAZWA>359 005 261</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359005261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450288.226000 329073.355000</gml:lowerCorner>
        		<gml:upperCorner>450288.226000 329073.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450288.226000 329073.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 007 022</ms:GML_ID>
        <ms:NAZWA>359 007 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359007022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451162.868000 326148.065000</gml:lowerCorner>
        		<gml:upperCorner>451162.868000 326148.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451162.868000 326148.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 010 078</ms:GML_ID>
        <ms:NAZWA>359 010 078</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359010078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>451818.163000 324675.566000</gml:lowerCorner>
        		<gml:upperCorner>451818.163000 324675.566000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>451818.163000 324675.566000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 011 707</ms:GML_ID>
        <ms:NAZWA>359 011 707</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359011707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452107.325000 324234.817000</gml:lowerCorner>
        		<gml:upperCorner>452107.325000 324234.817000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452107.325000 324234.817000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 012 239</ms:GML_ID>
        <ms:NAZWA>359 012 239</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359012239</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3350">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452234.830000 324039.181000</gml:lowerCorner>
        		<gml:upperCorner>452234.830000 324039.181000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3350.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452234.830000 324039.181000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3350</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 012 478</ms:GML_ID>
        <ms:NAZWA>359 012 478</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359012478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3351">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453094.702000 322731.898000</gml:lowerCorner>
        		<gml:upperCorner>453094.702000 322731.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3351.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453094.702000 322731.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3351</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 014 037</ms:GML_ID>
        <ms:NAZWA>359 014 037</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359014037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3352">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453716.240000 321667.391000</gml:lowerCorner>
        		<gml:upperCorner>453716.240000 321667.391000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3352.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453716.240000 321667.391000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3352</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 015 276</ms:GML_ID>
        <ms:NAZWA>359 015 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359015276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3353">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454256.916000 320346.659000</gml:lowerCorner>
        		<gml:upperCorner>454256.916000 320346.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3353.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454256.916000 320346.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3353</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 016 708</ms:GML_ID>
        <ms:NAZWA>359 016 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359016708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3354">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454672.962000 319919.446000</gml:lowerCorner>
        		<gml:upperCorner>454672.962000 319919.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3354.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454672.962000 319919.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3354</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 017 306</ms:GML_ID>
        <ms:NAZWA>359 017 306</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359017306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455214.293371 319375.504960</gml:lowerCorner>
        		<gml:upperCorner>455214.293371 319375.504960</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455214.293371 319375.504960</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 018 071</ms:GML_ID>
        <ms:NAZWA>359 018 071</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359018071</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>455547.278000 319028.118000</gml:lowerCorner>
        		<gml:upperCorner>455547.278000 319028.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>455547.278000 319028.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 018 555</ms:GML_ID>
        <ms:NAZWA>359 018 555</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359018555</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440200.555969 317385.314549</gml:lowerCorner>
        		<gml:upperCorner>440200.555969 317385.314549</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440200.555969 317385.314549</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 252 304</ms:GML_ID>
        <ms:NAZWA>014 252 304</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014252304</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440424.258000 318680.410000</gml:lowerCorner>
        		<gml:upperCorner>440424.258000 318680.410000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440424.258000 318680.410000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 250 989</ms:GML_ID>
        <ms:NAZWA>014 250 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014250989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440509.290038 319168.586225</gml:lowerCorner>
        		<gml:upperCorner>440509.290038 319168.586225</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440509.290038 319168.586225</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 250 494</ms:GML_ID>
        <ms:NAZWA>014 250 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014250494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441148.221913 322846.859357</gml:lowerCorner>
        		<gml:upperCorner>441148.221913 322846.859357</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441148.221913 322846.859357</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 246 759</ms:GML_ID>
        <ms:NAZWA>014 246 759</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014246759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441341.818000 323959.686000</gml:lowerCorner>
        		<gml:upperCorner>441341.818000 323959.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441341.818000 323959.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 245 630</ms:GML_ID>
        <ms:NAZWA>014 245 630</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014245630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>441391.844820 324248.600415</gml:lowerCorner>
        		<gml:upperCorner>441391.844820 324248.600415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>441391.844820 324248.600415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 245 338</ms:GML_ID>
        <ms:NAZWA>014 245 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014245338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438610.827000 336226.112000</gml:lowerCorner>
        		<gml:upperCorner>438610.827000 336226.112000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438610.827000 336226.112000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 088 267</ms:GML_ID>
        <ms:NAZWA>271 088 267</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271088267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436599.332000 337595.122000</gml:lowerCorner>
        		<gml:upperCorner>436599.332000 337595.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436599.332000 337595.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 085 837</ms:GML_ID>
        <ms:NAZWA>271 085 837</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271085837</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433344.683000 339853.840000</gml:lowerCorner>
        		<gml:upperCorner>433344.683000 339853.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433344.683000 339853.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 081 874</ms:GML_ID>
        <ms:NAZWA>271 081 874</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271081874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428623.641404 343976.098296</gml:lowerCorner>
        		<gml:upperCorner>428623.641404 343976.098296</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428623.641404 343976.098296</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 075 607</ms:GML_ID>
        <ms:NAZWA>271 075 607</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271075607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440586.114000 346040.506000</gml:lowerCorner>
        		<gml:upperCorner>440586.114000 346040.506000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440586.114000 346040.506000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 216 087</ms:GML_ID>
        <ms:NAZWA>014 216 087</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014216087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438663.666000 346828.001000</gml:lowerCorner>
        		<gml:upperCorner>438663.666000 346828.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438663.666000 346828.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 214 011</ms:GML_ID>
        <ms:NAZWA>014 214 011</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014214011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423416.322000 347814.150000</gml:lowerCorner>
        		<gml:upperCorner>423416.322000 347814.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423416.322000 347814.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 069 128</ms:GML_ID>
        <ms:NAZWA>271 069 128</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271069128</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7833">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435749.637000 347820.976000</gml:lowerCorner>
        		<gml:upperCorner>435749.637000 347820.976000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7833.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435749.637000 347820.976000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7833</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 210 918</ms:GML_ID>
        <ms:NAZWA>014 210 918</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014210918</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7832">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435321.788000 348124.420000</gml:lowerCorner>
        		<gml:upperCorner>435321.788000 348124.420000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7832.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435321.788000 348124.420000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7832</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 210 380</ms:GML_ID>
        <ms:NAZWA>014 210 380</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014210380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7831">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435186.642440 348462.456883</gml:lowerCorner>
        		<gml:upperCorner>435186.642440 348462.456883</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7831.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435186.642440 348462.456883</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7831</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 210 013</ms:GML_ID>
        <ms:NAZWA>014 210 013</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014210013</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7830">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434840.009606 349415.403811</gml:lowerCorner>
        		<gml:upperCorner>434840.009606 349415.403811</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7830.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434840.009606 349415.403811</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7830</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 209 002</ms:GML_ID>
        <ms:NAZWA>014 209 002</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014209002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7829">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434685.590000 350381.679000</gml:lowerCorner>
        		<gml:upperCorner>434685.590000 350381.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7829.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434685.590000 350381.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7829</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 208 018</ms:GML_ID>
        <ms:NAZWA>014 208 018</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014208018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7828">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434589.644000 351193.972000</gml:lowerCorner>
        		<gml:upperCorner>434589.644000 351193.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7828.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434589.644000 351193.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7828</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 207 200</ms:GML_ID>
        <ms:NAZWA>014 207 200</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014207200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7827">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434505.491000 351904.148000</gml:lowerCorner>
        		<gml:upperCorner>434505.491000 351904.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7827.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434505.491000 351904.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7827</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 206 484</ms:GML_ID>
        <ms:NAZWA>014 206 484</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014206484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7826">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434128.992000 355084.774000</gml:lowerCorner>
        		<gml:upperCorner>434128.992000 355084.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7826.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434128.992000 355084.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7826</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 203 283</ms:GML_ID>
        <ms:NAZWA>014 203 283</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014203283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7825">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434118.798000 355347.264000</gml:lowerCorner>
        		<gml:upperCorner>434118.798000 355347.264000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7825.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434118.798000 355347.264000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7825</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 203 017</ms:GML_ID>
        <ms:NAZWA>014 203 017</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014203017</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7824">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434235.032000 356416.356000</gml:lowerCorner>
        		<gml:upperCorner>434235.032000 356416.356000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7824.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434235.032000 356416.356000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7824</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 201 940</ms:GML_ID>
        <ms:NAZWA>014 201 940</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014201940</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7823">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434266.062000 356683.057000</gml:lowerCorner>
        		<gml:upperCorner>434266.062000 356683.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7823.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434266.062000 356683.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7823</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 201 673</ms:GML_ID>
        <ms:NAZWA>014 201 673</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014201673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421218.497000 357157.814000</gml:lowerCorner>
        		<gml:upperCorner>421218.497000 357157.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421218.497000 357157.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 024 280</ms:GML_ID>
        <ms:NAZWA>362 024 280</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362024280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7822">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434336.442000 357282.325000</gml:lowerCorner>
        		<gml:upperCorner>434336.442000 357282.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7822.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434336.442000 357282.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7822</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 201 069</ms:GML_ID>
        <ms:NAZWA>014 201 069</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014201069</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421484.898000 357481.887000</gml:lowerCorner>
        		<gml:upperCorner>421484.898000 357481.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421484.898000 357481.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 023 869</ms:GML_ID>
        <ms:NAZWA>362 023 869</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362023869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421588.349000 357607.556000</gml:lowerCorner>
        		<gml:upperCorner>421588.349000 357607.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421588.349000 357607.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 023 708</ms:GML_ID>
        <ms:NAZWA>362 023 708</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362023708</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422005.764987 357790.761835</gml:lowerCorner>
        		<gml:upperCorner>422005.764987 357790.761835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422005.764987 357790.761835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 023 421</ms:GML_ID>
        <ms:NAZWA>362 023 421</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362023421</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421756.065000 357811.712000</gml:lowerCorner>
        		<gml:upperCorner>421756.065000 357811.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421756.065000 357811.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.362 023 444</ms:GML_ID>
        <ms:NAZWA>362 023 444</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>362023444</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7821">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434469.660000 358424.613000</gml:lowerCorner>
        		<gml:upperCorner>434469.660000 358424.613000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7821.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434469.660000 358424.613000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7821</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 199 917</ms:GML_ID>
        <ms:NAZWA>014 199 917</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014199917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>480769.537089 316045.954263</gml:lowerCorner>
        		<gml:upperCorner>480769.537089 316045.954263</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>480769.537089 316045.954263</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 057 572</ms:GML_ID>
        <ms:NAZWA>357 057 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357057572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459548.035000 316086.552000</gml:lowerCorner>
        		<gml:upperCorner>459548.035000 316086.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459548.035000 316086.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 023 550</ms:GML_ID>
        <ms:NAZWA>359 023 550</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359023550</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>458250.285191 317029.542683</gml:lowerCorner>
        		<gml:upperCorner>458250.285191 317029.542683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>458250.285191 317029.542683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 021 945</ms:GML_ID>
        <ms:NAZWA>359 021 945</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359021945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481319.419000 317104.464000</gml:lowerCorner>
        		<gml:upperCorner>481319.419000 317104.464000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481319.419000 317104.464000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 058 801</ms:GML_ID>
        <ms:NAZWA>357 058 801</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357058801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>481740.575000 317596.901000</gml:lowerCorner>
        		<gml:upperCorner>481740.575000 317596.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>481740.575000 317596.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 059 450</ms:GML_ID>
        <ms:NAZWA>357 059 450</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357059450</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>482409.695000 318380.344000</gml:lowerCorner>
        		<gml:upperCorner>482409.695000 318380.344000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>482409.695000 318380.344000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 060 481</ms:GML_ID>
        <ms:NAZWA>357 060 481</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357060481</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>483284.941000 319295.887000</gml:lowerCorner>
        		<gml:upperCorner>483284.941000 319295.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>483284.941000 319295.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 061 752</ms:GML_ID>
        <ms:NAZWA>357 061 752</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357061752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484335.370802 319851.471501</gml:lowerCorner>
        		<gml:upperCorner>484335.370802 319851.471501</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484335.370802 319851.471501</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 062 941</ms:GML_ID>
        <ms:NAZWA>357 062 941</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357062941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456996.115000 333548.575000</gml:lowerCorner>
        		<gml:upperCorner>456996.115000 333548.575000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456996.115000 333548.575000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 107 899</ms:GML_ID>
        <ms:NAZWA>271 107 899</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271107899</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>460072.207000 333992.289000</gml:lowerCorner>
        		<gml:upperCorner>460072.207000 333992.289000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>460072.207000 333992.289000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 111 008</ms:GML_ID>
        <ms:NAZWA>271 111 008</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271111008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462205.892000 334371.987000</gml:lowerCorner>
        		<gml:upperCorner>462205.892000 334371.987000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462205.892000 334371.987000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 113 176</ms:GML_ID>
        <ms:NAZWA>271 113 176</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271113176</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465017.042046 335399.380931</gml:lowerCorner>
        		<gml:upperCorner>465017.042046 335399.380931</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465017.042046 335399.380931</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 116 193</ms:GML_ID>
        <ms:NAZWA>271 116 193</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271116193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466163.066881 335768.832992</gml:lowerCorner>
        		<gml:upperCorner>466163.066881 335768.832992</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466163.066881 335768.832992</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 117 388</ms:GML_ID>
        <ms:NAZWA>271 117 388</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271117388</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3642">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471439.790000 339416.823000</gml:lowerCorner>
        		<gml:upperCorner>471439.790000 339416.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3642.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471439.790000 339416.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3642</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.366 074 332</ms:GML_ID>
        <ms:NAZWA>366 074 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>366074332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3641">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471219.342000 339624.102000</gml:lowerCorner>
        		<gml:upperCorner>471219.342000 339624.102000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3641.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471219.342000 339624.102000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3641</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.366 074 010</ms:GML_ID>
        <ms:NAZWA>366 074 010</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>366074010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3640">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471023.059000 339742.011000</gml:lowerCorner>
        		<gml:upperCorner>471023.059000 339742.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3640.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471023.059000 339742.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3640</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.366 073 771</ms:GML_ID>
        <ms:NAZWA>366 073 771</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>366073771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3639">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470660.092000 340256.425000</gml:lowerCorner>
        		<gml:upperCorner>470660.092000 340256.425000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3639.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470660.092000 340256.425000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3639</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.366 073 140</ms:GML_ID>
        <ms:NAZWA>366 073 140</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>366073140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470403.141000 340623.741000</gml:lowerCorner>
        		<gml:upperCorner>470403.141000 340623.741000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470403.141000 340623.741000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.366 072 692</ms:GML_ID>
        <ms:NAZWA>366 072 692</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>366072692</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>473385.788000 341720.513000</gml:lowerCorner>
        		<gml:upperCorner>473385.788000 341720.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>473385.788000 341720.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 126 921</ms:GML_ID>
        <ms:NAZWA>271 126 921</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271126921</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.676">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474011.701000 342545.337000</gml:lowerCorner>
        		<gml:upperCorner>474011.701000 342545.337000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.676.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474011.701000 342545.337000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>676</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 127 956</ms:GML_ID>
        <ms:NAZWA>271 127 956</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271127956</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.677">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475119.705054 344006.286415</gml:lowerCorner>
        		<gml:upperCorner>475119.705054 344006.286415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.677.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475119.705054 344006.286415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>677</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 129 791</ms:GML_ID>
        <ms:NAZWA>271 129 791</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271129791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.678">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476256.057810 345501.617611</gml:lowerCorner>
        		<gml:upperCorner>476256.057810 345501.617611</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.678.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476256.057810 345501.617611</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>678</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 131 670</ms:GML_ID>
        <ms:NAZWA>271 131 670</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271131670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.680">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>476688.476378 346064.552218</gml:lowerCorner>
        		<gml:upperCorner>476688.476378 346064.552218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.680.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>476688.476378 346064.552218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>680</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 132 341</ms:GML_ID>
        <ms:NAZWA>271 132 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271132341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.681">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477516.290178 346521.871879</gml:lowerCorner>
        		<gml:upperCorner>477516.290178 346521.871879</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.681.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477516.290178 346521.871879</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>681</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 133 293</ms:GML_ID>
        <ms:NAZWA>271 133 293</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271133293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.682">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477684.633356 346640.445396</gml:lowerCorner>
        		<gml:upperCorner>477684.633356 346640.445396</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.682.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477684.633356 346640.445396</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>682</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.271 133 501</ms:GML_ID>
        <ms:NAZWA>271 133 501</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>271133501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>472216.781000 304222.435000</gml:lowerCorner>
        		<gml:upperCorner>472216.781000 304222.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>472216.781000 304222.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 041 992</ms:GML_ID>
        <ms:NAZWA>359 041 992</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359041992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471478.029000 304669.902000</gml:lowerCorner>
        		<gml:upperCorner>471478.029000 304669.902000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471478.029000 304669.902000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 041 126</ms:GML_ID>
        <ms:NAZWA>359 041 126</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359041126</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>471231.861000 304818.149000</gml:lowerCorner>
        		<gml:upperCorner>471231.861000 304818.149000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>471231.861000 304818.149000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 040 840</ms:GML_ID>
        <ms:NAZWA>359 040 840</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359040840</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3217">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474390.857208 304888.827954</gml:lowerCorner>
        		<gml:upperCorner>474390.857208 304888.827954</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3217.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474390.857208 304888.827954</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3217</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 043 107</ms:GML_ID>
        <ms:NAZWA>357 043 107</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357043107</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3218">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474614.284072 305150.043278</gml:lowerCorner>
        		<gml:upperCorner>474614.284072 305150.043278</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3218.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474614.284072 305150.043278</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3218</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 043 446</ms:GML_ID>
        <ms:NAZWA>357 043 446</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357043446</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3219">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>474849.699000 305424.796000</gml:lowerCorner>
        		<gml:upperCorner>474849.699000 305424.796000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3219.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>474849.699000 305424.796000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3219</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 043 808</ms:GML_ID>
        <ms:NAZWA>357 043 808</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357043808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>470190.039000 305449.481000</gml:lowerCorner>
        		<gml:upperCorner>470190.039000 305449.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>470190.039000 305449.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 039 622</ms:GML_ID>
        <ms:NAZWA>359 039 622</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359039622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469908.728000 305619.653000</gml:lowerCorner>
        		<gml:upperCorner>469908.728000 305619.653000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469908.728000 305619.653000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 039 293</ms:GML_ID>
        <ms:NAZWA>359 039 293</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359039293</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3220">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>475757.582000 306373.057000</gml:lowerCorner>
        		<gml:upperCorner>475757.582000 306373.057000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3220.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>475757.582000 306373.057000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3220</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 045 131</ms:GML_ID>
        <ms:NAZWA>357 045 131</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357045131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3221">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477658.487421 306912.468816</gml:lowerCorner>
        		<gml:upperCorner>477658.487421 306912.468816</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3221.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477658.487421 306912.468816</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3221</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 047 106</ms:GML_ID>
        <ms:NAZWA>357 047 106</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357047106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3222">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477666.570280 306914.753897</gml:lowerCorner>
        		<gml:upperCorner>477666.570280 306914.753897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3222.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477666.570280 306914.753897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3222</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 047 120</ms:GML_ID>
        <ms:NAZWA>357 047 120</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357047120</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3223">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478155.921000 307977.579000</gml:lowerCorner>
        		<gml:upperCorner>478155.921000 307977.579000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3223.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478155.921000 307977.579000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3223</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 048 424</ms:GML_ID>
        <ms:NAZWA>357 048 424</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357048424</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3224">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478052.821000 309865.688000</gml:lowerCorner>
        		<gml:upperCorner>478052.821000 309865.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3224.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478052.821000 309865.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3224</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 050 342</ms:GML_ID>
        <ms:NAZWA>357 050 342</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357050342</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3225">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>477882.377000 312024.245000</gml:lowerCorner>
        		<gml:upperCorner>477882.377000 312024.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3225.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>477882.377000 312024.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3225</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 052 511</ms:GML_ID>
        <ms:NAZWA>357 052 511</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357052511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478363.515000 313081.488000</gml:lowerCorner>
        		<gml:upperCorner>478363.515000 313081.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478363.515000 313081.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 053 683</ms:GML_ID>
        <ms:NAZWA>357 053 683</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357053683</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478494.201000 313240.809000</gml:lowerCorner>
        		<gml:upperCorner>478494.201000 313240.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478494.201000 313240.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 053 888</ms:GML_ID>
        <ms:NAZWA>357 053 888</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357053888</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478721.309000 313557.824000</gml:lowerCorner>
        		<gml:upperCorner>478721.309000 313557.824000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478721.309000 313557.824000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 054 283</ms:GML_ID>
        <ms:NAZWA>357 054 283</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357054283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>478880.240000 313843.351000</gml:lowerCorner>
        		<gml:upperCorner>478880.240000 313843.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>478880.240000 313843.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 054 607</ms:GML_ID>
        <ms:NAZWA>357 054 607</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357054607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>479309.854000 314277.931000</gml:lowerCorner>
        		<gml:upperCorner>479309.854000 314277.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>479309.854000 314277.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.357 055 220</ms:GML_ID>
        <ms:NAZWA>357 055 220</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>357055220</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>461560.569331 314724.063077</gml:lowerCorner>
        		<gml:upperCorner>461560.569331 314724.063077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>461560.569331 314724.063077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 025 995</ms:GML_ID>
        <ms:NAZWA>359 025 995</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359025995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462165.038638 314714.169339</gml:lowerCorner>
        		<gml:upperCorner>462165.038638 314714.169339</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462165.038638 314714.169339</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 026 596</ms:GML_ID>
        <ms:NAZWA>359 026 596</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359026596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462369.910000 314653.834000</gml:lowerCorner>
        		<gml:upperCorner>462369.910000 314653.834000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462369.910000 314653.834000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 026 819</ms:GML_ID>
        <ms:NAZWA>359 026 819</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359026819</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463273.749000 312580.325000</gml:lowerCorner>
        		<gml:upperCorner>463273.749000 312580.325000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463273.749000 312580.325000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 029 105</ms:GML_ID>
        <ms:NAZWA>359 029 105</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359029105</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463575.939000 312063.130000</gml:lowerCorner>
        		<gml:upperCorner>463575.939000 312063.130000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463575.939000 312063.130000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 029 696</ms:GML_ID>
        <ms:NAZWA>359 029 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359029696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463829.222000 311537.857000</gml:lowerCorner>
        		<gml:upperCorner>463829.222000 311537.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463829.222000 311537.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 030 287</ms:GML_ID>
        <ms:NAZWA>359 030 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359030287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463948.978000 311144.888000</gml:lowerCorner>
        		<gml:upperCorner>463948.978000 311144.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463948.978000 311144.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 030 693</ms:GML_ID>
        <ms:NAZWA>359 030 693</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359030693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464254.215912 310138.808370</gml:lowerCorner>
        		<gml:upperCorner>464254.215912 310138.808370</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464254.215912 310138.808370</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 031 750</ms:GML_ID>
        <ms:NAZWA>359 031 750</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359031750</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464472.668497 309438.433545</gml:lowerCorner>
        		<gml:upperCorner>464472.668497 309438.433545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464472.668497 309438.433545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 032 488</ms:GML_ID>
        <ms:NAZWA>359 032 488</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359032488</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>464697.365979 308784.726067</gml:lowerCorner>
        		<gml:upperCorner>464697.365979 308784.726067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>464697.365979 308784.726067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 033 177</ms:GML_ID>
        <ms:NAZWA>359 033 177</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359033177</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>465841.089000 307997.442000</gml:lowerCorner>
        		<gml:upperCorner>465841.089000 307997.442000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>465841.089000 307997.442000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 034 578</ms:GML_ID>
        <ms:NAZWA>359 034 578</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359034578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466485.370000 307604.731000</gml:lowerCorner>
        		<gml:upperCorner>466485.370000 307604.731000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466485.370000 307604.731000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 035 325</ms:GML_ID>
        <ms:NAZWA>359 035 325</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359035325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468362.855000 306496.125000</gml:lowerCorner>
        		<gml:upperCorner>468362.855000 306496.125000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468362.855000 306496.125000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.359 037 515</ms:GML_ID>
        <ms:NAZWA>359 037 515</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>359037515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>468527.194000 300232.519000</gml:lowerCorner>
        		<gml:upperCorner>468527.194000 300232.519000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>468527.194000 300232.519000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 008 622</ms:GML_ID>
        <ms:NAZWA>371 008 622</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371008622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469002.199000 300554.687000</gml:lowerCorner>
        		<gml:upperCorner>469002.199000 300554.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469002.199000 300554.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 008 090</ms:GML_ID>
        <ms:NAZWA>371 008 090</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371008090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469201.790000 300684.679000</gml:lowerCorner>
        		<gml:upperCorner>469201.790000 300684.679000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469201.790000 300684.679000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 007 850</ms:GML_ID>
        <ms:NAZWA>371 007 850</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371007850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469468.838000 300858.308000</gml:lowerCorner>
        		<gml:upperCorner>469468.838000 300858.308000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469468.838000 300858.308000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 007 531</ms:GML_ID>
        <ms:NAZWA>371 007 531</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371007531</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469762.917000 301048.306000</gml:lowerCorner>
        		<gml:upperCorner>469762.917000 301048.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469762.917000 301048.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.371 007 181</ms:GML_ID>
        <ms:NAZWA>371 007 181</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>371007181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402278.015433 316492.346807</gml:lowerCorner>
        		<gml:upperCorner>402278.015433 316492.346807</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402278.015433 316492.346807</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 065 726</ms:GML_ID>
        <ms:NAZWA>273 065 726</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273065726</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404394.125185 307524.880258</gml:lowerCorner>
        		<gml:upperCorner>404394.125185 307524.880258</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404394.125185 307524.880258</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 031 645</ms:GML_ID>
        <ms:NAZWA>289 031 645</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289031645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>407376.766000 310086.497000</gml:lowerCorner>
        		<gml:upperCorner>407376.766000 310086.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>407376.766000 310086.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.289 035 596</ms:GML_ID>
        <ms:NAZWA>289 035 596</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>289035596</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414593.065000 307780.396000</gml:lowerCorner>
        		<gml:upperCorner>414593.065000 307780.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414593.065000 307780.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 083 284</ms:GML_ID>
        <ms:NAZWA>273 083 284</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273083284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417024.468000 305698.205000</gml:lowerCorner>
        		<gml:upperCorner>417024.468000 305698.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417024.468000 305698.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 086 511</ms:GML_ID>
        <ms:NAZWA>273 086 511</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273086511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417683.443868 305209.316090</gml:lowerCorner>
        		<gml:upperCorner>417683.443868 305209.316090</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417683.443868 305209.316090</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 087 332</ms:GML_ID>
        <ms:NAZWA>273 087 332</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273087332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418554.945562 304567.727485</gml:lowerCorner>
        		<gml:upperCorner>418554.945562 304567.727485</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418554.945562 304567.727485</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 088 417</ms:GML_ID>
        <ms:NAZWA>273 088 417</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273088417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.877">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419200.681405 304080.113345</gml:lowerCorner>
        		<gml:upperCorner>419200.681405 304080.113345</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.877.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419200.681405 304080.113345</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>877</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 089 221</ms:GML_ID>
        <ms:NAZWA>273 089 221</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273089221</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.878">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419789.073000 303659.032000</gml:lowerCorner>
        		<gml:upperCorner>419789.073000 303659.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.878.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419789.073000 303659.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>878</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 089 943</ms:GML_ID>
        <ms:NAZWA>273 089 943</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273089943</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.879">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421742.315000 303062.407000</gml:lowerCorner>
        		<gml:upperCorner>421742.315000 303062.407000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.879.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421742.315000 303062.407000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>879</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 091 990</ms:GML_ID>
        <ms:NAZWA>273 091 990</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273091990</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.880">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422621.159554 302555.651391</gml:lowerCorner>
        		<gml:upperCorner>422621.159554 302555.651391</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.880.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422621.159554 302555.651391</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>880</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 093 015</ms:GML_ID>
        <ms:NAZWA>273 093 015</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273093015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423623.235382 301813.238758</gml:lowerCorner>
        		<gml:upperCorner>423623.235382 301813.238758</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423623.235382 301813.238758</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 094 257</ms:GML_ID>
        <ms:NAZWA>273 094 257</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273094257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424388.629809 301160.973325</gml:lowerCorner>
        		<gml:upperCorner>424388.629809 301160.973325</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424388.629809 301160.973325</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 095 268</ms:GML_ID>
        <ms:NAZWA>273 095 268</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273095268</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424842.166599 300730.497816</gml:lowerCorner>
        		<gml:upperCorner>424842.166599 300730.497816</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424842.166599 300730.497816</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.273 095 893</ms:GML_ID>
        <ms:NAZWA>273 095 893</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>273095893</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433673.427000 299214.349000</gml:lowerCorner>
        		<gml:upperCorner>433673.427000 299214.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433673.427000 299214.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 271 966</ms:GML_ID>
        <ms:NAZWA>014 271 966</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014271966</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433907.997744 299593.396527</gml:lowerCorner>
        		<gml:upperCorner>433907.997744 299593.396527</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433907.997744 299593.396527</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 271 524</ms:GML_ID>
        <ms:NAZWA>014 271 524</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>014271524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438042.849050 306341.808513</gml:lowerCorner>
        		<gml:upperCorner>438042.849050 306341.808513</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438042.849050 306341.808513</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 263 599</ms:GML_ID>
        <ms:NAZWA>014 263 599</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014263599</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438502.241666 307266.323417</gml:lowerCorner>
        		<gml:upperCorner>438502.241666 307266.323417</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438502.241666 307266.323417</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 262 569</ms:GML_ID>
        <ms:NAZWA>014 262 569</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014262569</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438565.148000 307553.730000</gml:lowerCorner>
        		<gml:upperCorner>438565.148000 307553.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438565.148000 307553.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 262 276</ms:GML_ID>
        <ms:NAZWA>014 262 276</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014262276</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438678.075000 308232.305000</gml:lowerCorner>
        		<gml:upperCorner>438678.075000 308232.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438678.075000 308232.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 261 586</ms:GML_ID>
        <ms:NAZWA>014 261 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014261586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438793.246000 308925.171000</gml:lowerCorner>
        		<gml:upperCorner>438793.246000 308925.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438793.246000 308925.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 260 894</ms:GML_ID>
        <ms:NAZWA>014 260 894</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014260894</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438980.420537 310048.952048</gml:lowerCorner>
        		<gml:upperCorner>438980.420537 310048.952048</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438980.420537 310048.952048</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 259 743</ms:GML_ID>
        <ms:NAZWA>014 259 743</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014259743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439027.870374 310333.842753</gml:lowerCorner>
        		<gml:upperCorner>439027.870374 310333.842753</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439027.870374 310333.842753</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 259 454</ms:GML_ID>
        <ms:NAZWA>014 259 454</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014259454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

