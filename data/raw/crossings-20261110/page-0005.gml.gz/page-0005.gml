<?xml version='1.0' encoding="UTF-8" ?>
<wfs:FeatureCollection
   xmlns:ms="http://mapserver.gis.umn.edu/mapserver"
   xmlns:gml="http://www.opengis.net/gml/3.2"
   xmlns:wfs="http://www.opengis.net/wfs/2.0"
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation="http://mapserver.gis.umn.edu/mapserver https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=DescribeFeatureType&amp;TYPENAME=ms:PKP_PLK&amp;OUTPUTFORMAT=application%2Fgml%2Bxml%3B%20version%3D3.2 http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd"
   timeStamp="2026-11-10T11:07:23" numberMatched="unknown" numberReturned="1000"
   previous="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=4000"
   next="https://mapy.geoportal.gov.pl/wss/service/wfs/sdi/Przejazdy?SERVICE=WFS&amp;VERSION=2.0.0&amp;REQUEST=GetFeature&amp;TYPENAMES=ms%3APKP_PLK&amp;COUNT=1000&amp;STARTINDEX=6000">
      <wfs:boundedBy>
      	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
      		<gml:lowerCorner>287595.996903 405745.611933</gml:lowerCorner>
      		<gml:upperCorner>708304.112000 548104.961307</gml:upperCorner>
      	</gml:Envelope>
      </wfs:boundedBy>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704067.672000 525312.019000</gml:lowerCorner>
        		<gml:upperCorner>704067.672000 525312.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704067.672000 525312.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 006 912</ms:GML_ID>
        <ms:NAZWA>254 006 912</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254006912</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704517.251000 507971.637000</gml:lowerCorner>
        		<gml:upperCorner>704517.251000 507971.637000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704517.251000 507971.637000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 023 860</ms:GML_ID>
        <ms:NAZWA>256 023 860</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256023860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705547.752000 525139.476000</gml:lowerCorner>
        		<gml:upperCorner>705547.752000 525139.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705547.752000 525139.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 008 436</ms:GML_ID>
        <ms:NAZWA>254 008 436</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254008436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706246.252000 525251.577000</gml:lowerCorner>
        		<gml:upperCorner>706246.252000 525251.577000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706246.252000 525251.577000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 009 145</ms:GML_ID>
        <ms:NAZWA>254 009 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254009145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706312.282000 525263.169000</gml:lowerCorner>
        		<gml:upperCorner>706312.282000 525263.169000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706312.282000 525263.169000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 009 213</ms:GML_ID>
        <ms:NAZWA>254 009 213</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254009213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>706327.516000 525265.729000</gml:lowerCorner>
        		<gml:upperCorner>706327.516000 525265.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>706327.516000 525265.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 009 228</ms:GML_ID>
        <ms:NAZWA>254 009 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254009228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>707220.477000 525406.843000</gml:lowerCorner>
        		<gml:upperCorner>707220.477000 525406.843000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>707220.477000 525406.843000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 010 132</ms:GML_ID>
        <ms:NAZWA>254 010 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254010132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>708304.112000 525640.155000</gml:lowerCorner>
        		<gml:upperCorner>708304.112000 525640.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>708304.112000 525640.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 011 252</ms:GML_ID>
        <ms:NAZWA>254 011 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254011252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556290.485586 524485.256022</gml:lowerCorner>
        		<gml:upperCorner>556290.485586 524485.256022</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556290.485586 524485.256022</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 108 089</ms:GML_ID>
        <ms:NAZWA>027 108 089</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027108089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556318.622126 523763.806884</gml:lowerCorner>
        		<gml:upperCorner>556318.622126 523763.806884</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556318.622126 523763.806884</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 108 813</ms:GML_ID>
        <ms:NAZWA>027 108 813</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027108813</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556350.751000 522707.453000</gml:lowerCorner>
        		<gml:upperCorner>556350.751000 522707.453000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556350.751000 522707.453000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 109 869</ms:GML_ID>
        <ms:NAZWA>027 109 869</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027109869</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556365.512806 522200.974376</gml:lowerCorner>
        		<gml:upperCorner>556365.512806 522200.974376</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556365.512806 522200.974376</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 110 377</ms:GML_ID>
        <ms:NAZWA>027 110 377</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027110377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556651.259000 506118.326000</gml:lowerCorner>
        		<gml:upperCorner>556651.259000 506118.326000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556651.259000 506118.326000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 127 524</ms:GML_ID>
        <ms:NAZWA>027 127 524</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027127524</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11372">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>557068.683699 505565.113099</gml:lowerCorner>
        		<gml:upperCorner>557068.683699 505565.113099</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11372.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>557068.683699 505565.113099</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11372</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 128 218</ms:GML_ID>
        <ms:NAZWA>027 128 218</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027128218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11373">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>558626.772682 503558.873326</gml:lowerCorner>
        		<gml:upperCorner>558626.772682 503558.873326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11373.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>558626.772682 503558.873326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11373</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 130 759</ms:GML_ID>
        <ms:NAZWA>027 130 759</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027130759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11374">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559095.983775 502999.915359</gml:lowerCorner>
        		<gml:upperCorner>559095.983775 502999.915359</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11374.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559095.983775 502999.915359</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11374</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 131 490</ms:GML_ID>
        <ms:NAZWA>027 131 490</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027131490</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11375">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559467.392003 502555.699550</gml:lowerCorner>
        		<gml:upperCorner>559467.392003 502555.699550</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11375.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559467.392003 502555.699550</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11375</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 132 068</ms:GML_ID>
        <ms:NAZWA>027 132 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027132068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11376">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>559801.867369 502090.774076</gml:lowerCorner>
        		<gml:upperCorner>559801.867369 502090.774076</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11376.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>559801.867369 502090.774076</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11376</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 132 642</ms:GML_ID>
        <ms:NAZWA>027 132 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027132642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11377">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>560382.208229 501276.172155</gml:lowerCorner>
        		<gml:upperCorner>560382.208229 501276.172155</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11377.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>560382.208229 501276.172155</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11377</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 133 643</ms:GML_ID>
        <ms:NAZWA>027 133 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027133643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11378">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>561026.995175 500370.852584</gml:lowerCorner>
        		<gml:upperCorner>561026.995175 500370.852584</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11378.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>561026.995175 500370.852584</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11378</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 134 755</ms:GML_ID>
        <ms:NAZWA>027 134 755</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027134755</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7919">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>565823.437000 536623.101000</gml:lowerCorner>
        		<gml:upperCorner>565823.437000 536623.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7919.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>565823.437000 536623.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7919</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 101 690</ms:GML_ID>
        <ms:NAZWA>033 101 690</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033101690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7921">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571379.793000 532820.462000</gml:lowerCorner>
        		<gml:upperCorner>571379.793000 532820.462000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7921.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571379.793000 532820.462000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7921</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 108 494</ms:GML_ID>
        <ms:NAZWA>033 108 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033108494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7922">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>571703.468000 532520.533000</gml:lowerCorner>
        		<gml:upperCorner>571703.468000 532520.533000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7922.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>571703.468000 532520.533000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7922</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 108 938</ms:GML_ID>
        <ms:NAZWA>033 108 938</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033108938</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7923">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>572777.729176 531733.155073</gml:lowerCorner>
        		<gml:upperCorner>572777.729176 531733.155073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7923.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>572777.729176 531733.155073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7923</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 110 284</ms:GML_ID>
        <ms:NAZWA>033 110 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033110284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8149">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>575500.323000 529925.010000</gml:lowerCorner>
        		<gml:upperCorner>575500.323000 529925.010000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8149.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>575500.323000 529925.010000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8149</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 113 598</ms:GML_ID>
        <ms:NAZWA>033 113 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033113598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8150">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576273.645000 529380.240000</gml:lowerCorner>
        		<gml:upperCorner>576273.645000 529380.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8150.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576273.645000 529380.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8150</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 114 545</ms:GML_ID>
        <ms:NAZWA>033 114 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033114545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8151">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>576994.051000 528857.749000</gml:lowerCorner>
        		<gml:upperCorner>576994.051000 528857.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8151.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>576994.051000 528857.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8151</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 115 435</ms:GML_ID>
        <ms:NAZWA>033 115 435</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033115435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8152">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>577886.348457 528592.301459</gml:lowerCorner>
        		<gml:upperCorner>577886.348457 528592.301459</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8152.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>577886.348457 528592.301459</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8152</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 116 399</ms:GML_ID>
        <ms:NAZWA>033 116 399</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033116399</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8153">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>578127.959034 528625.905893</gml:lowerCorner>
        		<gml:upperCorner>578127.959034 528625.905893</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8153.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>578127.959034 528625.905893</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8153</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 116 656</ms:GML_ID>
        <ms:NAZWA>033 116 656</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033116656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8154">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>579079.242310 528780.532551</gml:lowerCorner>
        		<gml:upperCorner>579079.242310 528780.532551</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8154.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>579079.242310 528780.532551</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8154</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 117 607</ms:GML_ID>
        <ms:NAZWA>033 117 607</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033117607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8155">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>580880.205461 528735.622086</gml:lowerCorner>
        		<gml:upperCorner>580880.205461 528735.622086</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8155.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>580880.205461 528735.622086</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8155</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 119 476</ms:GML_ID>
        <ms:NAZWA>033 119 476</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033119476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8156">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>581281.343612 528418.723406</gml:lowerCorner>
        		<gml:upperCorner>581281.343612 528418.723406</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8156.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>581281.343612 528418.723406</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8156</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 119 989</ms:GML_ID>
        <ms:NAZWA>033 119 989</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033119989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8157">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>582437.477911 527999.382964</gml:lowerCorner>
        		<gml:upperCorner>582437.477911 527999.382964</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8157.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>582437.477911 527999.382964</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8157</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 121 241</ms:GML_ID>
        <ms:NAZWA>033 121 241</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033121241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8158">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>584122.782812 527535.303112</gml:lowerCorner>
        		<gml:upperCorner>584122.782812 527535.303112</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8158.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>584122.782812 527535.303112</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8158</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 122 994</ms:GML_ID>
        <ms:NAZWA>033 122 994</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033122994</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8159">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>585076.950278 527141.675120</gml:lowerCorner>
        		<gml:upperCorner>585076.950278 527141.675120</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8159.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>585076.950278 527141.675120</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8159</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 124 028</ms:GML_ID>
        <ms:NAZWA>033 124 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033124028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8160">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>587450.760194 526906.004907</gml:lowerCorner>
        		<gml:upperCorner>587450.760194 526906.004907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8160.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>587450.760194 526906.004907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8160</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 126 422</ms:GML_ID>
        <ms:NAZWA>033 126 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033126422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>589246.423234 527020.401990</gml:lowerCorner>
        		<gml:upperCorner>589246.423234 527020.401990</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>589246.423234 527020.401990</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 128 223</ms:GML_ID>
        <ms:NAZWA>033 128 223</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033128223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8162">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>590317.610146 527089.216290</gml:lowerCorner>
        		<gml:upperCorner>590317.610146 527089.216290</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8162.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>590317.610146 527089.216290</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8162</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 129 294</ms:GML_ID>
        <ms:NAZWA>033 129 294</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033129294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8163">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>591974.164000 526546.041000</gml:lowerCorner>
        		<gml:upperCorner>591974.164000 526546.041000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8163.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>591974.164000 526546.041000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8163</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 131 084</ms:GML_ID>
        <ms:NAZWA>033 131 084</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033131084</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8164">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>592954.025650 526060.936096</gml:lowerCorner>
        		<gml:upperCorner>592954.025650 526060.936096</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8164.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>592954.025650 526060.936096</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8164</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 132 180</ms:GML_ID>
        <ms:NAZWA>033 132 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033132180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8165">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>596792.052000 527130.474000</gml:lowerCorner>
        		<gml:upperCorner>596792.052000 527130.474000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8165.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>596792.052000 527130.474000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8165</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 136 285</ms:GML_ID>
        <ms:NAZWA>033 136 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033136285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1349">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>617402.595000 500112.965000</gml:lowerCorner>
        		<gml:upperCorner>617402.595000 500112.965000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1349.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>617402.595000 500112.965000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1349</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 090 937</ms:GML_ID>
        <ms:NAZWA>208 090 937</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208090937</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>603368.460204 500948.562563</gml:lowerCorner>
        		<gml:upperCorner>603368.460204 500948.562563</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>603368.460204 500948.562563</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 179 031</ms:GML_ID>
        <ms:NAZWA>353 179 031</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353179031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>604341.570268 501644.956725</gml:lowerCorner>
        		<gml:upperCorner>604341.570268 501644.956725</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>604341.570268 501644.956725</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 180 229</ms:GML_ID>
        <ms:NAZWA>353 180 229</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353180229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>605485.674469 502469.786844</gml:lowerCorner>
        		<gml:upperCorner>605485.674469 502469.786844</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>605485.674469 502469.786844</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 181 642</ms:GML_ID>
        <ms:NAZWA>353 181 642</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353181642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1348">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>616023.094000 502582.018000</gml:lowerCorner>
        		<gml:upperCorner>616023.094000 502582.018000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1348.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>616023.094000 502582.018000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1348</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 088 108</ms:GML_ID>
        <ms:NAZWA>208 088 108</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208088108</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1347">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615633.111000 503429.496000</gml:lowerCorner>
        		<gml:upperCorner>615633.111000 503429.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1347.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615633.111000 503429.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1347</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 087 173</ms:GML_ID>
        <ms:NAZWA>208 087 173</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208087173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>606750.762000 504187.838000</gml:lowerCorner>
        		<gml:upperCorner>606750.762000 504187.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>606750.762000 504187.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 183 808</ms:GML_ID>
        <ms:NAZWA>353 183 808</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353183808</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1346">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>615174.285000 504582.431000</gml:lowerCorner>
        		<gml:upperCorner>615174.285000 504582.431000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1346.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>615174.285000 504582.431000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1346</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 085 932</ms:GML_ID>
        <ms:NAZWA>208 085 932</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208085932</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607360.958353 504603.283810</gml:lowerCorner>
        		<gml:upperCorner>607360.958353 504603.283810</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607360.958353 504603.283810</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 184 540</ms:GML_ID>
        <ms:NAZWA>353 184 540</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353184540</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>607562.656013 504740.474033</gml:lowerCorner>
        		<gml:upperCorner>607562.656013 504740.474033</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>607562.656013 504740.474033</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 184 786</ms:GML_ID>
        <ms:NAZWA>353 184 786</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353184786</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4004">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608172.505000 505153.706000</gml:lowerCorner>
        		<gml:upperCorner>608172.505000 505153.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4004.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608172.505000 505153.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4004</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 185 520</ms:GML_ID>
        <ms:NAZWA>353 185 520</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353185520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1345">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614845.897952 505420.102885</gml:lowerCorner>
        		<gml:upperCorner>614845.897952 505420.102885</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1345.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614845.897952 505420.102885</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1345</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 085 032</ms:GML_ID>
        <ms:NAZWA>208 085 032</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208085032</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4005">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>608773.459000 505562.734000</gml:lowerCorner>
        		<gml:upperCorner>608773.459000 505562.734000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4005.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>608773.459000 505562.734000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4005</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 186 248</ms:GML_ID>
        <ms:NAZWA>353 186 248</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353186248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1344">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614698.048000 505794.975000</gml:lowerCorner>
        		<gml:upperCorner>614698.048000 505794.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1344.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614698.048000 505794.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1344</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 084 627</ms:GML_ID>
        <ms:NAZWA>208 084 627</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208084627</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4006">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609224.488206 505869.473391</gml:lowerCorner>
        		<gml:upperCorner>609224.488206 505869.473391</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4006.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609224.488206 505869.473391</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4006</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 186 795</ms:GML_ID>
        <ms:NAZWA>353 186 795</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353186795</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4007">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>609460.409729 506026.498066</gml:lowerCorner>
        		<gml:upperCorner>609460.409729 506026.498066</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4007.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>609460.409729 506026.498066</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4007</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 187 078</ms:GML_ID>
        <ms:NAZWA>353 187 078</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353187078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1343">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614482.304308 506340.517993</gml:lowerCorner>
        		<gml:upperCorner>614482.304308 506340.517993</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1343.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614482.304308 506340.517993</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1343</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 084 041</ms:GML_ID>
        <ms:NAZWA>208 084 041</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208084041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4008">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610133.730000 506459.694000</gml:lowerCorner>
        		<gml:upperCorner>610133.730000 506459.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4008.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610133.730000 506459.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4008</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 187 880</ms:GML_ID>
        <ms:NAZWA>353 187 880</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353187880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1342">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>614332.558733 506719.438811</gml:lowerCorner>
        		<gml:upperCorner>614332.558733 506719.438811</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1342.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>614332.558733 506719.438811</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1342</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 083 633</ms:GML_ID>
        <ms:NAZWA>208 083 633</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208083633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4009">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>610856.659315 506925.465462</gml:lowerCorner>
        		<gml:upperCorner>610856.659315 506925.465462</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4009.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>610856.659315 506925.465462</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4009</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 188 740</ms:GML_ID>
        <ms:NAZWA>353 188 740</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353188740</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4010">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>611890.118000 507781.399000</gml:lowerCorner>
        		<gml:upperCorner>611890.118000 507781.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4010.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>611890.118000 507781.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4010</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 190 095</ms:GML_ID>
        <ms:NAZWA>353 190 095</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353190095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1341">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>613359.842000 507875.383000</gml:lowerCorner>
        		<gml:upperCorner>613359.842000 507875.383000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1341.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>613359.842000 507875.383000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1341</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 082 086</ms:GML_ID>
        <ms:NAZWA>208 082 086</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208082086</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1340">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>612993.935047 508203.515865</gml:lowerCorner>
        		<gml:upperCorner>612993.935047 508203.515865</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1340.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>612993.935047 508203.515865</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1340</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 081 589</ms:GML_ID>
        <ms:NAZWA>208 081 589</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208081589</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691021.927000 499673.897000</gml:lowerCorner>
        		<gml:upperCorner>691021.927000 499673.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691021.927000 499673.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 006 923</ms:GML_ID>
        <ms:NAZWA>256 006 923</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256006923</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>691952.408000 499749.614000</gml:lowerCorner>
        		<gml:upperCorner>691952.408000 499749.614000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>691952.408000 499749.614000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 007 849</ms:GML_ID>
        <ms:NAZWA>256 007 849</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256007849</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>693618.837000 499885.988000</gml:lowerCorner>
        		<gml:upperCorner>693618.837000 499885.988000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>693618.837000 499885.988000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 009 521</ms:GML_ID>
        <ms:NAZWA>256 009 521</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256009521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>694922.720000 500307.180000</gml:lowerCorner>
        		<gml:upperCorner>694922.720000 500307.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>694922.720000 500307.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 010 908</ms:GML_ID>
        <ms:NAZWA>256 010 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256010908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>695975.254000 500702.693000</gml:lowerCorner>
        		<gml:upperCorner>695975.254000 500702.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>695975.254000 500702.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 012 035</ms:GML_ID>
        <ms:NAZWA>256 012 035</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256012035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>696689.542000 500970.396000</gml:lowerCorner>
        		<gml:upperCorner>696689.542000 500970.396000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>696689.542000 500970.396000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 012 797</ms:GML_ID>
        <ms:NAZWA>256 012 797</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256012797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>697231.143000 501424.551000</gml:lowerCorner>
        		<gml:upperCorner>697231.143000 501424.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>697231.143000 501424.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 013 536</ms:GML_ID>
        <ms:NAZWA>256 013 536</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256013536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1278">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>684012.897288 503677.325637</gml:lowerCorner>
        		<gml:upperCorner>684012.897288 503677.325637</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1278.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>684012.897288 503677.325637</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1278</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 131 382</ms:GML_ID>
        <ms:NAZWA>207 131 382</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207131382</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698546.742000 504420.844000</gml:lowerCorner>
        		<gml:upperCorner>698546.742000 504420.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698546.742000 504420.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 016 817</ms:GML_ID>
        <ms:NAZWA>256 016 817</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256016817</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>698996.736000 504947.145000</gml:lowerCorner>
        		<gml:upperCorner>698996.736000 504947.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>698996.736000 504947.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 017 522</ms:GML_ID>
        <ms:NAZWA>256 017 522</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256017522</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699392.435000 505181.696000</gml:lowerCorner>
        		<gml:upperCorner>699392.435000 505181.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699392.435000 505181.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 017 982</ms:GML_ID>
        <ms:NAZWA>256 017 982</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256017982</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>700380.553000 505770.200000</gml:lowerCorner>
        		<gml:upperCorner>700380.553000 505770.200000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>700380.553000 505770.200000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 019 136</ms:GML_ID>
        <ms:NAZWA>256 019 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256019136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701292.981000 506312.394000</gml:lowerCorner>
        		<gml:upperCorner>701292.981000 506312.394000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701292.981000 506312.394000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 020 193</ms:GML_ID>
        <ms:NAZWA>256 020 193</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256020193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>701876.267000 506661.182000</gml:lowerCorner>
        		<gml:upperCorner>701876.267000 506661.182000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>701876.267000 506661.182000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 020 876</ms:GML_ID>
        <ms:NAZWA>256 020 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256020876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703619.328630 507394.614975</gml:lowerCorner>
        		<gml:upperCorner>703619.328630 507394.614975</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703619.328630 507394.614975</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 022 789</ms:GML_ID>
        <ms:NAZWA>256 022 789</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256022789</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>703933.127833 507581.101586</gml:lowerCorner>
        		<gml:upperCorner>703933.127833 507581.101586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>703933.127833 507581.101586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 023 154</ms:GML_ID>
        <ms:NAZWA>256 023 154</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256023154</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>704928.339000 508074.397000</gml:lowerCorner>
        		<gml:upperCorner>704928.339000 508074.397000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>704928.339000 508074.397000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 024 287</ms:GML_ID>
        <ms:NAZWA>256 024 287</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256024287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>705880.789068 508152.602428</gml:lowerCorner>
        		<gml:upperCorner>705880.789068 508152.602428</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>705880.789068 508152.602428</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.256 025 236</ms:GML_ID>
        <ms:NAZWA>256 025 236</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>256025236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>699518.308000 524199.351000</gml:lowerCorner>
        		<gml:upperCorner>699518.308000 524199.351000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>699518.308000 524199.351000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.254 002 875</ms:GML_ID>
        <ms:NAZWA>254 002 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>254002875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8166">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>597459.040472 527395.293456</gml:lowerCorner>
        		<gml:upperCorner>597459.040472 527395.293456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8166.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>597459.040472 527395.293456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8166</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 137 007</ms:GML_ID>
        <ms:NAZWA>033 137 007</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033137007</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8167">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598284.514000 528036.483000</gml:lowerCorner>
        		<gml:upperCorner>598284.514000 528036.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8167.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598284.514000 528036.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8167</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 138 065</ms:GML_ID>
        <ms:NAZWA>033 138 065</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033138065</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8168">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>598480.566000 528305.907000</gml:lowerCorner>
        		<gml:upperCorner>598480.566000 528305.907000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8168.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>598480.566000 528305.907000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8168</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 138 408</ms:GML_ID>
        <ms:NAZWA>033 138 408</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033138408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8169">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599338.012000 529014.148000</gml:lowerCorner>
        		<gml:upperCorner>599338.012000 529014.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8169.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599338.012000 529014.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8169</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 139 520</ms:GML_ID>
        <ms:NAZWA>033 139 520</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033139520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1326">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599765.958040 526760.843651</gml:lowerCorner>
        		<gml:upperCorner>599765.958040 526760.843651</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1326.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599765.958040 526760.843651</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1326</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 055 553</ms:GML_ID>
        <ms:NAZWA>208 055 553</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208055553</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1327">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>599839.757000 526294.528000</gml:lowerCorner>
        		<gml:upperCorner>599839.757000 526294.528000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1327.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>599839.757000 526294.528000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1327</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 056 056</ms:GML_ID>
        <ms:NAZWA>208 056 056</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208056056</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600195.352393 498899.168326</gml:lowerCorner>
        		<gml:upperCorner>600195.352393 498899.168326</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600195.352393 498899.168326</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 175 248</ms:GML_ID>
        <ms:NAZWA>353 175 248</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353175248</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1328">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600325.153440 525859.174929</gml:lowerCorner>
        		<gml:upperCorner>600325.153440 525859.174929</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1328.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600325.153440 525859.174929</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1328</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 056 707</ms:GML_ID>
        <ms:NAZWA>208 056 707</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208056707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8170">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600379.488679 528329.290922</gml:lowerCorner>
        		<gml:upperCorner>600379.488679 528329.290922</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8170.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600379.488679 528329.290922</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8170</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 141 098</ms:GML_ID>
        <ms:NAZWA>033 141 098</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033141098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600387.352000 536151.511000</gml:lowerCorner>
        		<gml:upperCorner>600387.352000 536151.511000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600387.352000 536151.511000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 045 441</ms:GML_ID>
        <ms:NAZWA>208 045 441</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208045441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600627.898000 535136.864000</gml:lowerCorner>
        		<gml:upperCorner>600627.898000 535136.864000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600627.898000 535136.864000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 046 484</ms:GML_ID>
        <ms:NAZWA>208 046 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208046484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1325">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600793.332000 528648.172000</gml:lowerCorner>
        		<gml:upperCorner>600793.332000 528648.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1325.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600793.332000 528648.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1325</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 053 390</ms:GML_ID>
        <ms:NAZWA>208 053 390</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208053390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600806.619000 534419.582000</gml:lowerCorner>
        		<gml:upperCorner>600806.619000 534419.582000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600806.619000 534419.582000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 047 225</ms:GML_ID>
        <ms:NAZWA>208 047 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208047225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>600984.096000 533849.305000</gml:lowerCorner>
        		<gml:upperCorner>600984.096000 533849.305000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>600984.096000 533849.305000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 047 825</ms:GML_ID>
        <ms:NAZWA>208 047 825</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208047825</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1317">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601085.037000 533537.597000</gml:lowerCorner>
        		<gml:upperCorner>601085.037000 533537.597000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1317.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601085.037000 533537.597000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1317</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 048 151</ms:GML_ID>
        <ms:NAZWA>208 048 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208048151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1324">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601097.224000 529365.665000</gml:lowerCorner>
        		<gml:upperCorner>601097.224000 529365.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1324.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601097.224000 529365.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1324</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 052 603</ms:GML_ID>
        <ms:NAZWA>208 052 603</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208052603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601198.205000 499466.971000</gml:lowerCorner>
        		<gml:upperCorner>601198.205000 499466.971000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601198.205000 499466.971000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 176 397</ms:GML_ID>
        <ms:NAZWA>353 176 397</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353176397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1323">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601207.953000 529678.146000</gml:lowerCorner>
        		<gml:upperCorner>601207.953000 529678.146000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1323.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601207.953000 529678.146000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1323</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 052 270</ms:GML_ID>
        <ms:NAZWA>208 052 270</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208052270</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1318">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601308.535000 532840.725000</gml:lowerCorner>
        		<gml:upperCorner>601308.535000 532840.725000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1318.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601308.535000 532840.725000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1318</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 048 884</ms:GML_ID>
        <ms:NAZWA>208 048 884</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208048884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1322">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601378.620000 530163.871000</gml:lowerCorner>
        		<gml:upperCorner>601378.620000 530163.871000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1322.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601378.620000 530163.871000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1322</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 051 756</ms:GML_ID>
        <ms:NAZWA>208 051 756</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208051756</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1319">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601401.767000 532551.789000</gml:lowerCorner>
        		<gml:upperCorner>601401.767000 532551.789000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1319.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601401.767000 532551.789000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1319</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 049 187</ms:GML_ID>
        <ms:NAZWA>208 049 187</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208049187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601506.954000 499638.188000</gml:lowerCorner>
        		<gml:upperCorner>601506.954000 499638.188000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601506.954000 499638.188000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 176 751</ms:GML_ID>
        <ms:NAZWA>353 176 751</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353176751</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1320">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601526.587736 532235.145181</gml:lowerCorner>
        		<gml:upperCorner>601526.587736 532235.145181</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1320.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601526.587736 532235.145181</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1320</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 049 529</ms:GML_ID>
        <ms:NAZWA>208 049 529</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208049529</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1321">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>601792.589283 531785.928380</gml:lowerCorner>
        		<gml:upperCorner>601792.589283 531785.928380</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1321.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>601792.589283 531785.928380</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1321</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.208 050 052</ms:GML_ID>
        <ms:NAZWA>208 050 052</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>208050052</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>602403.904200 500259.048586</gml:lowerCorner>
        		<gml:upperCorner>602403.904200 500259.048586</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>602403.904200 500259.048586</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.353 177 843</ms:GML_ID>
        <ms:NAZWA>353 177 843</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>353177843</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>633102.367000 496047.873000</gml:lowerCorner>
        		<gml:upperCorner>633102.367000 496047.873000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>633102.367000 496047.873000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 073 547</ms:GML_ID>
        <ms:NAZWA>207 073 547</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207073547</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636539.959828 537604.579149</gml:lowerCorner>
        		<gml:upperCorner>636539.959828 537604.579149</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636539.959828 537604.579149</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 210 394</ms:GML_ID>
        <ms:NAZWA>009 210 394</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009210394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>636623.434308 495346.859421</gml:lowerCorner>
        		<gml:upperCorner>636623.434308 495346.859421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>636623.434308 495346.859421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 077 727</ms:GML_ID>
        <ms:NAZWA>207 077 727</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207077727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>637052.344335 535468.464835</gml:lowerCorner>
        		<gml:upperCorner>637052.344335 535468.464835</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>637052.344335 535468.464835</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 212 705</ms:GML_ID>
        <ms:NAZWA>009 212 705</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009212705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>639259.468070 493512.683907</gml:lowerCorner>
        		<gml:upperCorner>639259.468070 493512.683907</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>639259.468070 493512.683907</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 081 186</ms:GML_ID>
        <ms:NAZWA>207 081 186</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207081186</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>647060.590253 493507.467427</gml:lowerCorner>
        		<gml:upperCorner>647060.590253 493507.467427</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>647060.590253 493507.467427</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 090 125</ms:GML_ID>
        <ms:NAZWA>207 090 125</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207090125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>648025.354828 522205.087627</gml:lowerCorner>
        		<gml:upperCorner>648025.354828 522205.087627</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>648025.354828 522205.087627</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 230 660</ms:GML_ID>
        <ms:NAZWA>009 230 660</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009230660</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11316">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>649836.035699 521442.009869</gml:lowerCorner>
        		<gml:upperCorner>649836.035699 521442.009869</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11316.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>649836.035699 521442.009869</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11316</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.009 232 797</ms:GML_ID>
        <ms:NAZWA>009 232 797</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>009232797</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>654611.865000 496434.171000</gml:lowerCorner>
        		<gml:upperCorner>654611.865000 496434.171000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>654611.865000 496434.171000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 098 716</ms:GML_ID>
        <ms:NAZWA>207 098 716</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207098716</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1257">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>655964.527131 497223.378126</gml:lowerCorner>
        		<gml:upperCorner>655964.527131 497223.378126</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1257.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>655964.527131 497223.378126</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1257</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 100 300</ms:GML_ID>
        <ms:NAZWA>207 100 300</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207100300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1259">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>658426.317000 497623.847000</gml:lowerCorner>
        		<gml:upperCorner>658426.317000 497623.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1259.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>658426.317000 497623.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1259</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 102 944</ms:GML_ID>
        <ms:NAZWA>207 102 944</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207102944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1260">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663857.197925 497083.717201</gml:lowerCorner>
        		<gml:upperCorner>663857.197925 497083.717201</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1260.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663857.197925 497083.717201</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1260</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 108 542</ms:GML_ID>
        <ms:NAZWA>207 108 542</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207108542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1262">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665040.511000 497295.300000</gml:lowerCorner>
        		<gml:upperCorner>665040.511000 497295.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1262.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665040.511000 497295.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1262</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 109 746</ms:GML_ID>
        <ms:NAZWA>207 109 746</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207109746</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1264">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667042.036662 497468.572743</gml:lowerCorner>
        		<gml:upperCorner>667042.036662 497468.572743</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1264.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667042.036662 497468.572743</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1264</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 111 784</ms:GML_ID>
        <ms:NAZWA>207 111 784</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207111784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1266">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670004.523752 500047.135997</gml:lowerCorner>
        		<gml:upperCorner>670004.523752 500047.135997</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1266.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670004.523752 500047.135997</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1266</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 116 011</ms:GML_ID>
        <ms:NAZWA>207 116 011</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207116011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1267">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670562.200733 500614.680684</gml:lowerCorner>
        		<gml:upperCorner>670562.200733 500614.680684</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1267.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670562.200733 500614.680684</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1267</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 116 807</ms:GML_ID>
        <ms:NAZWA>207 116 807</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207116807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1269">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>672031.110000 501395.036000</gml:lowerCorner>
        		<gml:upperCorner>672031.110000 501395.036000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1269.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>672031.110000 501395.036000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1269</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 118 526</ms:GML_ID>
        <ms:NAZWA>207 118 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207118526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1271">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>675354.885962 500953.461996</gml:lowerCorner>
        		<gml:upperCorner>675354.885962 500953.461996</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1271.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>675354.885962 500953.461996</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1271</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 121 946</ms:GML_ID>
        <ms:NAZWA>207 121 946</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207121946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1273">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677869.074556 500786.332646</gml:lowerCorner>
        		<gml:upperCorner>677869.074556 500786.332646</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1273.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677869.074556 500786.332646</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1273</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 124 478</ms:GML_ID>
        <ms:NAZWA>207 124 478</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207124478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1274">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>677960.919638 500819.931600</gml:lowerCorner>
        		<gml:upperCorner>677960.919638 500819.931600</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1274.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>677960.919638 500819.931600</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1274</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 124 578</ms:GML_ID>
        <ms:NAZWA>207 124 578</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207124578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1276">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>679266.067264 501300.545071</gml:lowerCorner>
        		<gml:upperCorner>679266.067264 501300.545071</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1276.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>679266.067264 501300.545071</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1276</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 125 968</ms:GML_ID>
        <ms:NAZWA>207 125 968</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207125968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6173">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685896.062044 507778.130749</gml:lowerCorner>
        		<gml:upperCorner>685896.062044 507778.130749</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6173.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685896.062044 507778.130749</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6173</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 005 050</ms:GML_ID>
        <ms:NAZWA>204 005 050</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204005050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6174">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686336.563000 509528.035000</gml:lowerCorner>
        		<gml:upperCorner>686336.563000 509528.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6174.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686336.563000 509528.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6174</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 006 860</ms:GML_ID>
        <ms:NAZWA>204 006 860</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204006860</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6175">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687106.890000 511777.659000</gml:lowerCorner>
        		<gml:upperCorner>687106.890000 511777.659000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6175.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687106.890000 511777.659000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6175</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 009 242</ms:GML_ID>
        <ms:NAZWA>204 009 242</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204009242</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6176">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687565.512000 513126.170000</gml:lowerCorner>
        		<gml:upperCorner>687565.512000 513126.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6176.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687565.512000 513126.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6176</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 010 668</ms:GML_ID>
        <ms:NAZWA>204 010 668</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204010668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6177">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>687816.544013 513870.672991</gml:lowerCorner>
        		<gml:upperCorner>687816.544013 513870.672991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6177.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>687816.544013 513870.672991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6177</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 011 451</ms:GML_ID>
        <ms:NAZWA>204 011 451</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204011451</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663746.533000 487181.452000</gml:lowerCorner>
        		<gml:upperCorner>663746.533000 487181.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663746.533000 487181.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 010 229</ms:GML_ID>
        <ms:NAZWA>244 010 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244010229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663749.008000 486686.377000</gml:lowerCorner>
        		<gml:upperCorner>663749.008000 486686.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663749.008000 486686.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 009 731</ms:GML_ID>
        <ms:NAZWA>244 009 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244009731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>663976.540000 485924.283000</gml:lowerCorner>
        		<gml:upperCorner>663976.540000 485924.283000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>663976.540000 485924.283000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 008 933</ms:GML_ID>
        <ms:NAZWA>244 008 933</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244008933</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664195.924000 479596.083000</gml:lowerCorner>
        		<gml:upperCorner>664195.924000 479596.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664195.924000 479596.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 000 608</ms:GML_ID>
        <ms:NAZWA>244 000 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244000608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1261">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664562.979216 497205.955962</gml:lowerCorner>
        		<gml:upperCorner>664562.979216 497205.955962</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1261.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664562.979216 497205.955962</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1261</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 109 261</ms:GML_ID>
        <ms:NAZWA>207 109 261</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207109261</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>664722.259000 484612.737000</gml:lowerCorner>
        		<gml:upperCorner>664722.259000 484612.737000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>664722.259000 484612.737000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 007 229</ms:GML_ID>
        <ms:NAZWA>244 007 229</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244007229</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665112.535000 480516.975000</gml:lowerCorner>
        		<gml:upperCorner>665112.535000 480516.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665112.535000 480516.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 002 001</ms:GML_ID>
        <ms:NAZWA>244 002 001</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244002001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665188.938000 484418.042000</gml:lowerCorner>
        		<gml:upperCorner>665188.938000 484418.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665188.938000 484418.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 006 720</ms:GML_ID>
        <ms:NAZWA>244 006 720</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244006720</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1263">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665300.279000 497338.493000</gml:lowerCorner>
        		<gml:upperCorner>665300.279000 497338.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1263.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665300.279000 497338.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1263</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 110 010</ms:GML_ID>
        <ms:NAZWA>207 110 010</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207110010</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665823.311000 484037.406000</gml:lowerCorner>
        		<gml:upperCorner>665823.311000 484037.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665823.311000 484037.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 005 976</ms:GML_ID>
        <ms:NAZWA>244 005 976</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244005976</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>665887.010000 482761.515000</gml:lowerCorner>
        		<gml:upperCorner>665887.010000 482761.515000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>665887.010000 482761.515000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.244 004 521</ms:GML_ID>
        <ms:NAZWA>244 004 521</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>244004521</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1265">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>667322.222000 497907.845000</gml:lowerCorner>
        		<gml:upperCorner>667322.222000 497907.845000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1265.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>667322.222000 497907.845000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1265</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 112 314</ms:GML_ID>
        <ms:NAZWA>207 112 314</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207112314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>668362.413000 479661.214000</gml:lowerCorner>
        		<gml:upperCorner>668362.413000 479661.214000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>668362.413000 479661.214000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 472 100</ms:GML_ID>
        <ms:NAZWA>131 472 100</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131472100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1268">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>670942.514000 501005.263000</gml:lowerCorner>
        		<gml:upperCorner>670942.514000 501005.263000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1268.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>670942.514000 501005.263000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1268</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 117 353</ms:GML_ID>
        <ms:NAZWA>207 117 353</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207117353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1270">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673146.545641 501387.057221</gml:lowerCorner>
        		<gml:upperCorner>673146.545641 501387.057221</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1270.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673146.545641 501387.057221</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1270</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 119 658</ms:GML_ID>
        <ms:NAZWA>207 119 658</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207119658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>673475.251000 480596.694000</gml:lowerCorner>
        		<gml:upperCorner>673475.251000 480596.694000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>673475.251000 480596.694000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 477 423</ms:GML_ID>
        <ms:NAZWA>131 477 423</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131477423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>674720.237000 482064.202000</gml:lowerCorner>
        		<gml:upperCorner>674720.237000 482064.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>674720.237000 482064.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 479 349</ms:GML_ID>
        <ms:NAZWA>131 479 349</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131479349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1272">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>676742.735598 500843.392769</gml:lowerCorner>
        		<gml:upperCorner>676742.735598 500843.392769</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1272.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>676742.735598 500843.392769</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1272</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 123 341</ms:GML_ID>
        <ms:NAZWA>207 123 341</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207123341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1275">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>678684.703378 501092.808545</gml:lowerCorner>
        		<gml:upperCorner>678684.703378 501092.808545</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1275.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>678684.703378 501092.808545</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1275</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 125 350</ms:GML_ID>
        <ms:NAZWA>207 125 350</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207125350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5636">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682039.530725 484325.109346</gml:lowerCorner>
        		<gml:upperCorner>682039.530725 484325.109346</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5636.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682039.530725 484325.109346</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5636</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 487 083</ms:GML_ID>
        <ms:NAZWA>131 487 083</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131487083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.1277">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>682501.157000 502940.912000</gml:lowerCorner>
        		<gml:upperCorner>682501.157000 502940.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.1277.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>682501.157000 502940.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>1277</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.207 129 678</ms:GML_ID>
        <ms:NAZWA>207 129 678</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>207129678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7033">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685444.784000 477063.677000</gml:lowerCorner>
        		<gml:upperCorner>685444.784000 477063.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7033.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685444.784000 477063.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7033</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.203 013 458</ms:GML_ID>
        <ms:NAZWA>203 013 458</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>203013458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6172">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685464.957000 505461.254000</gml:lowerCorner>
        		<gml:upperCorner>685464.957000 505461.254000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6172.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685464.957000 505461.254000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6172</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 002 687</ms:GML_ID>
        <ms:NAZWA>204 002 687</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204002687</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6171">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685498.540000 504544.518000</gml:lowerCorner>
        		<gml:upperCorner>685498.540000 504544.518000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6171.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685498.540000 504544.518000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6171</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.204 001 768</ms:GML_ID>
        <ms:NAZWA>204 001 768</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>204001768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5637">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>685652.945389 484497.442841</gml:lowerCorner>
        		<gml:upperCorner>685652.945389 484497.442841</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5637.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>685652.945389 484497.442841</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5637</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 490 753</ms:GML_ID>
        <ms:NAZWA>131 490 753</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131490753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5638">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>686465.375544 484527.223685</gml:lowerCorner>
        		<gml:upperCorner>686465.375544 484527.223685</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5638.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>686465.375544 484527.223685</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5638</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 491 572</ms:GML_ID>
        <ms:NAZWA>131 491 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131491572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347256.094000 511140.099000</gml:lowerCorner>
        		<gml:upperCorner>347256.094000 511140.099000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347256.094000 511140.099000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 015 169</ms:GML_ID>
        <ms:NAZWA>146 015 169</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146015169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346253.190000 511283.623000</gml:lowerCorner>
        		<gml:upperCorner>346253.190000 511283.623000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346253.190000 511283.623000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 014 157</ms:GML_ID>
        <ms:NAZWA>146 014 157</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146014157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344117.756000 511476.656000</gml:lowerCorner>
        		<gml:upperCorner>344117.756000 511476.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344117.756000 511476.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 012 008</ms:GML_ID>
        <ms:NAZWA>146 012 008</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146012008</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5112">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342875.621000 511883.708000</gml:lowerCorner>
        		<gml:upperCorner>342875.621000 511883.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5112.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342875.621000 511883.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5112</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 010 668</ms:GML_ID>
        <ms:NAZWA>146 010 668</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146010668</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5111">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342560.062000 512101.067000</gml:lowerCorner>
        		<gml:upperCorner>342560.062000 512101.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5111.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342560.062000 512101.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5111</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 010 284</ms:GML_ID>
        <ms:NAZWA>146 010 284</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146010284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5110">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342460.293000 512169.512000</gml:lowerCorner>
        		<gml:upperCorner>342460.293000 512169.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5110.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342460.293000 512169.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5110</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 010 163</ms:GML_ID>
        <ms:NAZWA>146 010 163</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146010163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5109">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339910.027000 512586.847000</gml:lowerCorner>
        		<gml:upperCorner>339910.027000 512586.847000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5109.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339910.027000 512586.847000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5109</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 007 560</ms:GML_ID>
        <ms:NAZWA>146 007 560</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146007560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5107">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337762.002000 512711.685000</gml:lowerCorner>
        		<gml:upperCorner>337762.002000 512711.685000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5107.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337762.002000 512711.685000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5107</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 005 402</ms:GML_ID>
        <ms:NAZWA>146 005 402</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146005402</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5108">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338788.371000 512715.049000</gml:lowerCorner>
        		<gml:upperCorner>338788.371000 512715.049000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5108.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338788.371000 512715.049000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5108</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 006 430</ms:GML_ID>
        <ms:NAZWA>146 006 430</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146006430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336820.579000 523206.931000</gml:lowerCorner>
        		<gml:upperCorner>336820.579000 523206.931000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336820.579000 523206.931000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 210 478</ms:GML_ID>
        <ms:NAZWA>001 210 478</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001210478</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340099.298000 524206.362000</gml:lowerCorner>
        		<gml:upperCorner>340099.298000 524206.362000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340099.298000 524206.362000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 206 928</ms:GML_ID>
        <ms:NAZWA>001 206 928</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001206928</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342461.326000 524593.857000</gml:lowerCorner>
        		<gml:upperCorner>342461.326000 524593.857000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342461.326000 524593.857000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 204 532</ms:GML_ID>
        <ms:NAZWA>001 204 532</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001204532</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344329.553000 524927.765000</gml:lowerCorner>
        		<gml:upperCorner>344329.553000 524927.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344329.553000 524927.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 202 632</ms:GML_ID>
        <ms:NAZWA>001 202 632</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001202632</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345203.101000 525334.027000</gml:lowerCorner>
        		<gml:upperCorner>345203.101000 525334.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345203.101000 525334.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 201 669</ms:GML_ID>
        <ms:NAZWA>001 201 669</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001201669</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345820.128000 525637.560000</gml:lowerCorner>
        		<gml:upperCorner>345820.128000 525637.560000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345820.128000 525637.560000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 200 981</ms:GML_ID>
        <ms:NAZWA>001 200 981</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001200981</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347254.353050 526341.022936</gml:lowerCorner>
        		<gml:upperCorner>347254.353050 526341.022936</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347254.353050 526341.022936</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 199 380</ms:GML_ID>
        <ms:NAZWA>001 199 380</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001199380</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350795.514000 528080.166000</gml:lowerCorner>
        		<gml:upperCorner>350795.514000 528080.166000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350795.514000 528080.166000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 195 428</ms:GML_ID>
        <ms:NAZWA>001 195 428</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001195428</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351302.867000 528328.951000</gml:lowerCorner>
        		<gml:upperCorner>351302.867000 528328.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351302.867000 528328.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 194 868</ms:GML_ID>
        <ms:NAZWA>001 194 868</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001194868</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354409.338000 529850.897000</gml:lowerCorner>
        		<gml:upperCorner>354409.338000 529850.897000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354409.338000 529850.897000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 191 407</ms:GML_ID>
        <ms:NAZWA>001 191 407</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001191407</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355140.951000 530208.938000</gml:lowerCorner>
        		<gml:upperCorner>355140.951000 530208.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355140.951000 530208.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 190 592</ms:GML_ID>
        <ms:NAZWA>001 190 592</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001190592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359638.100000 530438.108000</gml:lowerCorner>
        		<gml:upperCorner>359638.100000 530438.108000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359638.100000 530438.108000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 185 992</ms:GML_ID>
        <ms:NAZWA>001 185 992</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001185992</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360464.267000 530484.175000</gml:lowerCorner>
        		<gml:upperCorner>360464.267000 530484.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360464.267000 530484.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 185 159</ms:GML_ID>
        <ms:NAZWA>001 185 159</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001185159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358429.194927 530518.672659</gml:lowerCorner>
        		<gml:upperCorner>358429.194927 530518.672659</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358429.194927 530518.672659</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 187 207</ms:GML_ID>
        <ms:NAZWA>001 187 207</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001187207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355907.474000 530575.307000</gml:lowerCorner>
        		<gml:upperCorner>355907.474000 530575.307000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355907.474000 530575.307000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 189 742</ms:GML_ID>
        <ms:NAZWA>001 189 742</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001189742</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357250.777000 530591.875000</gml:lowerCorner>
        		<gml:upperCorner>357250.777000 530591.875000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357250.777000 530591.875000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 188 377</ms:GML_ID>
        <ms:NAZWA>001 188 377</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001188377</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356268.198000 530649.505000</gml:lowerCorner>
        		<gml:upperCorner>356268.198000 530649.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356268.198000 530649.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 189 372</ms:GML_ID>
        <ms:NAZWA>001 189 372</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001189372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6658">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288443.383000 509220.481000</gml:lowerCorner>
        		<gml:upperCorner>288443.383000 509220.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6658.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288443.383000 509220.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6658</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 022 106</ms:GML_ID>
        <ms:NAZWA>182 022 106</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182022106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288861.499282 506040.213246</gml:lowerCorner>
        		<gml:upperCorner>288861.499282 506040.213246</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288861.499282 506040.213246</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 018 877</ms:GML_ID>
        <ms:NAZWA>182 018 877</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182018877</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289569.989000 530129.314000</gml:lowerCorner>
        		<gml:upperCorner>289569.989000 530129.314000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289569.989000 530129.314000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 275 260</ms:GML_ID>
        <ms:NAZWA>001 275 260</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001275260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6660">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289826.925000 514698.684000</gml:lowerCorner>
        		<gml:upperCorner>289826.925000 514698.684000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6660.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289826.925000 514698.684000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6660</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 027 855</ms:GML_ID>
        <ms:NAZWA>182 027 855</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182027855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8659">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289997.489344 530520.240456</gml:lowerCorner>
        		<gml:upperCorner>289997.489344 530520.240456</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8659.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289997.489344 530520.240456</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8659</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 274 820</ms:GML_ID>
        <ms:NAZWA>001 274 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>boczny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001274820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290039.250349 525476.389362</gml:lowerCorner>
        		<gml:upperCorner>290039.250349 525476.389362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290039.250349 525476.389362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 039 074</ms:GML_ID>
        <ms:NAZWA>182 039 074</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182039074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6661">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290346.621310 517103.752911</gml:lowerCorner>
        		<gml:upperCorner>290346.621310 517103.752911</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6661.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290346.621310 517103.752911</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6661</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 030 327</ms:GML_ID>
        <ms:NAZWA>182 030 327</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182030327</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6662">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290615.943264 517998.400471</gml:lowerCorner>
        		<gml:upperCorner>290615.943264 517998.400471</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6662.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290615.943264 517998.400471</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6662</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 031 265</ms:GML_ID>
        <ms:NAZWA>182 031 265</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182031265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6667">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290783.608000 523794.818000</gml:lowerCorner>
        		<gml:upperCorner>290783.608000 523794.818000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6667.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290783.608000 523794.818000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6667</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 037 226</ms:GML_ID>
        <ms:NAZWA>182 037 226</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182037226</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6666">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290888.382213 522966.699399</gml:lowerCorner>
        		<gml:upperCorner>290888.382213 522966.699399</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6666.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290888.382213 522966.699399</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6666</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 036 219</ms:GML_ID>
        <ms:NAZWA>182 036 219</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182036219</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6665">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290961.364000 522252.470000</gml:lowerCorner>
        		<gml:upperCorner>290961.364000 522252.470000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6665.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290961.364000 522252.470000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6665</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 035 671</ms:GML_ID>
        <ms:NAZWA>182 035 671</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182035671</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6663">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290985.483000 520829.371000</gml:lowerCorner>
        		<gml:upperCorner>290985.483000 520829.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6663.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290985.483000 520829.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6663</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 034 190</ms:GML_ID>
        <ms:NAZWA>182 034 190</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182034190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6664">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291129.484000 521289.497000</gml:lowerCorner>
        		<gml:upperCorner>291129.484000 521289.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6664.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291129.484000 521289.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6664</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 034 673</ms:GML_ID>
        <ms:NAZWA>182 034 673</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182034673</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8635">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299846.453000 525581.052000</gml:lowerCorner>
        		<gml:upperCorner>299846.453000 525581.052000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8635.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299846.453000 525581.052000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8635</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 263 570</ms:GML_ID>
        <ms:NAZWA>001 263 570</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001263570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8634">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300278.028000 524601.643000</gml:lowerCorner>
        		<gml:upperCorner>300278.028000 524601.643000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8634.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300278.028000 524601.643000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8634</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 262 508</ms:GML_ID>
        <ms:NAZWA>001 262 508</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001262508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303005.851000 520694.704000</gml:lowerCorner>
        		<gml:upperCorner>303005.851000 520694.704000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303005.851000 520694.704000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 257 663</ms:GML_ID>
        <ms:NAZWA>001 257 663</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001257663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306179.054000 519339.706000</gml:lowerCorner>
        		<gml:upperCorner>306179.054000 519339.706000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306179.054000 519339.706000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 254 212</ms:GML_ID>
        <ms:NAZWA>001 254 212</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001254212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308403.149000 518438.378000</gml:lowerCorner>
        		<gml:upperCorner>308403.149000 518438.378000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308403.149000 518438.378000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 251 807</ms:GML_ID>
        <ms:NAZWA>001 251 807</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001251807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309257.852000 517980.730000</gml:lowerCorner>
        		<gml:upperCorner>309257.852000 517980.730000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309257.852000 517980.730000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 250 834</ms:GML_ID>
        <ms:NAZWA>001 250 834</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001250834</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311312.705000 516256.042000</gml:lowerCorner>
        		<gml:upperCorner>311312.705000 516256.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311312.705000 516256.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 248 147</ms:GML_ID>
        <ms:NAZWA>001 248 147</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001248147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312419.849000 515320.081000</gml:lowerCorner>
        		<gml:upperCorner>312419.849000 515320.081000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312419.849000 515320.081000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 246 697</ms:GML_ID>
        <ms:NAZWA>001 246 697</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001246697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313986.966000 513995.473000</gml:lowerCorner>
        		<gml:upperCorner>313986.966000 513995.473000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313986.966000 513995.473000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 244 646</ms:GML_ID>
        <ms:NAZWA>001 244 646</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001244646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317809.740000 512662.417000</gml:lowerCorner>
        		<gml:upperCorner>317809.740000 512662.417000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317809.740000 512662.417000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 240 494</ms:GML_ID>
        <ms:NAZWA>001 240 494</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001240494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319169.819000 512441.456000</gml:lowerCorner>
        		<gml:upperCorner>319169.819000 512441.456000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319169.819000 512441.456000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 239 116</ms:GML_ID>
        <ms:NAZWA>001 239 116</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001239116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320337.111000 512252.076000</gml:lowerCorner>
        		<gml:upperCorner>320337.111000 512252.076000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320337.111000 512252.076000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 237 929</ms:GML_ID>
        <ms:NAZWA>001 237 929</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>001237929</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321011.737000 524715.804000</gml:lowerCorner>
        		<gml:upperCorner>321011.737000 524715.804000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321011.737000 524715.804000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 096 725</ms:GML_ID>
        <ms:NAZWA>061 096 725</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061096725</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321411.067000 523439.459000</gml:lowerCorner>
        		<gml:upperCorner>321411.067000 523439.459000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321411.067000 523439.459000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 098 156</ms:GML_ID>
        <ms:NAZWA>061 098 156</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061098156</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321611.322000 527860.180000</gml:lowerCorner>
        		<gml:upperCorner>321611.322000 527860.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321611.322000 527860.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 093 454</ms:GML_ID>
        <ms:NAZWA>061 093 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061093454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321632.414000 526888.631000</gml:lowerCorner>
        		<gml:upperCorner>321632.414000 526888.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321632.414000 526888.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 094 426</ms:GML_ID>
        <ms:NAZWA>061 094 426</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061094426</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321733.483000 530022.466000</gml:lowerCorner>
        		<gml:upperCorner>321733.483000 530022.466000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321733.483000 530022.466000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 091 252</ms:GML_ID>
        <ms:NAZWA>061 091 252</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061091252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5133">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368000.946000 499261.452000</gml:lowerCorner>
        		<gml:upperCorner>368000.946000 499261.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5133.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368000.946000 499261.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5133</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 042 035</ms:GML_ID>
        <ms:NAZWA>146 042 035</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146042035</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5132">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367815.052000 500434.924000</gml:lowerCorner>
        		<gml:upperCorner>367815.052000 500434.924000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5132.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367815.052000 500434.924000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5132</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 040 850</ms:GML_ID>
        <ms:NAZWA>146 040 850</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146040850</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5131">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367599.334000 501795.436000</gml:lowerCorner>
        		<gml:upperCorner>367599.334000 501795.436000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5131.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367599.334000 501795.436000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5131</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 039 470</ms:GML_ID>
        <ms:NAZWA>146 039 470</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146039470</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5130">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>367411.115000 502472.736000</gml:lowerCorner>
        		<gml:upperCorner>367411.115000 502472.736000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5130.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>367411.115000 502472.736000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5130</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 038 772</ms:GML_ID>
        <ms:NAZWA>146 038 772</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146038772</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366961.885000 503359.088000</gml:lowerCorner>
        		<gml:upperCorner>366961.885000 503359.088000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366961.885000 503359.088000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 037 765</ms:GML_ID>
        <ms:NAZWA>146 037 765</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146037765</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366739.134000 503798.750000</gml:lowerCorner>
        		<gml:upperCorner>366739.134000 503798.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366739.134000 503798.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 037 275</ms:GML_ID>
        <ms:NAZWA>146 037 275</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146037275</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5127">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365921.675000 505207.443000</gml:lowerCorner>
        		<gml:upperCorner>365921.675000 505207.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5127.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365921.675000 505207.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5127</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 035 644</ms:GML_ID>
        <ms:NAZWA>146 035 644</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146035644</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5126">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361520.186000 508754.651000</gml:lowerCorner>
        		<gml:upperCorner>361520.186000 508754.651000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5126.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361520.186000 508754.651000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5126</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 029 951</ms:GML_ID>
        <ms:NAZWA>146 029 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146029951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386333.856052 524943.596163</gml:lowerCorner>
        		<gml:upperCorner>386333.856052 524943.596163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386333.856052 524943.596163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 027 886</ms:GML_ID>
        <ms:NAZWA>024 027 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024027886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361935.199000 531042.642000</gml:lowerCorner>
        		<gml:upperCorner>361935.199000 531042.642000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361935.199000 531042.642000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 183 573</ms:GML_ID>
        <ms:NAZWA>001 183 573</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001183573</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363269.762000 531806.933000</gml:lowerCorner>
        		<gml:upperCorner>363269.762000 531806.933000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363269.762000 531806.933000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 182 016</ms:GML_ID>
        <ms:NAZWA>001 182 016</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001182016</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363856.840000 533076.220000</gml:lowerCorner>
        		<gml:upperCorner>363856.840000 533076.220000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363856.840000 533076.220000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 180 613</ms:GML_ID>
        <ms:NAZWA>001 180 613</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001180613</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364956.414000 533793.398000</gml:lowerCorner>
        		<gml:upperCorner>364956.414000 533793.398000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364956.414000 533793.398000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 179 259</ms:GML_ID>
        <ms:NAZWA>001 179 259</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001179259</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366531.834000 534042.061000</gml:lowerCorner>
        		<gml:upperCorner>366531.834000 534042.061000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366531.834000 534042.061000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 177 664</ms:GML_ID>
        <ms:NAZWA>001 177 664</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001177664</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368883.222000 534747.505000</gml:lowerCorner>
        		<gml:upperCorner>368883.222000 534747.505000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368883.222000 534747.505000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 175 140</ms:GML_ID>
        <ms:NAZWA>001 175 140</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001175140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8371">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369415.127000 536025.288000</gml:lowerCorner>
        		<gml:upperCorner>369415.127000 536025.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8371.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369415.127000 536025.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8371</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 173 753</ms:GML_ID>
        <ms:NAZWA>001 173 753</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001173753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387187.151000 537357.311000</gml:lowerCorner>
        		<gml:upperCorner>387187.151000 537357.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387187.151000 537357.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 015 088</ms:GML_ID>
        <ms:NAZWA>024 015 088</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024015088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369964.062000 537447.101000</gml:lowerCorner>
        		<gml:upperCorner>369964.062000 537447.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369964.062000 537447.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 172 228</ms:GML_ID>
        <ms:NAZWA>001 172 228</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001172228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370213.788000 538091.887000</gml:lowerCorner>
        		<gml:upperCorner>370213.788000 538091.887000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370213.788000 538091.887000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 171 538</ms:GML_ID>
        <ms:NAZWA>001 171 538</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001171538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370794.226856 539594.655683</gml:lowerCorner>
        		<gml:upperCorner>370794.226856 539594.655683</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370794.226856 539594.655683</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 169 925</ms:GML_ID>
        <ms:NAZWA>001 169 925</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001169925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371370.912000 541077.304000</gml:lowerCorner>
        		<gml:upperCorner>371370.912000 541077.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371370.912000 541077.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 168 333</ms:GML_ID>
        <ms:NAZWA>001 168 333</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001168333</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372173.035000 541745.050000</gml:lowerCorner>
        		<gml:upperCorner>372173.035000 541745.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372173.035000 541745.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 167 260</ms:GML_ID>
        <ms:NAZWA>001 167 260</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001167260</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372480.737000 542021.794000</gml:lowerCorner>
        		<gml:upperCorner>372480.737000 542021.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372480.737000 542021.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 166 845</ms:GML_ID>
        <ms:NAZWA>001 166 845</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001166845</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374140.513000 543044.665000</gml:lowerCorner>
        		<gml:upperCorner>374140.513000 543044.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374140.513000 543044.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 164 871</ms:GML_ID>
        <ms:NAZWA>001 164 871</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001164871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375741.377000 543743.485000</gml:lowerCorner>
        		<gml:upperCorner>375741.377000 543743.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375741.377000 543743.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 163 121</ms:GML_ID>
        <ms:NAZWA>001 163 121</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001163121</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376398.656000 544029.741000</gml:lowerCorner>
        		<gml:upperCorner>376398.656000 544029.741000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376398.656000 544029.741000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 162 404</ms:GML_ID>
        <ms:NAZWA>001 162 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001162404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378173.440000 544805.908000</gml:lowerCorner>
        		<gml:upperCorner>378173.440000 544805.908000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378173.440000 544805.908000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 160 467</ms:GML_ID>
        <ms:NAZWA>001 160 467</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001160467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379252.240000 545218.432000</gml:lowerCorner>
        		<gml:upperCorner>379252.240000 545218.432000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379252.240000 545218.432000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 159 308</ms:GML_ID>
        <ms:NAZWA>001 159 308</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001159308</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380080.610000 545349.740000</gml:lowerCorner>
        		<gml:upperCorner>380080.610000 545349.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380080.610000 545349.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 158 468</ms:GML_ID>
        <ms:NAZWA>001 158 468</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001158468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380950.271000 545579.258000</gml:lowerCorner>
        		<gml:upperCorner>380950.271000 545579.258000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380950.271000 545579.258000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 157 565</ms:GML_ID>
        <ms:NAZWA>001 157 565</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001157565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381624.640463 545889.437664</gml:lowerCorner>
        		<gml:upperCorner>381624.640463 545889.437664</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381624.640463 545889.437664</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 156 824</ms:GML_ID>
        <ms:NAZWA>001 156 824</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001156824</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8356">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383382.805000 546615.042000</gml:lowerCorner>
        		<gml:upperCorner>383382.805000 546615.042000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8356.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383382.805000 546615.042000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8356</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 154 910</ms:GML_ID>
        <ms:NAZWA>001 154 910</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001154910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8355">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386779.148356 546934.391356</gml:lowerCorner>
        		<gml:upperCorner>386779.148356 546934.391356</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8355.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386779.148356 546934.391356</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8355</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.001 151 497</ms:GML_ID>
        <ms:NAZWA>001 151 497</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>001151497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372947.235000 496133.098000</gml:lowerCorner>
        		<gml:upperCorner>372947.235000 496133.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372947.235000 496133.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 125 662</ms:GML_ID>
        <ms:NAZWA>131 125 662</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131125662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373689.088000 496650.427000</gml:lowerCorner>
        		<gml:upperCorner>373689.088000 496650.427000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373689.088000 496650.427000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 126 565</ms:GML_ID>
        <ms:NAZWA>131 126 565</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131126565</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>368342.657000 497110.288000</gml:lowerCorner>
        		<gml:upperCorner>368342.657000 497110.288000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>368342.657000 497110.288000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 044 235</ms:GML_ID>
        <ms:NAZWA>146 044 235</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146044235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374641.384000 497245.065000</gml:lowerCorner>
        		<gml:upperCorner>374641.384000 497245.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374641.384000 497245.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 127 693</ms:GML_ID>
        <ms:NAZWA>131 127 693</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131127693</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375068.076000 497290.644000</gml:lowerCorner>
        		<gml:upperCorner>375068.076000 497290.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375068.076000 497290.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 128 123</ms:GML_ID>
        <ms:NAZWA>131 128 123</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131128123</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376408.403000 497358.161000</gml:lowerCorner>
        		<gml:upperCorner>376408.403000 497358.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376408.403000 497358.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 129 467</ms:GML_ID>
        <ms:NAZWA>131 129 467</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131129467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377786.416000 497427.501000</gml:lowerCorner>
        		<gml:upperCorner>377786.416000 497427.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377786.416000 497427.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 130 847</ms:GML_ID>
        <ms:NAZWA>131 130 847</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131130847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378119.437288 497444.100176</gml:lowerCorner>
        		<gml:upperCorner>378119.437288 497444.100176</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378119.437288 497444.100176</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 131 187</ms:GML_ID>
        <ms:NAZWA>131 131 187</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131131187</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378667.801000 497471.443000</gml:lowerCorner>
        		<gml:upperCorner>378667.801000 497471.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378667.801000 497471.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 131 730</ms:GML_ID>
        <ms:NAZWA>131 131 730</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131131730</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379306.572000 497503.776000</gml:lowerCorner>
        		<gml:upperCorner>379306.572000 497503.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379306.572000 497503.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 132 370</ms:GML_ID>
        <ms:NAZWA>131 132 370</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131132370</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380272.320000 497552.297000</gml:lowerCorner>
        		<gml:upperCorner>380272.320000 497552.297000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380272.320000 497552.297000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 133 339</ms:GML_ID>
        <ms:NAZWA>131 133 339</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131133339</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380823.224000 497579.677000</gml:lowerCorner>
        		<gml:upperCorner>380823.224000 497579.677000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380823.224000 497579.677000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 133 905</ms:GML_ID>
        <ms:NAZWA>131 133 905</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131133905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381815.712000 497629.814000</gml:lowerCorner>
        		<gml:upperCorner>381815.712000 497629.814000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381815.712000 497629.814000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 134 886</ms:GML_ID>
        <ms:NAZWA>131 134 886</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131134886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382418.179000 497718.321000</gml:lowerCorner>
        		<gml:upperCorner>382418.179000 497718.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382418.179000 497718.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 135 494</ms:GML_ID>
        <ms:NAZWA>131 135 494</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131135494</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>383766.153000 497930.189000</gml:lowerCorner>
        		<gml:upperCorner>383766.153000 497930.189000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>383766.153000 497930.189000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 136 858</ms:GML_ID>
        <ms:NAZWA>131 136 858</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131136858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384763.768000 498087.213000</gml:lowerCorner>
        		<gml:upperCorner>384763.768000 498087.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384763.768000 498087.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 137 872</ms:GML_ID>
        <ms:NAZWA>131 137 872</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131137872</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>385962.386073 498533.332860</gml:lowerCorner>
        		<gml:upperCorner>385962.386073 498533.332860</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>385962.386073 498533.332860</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 139 153</ms:GML_ID>
        <ms:NAZWA>131 139 153</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131139153</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5462">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386827.114000 498664.247000</gml:lowerCorner>
        		<gml:upperCorner>386827.114000 498664.247000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5462.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386827.114000 498664.247000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5462</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 140 031</ms:GML_ID>
        <ms:NAZWA>131 140 031</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131140031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337165.874000 494599.478000</gml:lowerCorner>
        		<gml:upperCorner>337165.874000 494599.478000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337165.874000 494599.478000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 088 487</ms:GML_ID>
        <ms:NAZWA>131 088 487</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131088487</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339161.559000 494617.648000</gml:lowerCorner>
        		<gml:upperCorner>339161.559000 494617.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339161.559000 494617.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 090 489</ms:GML_ID>
        <ms:NAZWA>131 090 489</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131090489</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357091.388764 494757.069912</gml:lowerCorner>
        		<gml:upperCorner>357091.388764 494757.069912</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357091.388764 494757.069912</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 109 005</ms:GML_ID>
        <ms:NAZWA>131 109 005</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131109005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346600.181000 495618.675000</gml:lowerCorner>
        		<gml:upperCorner>346600.181000 495618.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346600.181000 495618.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 098 001</ms:GML_ID>
        <ms:NAZWA>131 098 001</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131098001</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354562.449175 495720.421421</gml:lowerCorner>
        		<gml:upperCorner>354562.449175 495720.421421</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354562.449175 495720.421421</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 106 173</ms:GML_ID>
        <ms:NAZWA>131 106 173</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131106173</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352709.219000 495861.828000</gml:lowerCorner>
        		<gml:upperCorner>352709.219000 495861.828000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352709.219000 495861.828000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 104 313</ms:GML_ID>
        <ms:NAZWA>131 104 313</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131104313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352562.153000 495873.634000</gml:lowerCorner>
        		<gml:upperCorner>352562.153000 495873.634000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352562.153000 495873.634000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 104 163</ms:GML_ID>
        <ms:NAZWA>131 104 163</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131104163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5125">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360417.187000 509558.938000</gml:lowerCorner>
        		<gml:upperCorner>360417.187000 509558.938000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5125.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360417.187000 509558.938000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5125</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 028 584</ms:GML_ID>
        <ms:NAZWA>146 028 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146028584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5124">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359603.204000 509982.895000</gml:lowerCorner>
        		<gml:upperCorner>359603.204000 509982.895000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5124.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359603.204000 509982.895000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5124</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 027 659</ms:GML_ID>
        <ms:NAZWA>146 027 659</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146027659</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358497.610000 510259.441000</gml:lowerCorner>
        		<gml:upperCorner>358497.610000 510259.441000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358497.610000 510259.441000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 026 505</ms:GML_ID>
        <ms:NAZWA>146 026 505</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146026505</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357025.580000 510264.898000</gml:lowerCorner>
        		<gml:upperCorner>357025.580000 510264.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357025.580000 510264.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 025 033</ms:GML_ID>
        <ms:NAZWA>146 025 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146025033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356454.628000 510266.930000</gml:lowerCorner>
        		<gml:upperCorner>356454.628000 510266.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356454.628000 510266.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 024 462</ms:GML_ID>
        <ms:NAZWA>146 024 462</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146024462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354266.447000 510275.371000</gml:lowerCorner>
        		<gml:upperCorner>354266.447000 510275.371000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354266.447000 510275.371000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 022 271</ms:GML_ID>
        <ms:NAZWA>146 022 271</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146022271</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353346.695000 510278.797000</gml:lowerCorner>
        		<gml:upperCorner>353346.695000 510278.797000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353346.695000 510278.797000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 021 349</ms:GML_ID>
        <ms:NAZWA>146 021 349</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146021349</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352424.088630 510282.634948</gml:lowerCorner>
        		<gml:upperCorner>352424.088630 510282.634948</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352424.088630 510282.634948</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 020 425</ms:GML_ID>
        <ms:NAZWA>146 020 425</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146020425</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350384.295000 510467.555000</gml:lowerCorner>
        		<gml:upperCorner>350384.295000 510467.555000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350384.295000 510467.555000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 018 376</ms:GML_ID>
        <ms:NAZWA>146 018 376</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146018376</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348255.381000 510888.624000</gml:lowerCorner>
        		<gml:upperCorner>348255.381000 510888.624000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348255.381000 510888.624000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 016 199</ms:GML_ID>
        <ms:NAZWA>146 016 199</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146016199</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415860.908145 491591.445720</gml:lowerCorner>
        		<gml:upperCorner>415860.908145 491591.445720</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415860.908145 491591.445720</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 047 106</ms:GML_ID>
        <ms:NAZWA>014 047 106</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014047106</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415886.885540 493034.307065</gml:lowerCorner>
        		<gml:upperCorner>415886.885540 493034.307065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415886.885540 493034.307065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 045 658</ms:GML_ID>
        <ms:NAZWA>014 045 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014045658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>438786.600000 493488.844000</gml:lowerCorner>
        		<gml:upperCorner>438786.600000 493488.844000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>438786.600000 493488.844000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 195 642</ms:GML_ID>
        <ms:NAZWA>131 195 642</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131195642</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>437524.466000 493608.229000</gml:lowerCorner>
        		<gml:upperCorner>437524.466000 493608.229000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>437524.466000 493608.229000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 194 375</ms:GML_ID>
        <ms:NAZWA>131 194 375</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131194375</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436674.554000 493689.404000</gml:lowerCorner>
        		<gml:upperCorner>436674.554000 493689.404000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436674.554000 493689.404000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 193 519</ms:GML_ID>
        <ms:NAZWA>131 193 519</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131193519</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442012.951000 493702.913000</gml:lowerCorner>
        		<gml:upperCorner>442012.951000 493702.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442012.951000 493702.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 198 910</ms:GML_ID>
        <ms:NAZWA>131 198 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131198910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442883.956000 493880.935000</gml:lowerCorner>
        		<gml:upperCorner>442883.956000 493880.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442883.956000 493880.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 199 800</ms:GML_ID>
        <ms:NAZWA>131 199 800</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131199800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443797.189000 494068.002000</gml:lowerCorner>
        		<gml:upperCorner>443797.189000 494068.002000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443797.189000 494068.002000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 200 734</ms:GML_ID>
        <ms:NAZWA>131 200 734</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131200734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448201.427000 495684.898000</gml:lowerCorner>
        		<gml:upperCorner>448201.427000 495684.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448201.427000 495684.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 205 511</ms:GML_ID>
        <ms:NAZWA>131 205 511</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131205511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449247.300000 495834.195000</gml:lowerCorner>
        		<gml:upperCorner>449247.300000 495834.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449247.300000 495834.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 206 568</ms:GML_ID>
        <ms:NAZWA>131 206 568</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131206568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429522.158949 496229.093864</gml:lowerCorner>
        		<gml:upperCorner>429522.158949 496229.093864</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429522.158949 496229.093864</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 185 886</ms:GML_ID>
        <ms:NAZWA>131 185 886</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131185886</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5482">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428369.878691 496648.409756</gml:lowerCorner>
        		<gml:upperCorner>428369.878691 496648.409756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5482.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428369.878691 496648.409756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5482</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 184 658</ms:GML_ID>
        <ms:NAZWA>131 184 658</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131184658</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5481">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426460.917000 497168.761000</gml:lowerCorner>
        		<gml:upperCorner>426460.917000 497168.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5481.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426460.917000 497168.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5481</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 182 656</ms:GML_ID>
        <ms:NAZWA>131 182 656</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131182656</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424110.231000 497271.982000</gml:lowerCorner>
        		<gml:upperCorner>424110.231000 497271.982000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424110.231000 497271.982000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 180 283</ms:GML_ID>
        <ms:NAZWA>131 180 283</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131180283</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7239">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418531.646369 517395.097443</gml:lowerCorner>
        		<gml:upperCorner>418531.646369 517395.097443</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7239.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418531.646369 517395.097443</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7239</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 020 474</ms:GML_ID>
        <ms:NAZWA>014 020 474</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014020474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7238">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419411.756698 518986.582602</gml:lowerCorner>
        		<gml:upperCorner>419411.756698 518986.582602</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7238.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419411.756698 518986.582602</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7238</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 018 653</ms:GML_ID>
        <ms:NAZWA>014 018 653</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014018653</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419870.006000 519814.269000</gml:lowerCorner>
        		<gml:upperCorner>419870.006000 519814.269000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419870.006000 519814.269000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 017 706</ms:GML_ID>
        <ms:NAZWA>014 017 706</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014017706</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420352.186358 520592.057147</gml:lowerCorner>
        		<gml:upperCorner>420352.186358 520592.057147</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420352.186358 520592.057147</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 016 790</ms:GML_ID>
        <ms:NAZWA>014 016 790</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014016790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447695.890414 521134.976660</gml:lowerCorner>
        		<gml:upperCorner>447695.890414 521134.976660</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447695.890414 521134.976660</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 026 184</ms:GML_ID>
        <ms:NAZWA>016 026 184</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016026184</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420847.708259 521364.193363</gml:lowerCorner>
        		<gml:upperCorner>420847.708259 521364.193363</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420847.708259 521364.193363</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 015 871</ms:GML_ID>
        <ms:NAZWA>014 015 871</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014015871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>445768.151718 521645.361491</gml:lowerCorner>
        		<gml:upperCorner>445768.151718 521645.361491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>445768.151718 521645.361491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 024 169</ms:GML_ID>
        <ms:NAZWA>016 024 169</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016024169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444746.181000 522164.641000</gml:lowerCorner>
        		<gml:upperCorner>444746.181000 522164.641000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444746.181000 522164.641000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 023 005</ms:GML_ID>
        <ms:NAZWA>016 023 005</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016023005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7234">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421513.788069 522312.011194</gml:lowerCorner>
        		<gml:upperCorner>421513.788069 522312.011194</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7234.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421513.788069 522312.011194</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7234</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 014 709</ms:GML_ID>
        <ms:NAZWA>014 014 709</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014014709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422207.014700 523160.364824</gml:lowerCorner>
        		<gml:upperCorner>422207.014700 523160.364824</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422207.014700 523160.364824</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 013 622</ms:GML_ID>
        <ms:NAZWA>014 013 622</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014013622</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7232">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422755.283837 523681.314647</gml:lowerCorner>
        		<gml:upperCorner>422755.283837 523681.314647</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7232.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422755.283837 523681.314647</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7232</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 012 846</ms:GML_ID>
        <ms:NAZWA>014 012 846</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014012846</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7231">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424093.798294 523834.101966</gml:lowerCorner>
        		<gml:upperCorner>424093.798294 523834.101966</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7231.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424093.798294 523834.101966</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7231</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 011 497</ms:GML_ID>
        <ms:NAZWA>014 011 497</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014011497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7230">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424475.104747 523871.550414</gml:lowerCorner>
        		<gml:upperCorner>424475.104747 523871.550414</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7230.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424475.104747 523871.550414</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7230</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 011 114</ms:GML_ID>
        <ms:NAZWA>014 011 114</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014011114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7229">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425357.879468 523958.310786</gml:lowerCorner>
        		<gml:upperCorner>425357.879468 523958.310786</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7229.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425357.879468 523958.310786</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7229</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 010 225</ms:GML_ID>
        <ms:NAZWA>014 010 225</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014010225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7228">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426163.245009 524037.391651</gml:lowerCorner>
        		<gml:upperCorner>426163.245009 524037.391651</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7228.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426163.245009 524037.391651</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7228</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 009 415</ms:GML_ID>
        <ms:NAZWA>014 009 415</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014009415</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7227">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427416.583157 524120.017073</gml:lowerCorner>
        		<gml:upperCorner>427416.583157 524120.017073</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7227.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427416.583157 524120.017073</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7227</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 008 157</ms:GML_ID>
        <ms:NAZWA>014 008 157</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014008157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7226">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428211.396996 524716.161360</gml:lowerCorner>
        		<gml:upperCorner>428211.396996 524716.161360</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7226.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428211.396996 524716.161360</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7226</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 007 159</ms:GML_ID>
        <ms:NAZWA>014 007 159</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014007159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325319.226000 490670.816000</gml:lowerCorner>
        		<gml:upperCorner>325319.226000 490670.816000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325319.226000 490670.816000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 075 515</ms:GML_ID>
        <ms:NAZWA>131 075 515</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131075515</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326469.872000 491148.205000</gml:lowerCorner>
        		<gml:upperCorner>326469.872000 491148.205000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326469.872000 491148.205000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 076 760</ms:GML_ID>
        <ms:NAZWA>131 076 760</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131076760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326903.279000 491456.019000</gml:lowerCorner>
        		<gml:upperCorner>326903.279000 491456.019000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326903.279000 491456.019000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 077 294</ms:GML_ID>
        <ms:NAZWA>131 077 294</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131077294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330177.578000 492408.592000</gml:lowerCorner>
        		<gml:upperCorner>330177.578000 492408.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330177.578000 492408.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 080 854</ms:GML_ID>
        <ms:NAZWA>131 080 854</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131080854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336064.558000 494251.085000</gml:lowerCorner>
        		<gml:upperCorner>336064.558000 494251.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336064.558000 494251.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 087 330</ms:GML_ID>
        <ms:NAZWA>131 087 330</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131087330</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10848">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322056.108000 495634.167000</gml:lowerCorner>
        		<gml:upperCorner>322056.108000 495634.167000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10848.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322056.108000 495634.167000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10848</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 130 081</ms:GML_ID>
        <ms:NAZWA>061 130 081</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061130081</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10847">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322148.966000 496025.202000</gml:lowerCorner>
        		<gml:upperCorner>322148.966000 496025.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10847.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322148.966000 496025.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10847</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 129 678</ms:GML_ID>
        <ms:NAZWA>061 129 678</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061129678</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10846">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322372.190000 496554.033000</gml:lowerCorner>
        		<gml:upperCorner>322372.190000 496554.033000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10846.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322372.190000 496554.033000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10846</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 129 100</ms:GML_ID>
        <ms:NAZWA>061 129 100</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061129100</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10845">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322933.322932 497725.190390</gml:lowerCorner>
        		<gml:upperCorner>322933.322932 497725.190390</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10845.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322933.322932 497725.190390</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10845</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 127 800</ms:GML_ID>
        <ms:NAZWA>061 127 800</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061127800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10844">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323252.658000 498398.648000</gml:lowerCorner>
        		<gml:upperCorner>323252.658000 498398.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10844.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323252.658000 498398.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10844</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 127 060</ms:GML_ID>
        <ms:NAZWA>061 127 060</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061127060</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10843">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323432.065000 498776.967000</gml:lowerCorner>
        		<gml:upperCorner>323432.065000 498776.967000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10843.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323432.065000 498776.967000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10843</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 126 637</ms:GML_ID>
        <ms:NAZWA>061 126 637</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061126637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10842">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323858.780000 499677.027000</gml:lowerCorner>
        		<gml:upperCorner>323858.780000 499677.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10842.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323858.780000 499677.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10842</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 125 630</ms:GML_ID>
        <ms:NAZWA>061 125 630</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061125630</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10841">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324339.068000 501252.619000</gml:lowerCorner>
        		<gml:upperCorner>324339.068000 501252.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10841.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324339.068000 501252.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10841</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 123 985</ms:GML_ID>
        <ms:NAZWA>061 123 985</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061123985</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10840">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325004.762429 502169.986453</gml:lowerCorner>
        		<gml:upperCorner>325004.762429 502169.986453</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10840.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325004.762429 502169.986453</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10840</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 122 814</ms:GML_ID>
        <ms:NAZWA>061 122 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061122814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10839">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325373.395000 503305.744000</gml:lowerCorner>
        		<gml:upperCorner>325373.395000 503305.744000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10839.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325373.395000 503305.744000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10839</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 121 618</ms:GML_ID>
        <ms:NAZWA>061 121 618</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061121618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10838">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325609.451000 504071.365000</gml:lowerCorner>
        		<gml:upperCorner>325609.451000 504071.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10838.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325609.451000 504071.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10838</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 120 815</ms:GML_ID>
        <ms:NAZWA>061 120 815</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061120815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10837">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325722.962000 504442.561000</gml:lowerCorner>
        		<gml:upperCorner>325722.962000 504442.561000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10837.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325722.962000 504442.561000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10837</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 120 418</ms:GML_ID>
        <ms:NAZWA>061 120 418</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061120418</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10836">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325898.058000 505014.193000</gml:lowerCorner>
        		<gml:upperCorner>325898.058000 505014.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10836.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325898.058000 505014.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10836</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 119 829</ms:GML_ID>
        <ms:NAZWA>061 119 829</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061119829</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10835">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325987.469559 505842.224415</gml:lowerCorner>
        		<gml:upperCorner>325987.469559 505842.224415</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10835.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325987.469559 505842.224415</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10835</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 118 970</ms:GML_ID>
        <ms:NAZWA>061 118 970</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061118970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10834">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325909.597000 506208.032000</gml:lowerCorner>
        		<gml:upperCorner>325909.597000 506208.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10834.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325909.597000 506208.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10834</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 118 603</ms:GML_ID>
        <ms:NAZWA>061 118 603</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061118603</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287595.996903 490749.722404</gml:lowerCorner>
        		<gml:upperCorner>287595.996903 490749.722404</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287595.996903 490749.722404</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 034 910</ms:GML_ID>
        <ms:NAZWA>131 034 910</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131034910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5044">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>287842.089000 489699.332000</gml:lowerCorner>
        		<gml:upperCorner>287842.089000 489699.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5044.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>287842.089000 489699.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5044</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 001 645</ms:GML_ID>
        <ms:NAZWA>144 001 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>144001645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>288018.851181 491110.683340</gml:lowerCorner>
        		<gml:upperCorner>288018.851181 491110.683340</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>288018.851181 491110.683340</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 035 500</ms:GML_ID>
        <ms:NAZWA>131 035 500</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131035500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6652">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289718.994306 502479.604077</gml:lowerCorner>
        		<gml:upperCorner>289718.994306 502479.604077</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6652.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289718.994306 502479.604077</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6652</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 015 213</ms:GML_ID>
        <ms:NAZWA>182 015 213</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182015213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6651">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289913.977611 500437.516029</gml:lowerCorner>
        		<gml:upperCorner>289913.977611 500437.516029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6651.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289913.977611 500437.516029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6651</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 013 157</ms:GML_ID>
        <ms:NAZWA>182 013 157</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182013157</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6650">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>289969.234000 499621.883000</gml:lowerCorner>
        		<gml:upperCorner>289969.234000 499621.883000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6650.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>289969.234000 499621.883000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6650</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 012 339</ms:GML_ID>
        <ms:NAZWA>182 012 339</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182012339</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6649">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290555.737116 495945.355247</gml:lowerCorner>
        		<gml:upperCorner>290555.737116 495945.355247</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6649.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290555.737116 495945.355247</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6649</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 008 568</ms:GML_ID>
        <ms:NAZWA>182 008 568</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182008568</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6647">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>290744.761816 492957.001585</gml:lowerCorner>
        		<gml:upperCorner>290744.761816 492957.001585</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6647.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>290744.761816 492957.001585</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6647</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 004 816</ms:GML_ID>
        <ms:NAZWA>182 004 816</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182004816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6648">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291433.879613 493586.389783</gml:lowerCorner>
        		<gml:upperCorner>291433.879613 493586.389783</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6648.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291433.879613 493586.389783</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6648</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.182 006 041</ms:GML_ID>
        <ms:NAZWA>182 006 041</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>182006041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>291589.046206 493096.485199</gml:lowerCorner>
        		<gml:upperCorner>291589.046206 493096.485199</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>291589.046206 493096.485199</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.892 000 474</ms:GML_ID>
        <ms:NAZWA>892 000 474</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>892000474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>299388.304548 492232.001760</gml:lowerCorner>
        		<gml:upperCorner>299388.304548 492232.001760</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>299388.304548 492232.001760</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 047 472</ms:GML_ID>
        <ms:NAZWA>131 047 472</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131047472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308318.033000 493564.840000</gml:lowerCorner>
        		<gml:upperCorner>308318.033000 493564.840000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308318.033000 493564.840000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 056 732</ms:GML_ID>
        <ms:NAZWA>131 056 732</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131056732</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310665.313966 493198.871417</gml:lowerCorner>
        		<gml:upperCorner>310665.313966 493198.871417</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310665.313966 493198.871417</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 059 250</ms:GML_ID>
        <ms:NAZWA>131 059 250</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131059250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311518.435774 492702.533847</gml:lowerCorner>
        		<gml:upperCorner>311518.435774 492702.533847</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311518.435774 492702.533847</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 060 238</ms:GML_ID>
        <ms:NAZWA>131 060 238</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131060238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314410.785000 491351.823000</gml:lowerCorner>
        		<gml:upperCorner>314410.785000 491351.823000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314410.785000 491351.823000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 063 455</ms:GML_ID>
        <ms:NAZWA>131 063 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131063455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316178.110000 490883.492000</gml:lowerCorner>
        		<gml:upperCorner>316178.110000 490883.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316178.110000 490883.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 065 284</ms:GML_ID>
        <ms:NAZWA>131 065 284</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131065284</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318873.694000 490436.343000</gml:lowerCorner>
        		<gml:upperCorner>318873.694000 490436.343000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318873.694000 490436.343000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.687 000 977</ms:GML_ID>
        <ms:NAZWA>687 000 977</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>687000977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10851">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318948.834410 490455.179130</gml:lowerCorner>
        		<gml:upperCorner>318948.834410 490455.179130</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10851.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318948.834410 490455.179130</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10851</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 136 252</ms:GML_ID>
        <ms:NAZWA>061 136 252</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061136252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10850">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319935.190532 491398.733526</gml:lowerCorner>
        		<gml:upperCorner>319935.190532 491398.733526</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10850.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319935.190532 491398.733526</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10850</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 134 848</ms:GML_ID>
        <ms:NAZWA>061 134 848</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061134848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320109.594557 489700.467825</gml:lowerCorner>
        		<gml:upperCorner>320109.594557 489700.467825</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320109.594557 489700.467825</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 069 412</ms:GML_ID>
        <ms:NAZWA>131 069 412</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131069412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10849">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321557.787000 494358.801000</gml:lowerCorner>
        		<gml:upperCorner>321557.787000 494358.801000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10849.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321557.787000 494358.801000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10849</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 131 447</ms:GML_ID>
        <ms:NAZWA>061 131 447</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061131447</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7485">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415927.175379 485291.922829</gml:lowerCorner>
        		<gml:upperCorner>415927.175379 485291.922829</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7485.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415927.175379 485291.922829</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7485</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 053 495</ms:GML_ID>
        <ms:NAZWA>014 053 495</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014053495</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7483">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415932.799082 490441.925939</gml:lowerCorner>
        		<gml:upperCorner>415932.799082 490441.925939</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7483.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415932.799082 490441.925939</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7483</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 048 258</ms:GML_ID>
        <ms:NAZWA>014 048 258</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014048258</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7480">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416040.263445 495023.212739</gml:lowerCorner>
        		<gml:upperCorner>416040.263445 495023.212739</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7480.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416040.263445 495023.212739</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7480</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 043 662</ms:GML_ID>
        <ms:NAZWA>014 043 662</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014043662</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7255">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416063.684028 495724.799447</gml:lowerCorner>
        		<gml:upperCorner>416063.684028 495724.799447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7255.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416063.684028 495724.799447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7255</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 042 959</ms:GML_ID>
        <ms:NAZWA>014 042 959</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014042959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7254">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416069.299409 496004.266822</gml:lowerCorner>
        		<gml:upperCorner>416069.299409 496004.266822</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7254.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416069.299409 496004.266822</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7254</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 042 680</ms:GML_ID>
        <ms:NAZWA>014 042 680</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014042680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5479">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417971.018000 497327.552000</gml:lowerCorner>
        		<gml:upperCorner>417971.018000 497327.552000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5479.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417971.018000 497327.552000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5479</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 174 124</ms:GML_ID>
        <ms:NAZWA>131 174 124</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131174124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5478">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417222.962000 497404.293000</gml:lowerCorner>
        		<gml:upperCorner>417222.962000 497404.293000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5478.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417222.962000 497404.293000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5478</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 173 368</ms:GML_ID>
        <ms:NAZWA>131 173 368</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131173368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417159.609000 497601.452000</gml:lowerCorner>
        		<gml:upperCorner>417159.609000 497601.452000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417159.609000 497601.452000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.543 001 663</ms:GML_ID>
        <ms:NAZWA>543 001 663</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>543001663</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7253">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416179.426000 497611.832000</gml:lowerCorner>
        		<gml:upperCorner>416179.426000 497611.832000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7253.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416179.426000 497611.832000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7253</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 041 067</ms:GML_ID>
        <ms:NAZWA>014 041 067</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014041067</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416882.916000 498019.039000</gml:lowerCorner>
        		<gml:upperCorner>416882.916000 498019.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416882.916000 498019.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.543 001 159</ms:GML_ID>
        <ms:NAZWA>543 001 159</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>543001159</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416064.529000 498100.708000</gml:lowerCorner>
        		<gml:upperCorner>416064.529000 498100.708000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416064.529000 498100.708000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.739 003 097</ms:GML_ID>
        <ms:NAZWA>739 003 097</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>739003097</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415843.994000 498293.379000</gml:lowerCorner>
        		<gml:upperCorner>415843.994000 498293.379000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415843.994000 498293.379000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.739 002 785</ms:GML_ID>
        <ms:NAZWA>739 002 785</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>739002785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415802.261000 498354.172000</gml:lowerCorner>
        		<gml:upperCorner>415802.261000 498354.172000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415802.261000 498354.172000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.542 004 350</ms:GML_ID>
        <ms:NAZWA>542 004 350</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>542004350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416067.423000 498472.777000</gml:lowerCorner>
        		<gml:upperCorner>416067.423000 498472.777000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416067.423000 498472.777000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.542 004 053</ms:GML_ID>
        <ms:NAZWA>542 004 053</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>542004053</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7252">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416078.252000 501221.349000</gml:lowerCorner>
        		<gml:upperCorner>416078.252000 501221.349000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7252.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416078.252000 501221.349000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7252</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 037 440</ms:GML_ID>
        <ms:NAZWA>014 037 440</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014037440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7251">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415922.027483 502470.407331</gml:lowerCorner>
        		<gml:upperCorner>415922.027483 502470.407331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7251.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415922.027483 502470.407331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7251</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 036 181</ms:GML_ID>
        <ms:NAZWA>014 036 181</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014036181</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7250">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415702.303044 504222.245412</gml:lowerCorner>
        		<gml:upperCorner>415702.303044 504222.245412</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7250.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415702.303044 504222.245412</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7250</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 034 416</ms:GML_ID>
        <ms:NAZWA>014 034 416</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014034416</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7249">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415653.793764 504609.975379</gml:lowerCorner>
        		<gml:upperCorner>415653.793764 504609.975379</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7249.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415653.793764 504609.975379</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7249</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 034 024</ms:GML_ID>
        <ms:NAZWA>014 034 024</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014034024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7248">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415501.876231 505822.859531</gml:lowerCorner>
        		<gml:upperCorner>415501.876231 505822.859531</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7248.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415501.876231 505822.859531</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7248</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 032 800</ms:GML_ID>
        <ms:NAZWA>014 032 800</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014032800</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7244">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415894.677896 511170.293814</gml:lowerCorner>
        		<gml:upperCorner>415894.677896 511170.293814</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7244.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415894.677896 511170.293814</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7244</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 027 300</ms:GML_ID>
        <ms:NAZWA>014 027 300</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014027300</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416465.158493 513459.454654</gml:lowerCorner>
        		<gml:upperCorner>416465.158493 513459.454654</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416465.158493 513459.454654</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 024 925</ms:GML_ID>
        <ms:NAZWA>014 024 925</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014024925</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7242">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417247.872000 515070.050000</gml:lowerCorner>
        		<gml:upperCorner>417247.872000 515070.050000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7242.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417247.872000 515070.050000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7242</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 023 131</ms:GML_ID>
        <ms:NAZWA>014 023 131</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014023131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7241">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417644.608867 515789.809813</gml:lowerCorner>
        		<gml:upperCorner>417644.608867 515789.809813</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7241.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417644.608867 515789.809813</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7241</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 022 309</ms:GML_ID>
        <ms:NAZWA>014 022 309</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014022309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7240">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418214.249294 516821.044894</gml:lowerCorner>
        		<gml:upperCorner>418214.249294 516821.044894</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7240.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418214.249294 516821.044894</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7240</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 021 130</ms:GML_ID>
        <ms:NAZWA>014 021 130</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014021130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7487">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415254.426314 481395.195865</gml:lowerCorner>
        		<gml:upperCorner>415254.426314 481395.195865</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7487.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415254.426314 481395.195865</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7487</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 058 080</ms:GML_ID>
        <ms:NAZWA>014 058 080</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014058080</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5477">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415328.693565 497674.452316</gml:lowerCorner>
        		<gml:upperCorner>415328.693565 497674.452316</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5477.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415328.693565 497674.452316</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5477</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 171 435</ms:GML_ID>
        <ms:NAZWA>131 171 435</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131171435</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5476">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414763.783000 498353.972000</gml:lowerCorner>
        		<gml:upperCorner>414763.783000 498353.972000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5476.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414763.783000 498353.972000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5476</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 170 545</ms:GML_ID>
        <ms:NAZWA>131 170 545</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131170545</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415361.437000 498357.949000</gml:lowerCorner>
        		<gml:upperCorner>415361.437000 498357.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415361.437000 498357.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.739 002 305</ms:GML_ID>
        <ms:NAZWA>739 002 305</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>739002305</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414916.172583 498360.109058</gml:lowerCorner>
        		<gml:upperCorner>414916.172583 498360.109058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414916.172583 498360.109058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.739 001 856</ms:GML_ID>
        <ms:NAZWA>739 001 856</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>739001856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5463">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387362.711575 498727.213767</gml:lowerCorner>
        		<gml:upperCorner>387362.711575 498727.213767</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5463.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387362.711575 498727.213767</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5463</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 140 570</ms:GML_ID>
        <ms:NAZWA>131 140 570</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131140570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5464">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388417.025000 498852.193000</gml:lowerCorner>
        		<gml:upperCorner>388417.025000 498852.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5464.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388417.025000 498852.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5464</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 141 633</ms:GML_ID>
        <ms:NAZWA>131 141 633</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131141633</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5468">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392091.297165 498871.703681</gml:lowerCorner>
        		<gml:upperCorner>392091.297165 498871.703681</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5468.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392091.297165 498871.703681</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5468</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 145 324</ms:GML_ID>
        <ms:NAZWA>131 145 324</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131145324</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5465">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>389244.730000 498949.985000</gml:lowerCorner>
        		<gml:upperCorner>389244.730000 498949.985000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5465.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>389244.730000 498949.985000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5465</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 142 467</ms:GML_ID>
        <ms:NAZWA>131 142 467</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131142467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5467">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390780.927000 498958.310000</gml:lowerCorner>
        		<gml:upperCorner>390780.927000 498958.310000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5467.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390780.927000 498958.310000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5467</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 144 009</ms:GML_ID>
        <ms:NAZWA>131 144 009</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131144009</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5466">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>390064.080000 499005.029000</gml:lowerCorner>
        		<gml:upperCorner>390064.080000 499005.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5466.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>390064.080000 499005.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5466</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 143 291</ms:GML_ID>
        <ms:NAZWA>131 143 291</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131143291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5469">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396311.692147 500173.614784</gml:lowerCorner>
        		<gml:upperCorner>396311.692147 500173.614784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5469.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396311.692147 500173.614784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5469</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 150 137</ms:GML_ID>
        <ms:NAZWA>131 150 137</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131150137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5470">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397994.971629 500671.917251</gml:lowerCorner>
        		<gml:upperCorner>397994.971629 500671.917251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5470.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397994.971629 500671.917251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5470</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 151 915</ms:GML_ID>
        <ms:NAZWA>131 151 915</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131151915</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5471">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398930.064000 501074.567000</gml:lowerCorner>
        		<gml:upperCorner>398930.064000 501074.567000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5471.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398930.064000 501074.567000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5471</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 152 934</ms:GML_ID>
        <ms:NAZWA>131 152 934</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131152934</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5473">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400112.019000 501246.788000</gml:lowerCorner>
        		<gml:upperCorner>400112.019000 501246.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5473.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400112.019000 501246.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5473</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 154 151</ms:GML_ID>
        <ms:NAZWA>131 154 151</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131154151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5472">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399437.876000 501253.317000</gml:lowerCorner>
        		<gml:upperCorner>399437.876000 501253.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5472.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399437.876000 501253.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5472</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 153 474</ms:GML_ID>
        <ms:NAZWA>131 153 474</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131153474</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5475">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>409439.188000 501467.562000</gml:lowerCorner>
        		<gml:upperCorner>409439.188000 501467.562000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5475.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>409439.188000 501467.562000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5475</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 164 039</ms:GML_ID>
        <ms:NAZWA>131 164 039</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131164039</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5474">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>404358.558000 502056.248000</gml:lowerCorner>
        		<gml:upperCorner>404358.558000 502056.248000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5474.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>404358.558000 502056.248000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5474</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 158 561</ms:GML_ID>
        <ms:NAZWA>131 158 561</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131158561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7247">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415364.581244 506919.021921</gml:lowerCorner>
        		<gml:upperCorner>415364.581244 506919.021921</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7247.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415364.581244 506919.021921</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7247</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 031 694</ms:GML_ID>
        <ms:NAZWA>014 031 694</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014031694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7246">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415295.661232 507509.613890</gml:lowerCorner>
        		<gml:upperCorner>415295.661232 507509.613890</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7246.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415295.661232 507509.613890</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7246</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 031 099</ms:GML_ID>
        <ms:NAZWA>014 031 099</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014031099</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7245">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415154.723944 508633.937888</gml:lowerCorner>
        		<gml:upperCorner>415154.723944 508633.937888</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7245.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415154.723944 508633.937888</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7245</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 029 965</ms:GML_ID>
        <ms:NAZWA>014 029 965</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>014029965</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388082.501000 531315.827000</gml:lowerCorner>
        		<gml:upperCorner>388082.501000 531315.827000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388082.501000 531315.827000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 021 198</ms:GML_ID>
        <ms:NAZWA>024 021 198</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024021198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388041.328000 544473.213000</gml:lowerCorner>
        		<gml:upperCorner>388041.328000 544473.213000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388041.328000 544473.213000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 007 891</ms:GML_ID>
        <ms:NAZWA>024 007 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024007891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388650.700902 546162.383050</gml:lowerCorner>
        		<gml:upperCorner>388650.700902 546162.383050</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388650.700902 546162.383050</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.024 006 083</ms:GML_ID>
        <ms:NAZWA>024 006 083</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>024006083</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10869">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312663.345000 470484.625000</gml:lowerCorner>
        		<gml:upperCorner>312663.345000 470484.625000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10869.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312663.345000 470484.625000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10869</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 160 234</ms:GML_ID>
        <ms:NAZWA>061 160 234</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061160234</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10870">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312716.029014 469604.227922</gml:lowerCorner>
        		<gml:upperCorner>312716.029014 469604.227922</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10870.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312716.029014 469604.227922</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10870</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 161 114</ms:GML_ID>
        <ms:NAZWA>061 161 114</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061161114</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10868">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312803.989000 472387.430000</gml:lowerCorner>
        		<gml:upperCorner>312803.989000 472387.430000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10868.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312803.989000 472387.430000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10868</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 158 323</ms:GML_ID>
        <ms:NAZWA>061 158 323</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061158323</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10867">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312849.890000 472949.921000</gml:lowerCorner>
        		<gml:upperCorner>312849.890000 472949.921000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10867.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312849.890000 472949.921000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10867</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 157 759</ms:GML_ID>
        <ms:NAZWA>061 157 759</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061157759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10866">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312892.657000 473478.298000</gml:lowerCorner>
        		<gml:upperCorner>312892.657000 473478.298000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10866.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312892.657000 473478.298000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10866</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 157 228</ms:GML_ID>
        <ms:NAZWA>061 157 228</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061157228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10858">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312910.319000 480310.400000</gml:lowerCorner>
        		<gml:upperCorner>312910.319000 480310.400000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10858.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312910.319000 480310.400000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10858</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 148 454</ms:GML_ID>
        <ms:NAZWA>061 148 454</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061148454</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10865">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312920.546000 473820.493000</gml:lowerCorner>
        		<gml:upperCorner>312920.546000 473820.493000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10865.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312920.546000 473820.493000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10865</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 156 885</ms:GML_ID>
        <ms:NAZWA>061 156 885</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061156885</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4957">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313340.342000 477105.316000</gml:lowerCorner>
        		<gml:upperCorner>313340.342000 477105.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4957.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313340.342000 477105.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4957</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 021 090</ms:GML_ID>
        <ms:NAZWA>143 021 090</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143021090</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4958">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313784.195000 476900.800000</gml:lowerCorner>
        		<gml:upperCorner>313784.195000 476900.800000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4958.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313784.195000 476900.800000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4958</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 021 580</ms:GML_ID>
        <ms:NAZWA>143 021 580</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143021580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10857">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315077.777634 482593.332442</gml:lowerCorner>
        		<gml:upperCorner>315077.777634 482593.332442</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10857.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315077.777634 482593.332442</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10857</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 145 294</ms:GML_ID>
        <ms:NAZWA>061 145 294</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061145294</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10856">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315280.613000 482785.909000</gml:lowerCorner>
        		<gml:upperCorner>315280.613000 482785.909000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10856.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315280.613000 482785.909000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10856</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 145 023</ms:GML_ID>
        <ms:NAZWA>061 145 023</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061145023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10855">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315527.216000 483042.594000</gml:lowerCorner>
        		<gml:upperCorner>315527.216000 483042.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10855.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315527.216000 483042.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10855</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 144 667</ms:GML_ID>
        <ms:NAZWA>061 144 667</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061144667</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4959">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315626.879000 476106.510000</gml:lowerCorner>
        		<gml:upperCorner>315626.879000 476106.510000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4959.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315626.879000 476106.510000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4959</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 023 590</ms:GML_ID>
        <ms:NAZWA>143 023 590</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143023590</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10854">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315951.752000 483485.294000</gml:lowerCorner>
        		<gml:upperCorner>315951.752000 483485.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10854.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315951.752000 483485.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10854</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 144 050</ms:GML_ID>
        <ms:NAZWA>061 144 050</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061144050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4960">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316456.908000 475806.838000</gml:lowerCorner>
        		<gml:upperCorner>316456.908000 475806.838000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4960.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316456.908000 475806.838000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4960</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 024 471</ms:GML_ID>
        <ms:NAZWA>143 024 471</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143024471</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4961">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317082.160000 475580.898000</gml:lowerCorner>
        		<gml:upperCorner>317082.160000 475580.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4961.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317082.160000 475580.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4961</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 025 139</ms:GML_ID>
        <ms:NAZWA>143 025 139</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143025139</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10853">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317254.576240 485645.020701</gml:lowerCorner>
        		<gml:upperCorner>317254.576240 485645.020701</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10853.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317254.576240 485645.020701</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10853</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 141 467</ms:GML_ID>
        <ms:NAZWA>061 141 467</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061141467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10852">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317542.054000 486424.749000</gml:lowerCorner>
        		<gml:upperCorner>317542.054000 486424.749000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10852.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317542.054000 486424.749000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10852</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 140 640</ms:GML_ID>
        <ms:NAZWA>061 140 640</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061140640</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317684.444000 475363.680000</gml:lowerCorner>
        		<gml:upperCorner>317684.444000 475363.680000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317684.444000 475363.680000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 025 776</ms:GML_ID>
        <ms:NAZWA>143 025 776</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143025776</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318365.679000 475114.497000</gml:lowerCorner>
        		<gml:upperCorner>318365.679000 475114.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318365.679000 475114.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 026 502</ms:GML_ID>
        <ms:NAZWA>143 026 502</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143026502</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321338.767000 473768.062000</gml:lowerCorner>
        		<gml:upperCorner>321338.767000 473768.062000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321338.767000 473768.062000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 029 771</ms:GML_ID>
        <ms:NAZWA>143 029 771</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143029771</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322697.901000 473151.228000</gml:lowerCorner>
        		<gml:upperCorner>322697.901000 473151.228000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322697.901000 473151.228000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 031 266</ms:GML_ID>
        <ms:NAZWA>143 031 266</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143031266</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323454.599000 472808.975000</gml:lowerCorner>
        		<gml:upperCorner>323454.599000 472808.975000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323454.599000 472808.975000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 032 098</ms:GML_ID>
        <ms:NAZWA>143 032 098</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143032098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324163.106000 472488.636000</gml:lowerCorner>
        		<gml:upperCorner>324163.106000 472488.636000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324163.106000 472488.636000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 032 876</ms:GML_ID>
        <ms:NAZWA>143 032 876</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143032876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325236.968000 471835.447000</gml:lowerCorner>
        		<gml:upperCorner>325236.968000 471835.447000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325236.968000 471835.447000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 034 137</ms:GML_ID>
        <ms:NAZWA>143 034 137</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143034137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326804.317000 470637.354000</gml:lowerCorner>
        		<gml:upperCorner>326804.317000 470637.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326804.317000 470637.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 036 113</ms:GML_ID>
        <ms:NAZWA>143 036 113</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143036113</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327151.906000 470372.335000</gml:lowerCorner>
        		<gml:upperCorner>327151.906000 470372.335000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327151.906000 470372.335000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 036 551</ms:GML_ID>
        <ms:NAZWA>143 036 551</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143036551</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328292.269000 485725.309000</gml:lowerCorner>
        		<gml:upperCorner>328292.269000 485725.309000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328292.269000 485725.309000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 009 403</ms:GML_ID>
        <ms:NAZWA>181 009 403</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181009403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328427.566000 469186.472000</gml:lowerCorner>
        		<gml:upperCorner>328427.566000 469186.472000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328427.566000 469186.472000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 038 307</ms:GML_ID>
        <ms:NAZWA>143 038 307</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143038307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329276.544000 467827.435000</gml:lowerCorner>
        		<gml:upperCorner>329276.544000 467827.435000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329276.544000 467827.435000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 039 909</ms:GML_ID>
        <ms:NAZWA>143 039 909</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143039909</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329789.933000 485129.079000</gml:lowerCorner>
        		<gml:upperCorner>329789.933000 485129.079000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329789.933000 485129.079000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 011 014</ms:GML_ID>
        <ms:NAZWA>181 011 014</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181011014</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329886.815000 466850.468000</gml:lowerCorner>
        		<gml:upperCorner>329886.815000 466850.468000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329886.815000 466850.468000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 041 066</ms:GML_ID>
        <ms:NAZWA>143 041 066</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143041066</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330572.253000 484817.428000</gml:lowerCorner>
        		<gml:upperCorner>330572.253000 484817.428000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330572.253000 484817.428000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 011 858</ms:GML_ID>
        <ms:NAZWA>181 011 858</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181011858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332686.582000 483975.056000</gml:lowerCorner>
        		<gml:upperCorner>332686.582000 483975.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332686.582000 483975.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 014 141</ms:GML_ID>
        <ms:NAZWA>181 014 141</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181014141</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335938.871000 482944.486000</gml:lowerCorner>
        		<gml:upperCorner>335938.871000 482944.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335938.871000 482944.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 017 638</ms:GML_ID>
        <ms:NAZWA>181 017 638</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181017638</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336390.694455 482563.817524</gml:lowerCorner>
        		<gml:upperCorner>336390.694455 482563.817524</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336390.694455 482563.817524</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 018 230</ms:GML_ID>
        <ms:NAZWA>181 018 230</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181018230</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376136.823000 464446.377000</gml:lowerCorner>
        		<gml:upperCorner>376136.823000 464446.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376136.823000 464446.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 067 449</ms:GML_ID>
        <ms:NAZWA>181 067 449</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181067449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376028.349000 464804.321000</gml:lowerCorner>
        		<gml:upperCorner>376028.349000 464804.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376028.349000 464804.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 067 075</ms:GML_ID>
        <ms:NAZWA>181 067 075</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181067075</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375436.025000 466758.945000</gml:lowerCorner>
        		<gml:upperCorner>375436.025000 466758.945000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375436.025000 466758.945000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 065 033</ms:GML_ID>
        <ms:NAZWA>181 065 033</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181065033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375061.490689 467972.033987</gml:lowerCorner>
        		<gml:upperCorner>375061.490689 467972.033987</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375061.490689 467972.033987</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 063 759</ms:GML_ID>
        <ms:NAZWA>181 063 759</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181063759</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374672.286850 469291.000106</gml:lowerCorner>
        		<gml:upperCorner>374672.286850 469291.000106</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374672.286850 469291.000106</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 062 398</ms:GML_ID>
        <ms:NAZWA>181 062 398</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181062398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373685.122000 470415.126000</gml:lowerCorner>
        		<gml:upperCorner>373685.122000 470415.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373685.122000 470415.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 060 848</ms:GML_ID>
        <ms:NAZWA>181 060 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181060848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372402.278000 471379.393000</gml:lowerCorner>
        		<gml:upperCorner>372402.278000 471379.393000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372402.278000 471379.393000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 059 236</ms:GML_ID>
        <ms:NAZWA>181 059 236</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181059236</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371670.361000 472283.023000</gml:lowerCorner>
        		<gml:upperCorner>371670.361000 472283.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371670.361000 472283.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 058 074</ms:GML_ID>
        <ms:NAZWA>181 058 074</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181058074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6561">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361069.873000 472999.170000</gml:lowerCorner>
        		<gml:upperCorner>361069.873000 472999.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6561.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361069.873000 472999.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6561</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 046 526</ms:GML_ID>
        <ms:NAZWA>181 046 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181046526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371014.667000 473092.879000</gml:lowerCorner>
        		<gml:upperCorner>371014.667000 473092.879000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371014.667000 473092.879000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 057 031</ms:GML_ID>
        <ms:NAZWA>181 057 031</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181057031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6562">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>361592.302000 473189.935000</gml:lowerCorner>
        		<gml:upperCorner>361592.302000 473189.935000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6562.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>361592.302000 473189.935000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6562</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 047 079</ms:GML_ID>
        <ms:NAZWA>181 047 079</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181047079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6563">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>363067.074000 473599.901000</gml:lowerCorner>
        		<gml:upperCorner>363067.074000 473599.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6563.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>363067.074000 473599.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6563</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 048 620</ms:GML_ID>
        <ms:NAZWA>181 048 620</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181048620</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6567">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369994.282000 473825.056000</gml:lowerCorner>
        		<gml:upperCorner>369994.282000 473825.056000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6567.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369994.282000 473825.056000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6567</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 055 729</ms:GML_ID>
        <ms:NAZWA>181 055 729</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181055729</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6564">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364319.143000 473945.759000</gml:lowerCorner>
        		<gml:upperCorner>364319.143000 473945.759000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6564.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364319.143000 473945.759000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6564</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 049 916</ms:GML_ID>
        <ms:NAZWA>181 049 916</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181049916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6565">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365421.363854 474250.177693</gml:lowerCorner>
        		<gml:upperCorner>365421.363854 474250.177693</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6565.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365421.363854 474250.177693</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6565</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 051 055</ms:GML_ID>
        <ms:NAZWA>181 051 055</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181051055</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6566">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366642.048000 474459.004000</gml:lowerCorner>
        		<gml:upperCorner>366642.048000 474459.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6566.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366642.048000 474459.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6566</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 052 303</ms:GML_ID>
        <ms:NAZWA>181 052 303</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181052303</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>362019.004655 493473.031514</gml:lowerCorner>
        		<gml:upperCorner>362019.004655 493473.031514</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>362019.004655 493473.031514</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 114 241</ms:GML_ID>
        <ms:NAZWA>131 114 241</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131114241</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365934.047000 494664.770000</gml:lowerCorner>
        		<gml:upperCorner>365934.047000 494664.770000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365934.047000 494664.770000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 118 385</ms:GML_ID>
        <ms:NAZWA>131 118 385</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131118385</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366755.883000 494922.913000</gml:lowerCorner>
        		<gml:upperCorner>366755.883000 494922.913000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366755.883000 494922.913000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 119 247</ms:GML_ID>
        <ms:NAZWA>131 119 247</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131119247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6233">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369113.239000 495816.153000</gml:lowerCorner>
        		<gml:upperCorner>369113.239000 495816.153000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6233.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369113.239000 495816.153000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6233</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.146 045 995</ms:GML_ID>
        <ms:NAZWA>146 045 995</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>146045995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370153.564825 495840.105665</gml:lowerCorner>
        		<gml:upperCorner>370153.564825 495840.105665</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370153.564825 495840.105665</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 122 816</ms:GML_ID>
        <ms:NAZWA>131 122 816</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131122816</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371035.973000 495876.354000</gml:lowerCorner>
        		<gml:upperCorner>371035.973000 495876.354000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371035.973000 495876.354000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 123 702</ms:GML_ID>
        <ms:NAZWA>131 123 702</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131123702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372553.678000 495954.071000</gml:lowerCorner>
        		<gml:upperCorner>372553.678000 495954.071000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372553.678000 495954.071000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 125 223</ms:GML_ID>
        <ms:NAZWA>131 125 223</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131125223</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305776.819677 461794.062058</gml:lowerCorner>
        		<gml:upperCorner>305776.819677 461794.062058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305776.819677 461794.062058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 035 924</ms:GML_ID>
        <ms:NAZWA>144 035 924</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144035924</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5071">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305300.717000 462274.512000</gml:lowerCorner>
        		<gml:upperCorner>305300.717000 462274.512000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5071.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305300.717000 462274.512000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5071</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 035 247</ms:GML_ID>
        <ms:NAZWA>144 035 247</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144035247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10873">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311000.795811 462660.080249</gml:lowerCorner>
        		<gml:upperCorner>311000.795811 462660.080249</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10873.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311000.795811 462660.080249</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10873</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 168 326</ms:GML_ID>
        <ms:NAZWA>061 168 326</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>061168326</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5070">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304421.569000 463113.006000</gml:lowerCorner>
        		<gml:upperCorner>304421.569000 463113.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5070.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304421.569000 463113.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5070</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 034 031</ms:GML_ID>
        <ms:NAZWA>144 034 031</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144034031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304117.828000 463378.144000</gml:lowerCorner>
        		<gml:upperCorner>304117.828000 463378.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304117.828000 463378.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 033 628</ms:GML_ID>
        <ms:NAZWA>144 033 628</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144033628</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303791.394000 463662.514000</gml:lowerCorner>
        		<gml:upperCorner>303791.394000 463662.514000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303791.394000 463662.514000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 033 195</ms:GML_ID>
        <ms:NAZWA>144 033 195</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144033195</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5067">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303057.351000 464301.155000</gml:lowerCorner>
        		<gml:upperCorner>303057.351000 464301.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5067.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303057.351000 464301.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5067</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 032 222</ms:GML_ID>
        <ms:NAZWA>144 032 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144032222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302344.721000 464922.141000</gml:lowerCorner>
        		<gml:upperCorner>302344.721000 464922.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302344.721000 464922.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 031 280</ms:GML_ID>
        <ms:NAZWA>144 031 280</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144031280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5065">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301906.984000 465303.161000</gml:lowerCorner>
        		<gml:upperCorner>301906.984000 465303.161000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5065.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301906.984000 465303.161000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5065</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 030 694</ms:GML_ID>
        <ms:NAZWA>144 030 694</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144030694</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>301345.085000 465790.476000</gml:lowerCorner>
        		<gml:upperCorner>301345.085000 465790.476000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>301345.085000 465790.476000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 029 953</ms:GML_ID>
        <ms:NAZWA>144 029 953</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144029953</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10872">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312056.008000 466751.418000</gml:lowerCorner>
        		<gml:upperCorner>312056.008000 466751.418000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10872.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312056.008000 466751.418000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10872</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 164 078</ms:GML_ID>
        <ms:NAZWA>061 164 078</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061164078</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10871">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312271.454030 467430.100392</gml:lowerCorner>
        		<gml:upperCorner>312271.454030 467430.100392</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10871.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312271.454030 467430.100392</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10871</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 163 366</ms:GML_ID>
        <ms:NAZWA>061 163 366</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061163366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6310">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>300830.726000 473739.640000</gml:lowerCorner>
        		<gml:upperCorner>300830.726000 473739.640000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6310.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>300830.726000 473739.640000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6310</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 025 960</ms:GML_ID>
        <ms:NAZWA>152 025 960</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152025960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10864">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312393.906000 475352.179000</gml:lowerCorner>
        		<gml:upperCorner>312393.906000 475352.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10864.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312393.906000 475352.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10864</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 155 211</ms:GML_ID>
        <ms:NAZWA>061 155 211</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061155211</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6311">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303487.947508 475989.312505</gml:lowerCorner>
        		<gml:upperCorner>303487.947508 475989.312505</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6311.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303487.947508 475989.312505</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6311</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 029 476</ms:GML_ID>
        <ms:NAZWA>152 029 476</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152029476</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10863">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312250.292000 476313.678000</gml:lowerCorner>
        		<gml:upperCorner>312250.292000 476313.678000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10863.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312250.292000 476313.678000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10863</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 154 200</ms:GML_ID>
        <ms:NAZWA>061 154 200</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061154200</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10862">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312285.361006 476824.804070</gml:lowerCorner>
        		<gml:upperCorner>312285.361006 476824.804070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10862.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312285.361006 476824.804070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10862</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 153 686</ms:GML_ID>
        <ms:NAZWA>061 153 686</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061153686</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10861">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312293.660123 477158.151362</gml:lowerCorner>
        		<gml:upperCorner>312293.660123 477158.151362</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10861.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312293.660123 477158.151362</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10861</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 153 353</ms:GML_ID>
        <ms:NAZWA>061 153 353</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061153353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10860">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312296.884000 477293.686000</gml:lowerCorner>
        		<gml:upperCorner>312296.884000 477293.686000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10860.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312296.884000 477293.686000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10860</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 153 218</ms:GML_ID>
        <ms:NAZWA>061 153 218</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061153218</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4956">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312103.655438 477833.819038</gml:lowerCorner>
        		<gml:upperCorner>312103.655438 477833.819038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4956.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312103.655438 477833.819038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4956</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 019 643</ms:GML_ID>
        <ms:NAZWA>143 019 643</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143019643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6312">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305825.641000 477892.602000</gml:lowerCorner>
        		<gml:upperCorner>305825.641000 477892.602000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6312.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305825.641000 477892.602000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6312</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 032 503</ms:GML_ID>
        <ms:NAZWA>152 032 503</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152032503</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4955">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310896.290000 479602.590000</gml:lowerCorner>
        		<gml:upperCorner>310896.290000 479602.590000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4955.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310896.290000 479602.590000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4955</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 017 462</ms:GML_ID>
        <ms:NAZWA>143 017 462</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143017462</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6315">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311032.517000 479769.203000</gml:lowerCorner>
        		<gml:upperCorner>311032.517000 479769.203000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6315.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311032.517000 479769.203000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6315</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 039 292</ms:GML_ID>
        <ms:NAZWA>152 039 292</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152039292</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10859">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311532.829105 479808.028917</gml:lowerCorner>
        		<gml:upperCorner>311532.829105 479808.028917</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10859.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311532.829105 479808.028917</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10859</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 150 006</ms:GML_ID>
        <ms:NAZWA>061 150 006</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>061150006</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311273.195000 479898.208000</gml:lowerCorner>
        		<gml:upperCorner>311273.195000 479898.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311273.195000 479898.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.685 002 777</ms:GML_ID>
        <ms:NAZWA>685 002 777</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>685002777</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6314">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310528.976892 480337.262151</gml:lowerCorner>
        		<gml:upperCorner>310528.976892 480337.262151</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6314.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310528.976892 480337.262151</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6314</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 038 366</ms:GML_ID>
        <ms:NAZWA>152 038 366</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152038366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6313">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310358.762000 480698.922000</gml:lowerCorner>
        		<gml:upperCorner>310358.762000 480698.922000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6313.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310358.762000 480698.922000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6313</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.152 038 030</ms:GML_ID>
        <ms:NAZWA>152 038 030</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>152038030</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4954">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309622.360000 482374.295000</gml:lowerCorner>
        		<gml:upperCorner>309622.360000 482374.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4954.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309622.360000 482374.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4954</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 014 405</ms:GML_ID>
        <ms:NAZWA>143 014 405</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143014405</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4953">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309142.050000 483300.316000</gml:lowerCorner>
        		<gml:upperCorner>309142.050000 483300.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4953.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309142.050000 483300.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4953</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 013 361</ms:GML_ID>
        <ms:NAZWA>143 013 361</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143013361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4952">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308858.603000 483846.367000</gml:lowerCorner>
        		<gml:upperCorner>308858.603000 483846.367000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4952.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308858.603000 483846.367000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4952</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 012 745</ms:GML_ID>
        <ms:NAZWA>143 012 745</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143012745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4951">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307311.454000 486818.485000</gml:lowerCorner>
        		<gml:upperCorner>307311.454000 486818.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4951.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307311.454000 486818.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4951</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 009 394</ms:GML_ID>
        <ms:NAZWA>143 009 394</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143009394</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4950">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306775.464000 487755.810000</gml:lowerCorner>
        		<gml:upperCorner>306775.464000 487755.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4950.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306775.464000 487755.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4950</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 008 310</ms:GML_ID>
        <ms:NAZWA>143 008 310</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>143008310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7512">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428850.145963 454869.447031</gml:lowerCorner>
        		<gml:upperCorner>428850.145963 454869.447031</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7512.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428850.145963 454869.447031</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7512</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 089 745</ms:GML_ID>
        <ms:NAZWA>014 089 745</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014089745</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7511">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428264.645000 456514.451000</gml:lowerCorner>
        		<gml:upperCorner>428264.645000 456514.451000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7511.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428264.645000 456514.451000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7511</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 088 002</ms:GML_ID>
        <ms:NAZWA>014 088 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014088002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7510">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428032.934403 457293.449515</gml:lowerCorner>
        		<gml:upperCorner>428032.934403 457293.449515</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7510.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428032.934403 457293.449515</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7510</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 087 190</ms:GML_ID>
        <ms:NAZWA>014 087 190</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014087190</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7509">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427581.361105 458344.153756</gml:lowerCorner>
        		<gml:upperCorner>427581.361105 458344.153756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7509.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427581.361105 458344.153756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7509</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 086 037</ms:GML_ID>
        <ms:NAZWA>014 086 037</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014086037</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7508">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426867.700465 459346.193627</gml:lowerCorner>
        		<gml:upperCorner>426867.700465 459346.193627</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7508.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426867.700465 459346.193627</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7508</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 084 803</ms:GML_ID>
        <ms:NAZWA>014 084 803</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014084803</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7504">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426372.193000 459949.173000</gml:lowerCorner>
        		<gml:upperCorner>426372.193000 459949.173000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7504.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426372.193000 459949.173000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7504</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 084 021</ms:GML_ID>
        <ms:NAZWA>014 084 021</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014084021</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7507">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425809.374000 460634.070000</gml:lowerCorner>
        		<gml:upperCorner>425809.374000 460634.070000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7507.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425809.374000 460634.070000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7507</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 083 136</ms:GML_ID>
        <ms:NAZWA>014 083 136</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014083136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7506">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425092.171340 461404.617986</gml:lowerCorner>
        		<gml:upperCorner>425092.171340 461404.617986</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7506.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425092.171340 461404.617986</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7506</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 082 082</ms:GML_ID>
        <ms:NAZWA>014 082 082</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014082082</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7505">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424698.179493 461820.614491</gml:lowerCorner>
        		<gml:upperCorner>424698.179493 461820.614491</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7505.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424698.179493 461820.614491</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7505</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 081 508</ms:GML_ID>
        <ms:NAZWA>014 081 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014081508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7503">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424105.585750 462446.248903</gml:lowerCorner>
        		<gml:upperCorner>424105.585750 462446.248903</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7503.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424105.585750 462446.248903</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7503</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 080 646</ms:GML_ID>
        <ms:NAZWA>014 080 646</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014080646</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>423624.214651 462953.838776</gml:lowerCorner>
        		<gml:upperCorner>423624.214651 462953.838776</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>423624.214651 462953.838776</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 079 941</ms:GML_ID>
        <ms:NAZWA>014 079 941</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014079941</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7501">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>422769.892394 463840.078796</gml:lowerCorner>
        		<gml:upperCorner>422769.892394 463840.078796</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7501.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>422769.892394 463840.078796</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7501</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 078 715</ms:GML_ID>
        <ms:NAZWA>014 078 715</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014078715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421763.692000 464635.074000</gml:lowerCorner>
        		<gml:upperCorner>421763.692000 464635.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421763.692000 464635.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 077 411</ms:GML_ID>
        <ms:NAZWA>014 077 411</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014077411</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>421103.357371 465031.680231</gml:lowerCorner>
        		<gml:upperCorner>421103.357371 465031.680231</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>421103.357371 465031.680231</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 076 625</ms:GML_ID>
        <ms:NAZWA>014 076 625</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014076625</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>420246.649026 466411.742461</gml:lowerCorner>
        		<gml:upperCorner>420246.649026 466411.742461</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>420246.649026 466411.742461</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 075 002</ms:GML_ID>
        <ms:NAZWA>014 075 002</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014075002</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>419620.962671 467421.263439</gml:lowerCorner>
        		<gml:upperCorner>419620.962671 467421.263439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>419620.962671 467421.263439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 073 812</ms:GML_ID>
        <ms:NAZWA>014 073 812</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014073812</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>418697.966000 469126.429000</gml:lowerCorner>
        		<gml:upperCorner>418697.966000 469126.429000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>418697.966000 469126.429000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 071 871</ms:GML_ID>
        <ms:NAZWA>014 071 871</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014071871</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417990.935896 470538.865384</gml:lowerCorner>
        		<gml:upperCorner>417990.935896 470538.865384</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417990.935896 470538.865384</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 070 291</ms:GML_ID>
        <ms:NAZWA>014 070 291</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014070291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>417354.008350 472285.175564</gml:lowerCorner>
        		<gml:upperCorner>417354.008350 472285.175564</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>417354.008350 472285.175564</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 068 417</ms:GML_ID>
        <ms:NAZWA>014 068 417</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014068417</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416690.476993 474045.419087</gml:lowerCorner>
        		<gml:upperCorner>416690.476993 474045.419087</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416690.476993 474045.419087</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 066 526</ms:GML_ID>
        <ms:NAZWA>014 066 526</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014066526</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415703.155387 475023.759429</gml:lowerCorner>
        		<gml:upperCorner>415703.155387 475023.759429</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415703.155387 475023.759429</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 065 137</ms:GML_ID>
        <ms:NAZWA>014 065 137</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014065137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7491">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414872.541797 475842.905150</gml:lowerCorner>
        		<gml:upperCorner>414872.541797 475842.905150</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7491.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414872.541797 475842.905150</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7491</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 063 970</ms:GML_ID>
        <ms:NAZWA>014 063 970</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014063970</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7490">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414461.559937 478452.737006</gml:lowerCorner>
        		<gml:upperCorner>414461.559937 478452.737006</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7490.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414461.559937 478452.737006</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7490</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 061 235</ms:GML_ID>
        <ms:NAZWA>014 061 235</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014061235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7489">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>414491.504000 478881.990000</gml:lowerCorner>
        		<gml:upperCorner>414491.504000 478881.990000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7489.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>414491.504000 478881.990000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7489</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 060 805</ms:GML_ID>
        <ms:NAZWA>014 060 805</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014060805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7488">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415156.982106 481251.347065</gml:lowerCorner>
        		<gml:upperCorner>415156.982106 481251.347065</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7488.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415156.982106 481251.347065</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7488</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 058 245</ms:GML_ID>
        <ms:NAZWA>014 058 245</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014058245</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7486">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>416635.444112 484143.636770</gml:lowerCorner>
        		<gml:upperCorner>416635.444112 484143.636770</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7486.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>416635.444112 484143.636770</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7486</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 054 919</ms:GML_ID>
        <ms:NAZWA>014 054 919</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014054919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7484">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415873.521766 489489.131886</gml:lowerCorner>
        		<gml:upperCorner>415873.521766 489489.131886</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7484.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415873.521766 489489.131886</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7484</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 049 215</ms:GML_ID>
        <ms:NAZWA>014 049 215</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014049215</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5085">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311428.080000 448202.513000</gml:lowerCorner>
        		<gml:upperCorner>311428.080000 448202.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5085.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311428.080000 448202.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5085</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 051 207</ms:GML_ID>
        <ms:NAZWA>144 051 207</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144051207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5084">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311362.094000 448983.712000</gml:lowerCorner>
        		<gml:upperCorner>311362.094000 448983.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5084.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311362.094000 448983.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5084</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 050 422</ms:GML_ID>
        <ms:NAZWA>144 050 422</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144050422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6417">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304294.047000 449168.101000</gml:lowerCorner>
        		<gml:upperCorner>304294.047000 449168.101000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6417.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304294.047000 449168.101000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6417</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 040 916</ms:GML_ID>
        <ms:NAZWA>175 040 916</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175040916</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6418">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>304521.637000 449184.295000</gml:lowerCorner>
        		<gml:upperCorner>304521.637000 449184.295000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6418.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>304521.637000 449184.295000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6418</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 041 145</ms:GML_ID>
        <ms:NAZWA>175 041 145</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175041145</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6416">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302753.925000 449406.035000</gml:lowerCorner>
        		<gml:upperCorner>302753.925000 449406.035000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6416.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302753.925000 449406.035000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6416</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 039 325</ms:GML_ID>
        <ms:NAZWA>175 039 325</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175039325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6419">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305413.308000 449439.486000</gml:lowerCorner>
        		<gml:upperCorner>305413.308000 449439.486000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6419.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305413.308000 449439.486000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6419</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 042 073</ms:GML_ID>
        <ms:NAZWA>175 042 073</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175042073</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6420">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305854.807000 449577.657000</gml:lowerCorner>
        		<gml:upperCorner>305854.807000 449577.657000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6420.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305854.807000 449577.657000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6420</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 042 537</ms:GML_ID>
        <ms:NAZWA>175 042 537</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175042537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6421">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306944.535000 450015.826000</gml:lowerCorner>
        		<gml:upperCorner>306944.535000 450015.826000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6421.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306944.535000 450015.826000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6421</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 043 717</ms:GML_ID>
        <ms:NAZWA>175 043 717</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175043717</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6422">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307605.243000 450435.619000</gml:lowerCorner>
        		<gml:upperCorner>307605.243000 450435.619000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6422.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307605.243000 450435.619000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6422</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 044 500</ms:GML_ID>
        <ms:NAZWA>175 044 500</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175044500</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5083">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311195.979000 450959.428000</gml:lowerCorner>
        		<gml:upperCorner>311195.979000 450959.428000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5083.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311195.979000 450959.428000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5083</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 048 440</ms:GML_ID>
        <ms:NAZWA>144 048 440</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144048440</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6423">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308244.769000 451490.148000</gml:lowerCorner>
        		<gml:upperCorner>308244.769000 451490.148000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6423.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308244.769000 451490.148000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6423</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 045 811</ms:GML_ID>
        <ms:NAZWA>175 045 811</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175045811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5082">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311115.144000 451629.179000</gml:lowerCorner>
        		<gml:upperCorner>311115.144000 451629.179000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5082.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311115.144000 451629.179000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5082</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 047 763</ms:GML_ID>
        <ms:NAZWA>144 047 763</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144047763</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5081">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311066.423000 451790.984000</gml:lowerCorner>
        		<gml:upperCorner>311066.423000 451790.984000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5081.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311066.423000 451790.984000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5081</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 047 594</ms:GML_ID>
        <ms:NAZWA>144 047 594</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144047594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5080">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310814.872000 452382.609000</gml:lowerCorner>
        		<gml:upperCorner>310814.872000 452382.609000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5080.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310814.872000 452382.609000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5080</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 046 952</ms:GML_ID>
        <ms:NAZWA>144 046 952</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144046952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5079">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310524.947759 453192.649701</gml:lowerCorner>
        		<gml:upperCorner>310524.947759 453192.649701</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5079.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310524.947759 453192.649701</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5079</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 046 087</ms:GML_ID>
        <ms:NAZWA>144 046 087</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144046087</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5078">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310557.951000 453641.761000</gml:lowerCorner>
        		<gml:upperCorner>310557.951000 453641.761000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5078.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310557.951000 453641.761000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5078</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 045 635</ms:GML_ID>
        <ms:NAZWA>144 045 635</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144045635</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5077">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310644.467000 454312.866000</gml:lowerCorner>
        		<gml:upperCorner>310644.467000 454312.866000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5077.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310644.467000 454312.866000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5077</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 044 959</ms:GML_ID>
        <ms:NAZWA>144 044 959</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144044959</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6427">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311280.087000 454424.547000</gml:lowerCorner>
        		<gml:upperCorner>311280.087000 454424.547000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6427.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311280.087000 454424.547000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6427</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 052 542</ms:GML_ID>
        <ms:NAZWA>175 052 542</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175052542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6426">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310898.379392 454534.335617</gml:lowerCorner>
        		<gml:upperCorner>310898.379392 454534.335617</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6426.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310898.379392 454534.335617</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6426</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 052 136</ms:GML_ID>
        <ms:NAZWA>175 052 136</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175052136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6424">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309598.377000 455476.563000</gml:lowerCorner>
        		<gml:upperCorner>309598.377000 455476.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6424.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309598.377000 455476.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6424</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 050 350</ms:GML_ID>
        <ms:NAZWA>175 050 350</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175050350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6425">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309820.883000 455543.605000</gml:lowerCorner>
        		<gml:upperCorner>309820.883000 455543.605000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6425.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309820.883000 455543.605000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6425</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 050 584</ms:GML_ID>
        <ms:NAZWA>175 050 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175050584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10876">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310311.827000 455940.045000</gml:lowerCorner>
        		<gml:upperCorner>310311.827000 455940.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10876.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310311.827000 455940.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10876</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 175 098</ms:GML_ID>
        <ms:NAZWA>061 175 098</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>061175098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5076">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309758.165000 456441.440000</gml:lowerCorner>
        		<gml:upperCorner>309758.165000 456441.440000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5076.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309758.165000 456441.440000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5076</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 042 629</ms:GML_ID>
        <ms:NAZWA>144 042 629</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144042629</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5075">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309741.673000 456475.475000</gml:lowerCorner>
        		<gml:upperCorner>309741.673000 456475.475000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5075.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309741.673000 456475.475000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5075</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 042 592</ms:GML_ID>
        <ms:NAZWA>144 042 592</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144042592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10875">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310441.436000 456522.038000</gml:lowerCorner>
        		<gml:upperCorner>310441.436000 456522.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10875.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310441.436000 456522.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10875</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 174 501</ms:GML_ID>
        <ms:NAZWA>061 174 501</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>061174501</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5074">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309575.168345 456827.403072</gml:lowerCorner>
        		<gml:upperCorner>309575.168345 456827.403072</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5074.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309575.168345 456827.403072</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5074</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 042 205</ms:GML_ID>
        <ms:NAZWA>144 042 205</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144042205</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.10874">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310765.486883 459534.022369</gml:lowerCorner>
        		<gml:upperCorner>310765.486883 459534.022369</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.10874.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310765.486883 459534.022369</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>10874</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.061 171 464</ms:GML_ID>
        <ms:NAZWA>061 171 464</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>061171464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5073">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306277.340974 461288.328297</gml:lowerCorner>
        		<gml:upperCorner>306277.340974 461288.328297</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5073.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306277.340974 461288.328297</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5073</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 036 637</ms:GML_ID>
        <ms:NAZWA>144 036 637</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144036637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6455">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337766.150000 447446.276000</gml:lowerCorner>
        		<gml:upperCorner>337766.150000 447446.276000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6455.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337766.150000 447446.276000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6455</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 080 696</ms:GML_ID>
        <ms:NAZWA>175 080 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175080696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4981">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343852.456241 448032.763935</gml:lowerCorner>
        		<gml:upperCorner>343852.456241 448032.763935</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4981.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343852.456241 448032.763935</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4981</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 065 536</ms:GML_ID>
        <ms:NAZWA>143 065 536</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143065536</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4980">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343732.815000 449092.304000</gml:lowerCorner>
        		<gml:upperCorner>343732.815000 449092.304000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4980.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343732.815000 449092.304000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4980</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 064 467</ms:GML_ID>
        <ms:NAZWA>143 064 467</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143064467</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343718.014000 451273.495000</gml:lowerCorner>
        		<gml:upperCorner>343718.014000 451273.495000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343718.014000 451273.495000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 062 267</ms:GML_ID>
        <ms:NAZWA>143 062 267</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143062267</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343616.033000 451538.785000</gml:lowerCorner>
        		<gml:upperCorner>343616.033000 451538.785000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343616.033000 451538.785000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 061 986</ms:GML_ID>
        <ms:NAZWA>143 061 986</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143061986</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338875.936000 456138.414000</gml:lowerCorner>
        		<gml:upperCorner>338875.936000 456138.414000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338875.936000 456138.414000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 055 165</ms:GML_ID>
        <ms:NAZWA>143 055 165</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143055165</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6556">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355390.471000 472045.631000</gml:lowerCorner>
        		<gml:upperCorner>355390.471000 472045.631000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6556.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355390.471000 472045.631000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6556</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 040 578</ms:GML_ID>
        <ms:NAZWA>181 040 578</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181040578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6557">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356033.956000 472135.665000</gml:lowerCorner>
        		<gml:upperCorner>356033.956000 472135.665000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6557.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356033.956000 472135.665000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6557</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 041 228</ms:GML_ID>
        <ms:NAZWA>181 041 228</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181041228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6558">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356532.341000 472320.306000</gml:lowerCorner>
        		<gml:upperCorner>356532.341000 472320.306000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6558.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356532.341000 472320.306000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6558</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 041 764</ms:GML_ID>
        <ms:NAZWA>181 041 764</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181041764</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6555">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354304.250872 472558.682424</gml:lowerCorner>
        		<gml:upperCorner>354304.250872 472558.682424</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6555.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354304.250872 472558.682424</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6555</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 039 278</ms:GML_ID>
        <ms:NAZWA>181 039 278</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181039278</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6559">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357416.469000 472896.144000</gml:lowerCorner>
        		<gml:upperCorner>357416.469000 472896.144000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6559.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357416.469000 472896.144000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6559</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 042 820</ms:GML_ID>
        <ms:NAZWA>181 042 820</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181042820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6560">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>360110.887000 473058.239000</gml:lowerCorner>
        		<gml:upperCorner>360110.887000 473058.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6560.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>360110.887000 473058.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6560</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 045 558</ms:GML_ID>
        <ms:NAZWA>181 045 558</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181045558</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6554">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353055.592000 473940.463000</gml:lowerCorner>
        		<gml:upperCorner>353055.592000 473940.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6554.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353055.592000 473940.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6554</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 037 361</ms:GML_ID>
        <ms:NAZWA>181 037 361</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181037361</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6553">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351780.251000 474752.271000</gml:lowerCorner>
        		<gml:upperCorner>351780.251000 474752.271000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6553.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351780.251000 474752.271000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6553</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 035 848</ms:GML_ID>
        <ms:NAZWA>181 035 848</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181035848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6552">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351139.758000 475053.959000</gml:lowerCorner>
        		<gml:upperCorner>351139.758000 475053.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6552.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351139.758000 475053.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6552</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 035 138</ms:GML_ID>
        <ms:NAZWA>181 035 138</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181035138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6551">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348749.488000 475906.538000</gml:lowerCorner>
        		<gml:upperCorner>348749.488000 475906.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6551.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348749.488000 475906.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6551</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 032 563</ms:GML_ID>
        <ms:NAZWA>181 032 563</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181032563</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6550">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348112.629000 476195.024000</gml:lowerCorner>
        		<gml:upperCorner>348112.629000 476195.024000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6550.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348112.629000 476195.024000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6550</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 031 854</ms:GML_ID>
        <ms:NAZWA>181 031 854</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181031854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6549">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347397.683000 476732.878000</gml:lowerCorner>
        		<gml:upperCorner>347397.683000 476732.878000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6549.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347397.683000 476732.878000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6549</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 030 960</ms:GML_ID>
        <ms:NAZWA>181 030 960</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181030960</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6548">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346783.888000 477194.949000</gml:lowerCorner>
        		<gml:upperCorner>346783.888000 477194.949000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6548.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346783.888000 477194.949000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6548</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 030 191</ms:GML_ID>
        <ms:NAZWA>181 030 191</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181030191</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6547">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>346152.387000 477670.218000</gml:lowerCorner>
        		<gml:upperCorner>346152.387000 477670.218000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6547.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>346152.387000 477670.218000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6547</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 029 392</ms:GML_ID>
        <ms:NAZWA>181 029 392</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181029392</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6546">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345329.426000 478289.513000</gml:lowerCorner>
        		<gml:upperCorner>345329.426000 478289.513000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6546.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345329.426000 478289.513000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6546</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 028 368</ms:GML_ID>
        <ms:NAZWA>181 028 368</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181028368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6545">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340834.646000 480210.246000</gml:lowerCorner>
        		<gml:upperCorner>340834.646000 480210.246000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6545.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340834.646000 480210.246000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6545</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 023 408</ms:GML_ID>
        <ms:NAZWA>181 023 408</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181023408</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6544">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339261.809000 480561.492000</gml:lowerCorner>
        		<gml:upperCorner>339261.809000 480561.492000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6544.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339261.809000 480561.492000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6544</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 021 793</ms:GML_ID>
        <ms:NAZWA>181 021 793</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181021793</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6543">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338357.737000 480870.032000</gml:lowerCorner>
        		<gml:upperCorner>338357.737000 480870.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6543.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338357.737000 480870.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6543</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 020 827</ms:GML_ID>
        <ms:NAZWA>181 020 827</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181020827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6542">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337851.681000 481303.118000</gml:lowerCorner>
        		<gml:upperCorner>337851.681000 481303.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6542.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337851.681000 481303.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6542</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 020 150</ms:GML_ID>
        <ms:NAZWA>181 020 150</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181020150</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337432.078000 481663.097000</gml:lowerCorner>
        		<gml:upperCorner>337432.078000 481663.097000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337432.078000 481663.097000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 019 608</ms:GML_ID>
        <ms:NAZWA>181 019 608</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181019608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337209.085000 481854.463000</gml:lowerCorner>
        		<gml:upperCorner>337209.085000 481854.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337209.085000 481854.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 019 315</ms:GML_ID>
        <ms:NAZWA>181 019 315</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>181019315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359789.435000 494352.556000</gml:lowerCorner>
        		<gml:upperCorner>359789.435000 494352.556000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359789.435000 494352.556000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 111 743</ms:GML_ID>
        <ms:NAZWA>131 111 743</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK SOSNOWIEC</ms:IDDE>
        <ms:SEARCH>131111743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5086">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311538.009000 446898.422000</gml:lowerCorner>
        		<gml:upperCorner>311538.009000 446898.422000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5086.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311538.009000 446898.422000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5086</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 052 516</ms:GML_ID>
        <ms:NAZWA>144 052 516</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144052516</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5087">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311596.091000 446206.317000</gml:lowerCorner>
        		<gml:upperCorner>311596.091000 446206.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5087.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311596.091000 446206.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5087</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 053 212</ms:GML_ID>
        <ms:NAZWA>144 053 212</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144053212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5088">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311646.189232 445524.551782</gml:lowerCorner>
        		<gml:upperCorner>311646.189232 445524.551782</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5088.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311646.189232 445524.551782</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5088</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 053 896</ms:GML_ID>
        <ms:NAZWA>144 053 896</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144053896</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5089">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311777.687000 443653.540000</gml:lowerCorner>
        		<gml:upperCorner>311777.687000 443653.540000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5089.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311777.687000 443653.540000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5089</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 055 774</ms:GML_ID>
        <ms:NAZWA>144 055 774</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144055774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6428">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314148.258000 454969.388000</gml:lowerCorner>
        		<gml:upperCorner>314148.258000 454969.388000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6428.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314148.258000 454969.388000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6428</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 055 484</ms:GML_ID>
        <ms:NAZWA>175 055 484</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175055484</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6429">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314437.362000 455042.368000</gml:lowerCorner>
        		<gml:upperCorner>314437.362000 455042.368000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6429.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314437.362000 455042.368000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6429</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 055 784</ms:GML_ID>
        <ms:NAZWA>175 055 784</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175055784</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6430">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314950.713000 455171.604000</gml:lowerCorner>
        		<gml:upperCorner>314950.713000 455171.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6430.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314950.713000 455171.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6430</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 056 313</ms:GML_ID>
        <ms:NAZWA>175 056 313</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175056313</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6431">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315222.873000 455240.402000</gml:lowerCorner>
        		<gml:upperCorner>315222.873000 455240.402000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6431.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315222.873000 455240.402000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6431</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 056 594</ms:GML_ID>
        <ms:NAZWA>175 056 594</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175056594</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6432">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315716.916000 455365.446000</gml:lowerCorner>
        		<gml:upperCorner>315716.916000 455365.446000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6432.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315716.916000 455365.446000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6432</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 057 104</ms:GML_ID>
        <ms:NAZWA>175 057 104</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175057104</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6433">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316202.949000 455415.093000</gml:lowerCorner>
        		<gml:upperCorner>316202.949000 455415.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6433.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316202.949000 455415.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6433</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 057 597</ms:GML_ID>
        <ms:NAZWA>175 057 597</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175057597</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6434">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316415.778000 455372.463000</gml:lowerCorner>
        		<gml:upperCorner>316415.778000 455372.463000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6434.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316415.778000 455372.463000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6434</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 057 814</ms:GML_ID>
        <ms:NAZWA>175 057 814</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175057814</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6435">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>316952.975000 455156.004000</gml:lowerCorner>
        		<gml:upperCorner>316952.975000 455156.004000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6435.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>316952.975000 455156.004000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6435</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 058 395</ms:GML_ID>
        <ms:NAZWA>175 058 395</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175058395</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6436">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>317684.817000 454855.810000</gml:lowerCorner>
        		<gml:upperCorner>317684.817000 454855.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6436.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>317684.817000 454855.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6436</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 059 185</ms:GML_ID>
        <ms:NAZWA>175 059 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175059185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6437">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318309.793000 454598.150000</gml:lowerCorner>
        		<gml:upperCorner>318309.793000 454598.150000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6437.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318309.793000 454598.150000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6437</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 059 862</ms:GML_ID>
        <ms:NAZWA>175 059 862</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175059862</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6438">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318817.895000 454387.240000</gml:lowerCorner>
        		<gml:upperCorner>318817.895000 454387.240000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6438.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318817.895000 454387.240000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6438</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 060 412</ms:GML_ID>
        <ms:NAZWA>175 060 412</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175060412</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6439">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319756.692000 453995.202000</gml:lowerCorner>
        		<gml:upperCorner>319756.692000 453995.202000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6439.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319756.692000 453995.202000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6439</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 061 431</ms:GML_ID>
        <ms:NAZWA>175 061 431</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175061431</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6440">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>320688.261000 453603.165000</gml:lowerCorner>
        		<gml:upperCorner>320688.261000 453603.165000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6440.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>320688.261000 453603.165000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6440</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 062 422</ms:GML_ID>
        <ms:NAZWA>175 062 422</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175062422</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6441">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321309.794000 453341.022000</gml:lowerCorner>
        		<gml:upperCorner>321309.794000 453341.022000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6441.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321309.794000 453341.022000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6441</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 063 116</ms:GML_ID>
        <ms:NAZWA>175 063 116</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175063116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6442">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321895.990000 453094.874000</gml:lowerCorner>
        		<gml:upperCorner>321895.990000 453094.874000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6442.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321895.990000 453094.874000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6442</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 063 753</ms:GML_ID>
        <ms:NAZWA>175 063 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175063753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6443">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>322666.346000 452774.485000</gml:lowerCorner>
        		<gml:upperCorner>322666.346000 452774.485000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6443.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>322666.346000 452774.485000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6443</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 064 588</ms:GML_ID>
        <ms:NAZWA>175 064 588</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175064588</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6444">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324122.152000 452120.918000</gml:lowerCorner>
        		<gml:upperCorner>324122.152000 452120.918000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6444.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324122.152000 452120.918000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6444</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 066 185</ms:GML_ID>
        <ms:NAZWA>175 066 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175066185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6445">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325479.885000 451394.629000</gml:lowerCorner>
        		<gml:upperCorner>325479.885000 451394.629000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6445.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325479.885000 451394.629000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6445</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 067 727</ms:GML_ID>
        <ms:NAZWA>175 067 727</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175067727</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6446">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>326223.413000 450998.126000</gml:lowerCorner>
        		<gml:upperCorner>326223.413000 450998.126000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6446.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>326223.413000 450998.126000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6446</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 068 570</ms:GML_ID>
        <ms:NAZWA>175 068 570</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175068570</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6447">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327336.864000 450443.876000</gml:lowerCorner>
        		<gml:upperCorner>327336.864000 450443.876000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6447.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327336.864000 450443.876000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6447</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 069 815</ms:GML_ID>
        <ms:NAZWA>175 069 815</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175069815</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6448">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329073.673000 449698.977000</gml:lowerCorner>
        		<gml:upperCorner>329073.673000 449698.977000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6448.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329073.673000 449698.977000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6448</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 071 709</ms:GML_ID>
        <ms:NAZWA>175 071 709</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175071709</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6449">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329663.945000 449559.675000</gml:lowerCorner>
        		<gml:upperCorner>329663.945000 449559.675000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6449.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329663.945000 449559.675000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6449</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 072 315</ms:GML_ID>
        <ms:NAZWA>175 072 315</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175072315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6450">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330205.112000 449429.626000</gml:lowerCorner>
        		<gml:upperCorner>330205.112000 449429.626000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6450.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330205.112000 449429.626000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6450</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 072 873</ms:GML_ID>
        <ms:NAZWA>175 072 873</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175072873</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6451">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332396.634000 448917.898000</gml:lowerCorner>
        		<gml:upperCorner>332396.634000 448917.898000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6451.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332396.634000 448917.898000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6451</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 075 124</ms:GML_ID>
        <ms:NAZWA>175 075 124</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175075124</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6452">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332984.547000 448757.358000</gml:lowerCorner>
        		<gml:upperCorner>332984.547000 448757.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6452.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332984.547000 448757.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6452</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 075 734</ms:GML_ID>
        <ms:NAZWA>175 075 734</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175075734</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333727.520000 461141.316000</gml:lowerCorner>
        		<gml:upperCorner>333727.520000 461141.316000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333727.520000 461141.316000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 047 951</ms:GML_ID>
        <ms:NAZWA>143 047 951</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143047951</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6453">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333995.422000 448479.805000</gml:lowerCorner>
        		<gml:upperCorner>333995.422000 448479.805000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6453.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333995.422000 448479.805000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6453</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 076 783</ms:GML_ID>
        <ms:NAZWA>175 076 783</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175076783</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334677.996000 459982.192000</gml:lowerCorner>
        		<gml:upperCorner>334677.996000 459982.192000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334677.996000 459982.192000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 049 460</ms:GML_ID>
        <ms:NAZWA>143 049 460</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143049460</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6454">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>335949.262000 447945.739000</gml:lowerCorner>
        		<gml:upperCorner>335949.262000 447945.739000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6454.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>335949.262000 447945.739000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6454</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 078 811</ms:GML_ID>
        <ms:NAZWA>175 078 811</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175078811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>336841.862000 458126.912000</gml:lowerCorner>
        		<gml:upperCorner>336841.862000 458126.912000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>336841.862000 458126.912000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 052 311</ms:GML_ID>
        <ms:NAZWA>143 052 311</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143052311</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6456">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340218.904000 446556.884000</gml:lowerCorner>
        		<gml:upperCorner>340218.904000 446556.884000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6456.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340218.904000 446556.884000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6456</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 083 320</ms:GML_ID>
        <ms:NAZWA>175 083 320</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175083320</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6457">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341308.030000 445959.443000</gml:lowerCorner>
        		<gml:upperCorner>341308.030000 445959.443000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6457.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341308.030000 445959.443000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6457</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 084 564</ms:GML_ID>
        <ms:NAZWA>175 084 564</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175084564</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6458">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341989.388000 445585.494000</gml:lowerCorner>
        		<gml:upperCorner>341989.388000 445585.494000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6458.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341989.388000 445585.494000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6458</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 085 341</ms:GML_ID>
        <ms:NAZWA>175 085 341</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175085341</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342306.320000 445411.130000</gml:lowerCorner>
        		<gml:upperCorner>342306.320000 445411.130000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342306.320000 445411.130000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 085 704</ms:GML_ID>
        <ms:NAZWA>175 085 704</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175085704</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6460">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>342555.221000 445273.846000</gml:lowerCorner>
        		<gml:upperCorner>342555.221000 445273.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6460.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>342555.221000 445273.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6460</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 085 987</ms:GML_ID>
        <ms:NAZWA>175 085 987</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175085987</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6461">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343148.910257 444975.170439</gml:lowerCorner>
        		<gml:upperCorner>343148.910257 444975.170439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6461.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343148.910257 444975.170439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6461</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.175 086 654</ms:GML_ID>
        <ms:NAZWA>175 086 654</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>175086654</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343259.634000 444227.090000</gml:lowerCorner>
        		<gml:upperCorner>343259.634000 444227.090000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343259.634000 444227.090000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 022 910</ms:GML_ID>
        <ms:NAZWA>293 022 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293022910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343672.525000 444440.846000</gml:lowerCorner>
        		<gml:upperCorner>343672.525000 444440.846000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343672.525000 444440.846000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 023 368</ms:GML_ID>
        <ms:NAZWA>293 023 368</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293023368</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4982">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343945.551000 447218.516000</gml:lowerCorner>
        		<gml:upperCorner>343945.551000 447218.516000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4982.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343945.551000 447218.516000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4982</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 066 355</ms:GML_ID>
        <ms:NAZWA>143 066 355</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143066355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4983">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344163.735000 445692.563000</gml:lowerCorner>
        		<gml:upperCorner>344163.735000 445692.563000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4983.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344163.735000 445692.563000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4983</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 067 901</ms:GML_ID>
        <ms:NAZWA>143 067 901</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143067901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4984">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344314.339705 445172.456168</gml:lowerCorner>
        		<gml:upperCorner>344314.339705 445172.456168</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4984.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344314.339705 445172.456168</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4984</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 068 441</ms:GML_ID>
        <ms:NAZWA>143 068 441</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143068441</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344355.204834 444376.087680</gml:lowerCorner>
        		<gml:upperCorner>344355.204834 444376.087680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344355.204834 444376.087680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 024 088</ms:GML_ID>
        <ms:NAZWA>293 024 088</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293024088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4985">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344805.421752 444104.534776</gml:lowerCorner>
        		<gml:upperCorner>344805.421752 444104.534776</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4985.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344805.421752 444104.534776</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4985</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 069 639</ms:GML_ID>
        <ms:NAZWA>143 069 639</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143069639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4986">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345808.532163 443515.816640</gml:lowerCorner>
        		<gml:upperCorner>345808.532163 443515.816640</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4986.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345808.532163 443515.816640</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4986</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 070 820</ms:GML_ID>
        <ms:NAZWA>143 070 820</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143070820</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.697">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348858.870000 443748.930000</gml:lowerCorner>
        		<gml:upperCorner>348858.870000 443748.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.697.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348858.870000 443748.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>697</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 003 715</ms:GML_ID>
        <ms:NAZWA>272 003 715</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272003715</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.698">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349701.516000 443824.013000</gml:lowerCorner>
        		<gml:upperCorner>349701.516000 443824.013000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.698.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349701.516000 443824.013000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>698</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 004 561</ms:GML_ID>
        <ms:NAZWA>272 004 561</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272004561</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.699">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350207.195000 443889.321000</gml:lowerCorner>
        		<gml:upperCorner>350207.195000 443889.321000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.699.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350207.195000 443889.321000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>699</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 005 074</ms:GML_ID>
        <ms:NAZWA>272 005 074</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272005074</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.700">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350641.468000 443946.414000</gml:lowerCorner>
        		<gml:upperCorner>350641.468000 443946.414000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.700.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350641.468000 443946.414000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>700</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 005 511</ms:GML_ID>
        <ms:NAZWA>272 005 511</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272005511</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.701">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351494.235000 444059.895000</gml:lowerCorner>
        		<gml:upperCorner>351494.235000 444059.895000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.701.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351494.235000 444059.895000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>701</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 006 371</ms:GML_ID>
        <ms:NAZWA>272 006 371</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272006371</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.702">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355110.818000 444670.241000</gml:lowerCorner>
        		<gml:upperCorner>355110.818000 444670.241000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.702.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355110.818000 444670.241000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>702</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 010 045</ms:GML_ID>
        <ms:NAZWA>272 010 045</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272010045</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.703">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356457.333000 444689.604000</gml:lowerCorner>
        		<gml:upperCorner>356457.333000 444689.604000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.703.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356457.333000 444689.604000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>703</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 011 393</ms:GML_ID>
        <ms:NAZWA>272 011 393</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272011393</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.704">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>357494.506000 444673.083000</gml:lowerCorner>
        		<gml:upperCorner>357494.506000 444673.083000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.704.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>357494.506000 444673.083000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>704</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 012 432</ms:GML_ID>
        <ms:NAZWA>272 012 432</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272012432</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.705">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>358480.140769 444475.886157</gml:lowerCorner>
        		<gml:upperCorner>358480.140769 444475.886157</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.705.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>358480.140769 444475.886157</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>705</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 013 438</ms:GML_ID>
        <ms:NAZWA>272 013 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272013438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.706">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>359360.318000 444289.888000</gml:lowerCorner>
        		<gml:upperCorner>359360.318000 444289.888000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.706.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>359360.318000 444289.888000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>706</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 014 334</ms:GML_ID>
        <ms:NAZWA>272 014 334</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272014334</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.711">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366774.839829 440421.787952</gml:lowerCorner>
        		<gml:upperCorner>366774.839829 440421.787952</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.711.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366774.839829 440421.787952</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>711</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 023 235</ms:GML_ID>
        <ms:NAZWA>272 023 235</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272023235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.710">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>366572.377000 440715.740000</gml:lowerCorner>
        		<gml:upperCorner>366572.377000 440715.740000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.710.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>366572.377000 440715.740000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>710</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 022 876</ms:GML_ID>
        <ms:NAZWA>272 022 876</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272022876</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.708">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365130.758000 442319.290000</gml:lowerCorner>
        		<gml:upperCorner>365130.758000 442319.290000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.708.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365130.758000 442319.290000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>708</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 020 712</ms:GML_ID>
        <ms:NAZWA>272 020 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272020712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.707">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>364805.182000 442613.717000</gml:lowerCorner>
        		<gml:upperCorner>364805.182000 442613.717000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.707.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>364805.182000 442613.717000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>707</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 020 272</ms:GML_ID>
        <ms:NAZWA>272 020 272</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272020272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380728.664692 443939.556615</gml:lowerCorner>
        		<gml:upperCorner>380728.664692 443939.556615</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380728.664692 443939.556615</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 088 539</ms:GML_ID>
        <ms:NAZWA>181 088 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181088539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6593">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380433.715000 444717.011000</gml:lowerCorner>
        		<gml:upperCorner>380433.715000 444717.011000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6593.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380433.715000 444717.011000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6593</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 087 707</ms:GML_ID>
        <ms:NAZWA>181 087 707</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181087707</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6592">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380153.508000 445488.570000</gml:lowerCorner>
        		<gml:upperCorner>380153.508000 445488.570000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6592.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380153.508000 445488.570000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6592</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 086 875</ms:GML_ID>
        <ms:NAZWA>181 086 875</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181086875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380007.613000 446338.235000</gml:lowerCorner>
        		<gml:upperCorner>380007.613000 446338.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380007.613000 446338.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 086 022</ms:GML_ID>
        <ms:NAZWA>181 086 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181086022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379743.844000 447982.490000</gml:lowerCorner>
        		<gml:upperCorner>379743.844000 447982.490000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379743.844000 447982.490000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 084 355</ms:GML_ID>
        <ms:NAZWA>181 084 355</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181084355</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379332.553000 450549.072000</gml:lowerCorner>
        		<gml:upperCorner>379332.553000 450549.072000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379332.553000 450549.072000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 081 753</ms:GML_ID>
        <ms:NAZWA>181 081 753</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181081753</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379216.784000 451272.831000</gml:lowerCorner>
        		<gml:upperCorner>379216.784000 451272.831000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379216.784000 451272.831000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 081 020</ms:GML_ID>
        <ms:NAZWA>181 081 020</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181081020</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378976.217000 452775.399000</gml:lowerCorner>
        		<gml:upperCorner>378976.217000 452775.399000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378976.217000 452775.399000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 079 497</ms:GML_ID>
        <ms:NAZWA>181 079 497</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181079497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378898.652006 453276.351102</gml:lowerCorner>
        		<gml:upperCorner>378898.652006 453276.351102</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378898.652006 453276.351102</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 078 980</ms:GML_ID>
        <ms:NAZWA>181 078 980</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181078980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378491.883000 455793.249000</gml:lowerCorner>
        		<gml:upperCorner>378491.883000 455793.249000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378491.883000 455793.249000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 076 438</ms:GML_ID>
        <ms:NAZWA>181 076 438</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181076438</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378274.633000 457140.541000</gml:lowerCorner>
        		<gml:upperCorner>378274.633000 457140.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378274.633000 457140.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 075 085</ms:GML_ID>
        <ms:NAZWA>181 075 085</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181075085</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378150.838000 457802.632000</gml:lowerCorner>
        		<gml:upperCorner>378150.838000 457802.632000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378150.838000 457802.632000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 074 397</ms:GML_ID>
        <ms:NAZWA>181 074 397</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181074397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377846.341000 458807.696000</gml:lowerCorner>
        		<gml:upperCorner>377846.341000 458807.696000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377846.341000 458807.696000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 073 346</ms:GML_ID>
        <ms:NAZWA>181 073 346</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181073346</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377587.518000 459661.469000</gml:lowerCorner>
        		<gml:upperCorner>377587.518000 459661.469000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377587.518000 459661.469000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 072 455</ms:GML_ID>
        <ms:NAZWA>181 072 455</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181072455</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377145.774000 461118.517000</gml:lowerCorner>
        		<gml:upperCorner>377145.774000 461118.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377145.774000 461118.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 070 930</ms:GML_ID>
        <ms:NAZWA>181 070 930</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181070930</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>377076.363000 461347.196000</gml:lowerCorner>
        		<gml:upperCorner>377076.363000 461347.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>377076.363000 461347.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 070 691</ms:GML_ID>
        <ms:NAZWA>181 070 691</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181070691</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376924.412000 461848.523000</gml:lowerCorner>
        		<gml:upperCorner>376924.412000 461848.523000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376924.412000 461848.523000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 070 166</ms:GML_ID>
        <ms:NAZWA>181 070 166</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181070166</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376761.245000 462387.282000</gml:lowerCorner>
        		<gml:upperCorner>376761.245000 462387.282000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376761.245000 462387.282000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 069 604</ms:GML_ID>
        <ms:NAZWA>181 069 604</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181069604</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381852.587000 433223.086000</gml:lowerCorner>
        		<gml:upperCorner>381852.587000 433223.086000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381852.587000 433223.086000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 099 614</ms:GML_ID>
        <ms:NAZWA>181 099 614</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181099614</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381876.091985 438696.906381</gml:lowerCorner>
        		<gml:upperCorner>381876.091985 438696.906381</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381876.091985 438696.906381</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 094 112</ms:GML_ID>
        <ms:NAZWA>181 094 112</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181094112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381935.155000 433699.194000</gml:lowerCorner>
        		<gml:upperCorner>381935.155000 433699.194000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381935.155000 433699.194000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 099 131</ms:GML_ID>
        <ms:NAZWA>181 099 131</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181099131</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381967.784000 436133.984000</gml:lowerCorner>
        		<gml:upperCorner>381967.784000 436133.984000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381967.784000 436133.984000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 096 680</ms:GML_ID>
        <ms:NAZWA>181 096 680</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181096680</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381988.514000 435795.930000</gml:lowerCorner>
        		<gml:upperCorner>381988.514000 435795.930000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381988.514000 435795.930000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 097 019</ms:GML_ID>
        <ms:NAZWA>181 097 019</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181097019</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382020.437000 435279.239000</gml:lowerCorner>
        		<gml:upperCorner>382020.437000 435279.239000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382020.437000 435279.239000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 097 537</ms:GML_ID>
        <ms:NAZWA>181 097 537</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181097537</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2655">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382458.213000 429664.235000</gml:lowerCorner>
        		<gml:upperCorner>382458.213000 429664.235000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2655.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382458.213000 429664.235000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2655</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.812 003 003</ms:GML_ID>
        <ms:NAZWA>812 003 003</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>812003003</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>382989.619326 429651.212844</gml:lowerCorner>
        		<gml:upperCorner>382989.619326 429651.212844</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>382989.619326 429651.212844</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 043 015</ms:GML_ID>
        <ms:NAZWA>272 043 015</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272043015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384053.253000 429899.955000</gml:lowerCorner>
        		<gml:upperCorner>384053.253000 429899.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384053.253000 429899.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 044 144</ms:GML_ID>
        <ms:NAZWA>272 044 144</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272044144</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>384786.522000 430226.712000</gml:lowerCorner>
        		<gml:upperCorner>384786.522000 430226.712000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>384786.522000 430226.712000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 044 948</ms:GML_ID>
        <ms:NAZWA>272 044 948</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272044948</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>386375.984209 430144.495675</gml:lowerCorner>
        		<gml:upperCorner>386375.984209 430144.495675</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>386375.984209 430144.495675</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 046 584</ms:GML_ID>
        <ms:NAZWA>272 046 584</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272046584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>387101.578397 430017.741928</gml:lowerCorner>
        		<gml:upperCorner>387101.578397 430017.741928</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>387101.578397 430017.741928</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 047 288</ms:GML_ID>
        <ms:NAZWA>272 047 288</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272047288</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>388837.879000 429708.856000</gml:lowerCorner>
        		<gml:upperCorner>388837.879000 429708.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>388837.879000 429708.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 049 059</ms:GML_ID>
        <ms:NAZWA>272 049 059</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272049059</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>392685.532000 428461.317000</gml:lowerCorner>
        		<gml:upperCorner>392685.532000 428461.317000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>392685.532000 428461.317000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 053 207</ms:GML_ID>
        <ms:NAZWA>272 053 207</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272053207</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.730">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>394115.201000 427619.718000</gml:lowerCorner>
        		<gml:upperCorner>394115.201000 427619.718000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.730.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>394115.201000 427619.718000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>730</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 055 077</ms:GML_ID>
        <ms:NAZWA>272 055 077</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272055077</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.731">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396232.337000 426472.413000</gml:lowerCorner>
        		<gml:upperCorner>396232.337000 426472.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.731.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396232.337000 426472.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>731</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 057 902</ms:GML_ID>
        <ms:NAZWA>272 057 902</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272057902</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>396909.696972 426120.814360</gml:lowerCorner>
        		<gml:upperCorner>396909.696972 426120.814360</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>396909.696972 426120.814360</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 058 657</ms:GML_ID>
        <ms:NAZWA>272 058 657</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272058657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>397875.270000 425889.339000</gml:lowerCorner>
        		<gml:upperCorner>397875.270000 425889.339000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>397875.270000 425889.339000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 059 690</ms:GML_ID>
        <ms:NAZWA>272 059 690</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272059690</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>398561.344000 426026.644000</gml:lowerCorner>
        		<gml:upperCorner>398561.344000 426026.644000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>398561.344000 426026.644000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 060 390</ms:GML_ID>
        <ms:NAZWA>272 060 390</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272060390</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>399627.832150 426177.098324</gml:lowerCorner>
        		<gml:upperCorner>399627.832150 426177.098324</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>399627.832150 426177.098324</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 061 472</ms:GML_ID>
        <ms:NAZWA>272 061 472</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272061472</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400159.881000 424892.419000</gml:lowerCorner>
        		<gml:upperCorner>400159.881000 424892.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400159.881000 424892.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 063 041</ms:GML_ID>
        <ms:NAZWA>272 063 041</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272063041</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.716">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>373427.187000 435645.294000</gml:lowerCorner>
        		<gml:upperCorner>373427.187000 435645.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.716.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>373427.187000 435645.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>716</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 031 533</ms:GML_ID>
        <ms:NAZWA>272 031 533</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272031533</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.717">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>374417.869000 434720.039000</gml:lowerCorner>
        		<gml:upperCorner>374417.869000 434720.039000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.717.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>374417.869000 434720.039000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>717</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 032 901</ms:GML_ID>
        <ms:NAZWA>272 032 901</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272032901</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.718">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>375582.578000 433854.648000</gml:lowerCorner>
        		<gml:upperCorner>375582.578000 433854.648000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.718.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>375582.578000 433854.648000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>718</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 034 352</ms:GML_ID>
        <ms:NAZWA>272 034 352</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272034352</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376094.018000 433473.412000</gml:lowerCorner>
        		<gml:upperCorner>376094.018000 433473.412000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376094.018000 433473.412000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 034 988</ms:GML_ID>
        <ms:NAZWA>272 034 988</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272034988</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>376578.395000 433113.762000</gml:lowerCorner>
        		<gml:upperCorner>376578.395000 433113.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>376578.395000 433113.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 035 592</ms:GML_ID>
        <ms:NAZWA>272 035 592</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272035592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>378742.823000 431505.048000</gml:lowerCorner>
        		<gml:upperCorner>378742.823000 431505.048000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>378742.823000 431505.048000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 038 287</ms:GML_ID>
        <ms:NAZWA>272 038 287</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272038287</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380734.398589 429292.912445</gml:lowerCorner>
        		<gml:upperCorner>380734.398589 429292.912445</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380734.398589 429292.912445</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 103 731</ms:GML_ID>
        <ms:NAZWA>181 103 731</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181103731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6610">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380862.753000 424068.119000</gml:lowerCorner>
        		<gml:upperCorner>380862.753000 424068.119000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6610.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380862.753000 424068.119000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6610</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 109 034</ms:GML_ID>
        <ms:NAZWA>181 109 034</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181109034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380865.122943 429879.951448</gml:lowerCorner>
        		<gml:upperCorner>380865.122943 429879.951448</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380865.122943 429879.951448</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 103 125</ms:GML_ID>
        <ms:NAZWA>181 103 125</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181103125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380890.119328 425957.592255</gml:lowerCorner>
        		<gml:upperCorner>380890.119328 425957.592255</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380890.119328 425957.592255</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 107 119</ms:GML_ID>
        <ms:NAZWA>181 107 119</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181107119</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2657">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381034.875000 430197.788000</gml:lowerCorner>
        		<gml:upperCorner>381034.875000 430197.788000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2657.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381034.875000 430197.788000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2657</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.814 000 480</ms:GML_ID>
        <ms:NAZWA>814 000 480</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>814000480</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381054.822043 426849.523532</gml:lowerCorner>
        		<gml:upperCorner>381054.822043 426849.523532</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381054.822043 426849.523532</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 106 212</ms:GML_ID>
        <ms:NAZWA>181 106 212</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181106212</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2654">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381088.297000 429081.365000</gml:lowerCorner>
        		<gml:upperCorner>381088.297000 429081.365000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2654.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381088.297000 429081.365000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2654</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.812 001 468</ms:GML_ID>
        <ms:NAZWA>812 001 468</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>812001468</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381197.915768 430716.059834</gml:lowerCorner>
        		<gml:upperCorner>381197.915768 430716.059834</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381197.915768 430716.059834</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 102 222</ms:GML_ID>
        <ms:NAZWA>181 102 222</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181102222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.2656">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381275.794098 430717.046595</gml:lowerCorner>
        		<gml:upperCorner>381275.794098 430717.046595</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.2656.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381275.794098 430717.046595</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>2656</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.813 000 309</ms:GML_ID>
        <ms:NAZWA>813 000 309</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>813000309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381319.658000 442470.457000</gml:lowerCorner>
        		<gml:upperCorner>381319.658000 442470.457000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381319.658000 442470.457000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 090 125</ms:GML_ID>
        <ms:NAZWA>181 090 125</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181090125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381688.417000 432271.763000</gml:lowerCorner>
        		<gml:upperCorner>381688.417000 432271.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381688.417000 432271.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 100 579</ms:GML_ID>
        <ms:NAZWA>181 100 579</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181100579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381741.752171 430118.082966</gml:lowerCorner>
        		<gml:upperCorner>381741.752171 430118.082966</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381741.752171 430118.082966</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 041 676</ms:GML_ID>
        <ms:NAZWA>272 041 676</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272041676</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381746.922000 432610.994000</gml:lowerCorner>
        		<gml:upperCorner>381746.922000 432610.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381746.922000 432610.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 100 235</ms:GML_ID>
        <ms:NAZWA>181 100 235</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181100235</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381797.108000 441725.750000</gml:lowerCorner>
        		<gml:upperCorner>381797.108000 441725.750000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381797.108000 441725.750000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 091 011</ms:GML_ID>
        <ms:NAZWA>181 091 011</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181091011</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.459">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313626.540000 423923.793000</gml:lowerCorner>
        		<gml:upperCorner>313626.540000 423923.793000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.459.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313626.540000 423923.793000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>459</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.277 007 828</ms:GML_ID>
        <ms:NAZWA>277 007 828</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>277007828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5102">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310770.513945 424857.513283</gml:lowerCorner>
        		<gml:upperCorner>310770.513945 424857.513283</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5102.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310770.513945 424857.513283</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5102</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 075 198</ms:GML_ID>
        <ms:NAZWA>144 075 198</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144075198</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4568">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311663.486000 428104.539000</gml:lowerCorner>
        		<gml:upperCorner>311663.486000 428104.539000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4568.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311663.486000 428104.539000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4568</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 004 634</ms:GML_ID>
        <ms:NAZWA>301 004 634</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301004634</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4569">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311872.194000 428224.054000</gml:lowerCorner>
        		<gml:upperCorner>311872.194000 428224.054000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4569.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311872.194000 428224.054000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4569</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 004 874</ms:GML_ID>
        <ms:NAZWA>301 004 874</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301004874</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4570">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312263.401000 428448.258000</gml:lowerCorner>
        		<gml:upperCorner>312263.401000 428448.258000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4570.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312263.401000 428448.258000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4570</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 005 325</ms:GML_ID>
        <ms:NAZWA>301 005 325</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301005325</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4571">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>312736.816521 428726.407740</gml:lowerCorner>
        		<gml:upperCorner>312736.816521 428726.407740</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4571.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>312736.816521 428726.407740</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4571</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 005 880</ms:GML_ID>
        <ms:NAZWA>301 005 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301005880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4572">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>313055.335000 428902.038000</gml:lowerCorner>
        		<gml:upperCorner>313055.335000 428902.038000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4572.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>313055.335000 428902.038000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4572</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 006 238</ms:GML_ID>
        <ms:NAZWA>301 006 238</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301006238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4573">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>314711.909000 429851.667000</gml:lowerCorner>
        		<gml:upperCorner>314711.909000 429851.667000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4573.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>314711.909000 429851.667000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4573</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 008 149</ms:GML_ID>
        <ms:NAZWA>301 008 149</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301008149</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4574">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315470.749000 430286.372000</gml:lowerCorner>
        		<gml:upperCorner>315470.749000 430286.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4574.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315470.749000 430286.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4574</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 009 024</ms:GML_ID>
        <ms:NAZWA>301 009 024</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301009024</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4575">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>315963.051000 430568.624000</gml:lowerCorner>
        		<gml:upperCorner>315963.051000 430568.624000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4575.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>315963.051000 430568.624000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4575</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 009 592</ms:GML_ID>
        <ms:NAZWA>301 009 592</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301009592</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4576">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318309.150000 431913.670000</gml:lowerCorner>
        		<gml:upperCorner>318309.150000 431913.670000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4576.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318309.150000 431913.670000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4576</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 012 298</ms:GML_ID>
        <ms:NAZWA>301 012 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301012298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5097">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310780.016615 434567.654070</gml:lowerCorner>
        		<gml:upperCorner>310780.016615 434567.654070</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5097.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310780.016615 434567.654070</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5097</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 065 367</ms:GML_ID>
        <ms:NAZWA>144 065 367</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144065367</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5096">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311016.493457 435195.107406</gml:lowerCorner>
        		<gml:upperCorner>311016.493457 435195.107406</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5096.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311016.493457 435195.107406</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5096</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 064 698</ms:GML_ID>
        <ms:NAZWA>144 064 698</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144064698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5095">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311226.080837 435736.424932</gml:lowerCorner>
        		<gml:upperCorner>311226.080837 435736.424932</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5095.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311226.080837 435736.424932</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5095</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 064 116</ms:GML_ID>
        <ms:NAZWA>144 064 116</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144064116</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5094">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311348.347240 436317.333925</gml:lowerCorner>
        		<gml:upperCorner>311348.347240 436317.333925</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5094.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311348.347240 436317.333925</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5094</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 063 520</ms:GML_ID>
        <ms:NAZWA>144 063 520</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144063520</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5093">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311270.069000 436885.332000</gml:lowerCorner>
        		<gml:upperCorner>311270.069000 436885.332000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5093.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311270.069000 436885.332000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5093</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 062 944</ms:GML_ID>
        <ms:NAZWA>144 062 944</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144062944</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5092">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311206.829000 437216.087000</gml:lowerCorner>
        		<gml:upperCorner>311206.829000 437216.087000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5092.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311206.829000 437216.087000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5092</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 062 607</ms:GML_ID>
        <ms:NAZWA>144 062 607</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144062607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5091">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311627.891000 441698.671000</gml:lowerCorner>
        		<gml:upperCorner>311627.891000 441698.671000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5091.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311627.891000 441698.671000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5091</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 057 773</ms:GML_ID>
        <ms:NAZWA>144 057 773</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144057773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5090">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>311853.952000 442451.253000</gml:lowerCorner>
        		<gml:upperCorner>311853.952000 442451.253000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5090.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>311853.952000 442451.253000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5090</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 056 977</ms:GML_ID>
        <ms:NAZWA>144 056 977</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144056977</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4577">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>318735.352000 432158.032000</gml:lowerCorner>
        		<gml:upperCorner>318735.352000 432158.032000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4577.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>318735.352000 432158.032000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4577</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 012 790</ms:GML_ID>
        <ms:NAZWA>301 012 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301012790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4578">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>319637.488000 432454.406000</gml:lowerCorner>
        		<gml:upperCorner>319637.488000 432454.406000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4578.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>319637.488000 432454.406000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4578</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 013 757</ms:GML_ID>
        <ms:NAZWA>301 013 757</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301013757</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4579">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>321123.053000 432546.856000</gml:lowerCorner>
        		<gml:upperCorner>321123.053000 432546.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4579.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>321123.053000 432546.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4579</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 015 247</ms:GML_ID>
        <ms:NAZWA>301 015 247</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301015247</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4580">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>323507.415000 432695.294000</gml:lowerCorner>
        		<gml:upperCorner>323507.415000 432695.294000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4580.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>323507.415000 432695.294000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4580</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 017 639</ms:GML_ID>
        <ms:NAZWA>301 017 639</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301017639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4581">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>324662.166000 432767.483000</gml:lowerCorner>
        		<gml:upperCorner>324662.166000 432767.483000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4581.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>324662.166000 432767.483000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4581</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 018 796</ms:GML_ID>
        <ms:NAZWA>301 018 796</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301018796</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4582">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>325725.084154 432826.362386</gml:lowerCorner>
        		<gml:upperCorner>325725.084154 432826.362386</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4582.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>325725.084154 432826.362386</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4582</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 019 859</ms:GML_ID>
        <ms:NAZWA>301 019 859</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301019859</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4583">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>327841.428000 431400.481000</gml:lowerCorner>
        		<gml:upperCorner>327841.428000 431400.481000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4583.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>327841.428000 431400.481000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4583</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 022 452</ms:GML_ID>
        <ms:NAZWA>301 022 452</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301022452</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4584">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>328475.750000 430896.538000</gml:lowerCorner>
        		<gml:upperCorner>328475.750000 430896.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4584.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>328475.750000 430896.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4584</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 023 262</ms:GML_ID>
        <ms:NAZWA>301 023 262</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301023262</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>329404.388000 435359.023000</gml:lowerCorner>
        		<gml:upperCorner>329404.388000 435359.023000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>329404.388000 435359.023000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 004 807</ms:GML_ID>
        <ms:NAZWA>293 004 807</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293004807</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4585">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>330111.547000 429595.745000</gml:lowerCorner>
        		<gml:upperCorner>330111.547000 429595.745000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4585.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>330111.547000 429595.745000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4585</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 025 353</ms:GML_ID>
        <ms:NAZWA>301 025 353</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301025353</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4586">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332071.430000 426967.488000</gml:lowerCorner>
        		<gml:upperCorner>332071.430000 426967.488000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4586.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332071.430000 426967.488000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4586</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 028 637</ms:GML_ID>
        <ms:NAZWA>301 028 637</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301028637</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4587">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332403.465000 426515.767000</gml:lowerCorner>
        		<gml:upperCorner>332403.465000 426515.767000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4587.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332403.465000 426515.767000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4587</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 029 196</ms:GML_ID>
        <ms:NAZWA>301 029 196</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301029196</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>332472.580000 436310.848000</gml:lowerCorner>
        		<gml:upperCorner>332472.580000 436310.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>332472.580000 436310.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 008 265</ms:GML_ID>
        <ms:NAZWA>293 008 265</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293008265</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4588">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333084.589000 425589.195000</gml:lowerCorner>
        		<gml:upperCorner>333084.589000 425589.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4588.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333084.589000 425589.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4588</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 030 347</ms:GML_ID>
        <ms:NAZWA>301 030 347</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301030347</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4589">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>333872.056000 424563.031000</gml:lowerCorner>
        		<gml:upperCorner>333872.056000 424563.031000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4589.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>333872.056000 424563.031000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4589</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 031 643</ms:GML_ID>
        <ms:NAZWA>301 031 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301031643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4590">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334443.711000 423836.763000</gml:lowerCorner>
        		<gml:upperCorner>334443.711000 423836.763000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4590.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334443.711000 423836.763000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4590</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 032 566</ms:GML_ID>
        <ms:NAZWA>301 032 566</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301032566</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334623.175000 436709.917000</gml:lowerCorner>
        		<gml:upperCorner>334623.175000 436709.917000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334623.175000 436709.917000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 010 457</ms:GML_ID>
        <ms:NAZWA>293 010 457</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293010457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4591">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>334826.481000 423371.881000</gml:lowerCorner>
        		<gml:upperCorner>334826.481000 423371.881000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4591.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>334826.481000 423371.881000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4591</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 033 170</ms:GML_ID>
        <ms:NAZWA>301 033 170</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301033170</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337704.897000 437910.029000</gml:lowerCorner>
        		<gml:upperCorner>337704.897000 437910.029000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337704.897000 437910.029000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 013 887</ms:GML_ID>
        <ms:NAZWA>293 013 887</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293013887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.747">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427037.981000 417088.232000</gml:lowerCorner>
        		<gml:upperCorner>427037.981000 417088.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.747.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427037.981000 417088.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>747</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 092 314</ms:GML_ID>
        <ms:NAZWA>272 092 314</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272092314</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.746">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425131.942000 417213.285000</gml:lowerCorner>
        		<gml:upperCorner>425131.942000 417213.285000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.746.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425131.942000 417213.285000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>746</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 090 403</ms:GML_ID>
        <ms:NAZWA>272 090 403</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272090403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.743">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>411695.057000 419071.196000</gml:lowerCorner>
        		<gml:upperCorner>411695.057000 419071.196000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.743.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>411695.057000 419071.196000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>743</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 076 696</ms:GML_ID>
        <ms:NAZWA>272 076 696</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272076696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7541">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424334.359000 419321.812000</gml:lowerCorner>
        		<gml:upperCorner>424334.359000 419321.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7541.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424334.359000 419321.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7541</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 131 171</ms:GML_ID>
        <ms:NAZWA>014 131 171</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014131171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7540">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>424517.867000 420022.027000</gml:lowerCorner>
        		<gml:upperCorner>424517.867000 420022.027000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7540.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>424517.867000 420022.027000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7540</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 130 449</ms:GML_ID>
        <ms:NAZWA>014 130 449</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014130449</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7539">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425046.908990 421511.044174</gml:lowerCorner>
        		<gml:upperCorner>425046.908990 421511.044174</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7539.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425046.908990 421511.044174</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7539</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 128 865</ms:GML_ID>
        <ms:NAZWA>014 128 865</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014128865</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7538">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>425489.586000 422759.496000</gml:lowerCorner>
        		<gml:upperCorner>425489.586000 422759.496000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7538.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>425489.586000 422759.496000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7538</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 127 539</ms:GML_ID>
        <ms:NAZWA>014 127 539</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014127539</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7537">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426294.019000 424918.014000</gml:lowerCorner>
        		<gml:upperCorner>426294.019000 424918.014000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7537.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426294.019000 424918.014000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7537</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 125 232</ms:GML_ID>
        <ms:NAZWA>014 125 232</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014125232</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7536">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426701.996772 426233.187680</gml:lowerCorner>
        		<gml:upperCorner>426701.996772 426233.187680</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7536.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426701.996772 426233.187680</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7536</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 123 855</ms:GML_ID>
        <ms:NAZWA>014 123 855</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014123855</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426728.810485 426938.007748</gml:lowerCorner>
        		<gml:upperCorner>426728.810485 426938.007748</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426728.810485 426938.007748</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 123 137</ms:GML_ID>
        <ms:NAZWA>014 123 137</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014123137</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426408.508321 427961.110534</gml:lowerCorner>
        		<gml:upperCorner>426408.508321 427961.110534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426408.508321 427961.110534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 122 062</ms:GML_ID>
        <ms:NAZWA>014 122 062</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014122062</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7533">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426334.089000 428930.951000</gml:lowerCorner>
        		<gml:upperCorner>426334.089000 428930.951000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7533.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426334.089000 428930.951000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7533</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 121 079</ms:GML_ID>
        <ms:NAZWA>014 121 079</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014121079</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7532">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>426413.510789 430033.209079</gml:lowerCorner>
        		<gml:upperCorner>426413.510789 430033.209079</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7532.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>426413.510789 430033.209079</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7532</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 119 974</ms:GML_ID>
        <ms:NAZWA>014 119 974</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014119974</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7531">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428928.991000 432361.341000</gml:lowerCorner>
        		<gml:upperCorner>428928.991000 432361.341000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7531.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428928.991000 432361.341000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7531</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 116 317</ms:GML_ID>
        <ms:NAZWA>014 116 317</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014116317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7530">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429357.259000 432900.812000</gml:lowerCorner>
        		<gml:upperCorner>429357.259000 432900.812000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7530.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429357.259000 432900.812000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7530</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 115 621</ms:GML_ID>
        <ms:NAZWA>014 115 621</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014115621</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7529">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429924.582000 433727.053000</gml:lowerCorner>
        		<gml:upperCorner>429924.582000 433727.053000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7529.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429924.582000 433727.053000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7529</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 114 618</ms:GML_ID>
        <ms:NAZWA>014 114 618</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014114618</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7528">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431197.859388 436059.500401</gml:lowerCorner>
        		<gml:upperCorner>431197.859388 436059.500401</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7528.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431197.859388 436059.500401</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7528</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 111 954</ms:GML_ID>
        <ms:NAZWA>014 111 954</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014111954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7526">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429286.378000 437002.170000</gml:lowerCorner>
        		<gml:upperCorner>429286.378000 437002.170000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7526.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429286.378000 437002.170000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7526</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 109 182</ms:GML_ID>
        <ms:NAZWA>014 109 182</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014109182</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7527">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430713.576000 437040.553000</gml:lowerCorner>
        		<gml:upperCorner>430713.576000 437040.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7527.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430713.576000 437040.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7527</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 110 697</ms:GML_ID>
        <ms:NAZWA>014 110 697</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014110697</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7525">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429365.631459 438053.299438</gml:lowerCorner>
        		<gml:upperCorner>429365.631459 438053.299438</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7525.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429365.631459 438053.299438</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7525</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 107 903</ms:GML_ID>
        <ms:NAZWA>014 107 903</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014107903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7524">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429703.280000 438125.592000</gml:lowerCorner>
        		<gml:upperCorner>429703.280000 438125.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7524.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429703.280000 438125.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7524</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 107 560</ms:GML_ID>
        <ms:NAZWA>014 107 560</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014107560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7523">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430024.351860 440239.506778</gml:lowerCorner>
        		<gml:upperCorner>430024.351860 440239.506778</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7523.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430024.351860 440239.506778</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7523</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 105 297</ms:GML_ID>
        <ms:NAZWA>014 105 297</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014105297</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7522">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429914.462000 441814.122000</gml:lowerCorner>
        		<gml:upperCorner>429914.462000 441814.122000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7522.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429914.462000 441814.122000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7522</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 103 712</ms:GML_ID>
        <ms:NAZWA>014 103 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014103712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7521">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429858.540725 442822.261544</gml:lowerCorner>
        		<gml:upperCorner>429858.540725 442822.261544</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7521.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429858.540725 442822.261544</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7521</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 102 698</ms:GML_ID>
        <ms:NAZWA>014 102 698</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014102698</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7520">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431242.718000 445086.932000</gml:lowerCorner>
        		<gml:upperCorner>431242.718000 445086.932000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7520.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431242.718000 445086.932000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7520</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 099 904</ms:GML_ID>
        <ms:NAZWA>014 099 904</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014099904</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7519">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431175.731437 445971.506248</gml:lowerCorner>
        		<gml:upperCorner>431175.731437 445971.506248</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7519.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431175.731437 445971.506248</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7519</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 099 015</ms:GML_ID>
        <ms:NAZWA>014 099 015</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014099015</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7518">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431015.065962 446969.477731</gml:lowerCorner>
        		<gml:upperCorner>431015.065962 446969.477731</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7518.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431015.065962 446969.477731</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7518</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 098 005</ms:GML_ID>
        <ms:NAZWA>014 098 005</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014098005</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7517">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430848.839333 448035.606302</gml:lowerCorner>
        		<gml:upperCorner>430848.839333 448035.606302</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7517.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430848.839333 448035.606302</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7517</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 096 917</ms:GML_ID>
        <ms:NAZWA>014 096 917</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014096917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7516">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430745.902223 448694.388224</gml:lowerCorner>
        		<gml:upperCorner>430745.902223 448694.388224</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7516.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430745.902223 448694.388224</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7516</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 096 251</ms:GML_ID>
        <ms:NAZWA>014 096 251</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014096251</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7515">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429975.440858 451404.214894</gml:lowerCorner>
        		<gml:upperCorner>429975.440858 451404.214894</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7515.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429975.440858 451404.214894</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7515</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 093 404</ms:GML_ID>
        <ms:NAZWA>014 093 404</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014093404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7514">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429579.703000 452653.662000</gml:lowerCorner>
        		<gml:upperCorner>429579.703000 452653.662000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7514.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429579.703000 452653.662000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7514</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 092 089</ms:GML_ID>
        <ms:NAZWA>014 092 089</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014092089</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7513">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429325.776000 453489.809000</gml:lowerCorner>
        		<gml:upperCorner>429325.776000 453489.809000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7513.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429325.776000 453489.809000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7513</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.014 091 125</ms:GML_ID>
        <ms:NAZWA>014 091 125</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>014091125</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4395">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307320.230632 415037.795787</gml:lowerCorner>
        		<gml:upperCorner>307320.230632 415037.795787</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4395.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307320.230632 415037.795787</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4395</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 008 329</ms:GML_ID>
        <ms:NAZWA>287 008 329</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287008329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4394">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307401.711084 415289.255372</gml:lowerCorner>
        		<gml:upperCorner>307401.711084 415289.255372</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4394.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307401.711084 415289.255372</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4394</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 008 057</ms:GML_ID>
        <ms:NAZWA>287 008 057</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287008057</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4393">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307657.318746 416133.149067</gml:lowerCorner>
        		<gml:upperCorner>307657.318746 416133.149067</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4393.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307657.318746 416133.149067</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4393</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 007 171</ms:GML_ID>
        <ms:NAZWA>287 007 171</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287007171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4392">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307864.936017 416756.053657</gml:lowerCorner>
        		<gml:upperCorner>307864.936017 416756.053657</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4392.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307864.936017 416756.053657</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4392</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 006 517</ms:GML_ID>
        <ms:NAZWA>287 006 517</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287006517</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4391">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307961.332000 417091.124000</gml:lowerCorner>
        		<gml:upperCorner>307961.332000 417091.124000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4391.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307961.332000 417091.124000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4391</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 006 171</ms:GML_ID>
        <ms:NAZWA>287 006 171</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287006171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4390">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307949.635000 417295.045000</gml:lowerCorner>
        		<gml:upperCorner>307949.635000 417295.045000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4390.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307949.635000 417295.045000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4390</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 005 967</ms:GML_ID>
        <ms:NAZWA>287 005 967</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287005967</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4389">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307920.705000 417716.723000</gml:lowerCorner>
        		<gml:upperCorner>307920.705000 417716.723000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4389.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307920.705000 417716.723000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4389</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 005 543</ms:GML_ID>
        <ms:NAZWA>287 005 543</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287005543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4388">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308427.662000 418741.302000</gml:lowerCorner>
        		<gml:upperCorner>308427.662000 418741.302000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4388.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308427.662000 418741.302000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4388</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 004 391</ms:GML_ID>
        <ms:NAZWA>287 004 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287004391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4387">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>308623.445000 419024.836000</gml:lowerCorner>
        		<gml:upperCorner>308623.445000 419024.836000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4387.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>308623.445000 419024.836000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4387</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 004 046</ms:GML_ID>
        <ms:NAZWA>287 004 046</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287004046</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4386">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309287.814000 419943.433000</gml:lowerCorner>
        		<gml:upperCorner>309287.814000 419943.433000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4386.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309287.814000 419943.433000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4386</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 002 910</ms:GML_ID>
        <ms:NAZWA>287 002 910</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287002910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4385">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309621.405000 420249.842000</gml:lowerCorner>
        		<gml:upperCorner>309621.405000 420249.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4385.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309621.405000 420249.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4385</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 002 458</ms:GML_ID>
        <ms:NAZWA>287 002 458</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287002458</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4384">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310006.318000 420602.808000</gml:lowerCorner>
        		<gml:upperCorner>310006.318000 420602.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4384.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310006.318000 420602.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4384</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 001 935</ms:GML_ID>
        <ms:NAZWA>287 001 935</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287001935</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4383">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310506.881000 421062.915000</gml:lowerCorner>
        		<gml:upperCorner>310506.881000 421062.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4383.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310506.881000 421062.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4383</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.287 001 255</ms:GML_ID>
        <ms:NAZWA>287 001 255</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>287001255</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5675">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310351.847000 424773.688000</gml:lowerCorner>
        		<gml:upperCorner>310351.847000 424773.688000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5675.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310351.847000 424773.688000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5675</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 098 356</ms:GML_ID>
        <ms:NAZWA>132 098 356</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132098356</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5674">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309422.498000 425302.748000</gml:lowerCorner>
        		<gml:upperCorner>309422.498000 425302.748000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5674.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309422.498000 425302.748000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5674</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 097 285</ms:GML_ID>
        <ms:NAZWA>132 097 285</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132097285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.161">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>309952.487000 425766.870000</gml:lowerCorner>
        		<gml:upperCorner>309952.487000 425766.870000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.161.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>309952.487000 425766.870000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>161</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.280 001 975</ms:GML_ID>
        <ms:NAZWA>280 001 975</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>280001975</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5673">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>307286.999000 427131.862000</gml:lowerCorner>
        		<gml:upperCorner>307286.999000 427131.862000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5673.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>307286.999000 427131.862000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5673</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 094 436</ms:GML_ID>
        <ms:NAZWA>132 094 436</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132094436</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306435.557000 427158.553000</gml:lowerCorner>
        		<gml:upperCorner>306435.557000 427158.553000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306435.557000 427158.553000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 036 096</ms:GML_ID>
        <ms:NAZWA>136 036 096</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136036096</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305802.945000 427376.656000</gml:lowerCorner>
        		<gml:upperCorner>305802.945000 427376.656000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305802.945000 427376.656000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 035 423</ms:GML_ID>
        <ms:NAZWA>136 035 423</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136035423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5672">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>306765.070255 427768.073654</gml:lowerCorner>
        		<gml:upperCorner>306765.070255 427768.073654</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5672.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>306765.070255 427768.073654</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5672</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 093 611</ms:GML_ID>
        <ms:NAZWA>132 093 611</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132093611</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303984.644000 428003.810000</gml:lowerCorner>
        		<gml:upperCorner>303984.644000 428003.810000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303984.644000 428003.810000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.136 033 499</ms:GML_ID>
        <ms:NAZWA>136 033 499</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>136033499</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5101">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310538.075000 428262.141000</gml:lowerCorner>
        		<gml:upperCorner>310538.075000 428262.141000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5101.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310538.075000 428262.141000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5101</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 071 735</ms:GML_ID>
        <ms:NAZWA>144 071 735</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144071735</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5671">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305959.938000 428735.695000</gml:lowerCorner>
        		<gml:upperCorner>305959.938000 428735.695000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5671.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305959.938000 428735.695000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5671</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 092 350</ms:GML_ID>
        <ms:NAZWA>132 092 350</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132092350</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5670">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>305467.343714 429327.261410</gml:lowerCorner>
        		<gml:upperCorner>305467.343714 429327.261410</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5670.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>305467.343714 429327.261410</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5670</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 091 579</ms:GML_ID>
        <ms:NAZWA>132 091 579</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132091579</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5669">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>303973.127000 431119.915000</gml:lowerCorner>
        		<gml:upperCorner>303973.127000 431119.915000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5669.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>303973.127000 431119.915000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5669</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 089 257</ms:GML_ID>
        <ms:NAZWA>132 089 257</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132089257</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5100">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310476.935000 431819.178000</gml:lowerCorner>
        		<gml:upperCorner>310476.935000 431819.178000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5100.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310476.935000 431819.178000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5100</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 068 174</ms:GML_ID>
        <ms:NAZWA>144 068 174</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144068174</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5668">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>302793.532000 432531.994000</gml:lowerCorner>
        		<gml:upperCorner>302793.532000 432531.994000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5668.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>302793.532000 432531.994000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5668</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.132 087 403</ms:GML_ID>
        <ms:NAZWA>132 087 403</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>132087403</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5099">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310437.994000 433110.541000</gml:lowerCorner>
        		<gml:upperCorner>310437.994000 433110.541000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5099.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310437.994000 433110.541000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5099</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 066 881</ms:GML_ID>
        <ms:NAZWA>144 066 881</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144066881</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5098">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>310431.329000 433386.517000</gml:lowerCorner>
        		<gml:upperCorner>310431.329000 433386.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5098.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>310431.329000 433386.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5098</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.144 066 606</ms:GML_ID>
        <ms:NAZWA>144 066 606</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>144066606</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4609">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348626.495136 414021.482486</gml:lowerCorner>
        		<gml:upperCorner>348626.495136 414021.482486</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4609.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348626.495136 414021.482486</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4609</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 050 339</ms:GML_ID>
        <ms:NAZWA>301 050 339</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301050339</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4608">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347749.137000 414378.673000</gml:lowerCorner>
        		<gml:upperCorner>347749.137000 414378.673000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4608.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347749.137000 414378.673000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4608</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 049 391</ms:GML_ID>
        <ms:NAZWA>301 049 391</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301049391</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4607">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347039.366000 414667.683000</gml:lowerCorner>
        		<gml:upperCorner>347039.366000 414667.683000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4607.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347039.366000 414667.683000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4607</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 048 624</ms:GML_ID>
        <ms:NAZWA>301 048 624</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301048624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4606">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345878.889000 415057.901000</gml:lowerCorner>
        		<gml:upperCorner>345878.889000 415057.901000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4606.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345878.889000 415057.901000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4606</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 047 398</ms:GML_ID>
        <ms:NAZWA>301 047 398</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301047398</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4605">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345301.974000 415299.687000</gml:lowerCorner>
        		<gml:upperCorner>345301.974000 415299.687000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4605.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345301.974000 415299.687000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4605</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 046 773</ms:GML_ID>
        <ms:NAZWA>301 046 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301046773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4604">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>345062.976000 415411.639000</gml:lowerCorner>
        		<gml:upperCorner>345062.976000 415411.639000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4604.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>345062.976000 415411.639000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4604</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 046 508</ms:GML_ID>
        <ms:NAZWA>301 046 508</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301046508</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4603">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>344808.813000 415530.765000</gml:lowerCorner>
        		<gml:upperCorner>344808.813000 415530.765000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4603.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>344808.813000 415530.765000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4603</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 046 227</ms:GML_ID>
        <ms:NAZWA>301 046 227</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301046227</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4602">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>343569.561000 416109.851000</gml:lowerCorner>
        		<gml:upperCorner>343569.561000 416109.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4602.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>343569.561000 416109.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4602</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 044 854</ms:GML_ID>
        <ms:NAZWA>301 044 854</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301044854</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4601">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340393.573000 417596.970000</gml:lowerCorner>
        		<gml:upperCorner>340393.573000 417596.970000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4601.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340393.573000 417596.970000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4601</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 041 351</ms:GML_ID>
        <ms:NAZWA>301 041 351</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301041351</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4600">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>339294.971620 418110.353166</gml:lowerCorner>
        		<gml:upperCorner>339294.971620 418110.353166</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4600.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>339294.971620 418110.353166</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4600</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 040 136</ms:GML_ID>
        <ms:NAZWA>301 040 136</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301040136</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4599">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338587.781000 418714.426000</gml:lowerCorner>
        		<gml:upperCorner>338587.781000 418714.426000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4599.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338587.781000 418714.426000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4599</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 039 172</ms:GML_ID>
        <ms:NAZWA>301 039 172</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301039172</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4598">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338396.245000 419027.085000</gml:lowerCorner>
        		<gml:upperCorner>338396.245000 419027.085000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4598.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338396.245000 419027.085000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4598</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 038 805</ms:GML_ID>
        <ms:NAZWA>301 038 805</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301038805</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4597">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>338023.748000 419377.193000</gml:lowerCorner>
        		<gml:upperCorner>338023.748000 419377.193000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4597.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>338023.748000 419377.193000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4597</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 038 291</ms:GML_ID>
        <ms:NAZWA>301 038 291</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301038291</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4596">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337829.645000 419561.722000</gml:lowerCorner>
        		<gml:upperCorner>337829.645000 419561.722000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4596.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337829.645000 419561.722000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4596</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 038 022</ms:GML_ID>
        <ms:NAZWA>301 038 022</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301038022</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4595">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337460.588785 420024.521439</gml:lowerCorner>
        		<gml:upperCorner>337460.588785 420024.521439</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4595.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337460.588785 420024.521439</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4595</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 037 430</ms:GML_ID>
        <ms:NAZWA>301 037 430</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301037430</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4594">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>337100.560000 420482.983000</gml:lowerCorner>
        		<gml:upperCorner>337100.560000 420482.983000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4594.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>337100.560000 420482.983000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4594</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 036 847</ms:GML_ID>
        <ms:NAZWA>301 036 847</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301036847</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4992">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350327.211000 431644.883000</gml:lowerCorner>
        		<gml:upperCorner>350327.211000 431644.883000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4992.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350327.211000 431644.883000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4992</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 083 649</ms:GML_ID>
        <ms:NAZWA>143 083 649</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143083649</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4991">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350195.063963 432432.650251</gml:lowerCorner>
        		<gml:upperCorner>350195.063963 432432.650251</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4991.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350195.063963 432432.650251</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4991</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 082 848</ms:GML_ID>
        <ms:NAZWA>143 082 848</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143082848</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4990">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350017.280000 433435.969000</gml:lowerCorner>
        		<gml:upperCorner>350017.280000 433435.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4990.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350017.280000 433435.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4990</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 081 828</ms:GML_ID>
        <ms:NAZWA>143 081 828</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143081828</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4989">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>349929.919000 433946.620000</gml:lowerCorner>
        		<gml:upperCorner>349929.919000 433946.620000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4989.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>349929.919000 433946.620000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4989</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 081 307</ms:GML_ID>
        <ms:NAZWA>143 081 307</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143081307</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4988">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>348860.717000 437348.997000</gml:lowerCorner>
        		<gml:upperCorner>348860.717000 437348.997000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4988.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>348860.717000 437348.997000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4988</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 077 712</ms:GML_ID>
        <ms:NAZWA>143 077 712</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143077712</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4987">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>347547.560000 440116.693000</gml:lowerCorner>
        		<gml:upperCorner>347547.560000 440116.693000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4987.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>347547.560000 440116.693000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4987</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 074 650</ms:GML_ID>
        <ms:NAZWA>143 074 650</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143074650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4534">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>340966.890000 440811.145000</gml:lowerCorner>
        		<gml:upperCorner>340966.890000 440811.145000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4534.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>340966.890000 440811.145000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4534</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 018 571</ms:GML_ID>
        <ms:NAZWA>293 018 571</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293018571</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4535">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>341463.261000 442000.593000</gml:lowerCorner>
        		<gml:upperCorner>341463.261000 442000.593000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4535.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>341463.261000 442000.593000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4535</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.293 019 861</ms:GML_ID>
        <ms:NAZWA>293 019 861</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>293019861</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5003">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356927.565000 410648.497000</gml:lowerCorner>
        		<gml:upperCorner>356927.565000 410648.497000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5003.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356927.565000 410648.497000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5003</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 105 858</ms:GML_ID>
        <ms:NAZWA>143 105 858</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143105858</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356781.677000 410666.914000</gml:lowerCorner>
        		<gml:upperCorner>356781.677000 410666.914000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356781.677000 410666.914000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 059 231</ms:GML_ID>
        <ms:NAZWA>301 059 231</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301059231</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5002">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356786.957000 411319.517000</gml:lowerCorner>
        		<gml:upperCorner>356786.957000 411319.517000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5002.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356786.957000 411319.517000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5002</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 105 169</ms:GML_ID>
        <ms:NAZWA>143 105 169</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143105169</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355724.224000 411411.120000</gml:lowerCorner>
        		<gml:upperCorner>355724.224000 411411.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355724.224000 411411.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 057 931</ms:GML_ID>
        <ms:NAZWA>301 057 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301057931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>354517.540000 412021.065000</gml:lowerCorner>
        		<gml:upperCorner>354517.540000 412021.065000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>354517.540000 412021.065000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 056 580</ms:GML_ID>
        <ms:NAZWA>301 056 580</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301056580</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353757.999000 412401.001000</gml:lowerCorner>
        		<gml:upperCorner>353757.999000 412401.001000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353757.999000 412401.001000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 055 731</ms:GML_ID>
        <ms:NAZWA>301 055 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301055731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353353.958000 412516.919000</gml:lowerCorner>
        		<gml:upperCorner>353353.958000 412516.919000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353353.958000 412516.919000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 055 309</ms:GML_ID>
        <ms:NAZWA>301 055 309</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301055309</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352950.965121 412625.096577</gml:lowerCorner>
        		<gml:upperCorner>352950.965121 412625.096577</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352950.965121 412625.096577</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 054 891</ms:GML_ID>
        <ms:NAZWA>301 054 891</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301054891</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5001">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356593.289168 412731.751363</gml:lowerCorner>
        		<gml:upperCorner>356593.289168 412731.751363</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5001.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356593.289168 412731.751363</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5001</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 103 743</ms:GML_ID>
        <ms:NAZWA>143 103 743</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143103743</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351615.809336 412983.911655</gml:lowerCorner>
        		<gml:upperCorner>351615.809336 412983.911655</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351615.809336 412983.911655</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.301 053 509</ms:GML_ID>
        <ms:NAZWA>301 053 509</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>301053509</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5000">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>356052.103000 416091.551000</gml:lowerCorner>
        		<gml:upperCorner>356052.103000 416091.551000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5000.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>356052.103000 416091.551000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5000</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 100 336</ms:GML_ID>
        <ms:NAZWA>143 100 336</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143100336</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4999">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>355836.747332 416942.573159</gml:lowerCorner>
        		<gml:upperCorner>355836.747332 416942.573159</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4999.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>355836.747332 416942.573159</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4999</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 099 457</ms:GML_ID>
        <ms:NAZWA>143 099 457</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143099457</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4998">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353999.005110 422034.527498</gml:lowerCorner>
        		<gml:upperCorner>353999.005110 422034.527498</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4998.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353999.005110 422034.527498</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4998</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 094 012</ms:GML_ID>
        <ms:NAZWA>143 094 012</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143094012</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4997">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>353140.159000 423814.216000</gml:lowerCorner>
        		<gml:upperCorner>353140.159000 423814.216000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4997.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>353140.159000 423814.216000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4997</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 092 034</ms:GML_ID>
        <ms:NAZWA>143 092 034</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143092034</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4996">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>352421.794212 425312.021568</gml:lowerCorner>
        		<gml:upperCorner>352421.794212 425312.021568</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4996.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>352421.794212 425312.021568</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4996</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 090 372</ms:GML_ID>
        <ms:NAZWA>143 090 372</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143090372</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4995">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351884.501000 426427.311000</gml:lowerCorner>
        		<gml:upperCorner>351884.501000 426427.311000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4995.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351884.501000 426427.311000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4995</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 089 132</ms:GML_ID>
        <ms:NAZWA>143 089 132</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143089132</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4994">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>351066.409641 428293.950488</gml:lowerCorner>
        		<gml:upperCorner>351066.409641 428293.950488</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4994.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>351066.409641 428293.950488</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4994</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 087 088</ms:GML_ID>
        <ms:NAZWA>143 087 088</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143087088</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.4993">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>350971.294105 428589.374496</gml:lowerCorner>
        		<gml:upperCorner>350971.294105 428589.374496</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.4993.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>350971.294105 428589.374496</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>4993</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.143 086 779</ms:GML_ID>
        <ms:NAZWA>143 086 779</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>143086779</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.715">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>372402.697000 436895.729000</gml:lowerCorner>
        		<gml:upperCorner>372402.697000 436895.729000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.715.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>372402.697000 436895.729000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>715</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 029 917</ms:GML_ID>
        <ms:NAZWA>272 029 917</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272029917</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.714">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>371538.518000 437453.580000</gml:lowerCorner>
        		<gml:upperCorner>371538.518000 437453.580000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.714.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>371538.518000 437453.580000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>714</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 028 882</ms:GML_ID>
        <ms:NAZWA>272 028 882</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272028882</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.713">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>370647.490000 437963.374000</gml:lowerCorner>
        		<gml:upperCorner>370647.490000 437963.374000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.713.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>370647.490000 437963.374000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>713</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 027 856</ms:GML_ID>
        <ms:NAZWA>272 027 856</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272027856</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.712">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>369992.975000 438337.419000</gml:lowerCorner>
        		<gml:upperCorner>369992.975000 438337.419000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.712.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>369992.975000 438337.419000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>712</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 027 102</ms:GML_ID>
        <ms:NAZWA>272 027 102</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272027102</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.709">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>365946.628000 441557.947000</gml:lowerCorner>
        		<gml:upperCorner>365946.628000 441557.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.709.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>365946.628000 441557.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>709</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 021 827</ms:GML_ID>
        <ms:NAZWA>272 021 827</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>272021827</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3066">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>408442.394000 406229.421000</gml:lowerCorner>
        		<gml:upperCorner>408442.394000 406229.421000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3066.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>408442.394000 406229.421000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3066</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 017 946</ms:GML_ID>
        <ms:NAZWA>355 017 946</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355017946</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.774">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450901.652000 406240.330000</gml:lowerCorner>
        		<gml:upperCorner>450901.652000 406240.330000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.774.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450901.652000 406240.330000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>774</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 121 264</ms:GML_ID>
        <ms:NAZWA>272 121 264</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272121264</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3064">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>410238.144000 406509.762000</gml:lowerCorner>
        		<gml:upperCorner>410238.144000 406509.762000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3064.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>410238.144000 406509.762000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3064</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 016 129</ms:GML_ID>
        <ms:NAZWA>355 016 129</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355016129</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.773">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450608.330194 407389.403649</gml:lowerCorner>
        		<gml:upperCorner>450608.330194 407389.403649</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.773.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450608.330194 407389.403649</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>773</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 120 076</ms:GML_ID>
        <ms:NAZWA>272 120 076</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272120076</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3061">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>412992.614182 407836.315161</gml:lowerCorner>
        		<gml:upperCorner>412992.614182 407836.315161</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3061.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>412992.614182 407836.315161</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3061</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 012 945</ms:GML_ID>
        <ms:NAZWA>355 012 945</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355012945</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.772">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450448.762000 408009.848000</gml:lowerCorner>
        		<gml:upperCorner>450448.762000 408009.848000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.772.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450448.762000 408009.848000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>772</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 119 433</ms:GML_ID>
        <ms:NAZWA>272 119 433</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272119433</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3059">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>413807.595000 409273.155000</gml:lowerCorner>
        		<gml:upperCorner>413807.595000 409273.155000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3059.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>413807.595000 409273.155000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3059</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 011 286</ms:GML_ID>
        <ms:NAZWA>355 011 286</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355011286</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.771">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449654.336000 409482.224000</gml:lowerCorner>
        		<gml:upperCorner>449654.336000 409482.224000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.771.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449654.336000 409482.224000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>771</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 117 760</ms:GML_ID>
        <ms:NAZWA>272 117 760</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272117760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.770">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449383.428000 410166.936000</gml:lowerCorner>
        		<gml:upperCorner>449383.428000 410166.936000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.770.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449383.428000 410166.936000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>770</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 117 023</ms:GML_ID>
        <ms:NAZWA>272 117 023</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272117023</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.769">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>449239.554000 410557.296000</gml:lowerCorner>
        		<gml:upperCorner>449239.554000 410557.296000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.769.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>449239.554000 410557.296000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>769</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 116 607</ms:GML_ID>
        <ms:NAZWA>272 116 607</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272116607</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.768">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>448791.742000 411692.830000</gml:lowerCorner>
        		<gml:upperCorner>448791.742000 411692.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.768.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>448791.742000 411692.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>768</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 115 386</ms:GML_ID>
        <ms:NAZWA>272 115 386</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272115386</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3056">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>415842.401000 412834.721000</gml:lowerCorner>
        		<gml:upperCorner>415842.401000 412834.721000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3056.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>415842.401000 412834.721000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3056</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 007 171</ms:GML_ID>
        <ms:NAZWA>355 007 171</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355007171</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.767">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>447921.278000 413127.543000</gml:lowerCorner>
        		<gml:upperCorner>447921.278000 413127.543000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.767.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>447921.278000 413127.543000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>767</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 113 705</ms:GML_ID>
        <ms:NAZWA>272 113 705</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272113705</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.766">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446541.780000 413618.175000</gml:lowerCorner>
        		<gml:upperCorner>446541.780000 413618.175000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.766.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446541.780000 413618.175000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>766</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 112 194</ms:GML_ID>
        <ms:NAZWA>272 112 194</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272112194</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.765">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>446085.299000 413696.372000</gml:lowerCorner>
        		<gml:upperCorner>446085.299000 413696.372000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.765.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>446085.299000 413696.372000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>765</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 111 731</ms:GML_ID>
        <ms:NAZWA>272 111 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272111731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.764">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>444165.141000 414025.635000</gml:lowerCorner>
        		<gml:upperCorner>444165.141000 414025.635000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.764.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>444165.141000 414025.635000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>764</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 109 782</ms:GML_ID>
        <ms:NAZWA>272 109 782</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272109782</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.763">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>443707.089000 414104.245000</gml:lowerCorner>
        		<gml:upperCorner>443707.089000 414104.245000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.763.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>443707.089000 414104.245000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>763</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 109 317</ms:GML_ID>
        <ms:NAZWA>272 109 317</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272109317</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.762">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>442213.502000 414359.905000</gml:lowerCorner>
        		<gml:upperCorner>442213.502000 414359.905000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.762.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>442213.502000 414359.905000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>762</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 107 801</ms:GML_ID>
        <ms:NAZWA>272 107 801</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272107801</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.761">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>440620.937000 414633.236000</gml:lowerCorner>
        		<gml:upperCorner>440620.937000 414633.236000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.761.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>440620.937000 414633.236000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>761</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 106 185</ms:GML_ID>
        <ms:NAZWA>272 106 185</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272106185</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.760">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>439471.939000 414830.955000</gml:lowerCorner>
        		<gml:upperCorner>439471.939000 414830.955000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.760.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>439471.939000 414830.955000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>760</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 105 018</ms:GML_ID>
        <ms:NAZWA>272 105 018</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272105018</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.759">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>437299.283000 415459.028000</gml:lowerCorner>
        		<gml:upperCorner>437299.283000 415459.028000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.759.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>437299.283000 415459.028000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>759</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 102 752</ms:GML_ID>
        <ms:NAZWA>272 102 752</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272102752</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.758">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>436567.244774 415692.141245</gml:lowerCorner>
        		<gml:upperCorner>436567.244774 415692.141245</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.758.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>436567.244774 415692.141245</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>758</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 101 980</ms:GML_ID>
        <ms:NAZWA>272 101 980</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272101980</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.757">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>435771.532000 415946.260000</gml:lowerCorner>
        		<gml:upperCorner>435771.532000 415946.260000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.757.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>435771.532000 415946.260000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>757</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 101 147</ms:GML_ID>
        <ms:NAZWA>272 101 147</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272101147</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.756">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>434978.163000 416199.377000</gml:lowerCorner>
        		<gml:upperCorner>434978.163000 416199.377000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.756.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>434978.163000 416199.377000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>756</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 100 315</ms:GML_ID>
        <ms:NAZWA>272 100 315</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272100315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.755">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>433954.168000 416360.612000</gml:lowerCorner>
        		<gml:upperCorner>433954.168000 416360.612000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.755.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>433954.168000 416360.612000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>755</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 099 272</ms:GML_ID>
        <ms:NAZWA>272 099 272</ms:NAZWA>
        <ms:KATEGORIA>F</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272099272</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.754">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>432612.259000 416489.537000</gml:lowerCorner>
        		<gml:upperCorner>432612.259000 416489.537000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.754.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>432612.259000 416489.537000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>754</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 097 926</ms:GML_ID>
        <ms:NAZWA>272 097 926</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272097926</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.753">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>431569.893000 416589.355000</gml:lowerCorner>
        		<gml:upperCorner>431569.893000 416589.355000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.753.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>431569.893000 416589.355000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>753</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 096 878</ms:GML_ID>
        <ms:NAZWA>272 096 878</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272096878</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.752">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>430014.314000 416738.599000</gml:lowerCorner>
        		<gml:upperCorner>430014.314000 416738.599000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.752.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>430014.314000 416738.599000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>752</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 095 315</ms:GML_ID>
        <ms:NAZWA>272 095 315</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272095315</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.751">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>429158.341000 416819.531000</gml:lowerCorner>
        		<gml:upperCorner>429158.341000 416819.531000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.751.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>429158.341000 416819.531000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>751</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 094 453</ms:GML_ID>
        <ms:NAZWA>272 094 453</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272094453</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.750">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428801.389000 416855.272000</gml:lowerCorner>
        		<gml:upperCorner>428801.389000 416855.272000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.750.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428801.389000 416855.272000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>750</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 094 095</ms:GML_ID>
        <ms:NAZWA>272 094 095</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272094095</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.749">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>428369.002000 416924.548000</gml:lowerCorner>
        		<gml:upperCorner>428369.002000 416924.548000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.749.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>428369.002000 416924.548000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>749</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 093 657</ms:GML_ID>
        <ms:NAZWA>272 093 657</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272093657</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.748">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>427510.621000 417049.808000</gml:lowerCorner>
        		<gml:upperCorner>427510.621000 417049.808000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.748.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>427510.621000 417049.808000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>748</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 092 788</ms:GML_ID>
        <ms:NAZWA>272 092 788</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272092788</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3072">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>393592.011665 405745.611933</gml:lowerCorner>
        		<gml:upperCorner>393592.011665 405745.611933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3072.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>393592.011665 405745.611933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3072</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 034 306</ms:GML_ID>
        <ms:NAZWA>355 034 306</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>355034306</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3069">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403386.206000 405748.781000</gml:lowerCorner>
        		<gml:upperCorner>403386.206000 405748.781000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3069.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403386.206000 405748.781000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3069</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 023 028</ms:GML_ID>
        <ms:NAZWA>355 023 028</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355023028</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.3068">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>406035.900000 406028.501000</gml:lowerCorner>
        		<gml:upperCorner>406035.900000 406028.501000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.3068.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>406035.900000 406028.501000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>3068</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.355 020 362</ms:GML_ID>
        <ms:NAZWA>355 020 362</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>355020362</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6633">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379165.938000 406145.776000</gml:lowerCorner>
        		<gml:upperCorner>379165.938000 406145.776000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6633.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379165.938000 406145.776000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6633</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 127 880</ms:GML_ID>
        <ms:NAZWA>181 127 880</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181127880</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6632">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379767.773000 407026.646000</gml:lowerCorner>
        		<gml:upperCorner>379767.773000 407026.646000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6632.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379767.773000 407026.646000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6632</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 126 811</ms:GML_ID>
        <ms:NAZWA>181 126 811</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181126811</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6631">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379891.201804 407182.858309</gml:lowerCorner>
        		<gml:upperCorner>379891.201804 407182.858309</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6631.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379891.201804 407182.858309</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6631</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 126 612</ms:GML_ID>
        <ms:NAZWA>181 126 612</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181126612</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6630">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380536.120000 408009.794000</gml:lowerCorner>
        		<gml:upperCorner>380536.120000 408009.794000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6630.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380536.120000 408009.794000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6630</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 125 560</ms:GML_ID>
        <ms:NAZWA>181 125 560</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181125560</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6629">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380680.330000 408194.277000</gml:lowerCorner>
        		<gml:upperCorner>380680.330000 408194.277000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6629.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380680.330000 408194.277000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6629</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 125 329</ms:GML_ID>
        <ms:NAZWA>181 125 329</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181125329</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6628">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380911.974000 408491.093000</gml:lowerCorner>
        		<gml:upperCorner>380911.974000 408491.093000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6628.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380911.974000 408491.093000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6628</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 124 952</ms:GML_ID>
        <ms:NAZWA>181 124 952</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181124952</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6627">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381179.651000 409197.856000</gml:lowerCorner>
        		<gml:upperCorner>381179.651000 409197.856000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6627.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381179.651000 409197.856000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6627</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 124 180</ms:GML_ID>
        <ms:NAZWA>181 124 180</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181124180</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6626">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>381095.622704 410382.692592</gml:lowerCorner>
        		<gml:upperCorner>381095.622704 410382.692592</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6626.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>381095.622704 410382.692592</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6626</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 122 991</ms:GML_ID>
        <ms:NAZWA>181 122 991</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181122991</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6625">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380732.204528 411677.368934</gml:lowerCorner>
        		<gml:upperCorner>380732.204528 411677.368934</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6625.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380732.204528 411677.368934</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6625</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 121 645</ms:GML_ID>
        <ms:NAZWA>181 121 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181121645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6624">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380462.543306 412580.898631</gml:lowerCorner>
        		<gml:upperCorner>380462.543306 412580.898631</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6624.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380462.543306 412580.898631</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6624</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 120 696</ms:GML_ID>
        <ms:NAZWA>181 120 696</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WROCŁAW</ms:IDDE>
        <ms:SEARCH>181120696</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6623">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380257.468355 413266.680708</gml:lowerCorner>
        		<gml:upperCorner>380257.468355 413266.680708</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6623.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380257.468355 413266.680708</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6623</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 119 983</ms:GML_ID>
        <ms:NAZWA>181 119 983</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181119983</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6622">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380163.020000 413584.195000</gml:lowerCorner>
        		<gml:upperCorner>380163.020000 413584.195000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6622.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380163.020000 413584.195000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6622</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 119 643</ms:GML_ID>
        <ms:NAZWA>181 119 643</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181119643</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6621">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>379968.768000 414234.067000</gml:lowerCorner>
        		<gml:upperCorner>379968.768000 414234.067000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6621.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>379968.768000 414234.067000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6621</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 118 972</ms:GML_ID>
        <ms:NAZWA>181 118 972</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181118972</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6620">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380097.859000 416645.668000</gml:lowerCorner>
        		<gml:upperCorner>380097.859000 416645.668000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6620.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380097.859000 416645.668000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6620</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 116 542</ms:GML_ID>
        <ms:NAZWA>181 116 542</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181116542</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6619">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380132.958000 416958.273000</gml:lowerCorner>
        		<gml:upperCorner>380132.958000 416958.273000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6619.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380132.958000 416958.273000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6619</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 116 228</ms:GML_ID>
        <ms:NAZWA>181 116 228</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181116228</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6618">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380256.131779 418067.506350</gml:lowerCorner>
        		<gml:upperCorner>380256.131779 418067.506350</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6618.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380256.131779 418067.506350</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6618</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 115 112</ms:GML_ID>
        <ms:NAZWA>181 115 112</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181115112</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6617">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380323.009000 418661.197000</gml:lowerCorner>
        		<gml:upperCorner>380323.009000 418661.197000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6617.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380323.009000 418661.197000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6617</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 114 514</ms:GML_ID>
        <ms:NAZWA>181 114 514</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181114514</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6616">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380385.635549 419584.428153</gml:lowerCorner>
        		<gml:upperCorner>380385.635549 419584.428153</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6616.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380385.635549 419584.428153</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6616</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 113 586</ms:GML_ID>
        <ms:NAZWA>181 113 586</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181113586</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6615">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380408.963000 420396.223000</gml:lowerCorner>
        		<gml:upperCorner>380408.963000 420396.223000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6615.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380408.963000 420396.223000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6615</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 112 774</ms:GML_ID>
        <ms:NAZWA>181 112 774</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181112774</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6614">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380421.315668 420837.943289</gml:lowerCorner>
        		<gml:upperCorner>380421.315668 420837.943289</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6614.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380421.315668 420837.943289</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6614</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 112 332</ms:GML_ID>
        <ms:NAZWA>181 112 332</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181112332</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6613">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380538.001487 421572.630349</gml:lowerCorner>
        		<gml:upperCorner>380538.001487 421572.630349</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6613.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380538.001487 421572.630349</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6613</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 111 584</ms:GML_ID>
        <ms:NAZWA>181 111 584</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181111584</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>403264.516000 422295.180000</gml:lowerCorner>
        		<gml:upperCorner>403264.516000 422295.180000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>403264.516000 422295.180000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 067 624</ms:GML_ID>
        <ms:NAZWA>272 067 624</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272067624</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>402740.705000 422521.786000</gml:lowerCorner>
        		<gml:upperCorner>402740.705000 422521.786000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>402740.705000 422521.786000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 067 054</ms:GML_ID>
        <ms:NAZWA>272 067 054</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272067054</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6612">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380804.360000 422713.415000</gml:lowerCorner>
        		<gml:upperCorner>380804.360000 422713.415000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6612.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380804.360000 422713.415000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6612</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 110 379</ms:GML_ID>
        <ms:NAZWA>181 110 379</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181110379</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.6611">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>380934.738639 423290.292923</gml:lowerCorner>
        		<gml:upperCorner>380934.738639 423290.292923</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.6611.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>380934.738639 423290.292923</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>6611</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.181 109 821</ms:GML_ID>
        <ms:NAZWA>181 109 821</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>181109821</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>400752.375000 423383.576000</gml:lowerCorner>
        		<gml:upperCorner>400752.375000 423383.576000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>400752.375000 423383.576000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.272 064 884</ms:GML_ID>
        <ms:NAZWA>272 064 884</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK POZNAŃ</ms:IDDE>
        <ms:SEARCH>272064884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11370">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556286.067134 506601.063199</gml:lowerCorner>
        		<gml:upperCorner>556286.067134 506601.063199</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11370.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556286.067134 506601.063199</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11370</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 126 919</ms:GML_ID>
        <ms:NAZWA>027 126 919</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027126919</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11369">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556125.763105 506813.093314</gml:lowerCorner>
        		<gml:upperCorner>556125.763105 506813.093314</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11369.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556125.763105 506813.093314</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11369</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 126 650</ms:GML_ID>
        <ms:NAZWA>027 126 650</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027126650</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11368">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555791.752729 507255.070756</gml:lowerCorner>
        		<gml:upperCorner>555791.752729 507255.070756</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11368.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555791.752729 507255.070756</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11368</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 126 098</ms:GML_ID>
        <ms:NAZWA>027 126 098</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027126098</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11367">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555570.727000 507546.851000</gml:lowerCorner>
        		<gml:upperCorner>555570.727000 507546.851000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11367.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555570.727000 507546.851000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11367</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 125 731</ms:GML_ID>
        <ms:NAZWA>027 125 731</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027125731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11366">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555281.321876 507930.655707</gml:lowerCorner>
        		<gml:upperCorner>555281.321876 507930.655707</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11366.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555281.321876 507930.655707</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11366</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 125 252</ms:GML_ID>
        <ms:NAZWA>027 125 252</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027125252</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11365">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554948.235000 508370.969000</gml:lowerCorner>
        		<gml:upperCorner>554948.235000 508370.969000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11365.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554948.235000 508370.969000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11365</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 124 699</ms:GML_ID>
        <ms:NAZWA>027 124 699</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027124699</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11364">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554707.251000 508689.952000</gml:lowerCorner>
        		<gml:upperCorner>554707.251000 508689.952000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11364.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554707.251000 508689.952000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11364</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 124 298</ms:GML_ID>
        <ms:NAZWA>027 124 298</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027124298</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11363">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554546.801000 508902.592000</gml:lowerCorner>
        		<gml:upperCorner>554546.801000 508902.592000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11363.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554546.801000 508902.592000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11363</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 124 031</ms:GML_ID>
        <ms:NAZWA>027 124 031</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027124031</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11362">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554402.895407 509673.818016</gml:lowerCorner>
        		<gml:upperCorner>554402.895407 509673.818016</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11362.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554402.895407 509673.818016</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11362</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 123 225</ms:GML_ID>
        <ms:NAZWA>027 123 225</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027123225</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11361">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554308.760350 511821.726896</gml:lowerCorner>
        		<gml:upperCorner>554308.760350 511821.726896</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11361.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554308.760350 511821.726896</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11361</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 121 049</ms:GML_ID>
        <ms:NAZWA>027 121 049</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027121049</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11360">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554284.359622 512902.281920</gml:lowerCorner>
        		<gml:upperCorner>554284.359622 512902.281920</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11360.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554284.359622 512902.281920</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11360</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 119 968</ms:GML_ID>
        <ms:NAZWA>027 119 968</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027119968</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11359">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>554610.926000 514132.251000</gml:lowerCorner>
        		<gml:upperCorner>554610.926000 514132.251000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11359.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>554610.926000 514132.251000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11359</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 118 689</ms:GML_ID>
        <ms:NAZWA>027 118 689</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027118689</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11358">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555019.077000 515329.504000</gml:lowerCorner>
        		<gml:upperCorner>555019.077000 515329.504000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11358.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555019.077000 515329.504000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11358</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 117 423</ms:GML_ID>
        <ms:NAZWA>027 117 423</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027117423</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11357">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555506.857120 516495.159269</gml:lowerCorner>
        		<gml:upperCorner>555506.857120 516495.159269</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11357.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555506.857120 516495.159269</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11357</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 116 158</ms:GML_ID>
        <ms:NAZWA>027 116 158</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027116158</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11129">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555915.843950 518960.126852</gml:lowerCorner>
        		<gml:upperCorner>555915.843950 518960.126852</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11129.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555915.843950 518960.126852</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11129</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 113 651</ms:GML_ID>
        <ms:NAZWA>027 113 651</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027113651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11128">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556142.332000 520563.299000</gml:lowerCorner>
        		<gml:upperCorner>556142.332000 520563.299000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11128.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556142.332000 520563.299000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11128</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 112 033</ms:GML_ID>
        <ms:NAZWA>027 112 033</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027112033</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11123">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>556053.147000 525021.118000</gml:lowerCorner>
        		<gml:upperCorner>556053.147000 525021.118000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11123.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>556053.147000 525021.118000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11123</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 107 497</ms:GML_ID>
        <ms:NAZWA>027 107 497</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027107497</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11122">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555858.113087 525321.224131</gml:lowerCorner>
        		<gml:upperCorner>555858.113087 525321.224131</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11122.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555858.113087 525321.224131</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11122</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 107 138</ms:GML_ID>
        <ms:NAZWA>027 107 138</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027107138</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11121">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555336.642000 526900.212000</gml:lowerCorner>
        		<gml:upperCorner>555336.642000 526900.212000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11121.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555336.642000 526900.212000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11121</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 105 413</ms:GML_ID>
        <ms:NAZWA>027 105 413</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027105413</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11120">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555379.706000 527666.366000</gml:lowerCorner>
        		<gml:upperCorner>555379.706000 527666.366000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11120.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555379.706000 527666.366000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11120</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 104 645</ms:GML_ID>
        <ms:NAZWA>027 104 645</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027104645</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11119">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555407.199000 528158.742000</gml:lowerCorner>
        		<gml:upperCorner>555407.199000 528158.742000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11119.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555407.199000 528158.742000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11119</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 104 151</ms:GML_ID>
        <ms:NAZWA>027 104 151</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027104151</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11118">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555486.885000 529592.833000</gml:lowerCorner>
        		<gml:upperCorner>555486.885000 529592.833000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11118.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555486.885000 529592.833000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11118</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 102 714</ms:GML_ID>
        <ms:NAZWA>027 102 714</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027102714</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11117">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555587.852000 531399.538000</gml:lowerCorner>
        		<gml:upperCorner>555587.852000 531399.538000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11117.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555587.852000 531399.538000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11117</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 100 903</ms:GML_ID>
        <ms:NAZWA>027 100 903</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027100903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11116">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555655.885000 532621.358000</gml:lowerCorner>
        		<gml:upperCorner>555655.885000 532621.358000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11116.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555655.885000 532621.358000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11116</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 099 679</ms:GML_ID>
        <ms:NAZWA>027 099 679</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027099679</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11115">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555694.155228 533314.727331</gml:lowerCorner>
        		<gml:upperCorner>555694.155228 533314.727331</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11115.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555694.155228 533314.727331</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11115</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 098 984</ms:GML_ID>
        <ms:NAZWA>027 098 984</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027098984</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11114">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555751.386145 534343.639285</gml:lowerCorner>
        		<gml:upperCorner>555751.386145 534343.639285</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11114.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555751.386145 534343.639285</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11114</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 097 954</ms:GML_ID>
        <ms:NAZWA>027 097 954</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027097954</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7920">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>568001.725000 535534.020000</gml:lowerCorner>
        		<gml:upperCorner>568001.725000 535534.020000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7920.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>568001.725000 535534.020000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7920</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 104 127</ms:GML_ID>
        <ms:NAZWA>033 104 127</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033104127</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.11113">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>555820.408000 535582.413000</gml:lowerCorner>
        		<gml:upperCorner>555820.408000 535582.413000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.11113.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>555820.408000 535582.413000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>11113</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.027 096 711</ms:GML_ID>
        <ms:NAZWA>027 096 711</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>027096711</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8739">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>514754.413405 506006.322058</gml:lowerCorner>
        		<gml:upperCorner>514754.413405 506006.322058</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8739.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>514754.413405 506006.322058</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8739</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 037 397</ms:GML_ID>
        <ms:NAZWA>018 037 397</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018037397</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8962">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>515663.821398 506055.595052</gml:lowerCorner>
        		<gml:upperCorner>515663.821398 506055.595052</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8962.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>515663.821398 506055.595052</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8962</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 038 312</ms:GML_ID>
        <ms:NAZWA>018 038 312</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018038312</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8963">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>517053.128004 506127.603976</gml:lowerCorner>
        		<gml:upperCorner>517053.128004 506127.603976</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8963.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>517053.128004 506127.603976</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8963</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 039 702</ms:GML_ID>
        <ms:NAZWA>018 039 702</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018039702</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8964">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518133.271000 506184.232000</gml:lowerCorner>
        		<gml:upperCorner>518133.271000 506184.232000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8964.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518133.271000 506184.232000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8964</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 040 785</ms:GML_ID>
        <ms:NAZWA>018 040 785</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018040785</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8738">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>512739.197603 506993.754446</gml:lowerCorner>
        		<gml:upperCorner>512739.197603 506993.754446</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8738.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>512739.197603 506993.754446</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8738</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 035 130</ms:GML_ID>
        <ms:NAZWA>018 035 130</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018035130</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8737">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>510939.181502 507222.412272</gml:lowerCorner>
        		<gml:upperCorner>510939.181502 507222.412272</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8737.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>510939.181502 507222.412272</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8737</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 033 310</ms:GML_ID>
        <ms:NAZWA>018 033 310</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018033310</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8736">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>509034.843602 507391.630629</gml:lowerCorner>
        		<gml:upperCorner>509034.843602 507391.630629</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8736.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>509034.843602 507391.630629</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8736</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 031 404</ms:GML_ID>
        <ms:NAZWA>018 031 404</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018031404</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8735">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>508561.537112 507433.666029</gml:lowerCorner>
        		<gml:upperCorner>508561.537112 507433.666029</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8735.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>508561.537112 507433.666029</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8735</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 030 922</ms:GML_ID>
        <ms:NAZWA>018 030 922</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018030922</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8734">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>505910.059251 508032.105247</gml:lowerCorner>
        		<gml:upperCorner>505910.059251 508032.105247</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8734.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>505910.059251 508032.105247</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8734</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 028 163</ms:GML_ID>
        <ms:NAZWA>018 028 163</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018028163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8733">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>504840.107413 508572.685165</gml:lowerCorner>
        		<gml:upperCorner>504840.107413 508572.685165</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8733.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>504840.107413 508572.685165</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8733</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 026 964</ms:GML_ID>
        <ms:NAZWA>018 026 964</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018026964</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8732">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>502877.359593 509554.603837</gml:lowerCorner>
        		<gml:upperCorner>502877.359593 509554.603837</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8732.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>502877.359593 509554.603837</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8732</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 024 768</ms:GML_ID>
        <ms:NAZWA>018 024 768</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018024768</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9237">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485409.529215 510551.123784</gml:lowerCorner>
        		<gml:upperCorner>485409.529215 510551.123784</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9237.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485409.529215 510551.123784</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9237</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 139 538</ms:GML_ID>
        <ms:NAZWA>003 139 538</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003139538</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8729">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>500352.853270 510680.919047</gml:lowerCorner>
        		<gml:upperCorner>500352.853270 510680.919047</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8729.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>500352.853270 510680.919047</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8729</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 021 989</ms:GML_ID>
        <ms:NAZWA>018 021 989</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018021989</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8728">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>499547.393860 510825.629279</gml:lowerCorner>
        		<gml:upperCorner>499547.393860 510825.629279</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8728.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>499547.393860 510825.629279</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8728</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 021 163</ms:GML_ID>
        <ms:NAZWA>018 021 163</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018021163</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8727">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>498190.250067 511069.315353</gml:lowerCorner>
        		<gml:upperCorner>498190.250067 511069.315353</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8727.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>498190.250067 511069.315353</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8727</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 019 790</ms:GML_ID>
        <ms:NAZWA>018 019 790</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018019790</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8726">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497794.187470 511140.403929</gml:lowerCorner>
        		<gml:upperCorner>497794.187470 511140.403929</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8726.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497794.187470 511140.403929</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8726</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 019 389</ms:GML_ID>
        <ms:NAZWA>018 019 389</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018019389</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8725">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>497171.856709 511252.105110</gml:lowerCorner>
        		<gml:upperCorner>497171.856709 511252.105110</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8725.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>497171.856709 511252.105110</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8725</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 018 760</ms:GML_ID>
        <ms:NAZWA>018 018 760</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018018760</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8724">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>496361.179531 511397.590512</gml:lowerCorner>
        		<gml:upperCorner>496361.179531 511397.590512</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8724.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>496361.179531 511397.590512</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8724</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 017 931</ms:GML_ID>
        <ms:NAZWA>018 017 931</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018017931</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8723">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>494528.252809 511727.857686</gml:lowerCorner>
        		<gml:upperCorner>494528.252809 511727.857686</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8723.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>494528.252809 511727.857686</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8723</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 016 068</ms:GML_ID>
        <ms:NAZWA>018 016 068</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018016068</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8722">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>493302.578780 512282.774218</gml:lowerCorner>
        		<gml:upperCorner>493302.578780 512282.774218</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8722.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>493302.578780 512282.774218</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8722</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 014 672</ms:GML_ID>
        <ms:NAZWA>018 014 672</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018014672</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8721">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492774.711941 512878.181667</gml:lowerCorner>
        		<gml:upperCorner>492774.711941 512878.181667</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8721.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492774.711941 512878.181667</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8721</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 013 875</ms:GML_ID>
        <ms:NAZWA>018 013 875</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018013875</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8720">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>492106.142000 513609.055000</gml:lowerCorner>
        		<gml:upperCorner>492106.142000 513609.055000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8720.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>492106.142000 513609.055000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8720</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 012 884</ms:GML_ID>
        <ms:NAZWA>018 012 884</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018012884</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8719">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>491082.624000 514877.098000</gml:lowerCorner>
        		<gml:upperCorner>491082.624000 514877.098000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8719.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>491082.624000 514877.098000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8719</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 011 250</ms:GML_ID>
        <ms:NAZWA>018 011 250</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>018011250</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9236">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485769.288000 515463.959000</gml:lowerCorner>
        		<gml:upperCorner>485769.288000 515463.959000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9236.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485769.288000 515463.959000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9236</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 134 608</ms:GML_ID>
        <ms:NAZWA>003 134 608</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003134608</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9235">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>485887.782000 517799.395000</gml:lowerCorner>
        		<gml:upperCorner>485887.782000 517799.395000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9235.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>485887.782000 517799.395000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9235</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 132 280</ms:GML_ID>
        <ms:NAZWA>003 132 280</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003132280</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8979">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>543228.754284 494681.653193</gml:lowerCorner>
        		<gml:upperCorner>543228.754284 494681.653193</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8979.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>543228.754284 494681.653193</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8979</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 070 670</ms:GML_ID>
        <ms:NAZWA>018 070 670</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018070670</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8978">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542545.231000 494787.807000</gml:lowerCorner>
        		<gml:upperCorner>542545.231000 494787.807000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8978.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542545.231000 494787.807000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8978</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 069 979</ms:GML_ID>
        <ms:NAZWA>018 069 979</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018069979</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8977">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541789.968933 494904.686534</gml:lowerCorner>
        		<gml:upperCorner>541789.968933 494904.686534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8977.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541789.968933 494904.686534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8977</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 069 213</ms:GML_ID>
        <ms:NAZWA>018 069 213</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018069213</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8976">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541157.357000 495003.208000</gml:lowerCorner>
        		<gml:upperCorner>541157.357000 495003.208000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8976.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541157.357000 495003.208000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8976</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 068 572</ms:GML_ID>
        <ms:NAZWA>018 068 572</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018068572</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8975">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>540496.214442 495105.667395</gml:lowerCorner>
        		<gml:upperCorner>540496.214442 495105.667395</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8975.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>540496.214442 495105.667395</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8975</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 067 903</ms:GML_ID>
        <ms:NAZWA>018 067 903</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018067903</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8974">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536707.235470 497698.934163</gml:lowerCorner>
        		<gml:upperCorner>536707.235470 497698.934163</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8974.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536707.235470 497698.934163</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8974</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 062 905</ms:GML_ID>
        <ms:NAZWA>018 062 905</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018062905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8973">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536500.988933 498033.451933</gml:lowerCorner>
        		<gml:upperCorner>536500.988933 498033.451933</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8973.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536500.988933 498033.451933</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8973</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 062 535</ms:GML_ID>
        <ms:NAZWA>018 062 535</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018062535</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8972">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533545.923000 502692.393000</gml:lowerCorner>
        		<gml:upperCorner>533545.923000 502692.393000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8972.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533545.923000 502692.393000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8972</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 056 995</ms:GML_ID>
        <ms:NAZWA>018 056 995</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018056995</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8971">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533339.043214 503021.660447</gml:lowerCorner>
        		<gml:upperCorner>533339.043214 503021.660447</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8971.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533339.043214 503021.660447</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8971</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 056 595</ms:GML_ID>
        <ms:NAZWA>018 056 595</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018056595</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8970">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>533026.773106 503480.609943</gml:lowerCorner>
        		<gml:upperCorner>533026.773106 503480.609943</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8970.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>533026.773106 503480.609943</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8970</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 056 044</ms:GML_ID>
        <ms:NAZWA>018 056 044</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018056044</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8969">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>532770.439000 503659.956000</gml:lowerCorner>
        		<gml:upperCorner>532770.439000 503659.956000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8969.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>532770.439000 503659.956000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8969</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 055 731</ms:GML_ID>
        <ms:NAZWA>018 055 731</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018055731</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8968">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>531590.816985 504126.378534</gml:lowerCorner>
        		<gml:upperCorner>531590.816985 504126.378534</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8968.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>531590.816985 504126.378534</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8968</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 054 464</ms:GML_ID>
        <ms:NAZWA>018 054 464</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018054464</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8967">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>526584.236280 505120.016378</gml:lowerCorner>
        		<gml:upperCorner>526584.236280 505120.016378</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8967.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>526584.236280 505120.016378</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8967</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 049 338</ms:GML_ID>
        <ms:NAZWA>018 049 338</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018049338</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8966">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>524555.650335 505436.555503</gml:lowerCorner>
        		<gml:upperCorner>524555.650335 505436.555503</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8966.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>524555.650335 505436.555503</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8966</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 047 285</ms:GML_ID>
        <ms:NAZWA>018 047 285</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018047285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8965">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>519992.260401 506201.826468</gml:lowerCorner>
        		<gml:upperCorner>519992.260401 506201.826468</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8965.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>519992.260401 506201.826468</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8965</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.018 042 651</ms:GML_ID>
        <ms:NAZWA>018 042 651</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>018042651</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7881">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518197.832000 545786.480000</gml:lowerCorner>
        		<gml:upperCorner>518197.832000 545786.480000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7881.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518197.832000 545786.480000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7881</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 046 140</ms:GML_ID>
        <ms:NAZWA>033 046 140</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033046140</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7882">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518397.983000 545892.594000</gml:lowerCorner>
        		<gml:upperCorner>518397.983000 545892.594000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7882.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518397.983000 545892.594000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7882</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 046 366</ms:GML_ID>
        <ms:NAZWA>033 046 366</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033046366</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7904">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>542444.742820 546709.408795</gml:lowerCorner>
        		<gml:upperCorner>542444.742820 546709.408795</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7904.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>542444.742820 546709.408795</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7904</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 075 222</ms:GML_ID>
        <ms:NAZWA>033 075 222</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033075222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7903">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>541142.023218 546894.817691</gml:lowerCorner>
        		<gml:upperCorner>541142.023218 546894.817691</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7903.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>541142.023218 546894.817691</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7903</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 073 905</ms:GML_ID>
        <ms:NAZWA>033 073 905</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033073905</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7902">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>539969.992688 547060.739897</gml:lowerCorner>
        		<gml:upperCorner>539969.992688 547060.739897</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7902.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>539969.992688 547060.739897</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7902</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 072 719</ms:GML_ID>
        <ms:NAZWA>033 072 719</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033072719</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7901">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>538088.949000 547548.074000</gml:lowerCorner>
        		<gml:upperCorner>538088.949000 547548.074000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7901.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>538088.949000 547548.074000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7901</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 070 773</ms:GML_ID>
        <ms:NAZWA>033 070 773</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033070773</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7888">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>521772.029000 547818.300000</gml:lowerCorner>
        		<gml:upperCorner>521772.029000 547818.300000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7888.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>521772.029000 547818.300000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7888</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 053 222</ms:GML_ID>
        <ms:NAZWA>033 053 222</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033053222</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7900">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>536292.027653 548054.247339</gml:lowerCorner>
        		<gml:upperCorner>536292.027653 548054.247339</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7900.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>536292.027653 548054.247339</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7900</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 068 908</ms:GML_ID>
        <ms:NAZWA>033 068 908</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033068908</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7883">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>518980.235886 548061.992790</gml:lowerCorner>
        		<gml:upperCorner>518980.235886 548061.992790</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7883.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>518980.235886 548061.992790</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7883</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 049 050</ms:GML_ID>
        <ms:NAZWA>033 049 050</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>033049050</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7899">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535580.433000 548089.509000</gml:lowerCorner>
        		<gml:upperCorner>535580.433000 548089.509000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7899.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535580.433000 548089.509000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7899</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 068 193</ms:GML_ID>
        <ms:NAZWA>033 068 193</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033068193</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.7898">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>535025.685268 548104.961307</gml:lowerCorner>
        		<gml:upperCorner>535025.685268 548104.961307</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.7898.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>535025.685268 548104.961307</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>7898</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.033 067 639</ms:GML_ID>
        <ms:NAZWA>033 067 639</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>033067639</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5502">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>462532.374315 494019.743991</gml:lowerCorner>
        		<gml:upperCorner>462532.374315 494019.743991</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5502.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>462532.374315 494019.743991</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5502</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 220 295</ms:GML_ID>
        <ms:NAZWA>131 220 295</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131220295</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5500">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459925.007000 495129.753000</gml:lowerCorner>
        		<gml:upperCorner>459925.007000 495129.753000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5500.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459925.007000 495129.753000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5500</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 217 459</ms:GML_ID>
        <ms:NAZWA>131 217 459</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131217459</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5499">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>459032.992000 495453.954000</gml:lowerCorner>
        		<gml:upperCorner>459032.992000 495453.954000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5499.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>459032.992000 495453.954000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5499</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 216 504</ms:GML_ID>
        <ms:NAZWA>131 216 504</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131216504</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5498">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>457774.169000 495863.830000</gml:lowerCorner>
        		<gml:upperCorner>457774.169000 495863.830000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5498.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>457774.169000 495863.830000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5498</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 215 183</ms:GML_ID>
        <ms:NAZWA>131 215 183</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131215183</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5492">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450266.265000 495979.774000</gml:lowerCorner>
        		<gml:upperCorner>450266.265000 495979.774000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5492.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450266.265000 495979.774000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5492</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 207 598</ms:GML_ID>
        <ms:NAZWA>131 207 598</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131207598</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5493">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>450574.683000 496023.960000</gml:lowerCorner>
        		<gml:upperCorner>450574.683000 496023.960000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5493.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>450574.683000 496023.960000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5493</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 207 910</ms:GML_ID>
        <ms:NAZWA>131 207 910</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131207910</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5497">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>456052.461000 496105.957000</gml:lowerCorner>
        		<gml:upperCorner>456052.461000 496105.957000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5497.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>456052.461000 496105.957000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5497</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 213 442</ms:GML_ID>
        <ms:NAZWA>131 213 442</ms:NAZWA>
        <ms:KATEGORIA>A</ms:KATEGORIA>
        <ms:STAC_SZLAK>stacyjny</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131213442</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5494">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>452189.716000 496254.842000</gml:lowerCorner>
        		<gml:upperCorner>452189.716000 496254.842000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5494.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>452189.716000 496254.842000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5494</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 209 543</ms:GML_ID>
        <ms:NAZWA>131 209 543</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131209543</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5496">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>454410.771000 496334.947000</gml:lowerCorner>
        		<gml:upperCorner>454410.771000 496334.947000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5496.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>454410.771000 496334.947000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5496</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 211 794</ms:GML_ID>
        <ms:NAZWA>131 211 794</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131211794</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.5495">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>453227.326000 496403.120000</gml:lowerCorner>
        		<gml:upperCorner>453227.326000 496403.120000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.5495.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>453227.326000 496403.120000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>5495</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.131 210 591</ms:GML_ID>
        <ms:NAZWA>131 210 591</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK GDAŃSK</ms:IDDE>
        <ms:SEARCH>131210591</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.9243">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>484691.934266 496893.292038</gml:lowerCorner>
        		<gml:upperCorner>484691.934266 496893.292038</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.9243.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>484691.934266 496893.292038</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>9243</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.003 153 238</ms:GML_ID>
        <ms:NAZWA>003 153 238</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>003153238</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8688">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>466121.606000 512714.006000</gml:lowerCorner>
        		<gml:upperCorner>466121.606000 512714.006000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8688.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>466121.606000 512714.006000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8688</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 047 887</ms:GML_ID>
        <ms:NAZWA>016 047 887</ms:NAZWA>
        <ms:KATEGORIA>E</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016047887</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8689">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>469726.266000 513766.877000</gml:lowerCorner>
        		<gml:upperCorner>469726.266000 513766.877000</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8689.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>469726.266000 513766.877000</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8689</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 051 791</ms:GML_ID>
        <ms:NAZWA>016 051 791</ms:NAZWA>
        <ms:KATEGORIA>D</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016051791</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8687">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463901.787039 513910.123149</gml:lowerCorner>
        		<gml:upperCorner>463901.787039 513910.123149</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8687.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463901.787039 513910.123149</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8687</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 045 285</ms:GML_ID>
        <ms:NAZWA>016 045 285</ms:NAZWA>
        <ms:KATEGORIA>C</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016045285</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
    <wfs:member>
      <ms:PKP_PLK gml:id="PKP_PLK.8686">
        <gml:boundedBy>
        	<gml:Envelope srsName="urn:ogc:def:crs:EPSG::2180">
        		<gml:lowerCorner>463335.364489 514328.207826</gml:lowerCorner>
        		<gml:upperCorner>463335.364489 514328.207826</gml:upperCorner>
        	</gml:Envelope>
        </gml:boundedBy>
        <ms:msGeometry>
          <gml:Point gml:id="PKP_PLK.8686.1" srsName="urn:ogc:def:crs:EPSG::2180">
            <gml:pos>463335.364489 514328.207826</gml:pos>
          </gml:Point>
        </ms:msGeometry>
        <ms:OGR_FID>8686</ms:OGR_FID>
        <ms:GML_ID>Przejazdy_naklejki.016 044 578</ms:GML_ID>
        <ms:NAZWA>016 044 578</ms:NAZWA>
        <ms:KATEGORIA>B</ms:KATEGORIA>
        <ms:STAC_SZLAK>szlakowy</ms:STAC_SZLAK>
        <ms:IDDE>PKP PLK WARSZAWA</ms:IDDE>
        <ms:SEARCH>016044578</ms:SEARCH>
      </ms:PKP_PLK>
    </wfs:member>
</wfs:FeatureCollection>

